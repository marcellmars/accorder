//go:build !tailscale

package cmd

import (
	"bytes"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestFastBuildCalibrePublishDoesNotRequireNativePayloadEvidence(t *testing.T) {
	for _, dry := range []bool{false, true} {
		for _, allow := range []bool{false, true} {
			name := "publish"
			if dry {
				name = "preview"
			}
			if allow {
				name += "-full-reupload"
			}
			t.Run(name, func(t *testing.T) {
				root := testSetup(t)
				seedPublishCalibreLibrary(t, root)
				remote := t.TempDir()
				withLocalCommandRemote(t, remote)
				withoutSourceCapability(t, func(string) bool { return true })
				build := fastBuildCommand(root)
				if err := build.Run(nil); err != nil {
					t.Fatal(err)
				}
				before, err := snapshotTree(remote)
				if err != nil {
					t.Fatal(err)
				}
				beforeRoot, err := snapshotTree(root)
				if err != nil {
					t.Fatal(err)
				}
				beforeConfig, err := snapshotTree(accorderConfigDir)
				if err != nil {
					t.Fatal(err)
				}
				transferReached := false
				publishCommitStageHook = func(stage string) error {
					if stage == "before-mirror" {
						transferReached = true
					}
					return nil
				}
				t.Cleanup(func() { publishCommitStageHook = nil })
				command := &LibPublishCmd{GroupLib: build.GroupLib, DryRun: dry, AllowCompleteOverwrite: allow, MaxDeletes: 25}
				command.ActionAlias = "alice"
				err = command.Run(nil)
				if err != nil {
					t.Fatalf("database-backed publication required native payload evidence: %v", err)
				}
				after, err := snapshotTree(remote)
				if err != nil || (dry && (before != after || transferReached)) || (!dry && (before == after || !transferReached)) {
					t.Fatalf("wrong preview/execution effects: dry=%v transfer=%v err=%v", dry, transferReached, err)
				}
				if dry {
					afterRoot, err := snapshotTree(root)
					if err != nil || beforeRoot != afterRoot {
						t.Fatalf("preview changed library: %v", err)
					}
					afterConfig, err := snapshotTree(accorderConfigDir)
					if err != nil || beforeConfig != afterConfig {
						t.Fatalf("preview changed configuration: %v", err)
					}
				}
			})
		}
	}
}

func TestFastBuildStandalonePreservesPendingPublication(t *testing.T) {
	root := testSetup(t)
	seedPublishCalibreLibrary(t, root)
	remote := t.TempDir()
	withLocalCommandRemote(t, remote)
	build := fastBuildCommand(root)
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	candidate, err := captureExistingCandidate(root, resolveUploadExcludes(root, nil))
	if err != nil {
		t.Fatal(err)
	}
	interrupted := errors.New("interrupted after manifest")
	publishCommitStageHook = func(stage string) error {
		if stage == "after-manifest" {
			return interrupted
		}
		return nil
	}
	t.Cleanup(func() { publishCommitStageHook = nil })
	if err := publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: 25}); !errors.Is(err, interrupted) {
		t.Fatal(err)
	}
	publishCommitStageHook = nil
	before, err := snapshotTree(root)
	if err != nil {
		t.Fatal(err)
	}
	journal, err := os.ReadFile(publishRecoveryPath("alice"))
	if err != nil {
		t.Fatal(err)
	}
	build.InPipeline = false
	if err := build.Run(nil); err == nil || !strings.Contains(err.Error(), "interrupted publication") {
		t.Fatalf("build blocker = %v", err)
	}
	after, err := snapshotTree(root)
	if err != nil || before != after {
		t.Fatalf("build changed recoverable artifacts: %v", err)
	}
	retained, err := os.ReadFile(publishRecoveryPath("alice"))
	if err != nil || !bytes.Equal(journal, retained) {
		t.Fatalf("recovery journal changed: %v", err)
	}
	command := &LibPublishCmd{GroupLib: build.GroupLib, MaxDeletes: 25}
	command.ActionAlias = "alice"
	if err := command.Run(nil); err != nil {
		t.Fatalf("publication cannot recover: %v", err)
	}
}

func TestFastBuildPreservesRejectedVersionedCheckpoint(t *testing.T) {
	for _, kind := range []string{"future-version", "legacy-digest", "malformed"} {
		t.Run(kind, func(t *testing.T) {
			root := testSetup(t)
			seedPublishCalibreLibrary(t, root)
			build := fastBuildCommand(root)
			if err := build.Run(nil); err != nil {
				t.Fatal(err)
			}
			candidate, err := loadLocalChangeCandidate(root)
			if err != nil {
				t.Fatal(err)
			}
			path := localChangeCandidateFile(root)
			switch kind {
			case "future-version":
				candidate.Version = 3
				if err := writeJSONAtomic(path, candidate); err != nil {
					t.Fatal(err)
				}
			case "legacy-digest":
				if err := writeJSONAtomic(legacyChangeCandidateFile(root), candidate); err != nil {
					t.Fatal(err)
				}
			case "malformed":
				if err := os.WriteFile(path, []byte("{interrupted"), 0600); err != nil {
					t.Fatal(err)
				}
			}
			before, err := snapshotTree(root)
			if err != nil {
				t.Fatal(err)
			}
			if err := build.Run(nil); err == nil {
				t.Fatal("build accepted rejected checkpoint")
			}
			after, err := snapshotTree(root)
			if err != nil || before != after {
				t.Fatalf("rejected checkpoint or artifacts replaced: %v", err)
			}
		})
	}
}

func TestFastBuildSyncRecoveryPreservesVerifiedStage(t *testing.T) {
	for _, edit := range []string{"unchanged", "unchanged-before-rename", "replaced-root", "same-size", "database", "deleted-format", "deleted-database", "missing-stage-evidence", "legacy-with-token"} {
		t.Run(edit, func(t *testing.T) {
			root := testSetup(t)
			seedPublishCalibreLibrary(t, root)
			remote := t.TempDir()
			withLocalCommandRemote(t, remote)
			build := fastBuildCommand(root)
			if err := build.Run(nil); err != nil {
				t.Fatal(err)
			}
			candidate, err := captureExistingCandidate(root, resolveUploadExcludes(root, nil))
			if err != nil {
				t.Fatal(err)
			}
			if err := publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: 25}); err != nil {
				t.Fatal(err)
			}
			destination := filepath.Join(t.TempDir(), "restored")
			command := &LibSyncCmd{GroupLib: build.GroupLib}
			command.ActionAlias, command.CalibreDirectory = "bob", destination
			interrupted := errors.New("interrupted after activation")
			syncAfterActivateHook = func() error { return interrupted }
			t.Cleanup(func() { syncAfterActivateHook = nil })
			if err := command.Run(nil); !errors.Is(err, interrupted) {
				t.Fatal(err)
			}
			syncAfterActivateHook = nil
			var record syncActivationRecord
			if err := readJSONFile(syncActivationPath("bob"), &record); err != nil {
				t.Fatal(err)
			}
			switch edit {
			case "replaced-root":
				original := destination + "-original"
				if err := os.Rename(destination, original); err != nil {
					t.Fatal(err)
				}
				if err := os.CopyFS(destination, os.DirFS(original)); err != nil {
					t.Fatal(err)
				}
			case "unchanged-before-rename":
				if err := os.Rename(destination, record.Stage); err != nil {
					t.Fatal(err)
				}
			case "missing-stage-evidence", "legacy-with-token":
				record.StageEvidence = nil
				if edit == "legacy-with-token" {
					record.Version = machineStateVersion
				}
				if err := writeJSONAtomic(syncActivationPath("bob"), record); err != nil {
					t.Fatal(err)
				}
			}
			journal, err := os.ReadFile(syncActivationPath("bob"))
			if err != nil {
				t.Fatal(err)
			}
			if edit == "same-size" || edit == "database" || edit == "deleted-format" || edit == "deleted-database" {
				path := fastBuildPayload
				if edit == "database" || edit == "deleted-database" {
					path = "metadata.db"
				}
				full := filepath.Join(destination, filepath.FromSlash(path))
				info, err := os.Stat(full)
				if err != nil {
					t.Fatal(err)
				}
				time.Sleep(2 * time.Millisecond)
				if strings.HasPrefix(edit, "deleted-") {
					if err := os.Remove(full); err != nil {
						t.Fatal(err)
					}
				} else {
					writeTestFile(t, destination, path, "changed")
					if err := os.Chtimes(full, info.ModTime(), info.ModTime()); err != nil {
						t.Fatal(err)
					}
				}
				if edit == "same-size" {
					fastBuildCalibreEdit(t, destination, 1)
				} else if edit == "deleted-format" {
					fastBuildSQL(t, destination, "DELETE FROM data WHERE book=1")
					fastBuildCalibreEdit(t, destination, 1)
				}
			}
			err = recoverSyncActivation("bob")
			if strings.HasPrefix(edit, "unchanged") {
				if err != nil {
					t.Fatal(err)
				}
				if err := command.Run(nil); err != nil {
					t.Fatalf("unchanged sync not current: %v", err)
				}
				return
			}
			if err == nil {
				t.Fatal("recovery granted coverage for edited payload")
			}
			retained, err := os.ReadFile(syncActivationPath("bob"))
			if err != nil || !bytes.Equal(journal, retained) {
				t.Fatalf("lost recovery journal: %v", err)
			}
			if baseline, err := loadBaseline("bob"); err != nil || baseline != nil {
				t.Fatalf("manufactured baseline: %+v %v", baseline, err)
			}
		})
	}
}
