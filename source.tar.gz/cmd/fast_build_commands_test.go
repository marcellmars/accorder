//go:build !tailscale

package cmd

import (
	"bytes"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
	"time"
)

const fastBuildLibraryID = "550e8400-e29b-41d4-a716-446655440000"
const fastBuildPayload = "Author/Book (1)/Book - Author.epub"

func TestFastBuildRecoveryRejectsWrongVersionInNewPath(t *testing.T) {
	for _, version := range []int{0, 1, 3} {
		t.Run(fmt.Sprint(version), func(t *testing.T) {
			root := testSetup(t)
			path := evidenceStatePath(legacyPublishRecoveryPath("alice"))
			if err := writeJSONAtomic(path, publishRecoveryRecord{Version: version}); err != nil {
				t.Fatal(err)
			}
			before, err := os.ReadFile(path)
			if err != nil {
				t.Fatal(err)
			}
			// No remote is needed: reject the schema before any remote operation.
			if recovered, err := recoverPublishBookkeeping("alice", fastBuildLibraryID, nil, root, publishOptions{}); recovered || err == nil {
				t.Fatalf("recovered=%v err=%v", recovered, err)
			}
			after, err := os.ReadFile(path)
			if err != nil || !bytes.Equal(before, after) {
				t.Fatalf("recovery was altered: %v", err)
			}
		})
	}
}

func fastBuildCommand(root string) *LibBuildCmd {
	c := &LibBuildCmd{GroupLib: GroupLib{GroupLibDir: GroupLibDir{CalibreDirectory: root}, LibraryID: fastBuildLibraryID,
		Librarian: "Alice", JsonLPath: filepath.Join(root, "static/catalog.jsonl"), IndexPath: filepath.Join(root, "static/library_index"), Index: new(bool)}}
	c.ActionAlias, c.InPipeline = "alice", true
	return c
}

func TestFastBuildCommandsFirstBuildAndSameSizePublish(t *testing.T) {
	root := testSetup(t)
	seedPublishCalibreLibrary(t, root)
	remote := t.TempDir()
	withLocalCommandRemote(t, remote)
	build := fastBuildCommand(root)
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	first, err := loadLocalChangeCandidate(root)
	if err != nil {
		t.Fatal(err)
	}
	if first.ContentLedgerVersion != sourceEvidenceVersion {
		t.Fatal("build did not create v2")
	}
	for _, object := range first.ContentLedger {
		if strings.HasSuffix(object.Path, ".epub") && object.Hash != "" {
			t.Fatal("first build hashed a format")
		}
	}
	if _, err := os.Stat(legacyChangeCandidateFile(root)); !os.IsNotExist(err) {
		t.Fatalf("first build created a misleading v1 file: %v", err)
	}
	candidate, err := captureExistingCandidate(root, resolveUploadExcludes(root, nil))
	if err != nil || candidate.Change == nil {
		t.Fatalf("capture=%+v %v", candidate, err)
	}
	if err := publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: 25}); err != nil {
		t.Fatal(err)
	}
	baseline, err := loadBaseline("alice")
	if err != nil || baseline.ContentLedgerVersion != sourceEvidenceVersion {
		t.Fatalf("baseline=%+v %v", baseline, err)
	}
	info, err := os.Stat(filepath.Join(root, filepath.FromSlash(fastBuildPayload)))
	if err != nil {
		t.Fatal(err)
	}
	time.Sleep(2 * time.Millisecond)
	writeTestFile(t, root, fastBuildPayload, "changed")
	if err := os.Chtimes(filepath.Join(root, filepath.FromSlash(fastBuildPayload)), info.ModTime(), info.ModTime()); err != nil {
		t.Fatal(err)
	}
	stale, err := captureExistingCandidate(root, resolveUploadExcludes(root, nil))
	if err != nil || stale.Change != nil {
		t.Fatalf("same-size edit retained stale candidate: %+v %v", stale, err)
	}
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	pending, err := loadLocalChangeCandidate(root)
	if err != nil || pending.CompleteOverwrite || !containsString(pending.ForcePaths, fastBuildPayload) {
		t.Fatalf("pending=%+v %v", pending, err)
	}
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	repeated, err := loadLocalChangeCandidate(root)
	if err != nil || !reflect.DeepEqual(repeated.ForcePaths, pending.ForcePaths) {
		t.Fatalf("repeat erased pending paths: %+v %v", repeated, err)
	}
	candidate, err = captureExistingCandidate(root, resolveUploadExcludes(root, nil))
	if err != nil {
		t.Fatal(err)
	}
	if err := publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: 25}); err != nil {
		t.Fatal(err)
	}
	got, err := os.ReadFile(filepath.Join(remote, filepath.FromSlash(fastBuildPayload)))
	if err != nil || string(got) != "changed" {
		t.Fatalf("same-size transfer=%q %v", got, err)
	}
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	settled, err := loadLocalChangeCandidate(root)
	if err != nil || len(settled.ForcePaths) != 0 || settled.CompleteOverwrite {
		t.Fatalf("committed paths stayed pending: %+v %v", settled, err)
	}
}

func TestFastBuildImportsHashesAndRetainsPendingAfterIndexDamage(t *testing.T) {
	root := testSetup(t)
	seedPublishCalibreLibrary(t, root)
	build := fastBuildCommand(root)
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	candidate, err := loadLocalChangeCandidate(root)
	if err != nil {
		t.Fatal(err)
	}
	// Construct the complete checkpoint an older checksum-based client saved.
	for i := range candidate.ContentLedger {
		object := &candidate.ContentLedger[i]
		object.Hash, err = hashLocalFile(filepath.Join(root, filepath.FromSlash(object.Path)))
		if err != nil {
			t.Fatal(err)
		}
	}
	originalLedger := append(candidate.ContentLedger[:0:0], candidate.ContentLedger...)
	if err := os.Remove(localChangeCandidateFile(root)); err != nil {
		t.Fatal(err)
	}
	candidate.Version, candidate.ContentLedgerVersion = 1, 1
	candidate.Evidence = nil
	candidate.LegacyDigest = ""
	if err := saveLocalChangeCandidate(root, *candidate); err != nil {
		t.Fatal(err)
	}
	legacy, err := os.ReadFile(legacyChangeCandidateFile(root))
	if err != nil {
		t.Fatal(err)
	}
	for _, damageIndex := range []bool{false, true} {
		if damageIndex {
			writeTestFile(t, root, candidate.IndexArtifact.Path, "interrupted index rebuild")
		}
		if err := build.Run(nil); err != nil {
			t.Fatal(err)
		}
		current, err := loadLocalChangeCandidate(root)
		if err != nil {
			t.Fatal(err)
		}
		if !reflect.DeepEqual(current.ContentLedger, originalLedger) {
			t.Fatalf("damage=%v: migration/rebuild lost validated hashes", damageIndex)
		}
		for _, path := range candidate.ForcePaths {
			if !containsString(current.ForcePaths, path) {
				t.Fatalf("damage=%v: lost pending path %s", damageIndex, path)
			}
		}
		if !current.CompleteOverwrite {
			t.Fatal("unknown remote history became complete coverage")
		}
		retained, err := os.ReadFile(legacyChangeCandidateFile(root))
		if err != nil || !bytes.Equal(legacy, retained) {
			t.Fatalf("legacy checkpoint was altered: %v", err)
		}
	}
}

func TestFastBuildDryRunMatchesPublishPlan(t *testing.T) {
	for _, authorize := range []bool{false, true} {
		t.Run(map[bool]string{false: "unknown-blocked", true: "unknown-authorized"}[authorize], func(t *testing.T) {
			root := testSetup(t)
			seedPublishCalibreLibrary(t, root)
			remote := t.TempDir()
			withLocalCommandRemote(t, remote)
			if err := fastBuildCommand(root).Run(nil); err != nil {
				t.Fatal(err)
			}
			// Non-empty committed remote; no local predecessor coverage exists.
			writeTestFile(t, remote, "metadata.db", "old database")
			seedCommittedRemote(t, remote, 7)
			candidate, err := captureExistingCandidate(root, resolveUploadExcludes(root, nil))
			if err != nil {
				t.Fatal(err)
			}
			beforeRoot, _ := snapshotTree(root)
			beforeConfig, _ := snapshotTree(accorderConfigDir)
			beforeRemote, _ := snapshotTree(remote)
			options := publishOptions{DryRun: true, LocalWins: true, MaxDeletes: 25, AllowCompleteOverwrite: authorize}
			err = publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, options)
			if authorize && err != nil {
				t.Fatal(err)
			}
			if !authorize && (err == nil || !strings.Contains(err.Error(), "--allow-full-reupload")) {
				t.Fatalf("preview blocker=%v", err)
			}
			afterRoot, _ := snapshotTree(root)
			afterConfig, _ := snapshotTree(accorderConfigDir)
			afterRemote, _ := snapshotTree(remote)
			if beforeRoot != afterRoot || beforeConfig != afterConfig || beforeRemote != afterRemote {
				t.Fatal("preview mutated persistent state")
			}
			options.DryRun = false
			err = publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, options)
			if authorize && err != nil {
				t.Fatal(err)
			}
			if !authorize && (err == nil || !strings.Contains(err.Error(), "--allow-full-reupload")) {
				t.Fatalf("execution blocker=%v", err)
			}
		})
	}
}

func TestFastBuildDerivedRepairPreservesCoverage(t *testing.T) {
	root := testSetup(t)
	seedPublishCalibreLibrary(t, root)
	remote := t.TempDir()
	withLocalCommandRemote(t, remote)
	build := fastBuildCommand(root)
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	candidate, err := captureExistingCandidate(root, resolveUploadExcludes(root, nil))
	if err != nil {
		t.Fatal(err)
	}
	if err := publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: 25}); err != nil {
		t.Fatal(err)
	}
	baseline, err := loadBaseline("alice")
	if err != nil {
		t.Fatal(err)
	}
	writeTestFile(t, root, fastBuildPayload, "changed")
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	pending, err := loadLocalChangeCandidate(root)
	if err != nil {
		t.Fatal(err)
	}
	command := &LibUploadCmd{GroupLib: build.GroupLib}
	command.ActionAlias = "alice"
	if err := command.runDerivedRepair([]string{"static/library_index.zst", "static/library_index.jsonl.zst"}); err != nil {
		t.Fatal(err)
	}
	updated, err := loadBaseline("alice")
	if err != nil {
		t.Fatal(err)
	}
	if updated.GenerationToken == baseline.GenerationToken || !reflect.DeepEqual(updated.ContentLedger, baseline.ContentLedger) || !updated.UpdatedAt.Equal(baseline.UpdatedAt) {
		t.Fatal("repair lost payload history")
	}
	updatedCandidate, err := loadLocalChangeCandidate(root)
	if err != nil || !containsString(updatedCandidate.ForcePaths, fastBuildPayload) || updatedCandidate.FromGeneration != updated.GenerationToken || updatedCandidate.CompleteOverwrite {
		t.Fatalf("pending repair rebase=%+v %v (before=%+v)", updatedCandidate, err, pending)
	}
	got, err := os.ReadFile(filepath.Join(remote, filepath.FromSlash(fastBuildPayload)))
	if err != nil || !bytes.Equal(got, []byte("payload")) {
		t.Fatalf("repair transferred payload: %q %v", got, err)
	}
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	candidate, err = captureExistingCandidate(root, resolveUploadExcludes(root, nil))
	if err != nil {
		t.Fatal(err)
	}
	if err := publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: 25}); err != nil {
		t.Fatal(err)
	}
	got, err = os.ReadFile(filepath.Join(remote, filepath.FromSlash(fastBuildPayload)))
	if err != nil || string(got) != "changed" {
		t.Fatalf("pending edit lost after repair: %q %v", got, err)
	}
}

func TestFastBuildSourceBoundaries(t *testing.T) {
	for _, stage := range []string{"before-mirror", "after-mirror", "before-manifest", "before-sentinel"} {
		t.Run(stage, func(t *testing.T) {
			root := testSetup(t)
			seedPublishCalibreLibrary(t, root)
			remote := t.TempDir()
			withLocalCommandRemote(t, remote)
			if err := fastBuildCommand(root).Run(nil); err != nil {
				t.Fatal(err)
			}
			candidate, err := captureExistingCandidate(root, resolveUploadExcludes(root, nil))
			if err != nil {
				t.Fatal(err)
			}
			info, err := os.Stat(filepath.Join(root, filepath.FromSlash(fastBuildPayload)))
			if err != nil {
				t.Fatal(err)
			}
			reached := false
			publishCommitStageHook = func(at string) error {
				if at == stage {
					reached = true
					time.Sleep(2 * time.Millisecond)
					writeTestFile(t, root, fastBuildPayload, "changed")
					return os.Chtimes(filepath.Join(root, filepath.FromSlash(fastBuildPayload)), info.ModTime(), info.ModTime())
				}
				return nil
			}
			t.Cleanup(func() { publishCommitStageHook = nil })
			err = publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: 25})
			if !reached || err == nil || !strings.Contains(err.Error(), "library files changed") {
				t.Fatalf("source edit not rejected at %s: %v", stage, err)
			}
			if _, err := os.Stat(filepath.Join(remote, "_GENERATION")); !os.IsNotExist(err) {
				t.Fatalf("edit activated a generation: %v", err)
			}
		})
	}
}

func TestFastBuildInterruptedPublication(t *testing.T) {
	for _, stage := range []string{"before-mirror", "after-manifest", "after-pointer", "after-sentinel"} {
		t.Run(stage, func(t *testing.T) {
			root := testSetup(t)
			seedPublishCalibreLibrary(t, root)
			remote := t.TempDir()
			withLocalCommandRemote(t, remote)
			build := fastBuildCommand(root)
			if err := build.Run(nil); err != nil {
				t.Fatal(err)
			}
			candidate, err := captureExistingCandidate(root, resolveUploadExcludes(root, nil))
			if err != nil {
				t.Fatal(err)
			}
			interrupted := errors.New("injected interruption")
			publishCommitStageHook = func(at string) error {
				if at == stage {
					return interrupted
				}
				return nil
			}
			t.Cleanup(func() { publishCommitStageHook = nil })
			if err := publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: 25}); !errors.Is(err, interrupted) {
				t.Fatal(err)
			}
			var record publishRecoveryRecord
			if err := readJSONFile(evidenceStatePath(legacyPublishRecoveryPath("alice")), &record); err != nil {
				t.Fatal(err)
			}
			if record.Version != sourceEvidenceVersion || record.Evidence == nil {
				t.Fatal("new recovery was not isolated/versioned")
			}
			if _, err := os.Stat(legacyPublishRecoveryPath("alice")); !os.IsNotExist(err) {
				t.Fatalf("new recovery appeared in old-client path: %v", err)
			}
			publishCommitStageHook = nil
			command := &LibPublishCmd{GroupLib: build.GroupLib, MaxDeletes: 25}
			command.ActionAlias = "alice"
			if err := command.Run(nil); err != nil {
				t.Fatal(err)
			}
			snapshot := (&libraryRemote{fsPath: remote}).commitState()
			if snapshot.Err != nil || !snapshot.Committed {
				t.Fatalf("recovery did not finish: %+v", snapshot)
			}
			if stage != "before-mirror" && !bytes.Equal(snapshot.PointerRaw, record.Pointer) {
				t.Fatal("recovery replaced exact pointer bytes")
			}
		})
	}
}
