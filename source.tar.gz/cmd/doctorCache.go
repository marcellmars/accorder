package cmd

import (
	"encoding/json"
	"fmt"
	"io"
	"math"
	"os"
	"path/filepath"
	"reflect"
	"sort"
	"strings"
	"time"

	rclonefs "github.com/rclone/rclone/fs"
)

type doctorCachePlane struct {
	name       string
	remoteName string
	capField   string
	capPath    string
}

// resolvedCapPath returns the alias-relative gjson path holding this plane's
// saved cap. Planes built without an explicit capPath default to the live
// serve subtree, preserving the original two-plane construction.
func (p doctorCachePlane) resolvedCapPath() string {
	if p.capPath != "" {
		return p.capPath
	}
	return "fedlib.share.live." + p.capField
}

type doctorCacheContext struct {
	currentRoot   string
	rootError     error
	ledgerRoots   map[string]map[string]bool
	ledgerWarning string
}

type doctorRootFootprint struct {
	dataBytes     int64
	metaBytes     int64
	dataPresent   bool
	metaPresent   bool
	dataAvailable bool
	metaAvailable bool
	incomplete    bool
}

type doctorCacheRange struct {
	Pos  int64
	Size int64
}

type doctorCacheMetadata struct {
	Size int64
	Rs   []doctorCacheRange
}

func parseVFSCacheSize(value string) (int64, error) {
	var size rclonefs.SizeSuffix
	if err := size.Set(strings.TrimSpace(value)); err != nil {
		return 0, fmt.Errorf("invalid rclone size %q: %w", value, err)
	}
	return int64(size), nil
}

func (c *DoctorCmd) checkCachePlanes() []checkResult {
	live := liveCacheRemoteNames(c.ActionAlias)
	funnel := funnelCacheRemoteNames(c.ActionAlias)
	liveCtx := c.doctorCacheContext()
	funnelCtx := liveCtx
	funnelCtx.currentRoot, funnelCtx.rootError = c.resolveFunnelCacheRoot()
	planes := []struct {
		plane doctorCachePlane
		ctx   doctorCacheContext
	}{
		{doctorCachePlane{name: "cache books", remoteName: live.Books, capField: "cache-size",
			capPath: "fedlib.share.live.cache-size"}, liveCtx},
		{doctorCachePlane{name: "cache assets", remoteName: live.Assets, capField: "cache-size-assets",
			capPath: "fedlib.share.live.cache-size-assets"}, liveCtx},
		{doctorCachePlane{name: "funnel cache books", remoteName: funnel.Books, capField: "cache-size",
			capPath: "fedlib.share.funnel.cache-size"}, funnelCtx},
		{doctorCachePlane{name: "funnel cache assets", remoteName: funnel.Assets, capField: "cache-size-assets",
			capPath: "fedlib.share.funnel.cache-size-assets"}, funnelCtx},
	}
	out := make([]checkResult, 0, len(planes))
	for _, item := range planes {
		out = append(out, c.checkCachePlane(item.plane, item.ctx))
	}
	return out
}

func (c *DoctorCmd) resolveFunnelCacheRoot() (string, error) {
	bucket := gjsonAliasString(c.ActionAlias, "fedlib.share.funnel.bucket")
	if bucket == "" {
		return "", fmt.Errorf("no saved --bucket for fedlib share funnel alias %q", c.ActionAlias)
	}
	if !validRemoteRoot(bucket) {
		return "", fmt.Errorf("saved funnel bucket %q is not a safe rclone root", bucket)
	}
	return bucket, nil
}

func (c *DoctorCmd) doctorCacheContext() doctorCacheContext {
	ctx := doctorCacheContext{}
	live, _, err := resolveServeForAlias(c.ActionAlias)
	if err != nil {
		ctx.rootError = err
	} else if err := blockingIssueError("fedlib share live", live.descriptorPreflight()); err != nil {
		ctx.rootError = err
	} else if live.Bucket == "" {
		ctx.rootError = fmt.Errorf("descriptor for %q has no bucket", c.ActionAlias)
	} else if !validRemoteRoot(live.Bucket) {
		ctx.rootError = fmt.Errorf("descriptor bucket %q is not a safe rclone root", live.Bucket)
	} else {
		ctx.currentRoot = live.Bucket
	}

	records, malformed, err := readLedger()
	switch {
	case err != nil:
		ctx.ledgerWarning = "identity ledger unreadable: " + err.Error()
	case malformed:
		ctx.ledgerWarning = "identity ledger malformed; ledger roots omitted"
	default:
		ctx.ledgerRoots = replayLedger(records).activeRoots
	}
	return ctx
}

func (c *DoctorCmd) checkCachePlane(plane doctorCachePlane, ctx doctorCacheContext) checkResult {
	roots, inventoryWarnings, remotePresent := doctorCacheRoots(plane.remoteName, ctx.currentRoot, ctx.ledgerRoots)
	warnings := append([]string(nil), inventoryWarnings...)
	if ctx.ledgerWarning != "" {
		warnings = append(warnings, ctx.ledgerWarning)
	}
	if !remotePresent {
		// No cache tree for this remote on disk. That is the healthy state
		// for a host that never serves through it (lib-only machine, fresh
		// serve host, funnel-only host for the live planes) — skip, so
		// doctor exits 0, matching the pre-split behavior. Warn only when
		// something disagrees: an unreadable tree (EACCES lands in
		// inventoryWarnings and must not be misreported as absence), a
		// ledger problem, or ledger-recorded active roots for a gone tree.
		if len(ctx.ledgerRoots[plane.remoteName]) > 0 {
			warnings = append(warnings, fmt.Sprintf(
				"identity ledger records active roots for %s but no cache tree exists", plane.remoteName))
		}
		if len(warnings) == 0 {
			return checkResult{name: plane.name, verdict: vSkipped,
				detail: fmt.Sprintf("no VFS cache tree for %s", plane.remoteName)}
		}
		return checkResult{name: plane.name, verdict: vWarn,
			detail: strings.Join(append([]string{
				fmt.Sprintf("no readable VFS cache tree for %s", plane.remoteName)}, warnings...), "; ")}
	}
	if ctx.rootError != nil {
		warnings = append(warnings, "current root unresolved: "+ctx.rootError.Error())
	}

	budget := defaultSizeBudget.newState()
	rootDetails := make([]string, 0, len(roots))
	currentFound := false
	var cleanerBytes int64
	cleanerOK := false
	cleanerPartial := false
	for _, root := range roots {
		dataRoot := filepath.Join(accorderCacheDir(), "vfs", plane.remoteName, filepath.FromSlash(root))
		metaRoot := filepath.Join(accorderCacheDir(), "vfsMeta", plane.remoteName, filepath.FromSlash(root))
		footprint := doctorAllocatedFootprint(dataRoot, metaRoot, defaultSizeBudget, budget)
		label := "stale " + fmt.Sprintf("%q", root)
		if root == ctx.currentRoot && ctx.rootError == nil {
			label = "current " + fmt.Sprintf("%q", root)
			currentFound = true
			if !footprint.dataPresent || !footprint.metaPresent {
				warnings = append(warnings, fmt.Sprintf("current root %q has only %s",
					root, presentCacheHalves(footprint.dataPresent, footprint.metaPresent)))
			} else {
				var accountWarnings []string
				cleanerBytes, accountWarnings = doctorCleanerBytes(dataRoot, metaRoot, defaultSizeBudget)
				// The total stays usable across accounting warnings:
				// skipped entries only make it a lower bound, and a lower
				// bound over cap is still over cap. Discarding it would let
				// a single corrupt vfsMeta file permanently mask the
				// "eviction is not keeping up" check.
				cleanerOK = true
				if len(accountWarnings) > 0 {
					cleanerPartial = true
					warnings = append(warnings, accountWarnings...)
				}
			}
		} else {
			warnings = append(warnings, fmt.Sprintf("stale root %q remains outside the current cap", root))
		}
		if footprint.incomplete {
			warnings = append(warnings, fmt.Sprintf("%s footprint walk incomplete", label))
		}
		rootDetails = append(rootDetails, label+": "+formatDoctorFootprint(footprint))
	}

	if ctx.rootError == nil && !currentFound {
		warnings = append(warnings, fmt.Sprintf("current root %q is missing", ctx.currentRoot))
	}
	if ctx.rootError == nil && cleanerOK {
		rawCap := gjsonAliasString(c.ActionAlias, plane.resolvedCapPath())
		switch {
		case rawCap == "":
			// Missing trees were skipped before accounting. Reaching this
			// branch means the plane exists at its current root, so an absent
			// cap is active configuration drift rather than a harmless legacy
			// alias that has never started this plane.
			warnings = append(warnings, "no saved --"+plane.capField+" cap recorded for this alias")
		default:
			capBytes, err := parseVFSCacheSize(rawCap)
			if err != nil || capBytes <= 0 {
				warnings = append(warnings, fmt.Sprintf("saved --%s value %q is invalid", plane.capField, rawCap))
			} else {
				cleanerLabel := formatByteSize(cleanerBytes)
				if cleanerPartial {
					cleanerLabel = "at least " + cleanerLabel
				}
				rootDetails = append([]string{fmt.Sprintf("cleaner %s of %s cap", cleanerLabel, formatByteSize(capBytes))}, rootDetails...)
				if cleanerBytes > capBytes {
					warnings = append(warnings, "eviction is not keeping up")
				}
			}
		}
	}

	details := append(rootDetails, warnings...)
	if len(details) == 0 {
		details = append(details, "no VFS cache roots found")
	}
	verdict := vOK
	if len(warnings) > 0 {
		verdict = vWarn
	}
	return checkResult{name: plane.name, verdict: verdict, detail: strings.Join(details, "; ")}
}

func doctorCacheRoots(remoteName, currentRoot string, ledgerRoots map[string]map[string]bool) (roots []string, warnings []string, remotePresent bool) {
	exact := make(map[string]bool)
	if currentRoot != "" {
		exact[currentRoot] = true
	}
	for root := range ledgerRoots[remoteName] {
		if validRemoteRoot(root) {
			exact[root] = true
		}
	}
	discovered := make(map[string]bool)
	for _, half := range []string{"vfs", "vfsMeta"} {
		remoteDir := filepath.Join(accorderCacheDir(), half, remoteName)
		entries, err := os.ReadDir(remoteDir)
		if err != nil {
			if !os.IsNotExist(err) {
				warnings = append(warnings, fmt.Sprintf("cannot inventory %s: %v", remoteDir, err))
			}
			continue
		}
		remotePresent = true
		for _, entry := range entries {
			if entry.IsDir() && validRemoteRoot(entry.Name()) {
				discovered[entry.Name()] = true
			}
		}
	}
	for root := range discovered {
		covered := false
		for known := range exact {
			if known == root || strings.HasPrefix(known, root+"/") {
				covered = true
				break
			}
		}
		if !covered {
			exact[root] = true
		}
	}
	for root := range exact {
		dataPath := filepath.Join(accorderCacheDir(), "vfs", remoteName, filepath.FromSlash(root))
		metaPath := filepath.Join(accorderCacheDir(), "vfsMeta", remoteName, filepath.FromSlash(root))
		if dirExists(dataPath) || dirExists(metaPath) {
			roots = append(roots, root)
		}
	}
	sort.Slice(roots, func(i, j int) bool {
		if roots[i] == currentRoot {
			return true
		}
		if roots[j] == currentRoot {
			return false
		}
		return roots[i] < roots[j]
	})
	return roots, warnings, remotePresent
}

func doctorAllocatedFootprint(dataRoot, metaRoot string, budget sizeBudget, state *walkBudgetState) doctorRootFootprint {
	dataBytes, dataPresent, dataAvailable, dataIncomplete := doctorAllocatedTreeBytes(dataRoot, budget, state)
	metaBytes, metaPresent, metaAvailable, metaIncomplete := doctorAllocatedTreeBytes(metaRoot, budget, state)
	return doctorRootFootprint{
		dataBytes: dataBytes, metaBytes: metaBytes,
		dataPresent: dataPresent, metaPresent: metaPresent,
		dataAvailable: dataAvailable, metaAvailable: metaAvailable,
		incomplete: dataIncomplete || metaIncomplete,
	}
}

func doctorAllocatedTreeBytes(root string, budget sizeBudget, state *walkBudgetState) (bytes int64, present, available, incomplete bool) {
	info, err := os.Stat(root)
	if err != nil || !info.IsDir() {
		return 0, false, true, err != nil && !os.IsNotExist(err)
	}
	present, available = true, true
	_ = filepath.WalkDir(root, func(path string, entry os.DirEntry, walkErr error) error {
		if walkErr != nil {
			incomplete = true
			return nil
		}
		state.entries++
		if state.entries > budget.MaxEntries || time.Now().After(state.deadline) {
			incomplete = true
			return filepath.SkipAll
		}
		if !entry.Type().IsRegular() {
			return nil
		}
		info, err := entry.Info()
		if err != nil {
			incomplete = true
			return nil
		}
		allocated, ok := doctorAllocatedBytes(info)
		if !ok {
			available = false
			return nil
		}
		if allocated > math.MaxInt64-bytes {
			incomplete = true
			return filepath.SkipAll
		}
		bytes += allocated
		return nil
	})
	return bytes, present, available, incomplete
}

func doctorAllocatedBytes(info os.FileInfo) (int64, bool) {
	value := reflect.ValueOf(info.Sys())
	if !value.IsValid() {
		return 0, false
	}
	if value.Kind() == reflect.Pointer {
		if value.IsNil() {
			return 0, false
		}
		value = value.Elem()
	}
	if value.Kind() != reflect.Struct {
		return 0, false
	}
	blocks := value.FieldByName("Blocks")
	if !blocks.IsValid() {
		return 0, false
	}
	var count int64
	switch blocks.Kind() {
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		count = blocks.Int()
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
		if blocks.Uint() > math.MaxInt64 {
			return 0, false
		}
		count = int64(blocks.Uint())
	default:
		return 0, false
	}
	if count < 0 || count > math.MaxInt64/512 {
		return 0, false
	}
	return count * 512, true
}

func doctorCleanerBytes(dataRoot, metaRoot string, budget sizeBudget) (total int64, warnings []string) {
	metadata := make(map[string]bool)
	state := budget.newState()
	stop := false
	_ = filepath.WalkDir(metaRoot, func(path string, entry os.DirEntry, walkErr error) error {
		if walkErr != nil {
			warnings = appendLimitedWarning(warnings, "metadata walk: "+walkErr.Error())
			return nil
		}
		state.entries++
		if state.entries > budget.MaxEntries || time.Now().After(state.deadline) {
			warnings = appendLimitedWarning(warnings, "metadata accounting hit its traversal budget")
			stop = true
			return filepath.SkipAll
		}
		if !entry.Type().IsRegular() {
			return nil
		}
		rel, err := filepath.Rel(metaRoot, path)
		if err != nil || rel == "." || strings.HasPrefix(rel, ".."+string(filepath.Separator)) {
			warnings = appendLimitedWarning(warnings, "metadata path escaped its root")
			return nil
		}
		metadata[rel] = false
		dataInfo, err := os.Stat(filepath.Join(dataRoot, rel))
		if err != nil || !dataInfo.Mode().IsRegular() {
			warnings = appendLimitedWarning(warnings, fmt.Sprintf("metadata %q has no data file", filepath.ToSlash(rel)))
			return nil
		}
		info, err := readDoctorCacheMetadata(path)
		if err != nil {
			warnings = appendLimitedWarning(warnings, fmt.Sprintf("metadata %q is malformed: %v", filepath.ToSlash(rel), err))
			return nil
		}
		used, err := doctorRangeBytes(info, dataInfo.Size())
		if err != nil {
			warnings = appendLimitedWarning(warnings, fmt.Sprintf("metadata %q is malformed: %v", filepath.ToSlash(rel), err))
			return nil
		}
		metadata[rel] = true
		if used > math.MaxInt64-total {
			warnings = appendLimitedWarning(warnings, "cleaner-accounted byte total overflowed")
			stop = true
			return filepath.SkipAll
		}
		total += used
		return nil
	})
	if stop {
		return total, warnings
	}
	_ = filepath.WalkDir(dataRoot, func(path string, entry os.DirEntry, walkErr error) error {
		if walkErr != nil {
			warnings = appendLimitedWarning(warnings, "data walk: "+walkErr.Error())
			return nil
		}
		state.entries++
		if state.entries > budget.MaxEntries || time.Now().After(state.deadline) {
			warnings = appendLimitedWarning(warnings, "data accounting hit its traversal budget")
			return filepath.SkipAll
		}
		if !entry.Type().IsRegular() {
			return nil
		}
		rel, err := filepath.Rel(dataRoot, path)
		if err != nil || !metadata[rel] {
			warnings = appendLimitedWarning(warnings, fmt.Sprintf("data %q has no decodable metadata", filepath.ToSlash(rel)))
		}
		return nil
	})
	return total, warnings
}

func readDoctorCacheMetadata(path string) (doctorCacheMetadata, error) {
	file, err := os.Open(path)
	if err != nil {
		return doctorCacheMetadata{}, err
	}
	defer file.Close()
	limited := io.LimitReader(file, 1<<20)
	var info doctorCacheMetadata
	if err := json.NewDecoder(limited).Decode(&info); err != nil {
		return doctorCacheMetadata{}, err
	}
	return info, nil
}

func doctorRangeBytes(info doctorCacheMetadata, dataSize int64) (int64, error) {
	if info.Size < 0 {
		return 0, fmt.Errorf("negative object size")
	}
	if dataSize > 0 && info.Size == 0 {
		return 0, fmt.Errorf("zero object size for non-empty data file")
	}
	var total, previousEnd int64
	for index, current := range info.Rs {
		if current.Pos < 0 || current.Size <= 0 || current.Pos > math.MaxInt64-current.Size {
			return 0, fmt.Errorf("invalid range at index %d", index)
		}
		end := current.Pos + current.Size
		if index > 0 && current.Pos < previousEnd {
			return 0, fmt.Errorf("overlapping or unsorted ranges")
		}
		if end > info.Size {
			return 0, fmt.Errorf("range ends beyond object size")
		}
		if current.Size > math.MaxInt64-total {
			return 0, fmt.Errorf("range total overflow")
		}
		total += current.Size
		previousEnd = end
	}
	return total, nil
}

func appendLimitedWarning(warnings []string, warning string) []string {
	if len(warnings) < 4 {
		return append(warnings, warning)
	}
	if len(warnings) == 4 {
		return append(warnings, "additional cache accounting errors omitted")
	}
	return warnings
}

func presentCacheHalves(data, meta bool) string {
	switch {
	case data && !meta:
		return "vfs data (vfsMeta missing)"
	case !data && meta:
		return "vfsMeta (vfs data missing)"
	default:
		return "neither cache half"
	}
}

func formatDoctorFootprint(footprint doctorRootFootprint) string {
	format := func(present, available bool, bytes int64) string {
		switch {
		case !present:
			return "missing"
		case !available:
			return "allocated bytes unavailable"
		default:
			return formatByteSize(bytes) + " allocated"
		}
	}
	return "data " + format(footprint.dataPresent, footprint.dataAvailable, footprint.dataBytes) +
		", metadata " + format(footprint.metaPresent, footprint.metaAvailable, footprint.metaBytes)
}
