//go:build !tailscale

package cmd

import (
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestLibraryInstallationStableAndExcludedFromBackup(t *testing.T) {
	testSetup(t)
	first, err := loadOrCreateInstallation()
	if err != nil {
		t.Fatal(err)
	}
	second, err := loadOrCreateInstallation()
	if err != nil {
		t.Fatal(err)
	}
	if first != second || first.SeatID == "" || first.SeatLabel == "" {
		t.Fatalf("installation states differ: first=%+v second=%+v", first, second)
	}
	for _, path := range enumerateBackupFiles(accorderConfigDir) {
		if rel, _ := filepath.Rel(accorderConfigDir, path); filepath.ToSlash(rel) == "machine-state/installation.json" {
			t.Fatalf("machine-local installation identity included in backup: %s", path)
		}
	}
}

func TestLibraryBaselineRoundTrip(t *testing.T) {
	testSetup(t)
	want := libraryBaseline{
		LibraryID:               "550e8400-e29b-41d4-a716-446655440000",
		RemoteSourceFingerprint: "remote",
		LocalSourceFingerprint:  "local",
		Generation:              47,
		UpdatedAt:               time.Date(2026, 8, 19, 12, 0, 0, 0, time.UTC),
	}
	if err := saveBaseline("alice", want); err != nil {
		t.Fatal(err)
	}
	got, err := loadBaseline("alice")
	if err != nil {
		t.Fatal(err)
	}
	if got == nil || got.LibraryID != want.LibraryID || got.Generation != 47 || !got.UpdatedAt.Equal(want.UpdatedAt) {
		t.Fatalf("baseline = %+v", got)
	}
	if mode := mustStatMode(t, baselineStatePath("alice")); mode.Perm() != 0o600 {
		t.Fatalf("baseline mode = %o, want 600", mode.Perm())
	}
}

func TestLibraryExecutionLockRefusesConcurrentProcess(t *testing.T) {
	testSetup(t)
	release, err := acquireLibraryExecutionLock("alice")
	if err != nil {
		t.Fatal(err)
	}
	defer release()
	if _, err := acquireLibraryExecutionLock("alice"); err == nil {
		t.Fatal("second lock unexpectedly succeeded")
	}
}

func mustStatMode(t *testing.T, path string) os.FileMode {
	t.Helper()
	info, err := os.Stat(path)
	if err != nil {
		t.Fatal(err)
	}
	return info.Mode()
}
