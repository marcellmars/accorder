package cmd

import (
	"context"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

// ---------- parseByteSize ----------

func TestParseByteSize(t *testing.T) {
	tests := []struct {
		input   string
		want    int64
		wantErr bool
	}{

		// Bare integer
		{"0", 0, false},
		{"1024", 1024, false},
		{"3000000000B", 3000000000, false},
		{"5000000000B", 5000000000, false},

		// K / Ki
		{"1K", 1024, false},
		{"1KB", 1024, false},
		{"1Ki", 1024, false},
		{"10K", 10240, false},

		// M / Mi
		{"1M", 1 << 20, false},
		{"1Mi", 1 << 20, false},
		{"512M", 512 << 20, false},

		// G / Gi
		{"1G", 1 << 30, false},
		{"3GB", 3 << 30, false},
		{"1Gi", 1 << 30, false},
		{"1GiB", 1 << 30, false},
		{"500Gi", 500 * (1 << 30), false},

		// T / Ti
		{"1T", 1 << 40, false},
		{"1Ti", 1 << 40, false},

		// Whitespace
		{" 10Gi ", 10 * (1 << 30), false},

		// Errors
		{"", 0, true},
		{"abc", 0, true},
		{"-5Gi", 0, true},
		{"Gi", 0, true},
		{"9999999999999999999Ki", 0, true}, // overflow
	}
	for _, tt := range tests {
		t.Run(tt.input, func(t *testing.T) {
			got, err := parseByteSize(tt.input)
			if (err != nil) != tt.wantErr {
				t.Fatalf("parseByteSize(%q) error = %v, wantErr %v", tt.input, err, tt.wantErr)
			}
			if !tt.wantErr && got != tt.want {
				t.Errorf("parseByteSize(%q) = %d, want %d", tt.input, got, tt.want)
			}
		})
	}
}

// ---------- sessionData.record (rolling-window distinct counter) ----------

func newTestSessionData(window time.Duration, gsec int64, maxDistinct int) *sessionData {
	return &sessionData{
		window:             window,
		granularitySeconds: gsec,
		maxDistinct:        maxDistinct,
		bookHashes:         make(map[uint64]int64),
		coverHashes:        make(map[uint64]int64),
	}
}

func TestSessionDataRecord(t *testing.T) {
	t.Run("distinct_within_window", func(t *testing.T) {
		sd := newTestSessionData(10*time.Second, 1, 100)
		now := time.Date(2026, 1, 1, 0, 0, 5, 0, time.UTC)
		sd.record("/files/lib1/book1.epub", "book", now)
		sd.record("/files/lib1/book2.epub", "book", now)
		sd.record("/files/lib1/book1.epub", "book", now) // duplicate
		got, _ := sd.record("/files/lib2/book3.pdf", "book", now.Add(time.Second))
		if got != 3 {
			t.Errorf("distinct book count = %d, want 3", got)
		}
	})

	t.Run("expired_paths_pruned", func(t *testing.T) {
		sd := newTestSessionData(5*time.Second, 1, 100)
		base := time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC)
		sd.record("/files/lib1/old.epub", "book", base)
		sd.record("/files/lib1/recent.epub", "book", base.Add(4*time.Second))
		got, _ := sd.record("/files/lib1/newest.epub", "book", base.Add(6*time.Second))
		if got != 2 {
			t.Errorf("distinct book count = %d, want 2 (old.epub should be pruned)", got)
		}
	})

	t.Run("same_path_different_buckets", func(t *testing.T) {
		sd := newTestSessionData(10*time.Second, 1, 100)
		base := time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC)
		sd.record("/files/lib1/book.epub", "book", base)
		sd.record("/files/lib1/book.epub", "book", base.Add(3*time.Second))
		got, _ := sd.record("/files/lib1/book.epub", "book", base.Add(6*time.Second))
		if got != 1 {
			t.Errorf("distinct book count = %d, want 1", got)
		}
	})

	t.Run("empty_counter", func(t *testing.T) {
		sd := newTestSessionData(10*time.Second, 1, 100)
		if got := len(sd.bookHashes) + len(sd.coverHashes); got != 0 {
			t.Errorf("distinct count = %d, want 0", got)
		}
	})

	t.Run("bucket_granularity", func(t *testing.T) {
		sd := newTestSessionData(60*time.Second, 60, 100)
		base := time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC)
		sd.record("/files/book1.epub", "book", base)
		sd.record("/files/book2.epub", "book", base.Add(30*time.Second))

		// Both within same 60s bucket
		got, _ := sd.record("/files/book3.epub", "book", base.Add(59*time.Second))
		if got != 3 {
			t.Errorf("distinct book count = %d, want 3", got)
		}
	})

	t.Run("kinds_count_independently", func(t *testing.T) {
		sd := newTestSessionData(time.Hour, 1, 100)
		now := time.Date(2026, 1, 1, 0, 0, 5, 0, time.UTC)
		sd.record("lib1/b1/cover.jpg", "cover", now)
		sd.record("lib1/b2/cover.jpg", "cover", now)
		books, covers := sd.record("lib1/b1/book.epub", "book", now)
		if books != 1 || covers != 2 {
			t.Errorf("got books=%d covers=%d, want 1/2", books, covers)
		}
	})

	t.Run("other_counts_nothing", func(t *testing.T) {
		sd := newTestSessionData(time.Hour, 1, 100)
		now := time.Date(2026, 1, 1, 0, 0, 5, 0, time.UTC)
		sd.record("lib1/b1/book.epub", "book", now)
		books, covers := sd.record("lib1/b1/metadata.opf", "other", now)
		if books != 1 || covers != 0 {
			t.Errorf("other must not move counts: got books=%d covers=%d, want 1/0", books, covers)
		}
	})
}

func TestSessionDistinctCap(t *testing.T) {
	sd := newTestSessionData(1*time.Hour, 60, 3) // very low cap
	now := time.Now()
	sd.record("/files/a", "book", now)
	sd.record("/files/b", "book", now)
	sd.record("/files/c", "book", now)

	// At cap — new path should be silently dropped
	got, _ := sd.record("/files/d", "book", now)
	if got != 3 {
		t.Errorf("distinct book count = %d, want 3 (cap should prevent new entry)", got)
	}

	// Existing path should still update
	got, _ = sd.record("/files/a", "book", now)
	if got != 3 {
		t.Errorf("distinct book count = %d, want 3 (existing path should refresh)", got)
	}

	// Cap is per kind: covers still have room
	_, covers := sd.record("lib/x/cover.jpg", "cover", now)
	if covers != 1 {
		t.Errorf("cover count = %d, want 1 (cap applies per kind)", covers)
	}
}

func TestFileKind(t *testing.T) {
	tests := []struct{ path, want string }{
		{"lib/author/title/book.epub", "book"},
		{"lib/author/title/book.PDF", "book"},
		{"lib/author/title/cover.jpg", "cover"},
		{"lib/author/title/cover.WebP", "cover"},
		{"lib/author/title/metadata.opf", "other"},
		{"lib/author/title/noext", "other"},
		{"lib/author/title/archive.tar.gz", "other"},       // last segment "gz" not in sets
		{"lib/author/title/file.toolongext", "other"},      // >5 chars
		{"lib/author.pdf/title/noext", "other"},            // dot in dir, not base
		{"lib/author/Getting Real (1)/cover.jpg", "cover"}, // spaces + parens survive
	}
	for _, tt := range tests {
		if got := fileKind(tt.path); got != tt.want {
			t.Errorf("fileKind(%q) = %q, want %q", tt.path, got, tt.want)
		}
	}
}

// ---------- clientIP ----------

func TestClientIP(t *testing.T) {
	t.Run("direct_peer_non_loopback", func(t *testing.T) {
		r := httptest.NewRequest("GET", "/", nil)
		r.RemoteAddr = "192.168.1.100:12345"
		r.Header.Set("X-Forwarded-For", "10.0.0.1")
		got := clientIP(r)
		if got != "192.168.1.100" {
			t.Errorf("clientIP = %q, want %q (should ignore XFF for non-loopback peer)", got, "192.168.1.100")
		}
	})

	t.Run("loopback_with_xff_takes_rightmost", func(t *testing.T) {
		r := httptest.NewRequest("GET", "/", nil)
		r.RemoteAddr = "127.0.0.1:12345"
		// A spoofing client prepends a fake entry; the trusted proxy (Caddy)
		// appends the real peer it saw as the right-most value. clientIP must
		// return the right-most (proxy-appended) entry, not the spoofed one.
		r.Header.Set("X-Forwarded-For", "1.2.3.4, 203.0.113.42")
		got := clientIP(r)
		if got != "203.0.113.42" {
			t.Errorf("clientIP = %q, want %q (should take right-most/proxy-appended XFF entry, not the client-spoofable left)", got, "203.0.113.42")
		}
	})

	t.Run("loopback_with_xri", func(t *testing.T) {
		r := httptest.NewRequest("GET", "/", nil)
		r.RemoteAddr = "[::1]:12345"
		r.Header.Set("X-Real-IP", "198.51.100.7")
		got := clientIP(r)
		if got != "198.51.100.7" {
			t.Errorf("clientIP = %q, want %q (should trust X-Real-IP for loopback peer)", got, "198.51.100.7")
		}
	})

	t.Run("loopback_no_headers", func(t *testing.T) {
		r := httptest.NewRequest("GET", "/", nil)
		r.RemoteAddr = "127.0.0.1:55555"
		got := clientIP(r)
		if got != "127.0.0.1" {
			t.Errorf("clientIP = %q, want %q", got, "127.0.0.1")
		}
	})

	t.Run("strips_port", func(t *testing.T) {
		r := httptest.NewRequest("GET", "/", nil)
		r.RemoteAddr = "10.0.0.5:9999"
		got := clientIP(r)
		if got != "10.0.0.5" {
			t.Errorf("clientIP = %q, want %q (should strip port)", got, "10.0.0.5")
		}
	})
}

// ---------- session cookie + fallback ----------

func TestSessionCookieIssuance(t *testing.T) {
	meter := &sessionMeter{
		window:      time.Hour,
		granularity: 60 * time.Second,
		maxSessions: 100,
		maxDistinct: 100,
	}

	t.Run("first_request_sets_cookie", func(t *testing.T) {
		r := httptest.NewRequest("GET", "/files/test.epub", nil)
		r.RemoteAddr = "192.168.1.1:12345"
		w := httptest.NewRecorder()
		sid := meter.resolveSession(w, r)
		if sid == "" {
			t.Fatal("resolveSession returned empty session ID")
		}
		cookies := w.Result().Cookies()
		var found bool
		for _, c := range cookies {
			if c.Name == "ep_sid" {
				found = true
				if c.Value != sid {
					t.Errorf("cookie value = %q, want %q", c.Value, sid)
				}
				if !c.HttpOnly {
					t.Error("cookie should be HttpOnly")
				}
				if c.SameSite != http.SameSiteLaxMode {
					t.Errorf("cookie SameSite = %v, want Lax", c.SameSite)
				}
				if c.Path != "/files/" {
					t.Errorf("cookie Path = %q, want %q", c.Path, "/files/")
				}
			}
		}
		if !found {
			t.Error("ep_sid cookie not set in response")
		}
	})

	t.Run("cookie_readback", func(t *testing.T) {
		r := httptest.NewRequest("GET", "/files/test.epub", nil)
		r.RemoteAddr = "192.168.1.1:12345"
		r.AddCookie(&http.Cookie{Name: "ep_sid", Value: "my-session-id"})
		w := httptest.NewRecorder()
		sid := meter.resolveSession(w, r)
		if sid != "my-session-id" {
			t.Errorf("resolveSession = %q, want %q", sid, "my-session-id")
		}
	})

	t.Run("fallback_stable_across_ports", func(t *testing.T) {
		r1 := httptest.NewRequest("GET", "/files/test.epub", nil)
		r1.RemoteAddr = "192.168.1.1:12345"
		r1.Header.Set("User-Agent", "TestAgent/1.0")
		r2 := httptest.NewRequest("GET", "/files/test.epub", nil)
		r2.RemoteAddr = "192.168.1.1:99999"
		r2.Header.Set("User-Agent", "TestAgent/1.0")
		sid1 := meter.fallbackSessionID(r1)
		sid2 := meter.fallbackSessionID(r2)
		if sid1 != sid2 {
			t.Errorf("fallback IDs differ across ports: %q vs %q", sid1, sid2)
		}
	})
}

// ---------- session LRU eviction ----------

func TestSessionLRU(t *testing.T) {
	meter := &sessionMeter{
		window:      time.Hour,
		granularity: 60 * time.Second,
		maxSessions: 3,
		maxDistinct: 10,
	}

	// Create 5 sessions with increasing lastActive
	for i := 0; i < 5; i++ {
		sid := "session-" + string(rune('a'+i))
		sd := meter.getOrCreateSession(sid)
		sd.lastActive.Store(int64(1000 + i))
	}

	// After creation, eviction should have run. Check that we're at or near the cap.
	count := int(meter.sessionCount.Load())
	if count > 3 {

		// Inline eviction may not be perfectly atomic, but should be close
		t.Logf("session count = %d (expected ~3, minor overshoot acceptable)", count)
	}

	// Force a final eviction
	meter.evictSessions(3)
	count = int(meter.sessionCount.Load())
	if count > 3 {
		t.Errorf("session count after eviction = %d, want <= 3", count)
	}

	// The two oldest (session-a, session-b) should have been evicted
	if _, ok := meter.sessions.Load("session-a"); ok {
		t.Error("session-a should have been evicted (oldest)")
	}
	if _, ok := meter.sessions.Load("session-b"); ok {
		t.Error("session-b should have been evicted (second oldest)")
	}

	// The newest should be retained
	if _, ok := meter.sessions.Load("session-e"); !ok {
		t.Error("session-e should be retained (newest)")
	}
}

// ---------- egressBreaker ----------

func TestEgressBreakerDisabled(t *testing.T) {
	b, err := newEgressBreaker(egressBreakerConfig{})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if b != nil {
		t.Error("breaker should be nil when no flags are set")
	}
}

func TestEgressBreakerPrecedence(t *testing.T) {
	t.Run("egress_limit_highest", func(t *testing.T) {
		b, err := newEgressBreaker(egressBreakerConfig{
			RawLimitBytes:         50 * (1 << 30), // 50 GiB/day
			RawLimitIsSet:         true,
			BudgetUSD:             5.0,
			BudgetUSDIsSet:        true,
			PricePerGB:            0.04,
			MonthlyAllowanceBytes: 500 * (1 << 30),
			MonthlyAllowanceIsSet: true,
		})
		if err != nil {
			t.Fatalf("unexpected error: %v", err)
		}
		want := float64(50*(1<<30)) / 86400.0
		if diff := b.sustainedRate - want; diff > 1 || diff < -1 {
			t.Errorf("sustainedRate = %f, want %f (--egress-limit should take precedence)", b.sustainedRate, want)
		}
	})

	t.Run("budget_usd_over_monthly", func(t *testing.T) {
		b, err := newEgressBreaker(egressBreakerConfig{
			BudgetUSD:             5.0,
			BudgetUSDIsSet:        true,
			PricePerGB:            0.04,
			MonthlyAllowanceBytes: 500 * (1 << 30),
			MonthlyAllowanceIsSet: true,
		})
		if err != nil {
			t.Fatalf("unexpected error: %v", err)
		}
		budgetBytesPerDay := (5.0 / 0.04) * 1e9 // decimal GB (provider $/GB billing)
		want := budgetBytesPerDay / 86400.0
		if diff := b.sustainedRate - want; diff > 1 || diff < -1 {
			t.Errorf("sustainedRate = %f, want %f (--egress-budget-usd should take precedence over monthly)", b.sustainedRate, want)
		}
	})

	t.Run("monthly_allowance_default", func(t *testing.T) {
		b, err := newEgressBreaker(egressBreakerConfig{
			MonthlyAllowanceBytes: 500 * (1 << 30),
			MonthlyAllowanceIsSet: true,
		})
		if err != nil {
			t.Fatalf("unexpected error: %v", err)
		}
		want := float64(500*(1<<30)) / (30.0 * 86400.0)
		if diff := b.sustainedRate - want; diff > 1 || diff < -1 {
			t.Errorf("sustainedRate = %f, want %f", b.sustainedRate, want)
		}
	})
}

func TestEgressBreakerZeroRate(t *testing.T) {
	_, err := newEgressBreaker(egressBreakerConfig{
		MonthlyAllowanceBytes: 0,
		MonthlyAllowanceIsSet: true,
	})
	if err == nil {
		t.Error("expected error for zero-rate breaker")
	}
}

func TestEgressBreakerPriceValidation(t *testing.T) {
	_, err := newEgressBreaker(egressBreakerConfig{
		BudgetUSD:      5.0,
		BudgetUSDIsSet: true,
		PricePerGB:     0, // invalid
	})
	if err == nil {
		t.Error("expected error for zero price-per-gb with budget-usd")
	}
}

func TestEgressBreakerBurstValidation(t *testing.T) {
	t.Run("zero_burst_error", func(t *testing.T) {
		_, err := newEgressBreaker(egressBreakerConfig{
			MonthlyAllowanceBytes: 500 * (1 << 30),
			MonthlyAllowanceIsSet: true,
			BurstBytes:            0,
			BurstIsSet:            true,
		})
		if err == nil {
			t.Error("expected error for zero burst")
		}
	})

	t.Run("default_burst_1h", func(t *testing.T) {
		b, err := newEgressBreaker(egressBreakerConfig{
			MonthlyAllowanceBytes: 500 * (1 << 30),
			MonthlyAllowanceIsSet: true,
		})
		if err != nil {
			t.Fatalf("unexpected error: %v", err)
		}
		want := b.sustainedRate * 3600
		if b.bucketCapacity != want {
			t.Errorf("bucketCapacity = %f, want %f (1h of sustained rate)", b.bucketCapacity, want)
		}
	})

	t.Run("explicit_burst", func(t *testing.T) {
		b, err := newEgressBreaker(egressBreakerConfig{
			MonthlyAllowanceBytes: 500 * (1 << 30),
			MonthlyAllowanceIsSet: true,
			BurstBytes:            10 * (1 << 30),
			BurstIsSet:            true,
		})
		if err != nil {
			t.Fatalf("unexpected error: %v", err)
		}
		want := float64(10 * (1 << 30))
		if b.bucketCapacity != want {
			t.Errorf("bucketCapacity = %f, want %f", b.bucketCapacity, want)
		}
	})
}

func TestEgressBreakerMonthlyArithmetic(t *testing.T) {
	b, err := newEgressBreaker(egressBreakerConfig{
		MonthlyAllowanceBytes: 500 * (1 << 30),
		MonthlyAllowanceIsSet: true,
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	// 500 GiB / (30 * 86400) ≈ 207,243 bytes/s
	expectedRate := float64(500*(1<<30)) / (30.0 * 86400.0)
	if diff := b.sustainedRate - expectedRate; diff > 1 || diff < -1 {
		t.Errorf("sustainedRate = %f, want ~%f", b.sustainedRate, expectedRate)
	}

	// Default burst = 1h of sustained ≈ 711 MiB
	expectedBurst := expectedRate * 3600
	if diff := b.bucketCapacity - expectedBurst; diff > 1 || diff < -1 {
		t.Errorf("bucketCapacity = %f, want ~%f", b.bucketCapacity, expectedBurst)
	}
}

func TestEgressBreakerUSDArithmetic(t *testing.T) {
	b, err := newEgressBreaker(egressBreakerConfig{
		BudgetUSD:      5.0,
		BudgetUSDIsSet: true,
		PricePerGB:     0.04,
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	// 5.0 / 0.04 × 1024³ ≈ 134.2 GiB/day → bytes/sec
	budgetBytesPerDay := (5.0 / 0.04) * 1e9 // decimal GB (provider $/GB billing)
	expectedRate := budgetBytesPerDay / 86400.0
	if diff := b.sustainedRate - expectedRate; diff > 1 || diff < -1 {
		t.Errorf("sustainedRate = %f, want ~%f", b.sustainedRate, expectedRate)
	}
}

// ---------- token bucket mechanics ----------

func TestTokenBucketDrainTrips(t *testing.T) {
	b, err := newEgressBreaker(egressBreakerConfig{
		RawLimitBytes: 1 << 30, // 1 GiB/day
		RawLimitIsSet: true,
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	now := time.Now()

	// Drain the bucket by reporting massive bytes
	b.pollOnce(int64(b.bucketCapacity*2), now.Add(time.Second))
	if !b.tripped.Load() {
		t.Error("breaker should be tripped after draining bucket")
	}
}

func TestTokenBucketRefillResets(t *testing.T) {
	b, err := newEgressBreaker(egressBreakerConfig{
		RawLimitBytes: 1 << 30,
		RawLimitIsSet: true,
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	now := time.Now()

	// Trip the breaker
	b.pollOnce(int64(b.bucketCapacity*2), now.Add(time.Second))
	if !b.tripped.Load() {
		t.Fatal("breaker should be tripped")
	}

	// Wait long enough for significant refill (simulate passage of time)
	b.pollOnce(b.lastBytes, now.Add(2*time.Hour))
	if b.tripped.Load() {
		t.Error("breaker should reset after sufficient quiet period")
	}
}

func TestTokenBucketBurstWithinCapacity(t *testing.T) {
	b, err := newEgressBreaker(egressBreakerConfig{
		RawLimitBytes: 100 * (1 << 30), // 100 GiB/day
		RawLimitIsSet: true,
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	now := time.Now()

	// A burst that uses half the bucket capacity — should NOT trip
	halfBucket := int64(b.bucketCapacity / 2)
	b.pollOnce(halfBucket, now.Add(time.Second))
	if b.tripped.Load() {
		t.Error("breaker should NOT trip for burst within capacity")
	}
}

func TestTokenBucketHysteresis(t *testing.T) {
	b, err := newEgressBreaker(egressBreakerConfig{
		RawLimitBytes: 1 << 30,
		RawLimitIsSet: true,
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	now := time.Now()

	// Trip the breaker
	b.pollOnce(int64(b.bucketCapacity*2), now.Add(time.Second))
	if !b.tripped.Load() {
		t.Fatal("breaker should be tripped")
	}

	// Small refill — not enough to hit 20% threshold. Simulate short time elapsed.
	b.pollOnce(b.lastBytes, now.Add(5*time.Minute))

	// With negative tokens + small refill, tokens may still be below 20%.
	// The breaker should still be tripped.
	if !b.tripped.Load() {
		t.Error("breaker should remain tripped (hysteresis: needs 20% refill)")
	}
}

func TestTokenBucketNegativeDeltaGuard(t *testing.T) {
	b, err := newEgressBreaker(egressBreakerConfig{
		RawLimitBytes: 1 << 30,
		RawLimitIsSet: true,
	})
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	now := time.Now()
	b.pollOnce(1000, now.Add(time.Second))
	tokensBefore := b.tokens

	// Simulate stats reset (bytes drops to 0)
	b.pollOnce(0, now.Add(2*time.Second))

	// Tokens should have increased (refill) not decreased (negative delta)
	if b.tokens < tokensBefore {
		t.Errorf("tokens decreased after stats reset: before=%f after=%f", tokensBefore, b.tokens)
	}
}

// ---------- middleware integration ----------

func TestEndpointProtectionMiddleware(t *testing.T) {
	meter := &sessionMeter{
		window:      time.Hour,
		granularity: 60 * time.Second,
		maxSessions: 100,
		maxDistinct: 100,
	}

	inner := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	t.Run("passthrough_no_breaker", func(t *testing.T) {
		handler := withEndpointProtection(inner, meter, nil)
		r := httptest.NewRequest("GET", "/files/lib1/book.epub", nil)
		r.RemoteAddr = "192.168.1.1:12345"
		w := httptest.NewRecorder()
		handler.ServeHTTP(w, r)
		if w.Code != 200 {
			t.Errorf("status = %d, want 200", w.Code)
		}

		// Should have set a cookie
		cookies := w.Result().Cookies()
		var found bool
		for _, c := range cookies {
			if c.Name == "ep_sid" {
				found = true
			}
		}
		if !found {
			t.Error("ep_sid cookie not set")
		}
	})

	t.Run("503_when_breaker_tripped", func(t *testing.T) {
		b, _ := newEgressBreaker(egressBreakerConfig{
			RawLimitBytes: 1 << 30,
			RawLimitIsSet: true,
		})
		b.tripped.Store(true)
		handler := withEndpointProtection(inner, meter, b)
		r := httptest.NewRequest("GET", "/files/lib1/book.epub", nil)
		r.RemoteAddr = "192.168.1.1:12345"
		w := httptest.NewRecorder()
		handler.ServeHTTP(w, r)
		if w.Code != 503 {
			t.Errorf("status = %d, want 503", w.Code)
		}
		if w.Header().Get("Retry-After") != "60" {
			t.Errorf("Retry-After = %q, want %q", w.Header().Get("Retry-After"), "60")
		}
	})
}

// ---------- meter flag validation ----------

func TestValidateMeterFlags(t *testing.T) {
	tests := []struct {
		name        string
		window      time.Duration
		granularity time.Duration
		maxSessions int
		maxDistinct int
		wantErr     bool
	}{
		{"valid_defaults", time.Hour, 60 * time.Second, 50000, 1000, false},
		{"zero_window", 0, 60 * time.Second, 50000, 1000, true},
		{"negative_window", -time.Second, 60 * time.Second, 50000, 1000, true},
		{"zero_granularity", time.Hour, 0, 50000, 1000, true},
		{"negative_granularity", time.Hour, -time.Second, 50000, 1000, true},
		{"subsecond_granularity", time.Hour, 500 * time.Millisecond, 50000, 1000, true},
		{"zero_max_sessions", time.Hour, 60 * time.Second, 0, 1000, true},
		{"negative_max_sessions", time.Hour, 60 * time.Second, -1, 1000, true},
		{"zero_max_distinct", time.Hour, 60 * time.Second, 50000, 0, true},
		{"negative_max_distinct", time.Hour, 60 * time.Second, 50000, -1, true},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			err := validateMeterFlags(tt.window, tt.granularity, tt.maxSessions, tt.maxDistinct)
			if (err != nil) != tt.wantErr {
				t.Errorf("validateMeterFlags error = %v, wantErr %v", err, tt.wantErr)
			}
		})
	}
}

// ---------- session classing (accorder announce + class derivation) ----------

func TestResolveSession_AccorderHeader(t *testing.T) {
	meter := &sessionMeter{
		window:      time.Hour,
		granularity: time.Minute,
		maxSessions: 100,
		maxDistinct: 50,
	}

	t.Run("announced_client_keys_accorder_prefix", func(t *testing.T) {
		r := httptest.NewRequest("GET", "/files/lib/book.epub", nil)
		r.RemoteAddr = "10.0.0.1:4444"
		r.Header.Set(accorderClientHeader, "lib-browse/dev")
		w := httptest.NewRecorder()
		sid := meter.resolveSession(w, r)
		if !strings.HasPrefix(sid, "accorder:") {
			t.Fatalf("expected accorder: prefix, got %q", sid)
		}
		if got := w.Result().Cookies(); len(got) != 0 {
			t.Fatalf("announced session must not set ep_sid cookie, got %v", got)
		}
	})

	t.Run("stable_across_requests", func(t *testing.T) {
		mk := func() string {
			r := httptest.NewRequest("GET", "/files/lib/book.epub", nil)
			r.RemoteAddr = "10.0.0.2:5555"
			r.Header.Set(accorderClientHeader, "lib-browse/dev")
			return meter.resolveSession(httptest.NewRecorder(), r)
		}
		if a, b := mk(), mk(); a != b {
			t.Fatalf("announced session must be stable: %q vs %q", a, b)
		}
	})

	t.Run("grant_context_wins_over_announce", func(t *testing.T) {
		r := httptest.NewRequest("GET", "/files/lib/book.epub", nil)
		r.RemoteAddr = "10.0.0.3:6666"
		r.Header.Set(accorderClientHeader, "lib-browse/dev")
		r = r.WithContext(context.WithValue(r.Context(), grantIDKey, "alice"))
		sid := meter.resolveSession(httptest.NewRecorder(), r)
		if sid != "grant:alice" {
			t.Fatalf("grant identity must win over announce, got %q", sid)
		}
	})

	t.Run("nonce_distinguishes_same_ip_ua", func(t *testing.T) {
		// Two concurrent accorder runs behind one IP+UA, distinct per-run nonces.
		mk := func(nonce string) string {
			r := httptest.NewRequest("GET", "/files/lib/book.epub", nil)
			r.RemoteAddr = "10.0.0.4:7777"
			r.Header.Set(accorderClientHeader, "lib-browse/dev r="+nonce)
			return meter.resolveSession(httptest.NewRecorder(), r)
		}
		if a, b := mk("aaaa1111"), mk("bbbb2222"); a == b {
			t.Fatalf("distinct nonces must yield distinct sessions, both %q", a)
		}
		if a, b := mk("cccc3333"), mk("cccc3333"); a != b {
			t.Fatalf("same nonce must be stable: %q vs %q", a, b)
		}
	})
}

func TestSessionClass(t *testing.T) {
	tests := []struct{ sid, want string }{
		{"grant:alice", "grant"},
		{"accorder:deadbeef01234567", "accorder"},
		{"deadbeef01234567", "anon"},
		{"", "anon"},
	}
	for _, tt := range tests {
		if got := sessionClass(tt.sid); got != tt.want {
			t.Errorf("sessionClass(%q) = %q, want %q", tt.sid, got, tt.want)
		}
	}
}
