package cmd

import (
	"accorder/pkg/calibre"
	"accorder/pkg/rclonexfer"
	"bufio"
	"bytes"
	"context"
	"crypto/sha1"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"reflect"
	"sort"
	"strings"

	"github.com/goccy/go-json"
	"github.com/tidwall/sjson"
)

const aggregateSchemaVersion = 4

type FedlibBuildCmd struct {
	CommonCommandFields
	OutputPath          string `name:"output-path" json:"output-path" help:"Local working dir for the aggregate output (defaults to the descriptor's fedlib-path when the positional names a federation descriptor)." validate:"omitempty"`
	UploadPrefix        string `name:"upload-prefix" json:"upload-prefix" help:"S3 prefix under which the aggregate is uploaded." default:"aggregate"`
	Bucket              string `name:"bucket" json:"bucket" propagate:"-" help:"S3 bucket name." validate:"omitempty"`
	S3AccessKey         string `name:"s3-access-key" json:"s3-access-key" alias:"-" help:"S3 access key (full keys: must have s3:PutObject to upload the aggregate)." validate:"omitempty" sharedgroup:"s3creds" secret:"redact,fingerprint"`
	S3SecretKey         string `name:"s3-secret-key" json:"s3-secret-key" alias:"-" help:"S3 secret key." validate:"omitempty" sharedgroup:"s3creds" secret:"redact,fingerprint"`
	S3Provider          string `name:"s3-provider" json:"s3-provider" alias:"-" help:"S3 provider (e.g. Wasabi, AWS)." validate:"omitempty" sharedgroup:"s3creds"`
	S3Endpoint          string `name:"s3-endpoint" json:"s3-endpoint" alias:"-" help:"S3 endpoint URL." validate:"omitempty" sharedgroup:"s3creds"`
	KeysFile            string `name:"keys-file" json:"keys-file" help:"Path to the operator S3 keys-file (default: keys/<alias>.s3.keys under the config dir)." validate:"omitempty"`
	SkipUpload          *bool  `name:"skip-upload" json:"-" help:"Build the aggregate locally without uploading to S3."`
	SkipRcloneInit      bool   `kong:"-" json:"-"`
	ExternalBucket      string `kong:"-" json:"-"`
	NoMonolithicRebuild bool   `name:"no-monolithic-rebuild" json:"-" help:"Refuse the monolithic full-rebuild (materializes the whole aggregate, several GB of RAM) — splice or keep the last-good aggregate. The serve daemon sets this by default; a manual build leaves it off. See 'fedlib share live --allow-full-rebuild' to let a roomy daemon do full rebuilds."`
	MemberChangeRequest string `name:"member-change-request" json:"-" hidden:"" help:"Machine-private observed member transition request written by the live parent."`

	ObservedMemberTransitions []observedMemberTransition `kong:"-" json:"-"`
}

func (c *FedlibBuildCmd) RequireS3Creds() error {
	for _, field := range []struct{ name, val string }{
		{"--bucket", c.Bucket},
		{"--s3-access-key", c.S3AccessKey},
		{"--s3-secret-key", c.S3SecretKey},
		{"--s3-provider", c.S3Provider},
		{"--s3-endpoint", c.S3Endpoint},
	} {
		if field.val == "" {
			return fmt.Errorf("%s is required when the registry contains rclone members", field.name)
		}
	}
	return nil
}

// ResolveEffective fills output path and storage settings from the
// federation descriptor, then tops up credentials from the descriptor's
// keys file. Pure: reads only, and idempotent (every fill is guarded on
// the field still being empty).
//
// NOTE the keys-file read here is a SECOND, independent credential path
// that bypasses resolveOperatorS3Creds, which is why provenance must be
// stamped at both sites — see the proposal's invariant-falsification pass.
// recallFromDescriptor is the pre-ResolveEffective name, kept because it
// reads better at the call sites that only care about the blocking-error
// contract.
func (c *FedlibBuildCmd) recallFromDescriptor() error {
	return blockingIssueError("fedlib build", c.ResolveEffective())
}

func (c *FedlibBuildCmd) ResolveEffective() []FieldIssue {
	var issues []FieldIssue
	prov := c.provenanceTable()
	self := reflect.ValueOf(c).Elem()

	desc := loadFedlibDescriptor(c.ActionAlias)
	if desc.Version == 0 {
		if c.OutputPath == "" {
			return append(issues, FieldIssue{
				FieldPtr: fieldAddr(self, "OutputPath"),
				Message: fmt.Sprintf("--output-path is required when %q names no federation descriptor (run 'fedlib config set %s ...' first)",
					c.ActionAlias, c.ActionAlias),
				Blocking: true,
			})
		}
		log.Printf("fedlib build: %q names no federation descriptor — explicit-flags build", c.ActionAlias)
		return nil
	}
	for _, f := range []struct {
		name   string
		target *string
		source string
	}{
		{"OutputPath", &c.OutputPath, desc.FedlibPath},
		{"UploadPrefix", &c.UploadPrefix, desc.UploadPrefix},
		{"Bucket", &c.Bucket, desc.Bucket},
		{"S3Provider", &c.S3Provider, desc.S3Provider},
		{"S3Endpoint", &c.S3Endpoint, desc.S3Endpoint},
		{"KeysFile", &c.KeysFile, desc.KeysFile},
	} {
		if *f.target == "" && f.source != "" {
			*f.target = f.source
			prov.StampField(self, f.name, OriginDescriptor, "fedlibs.json:"+c.ActionAlias)
		}
	}
	if c.KeysFile != "" && (c.S3AccessKey == "" || c.S3SecretKey == "") {
		kfPath := c.KeysFile
		if !filepath.IsAbs(kfPath) {
			kfPath = filepath.Join(accorderConfigDir, kfPath)
		}
		if kf, err := parseKeysFile(kfPath); err == nil {
			if c.S3AccessKey == "" {
				c.S3AccessKey = kf.AccessKey
				prov.StampField(self, "S3AccessKey", OriginKeysFile, kfPath)
			}
			if c.S3SecretKey == "" {
				c.S3SecretKey = kf.SecretKey
				prov.StampField(self, "S3SecretKey", OriginKeysFile, kfPath)
			}
		} else {
			issues = append(issues, FieldIssue{
				FieldPtr: fieldAddr(self, "S3AccessKey"),
				Message:  "keys-file unreadable: " + kfPath,
			})
		}
	}
	return issues
}

func (c *FedlibBuildCmd) Run() error {
	if c.HandleShowConfig(c) {
		return nil
	}

	if err := c.recallFromDescriptor(); err != nil {
		return err
	}

	if c.OutputPath == "" {
		return fmt.Errorf("fedlib build: --output-path is required (or set fedlib-path in the descriptor: 'fedlib config set %s --fedlib-path ...')", c.ActionAlias)
	}

	registryPath := filepath.Join(c.OutputPath, "members.json")
	if _, err := os.Stat(registryPath); os.IsNotExist(err) {
		registryPath = filepath.Join(accorderConfigDir, "aggregate_libraries.json")
	}
	registry, err := readAggregateRegistry(registryPath)
	if err != nil {
		return err
	}
	if len(registry) == 0 {
		return fmt.Errorf("aggregate-build: registry %s is empty", registryPath)
	}
	observedTransitions := append([]observedMemberTransition(nil), c.ObservedMemberTransitions...)
	if c.MemberChangeRequest != "" {
		data, readErr := readFileBounded(c.MemberChangeRequest, memberChangeRequestMaxBytes)
		if readErr != nil {
			return fmt.Errorf("aggregate-build: read member change request: %w", readErr)
		}
		observedTransitions, readErr = decodeMemberChangeRequest(data)
		if readErr != nil {
			return fmt.Errorf("aggregate-build: %w", readErr)
		}
	}
	if c.MemberChangeRequest != "" || len(observedTransitions) > 0 {
		if err := (memberChangeRequest{Version: memberChangeRequestVersion, Members: observedTransitions}).validate(); err != nil {
			return fmt.Errorf("aggregate-build: %w", err)
		}
	}
	observedByUUID := make(map[string]observedMemberTransition, len(observedTransitions))
	for _, transition := range observedTransitions {
		meta, ok := registry[transition.LibraryUUID]
		if !ok || !isMemberActive(meta.State) || meta.IsLocal() || meta.IsPeer() {
			return fmt.Errorf("aggregate-build: member change request names non-rclone or inactive registry UUID %s", transition.LibraryUUID)
		}
		observedByUUID[transition.LibraryUUID] = transition
	}

	if err := os.MkdirAll(c.OutputPath, 0o755); err != nil {
		return fmt.Errorf("aggregate-build: mkdir %s: %w", c.OutputPath, err)
	}
	clearAggregateChangeReport(c.OutputPath)

	hasRclone := calibre.HasRcloneMembers(registry)

	var bucketFS string
	var remoteName string
	if hasRclone {
		if c.ExternalBucket != "" {
			bucketFS = c.ExternalBucket
		} else {
			if err := c.RequireS3Creds(); err != nil {
				return fmt.Errorf("aggregate-build: %w", err)
			}
			remoteName = "accorder-aggbuild-" + c.ActionAlias
			if !c.SkipRcloneInit {
				if err := rclonexfer.SetCacheDir(accorderCacheDir()); err != nil {
					return fmt.Errorf("aggregate-build: set cache dir: %w", err)
				}
				rclonexfer.Initialize()
				defer rclonexfer.Finalize()
			}

			_ = rclonexfer.DeleteRemote(remoteName)
			if err := rclonexfer.ConfigS3Remote(remoteName, rclonexfer.S3RemoteConfig{
				Provider:  c.S3Provider,
				AccessKey: c.S3AccessKey,
				SecretKey: c.S3SecretKey,
				Endpoint:  c.S3Endpoint,
			}); err != nil {
				return fmt.Errorf("aggregate-build: config s3 remote: %w", err)
			}
			defer func() { _ = rclonexfer.DeleteRemote(remoteName) }()
			bucketFS = remoteName + ":" + c.Bucket
		}
	}

	activeUUIDs := make([]string, 0, len(registry))
	for u, meta := range registry {
		if isMemberActive(meta.State) {
			activeUUIDs = append(activeUUIDs, u)
		}
	}
	sort.Strings(activeUUIDs)

	changedMembersEnv := os.Getenv("ACCORDER_CHANGED_MEMBERS")
	membershipChangedEnv := os.Getenv("ACCORDER_MEMBERSHIP_CHANGED")
	indexPath := filepath.Join(c.OutputPath, "library_index")
	existingIndex := indexPath + ".zst"

	if changedMembersEnv != "" && membershipChangedEnv != "1" {
		if _, statErr := os.Stat(existingIndex); statErr == nil {
			if mf, mfErr := calibre.ReadExistingManifest(indexPath); mfErr == nil && shouldAutoCompact(mf, true) {
				fmt.Fprintf(os.Stderr, "aggregate-build: %d regions, %d tombstones exceed compaction threshold — full rebuild to reclaim dead bytes\n",
					len(mf.Regions), len(mf.Tombstones))
			} else {
				incErr := c.runIncrementalBuild(registry, activeUUIDs, changedMembersEnv, indexPath, bucketFS)
				if incErr == nil {
					return nil
				}
				fmt.Fprintf(os.Stderr, "aggregate-build: incremental path failed (%v); falling back to full rebuild\n", incErr)
			}
		}
	}

	preparedObserved := make(map[string]bool, len(observedByUUID))
	spliced, spliceErr := c.trySpliceBuild(registry, activeUUIDs, indexPath, bucketFS, observedByUUID, preparedObserved)
	if spliceErr != nil {
		return spliceErr
	}

	if !spliced && c.NoMonolithicRebuild {
		return fmt.Errorf("aggregate-build: splice could not compose and the monolithic full-rebuild is disabled (no-monolithic-rebuild) — keeping the last-good aggregate (members may not be splice-ready; heal them with `accorder fedlib members reindex`, then the next rebuild will splice; or, on a roomy aggregator, run `fedlib share live --allow-full-rebuild`)")
	}

	if !spliced {
		type loaded struct {
			uuid  string
			books []*calibre.Book
			stamp aggMemberGen
		}
		var loadedLibs []loaded
		skipped := 0

		uuids := make([]string, 0, len(registry))
		for u := range registry {
			uuids = append(uuids, u)
		}
		sort.Strings(uuids)

		for _, uuid := range uuids {
			meta := registry[uuid]
			if !isMemberActive(meta.State) {
				fmt.Fprintf(os.Stderr, "aggregate-build: skipping %s (%s) — state=%s\n", uuid, meta.Librarian, meta.State)
				skipped++
				continue
			}

			var indexPath string

			if meta.IsLocal() {
				fmt.Fprintf(os.Stderr, "aggregate-build: reading local %s (%s, path: %s)\n", uuid, meta.Librarian, meta.LocalPath)
				indexPath = filepath.Join(meta.LocalPath, "static", "library_index")
			} else if meta.IsPeer() {
				fmt.Fprintf(os.Stderr, "aggregate-build: fetching peer %s (%s, endpoint: %s)\n", uuid, meta.Librarian, meta.Endpoint)

				libDir := filepath.Join(c.OutputPath, "libs", meta.Prefix)
				if err := prepPeerContainer(libDir, meta.Endpoint, meta.GrantToken, meta.Prefix, meta.DictID); err != nil {
					fmt.Fprintf(os.Stderr, "  WARN: peer prep %s failed: %v (skipping)\n", meta.Prefix, err)
					skipped++
					continue
				}
				indexPath = filepath.Join(libDir, "library_index")
			} else {
				fmt.Fprintf(os.Stderr, "aggregate-build: fetching %s (%s, prefix: %s)\n", uuid, meta.Librarian, meta.Prefix)

				libDir := filepath.Join(c.OutputPath, "libs", meta.Prefix)
				transition, observed := observedByUUID[uuid]
				alreadyPrepared := observed && preparedObserved[uuid]
				var prepErr error
				if !alreadyPrepared {
					prepErr = prepRcloneContainerObserved(bucketFS, libDir, meta.Prefix, uuid, transition, observed)
				}
				if prepErr != nil {
					if observed {
						return fmt.Errorf("aggregate-build: changed member %s: %w", meta.Prefix, prepErr)
					}
					fmt.Fprintf(os.Stderr, "  WARN: fetch %s/static/library_index.zst failed: %v (skipping)\n", meta.Prefix, prepErr)
					skipped++
					continue
				}
				indexPath = filepath.Join(libDir, "library_index")
			}

			books, err := calibre.AllBooksFromIndex(indexPath)
			if err != nil {
				fmt.Fprintf(os.Stderr, "  WARN: read %s: %v (skipping)\n", meta.Prefix, err)
				skipped++
				continue
			}

			rebakeBaseURL(books, meta.Prefix)

			stamp := aggMemberGen{uuid: uuid}
			if mf, mErr := calibre.ReadExistingManifest(indexPath); mErr == nil {
				stamp = aggMemberStamp(uuid, mf)
			} else {
				fmt.Fprintf(os.Stderr, "  WARN: read %s manifest generation: %v (content-only changes may not propagate)\n", meta.Prefix, mErr)
			}
			fmt.Fprintf(os.Stderr, "  loaded %d books\n", len(books))
			loadedLibs = append(loadedLibs, loaded{uuid: uuid, books: books, stamp: stamp})
		}

		if len(loadedLibs) == 0 {
			fmt.Fprintf(os.Stderr, "aggregate-build: no active libraries yet (registry had %d, %d skipped) — building empty aggregate for bootstrap\n", len(registry), skipped)
		}

		aggIdentity := aggregateIdentityHash(activeUUIDs)

		var allBooks []*calibre.Book
		for _, l := range loadedLibs {
			allBooks = append(allBooks, l.books...)
		}
		sort.SliceStable(allBooks, func(i, j int) bool {
			if allBooks[i].LastModified != allBooks[j].LastModified {
				return allBooks[i].LastModified > allBooks[j].LastModified
			}
			return allBooks[i].Id < allBooks[j].Id
		})

		fmt.Fprintf(os.Stderr, "aggregate-build: aggregated %d books from %d libraries (%d skipped); writing JSONL + building index\n",
			len(allBooks), len(loadedLibs), skipped)

		jsonlPath := filepath.Join(c.OutputPath, "aggregate.jsonl")
		if err := writeBooksJSONL(jsonlPath, allBooks); err != nil {
			return err
		}

		baseGen := computeMembershipHash(activeUUIDs)

		var startGen uint64
		if prevMf, mErr := calibre.ReadExistingManifest(indexPath); mErr == nil {
			startGen = prevMf.Generation + 1
		}

		ms := &calibre.MotwSearch{
			JsonlPath:            jsonlPath,
			IndexPath:            indexPath,
			IndexAggregateFields: true,
			BaseGeneration:       &baseGen,
			StartGeneration:      startGen,
		}
		idx, err := ms.BuildIndex()
		if err != nil {
			return fmt.Errorf("aggregate-build: BuildIndex: %w", err)
		}
		if err := ms.CompressToFile(idx); err != nil {
			return fmt.Errorf("aggregate-build: CompressToFile: %w", err)
		}

		mf, err := calibre.ReadExistingManifest(indexPath)
		if err != nil {
			return fmt.Errorf("aggregate-build: read aggregate manifest: %w", err)
		}

		if cErr := compressFileZstd(jsonlPath, indexPath+".jsonl.zst"); cErr != nil {
			log.Printf("aggregate-build: compress jsonl: %v (non-fatal)", cErr)
		}

		aggLib := calibre.PointerFileLibrary{
			UUID:      fmt.Sprintf("%x", aggIdentity),
			Librarian: "aggregate",
		}
		if err := calibre.WritePointerFile(indexPath, mf, aggLib, true); err != nil {
			return fmt.Errorf("aggregate-build: write pointer file: %w", err)
		}

		aggMembers := make([]aggMemberGen, 0, len(loadedLibs))
		for _, l := range loadedLibs {
			aggMembers = append(aggMembers, l.stamp)
		}
		if err := writeAggregateSentinel(c.OutputPath, aggMembers, mf); err != nil {
			return fmt.Errorf("aggregate-build: %w", err)
		}

		identityPath := filepath.Join(c.OutputPath, "_IDENTITY")
		if err := atomicWriteFile(identityPath, aggIdentity[:], 0o644); err != nil {
			return fmt.Errorf("aggregate-build: write _IDENTITY: %w", err)
		}

		fmt.Fprintf(os.Stderr, "aggregate-build: built %s.zst (%d books, %d libraries, %d regions, %d segments)\n",
			indexPath, mf.NumBooks, len(loadedLibs), len(mf.Regions), mf.NumSegments)
	}

	if !hasRclone {
		fmt.Fprintf(os.Stderr, "aggregate-build: all members are local; skipping upload\n")
		return nil
	}
	if c.SkipUpload != nil && *c.SkipUpload {
		fmt.Fprintf(os.Stderr, "aggregate-build: --skip-upload set; local artifacts at %s\n", c.OutputPath)
		return nil
	}

	fmt.Fprintf(os.Stderr, "aggregate-build: uploading to %s/%s/...\n", c.Bucket, c.UploadPrefix)
	for _, up := range aggregateUploadSequence(c.UploadPrefix) {
		if err := rclonexfer.CopyFile(c.OutputPath, up.local, bucketFS, up.remote); err != nil {
			s3DiagnosticHint(err)
			return fmt.Errorf("aggregate-build: upload %s: %w", up.local, err)
		}
	}
	if err := writeAggregateChangeReport(c.OutputPath, registry, observedTransitions); err != nil {
		return fmt.Errorf("aggregate-build: write change report after upload: %w", err)
	}

	fmt.Fprintf(os.Stderr, "aggregate-build: done.\n")
	return nil
}

type spliceMemberIdx struct {
	uuid      string
	meta      calibre.LibraryMeta
	indexPath string
}

func (c *FedlibBuildCmd) trySpliceBuild(
	registry map[string]calibre.LibraryMeta,
	activeUUIDs []string,
	indexPath string,
	bucketFS string,
	observedByUUID map[string]observedMemberTransition,
	preparedObserved map[string]bool,
) (bool, error) {

	var members []spliceMemberIdx
	for _, uuid := range activeUUIDs {
		meta := registry[uuid]
		var idxPath string
		if meta.IsLocal() {
			idxPath = filepath.Join(meta.LocalPath, "static", "library_index")
		} else if meta.IsPeer() {
			libDir := filepath.Join(c.OutputPath, "libs", meta.Prefix)
			if err := prepPeerContainer(libDir, meta.Endpoint, meta.GrantToken, meta.Prefix, meta.DictID); err != nil {
				fmt.Fprintf(os.Stderr, "aggregate-build(splice): WARN: peer prep %s failed: %v — falling back to full rebuild\n", meta.Prefix, err)
				return false, nil
			}
			idxPath = filepath.Join(libDir, "library_index")
		} else {
			libDir := filepath.Join(c.OutputPath, "libs", meta.Prefix)
			transition, observed := observedByUUID[uuid]
			if err := prepRcloneContainerObserved(bucketFS, libDir, meta.Prefix, uuid, transition, observed); err != nil {
				fmt.Fprintf(os.Stderr, "aggregate-build(splice): WARN: fetch %s failed: %v — falling back to full rebuild\n", meta.Prefix, err)
				return false, nil
			}
			if observed {
				preparedObserved[uuid] = true
			}
			idxPath = filepath.Join(libDir, "library_index")
		}
		members = append(members, spliceMemberIdx{uuid: uuid, meta: meta, indexPath: idxPath})
	}

	for _, m := range members {
		ver, err := calibre.ReadContainerVersion(m.indexPath)
		if err != nil {
			fmt.Fprintf(os.Stderr, "aggregate-build(splice): cannot read version for %s: %v — falling back to full rebuild\n", m.uuid, err)
			return false, nil
		}
		if ver != 2 {
			fmt.Fprintf(os.Stderr, "aggregate-build(splice): member %s has container v%d (need v2) — falling back to full rebuild\n", m.uuid, ver)
			return false, nil
		}
	}

	if len(members) == 0 {
		return false, nil
	}

	fmt.Fprintf(os.Stderr, "aggregate-build: all %d member indexes are v2 — using splice path\n", len(members))

	var extracted []*calibre.MemberContainerData
	for _, m := range members {
		mcd, err := calibre.ExtractMemberContainer(m.indexPath)
		if err != nil {
			fmt.Fprintf(os.Stderr, "aggregate-build(splice): extract %s failed: %v — falling back to full rebuild\n", m.uuid, err)
			return false, nil
		}
		extracted = append(extracted, mcd)
	}

	baseGen := computeMembershipHash(activeUUIDs)
	var startGen uint64
	if prevMf, mErr := calibre.ReadExistingManifest(indexPath); mErr == nil {
		startGen = prevMf.Generation + 1
	}

	if err := calibre.ComposeAggregate(indexPath, extracted, baseGen, startGen, calibre.ComposeOpts{PriorAggregatePath: indexPath}); err != nil {
		if strings.Contains(err.Error(), "collision") {
			log.Printf("aggregate-build(splice): DictID collision — run `accorder fedlib members reindex` to assign unique per-member DictIDs; falling back to full rebuild: %v", err)
		} else {
			fmt.Fprintf(os.Stderr, "aggregate-build(splice): compose failed: %v — falling back to full rebuild\n", err)
		}
		return false, nil
	}

	mf, err := calibre.ReadExistingManifest(indexPath)
	if err != nil {
		return false, fmt.Errorf("aggregate-build(splice): read composed manifest: %w", err)
	}

	aggIdentity := aggregateIdentityHash(activeUUIDs)
	aggLib := calibre.PointerFileLibrary{
		UUID:      fmt.Sprintf("%x", aggIdentity),
		Librarian: "aggregate",
	}
	if err := calibre.WritePointerFile(indexPath, mf, aggLib, true); err != nil {
		return false, fmt.Errorf("aggregate-build(splice): write pointer file: %w", err)
	}

	aggMembers := make([]aggMemberGen, 0, len(members))
	for i, m := range members {
		aggMembers = append(aggMembers, aggMemberStamp(m.uuid, extracted[i].Manifest))
	}
	if err := writeAggregateSentinel(c.OutputPath, aggMembers, mf); err != nil {
		return false, fmt.Errorf("aggregate-build(splice): %w", err)
	}

	identityPath := filepath.Join(c.OutputPath, "_IDENTITY")
	if err := atomicWriteFile(identityPath, aggIdentity[:], 0o644); err != nil {
		return false, fmt.Errorf("aggregate-build(splice): write _IDENTITY: %w", err)
	}

	fmt.Fprintf(os.Stderr, "aggregate-build(splice): built %s.zst (%d books, %d members, %d regions)\n",
		indexPath, mf.NumBooks, len(members), len(mf.Regions))

	return true, nil
}

type aggregateUpload struct {
	local  string
	remote string
}

func rebakeBaseURL(books []*calibre.Book, prefix string) {
	baseURL, libURL := calibre.FilesBaseURL(prefix)
	for _, b := range books {
		b.BaseURL = baseURL
		b.LibraryUrl = libURL
	}
}

func fetchPeerMemberIndex(endpoint, grantToken, destDir string) error {
	client := newBrowseClearnetHTTPClient(grantToken, "")
	resp, err := client.Get(endpoint + "/static/library_index.zst")
	if err != nil {
		return fmt.Errorf("peer fetch %s: %w", endpoint, err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("peer fetch %s/static/library_index.zst: status %d", endpoint, resp.StatusCode)
	}
	dst := filepath.Join(destDir, "library_index.zst")
	f, err := os.Create(dst)
	if err != nil {
		return fmt.Errorf("peer fetch: create %s: %w", dst, err)
	}
	if _, err := io.Copy(f, resp.Body); err != nil {
		f.Close()
		return fmt.Errorf("peer fetch: write %s: %w", dst, err)
	}
	return f.Close()
}

func fetchPeerGeneration(endpoint, grantToken string) ([]byte, error) {
	client := newBrowseClearnetHTTPClient(grantToken, "")
	resp, err := client.Get(endpoint + "/_GENERATION")
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("peer _GENERATION %s: status %d", endpoint, resp.StatusCode)
	}
	return io.ReadAll(io.LimitReader(resp.Body, 1024))
}

func rebakePeerContainer(libDir, prefix string, dictID uint32) error {
	srcIdx := filepath.Join(libDir, "library_index")
	jsonl, err := calibre.ReadDisplayJSONL(srcIdx)
	if err != nil {
		return fmt.Errorf("rebake peer %s: extract JSONL: %w", prefix, err)
	}
	baseURL, libURL := calibre.FilesBaseURL(prefix)
	var rebaked bytes.Buffer
	sc := bufio.NewScanner(bytes.NewReader(jsonl))
	sc.Buffer(make([]byte, 0, 1024*1024), 32*1024*1024)
	for sc.Scan() {
		line := bytes.TrimSpace(sc.Bytes())
		if len(line) == 0 {
			continue
		}
		out, err := sjson.SetBytes(line, "baseurl", baseURL)
		if err != nil {
			return fmt.Errorf("rebake peer %s baseurl: %w", prefix, err)
		}
		out, err = sjson.SetBytes(out, "library_url", libURL)
		if err != nil {
			return fmt.Errorf("rebake peer %s library_url: %w", prefix, err)
		}
		rebaked.Write(out)
		rebaked.WriteByte('\n')
	}
	if err := sc.Err(); err != nil {
		return fmt.Errorf("rebake peer %s scan: %w", prefix, err)
	}
	jsonlPath := filepath.Join(libDir, "books.jsonl")
	if err := os.WriteFile(jsonlPath, rebaked.Bytes(), 0o644); err != nil {
		return err
	}
	defer os.Remove(jsonlPath)
	ms := &calibre.MotwSearch{
		JsonlPath:            jsonlPath,
		IndexPath:            srcIdx,
		DictID:               dictID,
		IndexAggregateFields: true,
	}
	idx, err := ms.BuildIndex()
	if err != nil {
		return fmt.Errorf("rebake peer %s build: %w", prefix, err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		return fmt.Errorf("rebake peer %s compress: %w", prefix, err)
	}
	return nil
}

func prepPeerContainer(libDir, endpoint, grantToken, prefix string, dictID uint32) error {
	if err := os.MkdirAll(libDir, 0o755); err != nil {
		return fmt.Errorf("mkdir lib %s: %w", prefix, err)
	}
	haveCache := false
	if _, err := os.Stat(filepath.Join(libDir, "library_index.zst")); err == nil {
		haveCache = true
	}
	genPath := filepath.Join(libDir, ".peer_generation")

	curGen, probeErr := fetchPeerGeneration(endpoint, grantToken)
	if probeErr != nil {
		if haveCache {
			fmt.Fprintf(os.Stderr, "  WARN: peer probe %s failed: %v — using cached index\n", prefix, probeErr)
			return nil
		}
		return fmt.Errorf("peer probe %s: %w", prefix, probeErr)
	}

	if haveCache {
		if prev, err := os.ReadFile(genPath); err == nil && bytes.Equal(prev, curGen) {
			return nil
		}
	}

	if err := fetchPeerMemberIndex(endpoint, grantToken, libDir); err != nil {
		if haveCache {
			fmt.Fprintf(os.Stderr, "  WARN: peer fetch %s failed: %v — using cached index\n", prefix, err)
			return nil
		}
		return fmt.Errorf("peer fetch %s: %w", prefix, err)
	}
	if err := rebakePeerContainer(libDir, prefix, dictID); err != nil {
		if haveCache {
			fmt.Fprintf(os.Stderr, "  WARN: peer rebake %s failed: %v — using cached index\n", prefix, err)
			return nil
		}
		return err
	}
	_ = os.WriteFile(genPath, curGen, 0o644)
	return nil
}

func prepRcloneContainer(bucketFS, libDir, prefix string) error {
	return prepRcloneContainerObserved(bucketFS, libDir, prefix, "", observedMemberTransition{}, false)
}

func prepRcloneContainerObserved(bucketFS, libDir, prefix, expectedUUID string, transition observedMemberTransition, observed bool) error {
	if observed {
		return prepObservedRcloneContainer(bucketFS, libDir, prefix, expectedUUID, transition)
	}
	if err := os.MkdirAll(libDir, 0o755); err != nil {
		return fmt.Errorf("mkdir lib %s: %w", prefix, err)
	}
	haveCache := false
	if _, err := os.Stat(filepath.Join(libDir, "library_index.zst")); err == nil {
		haveCache = true
	}
	genPath := filepath.Join(libDir, ".member_generation")

	curGen, probeErr := fetchRcloneGeneration(bucketFS, prefix, libDir)
	if probeErr != nil {
		if haveCache {
			fmt.Fprintf(os.Stderr, "  WARN: member probe %s failed: %v — using cached index\n", prefix, probeErr)
			return nil
		}
		return fmt.Errorf("member probe %s: %w", prefix, probeErr)
	}

	if haveCache {
		if prev, err := os.ReadFile(genPath); err == nil && bytes.Equal(prev, curGen) {
			return nil
		}
	}

	if err := rclonexfer.CopyFile(bucketFS, prefix+"/static/library_index.zst", libDir, "library_index.zst"); err != nil {
		if haveCache {
			fmt.Fprintf(os.Stderr, "  WARN: member fetch %s failed: %v — using cached index\n", prefix, err)
			return nil
		}
		return fmt.Errorf("member fetch %s: %w", prefix, err)
	}
	_ = os.WriteFile(genPath, curGen, 0o644)
	return nil
}

// memberFetchStageHook is a test-only seam for moving the protected member
// commit while an observed index is staged.
var memberFetchStageHook func(stage string, attempt int) error

func runMemberFetchStageHook(stage string, attempt int) error {
	if memberFetchStageHook == nil {
		return nil
	}
	return memberFetchStageHook(stage, attempt)
}

func prepObservedRcloneContainer(bucketFS, libDir, prefix, expectedUUID string, transition observedMemberTransition) error {
	if transition.LibraryUUID != expectedUUID {
		return fmt.Errorf("observed member identity %q does not match registry %q", transition.LibraryUUID, expectedUUID)
	}
	previous, err := decodeGenerationHex(transition.PreviousGeneration)
	if err != nil {
		return err
	}
	if _, err := decodeGenerationHex(transition.ObservedGeneration); err != nil {
		return err
	}
	if err := os.MkdirAll(libDir, 0o755); err != nil {
		return fmt.Errorf("mkdir lib %s: %w", prefix, err)
	}

	for attempt := 1; attempt <= 3; attempt++ {
		stage, err := os.MkdirTemp(libDir, ".member-fetch-*")
		if err != nil {
			return err
		}
		cleanup := func() { _ = os.RemoveAll(stage) }

		beforeGeneration, beforePointer, err := fetchRcloneMemberCommit(bucketFS, prefix, stage, "before")
		if err != nil {
			cleanup()
			if attempt < 3 {
				continue
			}
			return fmt.Errorf("changed member %s commit probe: %w", prefix, err)
		}
		target, err := decodeAggregateGenerationToken(beforeGeneration)
		if err != nil {
			cleanup()
			if attempt < 3 {
				continue
			}
			return fmt.Errorf("changed member %s generation: %w", prefix, err)
		}
		if target == previous {
			cleanup()
			return fmt.Errorf("changed member %s reverted to requested previous generation", prefix)
		}
		pointer, err := calibre.DecodePointerFile(bytes.NewReader(beforePointer))
		if err != nil {
			cleanup()
			if attempt < 3 {
				continue
			}
			return fmt.Errorf("changed member %s pointer: %w", prefix, err)
		}
		_, targetGeneration := target.parts()
		if pointer.Library.UUID != expectedUUID {
			cleanup()
			return fmt.Errorf("changed member %s pointer UUID %s does not match registry %s", prefix, pointer.Library.UUID, expectedUUID)
		}
		if err := calibre.ValidatePointerCommit(pointer, pointer.SourceFingerprint, targetGeneration); err != nil {
			cleanup()
			if attempt < 3 {
				continue
			}
			return fmt.Errorf("changed member %s pointer binding: %w", prefix, err)
		}

		if err := rclonexfer.CopyFile(bucketFS, prefix+"/static/library_index.zst", stage, "library_index.zst"); err != nil {
			cleanup()
			return fmt.Errorf("changed member %s staged index fetch: %w", prefix, err)
		}
		if err := runMemberFetchStageHook("after-index-fetch", attempt); err != nil {
			cleanup()
			return fmt.Errorf("changed member %s staged fetch hook: %w", prefix, err)
		}
		afterGeneration, afterPointer, err := fetchRcloneMemberCommit(bucketFS, prefix, stage, "after")
		if err != nil {
			cleanup()
			return fmt.Errorf("changed member %s commit recheck: %w", prefix, err)
		}
		if !bytes.Equal(beforeGeneration, afterGeneration) || !bytes.Equal(beforePointer, afterPointer) {
			cleanup()
			if attempt < 3 {
				continue
			}
			return fmt.Errorf("changed member %s did not stabilize after %d attempts", prefix, attempt)
		}

		mf, err := calibre.ReadExistingManifest(filepath.Join(stage, "library_index"))
		if err != nil {
			cleanup()
			return fmt.Errorf("changed member %s staged index: %w", prefix, err)
		}
		if filepath.Base(pointer.Index.URL) != "library_index.zst" ||
			pointer.Index.NumBooks != mf.NumBooks ||
			pointer.Index.BaseGeneration != hex.EncodeToString(mf.BaseGeneration[:]) ||
			pointer.Index.Regions != len(mf.Regions) ||
			pointer.Index.Tombstones != len(mf.Tombstones) ||
			(pointer.Index.ChunkSize != 0 && pointer.Index.ChunkSize != mf.ChunkSize) {
			cleanup()
			return fmt.Errorf("changed member %s: published index metadata does not match the downloaded index", prefix)
		}
		if pointer.CatalogChecksum != "" {
			checksum, count, err := calibre.CatalogChecksumFromIndex(filepath.Join(stage, "library_index"))
			if err != nil {
				cleanup()
				return fmt.Errorf("changed member %s staged index checksum: %w", prefix, err)
			}
			if checksum != pointer.CatalogChecksum || count != pointer.Index.NumBooks {
				cleanup()
				return fmt.Errorf("changed member %s staged index does not match pointer catalog checksum/count", prefix)
			}
		}
		changeResult := deriveMemberChangeResult(bucketFS, libDir, stage, prefix, expectedUUID, transition, target, pointer)

		if err := os.Rename(filepath.Join(stage, "library_index.zst"), filepath.Join(libDir, "library_index.zst")); err != nil {
			cleanup()
			return fmt.Errorf("changed member %s activate staged index: %w", prefix, err)
		}
		if err := atomicWriteFile(filepath.Join(libDir, ".member_generation"), beforeGeneration, 0o644); err != nil {
			cleanup()
			return fmt.Errorf("changed member %s cache generation: %w", prefix, err)
		}
		if err := atomicWriteFile(filepath.Join(libDir, ".member_pointer"), beforePointer, 0o644); err != nil {
			cleanup()
			return fmt.Errorf("changed member %s cache pointer: %w", prefix, err)
		}
		if err := writeMemberChangeResult(libDir, changeResult); err != nil {
			cleanup()
			return fmt.Errorf("changed member %s change result: %w", prefix, err)
		}
		if changeResult.Scope == calibre.GenerationChangeScopeExact {
			books, assets := len(changeResult.BooksDirectories), len(changeResult.AssetsDirectories)
			fmt.Fprintf(os.Stderr, "  cache refresh: only affected directories (%d book %s, %d asset %s)\n",
				books, plural(books, "directory", "directories"), assets, plural(assets, "directory", "directories"))
		} else {
			fmt.Fprintf(os.Stderr, "  cache refresh: whole member library because the exact changed-book list could not be verified (diagnostic: %s)\n",
				changeResult.Reason)
		}
		cleanup()
		return nil
	}
	return fmt.Errorf("changed member %s stable fetch exhausted", prefix)
}

func fetchRcloneMemberCommit(bucketFS, prefix, dstDir, suffix string) ([]byte, []byte, error) {
	generationName := ".member_generation." + suffix
	pointerName := ".member_pointer." + suffix
	if err := rclonexfer.CopyFile(bucketFS, prefix+"/_GENERATION", dstDir, generationName); err != nil {
		return nil, nil, err
	}
	if err := rclonexfer.CopyFile(bucketFS, prefix+"/"+memberPointerPath, dstDir, pointerName); err != nil {
		return nil, nil, err
	}
	generation, err := readFileBounded(filepath.Join(dstDir, generationName), 24)
	if err != nil {
		return nil, nil, err
	}
	if len(generation) != 24 {
		return nil, nil, fmt.Errorf("generation frame is %d bytes, want 24", len(generation))
	}
	pointer, err := readFileBounded(filepath.Join(dstDir, pointerName), 4<<20)
	if err != nil {
		return nil, nil, err
	}
	return generation, pointer, nil
}

func fetchRcloneGeneration(bucketFS, prefix, dstDir string) ([]byte, error) {
	if err := rclonexfer.CopyFile(bucketFS, prefix+"/_GENERATION", dstDir, ".member_generation.probe"); err != nil {
		return nil, err
	}
	return os.ReadFile(filepath.Join(dstDir, ".member_generation.probe"))
}

func aggregateUploadSequence(uploadPrefix string) []aggregateUpload {
	return []aggregateUpload{
		{local: "library_index.zst", remote: uploadPrefix + "/static/library_index.zst"},
		{local: "library_index.manifest.json", remote: uploadPrefix + "/static/library_index.manifest.json"},
		{local: "_IDENTITY", remote: uploadPrefix + "/_IDENTITY"},
		{local: "_GENERATION", remote: uploadPrefix + "/_GENERATION"},
	}
}

func readAggregateRegistry(path string) (map[string]calibre.LibraryMeta, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("aggregate-build: read registry %s: %w", path, err)
	}
	var registry map[string]calibre.LibraryMeta
	if err := json.Unmarshal(data, &registry); err != nil {
		return nil, fmt.Errorf("aggregate-build: parse registry: %w", err)
	}
	if err := decryptRegistrySecrets(filepath.Dir(path), registry); err != nil {
		return nil, fmt.Errorf("aggregate-build: %w", err)
	}
	return registry, nil
}

func writeBooksJSONL(path string, books []*calibre.Book) error {
	f, err := os.Create(path)
	if err != nil {
		return fmt.Errorf("aggregate-build: create %s: %w", path, err)
	}
	defer f.Close()
	for _, b := range books {
		data, err := json.Marshal(b)
		if err != nil {
			return fmt.Errorf("aggregate-build: marshal book %s: %w", b.Id, err)
		}
		if _, err := f.Write(append(data, '\n')); err != nil {
			return fmt.Errorf("aggregate-build: write book: %w", err)
		}
	}
	return nil
}

type aggMemberGen struct {
	uuid         string
	bookCount    int
	lastModified string
	idxBaseGen   [16]byte
	idxGen       uint64
}

func aggMemberStamp(uuid string, mf calibre.Manifest) aggMemberGen {
	var lastModified string
	if len(mf.RecencyIndex) > 0 {
		lastModified = mf.RecencyIndex[0].LastModified
	}
	return aggMemberGen{
		uuid:         uuid,
		bookCount:    int(mf.NumBooks),
		lastModified: lastModified,
		idxBaseGen:   mf.BaseGeneration,
		idxGen:       mf.Generation,
	}
}

func memberIndexPath(outputPath string, meta calibre.LibraryMeta) string {
	if meta.IsLocal() {
		return filepath.Join(meta.LocalPath, "static", "library_index")
	}
	return filepath.Join(outputPath, "libs", meta.Prefix, "library_index")
}

func writeAggregateSentinel(outputPath string, members []aggMemberGen, mf calibre.Manifest) error {
	return writeGenerationSentinel(outputPath, computeAggregateBaseGen(members), mf)
}

func computeAggregateBaseGen(members []aggMemberGen) [16]byte {
	h := sha1.New()
	fmt.Fprintf(h, "schema:%d\x00", aggregateSchemaVersion)
	for _, m := range members {
		fmt.Fprintf(h, "%s\x00%d\x00%s\x00", m.uuid, m.bookCount, m.lastModified)
		h.Write(m.idxBaseGen[:])
		fmt.Fprintf(h, "%d\x00", m.idxGen)
	}
	var baseGen [16]byte
	copy(baseGen[:], h.Sum(nil))
	return baseGen
}

func computeMembershipHash(memberUUIDs []string) [16]byte {
	sorted := make([]string, len(memberUUIDs))
	copy(sorted, memberUUIDs)
	sort.Strings(sorted)
	h := sha256.New()
	fmt.Fprintf(h, "schema:%d\x00", aggregateSchemaVersion)
	for _, uuid := range sorted {
		fmt.Fprintf(h, "%s\x00", uuid)
	}
	var baseGen [16]byte
	copy(baseGen[:], h.Sum(nil))
	return baseGen
}

func aggregateIdentityHash(memberUUIDs []string) [16]byte {
	sorted := make([]string, len(memberUUIDs))
	copy(sorted, memberUUIDs)
	sort.Strings(sorted)
	h := sha256.New()
	for _, u := range sorted {
		fmt.Fprintf(h, "%s\x00", u)
	}
	var id [16]byte
	copy(id[:], h.Sum(nil))
	return id
}

func (c *FedlibBuildCmd) runIncrementalBuild(
	registry map[string]calibre.LibraryMeta,
	activeUUIDs []string,
	changedMembersCSV string,
	indexPath string,
	bucketFS string,
) error {
	changedSet := make(map[string]bool)
	for _, u := range strings.Split(changedMembersCSV, ",") {
		u = strings.TrimSpace(u)
		if u != "" {
			changedSet[u] = true
		}
	}
	if len(changedSet) == 0 {
		return fmt.Errorf("no changed members in ACCORDER_CHANGED_MEMBERS")
	}

	existingMf, err := calibre.ReadExistingManifest(indexPath)
	if err != nil {
		return fmt.Errorf("read existing manifest: %w", err)
	}
	expectedBaseGen := computeMembershipHash(activeUUIDs)
	if existingMf.BaseGeneration != expectedBaseGen {
		return fmt.Errorf("membership-hash mismatch (existing=%x, expected=%x) — membership changed",
			existingMf.BaseGeneration, expectedBaseGen)
	}

	fmt.Fprintf(os.Stderr, "aggregate-build: incremental mode — %d changed member(s)\n", len(changedSet))

	ms := &calibre.MotwSearch{IndexPath: indexPath}
	opened, err := ms.Open()
	if err != nil {
		return fmt.Errorf("open existing aggregate: %w", err)
	}
	defer opened.Close()

	var allTombstones [][16]byte
	var allFreshBooks []*calibre.Book
	memberStamps := make(map[string]aggMemberGen, len(activeUUIDs))

	for uuid := range changedSet {
		meta, ok := registry[uuid]
		if !ok || !isMemberActive(meta.State) {
			fmt.Fprintf(os.Stderr, "  incremental: skipping %s (not in registry or not active)\n", uuid)
			continue
		}

		ctx := context.Background()
		priorBooks, err := opened.BooksByLibraryUUID(ctx, uuid)
		if err != nil {
			return fmt.Errorf("enumerate prior books for %s: %w", uuid, err)
		}
		if len(priorBooks) == 0 && existingMf.NumBooks > 0 {
			return fmt.Errorf("0-tombstone anomaly for member %s — UUID mismatch suspected (aggregate has %d books but BooksByLibraryUUID returned 0 for this member)", uuid, existingMf.NumBooks)
		}
		for _, b := range priorBooks {
			ts, err := calibre.BookIDToTombstone(b.Id)
			if err != nil {
				return fmt.Errorf("tombstone %s (member %s): %w", b.Id, uuid, err)
			}
			allTombstones = append(allTombstones, ts)
		}
		fmt.Fprintf(os.Stderr, "  incremental: member %s — %d prior books tombstoned\n", uuid, len(priorBooks))

		idxPath := memberIndexPath(c.OutputPath, meta)
		if meta.IsPeer() {
			libDir := filepath.Join(c.OutputPath, "libs", meta.Prefix)
			if err := prepPeerContainer(libDir, meta.Endpoint, meta.GrantToken, meta.Prefix, meta.DictID); err != nil {
				return fmt.Errorf("peer prep %s: %w", meta.Prefix, err)
			}
		} else if !meta.IsLocal() {
			libDir := filepath.Join(c.OutputPath, "libs", meta.Prefix)
			if err := os.MkdirAll(libDir, 0o755); err != nil {
				return fmt.Errorf("mkdir lib %s: %w", meta.Prefix, err)
			}
			if err := rclonexfer.CopyFile(bucketFS, meta.Prefix+"/static/library_index.zst", libDir, "library_index.zst"); err != nil {
				return fmt.Errorf("fetch %s/static/library_index.zst: %w", meta.Prefix, err)
			}
		}

		freshBooks, err := calibre.AllBooksFromIndex(idxPath)
		if err != nil {
			return fmt.Errorf("read fresh index for %s: %w", uuid, err)
		}

		rebakeBaseURL(freshBooks, meta.Prefix)

		memberMf, mErr := calibre.ReadExistingManifest(idxPath)
		if mErr != nil {
			return fmt.Errorf("read manifest for changed member %s: %w", uuid, mErr)
		}
		memberStamps[uuid] = aggMemberStamp(uuid, memberMf)

		fmt.Fprintf(os.Stderr, "  incremental: member %s — %d fresh books\n", uuid, len(freshBooks))
		allFreshBooks = append(allFreshBooks, freshBooks...)
	}

	for _, uuid := range activeUUIDs {
		if _, done := memberStamps[uuid]; done {
			continue
		}
		meta, ok := registry[uuid]
		if !ok || !isMemberActive(meta.State) {
			continue
		}
		memberMf, mErr := calibre.ReadExistingManifest(memberIndexPath(c.OutputPath, meta))
		if mErr != nil {
			return fmt.Errorf("read manifest for unchanged member %s (sentinel would be non-deterministic): %w", uuid, mErr)
		}
		memberStamps[uuid] = aggMemberStamp(uuid, memberMf)
	}

	sort.SliceStable(allFreshBooks, func(i, j int) bool {
		if allFreshBooks[i].LastModified != allFreshBooks[j].LastModified {
			return allFreshBooks[i].LastModified > allFreshBooks[j].LastModified
		}
		return allFreshBooks[i].Id < allFreshBooks[j].Id
	})

	jsonlPath := filepath.Join(c.OutputPath, "aggregate_delta.jsonl")
	if err := writeBooksJSONL(jsonlPath, allFreshBooks); err != nil {
		return fmt.Errorf("write delta JSONL: %w", err)
	}

	deltaMs := &calibre.MotwSearch{
		JsonlPath:            jsonlPath,
		IndexPath:            indexPath,
		IndexAggregateFields: true,
	}
	deltaIdx, err := deltaMs.BuildIndex()
	if err != nil {
		return fmt.Errorf("build delta index: %w", err)
	}

	if err := deltaMs.AppendToFile(deltaIdx, allTombstones); err != nil {
		return fmt.Errorf("append delta: %w", err)
	}

	fmt.Fprintf(os.Stderr, "aggregate-build: incremental append complete (%d tombstones, %d fresh books)\n",
		len(allTombstones), len(allFreshBooks))

	mf, err := calibre.ReadExistingManifest(indexPath)
	if err != nil {
		return fmt.Errorf("read updated manifest: %w", err)
	}

	if mf.Generation <= existingMf.Generation {
		return fmt.Errorf("generation did not advance after AppendToFile (existing=%d, new=%d) — stale manifest regression",
			existingMf.Generation, mf.Generation)
	}

	aggIdentity := aggregateIdentityHash(activeUUIDs)

	aggLib := calibre.PointerFileLibrary{
		UUID:      fmt.Sprintf("%x", aggIdentity),
		Librarian: "aggregate",
	}
	if err := calibre.WritePointerFile(indexPath, mf, aggLib, false); err != nil {
		return fmt.Errorf("write pointer file: %w", err)
	}

	aggMembers := make([]aggMemberGen, 0, len(activeUUIDs))
	for _, uuid := range activeUUIDs {
		stamp, ok := memberStamps[uuid]
		if !ok {
			return fmt.Errorf("missing content stamp for active member %s (sentinel would be non-deterministic)", uuid)
		}
		aggMembers = append(aggMembers, stamp)
	}
	if err := writeAggregateSentinel(c.OutputPath, aggMembers, mf); err != nil {
		return err
	}

	identityPath := filepath.Join(c.OutputPath, "_IDENTITY")
	if err := atomicWriteFile(identityPath, aggIdentity[:], 0o644); err != nil {
		return fmt.Errorf("write _IDENTITY: %w", err)
	}

	fmt.Fprintf(os.Stderr, "aggregate-build: built %s.zst (incremental: %d regions, gen=%d)\n",
		indexPath, len(mf.Regions), mf.Generation)

	hasRclone := calibre.HasRcloneMembers(registry)
	if !hasRclone {
		fmt.Fprintf(os.Stderr, "aggregate-build: all members are local; skipping upload\n")
		return nil
	}
	if c.SkipUpload != nil && *c.SkipUpload {
		fmt.Fprintf(os.Stderr, "aggregate-build: --skip-upload set; local artifacts at %s\n", c.OutputPath)
		return nil
	}

	fmt.Fprintf(os.Stderr, "aggregate-build: uploading to %s/%s/...\n", c.Bucket, c.UploadPrefix)
	for _, up := range aggregateUploadSequence(c.UploadPrefix) {
		if err := rclonexfer.CopyFile(c.OutputPath, up.local, bucketFS, up.remote); err != nil {
			s3DiagnosticHint(err)
			return fmt.Errorf("upload %s: %w", up.local, err)
		}
	}

	fmt.Fprintf(os.Stderr, "aggregate-build: done (incremental).\n")
	return nil
}
