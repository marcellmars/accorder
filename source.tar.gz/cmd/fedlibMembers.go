package cmd

import (
	"accorder/pkg/calibre"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"encoding/base64"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"text/tabwriter"

	"github.com/goccy/go-json"
)

type FedlibMembersCmd struct {
	Add     FedlibMembersAddCmd     `cmd:"" help:"Add a library to the federation." json:"add"`
	Remove  FedlibMembersRemoveCmd  `cmd:"" help:"Remove a library from the federation." json:"remove"`
	List    FedlibMembersListCmd    `cmd:"" help:"List federation members." json:"list"`
	Status  FedlibMembersStatusCmd  `cmd:"" help:"Show durable member state (health data only available in fedlib share live)." json:"status"`
	Enable  FedlibMembersEnableCmd  `cmd:"" help:"Enable a disabled or retired member." json:"enable"`
	Disable FedlibMembersDisableCmd `cmd:"" help:"Disable a member (excluded from fedlib build)." json:"disable"`
	Invite  FedlibMembersInviteCmd  `cmd:"" help:"Create an invite blob for a new member." json:"invite"`
	Offer   FedlibMembersOfferCmd   `cmd:"" help:"Create a claim-once peer membership offer." json:"offer"`
	Reindex FedlibMembersReindexCmd `cmd:"" help:"Assign unique DictIDs and rebuild member indexes." json:"reindex"`
}

func resolveMembersRegistryPath(fedlibPath string) string {
	if fedlibPath != "" {
		return filepath.Join(fedlibPath, "members.json")
	}
	return filepath.Join(accorderConfigDir, "aggregate_libraries.json")
}

func resolveFedlibRegistryPath(fedlibID, fedlibPath string) string {
	if fedlibID != "" {
		desc := loadFedlibDescriptor(fedlibID)
		if fedlibPath == "" {
			if desc.FedlibPath != "" {
				fedlibPath = desc.FedlibPath
				fmt.Fprintf(os.Stderr, "fedlib members: fedlib-path for %q recalled from %s\n",
					fedlibID, fedlibDescriptorPath())
			}
		} else if fedlibPath != desc.FedlibPath {
			desc.FedlibPath = fedlibPath
			desc.Version = fedlibDescriptorVersion
			if err := saveFedlibDescriptor(fedlibID, desc); err != nil {
				fmt.Fprintf(os.Stderr, "fedlib members: WARNING: %v\n", err)
			}
		}
	}
	return resolveMembersRegistryPath(fedlibPath)
}

type FedlibMembersAddCmd struct {
	FedlibID   string `arg:"" name:"fedlib-id" help:"Federation identifier (see 'fedlib config set')."`
	UUID       string `arg:"" help:"Library UUID."`
	Librarian  string `name:"librarian" short:"l" help:"Librarian name." validate:"required"`
	Prefix     string `name:"prefix" short:"p" help:"S3 bucket prefix (or override for --local-path basename)."`
	LocalPath  string `name:"local-path" help:"Absolute path to a local accorder-served library directory (sets kind=local)."`
	FedlibPath string `name:"fedlib-path" help:"Path to the fedlib output directory (uses per-fedlib members.json)."`
}

func (c *FedlibMembersAddCmd) Run() error {
	registryPath := resolveFedlibRegistryPath(c.FedlibID, c.FedlibPath)
	_, registryPath, err := loadMembersRegistryFromPath(registryPath)
	if err != nil {
		return err
	}

	meta := calibre.LibraryMeta{
		Librarian: c.Librarian,
	}

	if c.LocalPath != "" {
		if !filepath.IsAbs(c.LocalPath) {
			return fmt.Errorf("fedlib members add: --local-path must be an absolute path, got %q", c.LocalPath)
		}
		indexFile := filepath.Join(c.LocalPath, "static", "library_index.zst")
		if _, err := os.Stat(indexFile); err != nil {
			return fmt.Errorf("fedlib members add: --local-path %q does not contain static/library_index.zst", c.LocalPath)
		}
		meta.Kind = "local"
		meta.LocalPath = c.LocalPath
		if c.Prefix != "" {
			meta.Prefix = c.Prefix
		} else {
			meta.Prefix = filepath.Base(c.LocalPath)
		}
	} else {
		if c.Prefix == "" {
			return fmt.Errorf("fedlib members add: --prefix is required for rclone members")
		}
		meta.Prefix = c.Prefix
	}

	if err := mutateMembersRegistryLocked(registryPath, func(registry map[string]calibre.LibraryMeta) error {
		if _, exists := registry[c.UUID]; exists {
			return fmt.Errorf("fedlib members add: UUID %s already exists", c.UUID)
		}
		for uuid, existing := range registry {
			if existing.Prefix == meta.Prefix {
				return fmt.Errorf("fedlib members add: prefix %q already in use by %s", meta.Prefix, uuid)
			}
		}
		registry[c.UUID] = meta
		return nil
	}); err != nil {
		return err
	}
	kind := meta.Kind
	if kind == "" {
		kind = "rclone"
	}
	fmt.Fprintf(os.Stderr, "fedlib members: added %s (%s, prefix: %s, kind: %s)\n", c.UUID, c.Librarian, meta.Prefix, kind)
	return nil
}

type FedlibMembersRemoveCmd struct {
	FedlibID   string `arg:"" name:"fedlib-id" help:"Federation identifier (see 'fedlib config set')."`
	UUID       string `arg:"" help:"Library UUID to remove."`
	FedlibPath string `name:"fedlib-path" help:"Path to the fedlib output directory (uses per-fedlib members.json)."`
}

func (c *FedlibMembersRemoveCmd) Run() error {
	registryPath := resolveFedlibRegistryPath(c.FedlibID, c.FedlibPath)
	_, registryPath, err := loadMembersRegistryFromPath(registryPath)
	if err != nil {
		return err
	}
	if err := mutateMembersRegistryLocked(registryPath, func(registry map[string]calibre.LibraryMeta) error {
		if _, exists := registry[c.UUID]; !exists {
			return fmt.Errorf("fedlib members remove: UUID %s not found", c.UUID)
		}
		delete(registry, c.UUID)
		return nil
	}); err != nil {
		return err
	}
	fmt.Fprintf(os.Stderr, "fedlib members: removed %s\n", c.UUID)
	return nil
}

type FedlibMembersListCmd struct {
	FedlibID   string `arg:"" optional:"" name:"fedlib-id" help:"Federation identifier (see 'fedlib config set')."`
	FedlibPath string `name:"fedlib-path" help:"Path to the fedlib output directory (uses per-fedlib members.json)."`
}

func (c *FedlibMembersListCmd) Run() error {
	registryPath := resolveFedlibRegistryPath(c.FedlibID, c.FedlibPath)
	registry, _, err := loadMembersRegistryFromPath(registryPath)
	if err != nil {
		return err
	}
	if len(registry) == 0 {
		fmt.Println("No members.")
		return nil
	}

	uuids := make([]string, 0, len(registry))
	for u := range registry {
		uuids = append(uuids, u)
	}
	sort.Strings(uuids)

	tw := tabwriter.NewWriter(os.Stdout, 0, 0, 2, ' ', 0)
	fmt.Fprintf(tw, "UUID\tLIBRARIAN\tPREFIX\tKIND\tSTATE\n")
	for _, uuid := range uuids {
		m := registry[uuid]
		kind := m.Kind
		if kind == "" {
			kind = "rclone"
		}
		state := m.State
		if state == "" {
			state = "ready"
		}
		fmt.Fprintf(tw, "%s\t%s\t%s\t%s\t%s\n", uuid, m.Librarian, m.Prefix, kind, state)
	}
	tw.Flush()
	return nil
}

type FedlibMembersStatusCmd struct {
	FedlibID   string `arg:"" optional:"" name:"fedlib-id" help:"Federation identifier (see 'fedlib config set')."`
	FedlibPath string `name:"fedlib-path" help:"Path to the fedlib output directory (uses per-fedlib members.json)."`
}

func (c *FedlibMembersStatusCmd) Run() error {
	registryPath := resolveFedlibRegistryPath(c.FedlibID, c.FedlibPath)
	registry, _, err := loadMembersRegistryFromPath(registryPath)
	if err != nil {
		return err
	}
	if len(registry) == 0 {
		fmt.Println("No members.")
		return nil
	}

	uuids := make([]string, 0, len(registry))
	for u := range registry {
		uuids = append(uuids, u)
	}
	sort.Strings(uuids)

	tw := tabwriter.NewWriter(os.Stdout, 0, 0, 2, ' ', 0)
	fmt.Fprintf(tw, "UUID\tLIBRARIAN\tPREFIX\tSTATE\tKIND\n")
	for _, uuid := range uuids {
		m := registry[uuid]
		short := uuid
		if len(short) > 8 {
			short = short[:8]
		}
		kind := m.Kind
		if kind == "" {
			kind = "rclone"
		}
		state := m.State
		if state == "" {
			state = "ready"
		}
		fmt.Fprintf(tw, "%s\t%s\t%s\t%s\t%s\n", short, m.Librarian, m.Prefix, state, kind)
	}
	tw.Flush()
	return nil
}

type FedlibMembersEnableCmd struct {
	FedlibID   string `arg:"" name:"fedlib-id" help:"Federation identifier (see 'fedlib config set')."`
	UUID       string `arg:"" help:"Library UUID to enable."`
	FedlibPath string `name:"fedlib-path" help:"Path to the fedlib output directory (uses per-fedlib members.json)."`
}

func (c *FedlibMembersEnableCmd) Run() error {
	registryPath := resolveFedlibRegistryPath(c.FedlibID, c.FedlibPath)
	if err := mutateMembersRegistryLocked(registryPath, func(registry map[string]calibre.LibraryMeta) error {
		m, exists := registry[c.UUID]
		if !exists {
			return fmt.Errorf("fedlib members enable: UUID %s not found", c.UUID)
		}
		m.State = "ready"
		registry[c.UUID] = m
		return nil
	}); err != nil {
		return err
	}
	fmt.Fprintf(os.Stderr, "fedlib members: enabled %s\n", c.UUID)
	return nil
}

type FedlibMembersDisableCmd struct {
	FedlibID   string `arg:"" name:"fedlib-id" help:"Federation identifier (see 'fedlib config set')."`
	UUID       string `arg:"" help:"Library UUID to disable."`
	FedlibPath string `name:"fedlib-path" help:"Path to the fedlib output directory (uses per-fedlib members.json)."`
}

func (c *FedlibMembersDisableCmd) Run() error {
	registryPath := resolveFedlibRegistryPath(c.FedlibID, c.FedlibPath)
	if err := mutateMembersRegistryLocked(registryPath, func(registry map[string]calibre.LibraryMeta) error {
		m, exists := registry[c.UUID]
		if !exists {
			return fmt.Errorf("fedlib members disable: UUID %s not found", c.UUID)
		}
		m.State = "disabled"
		registry[c.UUID] = m
		return nil
	}); err != nil {
		return err
	}
	fmt.Fprintf(os.Stderr, "fedlib members: disabled %s\n", c.UUID)
	return nil
}

func loadMembersRegistryFromPath(registryPath string) (map[string]calibre.LibraryMeta, string, error) {
	data, err := os.ReadFile(registryPath)
	if err != nil {
		if os.IsNotExist(err) {
			return make(map[string]calibre.LibraryMeta), registryPath, nil
		}
		return nil, "", fmt.Errorf("fedlib members: read registry: %w", err)
	}
	var registry map[string]calibre.LibraryMeta
	if err := json.Unmarshal(data, &registry); err != nil {
		return nil, "", fmt.Errorf("fedlib members: parse registry: %w", err)
	}
	if registry == nil {
		registry = make(map[string]calibre.LibraryMeta)
	}
	if err := decryptRegistrySecrets(filepath.Dir(registryPath), registry); err != nil {
		return nil, "", fmt.Errorf("fedlib members: %w", err)
	}
	return registry, registryPath, nil
}

func isMemberActive(state string) bool {
	return calibre.LibraryMeta{State: state}.IsActive()
}

func saveMembersRegistry(path string, registry map[string]calibre.LibraryMeta) error {
	toWrite, err := encryptRegistrySecrets(filepath.Dir(path), registry)
	if err != nil {
		return fmt.Errorf("fedlib members: encrypt registry secrets: %w", err)
	}
	data, err := json.MarshalIndent(toWrite, "", "  ")
	if err != nil {
		return fmt.Errorf("fedlib members: marshal registry: %w", err)
	}
	if err := atomicWriteFile(path, data, 0o600); err != nil {
		return fmt.Errorf("fedlib members: %w", err)
	}
	return nil
}

const encryptedSecretPrefix = "enc:"

func membersRegistryKey(dir string, create bool) ([]byte, error) {
	keyPath := filepath.Join(dir, ".members_secret.key")
	data, err := os.ReadFile(keyPath)
	if err == nil {
		if len(data) != 32 {
			return nil, fmt.Errorf("members key %s: bad length %d", keyPath, len(data))
		}
		return data, nil
	}
	if !os.IsNotExist(err) || !create {
		return nil, err
	}
	key := make([]byte, 32)
	if _, err := rand.Read(key); err != nil {
		return nil, fmt.Errorf("members key: generate: %w", err)
	}
	if err := atomicWriteFile(keyPath, key, 0o600); err != nil {
		return nil, fmt.Errorf("members key: write: %w", err)
	}
	return key, nil
}

func encryptRegistrySecret(key []byte, plaintext string) (string, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return "", err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err := rand.Read(nonce); err != nil {
		return "", err
	}
	ct := gcm.Seal(nonce, nonce, []byte(plaintext), nil)
	return encryptedSecretPrefix + base64.StdEncoding.EncodeToString(ct), nil
}

func decryptRegistrySecret(key []byte, value string) (string, error) {
	raw, err := base64.StdEncoding.DecodeString(strings.TrimPrefix(value, encryptedSecretPrefix))
	if err != nil {
		return "", err
	}
	block, err := aes.NewCipher(key)
	if err != nil {
		return "", err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return "", err
	}
	if len(raw) < gcm.NonceSize() {
		return "", fmt.Errorf("members secret: ciphertext too short")
	}
	nonce, ct := raw[:gcm.NonceSize()], raw[gcm.NonceSize():]
	pt, err := gcm.Open(nil, nonce, ct, nil)
	if err != nil {
		return "", fmt.Errorf("members secret: decrypt: %w", err)
	}
	return string(pt), nil
}

func encryptRegistrySecrets(dir string, registry map[string]calibre.LibraryMeta) (map[string]calibre.LibraryMeta, error) {
	needsKey := false
	for _, m := range registry {
		if m.GrantToken != "" && !strings.HasPrefix(m.GrantToken, encryptedSecretPrefix) {
			needsKey = true
			break
		}
	}
	if !needsKey {
		return registry, nil
	}
	key, err := membersRegistryKey(dir, true)
	if err != nil {
		return nil, err
	}
	out := make(map[string]calibre.LibraryMeta, len(registry))
	for uuid, m := range registry {
		if m.GrantToken != "" && !strings.HasPrefix(m.GrantToken, encryptedSecretPrefix) {
			ct, err := encryptRegistrySecret(key, m.GrantToken)
			if err != nil {
				return nil, err
			}
			m.GrantToken = ct
		}
		out[uuid] = m
	}
	return out, nil
}

func decryptRegistrySecrets(dir string, registry map[string]calibre.LibraryMeta) error {
	hasEnc := false
	for _, m := range registry {
		if strings.HasPrefix(m.GrantToken, encryptedSecretPrefix) {
			hasEnc = true
			break
		}
	}
	if !hasEnc {
		return nil
	}
	key, err := membersRegistryKey(dir, false)
	if err != nil {
		return fmt.Errorf("members registry: load secret key: %w", err)
	}
	for uuid, m := range registry {
		if strings.HasPrefix(m.GrantToken, encryptedSecretPrefix) {
			pt, err := decryptRegistrySecret(key, m.GrantToken)
			if err != nil {
				return err
			}
			m.GrantToken = pt
			registry[uuid] = m
		}
	}
	return nil
}

func mutateMembersRegistryLocked(registryPath string, fn func(map[string]calibre.LibraryMeta) error) error {
	lockPath := registryPath + ".lock"
	lockFile, err := os.OpenFile(lockPath, os.O_CREATE|os.O_RDWR, 0o600)
	if err != nil {
		return fmt.Errorf("mutateMembersRegistry: open lock: %w", err)
	}
	defer lockFile.Close()

	unlock, err := lockFileExclusive(lockFile)
	if err != nil {
		return fmt.Errorf("mutateMembersRegistry: lock: %w", err)
	}
	defer unlock()

	registry, _, err := loadMembersRegistryFromPath(registryPath)
	if err != nil {
		return err
	}
	if err := fn(registry); err != nil {
		return err
	}
	return saveMembersRegistry(registryPath, registry)
}
