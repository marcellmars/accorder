package cmd

import "time"

// Test-only accounting for whole-command experiments. Nil in production.
// Observers must support concurrent inventory workers. Nested timings overlap;
// their sum is not command wall time. Traced runs are not latency benchmarks.
var libraryWorkObserver func(stage string, elapsed time.Duration, items int)

func beginLibraryWork(stage string) func(int) {
	observer := libraryWorkObserver
	if observer == nil {
		return func(int) {}
	}
	start := time.Now()
	return func(items int) { observer(stage, time.Since(start), items) }
}
