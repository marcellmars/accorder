package cmd

import (
	"accorder/pkg/calibre"
	"accorder/pkg/fedlibinvite"
	"net/url"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
	"time"
)

// Load-modify-save regression: an invite that passes only a subset of flags
// must not zero descriptor fields it does not itself set on the command line.
func TestInvite_LoadModifySave_PreservesNonInviteFields(t *testing.T) {
	testSetup(t)
	keysPath := filepath.Join(accorderConfigDir, "seeded_root.keys")
	if err := os.WriteFile(keysPath, []byte("access-key=AK\nsecret-key=SK\n"), 0o600); err != nil {
		t.Fatal(err)
	}
	seed := fedlibDescriptor{
		Version:      fedlibDescriptorVersion,
		Bucket:       "seedbucket",
		S3Provider:   "Wasabi",
		S3Endpoint:   "https://s3.example",
		UploadPrefix: "aggregate",
		KeysFile:     "keys/lib.s3.keys",
		Mode:         "public",
		Endpoint:     "https://lib.example",
		OfferExpiry:  "72h",
		RootKeysFile: keysPath,
		IAMEndpoint:  "https://iam.example",
	}
	if err := saveFedlibDescriptor("preserve", seed); err != nil {
		t.Fatal(err)
	}

	// Invite passes only --bucket; every other descriptor field must survive.
	cmd := &FedlibMembersInviteCmd{
		Label: "X", Prefix: "alice", FedlibID: "preserve",
		Bucket:            "newbucket",
		PrintMintCommands: ptrTo(true),
	}
	if err := cmd.Run(nil); err != nil {
		t.Fatalf("invite: %v", err)
	}

	got := loadFedlibDescriptor("preserve")
	want := seed
	want.Bucket = "newbucket" // explicit flag wins and is written through
	if got != want {
		t.Fatalf("descriptor mutated beyond the explicit flag:\n got: %+v\nwant: %+v", got, want)
	}
}

// Pre-descriptor seed entries (version absent) are stamped on the next save.
func TestInvite_VersionStampedOnSave(t *testing.T) {
	testSetup(t)
	cmd := &FedlibMembersInviteCmd{
		Label: "X", Prefix: "alice", FedlibID: "stamp",
		Bucket: "b", S3Provider: "Wasabi", S3Endpoint: "https://s3.example",
		PrintMintCommands: ptrTo(true),
	}
	if err := cmd.Run(nil); err != nil {
		t.Fatalf("invite: %v", err)
	}
	if d := loadFedlibDescriptor("stamp"); d.Version != fedlibDescriptorVersion {
		t.Fatalf("version not stamped: %+v", d)
	}
}

// offerExpiresAt runs an offer-mode invite and returns the sealed offer's
// expiry by claiming the token from the stdout URL.
func offerExpiresAt(t *testing.T, c *FedlibMembersInviteCmd) time.Time {
	t.Helper()
	stdout, _, err := captureInviteOutput(t, runNilCtx(c.Run))
	if err != nil {
		t.Fatalf("invite --offer: %v", err)
	}
	line := strings.TrimSuffix(stdout, "\n")
	u, err := url.Parse(line)
	if err != nil {
		t.Fatalf("stdout %q does not parse as URL: %v", line, err)
	}
	token := strings.TrimPrefix(u.Path, "/invite/")
	dir := inviteOffersDir(c.FedlibID)
	offer, err := fedlibinvite.ReadOffer(dir, token)
	if err != nil {
		t.Fatalf("read sealed offer: %v", err)
	}
	return offer.Expires
}

func wantExpiryAbout(t *testing.T, got time.Time, ttl time.Duration) {
	t.Helper()
	want := time.Now().Add(ttl)
	if d := got.Sub(want); d < -time.Minute || d > time.Minute {
		t.Errorf("offer expiry %s not ~%s out", got, ttl)
	}
}

// offer_expiry resolution: explicit flag → descriptor → "168h" code fallback;
// the fallback is never persisted to fedlibs.json.
func TestInvite_OfferExpiryResolution(t *testing.T) {
	testSetup(t)
	fedlibDir := t.TempDir()

	// No descriptor, no flag → code fallback 168h, not persisted.
	// Seed descriptor with serve_alias (required for --offer) but no offer_expiry.
	_ = saveFedlibDescriptor("exp-fallback", fedlibDescriptor{
		Version: fedlibDescriptorVersion, Endpoint: "https://lib.example.org",
	})
	c := offerCmd("A", "alice", fedlibDir)
	c.FedlibID = "exp-fallback"
	c.OfferExpiry = ""
	wantExpiryAbout(t, offerExpiresAt(t, c), 168*time.Hour)
	if d := loadFedlibDescriptor("exp-fallback"); d.OfferExpiry != "" {
		t.Errorf("168h fallback was persisted: %+v", d)
	}

	// Descriptor beats the fallback.
	_ = saveFedlibDescriptor("exp-desc", fedlibDescriptor{
		Version: fedlibDescriptorVersion, Endpoint: "https://lib.example.org",
		OfferExpiry: "24h",
	})
	c = offerCmd("B", "bob", fedlibDir)
	c.FedlibID = "exp-desc"
	c.OfferExpiry = ""
	wantExpiryAbout(t, offerExpiresAt(t, c), 24*time.Hour)

	// Explicit flag beats the descriptor and is written through.
	_ = saveFedlibDescriptor("exp-flag", fedlibDescriptor{
		Version: fedlibDescriptorVersion, Endpoint: "https://lib.example.org",
		OfferExpiry: "24h",
	})
	c = offerCmd("C", "carol", fedlibDir)
	c.FedlibID = "exp-flag"
	c.OfferExpiry = "1h"
	wantExpiryAbout(t, offerExpiresAt(t, c), time.Hour)
	if d := loadFedlibDescriptor("exp-flag"); d.OfferExpiry != "1h" {
		t.Errorf("explicit expiry not written through: %+v", d)
	}
}

// A descriptor root_keys_file is a deliberate pointer: pointing at a missing
// file must error loudly, exactly like an explicit --operator-root-keys-file.
func TestInvite_DescriptorRootKeysFileMissingErrorsLoudly(t *testing.T) {
	testSetup(t)
	if err := saveFedlibDescriptor("rk", fedlibDescriptor{
		Bucket: "b", S3Provider: "Wasabi", S3Endpoint: "https://s3.example",
		RootKeysFile: filepath.Join(accorderConfigDir, "nope.keys"),
	}); err != nil {
		t.Fatal(err)
	}
	cmd := &FedlibMembersInviteCmd{
		Label: "X", Prefix: "alice", FedlibID: "rk",
		PrintMintCommands: ptrTo(true),
	}
	_, _, err := captureInviteOutput(t, runNilCtx(cmd.Run))
	if err == nil || !strings.Contains(err.Error(), "--operator-root-keys-file") {
		t.Fatalf("want loud keys-file error, got %v", err)
	}
}

// Descriptor iam_endpoint wins over the provider switch (recall loop slots it
// into c.IAMEndpoint before resolveIAMEndpoint runs).
func TestInvite_DescriptorIAMEndpointWinsOverProviderSwitch(t *testing.T) {
	testSetup(t)
	if err := saveFedlibDescriptor("iam", fedlibDescriptor{
		Bucket: "b", S3Provider: "Wasabi", S3Endpoint: "https://s3.example",
		IAMEndpoint: "https://iam.custom.example",
	}); err != nil {
		t.Fatal(err)
	}
	cmd := &FedlibMembersInviteCmd{
		Label: "X", Prefix: "alice", FedlibID: "iam",
		PrintMintCommands: ptrTo(true),
	}
	stdout, stderr, err := captureInviteOutput(t, runNilCtx(cmd.Run))
	if err != nil {
		t.Fatalf("invite: %v", err)
	}
	if !strings.Contains(stdout+stderr, "https://iam.custom.example") {
		t.Errorf("descriptor iam_endpoint did not reach mint commands:\n%s%s", stdout, stderr)
	}
	if strings.Contains(stdout+stderr, "https://iam.wasabisys.com") {
		t.Errorf("provider-switch endpoint leaked despite descriptor value:\n%s%s", stdout, stderr)
	}
}

// members list --fedlib-id X reads the descriptor's fedlib_path.
func TestMembersList_FedlibIDResolvesRegistryFromDescriptor(t *testing.T) {
	testSetup(t)
	fedDir := t.TempDir()
	reg := map[string]calibre.LibraryMeta{
		"u1": {Librarian: "Lena", Prefix: "lena"},
	}
	if err := saveMembersRegistry(filepath.Join(fedDir, "members.json"), reg); err != nil {
		t.Fatal(err)
	}
	if err := saveFedlibDescriptor("lst", fedlibDescriptor{FedlibPath: fedDir}); err != nil {
		t.Fatal(err)
	}
	c := &FedlibMembersListCmd{FedlibID: "lst"}
	stdout, stderr, err := captureInviteOutput(t, c.Run)
	if err != nil {
		t.Fatalf("list: %v", err)
	}
	if !strings.Contains(stdout, "u1") || !strings.Contains(stdout, "lena") {
		t.Errorf("per-fedlib registry not listed:\n%s", stdout)
	}
	if !strings.Contains(stderr, `fedlib-path for "lst" recalled`) {
		t.Errorf("no recall notice on stderr:\n%s", stderr)
	}
}

// Explicit --fedlib-path alongside --fedlib-id wins and is written through.
func TestMembersList_ExplicitFedlibPathWritesThrough(t *testing.T) {
	testSetup(t)
	fedDir := t.TempDir()
	c := &FedlibMembersListCmd{FedlibID: "wt", FedlibPath: fedDir}
	if _, _, err := captureInviteOutput(t, c.Run); err != nil {
		t.Fatalf("list: %v", err)
	}
	d := loadFedlibDescriptor("wt")
	if d.FedlibPath != fedDir {
		t.Fatalf("explicit fedlib-path not written through: %+v", d)
	}
	if d.Version != fedlibDescriptorVersion {
		t.Fatalf("version not stamped on write-through: %+v", d)
	}
}

// Without --fedlib-id the singleton registry is used and the descriptor file
// is never created (read-style command stays side-effect free).
func TestMembersList_NoFedlibIDUsesSingleton(t *testing.T) {
	testSetup(t)
	reg := map[string]calibre.LibraryMeta{
		"u2": {Librarian: "Sam", Prefix: "sam"},
	}
	if err := saveMembersRegistry(filepath.Join(accorderConfigDir, "aggregate_libraries.json"), reg); err != nil {
		t.Fatal(err)
	}
	c := &FedlibMembersListCmd{}
	stdout, _, err := captureInviteOutput(t, c.Run)
	if err != nil {
		t.Fatalf("list: %v", err)
	}
	if !strings.Contains(stdout, "u2") {
		t.Errorf("singleton registry not listed:\n%s", stdout)
	}
	if _, err := os.Stat(fedlibDescriptorPath()); !os.IsNotExist(err) {
		t.Errorf("descriptor file created by a plain list run (err=%v)", err)
	}
}

// Invite recalls fedlib_path from the descriptor: the invited member lands in
// the per-fedlib members.json, not the singleton.
func TestInvite_FedlibPathRecalledFromDescriptor(t *testing.T) {
	testSetup(t)
	fedDir := t.TempDir()
	if err := saveFedlibDescriptor("fp", fedlibDescriptor{FedlibPath: fedDir}); err != nil {
		t.Fatal(err)
	}
	cmd := &FedlibMembersInviteCmd{
		Label: "X", Prefix: "alice", FedlibID: "fp",
		S3AccessKey: "AK", S3SecretKey: "SK",
		Bucket: "b", S3Provider: "Wasabi", S3Endpoint: "https://s3.example",
	}
	if _, _, err := captureInviteOutput(t, runNilCtx(cmd.Run)); err != nil {
		t.Fatalf("invite: %v", err)
	}
	reg, _, err := loadMembersRegistryFromPath(filepath.Join(fedDir, "members.json"))
	if err != nil {
		t.Fatal(err)
	}
	// Key-agnostic: the invite mints a real UUID key (operator-minted-member-uuid);
	// this test only cares that the invited member landed in the per-fedlib registry.
	foundInvited := false
	for _, meta := range reg {
		if meta.State == "invited" && meta.Prefix == "alice" {
			foundInvited = true
			break
		}
	}
	if !foundInvited {
		t.Fatalf("invited member not in per-fedlib registry: %+v", reg)
	}
	singleton, _, _ := loadMembersRegistryFromPath(filepath.Join(accorderConfigDir, "aggregate_libraries.json"))
	if len(singleton) != 0 {
		t.Fatalf("invite leaked into the singleton registry: %+v", singleton)
	}
}

// schemaLawViolations returns credential-like field names on tt. Extracted as
// a helper so a synthetic struct can prove the check actually detects
// violations (success criterion 5).
func schemaLawViolations(tt reflect.Type) []string {
	forbidden := []string{"accesskey", "secretkey", "password", "token", "secret"}
	var violations []string
	for i := 0; i < tt.NumField(); i++ {
		name := strings.ToLower(tt.Field(i).Name)
		if strings.HasSuffix(name, "file") {
			continue // *_file fields are pointers to files, not values — allowed
		}
		for _, f := range forbidden {
			if strings.Contains(name, f) {
				violations = append(violations, tt.Field(i).Name)
			}
		}
	}
	return violations
}

// Schema law: no credential values, no member state, no serve runtime tuning.
func TestFedlibDescriptor_SchemaLaw_NoCredentialValues(t *testing.T) {
	if v := schemaLawViolations(reflect.TypeOf(fedlibDescriptor{})); len(v) > 0 {
		t.Errorf("fedlibDescriptor: credential-like fields %v — schema law forbids credential values in fedlibs.json", v)
	}
}

func TestFedlibDescriptor_SchemaLaw_DetectsPlantedCredential(t *testing.T) {
	type planted struct {
		SecretKey string
	}
	if len(schemaLawViolations(reflect.TypeOf(planted{}))) == 0 {
		t.Error("schemaLawViolations missed a planted credential-bearing field")
	}
}

// `fedlib build --fedlib-id <fed>` recalls bucket/S3/paths/keys-file from the
// descriptor (so a manual bootstrap needs no other flags); a bare build with no
// --fedlib-id (the daemon's path) is left untouched.
func TestFedlibBuild_RecallFromDescriptor(t *testing.T) {
	testSetup(t)
	fedDir := t.TempDir()
	kfPath := filepath.Join(accorderConfigDir, "op.s3.keys")
	if err := os.WriteFile(kfPath, []byte("access-key=AKID\nsecret-key=SEKRET\n"), 0o600); err != nil {
		t.Fatal(err)
	}
	if err := saveFedlibDescriptor("fed", fedlibDescriptor{
		Version:      fedlibDescriptorVersion,
		Bucket:       "motw/fed",
		S3Provider:   "Wasabi",
		S3Endpoint:   "https://s3.wasabisys.com",
		UploadPrefix: "aggregate",
		FedlibPath:   fedDir,
		KeysFile:     kfPath,
	}); err != nil {
		t.Fatal(err)
	}

	c := &FedlibBuildCmd{CommonCommandFields: CommonCommandFields{ActionAlias: "fed"}}
	if err := c.recallFromDescriptor(); err != nil {
		t.Fatalf("recall: %v", err)
	}
	if c.Bucket != "motw/fed" || c.S3Provider != "Wasabi" || c.S3Endpoint != "https://s3.wasabisys.com" {
		t.Errorf("S3 not recalled: bucket=%q provider=%q endpoint=%q", c.Bucket, c.S3Provider, c.S3Endpoint)
	}
	if c.OutputPath != fedDir {
		t.Errorf("OutputPath = %q, want %q (descriptor fedlib-path)", c.OutputPath, fedDir)
	}
	if c.UploadPrefix != "aggregate" {
		t.Errorf("UploadPrefix = %q, want aggregate", c.UploadPrefix)
	}
	if c.S3AccessKey != "AKID" || c.S3SecretKey != "SEKRET" {
		t.Errorf("creds not filled from descriptor keys-file: ak=%q sk=%q", c.S3AccessKey, c.S3SecretKey)
	}

	// Descriptor-less positional (funnel child / e2e path): explicit flags are
	// left untouched.
	bare := &FedlibBuildCmd{CommonCommandFields: CommonCommandFields{ActionAlias: "plain"}, OutputPath: "/explicit", Bucket: "explicit-bucket"}
	if err := bare.recallFromDescriptor(); err != nil {
		t.Fatalf("bare recall: %v", err)
	}
	if bare.OutputPath != "/explicit" || bare.Bucket != "explicit-bucket" {
		t.Errorf("descriptor-less build mutated explicit flags: out=%q bucket=%q", bare.OutputPath, bare.Bucket)
	}

	// Descriptor-less positional without --output-path → a clear error rather
	// than a silent empty build.
	if err := (&FedlibBuildCmd{CommonCommandFields: CommonCommandFields{ActionAlias: "nope"}}).recallFromDescriptor(); err == nil {
		t.Error("expected error for descriptor-less build without --output-path")
	}
}
