package cmd

import (
	"bytes"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/tidwall/gjson"
	"github.com/tidwall/sjson"
)

const teachUUID = "11111111-2222-3333-4444-555555555555"

func TestTeaching_FirstRunEmitsAndRecords(t *testing.T) {
	testSetup(t)

	var buf bytes.Buffer
	emitted, err := emitBrowseTeaching("from-alice", teachUUID, "http://192.168.1.24:8900/", "alices-library", &buf)
	if err != nil {
		t.Fatalf("marker persist: %v", err)
	}
	if !emitted {
		t.Fatal("first run must emit the orientation message")
	}

	got := buf.String()
	for _, want := range []string{
		"--from alices-library",
		"your name for their library",
		"from-alice",
		"your action alias",
		"the run uses 'default'",
		"Next time:  accorder lib browse from-alice",
	} {
		if !strings.Contains(got, want) {
			t.Errorf("message missing %q:\n%s", want, got)
		}
	}

	cfg := loadActionAliases()
	if !gjson.GetBytes(cfg, "from-alice.taught.uuid:"+teachUUID).Bool() {
		t.Errorf("marker not recorded under the uuid key:\n%s", cfg)
	}
}

func TestTeaching_SecondRunIsSilent(t *testing.T) {
	testSetup(t)

	var first, second bytes.Buffer
	if _, err := emitBrowseTeaching("from-alice", teachUUID, "http://h/", "alices-library", &first); err != nil {
		t.Fatalf("first: %v", err)
	}
	emitted, err := emitBrowseTeaching("from-alice", teachUUID, "http://h/", "alices-library", &second)
	if err != nil {
		t.Fatalf("second: %v", err)
	}
	if emitted || second.Len() != 0 {
		t.Errorf("repeat run must stay silent, got:\n%s", second.String())
	}
}

// The bookmark is written before the catalog sync, so a failed first run leaves
// one behind. The marker must not be set by that failed attempt — otherwise the
// successful retry (the run that actually needs the message) stays silent.
func TestTeaching_RetryAfterFailedFirstRunStillTeaches(t *testing.T) {
	testSetup(t)

	// First attempt never reached the boundary: nothing was emitted, so no
	// marker exists. Simulate by simply not calling the helper.
	cfg := loadActionAliases()
	if gjson.GetBytes(cfg, "from-alice.taught").Exists() {
		t.Fatal("precondition: no marker should exist before a successful run")
	}

	var buf bytes.Buffer
	emitted, err := emitBrowseTeaching("from-alice", teachUUID, "http://h/", "alices-library", &buf)
	if err != nil {
		t.Fatalf("retry: %v", err)
	}
	if !emitted {
		t.Error("a successful retry after a failed first run must still teach")
	}
}

func TestTeaching_NoRegistryHandleOmitsFromRow(t *testing.T) {
	testSetup(t)

	var buf bytes.Buffer

	// savedSource empty: full-download path created no registry entry.
	if _, err := emitBrowseTeaching("solo", teachUUID, "http://h/", "", &buf); err != nil {
		t.Fatalf("emit: %v", err)
	}
	got := buf.String()
	if strings.Contains(got, "--from") {
		t.Errorf("message must not name a --from handle that was never created:\n%s", got)
	}
	if !strings.Contains(got, "your action alias") {
		t.Errorf("reduced message should still explain the alias:\n%s", got)
	}
}

// registerOrUpdate suffixes on collision, so the handle the user must type is
// the resolved one, not the derived slug.
func TestTeaching_PrintsResolvedSuffixedHandle(t *testing.T) {
	testSetup(t)

	var buf bytes.Buffer
	if _, err := emitBrowseTeaching("from-alice", teachUUID, "http://h/", "alices-library-2", &buf); err != nil {
		t.Fatalf("emit: %v", err)
	}
	got := buf.String()
	if !strings.Contains(got, "--from alices-library-2") {
		t.Errorf("message must print the resolved (suffixed) handle:\n%s", got)
	}
}

func TestTeaching_DifferentSourceTeachesAgain(t *testing.T) {
	testSetup(t)

	var first, second bytes.Buffer
	if _, err := emitBrowseTeaching("mylib", teachUUID, "http://a/", "alices-library", &first); err != nil {
		t.Fatalf("first: %v", err)
	}

	// Same alias, different source UUID: a new relationship, so teach again.
	emitted, err := emitBrowseTeaching("mylib", "99999999-8888-7777-6666-555555555555", "http://b/", "bobs-library", &second)
	if err != nil {
		t.Fatalf("second: %v", err)
	}
	if !emitted {
		t.Errorf("pointing one alias at a different source must teach again:\n%s", second.String())
	}
}

// A run that predates UUID discovery records an endpoint-keyed marker. When the
// UUID later becomes known, the lookup must find that marker (and migrate it)
// rather than teaching the same source a second time.
func TestTeaching_EndpointMarkerMigratesToUUID(t *testing.T) {
	testSetup(t)

	const ep = "http://192.168.1.24:8900/"
	var first bytes.Buffer
	if _, err := emitBrowseTeaching("from-alice", "", ep, "alices-library", &first); err != nil {
		t.Fatalf("endpoint-keyed run: %v", err)
	}
	epKey := teachingKey("", ep)
	cfg := loadActionAliases()
	if !gjson.GetBytes(cfg, "from-alice.taught."+epKey).Bool() {
		t.Fatalf("precondition: endpoint marker not recorded (%s)", epKey)
	}

	var second bytes.Buffer
	emitted, err := emitBrowseTeaching("from-alice", teachUUID, ep, "alices-library", &second)
	if err != nil {
		t.Fatalf("uuid run: %v", err)
	}
	if emitted {
		t.Errorf("UUID discovery must not re-teach an already-taught source:\n%s", second.String())
	}

	// The silent run must also migrate the marker: uuid key recorded, endpoint
	// key removed — otherwise a later address change re-teaches the source and
	// stale ep: keys accumulate forever.
	cfg = loadActionAliases()
	if !gjson.GetBytes(cfg, "from-alice.taught."+teachingKey(teachUUID, "")).Bool() {
		t.Errorf("uuid-keyed marker not recorded after migration")
	}
	if gjson.GetBytes(cfg, "from-alice.taught."+epKey).Exists() {
		t.Errorf("stale endpoint-keyed marker not removed by migration")
	}
}

// The marker is optional UX state: a browse must never fail because it could
// not be written.
func TestTeaching_MarkerWriteFailureIsReportedNotFatal(t *testing.T) {
	testSetup(t)

	if os.Geteuid() == 0 {
		t.Skip("root bypasses directory permissions")
	}

	// Make the config dir read-only: the alias file still LOADS (loadActionAliases
	// is fatal on read failure, so it must keep working), but the tmp-file write
	// cannot land — which is the failure this test is about.
	dir := filepath.Dir(savedActionAliases)
	info, err := os.Stat(dir)
	if err != nil {
		t.Fatal(err)
	}
	if err := os.Chmod(dir, 0o500); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = os.Chmod(dir, info.Mode().Perm()) })

	var buf bytes.Buffer
	emitted, terr := emitBrowseTeaching("from-alice", teachUUID, "http://h/", "alices-library", &buf)
	if terr == nil {
		t.Error("expected the persist error to be returned for the caller to log")
	}
	if !emitted {
		t.Error("the message must still be shown even when the marker cannot be saved")
	}
}

func TestTeachingKey_IsDotPathSafe(t *testing.T) {

	// Raw URLs contain "." and "/", which sjson would read as path separators.
	k := teachingKey("", "http://192.168.1.24:8900/lib")
	if strings.ContainsAny(strings.TrimPrefix(k, "ep:"), "./") {
		t.Errorf("endpoint key %q must not contain dot-path separators", k)
	}
	if !strings.HasPrefix(k, "ep:") {
		t.Errorf("endpoint key %q should carry the ep: discriminator", k)
	}
	if got := teachingKey(teachUUID, "http://h/"); got != "uuid:"+teachUUID {
		t.Errorf("uuid key = %q, want the uuid form", got)
	}
}

func TestTeaching_MarkerSurvivesInRealConfigShape(t *testing.T) {
	testSetup(t)

	// Write an alias tree first, then the marker, and confirm both coexist.
	cfg := loadActionAliases()
	cfg, err := sjson.SetBytes(cfg, "from-alice.lib.browse.endpoint", "http://h/")
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(savedActionAliases, cfg, 0644); err != nil {
		t.Fatal(err)
	}

	var buf bytes.Buffer
	if _, err := emitBrowseTeaching("from-alice", teachUUID, "http://h/", "alices-library", &buf); err != nil {
		t.Fatalf("emit: %v", err)
	}

	got := loadActionAliases()
	if v := gjson.GetBytes(got, "from-alice.lib.browse.endpoint").String(); v != "http://h/" {
		t.Errorf("existing alias data clobbered by the marker write: %q", v)
	}
	if !gjson.GetBytes(got, "from-alice.taught.uuid:"+teachUUID).Bool() {
		t.Error("marker missing after write alongside alias data")
	}
}
