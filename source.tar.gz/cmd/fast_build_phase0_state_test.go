//go:build linux && !tailscale

package cmd

import (
	"bytes"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"reflect"
	"sort"
	"strings"
	"syscall"
	"testing"
	"time"

	"accorder/pkg/calibre"
	"accorder/pkg/libraryflow"
	"accorder/pkg/torshare"
)

// Phase 0 experiment only. This is deliberately not read by production commands.
// It tests a single atomically activated bundle rather than independently
// upgrading the baseline and candidate. Identity policy here is Linux-only;
// production capability detection and command integration remain separate work.
type phase0Evidence struct {
	Version                      int
	Library, Seat, Root, RootID  string
	CoverageToken, ObservedToken string
	Known                        bool
	Inventory                    []phase0Entry
	Pending, Removed             []string
	LegacyAnchors                map[string]string
	Recovery                     []byte
	Candidate                    []byte
}

type phase0Entry struct {
	Object libraryflow.Object
	FileID string
}

func phase0ID(path string) (string, error) {
	info, err := os.Stat(path)
	if err != nil {
		return "", err
	}
	stat, ok := info.Sys().(*syscall.Stat_t)
	if !ok || stat.Ino == 0 {
		return "", errors.New("missing native identity")
	}
	return fmt.Sprintf("%x:%x", stat.Dev, stat.Ino), nil
}

func phase0TupleEqual(a, b libraryflow.Object) bool {
	return a.Path == b.Path && a.Size == b.Size && !a.ModTime.IsZero() &&
		a.ModTime.Equal(b.ModTime) && a.ChangeTime > 0 && a.ChangeTime == b.ChangeTime
}

func phase0Inventory(root string, previous []phase0Entry, excludes []string) ([]phase0Entry, []string, []string, error) {
	objects, err := listLocalObjects(root)
	if err != nil {
		return nil, nil, nil, err
	}
	objects, err = libraryflow.FilterInventory(objects, excludes, false)
	if err != nil {
		return nil, nil, nil, err
	}
	old := make(map[string]phase0Entry, len(previous))
	for _, entry := range previous {
		old[entry.Object.Path] = entry
	}
	var entries []phase0Entry
	var changed []string
	for _, object := range objects {
		path := filepath.Join(root, filepath.FromSlash(object.Path))
		id, err := phase0ID(path)
		if err != nil {
			return nil, nil, nil, err
		}
		prior, existed := old[object.Path]
		if existed && prior.FileID == id && phase0TupleEqual(prior.Object, object) {
			object.Hash = prior.Object.Hash
		} else {
			changed = append(changed, object.Path)
		}
		// metadata.db remains explicitly hashed; book formats do not.
		if object.Path == "metadata.db" && object.Hash == "" {
			object.Hash, err = hashLocalFile(path)
			if err != nil {
				return nil, nil, nil, err
			}
		}
		entries = append(entries, phase0Entry{object, id})
		delete(old, object.Path)
	}
	var removed []string
	for path := range old {
		removed = append(removed, path)
	}
	sort.Strings(removed)
	return entries, changed, removed, nil
}

func phase0Import(root string, installation libraryInstallation, baseline *libraryBaseline, token string) (phase0Evidence, error) {
	canonical, err := filepath.EvalSymlinks(root)
	if err != nil {
		return phase0Evidence{}, err
	}
	id, err := phase0ID(root)
	if err != nil {
		return phase0Evidence{}, err
	}
	state := phase0Evidence{Version: 2, Seat: installation.SeatID, Root: canonical, RootID: id, ObservedToken: token}
	// Use the existing v1 validation contract, not v0's refreshed timestamp.
	var ledger []libraryflow.Object
	if baseline != nil {
		state.Library = baseline.LibraryID
		if baseline.ContentLedgerVersion == 1 && validateSourceContentLedger(baseline.ContentLedger) == nil {
			ledger = baseline.ContentLedger // Hash reuse is separate from coverage.
		}
		_, coverageErr := spikeImportProvenCoverage(baseline, baseline.GenerationToken)
		_, tokenErr := decodeGenerationHex(baseline.GenerationToken)
		state.Known = coverageErr == nil && tokenErr == nil
	}
	if state.Known {
		state.CoverageToken = baseline.GenerationToken
	}
	// Inherited v1 lacks native IDs. Its existing nonzero-change-time reuse
	// contract is retained for one import, not represented as retroactive IDs.
	var prior []phase0Entry
	if ledger != nil {
		for _, object := range ledger {
			fileID, statErr := phase0ID(filepath.Join(root, filepath.FromSlash(object.Path)))
			if os.IsNotExist(statErr) {
				prior = append(prior, phase0Entry{Object: object})
				continue
			}
			if statErr != nil {
				return phase0Evidence{}, statErr
			}
			prior = append(prior, phase0Entry{object, fileID})
		}
	}
	state.Inventory, state.Pending, state.Removed, err = phase0Inventory(root, prior, nil)
	return state, err
}

func phase0Rebuild(state phase0Evidence, root, seat string, excludes []string) (phase0Evidence, error) {
	id, err := phase0ID(root)
	if err != nil {
		return state, err
	}
	canonical, err := filepath.EvalSymlinks(root)
	if err != nil {
		return state, err
	}
	if state.Seat != seat || state.Root != canonical || state.RootID != id {
		return state, errors.New("provenance mismatch; preserve prior evidence")
	}
	entries, changed, removed, err := phase0Inventory(root, state.Inventory, excludes)
	if err != nil {
		return state, err
	}
	objects := make([]libraryflow.Object, len(entries))
	for i, entry := range entries {
		objects[i] = entry.Object
	}
	state.Pending = mergeCandidateForcePaths(state.Pending, changed, objects)
	state.Removed = mergePhase0Paths(state.Removed, removed)
	state.Inventory = entries
	return state, nil
}

func mergePhase0Paths(a, b []string) []string {
	seen := map[string]bool{}
	for _, path := range append(append([]string(nil), a...), b...) {
		seen[path] = true
	}
	var paths []string
	for path := range seen {
		paths = append(paths, path)
	}
	sort.Strings(paths)
	return paths
}

func phase0CheckPublish(state phase0Evidence, token string) error {
	if !state.Known || state.CoverageToken == "" || state.CoverageToken != token {
		return errors.New("unresolved predecessor coverage")
	}
	for _, entry := range state.Inventory {
		if entry.FileID == "" || entry.Object.ChangeTime <= 0 || entry.Object.ModTime.IsZero() {
			return errors.New("source coherence unavailable")
		}
	}
	return nil
}

func TestFastBuildPhase0InventoryImportAndPending(t *testing.T) {
	testSetup(t)
	root := t.TempDir()
	for _, path := range []string{"metadata.db", "keep.epub", "edit.epub", "move.epub", "delete.epub", "private.epub"} {
		writeTestFile(t, root, path, "old!")
	}
	objects, err := listLocalObjects(root)
	if err != nil {
		t.Fatal(err)
	}
	ledger, _, _, err := buildContentLedger(root, objects, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	token := hex.EncodeToString(generationChangeMemberToken(10))
	baseline := &libraryBaseline{LibraryID: "library", ContentLedgerVersion: 1, ContentLedger: ledger,
		GenerationToken: token, LocalSourceFingerprint: "same", RemoteSourceFingerprint: "same"}
	installation, err := loadOrCreateInstallation()
	if err != nil {
		t.Fatal(err)
	}
	state, err := phase0Import(root, installation, baseline, token)
	if err != nil || !state.Known || len(state.Pending) != 0 {
		t.Fatalf("import=%+v err=%v", state, err)
	}
	for i, entry := range state.Inventory {
		if entry.Object.Hash != ledger[i].Hash {
			t.Fatal("import lost hash")
		}
	}
	oldInfo, err := os.Stat(filepath.Join(root, "edit.epub"))
	if err != nil {
		t.Fatal(err)
	}
	time.Sleep(2 * time.Millisecond)
	writeTestFile(t, root, "edit.epub", "new!")
	if err := os.Chtimes(filepath.Join(root, "edit.epub"), oldInfo.ModTime(), oldInfo.ModTime()); err != nil {
		t.Fatal(err)
	}
	writeTestFile(t, root, "new.epub", "epub")
	writeTestFile(t, root, "new.pdf", "pdf!")
	if err := os.Rename(filepath.Join(root, "move.epub"), filepath.Join(root, "moved.epub")); err != nil {
		t.Fatal(err)
	}
	if err := os.Remove(filepath.Join(root, "delete.epub")); err != nil {
		t.Fatal(err)
	}
	state, err = phase0Rebuild(state, root, installation.SeatID, []string{"private.epub"})
	if err != nil {
		t.Fatal(err)
	}
	want := []string{"edit.epub", "moved.epub", "new.epub", "new.pdf"}
	if !reflect.DeepEqual(state.Pending, want) || !reflect.DeepEqual(state.Removed, []string{"delete.epub", "move.epub", "private.epub"}) {
		t.Fatalf("pending=%v removed=%v", state.Pending, state.Removed)
	}
	for _, entry := range state.Inventory {
		if entry.Object.Path == "keep.epub" && entry.Object.Hash == "" {
			t.Fatal("unchanged hash discarded")
		}
		if entry.Object.Path == "edit.epub" && entry.Object.Hash != "" {
			t.Fatal("stale hash retained")
		}
	}
	repeated, err := phase0Rebuild(state, root, installation.SeatID, []string{"private.epub"})
	if err != nil || !reflect.DeepEqual(repeated, state) {
		t.Fatalf("repeat lost pending state: %v", err)
	}
	// Private-to-public restores selection without hashing the newly public file.
	public, err := phase0Rebuild(repeated, root, installation.SeatID, nil)
	if err != nil || !reflect.DeepEqual(public.Pending, append(want, "private.epub")) {
		t.Fatalf("public transition=%v err=%v", public.Pending, err)
	}
	if _, err := phase0Rebuild(state, root, "other-seat", nil); err == nil {
		t.Fatal("copied seat trusted")
	}
	for _, kind := range []string{"missing", "v0", "corrupt", "other-predecessor"} {
		t.Run(kind, func(t *testing.T) {
			copy := *baseline
			input := &copy
			switch kind {
			case "missing":
				input = nil
			case "v0":
				copy.ContentLedgerVersion = 0
			case "corrupt":
				copy.ContentLedger = []libraryflow.Object{{Path: "../escape"}}
			case "other-predecessor":
				copy.GenerationToken = hex.EncodeToString(generationChangeMemberToken(11))
			}
			unknown, err := phase0Import(root, installation, input, token)
			if err != nil || (unknown.Known && kind != "other-predecessor") || phase0CheckPublish(unknown, token) == nil {
				t.Fatalf("unknown promoted: %+v %v", unknown, err)
			}
			if kind == "other-predecessor" && unknown.CoverageToken != copy.GenerationToken {
				t.Fatal("remote observation erased original coverage ancestry")
			}
		})
	}
	t.Log("complete v1 hashes preserved; add/edit/delete/move/private changes tracked; repeated build retains pending paths without hashing formats")
}

func phase0Anchor(path string) (string, error) {
	digest, err := hashLocalFile(path)
	if os.IsNotExist(err) {
		return "absent", nil
	}
	return digest, err
}

func phase0Load(path string) (phase0Evidence, error) {
	var state phase0Evidence
	if err := readJSONFile(path, &state); err != nil {
		return state, err
	}
	if state.Version != 2 {
		return state, errors.New("unsupported evidence version")
	}
	for path, digest := range state.LegacyAnchors {
		current, err := phase0Anchor(path)
		if err != nil {
			return state, err
		}
		if digest != current {
			return state, errors.New("legacy client changed retained state; do not re-import")
		}
	}
	return state, nil
}

func TestFastBuildPhase0IsolatedStateAndOldExecutable(t *testing.T) {
	binary := os.Getenv("ACCORDER_PHASE0_OLD_BINARY")
	if binary == "" {
		t.Skip("explicit released v0.20.1 executable required")
	}
	digest, err := hashLocalFile(binary)
	if err != nil || digest != "6897cc6e4ef11ce7eb1ffbf5676eacd5db0e071d8606ee61a5032f168c7a1b05" {
		t.Fatalf("unverified old executable: digest=%s err=%v", digest, err)
	}
	root := testSetup(t)
	seedPublishCalibreLibrary(t, root)
	xdg := t.TempDir()
	const alias = "phase0"
	const libraryID = "550e8400-e29b-41d4-a716-446655440000"
	runOld := func(args ...string) ([]byte, error) {
		command := exec.Command(binary, args...)
		command.Env = []string{"PATH=" + os.Getenv("PATH"), "XDG_CONFIG_HOME=" + xdg, "XDG_CACHE_HOME=" + t.TempDir(), "LANG=C.UTF-8", "NO_COLOR=1"}
		command.Dir = root
		return command.CombinedOutput()
	}
	buildArgs := []string{"lib", "build", alias, "-c", root, "-i", libraryID, "-l", "Phase Zero", "--index"}
	if output, err := runOld(buildArgs...); err != nil {
		t.Fatalf("old build: %s %v", output, err)
	}
	legacy, err := loadLocalChangeCandidate(root)
	if err != nil {
		t.Fatal(err)
	}
	legacyBytes, err := os.ReadFile(localChangeCandidateFile(root))
	if err != nil {
		t.Fatal(err)
	}
	// Check the frozen reader rejects optional hashes under both v1 and v2.
	partial := *legacy
	partial.ContentLedger = append([]libraryflow.Object(nil), legacy.ContentLedger...)
	partial.ContentLedger[0].Hash = ""
	if partial.validate() == nil {
		t.Fatal("v1 accepted a missing hash")
	}
	partial.Version = 2
	partial.ContentLedgerVersion = 2
	if partial.validate() == nil {
		t.Fatal("old reader accepted v2")
	}

	newPath := evidenceStatePath(legacyChangeCandidateFile(root))
	anchor, err := phase0Anchor(legacyChangeCandidateFile(root))
	if err != nil {
		t.Fatal(err)
	}
	recovery := []byte(`{"version":2,"manifest":"exact immutable bytes","stage":"payload-complete"}`)
	state := phase0Evidence{Version: 2, Library: libraryID, Recovery: recovery,
		LegacyAnchors: map[string]string{legacyChangeCandidateFile(root): anchor}}
	if err := writeJSONAtomic(newPath, state); err != nil {
		t.Fatal(err)
	}
	saved, err := os.ReadFile(newPath)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := phase0Load(newPath); err != nil {
		t.Fatal(err)
	}
	// An interrupted activation writes only the pending sibling; active stays intact.
	if err := os.WriteFile(newPath+".pending", []byte(`{"Version":2`), 0o600); err != nil {
		t.Fatal(err)
	}
	if got, err := phase0Load(newPath); err != nil || !bytes.Equal(got.Recovery, recovery) {
		t.Fatalf("interruption lost recovery: %v", err)
	}
	// Force the old client to rebuild its legacy candidate without touching v2.
	writeTestFile(t, root, "Author/Book (1)/Book - Author.epub", "changed")
	if output, err := runOld(buildArgs...); err != nil {
		t.Fatalf("old rebuild: %s %v", output, err)
	}
	after, err := os.ReadFile(newPath)
	if err != nil || !bytes.Equal(after, saved) {
		t.Fatalf("old client altered v2 bytes: %v", err)
	}
	if _, err := phase0Load(newPath); err == nil {
		t.Fatal("legacy mutation was silently imported")
	}
	newLegacy, err := os.ReadFile(legacyChangeCandidateFile(root))
	if err != nil || bytes.Equal(newLegacy, legacyBytes) {
		t.Fatalf("counterexample did not alter legacy candidate: %v", err)
	}
	// Restore only the test fixture's old checkpoint for the dry-run control.
	if err := os.WriteFile(legacyChangeCandidateFile(root), legacyBytes, 0o600); err != nil {
		t.Fatal(err)
	}
	output, uploadErr := runOld("lib", "upload", alias, "-c", root, "--bucket", "fixture/member", "--dry-run",
		"--s3-access-key", "phase0-dummy", "--s3-secret-key", "phase0-dummy", "--s3-provider", "Other", "--s3-endpoint", "http://127.0.0.1:1")
	if uploadErr == nil || !strings.Contains(string(output), "lib build") {
		t.Fatalf("old dry-run should require build without network: %s %v", output, uploadErr)
	}
	after, err = os.ReadFile(newPath)
	if err != nil || !bytes.Equal(after, saved) {
		t.Fatalf("old dry-run altered v2: %v", err)
	}
	t.Logf("released v0.20.1 build/rebuild/dry-run preserved isolated v2 recovery; legacy mutation detected; executable SHA256=%s", digest)
}

func TestFastBuildMalformedRecoveryIsRetained(t *testing.T) {
	testSetup(t)
	const alias = "phase0"
	record := publishRecoveryRecord{Version: 2, Alias: alias, LibraryID: "library", Generation: 1, SourceFingerprint: "source", Manifest: []byte("immutable")}
	isolated := filepath.Join(machineStateDir(), "evidence-v2", alias+".json")
	if err := writeJSONAtomic(isolated, record); err != nil {
		t.Fatal(err)
	}
	if err := writeJSONAtomic(publishRecoveryPath(alias), record); err != nil {
		t.Fatal(err)
	}
	before, err := os.ReadFile(isolated)
	if err != nil {
		t.Fatal(err)
	}
	// The original Phase 0 result records v0.20.1 deleting this record.
	// The new reader must preserve it; nil detects accidental remote access.
	finished, err := recoverPublishBookkeeping(alias, "library", nil, t.TempDir(), publishOptions{})
	if err == nil || finished {
		t.Fatalf("malformed recovery accepted: finished=%t %v", finished, err)
	}
	if _, err := os.Stat(publishRecoveryPath(alias)); err != nil {
		t.Fatalf("malformed recovery was not retained: %v", err)
	}
	after, err := os.ReadFile(isolated)
	if err != nil || !bytes.Equal(before, after) {
		t.Fatalf("isolated recovery changed: %v", err)
	}
	t.Log("malformed v2 recovery is retained without contacting the remote")
}

func TestFastBuildPhase0IsolatedRealRecovery(t *testing.T) {
	testSetup(t)
	const libraryID = "550e8400-e29b-41d4-a716-446655440000"
	candidate := makePublishCandidate(t, libraryID, "payload")
	remoteRoot := t.TempDir()
	checksum := generationCandidateChecksum(t)
	fromToken := seedExactChangeRemote(t, remoteRoot, candidate, checksum)
	attachExactEmptyChange(t, candidate, fromToken, checksum)
	withLocalCommandRemote(t, remoteRoot)
	interrupted := errors.New("phase0 interrupt after immutable create")
	publishCommitStageHook = func(stage string) error {
		if stage == "after-manifest" {
			return interrupted
		}
		return nil
	}
	t.Cleanup(func() { publishCommitStageHook = nil })
	if err := publishCandidate("alice", libraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: libraryflow.DefaultMaxDeletes}); !errors.Is(err, interrupted) {
		t.Fatalf("wrong interruption: %v", err)
	}
	recoveryPath := publishRecoveryPath("alice")
	raw, err := os.ReadFile(recoveryPath)
	if err != nil {
		t.Fatal(err)
	}
	var record publishRecoveryRecord
	if err := readJSONFile(recoveryPath, &record); err != nil || record.Stage != "payload-complete" {
		t.Fatalf("wrong durable boundary: %+v %v", record, err)
	}
	anchor, err := phase0Anchor(recoveryPath)
	if err != nil {
		t.Fatal(err)
	}
	isolated := filepath.Join(machineStateDir(), "evidence-v2", "alice.json")
	state := phase0Evidence{Version: 2, Library: libraryID, Recovery: raw,
		LegacyAnchors: map[string]string{recoveryPath: anchor}}
	if err := writeJSONAtomic(isolated, state); err != nil {
		t.Fatal(err)
	}
	loaded, err := phase0Load(isolated)
	if err != nil || !bytes.Equal(loaded.Recovery, raw) {
		t.Fatalf("isolated activation changed real transaction bytes: %v", err)
	}
	// The frozen v0.20.1 recovery function completes the retained v1 record.
	// It is not an old executable talking to S3; this is a local-backend test.
	publishCommitStageHook = nil
	recovered, err := recoverPublishBookkeeping("alice", libraryID, &libraryRemote{fsPath: remoteRoot}, candidate.Root, publishOptions{})
	if err != nil || !recovered {
		t.Fatalf("retained recovery failed: recovered=%t err=%v", recovered, err)
	}
	for path, want := range map[string][]byte{record.ManifestPath: record.Manifest, memberPointerPath: record.Pointer} {
		got, err := os.ReadFile(filepath.Join(remoteRoot, filepath.FromSlash(path)))
		if err != nil || !bytes.Equal(got, want) {
			t.Fatalf("recovered %s bytes changed: %v", path, err)
		}
	}
	token, err := readLocalGenerationHex(remoteRoot)
	if err != nil || token != record.GenerationToken {
		t.Fatalf("recovered wrong generation: %s %v", token, err)
	}
	if _, err := phase0Load(isolated); err == nil {
		t.Fatal("old recovery completion was silently treated as unchanged legacy state")
	}
	var retained phase0Evidence
	if err := readJSONFile(isolated, &retained); err != nil || !bytes.Equal(retained.Recovery, raw) {
		t.Fatalf("old recovery lost isolated transaction: %v", err)
	}
	t.Log("isolated bundle preserves real v1 transaction bytes; frozen recovery commits exact artifacts; subsequent load detects old-client completion and requires reconciliation")
}

func TestFastBuildPhase0SyncAncestryCounterexample(t *testing.T) {
	testSetup(t)
	const libraryID = "550e8400-e29b-41d4-a716-446655440000"
	remote := t.TempDir()
	writeTestFile(t, remote, "metadata.db", "metadata")
	writeTestFile(t, remote, "book.epub", "old!")
	seedCommittedRemote(t, remote, 7)
	withLocalCommandRemote(t, remote)
	destination := filepath.Join(t.TempDir(), "library")
	command := &LibSyncCmd{GroupLib: GroupLib{GroupLibDir: GroupLibDir{CalibreDirectory: destination}, LibraryID: libraryID}, ExpectedLibraryID: libraryID}
	command.ActionAlias = "ancestry"
	if err := command.Run(nil); err != nil {
		t.Fatal(err)
	}
	baseline, err := loadBaseline("ancestry")
	if err != nil || baseline == nil {
		t.Fatalf("baseline=%+v %v", baseline, err)
	}
	objects, err := listLocalObjects(destination)
	if err != nil {
		t.Fatal(err)
	}
	ledger, _, _, err := buildContentLedger(destination, objects, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	baseline.ContentLedger = ledger
	baseline.CatalogChecksum = strings.Repeat("a", 64)
	baseline.GenerationToken, err = readLocalGenerationHex(remote)
	if err != nil {
		t.Fatal(err)
	}
	if err := saveBaseline("ancestry", *baseline); err != nil {
		t.Fatal(err)
	}
	installation, err := loadOrCreateInstallation()
	if err != nil {
		t.Fatal(err)
	}
	importFixture := *baseline
	importFixture.ContentLedgerVersion = 1
	state, err := phase0Import(destination, installation, &importFixture, baseline.GenerationToken)
	if err != nil {
		t.Fatal(err)
	}
	state.Pending = []string{"book.epub"} // Pending scope must survive observation.
	writeTestFile(t, remote, "book.epub", "new!")
	seedCommittedRemote(t, remote, 8)
	observed, err := readLocalGenerationHex(remote)
	if err != nil {
		t.Fatal(err)
	}
	localFP, _, err := libraryflow.SourceFingerprint(destination, nil)
	if err != nil {
		t.Fatal(err)
	}
	remoteFP, _, err := libraryflow.SourceFingerprint(remote, nil)
	if err != nil || localFP != remoteFP {
		t.Fatalf("portable fingerprints differ: %v", err)
	}
	if err := command.Run(nil); err == nil || !strings.Contains(err.Error(), "Matching names and sizes") {
		t.Fatalf("remote advance was not refused: %v", err)
	}
	rebound, err := loadBaseline("ancestry")
	if err != nil || rebound.GenerationToken != baseline.GenerationToken || !reflect.DeepEqual(rebound.ContentLedger, baseline.ContentLedger) {
		t.Fatalf("sync changed established coverage: %+v %v", rebound, err)
	}
	localBytes, err := os.ReadFile(filepath.Join(destination, "book.epub"))
	if err != nil || string(localBytes) != "old!" {
		t.Fatalf("counterexample unexpectedly synced bytes: %q %v", localBytes, err)
	}
	// Proposed observation only: retain the established token and all payload
	// evidence. This is not yet wired into LibSyncCmd above.
	before := state
	state.ObservedToken = observed
	if phase0CheckPublish(state, observed) == nil || state.CoverageToken != before.CoverageToken || !reflect.DeepEqual(state.Inventory, before.Inventory) || !reflect.DeepEqual(state.Pending, before.Pending) {
		t.Fatal("observation manufactured coverage or discarded evidence")
	}
	var otherBase [16]byte
	otherBase[0] = 99
	otherToken := hex.EncodeToString(torshare.EncodeGeneration(otherBase, 7))
	if phase0CheckPublish(state, otherToken) == nil {
		t.Fatal("same counter/different base accepted")
	}
	command.RemoteWins = true
	if err := command.Run(nil); err != nil {
		t.Fatal(err)
	}
	activated, err := os.ReadFile(filepath.Join(destination, "book.epub"))
	if err != nil || string(activated) != "new!" {
		t.Fatalf("explicit activation did not copy remote bytes: %q %v", activated, err)
	}
	t.Log("sync refuses fingerprint-only rebind and preserves A; explicit remote-wins activates B's actual bytes")
}

func TestFastBuildPhase0SourceBoundaryChecks(t *testing.T) {
	// Install the proposed inventory guard through real publisher fault hooks.
	// This establishes boundary reachability and the guard's decision, not
	// production integration: normal publication still uses the v1 ledger.
	for _, boundary := range []string{"before-mirror", "after-mirror", "before-manifest", "before-sentinel"} {
		for _, edit := range []bool{false, true} {
			t.Run(fmt.Sprintf("%s/edit=%t", boundary, edit), func(t *testing.T) {
				testSetup(t)
				candidate := makePublishCandidate(t, "550e8400-e29b-41d4-a716-446655440000", "payload")
				remoteRoot := t.TempDir()
				checksum := generationCandidateChecksum(t)
				fromToken := seedExactChangeRemote(t, remoteRoot, candidate, checksum)
				attachExactEmptyChange(t, candidate, fromToken, checksum)
				withLocalCommandRemote(t, remoteRoot)
				before, _, _, err := phase0Inventory(candidate.Root, nil, nil)
				if err != nil {
					t.Fatal(err)
				}
				const payloadPath = "Author/Book (1)/book.epub"
				info, err := os.Stat(filepath.Join(candidate.Root, filepath.FromSlash(payloadPath)))
				if err != nil {
					t.Fatal(err)
				}
				detected := errors.New("phase0 source changed")
				reached := false
				publishCommitStageHook = func(stage string) error {
					if stage != boundary {
						return nil
					}
					reached = true
					if edit {
						time.Sleep(2 * time.Millisecond)
						writeTestFile(t, candidate.Root, payloadPath, "changed")
						if err := os.Chtimes(filepath.Join(candidate.Root, filepath.FromSlash(payloadPath)), info.ModTime(), info.ModTime()); err != nil {
							return err
						}
					}
					_, changed, removed, err := phase0Inventory(candidate.Root, before, nil)
					if err != nil {
						return err
					}
					if edit {
						if !reflect.DeepEqual(changed, []string{payloadPath}) || len(removed) != 0 {
							return fmt.Errorf("unexpected inventory change: changed=%v removed=%v", changed, removed)
						}
						return detected
					}
					if len(changed) != 0 || len(removed) != 0 {
						return fmt.Errorf("unchanged source rejected: changed=%v removed=%v", changed, removed)
					}
					return nil
				}
				t.Cleanup(func() { publishCommitStageHook = nil })
				err = publishCandidate("alice", candidate.Change.LibraryUUID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: libraryflow.DefaultMaxDeletes})
				if !reached {
					t.Fatalf("publisher did not reach %s: %v", boundary, err)
				}
				if edit {
					if !errors.Is(err, detected) {
						t.Fatalf("publisher did not reject injected edit: %v", err)
					}
					remoteToken, readErr := os.ReadFile(filepath.Join(remoteRoot, libraryflow.GenerationPath))
					if readErr != nil || !bytes.Equal(remoteToken, fromToken) {
						t.Fatalf("rejected edit advanced sentinel: %x %v", remoteToken, readErr)
					}
					// At before-sentinel the pointer/manifest may already have been
					// written. Only the sentinel is asserted unchanged; recovery must
					// retain responsibility for those earlier, non-atomic writes.
				} else if err != nil {
					t.Fatal(err)
				} else if snapshot := (&libraryRemote{fsPath: remoteRoot}).commitState(); snapshot.Err != nil || !snapshot.Committed || snapshot.Generation != 2 {
					t.Fatalf("unchanged publication did not commit: %+v", snapshot)
				}
			})
		}
	}
	state := phase0Evidence{Known: true, CoverageToken: "token", Inventory: []phase0Entry{{Object: libraryflow.Object{Path: "book.epub", ModTime: time.Now()}, FileID: "id"}}}
	if phase0CheckPublish(state, "token") == nil {
		t.Fatal("missing ChangeTime treated as coherent")
	}
}

func TestFastBuildPhase0PendingCandidateBundle(t *testing.T) {
	// Reuse the real catalog compiler/composer; only persistence is experimental.
	root := testSetup(t)
	writeTestFile(t, root, "metadata.db", "metadata")
	writeTestFile(t, root, "book.epub", "payload")
	objects, err := listLocalObjects(root)
	if err != nil {
		t.Fatal(err)
	}
	ledger, _, _, err := buildContentLedger(root, objects, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	bookA := generationCandidateBook()
	bookB, bookC := *bookA, *bookA
	bookB.Title, bookC.Title = "middle", "final"
	diff := func(before, after *calibre.Book) calibre.CatalogDiff {
		t.Helper()
		info, err := calibre.CatalogRecordInfoForBook(before)
		if err != nil {
			t.Fatal(err)
		}
		result, err := calibre.CompileCatalogDiffFromRecordInfos([]*calibre.Book{after}, map[string]calibre.CatalogRecordInfo{before.Id: info})
		if err != nil {
			t.Fatal(err)
		}
		return result
	}
	ab, bc := diff(bookA, &bookB), diff(&bookB, &bookC)
	token := hex.EncodeToString(generationChangeMemberToken(10))
	prior := spikeCandidateFromDiff(ab, bookA.LibraryUUID, token, ledger[0])
	prior.ContentLedger, prior.ForcePaths = ledger, []string{"book.epub"}
	delta := spikeCandidateFromDiff(bc, bookA.LibraryUUID, token, ledger[0])
	delta.ContentLedger = ledger
	for _, reason := range []string{"", "legacy-content-baseline-upgrade", "missing-content-baseline"} {
		t.Run("reason="+reason, func(t *testing.T) {
			input := prior
			if reason != "" {
				input.makeCoarse(reason, reason == "missing-content-baseline")
			}
			if err := input.validate(); err != nil {
				t.Fatal(err)
			}
			raw, err := json.Marshal(input)
			if err != nil {
				t.Fatal(err)
			}
			path := filepath.Join(t.TempDir(), "evidence-v2.json")
			if err := writeJSONAtomic(path, phase0Evidence{Version: 2, Candidate: raw}); err != nil {
				t.Fatal(err)
			}
			bundle, err := phase0Load(path)
			if err != nil || !bytes.Equal(bundle.Candidate, raw) {
				t.Fatalf("candidate bytes: %v", err)
			}
			var imported localChangeCandidate
			if err := json.Unmarshal(bundle.Candidate, &imported); err != nil {
				t.Fatal(err)
			}
			combined, err := composeLocalBuildCandidate(imported, delta)
			if err != nil {
				t.Fatal(err)
			}
			if combined.FromGeneration != token || combined.FromCatalogChecksum != ab.FromChecksum || combined.ToCatalogChecksum != bc.ToChecksum || !reflect.DeepEqual(combined.ForcePaths, input.ForcePaths) || combined.CompleteOverwrite != input.CompleteOverwrite || combined.Reason != reason {
				t.Fatalf("migration lost ancestry, paths or reason: %+v", combined)
			}
			if reason == "" && (len(combined.Changes) != 1 || combined.Changes[0].OldRecordDigest != ab.Changes[0].OldRecordDigest || combined.Changes[0].NewRecordDigest != bc.Changes[0].NewRecordDigest) {
				t.Fatal("lost A-B-C catalog composition")
			}
			// Even a legacy-derived v1 candidate must not turn unknown coverage
			// into known solely because all its local files have hashes.
			if bundle.Known || phase0CheckPublish(bundle, token) == nil {
				t.Fatal("candidate promoted coverage")
			}
		})
	}
}

func TestFastBuildPhase0LocalDerivedRepairControl(t *testing.T) {
	testSetup(t)
	const libraryID = "550e8400-e29b-41d4-a716-446655440000"
	candidate := makePublishCandidate(t, libraryID, "payload")
	remoteRoot := t.TempDir()
	checksum := generationCandidateChecksum(t)
	from := seedExactChangeRemote(t, remoteRoot, candidate, checksum)
	attachExactEmptyChange(t, candidate, from, checksum)
	pointer, err := calibre.ReadPointerFile(filepath.Join(remoteRoot, filepath.FromSlash(memberPointerPath)))
	if err != nil {
		t.Fatal(err)
	}
	pointer, err = calibre.BindPointerCommit(pointer, candidate.SourceFingerprint, 1)
	if err != nil {
		t.Fatal(err)
	}
	if err := calibre.WritePointerDocument(filepath.Join(remoteRoot, filepath.FromSlash(memberPointerPath)), pointer); err != nil {
		t.Fatal(err)
	}
	baseline := &libraryBaseline{LibraryID: libraryID, Generation: 1, GenerationToken: hex.EncodeToString(from), CatalogChecksum: checksum,
		LocalSourceFingerprint: candidate.SourceFingerprint, RemoteSourceFingerprint: candidate.SourceFingerprint,
		ContentLedgerVersion: 1, ContentLedger: candidate.Change.ContentLedger}
	if err := saveBaseline("alice", *baseline); err != nil {
		t.Fatal(err)
	}
	installation, err := loadOrCreateInstallation()
	if err != nil {
		t.Fatal(err)
	}
	state, err := phase0Import(candidate.Root, installation, baseline, baseline.GenerationToken)
	if err != nil {
		t.Fatal(err)
	}
	const payload = "Author/Book (1)/book.epub"
	writeTestFile(t, candidate.Root, payload, "changed")
	state, err = phase0Rebuild(state, candidate.Root, installation.SeatID, nil)
	if err != nil || !reflect.DeepEqual(state.Pending, []string{payload}) {
		t.Fatalf("pending edit: %+v %v", state, err)
	}
	before := state
	withLocalCommandRemote(t, remoteRoot)
	command := &LibUploadCmd{GroupLib: GroupLib{GroupLibDir: GroupLibDir{CalibreDirectory: candidate.Root}, IndexPath: filepath.Join(candidate.Root, "static/library_index"), LibraryID: libraryID}}
	command.ActionAlias = "alice"
	if err := command.runDerivedRepair([]string{"static/library_index.zst", "static/library_index.jsonl.zst"}); err != nil {
		t.Fatal(err)
	}
	to, err := readLocalGenerationHex(remoteRoot)
	if err != nil || to == state.CoverageToken {
		t.Fatalf("repair did not advance: %s %v", to, err)
	}
	bytesAfter, err := os.ReadFile(filepath.Join(remoteRoot, filepath.FromSlash(payload)))
	if err != nil || string(bytesAfter) != "payload" {
		t.Fatalf("derived repair touched payload: %q %v", bytesAfter, err)
	}
	if phase0CheckPublish(state, to) == nil {
		t.Fatal("observation alone advanced coverage")
	}
	// Test-only application of the locally executed/verified A->B repair.
	// Production must persist this relationship with the exact transaction;
	// a no-transfer sync observation cannot call this a derived repair.
	state.CoverageToken, state.ObservedToken = to, to
	if err := phase0CheckPublish(state, to); err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(state.Pending, before.Pending) || !reflect.DeepEqual(state.Inventory, before.Inventory) {
		t.Fatal("repair discarded pending payload evidence")
	}
}
