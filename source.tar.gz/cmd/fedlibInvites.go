package cmd

import (
	"accorder/pkg/fedlibinvite"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"text/tabwriter"
	"time"
)

type FedlibInvitesCmd struct {
	List   FedlibInvitesListCmd   `cmd:"" help:"List unclaimed invite offers for a serve alias." json:"list"`
	Revoke FedlibInvitesRevokeCmd `cmd:"" help:"Revoke (delete) unclaimed invite offers for a prefix." json:"revoke"`
}

func inviteOffersDir(serveAlias string) string {
	return filepath.Join(accorderConfigDir, "clearnet", serveAlias, "invites")
}

type FedlibInvitesListCmd struct {
	FedlibID string `arg:"" name:"fedlib-id" help:"Federation identifier (see 'fedlib config set')."`
}

func (c *FedlibInvitesListCmd) Run() error {
	if _, err := requireFedlibDescriptor("fedlib invites list", c.FedlibID); err != nil {
		return err
	}
	dir := inviteOffersDir(c.FedlibID)
	if removed, err := fedlibinvite.SweepExpired(dir); err == nil && removed > 0 {
		fmt.Fprintf(os.Stderr, "fedlib invites: swept %d expired offer(s)\n", removed)
	}
	offers, err := fedlibinvite.ListOffers(dir)
	if err != nil {
		return fmt.Errorf("fedlib invites list: %w", err)
	}
	if len(offers) == 0 {
		fmt.Fprintf(os.Stderr, "fedlib invites: no unclaimed offers in %s\n", dir)
		return nil
	}

	sorted := make([]*fedlibinvite.Offer, 0, len(offers))
	for _, o := range offers {
		sorted = append(sorted, o)
	}
	sort.Slice(sorted, func(i, j int) bool { return sorted[i].Created.Before(sorted[j].Created) })

	w := tabwriter.NewWriter(os.Stderr, 2, 4, 2, ' ', 0)
	fmt.Fprintln(w, "PREFIX\tDISPLAY NAME\tCREATED\tEXPIRES")
	for _, o := range sorted {
		fmt.Fprintf(w, "%s\t%s\t%s\t%s\n",
			o.Prefix, o.DisplayName,
			o.Created.Format(time.RFC3339), o.Expires.Format(time.RFC3339))
	}
	return w.Flush()
}

type FedlibInvitesRevokeCmd struct {
	FedlibID string `arg:"" name:"fedlib-id" help:"Federation identifier (see 'fedlib config set')."`
	Prefix   string `arg:"" help:"Member prefix whose unclaimed offers to revoke." validate:"required"`
}

func (c *FedlibInvitesRevokeCmd) Run() error {
	if _, err := requireFedlibDescriptor("fedlib invites revoke", c.FedlibID); err != nil {
		return err
	}
	dir := inviteOffersDir(c.FedlibID)
	if removed, err := fedlibinvite.SweepExpired(dir); err == nil && removed > 0 {
		fmt.Fprintf(os.Stderr, "fedlib invites: swept %d expired offer(s)\n", removed)
	}
	offers, err := fedlibinvite.ListOffers(dir)
	if err != nil {
		return fmt.Errorf("fedlib invites revoke: %w", err)
	}
	revoked := 0
	for name, o := range offers {
		if o.Prefix != c.Prefix {
			continue
		}
		if err := os.Remove(filepath.Join(dir, name)); err != nil {
			return fmt.Errorf("fedlib invites revoke: %w", err)
		}
		revoked++
	}
	if revoked == 0 {
		fmt.Fprintf(os.Stderr, "fedlib invites: no unclaimed offers for prefix %q in %s\n", c.Prefix, dir)
		return nil
	}
	fmt.Fprintf(os.Stderr, "fedlib invites: revoked %d offer(s) for prefix %q\n", revoked, c.Prefix)
	return nil
}
