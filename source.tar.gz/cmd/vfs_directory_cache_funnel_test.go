//go:build tailscale

package cmd

import "testing"

func TestFunnelDirectoryCacheTimeDefaultAndPropagation(t *testing.T) {
	testSetup(t)
	cli, _ := parseCLI(t, []string{
		"fedlib", "share", "funnel", "motw",
		"--tailscale-auth-key", "tskey-test",
		"--subdomain", "motw-test",
		"--aggregate-path", t.TempDir(),
		"--bucket", "test-bucket",
		"--s3-access-key", "access",
		"--s3-secret-key", "secret",
		"--s3-provider", "Wasabi",
		"--s3-endpoint", "https://s3.example.test",
	})
	cmd := &cli.Fedlib.Share.Funnel
	if cmd.DirCacheTime != "24h" {
		t.Fatalf("DirCacheTime = %q, want default 24h", cmd.DirCacheTime)
	}
	if got := cmd.aggregateServeParams().DirCacheTime; got != "24h" {
		t.Fatalf("AggregateServeParams.DirCacheTime = %q, want 24h", got)
	}
}
