//go:build !tailscale && !tor

package cmd

// ===========================================================================
// Phase 0 spike: effective-config-provenance (ca-120)
// (.sit/workflows/2026-08-18_effective-config-provenance/study.md, Phase 7)
//
// Resolves the two assumptions the study left unvalidated, before the
// renderer is designed around them.
// ===========================================================================

import (
	"reflect"
	"testing"
)

// Assumption 1: a reflect.Value-identity map keyed on kong Value.Target
// resolves struct field -> CLI flag name through embedded (anonymous)
// structs, so the renderer never has to guess names.
//
// VALIDATED (spike run 2026-08-18): all 25 flag-backed fields of
// LibUploadCmd resolve, including two levels deep
// (GroupLib.GroupLibDir.CalibreDirectory -> --calibrepath).
//
// It also establishes the corollary that shapes the design: fields kong
// does not own resolve to NOTHING. That silently suppresses the
// kong:"-" plumbing the study wants gone (TeaOutputs.Header,
// ExcludeGlobs) — but it would equally suppress FedlibShareLiveCmd's
// descriptor-backed Bucket/UploadPrefix/S3Provider/S3Endpoint/KeysFile,
// which are the fields Finding 4 most needs shown. Flagless-but-renderable
// fields therefore need an explicit registry; they cannot fall out of the
// flag walk.
func TestSpike_TargetIdentityResolvesThroughEmbedding(t *testing.T) {
	testSetup(t)
	_, ctx := parseCLI(t, []string{"lib", "upload", "p",
		"--calibrepath", t.TempDir(),
		"--bucket", "b/p",
		"--s3-access-key", "AK", "--s3-secret-key", "SK",
		"--s3-provider", "Wasabi", "--s3-endpoint", "https://e",
	})
	sel := ctx.Selected()

	byAddr := map[uintptr]string{}
	for _, f := range sel.Flags {
		if f.Value == nil || !f.Value.Target.IsValid() || !f.Value.Target.CanAddr() {
			continue
		}
		byAddr[f.Value.Target.Addr().Pointer()] = f.Name
	}

	resolved := map[string]string{}
	unresolved := map[string]string{}
	var walk func(v reflect.Value, path string)
	walk = func(v reflect.Value, path string) {
		tp := v.Type()
		for i := 0; i < tp.NumField(); i++ {
			fv, ft := v.Field(i), tp.Field(i)
			if ft.Anonymous && fv.Kind() == reflect.Struct {
				walk(fv, path+ft.Name+".")
				continue
			}
			if !fv.CanAddr() {
				continue
			}
			if name, ok := byAddr[fv.Addr().Pointer()]; ok {
				resolved[path+ft.Name] = name
			} else {
				unresolved[path+ft.Name] = ft.Tag.Get("kong")
			}
		}
	}
	walk(sel.Target, "")

	// The load-bearing claim: embedding is transparent.
	for field, wantFlag := range map[string]string{
		"GroupLib.GroupLibDir.CalibreDirectory": "calibrepath",
		"GroupS3Credentials.S3SecretKey":        "s3-secret-key",
		"CommonCommandFields.ShowConfig":        "show-config",
		"Passphrase":                            "passphrase",
	} {
		if got := resolved[field]; got != wantFlag {
			t.Errorf("field %s resolved to --%s, want --%s", field, got, wantFlag)
		}
	}

	// The corollary: kong:"-" fields resolve to nothing, by design.
	for _, field := range []string{"TeaOutputs.Header", "TeaOutputs.InPipeline", "ExcludeGlobs"} {
		if flag, ok := resolved[field]; ok {
			t.Errorf("kong:\"-\" field %s unexpectedly resolved to --%s", field, flag)
		}
		if _, ok := unresolved[field]; !ok {
			t.Errorf("kong:\"-\" field %s missing from the walk entirely", field)
		}
	}

	// The positional alias is not a flag; the renderer must source it separately.
	if flag, ok := resolved["CommonCommandFields.ActionAlias"]; ok {
		t.Errorf("positional ActionAlias unexpectedly resolved to --%s", flag)
	}
}

// Assumption 2: env-tag-sourced values bypass ctx.Path, so origin "env"
// cannot be distinguished from "default" by the mechanism the alias-save
// path uses (getProvidedFlagNames, cmd/cli.go:63).
//
// CONFIRMED (spike run 2026-08-18): `secrets rekey --passphrase` reads
// ACCORDER_SECRETS_PASSPHRASE, the value lands on the struct, and the flag
// is absent from getProvidedFlagNames. kong exposes Flag.Envs, so the
// renderer must consult it plus os.LookupEnv to report origin "env" rather
// than mislabelling an env-sourced credential as a default.
func TestSpike_EnvSourcedValueIsInvisibleToCtxPath(t *testing.T) {
	testSetup(t)
	t.Setenv("ACCORDER_SECRETS_PASSPHRASE", "from-env")

	cli, ctx := parseCLI(t, []string{"secrets", "rekey", "--to-key-file"})

	if got := cli.Secrets.Rekey.Passphrase; got != "from-env" {
		t.Fatalf("env value did not reach the struct: got %q", got)
	}
	if _, inPath := getProvidedFlagNames(ctx)["passphrase"]; inPath {
		t.Fatal("REFUTED: env-sourced flag appears in ctx.Path — the renderer needs no Envs lookup")
	}

	var sawEnvTag bool
	for _, f := range ctx.Selected().Flags {
		if f.Name != "passphrase" {
			continue
		}
		for _, e := range f.Envs {
			if e == "ACCORDER_SECRETS_PASSPHRASE" {
				sawEnvTag = true
			}
		}
	}
	if !sawEnvTag {
		t.Error("kong Flag.Envs did not expose ACCORDER_SECRETS_PASSPHRASE — no recovery path for origin \"env\"")
	}
}

// Assumption 3 (Finding 4, structural half): FedlibShareLiveCmd's
// descriptor-backed fields are kong:"-" and therefore absent from the flag
// set entirely — the operator cannot learn which bucket the serve reads
// from any flag-derived view.
//
// CONFIRMED (spike run 2026-08-18): the node exposes 24 flags, none named
// bucket/upload-prefix/s3-provider/s3-endpoint/keys-file.
func TestSpike_ServeDescriptorFieldsAbsentFromFlagSet(t *testing.T) {
	testSetup(t)
	// ca-125: live serve validates descriptor existence at parse time.
	if err := saveFedlibDescriptor("f", fedlibDescriptor{Version: fedlibDescriptorVersion}); err != nil {
		t.Fatal(err)
	}
	_, ctx := parseCLI(t, []string{"fedlib", "share", "live", "f",
		"--aggregate-path", "/agg", "--mode", "public"})

	flags := map[string]bool{}
	for _, f := range ctx.Selected().Flags {
		flags[f.Name] = true
	}
	for _, name := range []string{"bucket", "upload-prefix", "s3-provider", "s3-endpoint", "keys-file"} {
		if flags[name] {
			t.Errorf("--%s IS a flag on fedlib share live — Finding 4's premise is wrong", name)
		}
	}
	if _, ok := flags["mode"]; !ok {
		t.Error("--mode missing from the flag set; the Mode divergence claim needs re-checking")
	}
}
