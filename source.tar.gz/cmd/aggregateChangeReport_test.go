package cmd

import (
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"testing"

	"accorder/pkg/calibre"
)

func TestBoundChildMemberChangeResultKeepsEarlierExactScope(t *testing.T) {
	result := memberChangeResult{
		Version: memberChangeResultVersion, LibraryUUID: "00000000-0000-4000-8000-000000000101", Prefix: "a",
		PreviousGeneration:     transitionGenerationHex(testAggregateGenerationToken(t, 1)),
		IncorporatedGeneration: transitionGenerationHex(testAggregateGenerationToken(t, 2)),
		Scope:                  calibre.GenerationChangeScopeExact,
		BooksDirectories:       make([]string, aggregateChangeMaxMemberDirs/2),
		AssetsDirectories:      make([]string, aggregateChangeMaxMemberDirs/2),
	}
	bounded, total := boundChildMemberChangeResult(result, 0)
	if bounded.Scope != calibre.GenerationChangeScopeExact || total != aggregateChangeMaxMemberDirs {
		t.Fatalf("first result=%+v total=%d", bounded, total)
	}
	result.Prefix = "b"
	result.LibraryUUID = "00000000-0000-4000-8000-000000000102"
	bounded, nextTotal := boundChildMemberChangeResult(result, total)
	if bounded.Scope != calibre.GenerationChangeScopeExact || nextTotal != aggregateChangeMaxTotalDirs {
		t.Fatalf("second result=%+v total=%d", bounded, nextTotal)
	}
	result.Prefix = "c"
	result.LibraryUUID = "00000000-0000-4000-8000-000000000103"
	result.BooksDirectories = []string{"c/book"}
	result.AssetsDirectories = nil
	bounded, nextTotal = boundChildMemberChangeResult(result, nextTotal)
	if bounded.Scope != calibre.GenerationChangeScopeCoarse || bounded.Reason != "cumulative-directory-limit" || nextTotal != total*2 {
		t.Fatalf("third result=%+v total=%d", bounded, nextTotal)
	}
}

func TestReadAggregateChangeScopeRejectsOversizedReport(t *testing.T) {
	dir := t.TempDir()
	if err := os.MkdirAll(filepath.Dir(aggregateChangeReportFile(dir)), 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(aggregateChangeReportFile(dir), make([]byte, aggregateChangeMaxReportBytes+1), 0o600); err != nil {
		t.Fatal(err)
	}
	_, _, err := readAggregateChangeScope(dir, testAggregateGenerationToken(t, 9), []observedMemberTransition{{
		LibraryUUID:        "00000000-0000-4000-8000-000000000101",
		PreviousGeneration: transitionGenerationHex(testAggregateGenerationToken(t, 1)),
		ObservedGeneration: transitionGenerationHex(testAggregateGenerationToken(t, 2)),
	}})
	if !errors.Is(err, errBoundedFileTooLarge) {
		t.Fatalf("oversized report error=%v", err)
	}
}

func TestReadAggregateChangeScopeCombinesExactAndMemberFallback(t *testing.T) {
	dir := t.TempDir()
	token := testAggregateGenerationToken(t, 9)
	previousA := transitionGenerationHex(testAggregateGenerationToken(t, 1))
	previousB := transitionGenerationHex(testAggregateGenerationToken(t, 2))
	incorporatedA := transitionGenerationHex(testAggregateGenerationToken(t, 3))
	incorporatedB := transitionGenerationHex(testAggregateGenerationToken(t, 4))
	uuidA := "00000000-0000-4000-8000-000000000101"
	uuidB := "00000000-0000-4000-8000-000000000102"
	report := aggregateChangeReport{
		Version: aggregateChangeReportVersion, AggregateGeneration: transitionGenerationHex(token),
		Members: []memberChangeResult{
			{
				Version: memberChangeResultVersion, LibraryUUID: uuidA, Prefix: "a", PreviousGeneration: previousA,
				IncorporatedGeneration: incorporatedA, Scope: calibre.GenerationChangeScopeExact,
				BooksDirectories: []string{"a/Author/Book"}, AssetsDirectories: []string{"a/Author/Book", "a/static"},
			},
			coarseMemberChangeResult("b", uuidB, previousB, incorporatedB, "manifest-missing"),
		},
	}
	if err := writeJSONAtomic(aggregateChangeReportFile(dir), report); err != nil {
		t.Fatal(err)
	}
	scope, incorporated, err := readAggregateChangeScope(dir, token, []observedMemberTransition{
		{LibraryUUID: uuidA, PreviousGeneration: previousA, ObservedGeneration: incorporatedA},
		{LibraryUUID: uuidB, PreviousGeneration: previousB, ObservedGeneration: incorporatedB},
	})
	if err != nil {
		t.Fatal(err)
	}
	if got := transitionGenerationHex(incorporated["a"]); got != incorporatedA {
		t.Fatalf("incorporated a=%s, want %s", got, incorporatedA)
	}
	if got := transitionGenerationHex(incorporated["b"]); got != incorporatedB {
		t.Fatalf("incorporated b=%s, want %s", got, incorporatedB)
	}
	if scope.full || !reflect.DeepEqual(scope.prefixes, []string{"b"}) {
		t.Fatalf("scope = %+v", scope)
	}
	if got := scope.directories("books"); !reflect.DeepEqual(got, []string{"a/Author/Book", "b"}) {
		t.Fatalf("books directories = %v", got)
	}
	if got := scope.directories("assets"); !reflect.DeepEqual(got, []string{"a/Author/Book", "a/static", "b"}) {
		t.Fatalf("assets directories = %v", got)
	}
}

func TestReadAggregateChangeScopeRejectsWrongAggregateToken(t *testing.T) {
	dir := t.TempDir()
	token := testAggregateGenerationToken(t, 9)
	if err := writeJSONAtomic(aggregateChangeReportFile(dir), aggregateChangeReport{
		Version: aggregateChangeReportVersion, AggregateGeneration: transitionGenerationHex(token), Members: []memberChangeResult{},
	}); err != nil {
		t.Fatal(err)
	}
	if _, _, err := readAggregateChangeScope(dir, testAggregateGenerationToken(t, 10), []observedMemberTransition{{
		LibraryUUID:        "00000000-0000-4000-8000-000000000101",
		PreviousGeneration: transitionGenerationHex(testAggregateGenerationToken(t, 1)),
		ObservedGeneration: transitionGenerationHex(testAggregateGenerationToken(t, 2)),
	}}); err == nil {
		t.Fatal("wrong aggregate token was accepted")
	}
}

func TestReadAggregateChangeScopeKeepsEarlierExactMembersAtCumulativeLimit(t *testing.T) {
	dir := t.TempDir()
	token := testAggregateGenerationToken(t, 20)
	report := aggregateChangeReport{
		Version: aggregateChangeReportVersion, AggregateGeneration: transitionGenerationHex(token),
	}
	var transitions []observedMemberTransition
	for memberIndex, prefix := range []string{"a", "b", "c"} {
		uuid := fmt.Sprintf("00000000-0000-4000-8000-%012d", memberIndex+1)
		previous := transitionGenerationHex(testAggregateGenerationToken(t, uint64(memberIndex+1)))
		incorporated := transitionGenerationHex(testAggregateGenerationToken(t, uint64(memberIndex+10)))
		directories := make([]string, 6999)
		for i := range directories {
			directories[i] = fmt.Sprintf("%s/books/%05d", prefix, i)
		}
		report.Members = append(report.Members, memberChangeResult{
			Version: memberChangeResultVersion, LibraryUUID: uuid, Prefix: prefix,
			PreviousGeneration: previous, IncorporatedGeneration: incorporated,
			Scope: calibre.GenerationChangeScopeExact, BooksDirectories: directories,
			AssetsDirectories: []string{prefix + "/static"},
		})
		transitions = append(transitions, observedMemberTransition{
			LibraryUUID: uuid, PreviousGeneration: previous, ObservedGeneration: incorporated,
		})
	}
	if err := writeJSONAtomic(aggregateChangeReportFile(dir), report); err != nil {
		t.Fatal(err)
	}
	scope, _, err := readAggregateChangeScope(dir, token, transitions)
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(scope.prefixes, []string{"c"}) {
		t.Fatalf("prefix fallbacks = %v, want only the member crossing the cumulative limit", scope.prefixes)
	}
	if len(scope.books) != 2*6999 || len(scope.assets) != 2 {
		t.Fatalf("retained exact scope books=%d assets=%d", len(scope.books), len(scope.assets))
	}
}
