package cmd

import (
	"bytes"
	"os"
	"path/filepath"
	"sync"
	"sync/atomic"
	"testing"
)

func TestSpikeGenerationChangeImmutableCreate(t *testing.T) {
	for _, test := range []struct {
		name        string
		payloadFor  func(int) []byte
		wantPayload func([]byte) bool
	}{
		{
			name:       "identical writers converge",
			payloadFor: func(int) []byte { return []byte("same manifest\n") },
			wantPayload: func(got []byte) bool {
				return bytes.Equal(got, []byte("same manifest\n"))
			},
		},
		{
			name:       "conflicting writers choose one immutable winner",
			payloadFor: func(i int) []byte { return []byte{byte('a' + i), '\n'} },
			wantPayload: func(got []byte) bool {
				return len(got) == 2 && got[0] >= 'a' && got[0] < 'q' && got[1] == '\n'
			},
		},
	} {
		t.Run(test.name, func(t *testing.T) {
			root := t.TempDir()
			remote := &libraryRemote{fsPath: root}
			const writers = 16
			var created atomic.Int32
			var wg sync.WaitGroup
			errs := make(chan error, writers)
			for i := 0; i < writers; i++ {
				wg.Add(1)
				go func(i int) {
					defer wg.Done()
					won, err := remote.createImmutable(".accorder/changes/target.manifest.json", test.payloadFor(i))
					if err != nil {
						errs <- err
						return
					}
					if won {
						created.Add(1)
					}
				}(i)
			}
			wg.Wait()
			close(errs)
			for err := range errs {
				t.Error(err)
			}
			if got := created.Load(); got != 1 {
				t.Fatalf("successful creates=%d, want exactly 1", got)
			}
			data, err := os.ReadFile(filepath.Join(root, ".accorder", "changes", "target.manifest.json"))
			if err != nil {
				t.Fatal(err)
			}
			if !test.wantPayload(data) {
				t.Fatalf("stored payload=%q", data)
			}
			won, err := remote.createImmutable(".accorder/changes/target.manifest.json", []byte("replacement\n"))
			if err != nil {
				t.Fatal(err)
			}
			if won {
				t.Fatal("replacement unexpectedly won after immutable object existed")
			}
			after, err := os.ReadFile(filepath.Join(root, ".accorder", "changes", "target.manifest.json"))
			if err != nil {
				t.Fatal(err)
			}
			if !bytes.Equal(after, data) {
				t.Fatalf("immutable object changed: %q -> %q", data, after)
			}
		})
	}
}

func TestGenerationChangeImmutableRejectsUnsupportedRemote(t *testing.T) {
	for _, remote := range []string{"", "unsupported:bucket/prefix"} {
		if _, err := (&libraryRemote{fsPath: remote}).createImmutable("manifest", []byte("data")); err == nil {
			t.Fatalf("unsupported remote %q accepted", remote)
		}
	}
}
