package cmd

import (
	"fmt"
	"log"
	"os"
	"sync"
)

var aliasConfigMu sync.Mutex

func aliasConfigLockPath() string { return savedActionAliases + ".lock" }

func lockAliasConfig() (release func(), err error) {
	aliasConfigMu.Lock()
	assertNotRealConfig(aliasConfigLockPath())
	// Every mutation acquires this lock first, so this is the one place
	// that needs to guarantee the config directory exists. Read-only runs
	// skip the lock entirely and therefore create nothing.
	if err := ensureConfigDir(savedActionAliases); err != nil {
		aliasConfigMu.Unlock()
		return nil, fmt.Errorf("alias config lock: %w", err)
	}
	f, err := os.OpenFile(aliasConfigLockPath(), os.O_CREATE|os.O_RDONLY, 0o600)
	if err != nil {
		aliasConfigMu.Unlock()
		return nil, fmt.Errorf("alias config lock: %w", err)
	}
	rel, err := lockFileExclusive(f)
	if err != nil {
		f.Close()
		aliasConfigMu.Unlock()
		return nil, fmt.Errorf("alias config lock: %w", err)
	}
	return func() {
		rel()
		f.Close()
		aliasConfigMu.Unlock()
	}, nil
}

func lockAliasConfigOrDie() (release func()) {
	release, err := lockAliasConfig()
	if err != nil {
		log.Fatalln(err)
	}
	return release
}

func withAliasConfigLock(fn func() error) error {
	release, err := lockAliasConfig()
	if err != nil {
		return err
	}
	defer release()
	return fn()
}

func trySaveActionAliasesDurable(content []byte) error {
	assertNotRealConfig(savedActionAliases)
	return writeFileDurable(savedActionAliases, content, 0o644)
}
