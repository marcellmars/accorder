package cmd

import (
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"strings"

	"accorder/pkg/calibre"

	"github.com/tidwall/gjson"
)

const (
	motwLibrariesFile      = "motw_libraries.json"
	aggregateLibrariesFile = "aggregate_libraries.json"
)

type companionRegistry struct {
	file      string
	valueType reflect.Type
}

func companionRegistries() []companionRegistry {
	return []companionRegistry{
		{file: motwLibrariesFile, valueType: reflect.TypeOf(calibre.MotwLibrary{})},
		{file: aggregateLibrariesFile, valueType: reflect.TypeOf(calibre.LibraryMeta{})},
	}
}

var secretBearingKeys = map[string]bool{"secret": true}

func liveJSONTags(t reflect.Type) map[string]bool {
	live := make(map[string]bool, t.NumField())
	for i := 0; i < t.NumField(); i++ {
		tag := t.Field(i).Tag.Get("json")
		if tag == "" || tag == "-" {
			continue
		}
		if comma := strings.IndexByte(tag, ','); comma >= 0 {
			tag = tag[:comma]
		}
		if tag != "" {
			live[tag] = true
		}
	}
	return live
}

func redactForeignValue(key, val string) string {
	if secretBearingKeys[key] {
		return fmt.Sprintf("<redacted secret, %d bytes>", len(val))
	}
	return fmt.Sprintf("<redacted, %d bytes>", len(val))
}

func loadCompanionRegistry(path string) ([]byte, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, fmt.Errorf("reading companion registry %s: %w", filepath.Base(path), err)
	}
	if !gjson.ValidBytes(data) {
		return nil, fmt.Errorf("companion registry %s: invalid JSON syntax", filepath.Base(path))
	}
	if !gjson.ParseBytes(data).IsObject() {
		return nil, fmt.Errorf("companion registry %s: top-level value is not a JSON object", filepath.Base(path))
	}
	return data, nil
}

func scanCompanionRot(file string, data []byte, valueType reflect.Type) []rotFinding {
	if len(data) == 0 {
		return nil
	}
	live := liveJSONTags(valueType)
	var findings []rotFinding
	gjson.ParseBytes(data).ForEach(func(entry, fields gjson.Result) bool {
		if !fields.IsObject() {
			findings = append(findings, rotFinding{
				File:   file,
				Alias:  entry.String(),
				Kind:   rotCorruptEntry,
				Reason: fmt.Sprintf("expected object value, got %s", fields.Type.String()),
			})
			return true
		}
		fields.ForEach(func(k, v gjson.Result) bool {
			key := k.String()
			if live[key] {
				return true
			}
			reason := fmt.Sprintf("no such field on %s", valueType.Name())
			if secretBearingKeys[key] {
				reason = fmt.Sprintf("secret-bearing key with no reader on %s", valueType.Name())
			}
			findings = append(findings, rotFinding{
				File:   file,
				Alias:  entry.String(),
				Path:   key,
				Kind:   rotForeignKey,
				Value:  redactForeignValue(key, v.String()),
				Reason: reason,
			})
			return true
		})
		return true
	})
	return findings
}

func scanAllCompanionRot(configDir string) ([]rotFinding, error) {
	var findings []rotFinding
	for _, reg := range companionRegistries() {
		data, err := loadCompanionRegistry(filepath.Join(configDir, reg.file))
		if err != nil {
			return nil, err
		}
		findings = append(findings, scanCompanionRot(reg.file, data, reg.valueType)...)
	}
	return findings, nil
}
