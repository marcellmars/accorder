package cmd

import "testing"

func TestCacheRemoteMutatingActionIsExact(t *testing.T) {
	tests := map[string]bool{
		"fedlib.share.live":         true,
		"fedlib.share.funnel":       true,
		"lib.share.live":            true,
		"fedlib.service.install":    true,
		"fedlib.share.grant":        false,
		"fedlib.share.revoke-grant": false,
		"fedlib.share.list-grants":  false,
		"fedlib.share.reset-grants": false,
		"lib.share.grant":           false,
		"lib.share.revoke-grant":    false,
		"lib.share.list-grants":     false,
		"lib.share.reset-grants":    false,
		"lib.share.funnel":          false,
		"fedlib.service.show":       false,
		"fedlib.build":              false,
		"lib.search":                false,
	}
	for actionPath, want := range tests {
		t.Run(actionPath, func(t *testing.T) {
			if got := cacheRemoteMutatingAction(actionPath); got != want {
				t.Fatalf("cacheRemoteMutatingAction(%q) = %v, want %v", actionPath, got, want)
			}
		})
	}
}

func TestAliasCollisionDoesNotBlockAccessControlOrServiceInspection(t *testing.T) {
	for _, args := range [][]string{
		{"fedlib", "share", "revoke-grant", "x", "--friend", "Reader"},
		{"fedlib", "share", "reset-grants", "x"},
		{"lib", "share", "revoke-grant", "x", "--friend", "Reader"},
		{"lib", "share", "reset-grants", "x"},
		{"fedlib", "service", "show", "x"},
	} {
		t.Run(args[0]+"/"+args[1]+"/"+args[2], func(t *testing.T) {
			testSetup(t)
			seedAliasNames(t, "x", "x-assets")
			if _, _, err := parseCLIErr(t, args); err != nil {
				t.Fatalf("parse %v with a pre-existing cache collision: %v", args, err)
			}
		})
	}
}
