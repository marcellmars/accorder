package cmd

import (
	"errors"
	"net"
	"testing"
)

// fixedAddrs installs a deterministic interface set for the duration of a test.
func fixedAddrs(t *testing.T, cidrs ...string) {
	t.Helper()
	var addrs []net.Addr
	for _, c := range cidrs {
		ip, ipNet, err := net.ParseCIDR(c)
		if err != nil {
			t.Fatalf("bad test CIDR %q: %v", c, err)
		}
		ipNet.IP = ip
		addrs = append(addrs, ipNet)
	}
	prev := interfaceAddrsFn
	interfaceAddrsFn = func() ([]net.Addr, error) { return addrs, nil }
	t.Cleanup(func() { interfaceAddrsFn = prev })
}

func TestHintHost_ExplicitHostsPassThrough(t *testing.T) {

	// An operator who named an address must get it back byte-for-byte.
	fixedAddrs(t, "192.168.1.24/24")

	for _, tc := range []struct {
		name, listen, want string
	}{
		{"lan ipv4", "192.168.1.24:8900", "192.168.1.24:8900"},
		{"public ipv4", "203.0.113.7:8900", "203.0.113.7:8900"},
		{"hostname", "example.local:8900", "example.local:8900"},
		{"ipv6", "[2001:db8::1]:8900", "[2001:db8::1]:8900"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			got, reachable, loop := hintHost(tc.listen)
			if got != tc.want {
				t.Errorf("host = %q, want %q", got, tc.want)
			}
			if !reachable {
				t.Errorf("explicit host should be reachable=true")
			}
			if loop {
				t.Errorf("explicit non-loopback host should not report boundLoopback")
			}
		})
	}
}

func TestHintHost_LoopbackIsFlaggedNotSubstituted(t *testing.T) {

	// Loopback must never be silently rewritten to a LAN address: the operator
	// asked for a private share. Callers suppress the pasteable command instead.
	fixedAddrs(t, "192.168.1.24/24")

	for _, tc := range []struct{ name, listen, want string }{
		{"ipv4", "127.0.0.1:8900", "127.0.0.1:8900"},
		{"ipv6", "[::1]:8900", "[::1]:8900"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			got, reachable, loop := hintHost(tc.listen)
			if got != tc.want {
				t.Errorf("host = %q, want %q (loopback must not be substituted)", got, tc.want)
			}
			if reachable {
				t.Errorf("loopback must not be reported reachable")
			}
			if !loop {
				t.Errorf("loopback must set boundLoopback")
			}
		})
	}
}

func TestHintHost_UnspecifiedSubstitutesLANAddress(t *testing.T) {
	fixedAddrs(t, "127.0.0.1/8", "192.168.1.24/24")

	for _, tc := range []struct{ name, listen, want string }{
		{"ipv4 wildcard", "0.0.0.0:8900", "192.168.1.24:8900"},
		{"ipv6 wildcard", "[::]:8900", "192.168.1.24:8900"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			got, reachable, loop := hintHost(tc.listen)
			if got != tc.want {
				t.Errorf("host = %q, want %q", got, tc.want)
			}

			// Enumeration cannot prove peer reachability — the caller must
			// still print the substitute-the-host note.
			if reachable {
				t.Errorf("a substituted address must report reachable=false")
			}
			if loop {
				t.Errorf("wildcard bind is not a loopback bind")
			}
		})
	}
}

func TestHintHost_ContainerAddressStillWarns(t *testing.T) {

	// A container's private IP is indistinguishable from a LAN IP here, and is
	// usually NOT reachable by the friend. Substituting it is fine; claiming it
	// is reachable is not.
	fixedAddrs(t, "127.0.0.1/8", "172.17.0.2/16")

	got, reachable, _ := hintHost("0.0.0.0:8900")
	if got != "172.17.0.2:8900" {
		t.Errorf("host = %q, want the only non-loopback address", got)
	}
	if reachable {
		t.Errorf("container-style address must still report reachable=false so the substitute-host note prints")
	}
}

func TestHintHost_SkipsLinkLocalPrefersIPv4(t *testing.T) {

	// Link-local needs a zone id the friend cannot use; IPv4 wins over IPv6.
	fixedAddrs(t, "169.254.10.1/16", "fe80::1/64", "2001:db8::5/64", "10.0.0.9/8")

	got, _, _ := hintHost("0.0.0.0:8900")
	if got != "10.0.0.9:8900" {
		t.Errorf("host = %q, want the routable IPv4 (link-local skipped, IPv4 preferred)", got)
	}
}

func TestHintHost_IPv6OnlyHostIsBracketed(t *testing.T) {
	fixedAddrs(t, "127.0.0.1/8", "2001:db8::5/64")

	got, _, _ := hintHost("[::]:8900")
	if got != "[2001:db8::5]:8900" {
		t.Errorf("host = %q, want a bracketed IPv6 host:port", got)
	}
}

func TestHintHost_NoCandidateKeepsLiteral(t *testing.T) {
	// Loopback-only machine: nothing to substitute, so don't invent one.
	fixedAddrs(t, "127.0.0.1/8")

	got, reachable, loop := hintHost("0.0.0.0:8900")
	if got != "0.0.0.0:8900" {
		t.Errorf("host = %q, want the literal listen address when no candidate exists", got)
	}
	if reachable || loop {
		t.Errorf("no-candidate case: reachable=%v loop=%v, want false/false", reachable, loop)
	}
}

func TestHintHost_EnumerationErrorKeepsLiteral(t *testing.T) {
	prev := interfaceAddrsFn
	interfaceAddrsFn = func() ([]net.Addr, error) { return nil, errors.New("no interfaces") }
	t.Cleanup(func() { interfaceAddrsFn = prev })

	got, reachable, _ := hintHost("0.0.0.0:8900")
	if got != "0.0.0.0:8900" {
		t.Errorf("host = %q, want the literal address when enumeration fails", got)
	}
	if reachable {
		t.Errorf("enumeration failure must not report reachable")
	}
}

func TestHintHost_MalformedListenPassesThrough(t *testing.T) {
	got, reachable, loop := hintHost("not-a-host-port")
	if got != "not-a-host-port" {
		t.Errorf("host = %q, want the input unchanged", got)
	}
	if reachable || loop {
		t.Errorf("malformed input: reachable=%v loop=%v, want false/false", reachable, loop)
	}
}
