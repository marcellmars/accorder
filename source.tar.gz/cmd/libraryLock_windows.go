//go:build windows

package cmd

import (
	"errors"
	"os"

	"golang.org/x/sys/windows"
)

// tryLibraryLockExclusive gives the library workflow the same cross-process
// exclusion guarantee on Windows that flock provides on Unix. Keep this
// separate from the cache-reclaim lock: reclaim has a broader, deliberately
// fail-closed Windows policy that is independent of library publishing.
func tryLibraryLockExclusive(f *os.File) (release func(), ok bool, err error) {
	overlapped := &windows.Overlapped{}
	err = windows.LockFileEx(
		windows.Handle(f.Fd()),
		windows.LOCKFILE_EXCLUSIVE_LOCK|windows.LOCKFILE_FAIL_IMMEDIATELY,
		0,
		^uint32(0),
		^uint32(0),
		overlapped,
	)
	if errors.Is(err, windows.ERROR_LOCK_VIOLATION) {
		return nil, false, nil
	}
	if err != nil {
		return nil, false, err
	}
	return func() {
		_ = windows.UnlockFileEx(
			windows.Handle(f.Fd()),
			0,
			^uint32(0),
			^uint32(0),
			overlapped,
		)
	}, true, nil
}
