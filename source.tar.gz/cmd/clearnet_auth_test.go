package cmd

import (
	"accorder/pkg/torinvite"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestGrantRegistry_IssueValidateRevoke(t *testing.T) {
	dir := t.TempDir()
	reg, err := newGrantRegistry(dir)
	if err != nil {
		t.Fatal(err)
	}

	token, err := reg.issue("alice", nil)
	if err != nil {
		t.Fatal(err)
	}

	// Validate active grant
	friend, ok := reg.validate(token)
	if !ok || friend != "alice" {
		t.Fatalf("expected alice, got %q ok=%v", friend, ok)
	}

	// Revoke and verify
	if err := reg.revoke("alice"); err != nil {
		t.Fatal(err)
	}
	if _, ok := reg.validate(token); ok {
		t.Fatal("expected revoked token to fail validation")
	}
}

func TestGrantRegistry_CorruptGrantsJSON(t *testing.T) {
	dir := t.TempDir()
	if err := os.WriteFile(filepath.Join(dir, "grants.json"), []byte("{bad json"), 0600); err != nil {
		t.Fatal(err)
	}
	key := make([]byte, 32)
	if err := os.WriteFile(filepath.Join(dir, "signing.key"), key, 0600); err != nil {
		t.Fatal(err)
	}
	_, err := newGrantRegistry(dir)
	if err == nil {
		t.Fatal("expected error for corrupt grants.json")
	}
}

func TestGrantRegistry_WrongLengthKey(t *testing.T) {
	dir := t.TempDir()
	if err := os.WriteFile(filepath.Join(dir, "signing.key"), []byte("short"), 0600); err != nil {
		t.Fatal(err)
	}
	_, err := newGrantRegistry(dir)
	if err == nil {
		t.Fatal("expected error for wrong-length signing key")
	}
}

func TestGrantRegistry_Persistence(t *testing.T) {
	dir := t.TempDir()
	reg1, err := newGrantRegistry(dir)
	if err != nil {
		t.Fatal(err)
	}
	token, err := reg1.issue("bob", nil)
	if err != nil {
		t.Fatal(err)
	}

	// Load from disk
	reg2, err := newGrantRegistry(dir)
	if err != nil {
		t.Fatal(err)
	}
	friend, ok := reg2.validate(token)
	if !ok || friend != "bob" {
		t.Fatalf("persistence failed: got %q ok=%v", friend, ok)
	}
}

func TestWithAuth_BearerToken(t *testing.T) {
	dir := t.TempDir()
	reg, err := newGrantRegistry(dir)
	if err != nil {
		t.Fatal(err)
	}
	token, err := reg.issue("alice", nil)
	if err != nil {
		t.Fatal(err)
	}

	handler := withAuth(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	}), reg)

	// Valid bearer
	req := httptest.NewRequest("GET", "/files/foo/bar.epub", nil)
	req.Header.Set("Authorization", "Bearer "+token)
	w := httptest.NewRecorder()
	handler.ServeHTTP(w, req)
	if w.Code != 200 {
		t.Fatalf("expected 200, got %d", w.Code)
	}

	// No auth → 401
	req2 := httptest.NewRequest("GET", "/files/foo/bar.epub", nil)
	w2 := httptest.NewRecorder()
	handler.ServeHTTP(w2, req2)
	if w2.Code != 401 {
		t.Fatalf("expected 401, got %d", w2.Code)
	}
}

func TestWithAuth_SignedCookie(t *testing.T) {
	dir := t.TempDir()
	reg, err := newGrantRegistry(dir)
	if err != nil {
		t.Fatal(err)
	}
	token, err := reg.issue("alice", nil)
	if err != nil {
		t.Fatal(err)
	}

	// Redeem token → get cookie
	redeemHandler := makeRedeemHandler(reg)
	req := httptest.NewRequest("GET", "/redeem?token="+token, nil)
	w := httptest.NewRecorder()
	redeemHandler.ServeHTTP(w, req)
	if w.Code != 200 {
		t.Fatalf("redeem: expected 200, got %d", w.Code)
	}
	cookies := w.Result().Cookies()
	if len(cookies) == 0 {
		t.Fatal("redeem: no Set-Cookie")
	}

	// Use the cookie on /files/
	handler := withAuth(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	}), reg)
	req2 := httptest.NewRequest("GET", "/files/foo/bar.epub", nil)
	req2.AddCookie(cookies[0])
	w2 := httptest.NewRecorder()
	handler.ServeHTTP(w2, req2)
	if w2.Code != 200 {
		t.Fatalf("cookie auth: expected 200, got %d", w2.Code)
	}

	// Revoke alice → cookie MUST fail (token-bound revocation)
	if err := reg.revoke("alice"); err != nil {
		t.Fatal(err)
	}
	req3 := httptest.NewRequest("GET", "/files/foo/bar.epub", nil)
	req3.AddCookie(cookies[0])
	w3 := httptest.NewRecorder()
	handler.ServeHTTP(w3, req3)
	if w3.Code != 401 {
		t.Fatalf("revoked cookie: expected 401, got %d", w3.Code)
	}
}

func TestWithAuth_GrantIDContext(t *testing.T) {
	dir := t.TempDir()
	reg, err := newGrantRegistry(dir)
	if err != nil {
		t.Fatal(err)
	}
	token, err := reg.issue("alice", nil)
	if err != nil {
		t.Fatal(err)
	}

	var capturedGrantID string
	inner := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if gid, ok := r.Context().Value(grantIDKey).(string); ok {
			capturedGrantID = gid
		}
		w.WriteHeader(http.StatusOK)
	})
	handler := withAuth(inner, reg)

	// Bearer auth → context should carry "alice"
	req := httptest.NewRequest("GET", "/files/foo/bar.epub", nil)
	req.Header.Set("Authorization", "Bearer "+token)
	w := httptest.NewRecorder()
	handler.ServeHTTP(w, req)
	if capturedGrantID != "alice" {
		t.Fatalf("expected grantIDKey='alice', got %q", capturedGrantID)
	}

	// No auth → 401, grantIDKey never set
	capturedGrantID = ""
	req2 := httptest.NewRequest("GET", "/files/foo/bar.epub", nil)
	w2 := httptest.NewRecorder()
	handler.ServeHTTP(w2, req2)
	if capturedGrantID != "" {
		t.Fatalf("unauthenticated request should not set grantIDKey, got %q", capturedGrantID)
	}

	// Client-supplied header is ignored (context set by code, not headers)
	capturedGrantID = ""
	req3 := httptest.NewRequest("GET", "/files/foo/bar.epub", nil)
	req3.Header.Set("X-Accorder-Grant-ID", "spoofed-identity")
	w3 := httptest.NewRecorder()
	handler.ServeHTTP(w3, req3)
	if w3.Code != 401 {
		t.Fatalf("spoofed header: expected 401, got %d", w3.Code)
	}
	if capturedGrantID != "" {
		t.Fatalf("spoofed header should not set grantIDKey, got %q", capturedGrantID)
	}
}

func TestWithAuth_EPIdentityHandoff(t *testing.T) {
	dir := t.TempDir()
	reg, err := newGrantRegistry(dir)
	if err != nil {
		t.Fatal(err)
	}
	token, err := reg.issue("alice", nil)
	if err != nil {
		t.Fatal(err)
	}

	meter := &sessionMeter{
		window:      time.Hour,
		granularity: time.Minute,
		maxSessions: 100,
		maxDistinct: 50,
	}
	breaker, _ := newEgressBreaker(egressBreakerConfig{})
	inner := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	// Compose: request → withAuth → withEndpointProtection → inner
	handler := withAuth(
		withEndpointProtection(inner, meter, breaker),
		reg,
	)

	// Authenticated request: EP should record session as "grant:alice"
	req := httptest.NewRequest("GET", "/files/foo/bar.epub", nil)
	req.Header.Set("Authorization", "Bearer "+token)
	w := httptest.NewRecorder()
	handler.ServeHTTP(w, req)
	if w.Code != 200 {
		t.Fatalf("expected 200, got %d", w.Code)
	}

	// Verify the meter has a "grant:alice" session, NOT an ep_sid session
	grantSID := "grant:alice"
	if _, ok := meter.sessions.Load(grantSID); !ok {
		t.Fatalf("meter should have session %q from grant identity", grantSID)
	}

	// Verify no ep_sid cookie was set (auth identity takes precedence)
	for _, cookie := range w.Result().Cookies() {
		if cookie.Name == "ep_sid" {
			t.Fatalf("ep_sid cookie should not be set when grant identity is present")
		}
	}
}

func TestLibBrowseCmd_ClearnetInviteParsing(t *testing.T) {
	token := "test-token-xyz"
	blob := torinvite.EncodeV2Clearnet("http://localhost:8723/", "testlib", "aggregator", token)

	inv, err := torinvite.Decode(blob)
	if err != nil {
		t.Fatalf("decode invite: %v", err)
	}
	if inv.Endpoint == "" {
		t.Fatal("expected clearnet endpoint in invite")
	}

	// Verify RedeemURL construction (matches cmd/libBrowseCmd.go plumbing)
	expectedRedeem := inv.Endpoint + "redeem?token=" + inv.Auth.Token
	if !strings.Contains(expectedRedeem, token) {
		t.Fatalf("RedeemURL should contain token: %q", expectedRedeem)
	}

	// Verify rclone headers format (comma-separated key,value)
	headers := "Authorization,Bearer " + inv.Auth.Token
	if !strings.HasPrefix(headers, "Authorization,Bearer ") {
		t.Fatalf("headers format: %q", headers)
	}
}

func TestWithAuthTag_PublicClassing(t *testing.T) {
	dir := t.TempDir()
	reg, err := newGrantRegistry(dir)
	if err != nil {
		t.Fatal(err)
	}
	token, err := reg.issue("alice", nil)
	if err != nil {
		t.Fatal(err)
	}

	var captured string
	handler := withAuthTag(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		captured, _ = r.Context().Value(grantIDKey).(string)
		w.WriteHeader(http.StatusOK)
	}), reg)

	do := func(t *testing.T, mutate func(*http.Request)) (int, string) {
		t.Helper()
		captured = ""
		req := httptest.NewRequest("GET", "/files/foo/bar.epub", nil)
		if mutate != nil {
			mutate(req)
		}
		w := httptest.NewRecorder()
		handler.ServeHTTP(w, req)
		return w.Code, captured
	}

	t.Run("valid_bearer_tags", func(t *testing.T) {
		code, friend := do(t, func(r *http.Request) {
			r.Header.Set("Authorization", "Bearer "+token)
		})
		if code != 200 || friend != "alice" {
			t.Fatalf("expected 200/alice, got %d/%q", code, friend)
		}
	})

	t.Run("invalid_bearer_serves_anonymously", func(t *testing.T) {
		code, friend := do(t, func(r *http.Request) {
			r.Header.Set("Authorization", "Bearer garbage")
		})
		if code != 200 {
			t.Fatalf("tag-only must never reject: expected 200, got %d", code)
		}
		if friend != "" {
			t.Fatalf("invalid bearer must not tag, got %q", friend)
		}
	})

	t.Run("no_credential_serves_anonymously", func(t *testing.T) {
		code, friend := do(t, nil)
		if code != 200 || friend != "" {
			t.Fatalf("expected 200/anonymous, got %d/%q", code, friend)
		}
	})

	t.Run("signed_cookie_tags", func(t *testing.T) {
		code, friend := do(t, func(r *http.Request) {
			r.AddCookie(&http.Cookie{Name: authCookieName, Value: reg.signCookie(token)})
		})
		if code != 200 || friend != "alice" {
			t.Fatalf("expected 200/alice via cookie, got %d/%q", code, friend)
		}
	})

	t.Run("invalid_cookie_serves_anonymously", func(t *testing.T) {
		code, friend := do(t, func(r *http.Request) {
			r.AddCookie(&http.Cookie{Name: authCookieName, Value: "forged"})
		})
		if code != 200 || friend != "" {
			t.Fatalf("expected 200/anonymous for forged cookie, got %d/%q", code, friend)
		}
	})
}
