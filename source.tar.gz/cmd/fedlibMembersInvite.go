package cmd

import (
	"accorder/pkg/calibre"
	"accorder/pkg/fedlibinvite"
	"context"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/alecthomas/kong"
	uuid "github.com/satori/go.uuid"
)

type FedlibMembersInviteCmd struct {
	FedlibID    string `arg:"" name:"fedlib-id" help:"Federation identifier (see 'fedlib config set')."`
	Label       string `arg:"" optional:"" help:"Label for the invited library (e.g. librarian name). Optional on re-invite (defaults to the registry librarian)."`
	Prefix      string `name:"prefix" help:"S3 prefix for the invited librarian." validate:"required"`
	S3AccessKey string `name:"s3-access-key" help:"Scoped write S3 access key for the librarian." validate:"omitempty" secret:"redact,fingerprint"`
	S3SecretKey string `name:"s3-secret-key" help:"Scoped write S3 secret key for the librarian." validate:"omitempty" secret:"redact,fingerprint"`
	S3Provider  string `name:"s3-provider" help:"S3 provider (remembered per federation id after first use)." validate:"omitempty"`
	S3Endpoint  string `name:"s3-endpoint" help:"S3 endpoint URL (remembered per federation id after first use)." validate:"omitempty"`
	Bucket      string `name:"bucket" help:"S3 bucket name (remembered per federation id after first use)." validate:"omitempty"`
	FedlibPath  string `name:"fedlib-path" help:"Path to the fedlib output directory (uses per-fedlib members.json)."`

	OperatorRootKey      string `name:"operator-root-key" help:"Operator IAM root access key (triggers auto-mint mode)." validate:"omitempty" secret:"redact,fingerprint"`
	OperatorRootSecret   string `name:"operator-root-secret" help:"Operator IAM root secret key." validate:"omitempty" secret:"redact,fingerprint"`
	OperatorRootKeysFile string `name:"operator-root-keys-file" help:"Keys file with operator IAM root keys (access-key=/secret-key= lines; remembered per federation id after first use). Default: operator_root.keys or wasabi_root.keys in the config dir." json:"-" validate:"omitempty"`
	PrintMintCommands    *bool  `name:"print-mint-commands" help:"Print IAM commands for manual minting instead of auto-minting." json:"-"`
	IAMEndpoint          string `name:"iam-endpoint" help:"IAM endpoint URL (remembered per federation id after first use; default: auto-detected from --s3-provider)." validate:"omitempty"`

	Offer       bool   `name:"offer" help:"Seal the invite into a claim-once offer served by 'fedlib share live' and print its URL instead of the blob."`
	Endpoint    string `name:"endpoint" help:"Public https:// base URL of the aggregate serve (required with --offer)." validate:"omitempty,url"`
	OfferExpiry string `name:"offer-expiry" help:"Offer lifetime (e.g. 72h, 168h; default 168h, remembered per federation id after first use)."`
}

func (c *FedlibMembersInviteCmd) resolveIAMEndpoint() string {
	if c.IAMEndpoint != "" {
		return c.IAMEndpoint
	}
	switch c.S3Provider {
	case "Wasabi":
		return "https://iam.wasabisys.com"
	default:
		return "https://iam.amazonaws.com"
	}
}

func validateAliasSafePrefix(prefix string) error {
	if strings.HasPrefix(prefix, "-") {
		return fmt.Errorf("fedlib members invite: prefix %q must not start with '-' (it doubles as the member's alias)", prefix)
	}
	for _, r := range prefix {
		isLetter := (r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z')
		isDigit := r >= '0' && r <= '9'
		if !isLetter && !isDigit && r != '-' {
			return fmt.Errorf("fedlib members invite: prefix %q contains %q — allowed: letters, digits, '-' (the prefix doubles as the member's alias and `lib publish` argument)",
				prefix, string(r))
		}
	}
	return nil
}

func memberJoinHint(blob, prefix string) string {
	return joinHint(blob, prefix, true)
}

func memberJoinHintURL(claimURL, prefix string) string {
	return joinHint(claimURL, prefix, false)
}

// joinCommandLine renders the exact `lib join` invocation an operator hands to
// a librarian. Every hint site renders through this one function: when the
// alias moved from a `--alias` flag to a positional argument, four separate
// call sites in three files kept printing the old form, so operators were
// handed a command the parser rejects. One renderer means a grammar change
// breaks one place, and the test below parses what it emits.
// It prints the long --invite rather than -I so the command an operator pastes
// matches the one the walkthrough teaches. Both parse; only one is
// self-explanatory in a message read while recovering from a refusal.
func joinCommandLine(prefix, invite, tail string) string {
	line := fmt.Sprintf("accorder lib join %s --invite '%s'", prefix, invite)
	if tail != "" {
		line += " " + tail
	}
	return line
}

func joinHint(arg, prefix string, includeExport bool) string {
	var b strings.Builder
	sep := "~ ~ ~ ~\n"
	b.WriteString(sep)
	if includeExport {
		b.WriteString("On the machine holding the Calibre library — full setup (fill in the passphrase and -c):\n\n")
		b.WriteString("  export ACCORDER_SECRETS_PASSPHRASE=…\n")
	} else {
		b.WriteString("On the machine holding the Calibre library — full setup (fill in -c):\n\n")
	}
	fmt.Fprintf(&b, "  %s\n\n", joinCommandLine(prefix, arg, "-c /path/to/calibre/library"))
	b.WriteString("Afterwards, to publish updates (cron-able, headless):\n\n")
	fmt.Fprintf(&b, "  accorder lib publish %s\n", prefix)
	b.WriteString(sep)
	return b.String()
}

func resolveOperatorRootKeys(explicitPath string) (key, secret, src string, err error) {
	candidates := []string{explicitPath}
	if explicitPath == "" {
		candidates = []string{
			filepath.Join(accorderConfigDir, "operator_root.keys"),
			filepath.Join(accorderConfigDir, "wasabi_root.keys"),
		}
	}
	for _, p := range candidates {
		kf, perr := parseKeysFile(p)
		if perr != nil || kf.AccessKey == "" || kf.SecretKey == "" {
			if explicitPath != "" {
				return "", "", "", fmt.Errorf("--operator-root-keys-file %s: missing or incomplete (need access-key= and secret-key= lines)", p)
			}
			continue
		}
		return kf.AccessKey, kf.SecretKey, p, nil
	}
	return "", "", "", nil
}

// Run accepts the Kong context so recalled descriptor values can be
// re-validated with the CLI's own spelling (ca-127); direct unit callers
// pass nil and names fall back to the struct's tags.
func (c *FedlibMembersInviteCmd) Run(kctx *kong.Context) error {
	if err := validateAliasSafePrefix(c.Prefix); err != nil {
		return err
	}

	if c.Offer {
		if _, err := requireFedlibDescriptor("fedlib members invite", c.FedlibID); err != nil {
			return err
		}
	}

	desc := loadFedlibDescriptor(c.FedlibID)
	recalled := false
	for _, f := range []struct {
		flag  *string
		saved *string
	}{
		{&c.Bucket, &desc.Bucket},
		{&c.S3Provider, &desc.S3Provider},
		{&c.S3Endpoint, &desc.S3Endpoint},
		{&c.Endpoint, &desc.Endpoint},
		{&c.OfferExpiry, &desc.OfferExpiry},
		{&c.OperatorRootKeysFile, &desc.RootKeysFile},
		{&c.IAMEndpoint, &desc.IAMEndpoint},
		{&c.FedlibPath, &desc.FedlibPath},
	} {
		if *f.flag == "" && *f.saved != "" {
			*f.flag = *f.saved
			recalled = true
		}
		*f.saved = *f.flag
	}
	if recalled {
		fmt.Fprintf(os.Stderr, "fedlib members invite: defaults for fedlib %q recalled from %s\n", c.FedlibID, fedlibDescriptorPath())
	}
	for flag, val := range map[string]string{
		"--bucket": c.Bucket, "--s3-provider": c.S3Provider, "--s3-endpoint": c.S3Endpoint,
	} {
		if val == "" {
			return fmt.Errorf("fedlib members invite: %s is required (no saved defaults for fedlib %q yet — provide it once and it is remembered)", flag, c.FedlibID)
		}
	}
	// ca-127: values recalled from the descriptor must satisfy the same
	// validator contract as typed flags — before the descriptor is saved
	// or used downstream, so an invalid recall leaves fedlibs.json
	// byte-identical.
	var selected *kong.Node
	if kctx != nil {
		selected = kctx.Selected()
	}
	if err := validateSelectedTarget(selected, c, "fedlib members invite", ""); err != nil {
		return err
	}

	desc.Version = fedlibDescriptorVersion
	if err := saveFedlibDescriptor(c.FedlibID, desc); err != nil {
		fmt.Fprintf(os.Stderr, "fedlib members invite: WARNING: %v\n", err)
	}

	var offerTTL time.Duration
	if c.Offer {
		if c.Endpoint == "" {
			return fmt.Errorf("fedlib members invite: --offer requires --endpoint (or set it in the descriptor via 'fedlib config set %s --endpoint ...')", c.FedlibID)
		}
		if !strings.HasPrefix(c.Endpoint, "https://") {
			return fmt.Errorf("fedlib members invite: --endpoint must be https:// (got %q)", c.Endpoint)
		}
		expiry := c.OfferExpiry
		if expiry == "" {
			expiry = "168h"
		}
		var err error
		offerTTL, err = time.ParseDuration(expiry)
		if err != nil {
			return fmt.Errorf("fedlib members invite: --offer-expiry: %w", err)
		}
		if offerTTL <= 0 {
			return fmt.Errorf("fedlib members invite: --offer-expiry must be positive (got %s)", expiry)
		}
	}

	if c.OperatorRootKey == "" && c.S3AccessKey == "" {
		key, secret, src, err := resolveOperatorRootKeys(c.OperatorRootKeysFile)
		if err != nil {
			return fmt.Errorf("fedlib members invite: %w", err)
		}
		if key != "" {
			c.OperatorRootKey, c.OperatorRootSecret = key, secret
			fmt.Fprintf(os.Stderr, "fedlib members invite: operator root keys loaded from %s\n", src)
		}
	}

	isAutoMint := c.OperatorRootKey != "" && c.OperatorRootSecret != ""
	isAssist := c.PrintMintCommands != nil && *c.PrintMintCommands

	if isAssist {
		printMintCommands(c.Prefix, c.Bucket, c.resolveIAMEndpoint())
		return nil
	}

	if isAutoMint {
		iamEP := c.resolveIAMEndpoint()
		result, err := mintScopedCredentials(context.Background(),
			c.OperatorRootKey, c.OperatorRootSecret, iamEP, c.Prefix, c.Bucket)
		if err != nil {
			return fmt.Errorf("fedlib members invite: mint scoped credentials: %w", err)
		}
		c.S3AccessKey = result.AccessKey
		c.S3SecretKey = result.SecretKey
		fmt.Fprintf(os.Stderr, "fedlib members invite: minted scoped key for %s\n", result.Username)
	}

	if c.S3AccessKey == "" || c.S3SecretKey == "" {
		return fmt.Errorf("fedlib members invite: --s3-access-key and --s3-secret-key are required " +
			"(provide them directly, or use --operator-root-key/--operator-root-secret for auto-mint, " +
			"or --print-mint-commands for manual minting instructions)")
	}

	registryPath := resolveMembersRegistryPath(c.FedlibPath)
	registry, registryPath, err := loadMembersRegistryFromPath(registryPath)
	if err != nil {
		return err
	}

	var reinviteID string
	var legacyPlaceholderKey string
	for key, existing := range registry {
		if existing.Prefix != c.Prefix {
			if c.Label != "" && existing.Librarian == c.Label {
				fmt.Fprintf(os.Stderr, "fedlib members invite: WARNING: label %q matches existing member %s — consider a distinct name\n",
					c.Label, key)
			}
			continue
		}
		if strings.HasPrefix(key, "invited:") {
			legacyPlaceholderKey = key
			if c.Label == "" {
				c.Label = existing.Librarian
			}
			continue
		}
		reinviteID = key
		if c.Label == "" {
			c.Label = existing.Librarian
		} else if c.Label != existing.Librarian {
			fmt.Fprintf(os.Stderr, "fedlib members invite: WARNING: label %q differs from registry librarian %q for %s\n",
				c.Label, existing.Librarian, c.Prefix)
		}
		fmt.Fprintf(os.Stderr, "fedlib members invite: re-inviting existing member %q (libraryID %s, librarian %q)\n",
			c.Prefix, key, existing.Librarian)
		break
	}

	if c.Label == "" {
		return fmt.Errorf("fedlib members invite: <label> is required when inviting a new member (prefix %q has no registry entry to take a librarian name from)", c.Prefix)
	}

	if reinviteID == "" && legacyPlaceholderKey != "" {
		fmt.Fprintf(os.Stderr, "fedlib members invite: re-issuing invite for pending member %q (migrating legacy placeholder)\n", c.Prefix)
	}

	memberID := reinviteID
	if memberID == "" {
		memberID = uuid.NewV4().String()
	}

	var memberDictID uint32
	registryDirty := false
	if legacyPlaceholderKey != "" {
		delete(registry, legacyPlaceholderKey)
		registryDirty = true
	}
	if reinviteID == "" {
		librarian := resolveMemberLibrarian(c.Label, memberID, registry)

		id, allocErr := allocateMemberDictID(c.FedlibID)
		if allocErr != nil {
			return fmt.Errorf("fedlib members invite: %w (invite aborted to prevent duplicate DictID assignment)", allocErr)
		}
		memberDictID = id

		registry[memberID] = calibre.LibraryMeta{
			Librarian: librarian,
			Prefix:    c.Prefix,
			State:     "invited",
			DictID:    memberDictID,
		}
		registryDirty = true
	} else {
		existing, ok := registry[reinviteID]
		if ok {
			memberDictID = existing.DictID
		}
		if memberDictID < 2 {
			id, allocErr := allocateMemberDictID(c.FedlibID)
			if allocErr != nil {
				return fmt.Errorf("fedlib members invite: %w (invite aborted to prevent duplicate DictID assignment)", allocErr)
			}
			memberDictID = id
			if ok {
				existing.DictID = memberDictID
				registry[reinviteID] = existing
				registryDirty = true
			}
		}
	}
	if registryDirty {
		if err := saveMembersRegistry(registryPath, registry); err != nil {
			return err
		}
	}

	inv := &fedlibinvite.WriteInvite{
		FedlibID: c.FedlibID,
		Backend:  "s3",
		RemoteConfig: map[string]string{
			"provider": c.S3Provider,
			"endpoint": c.S3Endpoint,
			"bucket":   c.Bucket,
		},
		Prefix:    c.Prefix,
		AccessKey: c.S3AccessKey,
		SecretKey: c.S3SecretKey,
		Label:     c.Label,
		LibraryID: memberID,
		DictID:    memberDictID,
	}

	blob := fedlibinvite.EncodeWriteInvite(inv)

	if reinviteID != "" {
		fmt.Fprintf(os.Stderr, "fedlib members: re-invited %q (prefix: %s, libraryID: %s)\n", c.Label, c.Prefix, reinviteID)
	} else {
		fmt.Fprintf(os.Stderr, "fedlib members: invited %q (prefix: %s, libraryID: %s, state: invited)\n", c.Label, c.Prefix, memberID)
	}

	if c.Offer {
		token, err := fedlibinvite.NewOfferToken()
		if err != nil {
			return fmt.Errorf("fedlib members invite: %w", err)
		}
		expires := time.Now().Add(offerTTL)
		offer, err := fedlibinvite.SealOffer(token, blob, c.Prefix, c.Label, expires)
		if err != nil {
			return fmt.Errorf("fedlib members invite: %w", err)
		}
		dir := inviteOffersDir(c.FedlibID)
		if err := fedlibinvite.WriteOffer(dir, token, offer); err != nil {
			return fmt.Errorf("fedlib members invite: %w", err)
		}
		if _, err := fedlibinvite.SweepExpired(dir); err != nil {
			fmt.Fprintf(os.Stderr, "fedlib members invite: sweep expired offers: %v\n", err)
		}
		claimURL := strings.TrimRight(c.Endpoint, "/") + "/invite/" + token
		fmt.Fprintln(os.Stdout, claimURL)
		fmt.Fprintf(os.Stderr, "fedlib members invite: offer for %q expires %s (sealed in %s)\n",
			c.Prefix, expires.Format(time.RFC3339), dir)
		fmt.Fprint(os.Stderr, memberJoinHintURL(claimURL, c.Prefix))
		return nil
	}

	fmt.Fprintln(os.Stdout, blob)
	fmt.Fprint(os.Stderr, memberJoinHint(blob, c.Prefix))
	return nil
}
