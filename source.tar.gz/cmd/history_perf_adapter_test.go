//go:build linux && !tailscale

package cmd

import "fmt"

const historicalUploadAdapter = "prepareUploadCandidate"

func historicalPrepareUpload(build *LibBuildCmd) error {
	upload := &LibUploadCmd{GroupLib: build.GroupLib}
	upload.ActionAlias = build.ActionAlias
	candidate, _, err := upload.prepareUploadCandidate(nil, resolveUploadExcludes(build.CalibreDirectory, nil))
	if err != nil {
		return err
	}
	if candidate == nil || candidate.Change == nil {
		return fmt.Errorf("missing current build candidate")
	}
	return nil
}
