package cmd

import (
	"reflect"
	"testing"
)

func TestPrivateDirsFromExcludes(t *testing.T) {
	// the manifest file rule alone → no dirs to purge
	if d := privateDirsFromExcludes([]string{"/.motw-upload-excludes"}); len(d) != 0 {
		t.Fatalf("manifest-only must yield no purge dirs, got %v", d)
	}
	// private dir globs → stripped to dirs; the manifest rule is skipped
	got := privateDirsFromExcludes([]string{
		"/Author/Title (3)/**",
		"/.motw-upload-excludes",
		"/Other/Book (7)/**",
	})
	want := []string{"Author/Title (3)", "Other/Book (7)"}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("got %v, want %v", got, want)
	}
	if d := privateDirsFromExcludes(nil); len(d) != 0 {
		t.Fatalf("empty must yield no dirs, got %v", d)
	}
}

func TestCurrentUploadExcludesDoesNotRetainPersistedPrivacy(t *testing.T) {
	root := t.TempDir()
	if err := writeUploadExcludes(root, []string{"/Formerly/Private (1)/**"}); err != nil {
		t.Fatal(err)
	}
	if got := resolveUploadExcludes(root, nil); !reflect.DeepEqual(got, []string{"/Formerly/Private (1)/**", "/.motw-upload-excludes"}) {
		t.Fatalf("persisted excludes = %v", got)
	}
	if got := currentUploadExcludes(nil); !reflect.DeepEqual(got, []string{"/.motw-upload-excludes"}) {
		t.Fatalf("current build excludes retained previous privacy = %v", got)
	}
}
