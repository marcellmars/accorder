package cmd

import (
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sort"

	"accorder/pkg/calibre"
)

const (
	aggregateChangeReportVersion  = 1
	aggregateChangeReportPath     = ".accorder/change-report.json"
	aggregateChangeMaxMemberDirs  = 10_000
	aggregateChangeMaxTotalDirs   = 20_000
	aggregateChangeMaxReportBytes = 8 << 20
)

type aggregateChangeReport struct {
	Version             int                  `json:"version"`
	AggregateGeneration string               `json:"aggregate_generation"`
	Members             []memberChangeResult `json:"members"`
}

func aggregateChangeReportFile(outputPath string) string {
	return filepath.Join(outputPath, filepath.FromSlash(aggregateChangeReportPath))
}

func writeAggregateChangeReport(outputPath string, registry map[string]calibre.LibraryMeta, transitions []observedMemberTransition) error {
	if len(transitions) == 0 {
		return removeStateFile(aggregateChangeReportFile(outputPath))
	}
	token, err := readAggregateGenerationToken(outputPath)
	if err != nil {
		return err
	}
	report := aggregateChangeReport{
		Version: aggregateChangeReportVersion, AggregateGeneration: transitionGenerationHex(token),
		Members: make([]memberChangeResult, 0, len(transitions)),
	}
	totalDirs := 0
	for _, transition := range transitions {
		meta, ok := registry[transition.LibraryUUID]
		if !ok || !isMemberActive(meta.State) {
			return fmt.Errorf("aggregate change report: inactive member %s", transition.LibraryUUID)
		}
		result, err := readMemberChangeResult(filepath.Join(outputPath, "libs", meta.Prefix))
		if err != nil {
			return fmt.Errorf("aggregate change report: member %s: %w", transition.LibraryUUID, err)
		}
		if result.LibraryUUID != transition.LibraryUUID || result.Prefix != meta.Prefix || result.PreviousGeneration != transition.PreviousGeneration {
			return fmt.Errorf("aggregate change report: member %s result is stale", transition.LibraryUUID)
		}
		result, totalDirs = boundChildMemberChangeResult(result, totalDirs)
		report.Members = append(report.Members, result)
	}
	sort.Slice(report.Members, func(i, j int) bool { return report.Members[i].LibraryUUID < report.Members[j].LibraryUUID })
	data, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		return fmt.Errorf("aggregate change report: marshal: %w", err)
	}
	if len(data) > aggregateChangeMaxReportBytes {
		return fmt.Errorf("aggregate change report: %d bytes exceeds limit %d", len(data), aggregateChangeMaxReportBytes)
	}
	if err := writeJSONAtomic(aggregateChangeReportFile(outputPath), report); err != nil {
		return err
	}
	exact, coarse, books, assets := 0, 0, 0, 0
	for _, member := range report.Members {
		if member.Scope == calibre.GenerationChangeScopeExact {
			exact++
		} else {
			coarse++
		}
		books += len(member.BooksDirectories)
		assets += len(member.AssetsDirectories)
	}
	fmt.Fprintf(os.Stderr, "aggregate-build: cache refresh plan for %d changed %s: %d targeted, %d whole-library; %d book %s and %d asset %s\n",
		len(report.Members), plural(len(report.Members), "member", "members"), exact, coarse,
		books, plural(books, "directory", "directories"), assets, plural(assets, "directory", "directories"))
	return nil
}

// withinDirectoryBudget applies the two Phase-0 directory ceilings a member's
// exact scope must respect: its own directory count, then the running
// cumulative total across every member processed so far in this build/report.
// It is the single place both the report writer (boundChildMemberChangeResult)
// and the report reader (readAggregateChangeScope) enforce these limits, so
// the two can never drift apart.
func withinDirectoryBudget(memberDirs, totalDirs int) (ok bool, reason string) {
	if memberDirs > aggregateChangeMaxMemberDirs {
		return false, "member-directory-limit"
	}
	if totalDirs+memberDirs > aggregateChangeMaxTotalDirs {
		return false, "cumulative-directory-limit"
	}
	return true, ""
}

func boundChildMemberChangeResult(result memberChangeResult, totalDirs int) (memberChangeResult, int) {
	if result.Scope != calibre.GenerationChangeScopeExact {
		return result, totalDirs
	}
	memberDirs := len(result.BooksDirectories) + len(result.AssetsDirectories)
	if ok, reason := withinDirectoryBudget(memberDirs, totalDirs); !ok {
		return coarseMemberChangeResult(result.Prefix, result.LibraryUUID, result.PreviousGeneration, result.IncorporatedGeneration, reason), totalDirs
	}
	return result, totalDirs + memberDirs
}

func readAggregateChangeScope(outputPath string, token aggregateGenerationToken, transitions []observedMemberTransition) (aggregateInvalidationScope, map[string]aggregateGenerationToken, error) {
	if len(transitions) == 0 {
		return fullAggregateInvalidation(), nil, errors.New("aggregate change report: no exact member transitions")
	}
	data, err := readFileBounded(aggregateChangeReportFile(outputPath), aggregateChangeMaxReportBytes)
	if err != nil {
		return aggregateInvalidationScope{}, nil, err
	}
	var report aggregateChangeReport
	if err := json.Unmarshal(data, &report); err != nil {
		return aggregateInvalidationScope{}, nil, err
	}
	if report.Version != aggregateChangeReportVersion || report.AggregateGeneration != hex.EncodeToString(token[:]) || len(report.Members) != len(transitions) {
		return aggregateInvalidationScope{}, nil, errors.New("aggregate change report: identity mismatch")
	}
	expected := make(map[string]observedMemberTransition, len(transitions))
	for _, transition := range transitions {
		expected[transition.LibraryUUID] = transition
	}
	scope := aggregateInvalidationScope{}
	incorporated := make(map[string]aggregateGenerationToken, len(report.Members))
	totalDirs := 0
	for _, member := range report.Members {
		if err := validateMemberChangeResult(member); err != nil {
			return aggregateInvalidationScope{}, nil, fmt.Errorf("aggregate change report: invalid member result: %w", err)
		}
		transition, ok := expected[member.LibraryUUID]
		if !ok || member.PreviousGeneration != transition.PreviousGeneration || member.IncorporatedGeneration == "" || member.Prefix == "" {
			return aggregateInvalidationScope{}, nil, errors.New("aggregate change report: stale member result")
		}
		incorporatedToken, err := decodeGenerationHex(member.IncorporatedGeneration)
		if err != nil {
			return aggregateInvalidationScope{}, nil, fmt.Errorf("aggregate change report: incorporated generation: %w", err)
		}
		incorporated[member.Prefix] = incorporatedToken
		delete(expected, member.LibraryUUID)
		if member.Scope == calibre.GenerationChangeScopeExact {
			memberDirs := len(member.BooksDirectories) + len(member.AssetsDirectories)
			if ok, reason := withinDirectoryBudget(memberDirs, totalDirs); !ok {
				fmt.Fprintf(os.Stderr, "fedlib share live: targeted cache refresh exceeds the safe directory limit; refreshing the whole member library (member directories: %d, already queued: %d; diagnostic: %s)\n",
					memberDirs, totalDirs, reason)
				scope = scope.merge(memberAggregateInvalidation(member.Prefix))
				continue
			}
			totalDirs += memberDirs
			scope = scope.merge(exactAggregateInvalidation(member.BooksDirectories, member.AssetsDirectories))
		} else {
			fmt.Fprintf(os.Stderr, "fedlib share live: exact changed-book list unavailable; refreshing the whole member library (diagnostic: %s)\n", member.Reason)
			scope = scope.merge(memberAggregateInvalidation(member.Prefix))
		}
	}
	if len(expected) != 0 {
		return aggregateInvalidationScope{}, nil, errors.New("aggregate change report: missing member result")
	}
	return scope, incorporated, nil
}

func clearAggregateChangeReport(outputPath string) {
	if err := os.Remove(aggregateChangeReportFile(outputPath)); err != nil && !os.IsNotExist(err) {
		fmt.Fprintf(os.Stderr, "aggregate-build: clear stale change report: %v\n", err)
	}
}
