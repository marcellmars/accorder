//go:build !tailscale

package cmd

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/alecthomas/kong"
)

// ═══════════════════════════════════════════════════════════════════
// Test: Import command parses with -z and -c (both must be directories)
// ═══════════════════════════════════════════════════════════════════

func TestLibImport_ParsesWithZoteroAndCalibrePaths(t *testing.T) {
	libDir := testSetup(t)

	// Create a separate directory for zotero export path.
	zotDir := filepath.Join(t.TempDir(), "zotero-export")
	_ = os.MkdirAll(zotDir, 0755)

	args := []string{
		"lib", "import", "test-import",
		"-z", zotDir,
		"-c", libDir,
	}
	cli, _ := parseCLI(t, args)

	if cli.Lib.Import.ZoteroPath != zotDir {
		t.Errorf("ZoteroPath = %q, want %q", cli.Lib.Import.ZoteroPath, zotDir)
	}
	if cli.Lib.Import.CalibreDirectory != libDir {
		t.Errorf("CalibreDirectory = %q, want %q", cli.Lib.Import.CalibreDirectory, libDir)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test: --prune and --yes are not persisted in alias config
// ═══════════════════════════════════════════════════════════════════

func TestLibImport_PruneAndYesNotPersisted(t *testing.T) {
	libDir := testSetup(t)

	zotDir := filepath.Join(t.TempDir(), "zotero-export")
	_ = os.MkdirAll(zotDir, 0755)

	args := []string{
		"lib", "import", "prune-test",
		"-z", zotDir,
		"-c", libDir,
		"--prune",
		"--yes",
	}
	parseCLI(t, args)

	// Read the alias config and verify prune/yes are absent.
	alias := readAlias(t, "prune-test")
	imp := alias.Get("lib.import")
	if !imp.Exists() {
		t.Fatal("lib.import not found in alias config")
	}

	// prune and yes should have json:"-" so they must not appear in config.
	raw := imp.Raw
	if strings.Contains(raw, "prune") {
		t.Errorf("prune found in persisted config: %s", raw)
	}
	if strings.Contains(raw, "yes") {
		t.Errorf("yes found in persisted config: %s", raw)
	}

	// But zotero-path and calibrepath should be persisted.
	if imp.Get("zotero-path").String() != zotDir {
		t.Errorf("zotero-path = %q, want %q", imp.Get("zotero-path").String(), zotDir)
	}
	if imp.Get("calibrepath").String() != libDir {
		t.Errorf("calibrepath = %q, want %q", imp.Get("calibrepath").String(), libDir)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test: sharedgroup:"motw" propagation from import to build (calibrepath)
// ═══════════════════════════════════════════════════════════════════

func TestLibImport_SharedGroupPropagation(t *testing.T) {
	libDir := testSetup(t)

	zotDir := filepath.Join(t.TempDir(), "zotero-export")
	_ = os.MkdirAll(zotDir, 0755)

	// Save via lib import — calibrepath should propagate to build/upload peers.
	args := []string{
		"lib", "import", "shared-import",
		"-z", zotDir,
		"-c", libDir,
	}
	parseCLI(t, args)

	alias := readAlias(t, "shared-import")

	// Build should have inherited calibrepath via sharedgroup.
	build := alias.Get("lib.build")
	if !build.Exists() {
		t.Fatal("lib.build not found — sharedgroup lib propagation failed from import")
	}
	if build.Get("calibrepath").String() != libDir {
		t.Errorf("lib.build.calibrepath = %q, want %q", build.Get("calibrepath").String(), libDir)
	}

	// Upload should also have it.
	upload := alias.Get("lib.upload")
	if !upload.Exists() {
		t.Fatal("lib.upload not found — sharedgroup lib propagation failed from import")
	}
	if upload.Get("calibrepath").String() != libDir {
		t.Errorf("lib.upload.calibrepath = %q, want %q", upload.Get("calibrepath").String(), libDir)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test: Validation error on missing -z
// ═══════════════════════════════════════════════════════════════════

func TestLibImport_ValidationErrorMissingZoteroPath(t *testing.T) {
	libDir := testSetup(t)

	cli := &CLI{}
	app, err := kong.New(cli,
		kong.Name("test"),
		kong.Exit(func(int) {}),
		kong.Bind(cli),
	)
	if err != nil {
		t.Fatalf("kong.New: %v", err)
	}

	// Provide only calibrepath, missing zotero-path.
	args := []string{
		"lib", "import", "missing-z",
		"-c", libDir,
	}
	_, err = app.Parse(args)
	if err == nil {
		t.Fatal("expected validation error for missing --zotero-path, got nil")
	}

	errMsg := err.Error()
	if !strings.Contains(errMsg, "zotero-path") && !strings.Contains(errMsg, "missing required") {
		t.Errorf("error should mention zotero-path or missing required, got: %s", errMsg)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test: Alias reuse for import (round-trip persistence)
// ═══════════════════════════════════════════════════════════════════

func TestLibImport_AliasReuse(t *testing.T) {
	libDir := testSetup(t)

	zotDir := filepath.Join(t.TempDir(), "zotero-export")
	_ = os.MkdirAll(zotDir, 0755)

	// First run: save config.
	args := []string{
		"lib", "import", "reuse-test",
		"-z", zotDir,
		"-c", libDir,
	}
	parseCLI(t, args)

	// Second run: alias only.
	cli, _ := parseCLI(t, []string{"lib", "import", "reuse-test"})

	if cli.Lib.Import.ZoteroPath != zotDir {
		t.Errorf("ZoteroPath = %q after alias reuse, want %q", cli.Lib.Import.ZoteroPath, zotDir)
	}
	if cli.Lib.Import.CalibreDirectory != libDir {
		t.Errorf("CalibreDirectory = %q after alias reuse, want %q", cli.Lib.Import.CalibreDirectory, libDir)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test: LibImportCmd JSON round-trip (struct serializes correctly)
// ═══════════════════════════════════════════════════════════════════

func TestLibImport_JSONRoundTrip(t *testing.T) {
	cmd := LibImportCmd{}
	cmd.ZoteroPath = "/tmp/zot"
	cmd.CalibreDirectory = "/tmp/lib"
	cmd.ActionAlias = "test"

	data, err := json.Marshal(cmd)
	if err != nil {
		t.Fatalf("marshal: %v", err)
	}

	// Verify prune and yes are absent (json:"-").
	if strings.Contains(string(data), "prune") {
		t.Errorf("prune should not be serialized: %s", data)
	}
	if strings.Contains(string(data), "yes") {
		t.Errorf("yes should not be serialized: %s", data)
	}

	// Verify expected fields are present.
	if !strings.Contains(string(data), "zotero-path") {
		t.Errorf("zotero-path should be serialized: %s", data)
	}
	if !strings.Contains(string(data), "calibrepath") {
		t.Errorf("calibrepath should be serialized: %s", data)
	}
}
