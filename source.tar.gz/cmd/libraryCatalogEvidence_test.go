//go:build !tailscale

package cmd

import (
	"bytes"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"accorder/pkg/calibre"
)

func TestCatalogManagedRealCalibreCommands(t *testing.T) {
	if os.Getenv("ACCORDER_CALIBRE_ACCEPTANCE") != "1" {
		t.Skip("explicit real-Calibre acceptance; uses only disposable libraries")
	}
	debug, err := exec.LookPath("calibre-debug")
	if err != nil {
		t.Fatal(err)
	}
	root := testSetup(t)
	config := t.TempDir()
	mutate := func(t *testing.T, action string) {
		t.Helper()
		command := exec.Command(debug, "testdata/calibre_managed_changes.py", action)
		command.Env = append(os.Environ(), "CALIBRE_CONFIG_DIRECTORY="+config, "QT_QPA_PLATFORM=offscreen", "ACCORDER_CALIBRE_TEST_LIBRARY="+root, "ACCORDER_CALIBRE_TEST_DISPOSABLE="+root)
		if output, err := command.CombinedOutput(); err != nil {
			t.Fatalf("Calibre %s: %v\n%s", action, err, output)
		}
	}
	mutate(t, "seed")
	remoteRoot := t.TempDir()
	withLocalCommandRemote(t, remoteRoot)
	build := fastBuildCommand(root)
	for _, action := range []string{"seeded", "replace", "cover", "replace-cover", "convert", "rename", "private", "public", "remove-format", "delete"} {
		t.Run(action, func(t *testing.T) {
			if action != "seeded" {
				mutate(t, action)
			}
			if err := build.Run(nil); err != nil {
				t.Fatal(err)
			}
			candidate, err := captureExistingCandidate(root, resolveUploadExcludes(root, nil))
			if err != nil || candidate.Change == nil {
				t.Fatalf("capture=%+v %v", candidate, err)
			}
			if action != "seeded" && (candidate.Change.CompleteOverwrite || len(candidate.Change.Changes) == 0) {
				t.Fatalf("Calibre change was missed or needs a full reupload: %+v", candidate.Change)
			}
			if err := publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: 25}); err != nil {
				t.Fatal(err)
			}
			for _, file := range candidate.Change.Evidence.Catalog.Files {
				local, err := os.ReadFile(filepath.Join(root, file.Path))
				if os.IsNotExist(err) && file.Optional {
					continue
				}
				if err != nil {
					t.Fatal(err)
				}
				remote, err := os.ReadFile(filepath.Join(remoteRoot, file.Path))
				if err != nil || !bytes.Equal(local, remote) {
					t.Fatalf("published bytes differ for %s: %v", file.Path, err)
				}
			}
			if action == "private" || action == "delete" {
				if err := filepath.WalkDir(remoteRoot, func(path string, entry os.DirEntry, err error) error {
					if err == nil && !entry.IsDir() && (strings.HasSuffix(path, ".epub") || strings.HasSuffix(path, ".pdf")) {
						t.Errorf("removed/private payload remains: %s", path)
					}
					return err
				}); err != nil {
					t.Fatal(err)
				}
			}
		})
	}
}

func TestCatalogManagedBuildPublishNoPayloadTraversal(t *testing.T) {
	root := testSetup(t)
	seedPublishCalibreLibrary(t, root)
	fastBuildSQL(t, root, "ALTER TABLE books ADD COLUMN has_cover INTEGER DEFAULT 0")
	remoteRoot := t.TempDir()
	withLocalCommandRemote(t, remoteRoot)
	oldObserver := libraryWorkObserver
	t.Cleanup(func() { libraryWorkObserver = oldObserver })
	var scans int
	libraryWorkObserver = func(stage string, _ time.Duration, _ int) {
		if stage == "inventory" {
			scans++
		}
	}
	build := fastBuildCommand(root)
	for i := 0; i < 2; i++ {
		if err := build.Run(nil); err != nil {
			t.Fatal(err)
		}
	}
	publish := func() {
		t.Helper()
		candidate, err := captureExistingCandidate(root, resolveUploadExcludes(root, nil))
		if err != nil || candidate.Change == nil || !isCatalogEvidence(candidate.Change.Evidence) {
			t.Fatalf("candidate=%+v err=%v", candidate, err)
		}
		if err := publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: 25}); err != nil {
			t.Fatal(err)
		}
	}
	publish()
	// An ordinary same-size replacement through Calibre changes last_modified.
	writeTestFile(t, root, fastBuildPayload, "changed")
	fastBuildSQL(t, root, "UPDATE books SET last_modified='2026-09-07T20:00:00+00:00' WHERE id=1")
	stale, err := captureExistingCandidate(root, resolveUploadExcludes(root, nil))
	if err != nil || stale.Change != nil {
		t.Fatalf("database edit did not stale candidate: %+v %v", stale, err)
	}
	for i := 0; i < 2; i++ {
		if err := build.Run(nil); err != nil {
			t.Fatal(err)
		}
	}
	pending, err := loadLocalChangeCandidate(root)
	if err != nil || pending.CompleteOverwrite || !containsString(pending.ForcePaths, fastBuildPayload) {
		t.Fatalf("lost narrow pending transfer: %+v %v", pending, err)
	}
	publish()
	got, err := os.ReadFile(filepath.Join(remoteRoot, fastBuildPayload))
	if err != nil || string(got) != "changed" {
		t.Fatalf("replacement=%q err=%v", got, err)
	}
	remote := &libraryRemote{fsPath: remoteRoot}
	state := remote.inspect()
	if state.Err != nil || state.Pointer.SourceContract != calibre.CatalogSourceContract {
		t.Fatalf("remote contract did not verify: %+v", state)
	}
	if scans != 0 {
		t.Fatalf("Calibre workflow performed %d whole-tree preflight scans", scans)
	}
}

func TestCatalogManagedEvidenceIgnoresExternalEditButRejectsDatabaseEdit(t *testing.T) {
	root := testSetup(t)
	seedPublishCalibreLibrary(t, root)
	build := fastBuildCommand(root)
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	candidate, err := captureExistingCandidate(root, resolveUploadExcludes(root, nil))
	if err != nil {
		t.Fatal(err)
	}
	writeTestFile(t, root, fastBuildPayload, "outside")
	if err := verifyLocalPublishCandidate(candidate); err != nil {
		t.Fatalf("out-of-contract file-browser edit blocked catalog: %v", err)
	}
	fastBuildSQL(t, root, "UPDATE books SET title='Calibre edit', last_modified='2026-09-07T20:00:00+00:00'")
	if err := verifyLocalPublishCandidate(candidate); err == nil || !strings.Contains(err.Error(), "changed") {
		t.Fatalf("database edit was accepted: %v", err)
	}
}

func TestCatalogManagedInvalidDatabaseCannotFallBackToFileInventory(t *testing.T) {
	root := testSetup(t)
	seedPublishCalibreLibrary(t, root)
	if err := fastBuildCommand(root).Run(nil); err != nil {
		t.Fatal(err)
	}
	candidate, err := captureExistingCandidate(root, resolveUploadExcludes(root, nil))
	if err != nil || candidate.Change == nil {
		t.Fatalf("capture: %v", err)
	}
	writeTestFile(t, root, "metadata.db", "not a database")
	if _, err := inventoryForEvidence(root, candidate.Change.Evidence, candidate.Change.ContentLedger); err == nil {
		t.Fatal("invalid database silently fell back to legacy file observations")
	}
}

func TestCatalogManagedChangedPathValidation(t *testing.T) {
	root := t.TempDir()
	if exists, err := checkCatalogTransferPath(root, "Book/metadata.opf", true); err != nil || exists {
		t.Fatalf("optional absent OPF: %t %v", exists, err)
	}
	if _, err := checkCatalogTransferPath(root, "Book/book.epub", false); err == nil {
		t.Fatal("required missing format was accepted")
	}
	if _, err := checkCatalogTransferPath(root, "../outside.epub", false); err == nil {
		t.Fatal("escaping path was accepted")
	}
	if err := os.Symlink(t.TempDir(), filepath.Join(root, "Book")); err != nil {
		t.Skipf("symlink unavailable: %v", err)
	}
	if _, err := checkCatalogTransferPath(root, "Book/metadata.opf", true); err == nil {
		t.Fatal("optional path may not escape through a symlink")
	}
}

func TestCatalogManagedRemoteReindexPreservesSourceContract(t *testing.T) {
	root := testSetup(t)
	seedPublishCalibreLibrary(t, root)
	bucket := t.TempDir()
	remoteRoot := filepath.Join(bucket, "alice")
	if err := os.MkdirAll(remoteRoot, 0700); err != nil {
		t.Fatal(err)
	}
	withLocalCommandRemote(t, remoteRoot)
	if err := fastBuildCommand(root).Run(nil); err != nil {
		t.Fatal(err)
	}
	candidate, err := captureExistingCandidate(root, resolveUploadExcludes(root, nil))
	if err != nil {
		t.Fatal(err)
	}
	if err := publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: 25}); err != nil {
		t.Fatal(err)
	}
	remote := &libraryRemote{fsPath: remoteRoot}
	before := remote.commitState()
	if err := (&FedlibMembersReindexCmd{}).rebuildRemoteMember("alice", 42, bucket); err != nil {
		t.Fatal(err)
	}
	after := remote.inspect()
	if after.Err != nil || after.Pointer.SourceContract != calibre.CatalogSourceContract || after.SourceFingerprint != before.SourceFingerprint || after.Generation != before.Generation+1 {
		t.Fatalf("derived reindex lost the database contract: %+v", after)
	}
}
