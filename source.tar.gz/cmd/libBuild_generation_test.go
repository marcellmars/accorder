//go:build !tailscale

package cmd

import (
	"accorder/pkg/calibre"
	"accorder/pkg/torshare"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

// TestLibBuild_StampsMemberGeneration verifies that stampMemberGeneration writes
// a valid 24-byte _GENERATION sentinel (decodable by the fedlib member poller)
// into the calibre dir, built from a real on-disk index manifest. This is the
// fix for the gap where `lib publish` produced no <prefix>/_GENERATION, leaving
// the G2 member poller with nothing to detect.
func TestLibBuild_StampsMemberGeneration(t *testing.T) {
	dir := t.TempDir()
	staticDir := filepath.Join(dir, "static")
	if err := os.MkdirAll(staticDir, 0o755); err != nil {
		t.Fatal(err)
	}

	books := []*calibre.Book{
		{Id: "1", LibraryUUID: "uuid-member-1", Title: "Discipline and Punish", Authors: []string{"Michel Foucault"}, Tags: []string{"x"}, Librarian: "biopolitics", LastModified: "2024-12-03T00:00:00+00:00"},
		{Id: "2", LibraryUUID: "uuid-member-1", Title: "The History of Sexuality", Authors: []string{"Michel Foucault"}, Tags: []string{"x"}, Librarian: "biopolitics", LastModified: "2024-12-03T00:00:00+00:00"},
	}

	jsonlPath := filepath.Join(dir, "books.jsonl")
	f, err := os.Create(jsonlPath)
	if err != nil {
		t.Fatal(err)
	}
	for _, b := range books {
		line, err := json.Marshal(b)
		if err != nil {
			f.Close()
			t.Fatal(err)
		}
		if _, err := f.Write(append(line, '\n')); err != nil {
			f.Close()
			t.Fatal(err)
		}
	}
	if err := f.Close(); err != nil {
		t.Fatal(err)
	}

	indexPath := filepath.Join(staticDir, "library_index")
	ms := &calibre.MotwSearch{JsonlPath: jsonlPath, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex: %v", err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatalf("CompressToFile: %v", err)
	}

	// Before the fix this file would never exist after a publish.
	if err := stampMemberGeneration(dir, indexPath); err != nil {
		t.Fatalf("stampMemberGeneration: %v", err)
	}

	genBytes, err := os.ReadFile(filepath.Join(dir, "_GENERATION"))
	if err != nil {
		t.Fatalf("read _GENERATION: %v", err)
	}
	if len(genBytes) != 24 {
		t.Fatalf("_GENERATION = %d bytes, want 24", len(genBytes))
	}
	if _, _, err := torshare.DecodeGeneration(genBytes); err != nil {
		t.Fatalf("DecodeGeneration: %v (the member poller would reject this)", err)
	}
}
