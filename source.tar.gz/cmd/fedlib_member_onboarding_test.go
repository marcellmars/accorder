//go:build !tailscale

package cmd

import (
	"accorder/pkg/calibre"
	"accorder/pkg/fedlibinvite"
	"accorder/pkg/secrets"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"reflect"
	"testing"

	"github.com/tidwall/gjson"
)

// ===========================================================================
// G1 Part A Tests: lib join persists all 7 keys in secrets store
// ===========================================================================

func TestG1A_LibJoinPersistsFullRemoteConfig(t *testing.T) {
	tmpDir := testSetup(t)
	withLocalCommandRemote(t, t.TempDir())

	// Key-file (X25519) store, not passphrase: this test asserts WHICH keys lib
	// join persists, not passphrase handling, so it has no reason to pay age's
	// scrypt KDF on every store operation. See testSecretsStore.
	store := testSecretsStore(t)

	// Create a WriteInvite with all fields populated.
	inv := &fedlibinvite.WriteInvite{
		FedlibID: "my-fedlib-001",
		Backend:  "s3",
		RemoteConfig: map[string]string{
			"provider": "Wasabi",
			"endpoint": "https://s3.wasabisys.com",
			"bucket":   "test-bucket",
		},
		Prefix:    "alice",
		AccessKey: "AKIATEST123",
		SecretKey: "secretkey456",
		Label:     "Alice's Library",
	}
	blob := fedlibinvite.EncodeWriteInvite(inv)

	// Run lib join via the command struct directly.
	joinCmd := &LibJoinCmd{
		Invite:              blob,
		CommonCommandFields: CommonCommandFields{ActionAlias: "mylib"},
	}

	// Run needs a kong.Context for grammar traversal (invite-Label
	// storage); parse the same command to obtain one.
	_, ctx := parseCLI(t, []string{"lib", "join", "mylib", "--invite", blob})
	// A library-less join is deliberately incomplete — credentials and identity
	// are stored but nothing is published, which now reports non-zero. That is
	// only the vehicle here; the subject is the persisted remote config below.
	if err := joinCmd.Run(ctx); !errors.Is(err, errJoinPublishedNothing) {
		t.Fatalf("lib join: expected the incomplete-join report, got: %v", err)
	}

	// Verify all 7 keys are in the store join resolved (same X25519 identity).

	expected := map[string]string{
		"mylib/write/access-key": "AKIATEST123",
		"mylib/write/secret-key": "secretkey456",
		"mylib/write/provider":   "Wasabi",
		"mylib/write/endpoint":   "https://s3.wasabisys.com",
		"mylib/write/bucket":     "test-bucket",
		"mylib/write/prefix":     "alice",
		"mylib/write/fedlib-id":  "my-fedlib-001",
	}

	for key, want := range expected {
		got, err := store.Get(key)
		if err != nil {
			t.Errorf("store.Get(%q): %v", key, err)
			continue
		}
		if got != want {
			t.Errorf("store.Get(%q) = %q, want %q", key, got, want)
		}
	}

	_ = tmpDir
}

// ===========================================================================
// G1 Part B Tests: AfterApply secrets-store resolver
// ===========================================================================

func TestG1B_ResolveS3CredsFromSecretsStore(t *testing.T) {
	_ = testSetup(t)

	passphrase := "test-passphrase"

	// Pre-populate the secrets store with all 5 S3 cred fields.
	storePath := filepath.Join(accorderConfigDir, "secrets.age")
	store := secrets.NewStore(storePath, passphrase)
	_ = store.Set("myalias/write/access-key", "AKIAFROMSTORE")
	_ = store.Set("myalias/write/secret-key", "SECRETFROMSTORE")
	_ = store.Set("myalias/write/provider", "Wasabi")
	_ = store.Set("myalias/write/endpoint", "https://s3.wasabisys.com")
	_ = store.Set("myalias/write/bucket", "test-bucket")
	_ = store.Set("myalias/write/prefix", "alice")

	t.Run("resolves_all_empty_fields", func(t *testing.T) {

		// Create a target struct with empty S3 creds but a passphrase.
		type testTarget struct {
			GroupS3Credentials
			Passphrase string
		}
		target := testTarget{
			Passphrase: passphrase,
		}

		v := reflect.ValueOf(&target).Elem()
		resolveS3CredsFromSecretsStore(v, "myalias", false)

		if target.S3AccessKey != "AKIAFROMSTORE" {
			t.Errorf("S3AccessKey = %q, want %q", target.S3AccessKey, "AKIAFROMSTORE")
		}
		if target.S3SecretKey != "SECRETFROMSTORE" {
			t.Errorf("S3SecretKey = %q, want %q", target.S3SecretKey, "SECRETFROMSTORE")
		}
		if target.S3Provider != "Wasabi" {
			t.Errorf("S3Provider = %q, want %q", target.S3Provider, "Wasabi")
		}
		if target.S3Endpoint != "https://s3.wasabisys.com" {
			t.Errorf("S3Endpoint = %q, want %q", target.S3Endpoint, "https://s3.wasabisys.com")
		}

		// Bucket must combine the stored bucket + prefix so publish lands under
		// the librarian's scoped location (motw/<prefix>), never the bucket root.
		if target.Bucket != "test-bucket/alice" {
			t.Errorf("Bucket = %q, want %q", target.Bucket, "test-bucket/alice")
		}
	})

	t.Run("flags_take_precedence", func(t *testing.T) {
		type testTarget struct {
			GroupS3Credentials
			Passphrase string
		}
		target := testTarget{
			Passphrase: passphrase,
			GroupS3Credentials: GroupS3Credentials{
				S3AccessKey: "FROM-FLAG", // pre-set by flag
			},
		}

		v := reflect.ValueOf(&target).Elem()
		resolveS3CredsFromSecretsStore(v, "myalias", false)

		// Flag-set value must NOT be overwritten.
		if target.S3AccessKey != "FROM-FLAG" {
			t.Errorf("S3AccessKey = %q, want %q (flag precedence)", target.S3AccessKey, "FROM-FLAG")
		}

		// Other fields should be resolved.
		if target.S3SecretKey != "SECRETFROMSTORE" {
			t.Errorf("S3SecretKey = %q, want %q", target.S3SecretKey, "SECRETFROMSTORE")
		}
	})

	t.Run("noop_when_all_set", func(t *testing.T) {
		type testTarget struct {
			GroupS3Credentials
			Passphrase string
		}
		target := testTarget{
			Passphrase: passphrase,
			GroupS3Credentials: GroupS3Credentials{
				Bucket:      "flag-bucket",
				S3AccessKey: "flag-ak",
				S3SecretKey: "flag-sk",
				S3Provider:  "flag-provider",
				S3Endpoint:  "flag-endpoint",
			},
		}

		v := reflect.ValueOf(&target).Elem()

		// bucket provided explicitly by flag → respected verbatim (not re-scoped).
		resolveS3CredsFromSecretsStore(v, "myalias", true)

		// Nothing should change.
		if target.Bucket != "flag-bucket" {
			t.Errorf("Bucket changed unexpectedly: %q", target.Bucket)
		}
	})

	t.Run("noop_without_passphrase", func(t *testing.T) {
		type testTarget struct {
			GroupS3Credentials
			Passphrase string
		}
		target := testTarget{} // no passphrase, no env var

		v := reflect.ValueOf(&target).Elem()
		resolveS3CredsFromSecretsStore(v, "myalias", false)

		// Should be a no-op — fields remain empty.
		if target.S3AccessKey != "" {
			t.Errorf("S3AccessKey should be empty, got %q", target.S3AccessKey)
		}
	})
}

func TestG1B_ActionAliasesNoSecrets(t *testing.T) {
	_ = testSetup(t)

	passphrase := "test-passphrase"

	// Pre-populate secrets store.
	storePath := filepath.Join(accorderConfigDir, "secrets.age")
	store := secrets.NewStore(storePath, passphrase)
	_ = store.Set("myalias/write/access-key", "AKIAFROMSTORE")
	_ = store.Set("myalias/write/secret-key", "SECRETFROMSTORE")
	_ = store.Set("myalias/write/provider", "Wasabi")
	_ = store.Set("myalias/write/endpoint", "https://s3.wasabisys.com")
	_ = store.Set("myalias/write/bucket", "test-bucket")

	// Create a valid calibre directory with enough structure for lib publish.
	libDir := filepath.Join(accorderConfigDir, "testlib")
	_ = os.MkdirAll(libDir, 0o755)

	// Parse lib publish with only --passphrase (no S3 flags).
	// This will trigger AfterApply, which calls resolveS3CredsFromSecretsStore.
	// But lib publish also requires GroupLib fields (calibrepath, librarian, libraryID).
	// We'll test at a lower level: verify that after resolver runs, the
	// action_aliases.json does NOT contain S3 secrets.
	//

	// Direct test: run resolver, then check what would be saved.
	type testTarget struct {
		GroupS3Credentials
		Passphrase string
	}
	target := testTarget{
		Passphrase: passphrase,
	}
	v := reflect.ValueOf(&target).Elem()
	resolveS3CredsFromSecretsStore(v, "myalias", false)

	// Verify creds are resolved.
	if target.S3AccessKey != "AKIAFROMSTORE" {
		t.Fatalf("resolver failed: S3AccessKey=%q", target.S3AccessKey)
	}

	// Verify Passphrase has json:"-" tag on LibPublishCmd.
	publishType := reflect.TypeOf(LibPublishCmd{})
	for i := 0; i < publishType.NumField(); i++ {
		f := publishType.Field(i)
		if f.Name == "Passphrase" {
			jsonTag := f.Tag.Get("json")
			if jsonTag != "-" {
				t.Errorf("LibPublishCmd.Passphrase json tag = %q, want %q", jsonTag, "-")
			}
		}
	}

	// Verify the same for LibUploadCmd.
	uploadType := reflect.TypeOf(LibUploadCmd{})
	for i := 0; i < uploadType.NumField(); i++ {
		f := uploadType.Field(i)
		if f.Name == "Passphrase" {
			jsonTag := f.Tag.Get("json")
			if jsonTag != "-" {
				t.Errorf("LibUploadCmd.Passphrase json tag = %q, want %q", jsonTag, "-")
			}
		}
	}

	// Parse a simple alias config and verify no S3 secrets are saved.
	// After running lib publish with --passphrase, the action_aliases.json
	// should contain no s3 keys since they came from secrets store (not flags).
	configBytes := loadActionAliases()
	configJSON := string(configBytes)

	// Should not find any S3 secret values.
	if gjson.Get(configJSON, "*.*.s3-access-key").Exists() {
		t.Error("action_aliases.json contains s3-access-key")
	}
	if gjson.Get(configJSON, "*.*.s3-secret-key").Exists() {
		t.Error("action_aliases.json contains s3-secret-key")
	}
}

// ===========================================================================
// G2 Tests: Member generation change detection
// ===========================================================================

func TestG2_BuildMemberPollSet(t *testing.T) {
	registry := map[string]calibre.LibraryMeta{
		"uuid-ready-alice": {
			Librarian: "Alice",
			Prefix:    "alice",
			State:     "ready",
		},
		"invited:bob": {
			Librarian: "Bob",
			Prefix:    "bob",
			State:     "invited",
		},
		"uuid-disabled-carol": {
			Librarian: "Carol",
			Prefix:    "carol",
			State:     "disabled",
		},
		"uuid-local-dave": {
			Librarian: "Dave",
			Prefix:    "dave",
			Kind:      "local",
			LocalPath: "/tmp/dave",
		},
		"uuid-active-eve": {
			Librarian: "Eve",
			Prefix:    "eve",

			// State "" => active
		},
	}

	pollSet := buildMemberPollSet(registry)

	// Should include: alice (ready), bob (invited), eve (active/empty state).
	// Should exclude: carol (disabled), dave (local).
	if len(pollSet) != 3 {
		t.Fatalf("pollSet len = %d, want 3; set: %+v", len(pollSet), pollSet)
	}

	if _, ok := pollSet["uuid-ready-alice"]; !ok {
		t.Error("missing alice (ready) in poll set")
	}
	if entry, ok := pollSet["invited:bob"]; !ok {
		t.Error("missing bob (invited) in poll set")
	} else if entry.State != "invited" {
		t.Errorf("bob state = %q, want %q", entry.State, "invited")
	}
	if _, ok := pollSet["uuid-active-eve"]; !ok {
		t.Error("missing eve (active) in poll set")
	}
	if _, ok := pollSet["uuid-disabled-carol"]; ok {
		t.Error("disabled carol should not be in poll set")
	}
	if _, ok := pollSet["uuid-local-dave"]; ok {
		t.Error("local dave should not be in poll set")
	}
}

func TestG2_SkipRcloneInit(t *testing.T) {

	// Verify that the SkipRcloneInit field exists and is not a Kong flag.
	buildType := reflect.TypeOf(FedlibBuildCmd{})
	f, ok := buildType.FieldByName("SkipRcloneInit")
	if !ok {
		t.Fatal("FedlibBuildCmd.SkipRcloneInit field not found")
	}
	kongTag := f.Tag.Get("kong")
	if kongTag != "-" {
		t.Errorf("SkipRcloneInit kong tag = %q, want %q", kongTag, "-")
	}
	jsonTag := f.Tag.Get("json")
	if jsonTag != "-" {
		t.Errorf("SkipRcloneInit json tag = %q, want %q", jsonTag, "-")
	}
}

// ===========================================================================
// G4 Tests: Invited→ready reconciliation — fallback rekey arms
// (operator-minted-member-uuid). The reconcile lookup is key-agnostic
// (state+prefix), so the SAME production mutation covers:
//   - migration: a legacy invited:<prefix> placeholder rekeys to the
//     index's real UUID (registries written by older binaries);
//   - conflict: a minted-UUID key whose member published under a
//     DIFFERENT UUID (stale blob / stored-wins joiner) rekeys to the
//     index UUID — the registry self-heals on first publish.
// The registry mutation is simulated here because the full
// reconcileInvitedMember requires an index fetch; the end-to-end flip
// (real index, real CopyFile) is asserted by the G4 leg of
// TestFedlib_E2E_WasabiOnboarding (wasabi_e2e tag, compile-gated).
// ===========================================================================

func TestG4_ReconcileFallbackRekey(t *testing.T) {
	cases := []struct {
		name       string
		invitedKey string // registry key holding the invited entry
	}{
		{"legacy placeholder migrates", "invited:alice"},
		{"conflicting minted UUID rekeys", "0b5b9c1d-7e2f-4a3b-8c4d-5e6f7a8b9c0d"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			tmpDir := testSetup(t)
			registryPath := filepath.Join(tmpDir, "members.json")

			initial := map[string]calibre.LibraryMeta{
				tc.invitedKey: {
					Librarian: "Alice",
					Prefix:    "alice",
					State:     "invited",
				},
				"uuid-bob": {
					Librarian: "Bob",
					Prefix:    "bob",
					State:     "ready",
				},
			}
			if err := saveMembersRegistry(registryPath, initial); err != nil {
				t.Fatalf("save initial: %v", err)
			}

			// Simulate the reconcileInvitedMember registry mutation: the
			// member's published index carries a UUID that differs from
			// the registry key.
			registry, registryPath, err := loadMembersRegistryFromPath(registryPath)
			if err != nil {
				t.Fatalf("load: %v", err)
			}

			realUUID := "uuid-alice-real-1234"
			for uuid, meta := range registry {
				if meta.State == "invited" && meta.Prefix == "alice" {
					delete(registry, uuid)
					registry[realUUID] = calibre.LibraryMeta{
						Librarian: meta.Librarian,
						Prefix:    meta.Prefix,
						State:     "ready",
						Kind:      meta.Kind,
					}
					break
				}
			}

			if err := saveMembersRegistry(registryPath, registry); err != nil {
				t.Fatalf("save: %v", err)
			}

			reloaded, _, err := loadMembersRegistryFromPath(registryPath)
			if err != nil {
				t.Fatalf("reload: %v", err)
			}

			if _, ok := reloaded[tc.invitedKey]; ok {
				t.Errorf("old key %q still present after rekey", tc.invitedKey)
			}
			alice, ok := reloaded[realUUID]
			if !ok {
				t.Fatal("real UUID key not found")
			}
			if alice.Librarian != "Alice" {
				t.Errorf("Librarian = %q, want %q", alice.Librarian, "Alice")
			}
			if alice.Prefix != "alice" {
				t.Errorf("Prefix = %q, want %q", alice.Prefix, "alice")
			}
			if alice.State != "ready" {
				t.Errorf("State = %q, want %q", alice.State, "ready")
			}
			if _, ok := reloaded["uuid-bob"]; !ok {
				t.Error("Bob's entry disappeared")
			}
		})
	}
}

// ===========================================================================
// G3 Tests: IAM policy construction
// ===========================================================================

func TestG3_BuildScopedPolicy(t *testing.T) {
	policy := buildScopedPolicy("motw", "alice")

	if policy.Version != "2012-10-17" {
		t.Errorf("Version = %q, want %q", policy.Version, "2012-10-17")
	}
	if len(policy.Statement) != 2 {
		t.Fatalf("Statement count = %d, want 2", len(policy.Statement))
	}

	// Statement 1: Object operations.
	s1 := policy.Statement[0]
	if s1.Effect != "Allow" {
		t.Errorf("Statement[0].Effect = %q, want %q", s1.Effect, "Allow")
	}
	// Both the bare prefix key (rclone's destination HeadObject probe) and
	// the objects under it must be covered, or missing keys 403 instead of 404.
	wantResources := []string{"arn:aws:s3:::motw/alice", "arn:aws:s3:::motw/alice/*"}
	if !reflect.DeepEqual(s1.Resource, wantResources) {
		t.Errorf("Statement[0].Resource = %v, want %v", s1.Resource, wantResources)
	}
	wantActions := []string{"s3:PutObject", "s3:GetObject", "s3:DeleteObject"}
	if !reflect.DeepEqual(s1.Action, wantActions) {
		t.Errorf("Statement[0].Action = %v, want %v", s1.Action, wantActions)
	}

	// Statement 2: ListBucket with prefix condition.
	s2 := policy.Statement[1]
	wantBucketARN := "arn:aws:s3:::motw"
	if s2.Resource != wantBucketARN {
		t.Errorf("Statement[1].Resource = %v, want %q", s2.Resource, wantBucketARN)
	}
	if s2.Condition == nil {
		t.Fatal("Statement[1].Condition is nil")
	}
	// Listing happens with both "alice" (no slash) and "alice/..." prefixes.
	condVal := s2.Condition["StringLike"]["s3:prefix"]
	if !reflect.DeepEqual(condVal, []string{"alice", "alice/*"}) {
		t.Errorf("Condition s3:prefix = %v, want [alice alice/*]", condVal)
	}

	// Verify JSON marshaling works.
	policyJSON, err := json.Marshal(policy)
	if err != nil {
		t.Fatalf("json.Marshal: %v", err)
	}
	if len(policyJSON) == 0 {
		t.Error("policy JSON is empty")
	}
}

func TestG3_InviteValidation(t *testing.T) {

	// Verify that S3AccessKey and S3SecretKey are now omitempty on FedlibMembersInviteCmd.
	invType := reflect.TypeOf(FedlibMembersInviteCmd{})

	for _, fieldName := range []string{"S3AccessKey", "S3SecretKey"} {
		f, ok := invType.FieldByName(fieldName)
		if !ok {
			t.Fatalf("field %s not found", fieldName)
		}
		validateTag := f.Tag.Get("validate")
		if validateTag != "omitempty" {
			t.Errorf("%s validate tag = %q, want %q", fieldName, validateTag, "omitempty")
		}
	}

	// Verify operator flags exist.
	for _, fieldName := range []string{"OperatorRootKey", "OperatorRootSecret", "IAMEndpoint"} {
		if _, ok := invType.FieldByName(fieldName); !ok {
			t.Errorf("field %s not found on FedlibMembersInviteCmd", fieldName)
		}
	}
}

func TestG3_ResolveIAMEndpoint(t *testing.T) {
	tests := []struct {
		name        string
		provider    string
		iamEndpoint string
		want        string
	}{
		{"wasabi_auto", "Wasabi", "", "https://iam.wasabisys.com"},
		{"aws_auto", "AWS", "", "https://iam.amazonaws.com"},
		{"custom_override", "Wasabi", "https://custom-iam.example.com", "https://custom-iam.example.com"},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			cmd := &FedlibMembersInviteCmd{
				S3Provider:  tt.provider,
				IAMEndpoint: tt.iamEndpoint,
			}
			got := cmd.resolveIAMEndpoint()
			if got != tt.want {
				t.Errorf("resolveIAMEndpoint() = %q, want %q", got, tt.want)
			}
		})
	}
}
