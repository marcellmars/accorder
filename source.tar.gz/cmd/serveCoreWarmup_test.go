package cmd

import (
	"context"
	"errors"
	"fmt"
	"net"
	"net/http"
	"testing"
	"time"
)

// get issues a GET against a bound listener and returns status + Retry-After.
func get(t *testing.T, addr, path string) (int, string) {
	t.Helper()
	resp, err := (&http.Client{Timeout: 5 * time.Second}).Get("http://" + addr + path)
	if err != nil {
		t.Fatalf("GET %s: %v", path, err)
	}
	defer resp.Body.Close()
	return resp.StatusCode, resp.Header.Get("Retry-After")
}

// TestServeHTTPWithTransport_WarmUpServes503ThenSwaps is the regression test for
// the 2026-08-15 outage: during warm-up the port must be bound and answering 503,
// never refusing connections, and the real mux must take over once warm-up ends.
func TestServeHTTPWithTransport_WarmUpServes503ThenSwaps(t *testing.T) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	addr := ln.Addr().String()

	release := make(chan struct{})
	warmStarted := make(chan struct{})

	mux := http.NewServeMux()
	mux.HandleFunc("/info", func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	done := make(chan error, 1)
	go func() {
		done <- serveHTTPWithTransport(ln, nil, ServeOptions{
			CommandName:       "test serve",
			OnlyHTTP:          true,
			SuppressListenLog: true,
			WarmUp: func(_ context.Context) (*http.ServeMux, *http.ServeMux, error) {
				close(warmStarted)
				<-release
				return mux, nil, nil
			},
		})
	}()

	<-warmStarted

	// The whole point: bound and answering, not ECONNREFUSED.
	if code, retry := get(t, addr, "/info"); code != http.StatusServiceUnavailable {
		t.Errorf("during warm-up: status = %d, want %d", code, http.StatusServiceUnavailable)
	} else if retry != warmingRetryAfter {
		t.Errorf("during warm-up: Retry-After = %q, want %q", retry, warmingRetryAfter)
	}

	close(release)

	// Poll for the swap rather than sleeping a fixed interval.
	deadline := time.Now().Add(5 * time.Second)
	var code int
	for time.Now().Before(deadline) {
		if code, _ = get(t, addr, "/info"); code == http.StatusOK {
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	if code != http.StatusOK {
		t.Errorf("after warm-up: status = %d, want %d", code, http.StatusOK)
	}

	ln.Close()
	select {
	case <-done:
	case <-time.After(5 * time.Second):
		t.Fatal("serveHTTPWithTransport did not return after listener close")
	}
}

// TestServeHTTPWithTransport_WarmUpFailurePropagates guards the design trap named
// in the proposal: a failed warm-up must return an error so the process exits
// non-zero. Latching a permanent 503 would look alive to systemd's
// Restart=on-failure and never be restarted.
func TestServeHTTPWithTransport_WarmUpFailurePropagates(t *testing.T) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer ln.Close()

	sentinel := errors.New("aggregate unreachable")

	done := make(chan error, 1)
	go func() {
		done <- serveHTTPWithTransport(ln, nil, ServeOptions{
			CommandName:       "test serve",
			OnlyHTTP:          true,
			SuppressListenLog: true,
			WarmUp: func(_ context.Context) (*http.ServeMux, *http.ServeMux, error) {
				return nil, nil, fmt.Errorf("setup: %w", sentinel)
			},
		})
	}()

	select {
	case err := <-done:
		if !errors.Is(err, sentinel) {
			t.Fatalf("warm-up failure returned %v, want wrapped %v", err, sentinel)
		}
	case <-time.After(10 * time.Second):
		t.Fatal("warm-up failure did not return; process would serve 503 forever")
	}
}

// TestServeHTTPWithTransport_NoWarmUpUnchanged pins the nil-WarmUp path: callers
// that pass no warm-up (lib share live) must serve their mux immediately, exactly
// as before the gate existed.
func TestServeHTTPWithTransport_NoWarmUpUnchanged(t *testing.T) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	addr := ln.Addr().String()

	mux := http.NewServeMux()
	mux.HandleFunc("/info", func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	done := make(chan error, 1)
	go func() {
		done <- serveHTTPWithTransport(ln, mux, ServeOptions{
			CommandName:       "test serve",
			OnlyHTTP:          true,
			SuppressListenLog: true,
		})
	}()

	deadline := time.Now().Add(5 * time.Second)
	var code int
	for time.Now().Before(deadline) {
		if code, _ = get(t, addr, "/info"); code == http.StatusOK {
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	if code != http.StatusOK {
		t.Errorf("no-warm-up path: status = %d, want %d (never 503)", code, http.StatusOK)
	}

	ln.Close()
	select {
	case <-done:
	case <-time.After(5 * time.Second):
		t.Fatal("serveHTTPWithTransport did not return after listener close")
	}
}

// TestServeHTTPWithTransport_NilMuxIsFailure pins the defensive guard: a WarmUp
// that returns (nil, nil, nil) must not latch the gate at 503 forever.
func TestServeHTTPWithTransport_NilMuxIsFailure(t *testing.T) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer ln.Close()

	done := make(chan error, 1)
	go func() {
		done <- serveHTTPWithTransport(ln, nil, ServeOptions{
			CommandName:       "test serve",
			OnlyHTTP:          true,
			SuppressListenLog: true,
			WarmUp: func(_ context.Context) (*http.ServeMux, *http.ServeMux, error) {
				return nil, nil, nil
			},
		})
	}()

	select {
	case err := <-done:
		if err == nil {
			t.Fatal("nil mux returned nil error; gate would serve 503 forever")
		}
	case <-time.After(10 * time.Second):
		t.Fatal("nil mux did not return")
	}
}
