package cmd

import (
	"accorder/pkg/secrets"
	"errors"
	"strings"
	"testing"
)

func TestLibJoinDiscardPendingRespectsLibraryExecutionLock(t *testing.T) {
	testSetup(t)
	store := testSecretsStore(t)
	const alias = "alice"
	const pending = `{"version":1,"library_id":"550e8400-e29b-41d4-a716-446655440000","dict_id":4,"prefix":"alice","label":"Alice"}`
	if err := store.Set(pendingJoinKey(alias), pending); err != nil {
		t.Fatal(err)
	}

	release, err := acquireLibraryExecutionLock(alias)
	if err != nil {
		t.Fatal(err)
	}
	locked := true
	defer func() {
		if locked {
			release()
		}
	}()

	discard := &LibJoinCmd{
		CommonCommandFields: CommonCommandFields{ActionAlias: alias},
		DiscardPending:      true,
		Yes:                 true,
	}
	if err := discard.Run(nil); err == nil || !strings.Contains(err.Error(), "another sync or publish is already running") {
		t.Fatalf("discard while alias locked error = %v", err)
	}
	if got, err := store.Get(pendingJoinKey(alias)); err != nil || got != pending {
		t.Fatalf("pending identity changed through held lock: got %q, err %v", got, err)
	}

	release()
	locked = false
	if err := discard.Run(nil); err != nil {
		t.Fatalf("discard after lock release: %v", err)
	}
	if _, err := store.Get(pendingJoinKey(alias)); !errors.Is(err, secrets.ErrKeyNotFound) {
		t.Fatalf("pending identity remained after discard: %v", err)
	}
}
