package cmd

import (
	"accorder/pkg/calibre"
	"testing"
)

func TestIsPeer(t *testing.T) {
	tests := []struct {
		kind string
		want bool
	}{
		{"peer", true},
		{"local", false},
		{"rclone", false},
		{"", false},
	}
	for _, tt := range tests {
		m := calibre.LibraryMeta{Kind: tt.kind}
		if got := m.IsPeer(); got != tt.want {
			t.Errorf("LibraryMeta{Kind: %q}.IsPeer() = %v, want %v", tt.kind, got, tt.want)
		}
	}
}

func TestHasPeerMembers(t *testing.T) {
	tests := []struct {
		name     string
		registry map[string]calibre.LibraryMeta
		want     bool
	}{
		{
			"active peer",
			map[string]calibre.LibraryMeta{
				"a": {Kind: "peer", State: "ready", Prefix: "alice", Endpoint: "http://localhost"},
			},
			true,
		},
		{
			"retired peer",
			map[string]calibre.LibraryMeta{
				"a": {Kind: "peer", State: "retired", Prefix: "alice", Endpoint: "http://localhost"},
			},
			true,
		},
		{
			"disabled peer excluded",
			map[string]calibre.LibraryMeta{
				"a": {Kind: "peer", State: "disabled", Prefix: "alice", Endpoint: "http://localhost"},
			},
			false,
		},
		{
			"no peers",
			map[string]calibre.LibraryMeta{
				"a": {Kind: "rclone", State: "ready", Prefix: "alice"},
			},
			false,
		},
		{
			"empty registry",
			map[string]calibre.LibraryMeta{},
			false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := calibre.HasPeerMembers(tt.registry); got != tt.want {
				t.Errorf("HasPeerMembers() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestHasRcloneMembers_ExcludesPeers(t *testing.T) {
	tests := []struct {
		name     string
		registry map[string]calibre.LibraryMeta
		want     bool
	}{
		{
			"peer only — no rclone needed",
			map[string]calibre.LibraryMeta{
				"a": {Kind: "peer", State: "ready", Prefix: "alice", Endpoint: "http://localhost"},
			},
			false,
		},
		{
			"rclone only",
			map[string]calibre.LibraryMeta{
				"a": {Kind: "rclone", State: "ready", Prefix: "alice"},
			},
			true,
		},
		{
			"mixed peer and rclone",
			map[string]calibre.LibraryMeta{
				"a": {Kind: "peer", State: "ready", Prefix: "alice"},
				"b": {Kind: "rclone", State: "ready", Prefix: "bob"},
			},
			true,
		},
		{
			"empty kind (legacy rclone)",
			map[string]calibre.LibraryMeta{
				"a": {Kind: "", State: "ready", Prefix: "alice"},
			},
			true,
		},
		{
			"peer + local only — no rclone needed",
			map[string]calibre.LibraryMeta{
				"a": {Kind: "peer", State: "ready", Prefix: "alice"},
				"b": {Kind: "local", State: "ready", LocalPath: "/tmp"},
			},
			false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := calibre.HasRcloneMembers(tt.registry); got != tt.want {
				t.Errorf("HasRcloneMembers() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestBuildMemberPollSet_IncludesPeers(t *testing.T) {
	registry := map[string]calibre.LibraryMeta{
		"a": {Prefix: "alice", Kind: "peer", State: "ready", Endpoint: "http://localhost"},
		"b": {Prefix: "bob", Kind: "rclone", State: "ready"},
		"c": {Prefix: "carol", Kind: "local", State: "ready", LocalPath: "/tmp"},
		"d": {Prefix: "dave", Kind: "peer", State: "disabled", Endpoint: "http://localhost"},
	}
	pollSet := buildMemberPollSet(registry)

	if _, ok := pollSet["a"]; !ok {
		t.Error("buildMemberPollSet should include active peer members")
	}
	if _, ok := pollSet["b"]; !ok {
		t.Error("buildMemberPollSet should include active rclone members")
	}
	if _, ok := pollSet["c"]; ok {
		t.Error("buildMemberPollSet should exclude local members")
	}
	if _, ok := pollSet["d"]; ok {
		t.Error("buildMemberPollSet should exclude disabled members")
	}

	// Verify peer fields are populated.
	entry := pollSet["a"]
	if entry.Kind != "peer" {
		t.Errorf("peer entry.Kind = %q, want %q", entry.Kind, "peer")
	}
	if entry.Endpoint != "http://localhost" {
		t.Errorf("peer entry.Endpoint = %q, want %q", entry.Endpoint, "http://localhost")
	}
}
