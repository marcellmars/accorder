//go:build tailscale

package cmd

import (
	"context"
	"fmt"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"tailscale.com/tsnet"
	"tailscale.com/types/logger"
)

type FedlibShareFunnelCmd struct {
	CommonCommandFields
	TailscaleAuthKey string `short:"k" help:"Tailscale's auth key." json:"tailscale-auth-key" validate:"required"`
	Subdomain        string `name:"subdomain" json:"subdomain" help:"Tailscale Funnel subdomain." validate:"required"`
	AggregatePath    string `name:"aggregate-path" json:"aggregate-path" help:"Local working dir for the cached aggregate (library_index.zst, libraries.json)." validate:"required"`
	UploadPrefix     string `name:"upload-prefix" json:"upload-prefix" help:"S3 prefix where the aggregate lives." default:"aggregate"`
	Bucket           string `name:"bucket" json:"bucket" propagate:"-" help:"S3 bucket name." validate:"required"`
	S3AccessKey      string `name:"s3-access-key" json:"s3-access-key" alias:"-" help:"S3 access key (read-only is enough for serve)." validate:"required" sharedgroup:"s3creds" secret:"redact,fingerprint"`
	S3SecretKey      string `name:"s3-secret-key" json:"s3-secret-key" alias:"-" help:"S3 secret key." validate:"required" sharedgroup:"s3creds" secret:"redact,fingerprint"`
	S3Provider       string `name:"s3-provider" json:"s3-provider" alias:"-" help:"S3 provider (e.g. Wasabi, AWS)." validate:"required" sharedgroup:"s3creds"`
	S3Endpoint       string `name:"s3-endpoint" json:"s3-endpoint" alias:"-" help:"S3 endpoint URL." validate:"required" sharedgroup:"s3creds"`
	KeysFile         string `name:"keys-file" json:"keys-file" help:"Path to the operator S3 keys-file (default: keys/<alias>.s3.keys under the config dir)." validate:"omitempty"`
	CacheSize        string `name:"cache-size" json:"cache-size" help:"VFS books-pool size cap (e.g. 3000000000B, 3Gi)." default:"3000000000B"`
	CacheSizeAssets  string `name:"cache-size-assets" json:"cache-size-assets" help:"VFS assets-pool size cap for cover.jpg and member static/ objects." default:"5000000000B"`
	CacheMaxAge      string `name:"cache-max-age" json:"cache-max-age" help:"Max idle time before cache eviction (e.g. 8760h). NOTE: rclone treats 0 as evict-immediately-when-idle, not as unlimited." default:"8760h"`
	CacheMinFree     string `name:"cache-min-free" json:"cache-min-free" help:"Disk-safety floor: stop the VFS cache filling the disk below this free amount (e.g. 2Gi)." default:"2Gi"`
	DirCacheTime     string `name:"dir-cache-time" json:"dir-cache-time" help:"In-memory VFS directory metadata lifetime shared by books and assets; committed generations invalidate it early (requires --poll-interval > 0, otherwise this is the only refresh)." default:"24h"`
	RcloneLogLevel   string `name:"rclone-log-level" json:"-" help:"Log level for the embedded rclone (EMERGENCY..DEBUG, OFF). Empty keeps rclone's default NOTICE. Use INFO to surface the VFS cache cleaner's per-pass stats, which is how you tell whether cache-size eviction is keeping up. Never remembered by the action alias (diagnostic class)." enum:"EMERGENCY,ALERT,CRITICAL,ERROR,WARNING,NOTICE,INFO,DEBUG,OFF," default:""`
	PollInterval     int    `name:"poll-interval" json:"poll-interval" help:"Generation poll interval in seconds (0 disables hot-swap)." default:"60"`

	MeterWindow            time.Duration `name:"meter-window" json:"meter-window" help:"Rolling window for per-session distinct-file counting." default:"1h"`
	MeterMaxSessions       int           `name:"meter-max-sessions" json:"meter-max-sessions" help:"Cap on concurrent live sessions." default:"50000"`
	MeterBucketGranularity time.Duration `name:"meter-bucket-granularity" json:"meter-bucket-granularity" help:"Time granularity for rolling-window distinct-file counter." default:"60s"`
	MeterMaxDistinct       int           `name:"meter-max-distinct" json:"meter-max-distinct" help:"Cap on distinct path hashes tracked per session." default:"1000"`

	EgressMonthlyAllowance string  `name:"egress-monthly-allowance" json:"egress-monthly-allowance" help:"Monthly egress allowance (e.g. 500Gi). Sets token-bucket sustained rate." default:""`
	EgressBudgetUSD        float64 `name:"egress-budget-usd" json:"egress-budget-usd" help:"Daily USD budget for S3 egress (pay-as-you-go backends). Overrides monthly allowance." default:"0"`
	EgressPricePerGB       float64 `name:"egress-price-per-gb" json:"egress-price-per-gb" help:"Provider egress price in $/GB (used with --egress-budget-usd)." default:"0.04"`
	EgressLimit            string  `name:"egress-limit" json:"egress-limit" help:"Raw bytes/day egress limit (e.g. 50Gi). Highest precedence override." default:""`
	EgressBurst            string  `name:"egress-burst" json:"egress-burst" help:"Token bucket burst allowance (e.g. 10Gi). Default: 1h of sustained budget." default:""`
}

func (c *FedlibShareFunnelCmd) aggregateServeParams() AggregateServeParams {
	remotes := funnelCacheRemoteNames(c.ActionAlias)
	return AggregateServeParams{
		CommandName:            "fedlib share funnel",
		RemoteName:             remotes.Books,
		AssetsRemoteName:       remotes.Assets,
		ActionAlias:            c.ActionAlias,
		AggregatePath:          c.AggregatePath,
		UploadPrefix:           c.UploadPrefix,
		Bucket:                 c.Bucket,
		KeysFile:               c.KeysFile,
		S3AccessKey:            c.S3AccessKey,
		S3SecretKey:            c.S3SecretKey,
		S3Provider:             c.S3Provider,
		S3Endpoint:             c.S3Endpoint,
		CacheSize:              c.CacheSize,
		CacheSizeAssets:        c.CacheSizeAssets,
		CacheMaxAge:            c.CacheMaxAge,
		CacheMinFree:           c.CacheMinFree,
		DirCacheTime:           c.DirCacheTime,
		RcloneLogLevel:         c.RcloneLogLevel,
		PollInterval:           c.PollInterval,
		MeterWindow:            c.MeterWindow,
		MeterMaxSessions:       c.MeterMaxSessions,
		MeterBucketGranularity: c.MeterBucketGranularity,
		MeterMaxDistinct:       c.MeterMaxDistinct,
		EgressMonthlyAllowance: c.EgressMonthlyAllowance,
		EgressBudgetUSD:        c.EgressBudgetUSD,
		EgressPricePerGB:       c.EgressPricePerGB,
		EgressLimit:            c.EgressLimit,
		EgressBurst:            c.EgressBurst,
	}
}

func (c *FedlibShareFunnelCmd) Run() error {
	if c.HandleShowConfig(c) {
		return nil
	}

	subdomain := strings.TrimSpace(c.Subdomain)
	if subdomain == "" {
		return fmt.Errorf("fedlib share funnel: --subdomain is required")
	}

	hasRclone, localMembers, err := scanMembersForServe(c.AggregatePath, "")
	if err != nil {
		return fmt.Errorf("fedlib share funnel: read members registry: %w", err)
	}
	if hasRclone {
		if err := requireS3Creds(c.Bucket, c.S3AccessKey, c.S3SecretKey, c.S3Provider, c.S3Endpoint); err != nil {
			return fmt.Errorf("fedlib share funnel: %w", err)
		}
	}

	params := c.aggregateServeParams()
	params.HasRcloneMembers = hasRclone
	params.LocalMembers = localMembers

	// res is populated by the WarmUp closure below, after the funnel listener is
	// already serving the readiness gate. Declared here so its cleanup keeps the
	// original teardown order (cleanup last, after ln and tsServer close).
	var res *AggregateServeResources
	defer func() {
		if res != nil {
			res.Cleanup()
		}
	}()

	tsDir := filepath.Join(accorderConfigDir, "tailscale_state", "funnel-"+c.ActionAlias)
	// 0700: tsnet stores node keys here, and fedlib backup treats this tree
	// as credential material.
	if err := os.MkdirAll(tsDir, configDirPerm); err != nil {
		return fmt.Errorf("fedlib share funnel: mkdir tailscale state: %w", err)
	}
	tsServer := &tsnet.Server{
		Dir:      tsDir,
		Logf:     logger.Discard,
		Hostname: subdomain,
		AuthKey:  c.TailscaleAuthKey,
	}
	defer tsServer.Close()

	ln, err := tsServer.ListenFunnel("tcp", ":443")
	if err != nil {
		return fmt.Errorf("fedlib share funnel: listen funnel: %w", err)
	}
	defer ln.Close()

	domains := tsServer.CertDomains()
	if len(domains) > 0 {
		log.Printf("fedlib share funnel: https://%s/", domains[0])
	}
	log.Printf("fedlib share funnel: serving via Tailscale Funnel")

	var pollerWG sync.WaitGroup
	var backgroundWG sync.WaitGroup
	// mux is nil here: it arrives from WarmUp once the aggregate is loaded.
	return serveHTTPWithTransport(ln, nil, ServeOptions{
		CommandName:       "fedlib share funnel",
		OnlyHTTP:          true,
		SuppressListenLog: true,
		WarmUp: func(_ context.Context) (*http.ServeMux, *http.ServeMux, error) {
			r, werr := setupAggregateServe(params)
			if werr != nil {
				return nil, nil, werr
			}
			res = r
			return r.Mux, r.BrowserMux, nil
		},
		PreServe: func(ctx context.Context) {
			if c.PollInterval > 0 && hasRclone {
				pollerWG.Add(1)
				go func() {
					defer pollerWG.Done()
					pollAggregateGeneration(ctx, res.BucketFS, res.VFS, c.UploadPrefix, c.AggregatePath, res.CacheDir, res.State,
						res.RegistryPrefixes, time.Duration(c.PollInterval)*time.Second,
						&params, res.Registry, res.RegistryPath, res.Lease)
				}()
			}
			backgroundWG.Add(1)
			go func() {
				defer backgroundWG.Done()
				res.Meter.startSweep(ctx)
			}()
			if res.Breaker != nil {
				backgroundWG.Add(1)
				go func() {
					defer backgroundWG.Done()
					res.Breaker.pollLoop(ctx, 30*time.Second)
				}()
				log.Printf("fedlib share funnel: egress breaker enabled (sustained=%.0f bytes/s, burst=%.0f bytes)",
					res.Breaker.sustainedRate, res.Breaker.bucketCapacity)
			}
		},
		OnShutdown: func() {
			runShutdownStep("fedlib share funnel", "member-poller-stop", pollerWG.Wait)
			runShutdownStep("fedlib share funnel", "meter-breaker-stop", backgroundWG.Wait)
		},
	})
}
