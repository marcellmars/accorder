package cmd

import (
	"os"
	"path/filepath"
	"testing"

	"accorder/pkg/calibre"
	"accorder/pkg/torshare"
)

// TestSentinelContentSensitive verifies that two aggregates with the same
// membership (same activeUUIDs) but different member content produce different
// sentinel bytes. This is the fix for bug #4: the daemon's
// aggregateVersionCurrent compares raw sentinel bytes, so a content-only change
// must produce a different sentinel to trigger auto-adoption.
//

// It also verifies that manifest.BaseGeneration stays identical (it's
// membership-only, consumed by the incremental membership-change check).
func TestSentinelContentSensitive(t *testing.T) {

	// Same membership.
	activeUUIDs := []string{"member-a", "member-b"}
	membershipHash := computeMembershipHash(activeUUIDs)

	// Two content-stamp sets: identical membership, but member-a's idxGen differs.
	membersV1 := []aggMemberGen{
		{uuid: "member-a", bookCount: 100, lastModified: "2026-06-01", idxBaseGen: [16]byte{1}, idxGen: 1},
		{uuid: "member-b", bookCount: 50, lastModified: "2026-05-15", idxBaseGen: [16]byte{2}, idxGen: 0},
	}
	membersV2 := []aggMemberGen{
		{uuid: "member-a", bookCount: 100, lastModified: "2026-06-01", idxBaseGen: [16]byte{1}, idxGen: 2}, // idxGen bumped
		{uuid: "member-b", bookCount: 50, lastModified: "2026-05-15", idxBaseGen: [16]byte{2}, idxGen: 0},
	}

	sentinelBaseV1 := computeAggregateBaseGen(membersV1)
	sentinelBaseV2 := computeAggregateBaseGen(membersV2)

	// Content-sensitive bases MUST differ.
	if sentinelBaseV1 == sentinelBaseV2 {
		t.Fatal("sentinel bases must differ when member content changes (same membership, different idxGen)")
	}

	// Write sentinels to temp dirs and compare the raw bytes.
	dir1 := t.TempDir()
	dir2 := t.TempDir()

	mf := calibre.Manifest{
		BaseGeneration: membershipHash,
		Generation:     5,
	}

	if err := writeGenerationSentinel(dir1, sentinelBaseV1, mf); err != nil {
		t.Fatalf("write sentinel v1: %v", err)
	}
	if err := writeGenerationSentinel(dir2, sentinelBaseV2, mf); err != nil {
		t.Fatalf("write sentinel v2: %v", err)
	}

	bytes1, err := os.ReadFile(filepath.Join(dir1, "_GENERATION"))
	if err != nil {
		t.Fatal(err)
	}
	bytes2, err := os.ReadFile(filepath.Join(dir2, "_GENERATION"))
	if err != nil {
		t.Fatal(err)
	}

	// Sentinel bytes MUST differ (content-sensitive).
	if string(bytes1) == string(bytes2) {
		t.Fatal("sentinel bytes must differ when member content changes — aggregateVersionCurrent would skip adoption")
	}

	// Both must decode successfully.
	base1, gen1, err := torshare.DecodeGeneration(bytes1)
	if err != nil {
		t.Fatalf("decode sentinel v1: %v", err)
	}
	base2, gen2, err := torshare.DecodeGeneration(bytes2)
	if err != nil {
		t.Fatalf("decode sentinel v2: %v", err)
	}

	// Generation counter is the same (both use mf.Generation=5).
	if gen1 != gen2 {
		t.Fatalf("generation counters differ: %d vs %d", gen1, gen2)
	}

	// Decoded bases differ (the content hash, not the membership hash).
	if base1 == base2 {
		t.Fatal("decoded bases must differ")
	}

	// Verify that manifest.BaseGeneration (membership hash) is NOT affected.
	// Both aggregates have the same activeUUIDs, so membershipHash is identical.
	membershipHash2 := computeMembershipHash(activeUUIDs)
	if membershipHash != membershipHash2 {
		t.Fatal("membership hash must be stable for same UUIDs")
	}
}

// TestSentinelSingleLibraryUnchanged verifies that single-library callers
// still produce sentinels using mf.BaseGeneration (behavior unchanged).
func TestSentinelSingleLibraryUnchanged(t *testing.T) {
	dir := t.TempDir()

	mf := calibre.Manifest{
		BaseGeneration: [16]byte{0xAA, 0xBB, 0xCC},
		Generation:     42,
	}

	// Single-library callers pass mf.BaseGeneration as the base.
	if err := writeGenerationSentinel(dir, mf.BaseGeneration, mf); err != nil {
		t.Fatal(err)
	}

	raw, err := os.ReadFile(filepath.Join(dir, "_GENERATION"))
	if err != nil {
		t.Fatal(err)
	}

	base, gen, err := torshare.DecodeGeneration(raw)
	if err != nil {
		t.Fatal(err)
	}
	if base != mf.BaseGeneration {
		t.Fatalf("base = %x; want %x (single-library sentinel must use mf.BaseGeneration)", base, mf.BaseGeneration)
	}
	if gen != 42 {
		t.Fatalf("gen = %d; want 42", gen)
	}
}
