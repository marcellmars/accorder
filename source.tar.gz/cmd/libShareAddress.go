//go:build tor

package cmd

import (
	"accorder/pkg/torshare"
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

type LibShareAddressCmd struct {
	CommonCommandFields
}

func (c *LibShareAddressCmd) Run() error {
	if c.HandleShowConfig(c) {
		return nil
	}
	stateDir := torshare.StateDir(accorderConfigDir, c.ActionAlias)

	if _, err := os.Stat(filepath.Join(stateDir, ".serve-dual")); err == nil {
		browser, index, err := torshare.ReadDualOnionAddrs(accorderConfigDir, c.ActionAlias)
		if err != nil {
			return fmt.Errorf("lib share address: %w", err)
		}
		printOnionBanner(
			fmt.Sprintf("sharing %q via Tor (dual onion)", c.ActionAlias),
			"browser (public):  http://"+browser+"/",
			"index (invite):    http://"+index+"/",
		)
		return nil
	}

	onion, err := torshare.ReadOnionAddr(accorderConfigDir, c.ActionAlias)
	if err != nil {
		return fmt.Errorf("lib share address: %w (start `accorder lib share live %s --only-tor` to create one)", err, c.ActionAlias)
	}
	printOnionBanner(fmt.Sprintf("sharing %q at  http://%s/", c.ActionAlias, strings.TrimSpace(onion)))
	return nil
}
