package cmd

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// End-to-end smoke of the prune surfacing + filesystem apply branch — the
// Verification Plan's user-facing output check: findings rendered with
// sizes, deletion only under the dedicated flags, jsonl always retained.

func TestPrune_ReportsStrandedTreeAndRetainedJSONL(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "motw")
	seedTreePair(t, "accorder-serve-gone")
	_ = os.WriteFile(filepath.Join(accorderCacheDir(), "dead.jsonl"), []byte("{}"), 0o644)

	_, ctx := parseCLI(t, []string{"config", "prune"})
	var runErr error
	out := captureStdout(t, func() { runErr = ctx.Run() })
	if runErr != nil {
		t.Fatal(runErr)
	}
	if !strings.Contains(out, "accorder-serve-gone") || !strings.Contains(out, "stranded cache tree") {
		t.Fatalf("stranded tree not reported:\n%s", out)
	}
	if !strings.Contains(out, "dead.jsonl") {
		t.Fatalf("retained jsonl not reported:\n%s", out)
	}
	if !strings.Contains(out, "--apply-cache-trees") {
		t.Fatalf("no hint toward the apply flag:\n%s", out)
	}

	// Dry run: nothing touched.
	if !treeExists("vfs", "accorder-serve-gone") {
		t.Fatal("dry-run prune deleted a tree")
	}
}

func TestPrune_ApplyCacheTreesAloneKeepsLegacy(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "motw")
	seedTreePair(t, "accorder-serve-gone") // legacy: unledgered
	activateReclaim(t)

	_, ctx := parseCLI(t, []string{"config", "prune", "--apply-cache-trees"})
	var runErr error
	out := captureStdout(t, func() { runErr = ctx.Run() })
	if runErr != nil {
		t.Fatal(runErr)
	}
	if !treeExists("vfs", "accorder-serve-gone") {
		t.Fatalf("--apply-cache-trees alone deleted a LEGACY tree:\n%s", out)
	}
	if !strings.Contains(out, "--attest-no-serves") {
		t.Fatalf("kept legacy tree without pointing at the attestation flag:\n%s", out)
	}
}

func TestPrune_AttestedReclaimsLegacyAndActivates(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "motw")
	seedTreePair(t, "accorder-serve-gone")
	_ = os.WriteFile(filepath.Join(accorderCacheDir(), "dead.jsonl"), []byte("{}"), 0o644)
	legacyDict := seedDict(t, "legacy-1.dict")

	// NOT pre-activated: the attested run itself writes the marker.

	_, ctx := parseCLI(t, []string{"config", "prune", "--apply-cache-trees", "--attest-no-serves"})
	var runErr error
	out := captureStdout(t, func() { runErr = ctx.Run() })
	if runErr != nil {
		t.Fatal(runErr)
	}
	if !reclaimActivated() {
		t.Fatal("attested run did not write the activation marker")
	}
	if treeExists("vfs", "accorder-serve-gone") || treeExists("vfsMeta", "accorder-serve-gone") {
		t.Fatalf("attested run left the legacy tree:\n%s", out)
	}
	if fileExists(legacyDict) {
		t.Fatal("attested run left the unledgered legacy dict")
	}
	if _, err := os.Stat(filepath.Join(accorderCacheDir(), "dead.jsonl")); err != nil {
		t.Fatal("jsonl deleted under attestation — it is retained data under EVERY flag combination")
	}
}

func TestPrune_AttestWithoutApplyIsAnError(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "motw")
	_, ctx := parseCLI(t, []string{"config", "prune", "--attest-no-serves"})
	if err := ctx.Run(); err == nil {
		t.Fatal("--attest-no-serves without --apply-cache-trees accepted")
	}
	if reclaimActivated() {
		t.Fatal("rejected flag combination still activated the protocol")
	}
}

func TestPrune_ScopedRunRejectsApplyCacheTrees(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "motw")
	_, ctx := parseCLI(t, []string{"config", "prune", "motw", "--apply-cache-trees"})
	if err := ctx.Run(); err == nil {
		t.Fatal("scoped run with --apply-cache-trees accepted")
	}
}

func TestPrune_ApplyReconcilesIntentMarkerFirst(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "old")
	activateReclaim(t)

	// Interrupted migration: vfs moved, meta not, config not yet renamed.
	seedTreePair(t, "accorder-serve-old", "vfsMeta")
	seedTreePair(t, "accorder-serve-new", "vfs")
	intent := `{"v":1,"oldAlias":"old","newAlias":"new","identities":[{"fromRemote":"accorder-serve-old","toRemote":"accorder-serve-new","hasVFS":true,"hasMeta":true,"roots":["bucket"]}],"ts":"2026-08-17T00:00:00Z"}`
	if err := writeFileDurable(renameIntentPath(), []byte(intent), 0o600); err != nil {
		t.Fatal(err)
	}

	_, ctx := parseCLI(t, []string{"config", "prune", "--apply-cache-trees"})
	var runErr error
	out := captureStdout(t, func() { runErr = ctx.Run() })
	if runErr != nil {
		t.Fatalf("%v\n%s", runErr, out)
	}
	if !strings.Contains(out, "Reconciled an interrupted cache-tree migration.") {
		t.Fatalf("recovery did not run:\n%s", out)
	}
	if !treeExists("vfs", "accorder-serve-new") || !treeExists("vfsMeta", "accorder-serve-new") {
		t.Fatal("migration not completed forward by the apply branch")
	}
	if !aliasExists("new") || aliasExists("old") {
		t.Fatal("config not reconciled")
	}
	if _, err := os.Stat(renameIntentPath()); !os.IsNotExist(err) {
		t.Fatal("intent marker survived reconciliation")
	}
}

func TestPrune_ZeroAliasesStillRunsFilesystemBranch(t *testing.T) {
	testSetup(t)
	activateReclaim(t)
	// Fresh config (no aliases) + an unreconcilable marker: the filesystem
	// branch must RUN (and surface the abort) rather than early-returning
	// "No saved profiles" around it.
	if err := writeFileDurable(renameIntentPath(), []byte(`{"v":1,"oldAlias":"gone","newAlias":"also-gone","identities":[],"ts":"2026-01-01T00:00:00Z"}`), 0o600); err != nil {
		t.Fatal(err)
	}
	_, ctx := parseCLI(t, []string{"config", "prune", "--apply-cache-trees"})
	var runErr error
	captureStdout(t, func() { runErr = ctx.Run() })
	if runErr == nil {
		t.Fatal("filesystem branch skipped: unreconcilable marker not surfaced on a zero-alias config")
	}
}
