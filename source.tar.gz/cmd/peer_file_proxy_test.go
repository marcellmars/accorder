package cmd

import (
	"accorder/pkg/calibre"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

// newPeerReverseProxy forwards /files/<prefix>/… to the peer's self-hosted
// endpoint with the operator's grant as a server-side Bearer token — preserving
// the full path and leaking neither the grant nor the reader's operator cookie.
func TestNewPeerReverseProxy_ForwardsWithBearer(t *testing.T) {
	const grant = "peer-grant-xyz"
	var gotAuth, gotPath, gotCookie string
	peer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		gotAuth, gotPath, gotCookie = r.Header.Get("Authorization"), r.URL.Path, r.Header.Get("Cookie")
		_, _ = io.WriteString(w, "EPUB-BYTES")
	}))
	defer peer.Close()

	proxy := newPeerReverseProxy("alice", peer.URL, grant)
	if proxy == nil {
		t.Fatal("newPeerReverseProxy returned nil for a valid endpoint")
	}
	req := httptest.NewRequest("GET", "/files/alice/book.epub", nil)
	req.Header.Set("Cookie", "op_session=secret") // operator-side; must NOT cross to the peer
	w := httptest.NewRecorder()
	proxy.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Fatalf("status = %d, want 200", w.Code)
	}
	if body, _ := io.ReadAll(w.Result().Body); string(body) != "EPUB-BYTES" {
		t.Errorf("body = %q, want EPUB-BYTES", body)
	}
	if gotAuth != "Bearer "+grant {
		t.Errorf("peer Authorization = %q, want %q", gotAuth, "Bearer "+grant)
	}
	if gotPath != "/files/book.epub" {
		t.Errorf("peer path = %q, want /files/book.epub (operator <prefix> stripped; peer serves flat)", gotPath)
	}
	if gotCookie != "" {
		t.Errorf("reader cookie leaked to peer: %q", gotCookie)
	}
	for k, v := range w.Header() {
		if strings.Contains(strings.Join(v, " "), grant) {
			t.Errorf("grant token leaked in response header %s", k)
		}
	}
}

// An offline peer yields a clean 502, not a hang or a 500.
func TestNewPeerReverseProxy_OfflinePeer502(t *testing.T) {
	proxy := newPeerReverseProxy("ghost", "http://127.0.0.1:1", "tok")
	if proxy == nil {
		t.Fatal("unexpected nil proxy for a syntactically valid endpoint")
	}
	req := httptest.NewRequest("GET", "/files/ghost/x.epub", nil)
	w := httptest.NewRecorder()
	proxy.ServeHTTP(w, req)
	if w.Code != http.StatusBadGateway {
		t.Fatalf("offline peer status = %d, want 502", w.Code)
	}
}

func TestNewPeerReverseProxy_InvalidEndpointNil(t *testing.T) {
	if newPeerReverseProxy("bad", "://nope", "tok") != nil {
		t.Fatal("expected nil proxy for an unparseable endpoint")
	}
}

// peerEndpointTable resolves only active peer members, drops retired (offline)
// ones, ignores non-peers, and reloads when members.json changes — so a peer's
// files appear and disappear with its presence.
func TestPeerEndpointTable_ActiveOnlyAndReload(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "members.json")
	writeReg := func(reg map[string]calibre.LibraryMeta, mtime time.Time) {
		data, _ := json.Marshal(reg)
		if err := os.WriteFile(path, data, 0o644); err != nil {
			t.Fatal(err)
		}
		if err := os.Chtimes(path, mtime, mtime); err != nil {
			t.Fatal(err)
		}
	}

	t1 := time.Unix(1_000_000, 0)
	writeReg(map[string]calibre.LibraryMeta{
		"u-alice": {Prefix: "alice", Kind: "peer", State: "ready", Endpoint: "http://alice:8900", GrantToken: "g1"},
		"u-bob":   {Prefix: "bob", Kind: "peer", State: "retired", Endpoint: "http://bob:8900", GrantToken: "g2"},
		"u-carol": {Prefix: "carol", Kind: "", State: "ready"},
		"u-evil":  {Prefix: "evil", Kind: "peer", State: "ready", Endpoint: "http://127.0.0.1:9", GrantToken: "g3"},
	}, t1)

	table := newPeerEndpointTable(path)
	if table.proxyFor("alice") == nil {
		t.Error("active peer alice should resolve to a proxy")
	}
	if table.proxyFor("bob") != nil {
		t.Error("retired (offline) peer bob must not resolve")
	}
	if table.proxyFor("carol") != nil {
		t.Error("rclone member carol must not resolve as a peer")
	}
	if table.proxyFor("evil") != nil {
		t.Error("loopback peer endpoint must be refused (SSRF guard)")
	}
	if table.proxyFor("nope") != nil {
		t.Error("unknown prefix must not resolve")
	}

	// Alice goes offline → the poller marks her retired in members.json; the table
	// reloads on the mtime change and drops her.
	t2 := t1.Add(time.Hour)
	writeReg(map[string]calibre.LibraryMeta{
		"u-alice": {Prefix: "alice", Kind: "peer", State: "retired", Endpoint: "http://alice:8900", GrantToken: "g1"},
	}, t2)
	if table.proxyFor("alice") != nil {
		t.Error("after alice retired, the table should drop her on reload")
	}
}
