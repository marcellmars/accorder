//go:build !tailscale

package cmd

// Tests for the config-prune-doctor workflow: rot detection (scanAliasRot),
// `config prune` (dry-run + --apply), the `config validate` rot warnings,
// the field-level liveness gates on both propagate functions, and the wf-09
// AfterApply reorder. The fixture (testdata/prune_rot_fixture.json) is a
// sanitized subset of the real 2026-07-05/06 operator backups; {{LIBDIR}}
// placeholders are rewritten to a temp dir so path checks are hermetic and
// the real config is never touched (savedActionAliases override in testSetup).

import (
	"bytes"
	"encoding/json"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	"github.com/tidwall/gjson"
	"github.com/tidwall/sjson"
)

// loadPruneFixture installs the fixture as the test's alias file (with
// {{LIBDIR}} rewritten to a real directory) and returns libDir.
func loadPruneFixture(t *testing.T) string {
	t.Helper()
	libDir := testSetup(t)
	raw, err := os.ReadFile(filepath.Join("testdata", "prune_rot_fixture.json"))
	if err != nil {
		t.Fatalf("read fixture: %v", err)
	}
	content := strings.ReplaceAll(string(raw), "{{LIBDIR}}", libDir)

	// The deliberate non-shadow index-path must exist (dangling is a
	// separate, seeded finding on keys-file).
	if err := os.MkdirAll(filepath.Join(libDir, "other"), 0o755); err != nil {
		t.Fatalf("mkdir other: %v", err)
	}
	if err := os.WriteFile(filepath.Join(libDir, "other", "library_index"), []byte("x"), 0o644); err != nil {
		t.Fatalf("write other index: %v", err)
	}
	// The required-field row (motw.lib.search.index-path) must not trip the
	// dangling-path check either — give it a real file.
	if err := os.MkdirAll(filepath.Join(libDir, "static"), 0o755); err != nil {
		t.Fatalf("mkdir static: %v", err)
	}
	if err := os.WriteFile(filepath.Join(libDir, "static", "library_index"), []byte("x"), 0o644); err != nil {
		t.Fatalf("write static index: %v", err)
	}
	if err := os.WriteFile(savedActionAliases, []byte(content), 0o644); err != nil {
		t.Fatalf("write fixture aliases: %v", err)
	}
	return libDir
}

var pruneFixtureAliases = []string{"aggbuild-asplm", "default", "leaky", "motw", "smoke-ftp"}

func scanFixture(t *testing.T) []rotFinding {
	t.Helper()
	_, ctx := parseCLI(t, []string{"config", "prune"})
	root := kongRootNode(ctx)
	cfg := loadActionAliases()
	var findings []rotFinding
	for _, alias := range pruneFixtureAliases {
		findings = append(findings, scanAliasRot(root, cfg, alias)...)
	}
	return findings
}

// ═══════════════════════════════════════════════════════════════════
// Phase 1: liveness oracle
// ═══════════════════════════════════════════════════════════════════

func TestPrune_TypeHasAliasField(t *testing.T) {
	cases := []struct {
		typ  reflect.Type
		key  string
		live bool
	}{
		{reflect.TypeOf(LibBuildCmd{}), "keys-file", true},          // direct field
		{reflect.TypeOf(LibUploadCmd{}), "keys-file", true},         // embedded GroupS3Credentials
		{reflect.TypeOf(LibBuildCmd{}), "calibrepath", true},        // doubly embedded
		{reflect.TypeOf(LibBuildCmd{}), "s3-access-key", false},     // alias:"-" — excluded
		{reflect.TypeOf(LibUploadCmd{}), "Files", false},            // json:"-" via Go-name match
		{reflect.TypeOf(LibBuildCmd{}), "no-such-flag", false},      // absent
		{reflect.TypeOf(LibShareLiveCmd{}), "dictID", false},        // GroupTorShare has no dictID
		{reflect.TypeOf(LibPublishCmd{}), "dictID", true},           // GroupLib declares dictID
		{reflect.TypeOf(LibIndexDownloadCmd{}), "librarian", false}, // the aggbuild fossil class
	}
	for _, c := range cases {
		if got := typeHasAliasField(c.typ, c.key); got != c.live {
			t.Errorf("typeHasAliasField(%s, %q) = %v, want %v", c.typ.Name(), c.key, got, c.live)
		}
	}
}

// ═══════════════════════════════════════════════════════════════════
// Phase 1: rot collector over the sanitized real-backup fixture — every
// seeded rot class detected, and nothing else flagged.
// ═══════════════════════════════════════════════════════════════════

func TestPrune_DetectsExactlySeededRot(t *testing.T) {
	loadPruneFixture(t)
	findings := scanFixture(t)

	want := map[string]rotKind{
		"aggbuild-asplm|lib.index.download.librarian": rotDeadKey,
		"aggbuild-asplm|lib.index.download.libraryID": rotDeadKey,
		"default|":                       rotEmptyNode,
		"leaky|lib.upload.s3-access-key": rotExcludedKey,
		"motw|fedlib":                    rotEmptyNode,
		"motw|lib.build.index-path":      rotDefaultShadow,
		"motw|lib.build.keys-file":       rotDanglingPath,
		"smoke-ftp|lib.share.funnel":     rotDeadSubtree,
		// index-path genuinely disagrees in the fixture: lib.search points at
		// static/, lib.upload at other/. calibrepath does NOT appear here —
		// it differs only by a trailing slash, which normalizes away.
		"motw|index-path": rotDriftedKey,
	}
	got := make(map[string]rotKind, len(findings))
	for _, f := range findings {
		got[f.Alias+"|"+f.Path] = f.Kind
	}
	for key, kind := range want {
		gk, ok := got[key]
		if !ok {
			t.Errorf("missing finding %s (want kind %d)", key, kind)
			continue
		}
		if gk != kind {
			t.Errorf("finding %s: kind = %d, want %d", key, gk, kind)
		}
	}
	for key, kind := range got {
		if _, ok := want[key]; !ok {
			t.Errorf("unexpected finding %s (kind %d) — live/whitelisted/non-shadow keys must not be flagged", key, kind)
		}
	}
}

// The leaked secret finding must never carry the stored value into reports.
func TestPrune_ExcludedKeyValueNotCaptured(t *testing.T) {
	loadPruneFixture(t)
	for _, f := range scanFixture(t) {
		if f.Kind == rotExcludedKey && f.Value != "" {
			t.Errorf("excluded-key finding %s.%s carries value %q — secret material must not be rendered", f.Alias, f.Path, f.Value)
		}
	}
}

// ═══════════════════════════════════════════════════════════════════
// Phase 2: `config prune` command
// ═══════════════════════════════════════════════════════════════════

func TestPrune_DryRunLeavesFileByteIdentical(t *testing.T) {
	loadPruneFixture(t)
	before, err := os.ReadFile(savedActionAliases)
	if err != nil {
		t.Fatalf("read before: %v", err)
	}
	_, ctx := parseCLI(t, []string{"config", "prune"})
	out := captureStdout(t, func() {
		if err := ctx.Run(); err != nil {
			t.Errorf("dry-run prune: %v", err)
		}
	})
	after, err := os.ReadFile(savedActionAliases)
	if err != nil {
		t.Fatalf("read after: %v", err)
	}
	if !bytes.Equal(before, after) {
		t.Error("dry-run modified the alias file")
	}
	if !strings.Contains(out, "lib.index.download.librarian") {
		t.Errorf("dry-run report missing the aggbuild dead key; got:\n%s", out)
	}
	if !strings.Contains(out, "--apply") {
		t.Errorf("dry-run report missing the --apply hint; got:\n%s", out)
	}
}

func TestPrune_ApplyRoundTrip(t *testing.T) {
	loadPruneFixture(t)
	_, ctx := parseCLI(t, []string{"config", "prune", "--apply"})
	out := captureStdout(t, func() {
		if err := ctx.Run(); err != nil {
			t.Fatalf("prune --apply: %v", err)
		}
	})

	data, err := os.ReadFile(savedActionAliases)
	if err != nil {
		t.Fatalf("read aliases: %v", err)
	}
	if !gjson.ValidBytes(data) {
		t.Fatal("alias file no longer parses after --apply")
	}

	// Deleted: dead keys, shadow, leaked secret, empty nodes.
	for _, gone := range []string{
		"aggbuild-asplm.lib.index.download.librarian",
		"aggbuild-asplm.lib.index.download.libraryID",
		"leaky.lib.upload.s3-access-key",
		"motw.lib.build.index-path",
		"motw.fedlib",
		"default",
	} {
		if gjson.GetBytes(data, gone).Exists() {
			t.Errorf("%s still present after --apply", gone)
		}
	}

	// Intact: live keys, whitelisted side-channel keys, report-only classes.
	for _, kept := range []string{
		"aggbuild-asplm.lib.index.download.pointer-url",
		"leaky.lib.upload.bucket",
		"motw.lib.build.calibrepath",
		"motw.lib.build.librarian",
		"motw.lib.build.keys-file", // dangling path — report-only
		"motw.lib.upload.index-path",
		"smoke-ftp.lib.share.funnel.listen", // unknown subtree — report-only
		"smoke-ftp.lib.browse.endpoint",
		"smoke-ftp.lib.browse.index-descriptions",
		"smoke-ftp.lib.browse.source-label",
	} {
		if !gjson.GetBytes(data, kept).Exists() {
			t.Errorf("%s missing after --apply — over-deletion", kept)
		}
	}

	// Backup written under the operator convention.
	backups, err := filepath.Glob(filepath.Join(accorderConfigDir, "backups", "action_aliases.json.bak-prune-*"))
	if err != nil || len(backups) == 0 {
		t.Errorf("no prune backup found (err=%v)", err)
	}
	if !strings.Contains(out, "Backup:") {
		t.Errorf("apply output missing backup line; got:\n%s", out)
	}

	// Re-scan: only the report-only classes remain.
	var remaining []rotFinding
	for _, f := range scanFixture(t) {
		remaining = append(remaining, f)
	}
	for _, f := range remaining {
		if f.Kind != rotDanglingPath && f.Kind != rotDeadSubtree && f.Kind != rotDriftedKey {
			t.Errorf("deletable finding survived --apply: %s.%s (kind %d)", f.Alias, f.Path, f.Kind)
		}
	}
	// Three report-only findings survive --apply: the dangling keys-file, the
	// unknown funnel subtree, and the index-path drift (lib.search vs
	// lib.upload) — none of which the tool may delete on the operator's behalf.
	if len(remaining) != 3 {
		t.Errorf("expected 3 report-only findings after --apply, got %d: %+v", len(remaining), remaining)
	}
}

func TestPrune_AliasScoping(t *testing.T) {
	loadPruneFixture(t)
	_, ctx := parseCLI(t, []string{"config", "prune", "leaky", "--apply"})
	captureStdout(t, func() {
		if err := ctx.Run(); err != nil {
			t.Fatalf("scoped prune --apply: %v", err)
		}
	})
	data, _ := os.ReadFile(savedActionAliases)
	if gjson.GetBytes(data, "leaky.lib.upload.s3-access-key").Exists() {
		t.Error("scoped prune did not delete the leaked key in scope")
	}
	if !gjson.GetBytes(data, "aggbuild-asplm.lib.index.download.librarian").Exists() {
		t.Error("scoped prune deleted findings outside the requested alias")
	}
	if !gjson.GetBytes(data, "motw.lib.build.index-path").Exists() {
		t.Error("scoped prune deleted a shadow outside the requested alias")
	}

	// Husk cleanup is scoped too: the out-of-scope empty `default` profile
	// and `motw.fedlib` husk survive a prune scoped to `leaky`.
	for _, kept := range []string{"default", "motw.fedlib"} {
		if !gjson.GetBytes(data, kept).Exists() {
			t.Errorf("scoped prune removed out-of-scope empty node %s", kept)
		}
	}
}

func TestPrune_UnknownAliasErrors(t *testing.T) {
	loadPruneFixture(t)
	_, ctx := parseCLI(t, []string{"config", "prune", "no-such-alias"})
	if err := ctx.Run(); err == nil {
		t.Error("expected error for unknown alias")
	}
}

// ═══════════════════════════════════════════════════════════════════
// Phase 3: `config validate` rot warnings (warn-only, exit code unchanged)
// ═══════════════════════════════════════════════════════════════════

func TestAliasValidate_WarnsOnRotButExitsZero(t *testing.T) {
	loadPruneFixture(t)
	_, ctx := parseCLI(t, []string{"config", "validate"})
	var runErr error
	out := captureStdout(t, func() { runErr = ctx.Run() })
	if runErr != nil {
		t.Fatalf("validate over rot-only fixture must not error (rot is warn-only), got: %v", runErr)
	}
	if !strings.Contains(out, "config prune") {
		t.Errorf("validate output missing the prune hint; got:\n%s", out)
	}
	if !strings.Contains(out, "lib.index.download.librarian") {
		t.Errorf("validate output missing dead-key warning; got:\n%s", out)
	}
	if strings.Contains(out, "AKIAEXAMPLESANITIZED") {
		t.Error("validate output leaks the secret value")
	}
}

func TestAliasValidate_BadNameStillErrors(t *testing.T) {
	testSetup(t)
	if err := os.WriteFile(savedActionAliases, []byte(`{"bad name":{"lib":{"build":{"librarian":"x"}}}}`), 0o644); err != nil {
		t.Fatalf("seed: %v", err)
	}
	_, ctx := parseCLI(t, []string{"config", "validate"})
	var runErr error
	captureStdout(t, func() { runErr = ctx.Run() })
	if runErr == nil {
		t.Error("expected error for invalid alias name")
	}
}

// ═══════════════════════════════════════════════════════════════════
// Phase 4: field-level liveness gate on both propagate functions
// ═══════════════════════════════════════════════════════════════════

// (b) propagateSharedField of dictID reaches peers embedding GroupLib but
// not peers that merely share the "lib" group (GroupTorShare, index cmds).
func TestPropagateGate_SharedFieldSkipsNonDeclaringPeers(t *testing.T) {
	testSetup(t)
	_, ctx := parseCLI(t, []string{"config", "prune"})
	root := kongRootNode(ctx)
	buildNode := findNodeByPath(root, "lib.build")
	if buildNode == nil {
		t.Fatal("lib.build node not found")
	}

	cfg := []byte("{}")
	propagateSharedField(root, buildNode, "t", "dictID", 7, "lib", &cfg)
	for _, path := range []string{"t.lib.publish.dictID", "t.lib.upload.dictID"} {
		if !gjson.GetBytes(cfg, path).Exists() {
			t.Errorf("%s missing — live propagation regressed", path)
		}
	}
	for _, path := range []string{"t.lib.share.live.dictID", "t.lib.index.download.dictID"} {
		if gjson.GetBytes(cfg, path).Exists() {
			t.Errorf("%s planted — field-level gate failed (peer does not declare dictID)", path)
		}
	}

	// (c) genuinely shared fields still propagate to declaring peers.
	cfg2 := []byte("{}")
	propagateSharedField(root, buildNode, "t2", "librarian", "Ann", "lib", &cfg2)
	for _, path := range []string{"t2.lib.share.live.librarian", "t2.lib.publish.librarian"} {
		if !gjson.GetBytes(cfg2, path).Exists() {
			t.Errorf("%s missing — existing live propagation must be unchanged", path)
		}
	}
	if gjson.GetBytes(cfg2, "t2.lib.index.download.librarian").Exists() {
		t.Error("t2.lib.index.download.librarian planted — the aggbuild fossil class regrew")
	}
}

// (a) a real grouped save on lib build no longer plants keys onto group
// siblings that do not declare them.
func TestPropagateGate_GroupSaveNoLongerMintsDeadKeys(t *testing.T) {
	libDir := testSetup(t)
	keysFile := filepath.Join(libDir, "gate.s3.keys")
	parseCLI(t, []string{
		"lib", "build", "gatealias",
		"--calibrepath=" + libDir,
		"--librarian=Alice",
		"--libraryID=550e8400-e29b-41d4-a716-446655440000",
		"--keys-file=" + keysFile,
	})

	alias := readAlias(t, "gatealias")

	// keys-file rides propagateGroupField (no sharedgroup tag): declared on
	// upload/publish/download — planted nowhere else.
	for _, path := range []string{"lib.upload.keys-file", "lib.publish.keys-file"} {
		if alias.Get(path).String() != keysFile {
			t.Errorf("%s = %q, want %q — live group propagation regressed", path, alias.Get(path).String(), keysFile)
		}
	}
	for _, path := range []string{"lib.browse.keys-file", "lib.import.keys-file", "lib.index.download.keys-file"} {
		if alias.Get(path).Exists() {
			t.Errorf("%s planted — group-field gate failed", path)
		}
	}

	// The aggbuild fossil class: identity fields must not land on index download.
	for _, path := range []string{"lib.index.download.librarian", "lib.index.download.libraryID"} {
		if alias.Get(path).Exists() {
			t.Errorf("%s planted — shared-field gate failed", path)
		}
	}

	// Existing propagation to declaring peers unchanged.
	if alias.Get("lib.upload.librarian").String() != "Alice" {
		t.Errorf("lib.upload.librarian = %q, want Alice", alias.Get("lib.upload.librarian").String())
	}
}

// ═══════════════════════════════════════════════════════════════════
// Phase 5: wf-09 reorder — failed scoped validation stages no mint;
// flagless runs mint no empty node.
// ═══════════════════════════════════════════════════════════════════

func TestActionAlias_NoMintOnScopedValidationFailure(t *testing.T) {
	libDir := testSetup(t)

	// Seed real content first so byte-identity is meaningful.
	parseCLI(t, []string{
		"lib", "build", "prod",
		"--calibrepath=" + libDir,
		"--librarian=Alice",
		"--libraryID=550e8400-e29b-41d4-a716-446655440000",
	})
	before, err := os.ReadFile(savedActionAliases)
	if err != nil {
		t.Fatalf("read before: %v", err)
	}

	// lib upload has required --bucket: scoped validation fails. (fedlib
	// build's output-path and fedlib share live's aggregate-path requiredness
	// both moved to Run() under descriptor recall, so they no longer fail at
	// parse time.)
	_, _, parseErr := parseCLIErr(t, []string{"lib", "upload", "partial"})
	if parseErr == nil {
		t.Fatal("expected scoped validation error for lib upload without --bucket")
	}

	after, err := os.ReadFile(savedActionAliases)
	if err != nil {
		t.Fatalf("read after: %v", err)
	}
	if !bytes.Equal(before, after) {
		t.Errorf("alias file changed on failed validation (wf-09 criterion 1)\nbefore: %s\nafter:  %s", before, after)
	}
	if gjson.GetBytes(after, "partial").Exists() {
		t.Error("empty node 'partial' minted despite validation failure")
	}
}

func TestActionAlias_NoEmptyNodeOnFlaglessRun(t *testing.T) {
	testSetup(t)
	_, _, err := parseCLIErr(t, []string{"lib", "browse", "ghost"})
	if err != nil {
		t.Fatalf("flagless lib browse parse: %v", err)
	}
	data, err := os.ReadFile(savedActionAliases)
	if err != nil {
		t.Fatalf("read aliases: %v", err)
	}
	if gjson.GetBytes(data, "ghost").Exists() {
		t.Error("flagless run minted an empty 'ghost' node (wf-09 empty-node mint regressed)")
	}
}

// A required field with no computed default (lib search index-path,
// validate:"required") is load-bearing even when its value equals the build
// default — the shadow pass must never flag it (deleting it would break the
// command; regression for the 2026-07-06 real-config dry-run false positive).
func TestPrune_RequiredFieldNeverShadow(t *testing.T) {
	loadPruneFixture(t)
	for _, f := range scanFixture(t) {
		if strings.HasPrefix(f.Path, "motw.lib.search.") {
			t.Errorf("required lib.search.index-path flagged: %+v", f)
		}
	}
}

// A literal junk key containing dots must be deleted AS a literal key —
// unescaped gjson composition would delete the live nested value instead
// (2026-07-07 review: path injection).
func TestPrune_DottedJunkKeyDeletesSafely(t *testing.T) {
	libDir := testSetup(t)
	quoted, _ := json.Marshal(libDir)
	seed := `{"prof":{"lib.build.calibrepath":"junk","lib":{"build":{"calibrepath":` + string(quoted) + `}}}}`
	if err := os.WriteFile(savedActionAliases, []byte(seed), 0o644); err != nil {
		t.Fatal(err)
	}
	_, ctx := parseCLI(t, []string{"config", "prune", "prof", "--apply"})
	_ = captureStdout(t, func() {
		if err := ctx.Run(); err != nil {
			t.Fatalf("prune --apply: %v", err)
		}
	})
	data, _ := os.ReadFile(savedActionAliases)
	if gjson.GetBytes(data, `prof.lib\.build\.calibrepath`).Exists() {
		t.Error("literal junk key survived --apply")
	}
	if !gjson.GetBytes(data, "prof.lib.build.calibrepath").Exists() {
		t.Error("live nested calibrepath was deleted — path injection")
	}
}

// Pretty-printed husks ("{\n }") must be detected and removed — the real
// alias file is pretty-printed; raw=="{}" matching silently no-ops on it
// (2026-07-07 review).
func TestPrune_PrettyPrintedHusksRemoved(t *testing.T) {
	testSetup(t)
	seed := "{\n \"husky\": {\n  \"lib\": {\n   \"import\": {\n   }\n  }\n }\n}"
	if err := os.WriteFile(savedActionAliases, []byte(seed), 0o644); err != nil {
		t.Fatal(err)
	}
	_, ctx := parseCLI(t, []string{"config", "prune", "husky", "--apply"})
	out := captureStdout(t, func() {
		if err := ctx.Run(); err != nil {
			t.Fatalf("prune --apply: %v", err)
		}
	})
	if strings.Contains(out, "No rot found") {
		t.Fatalf("pretty-printed husk not detected; got:\n%s", out)
	}
	data, _ := os.ReadFile(savedActionAliases)
	if gjson.GetBytes(data, "husky").Exists() {
		t.Errorf("husk profile survived --apply; file:\n%s", data)
	}
}

// The Name arg is used as a gjson path; nested paths and wildcards are
// rejected by selected-target validation at parse time (ca-127), spelled
// as the positional <name>. The Run-level guard stays as defense in depth
// for direct construction.
func TestPrune_InvalidNameErrors(t *testing.T) {
	loadPruneFixture(t)
	_, _, err := parseCLIErr(t, []string{"config", "prune", "motw.lib"})
	if err == nil || !strings.Contains(err.Error(), "<name> (alias)") {
		t.Errorf("nested-path name accepted at parse: %v", err)
	}
	_, ctx := parseCLI(t, []string{"config", "prune"})
	direct := &AliasPruneCmd{Name: "motw.lib"}
	if err := direct.Run(ctx); err == nil || !strings.Contains(err.Error(), "invalid profile name") {
		t.Errorf("Run-level guard gone: %v", err)
	}
}

// lib.share.live.index-path equal to the build default is NOT a shadow: in
// S3 mode a non-empty value is the Tier-1 "upload local index" escape hatch
// (2026-07-07 review: behavior-change on delete).
func TestPrune_ShareLiveIndexPathNotShadow(t *testing.T) {
	libDir := loadPruneFixture(t)
	cfg := loadActionAliases()
	cfg, _ = sjson.SetBytes(cfg, "motw.lib.share.live.index-path",
		filepath.Join(libDir, "static", "library_index"))
	if err := os.WriteFile(savedActionAliases, cfg, 0o644); err != nil {
		t.Fatal(err)
	}
	for _, f := range scanFixture(t) {
		if f.Path == "lib.share.live.index-path" && f.Kind == rotDefaultShadow {
			t.Errorf("share live index-path flagged as shadow: %+v", f)
		}
	}
}

// Persisted pre-migration S3 credentials must route through the lossless
// keys-file migration, not be destroyed as leaked-secret findings
// (2026-07-07 review).
func TestPrune_MigratesCredsBeforeApply(t *testing.T) {
	testSetup(t)
	seed := `{"oldy":{"lib":{"upload":{"bucket":"b/p","s3-access-key":"AK","s3-secret-key":"SK","s3-provider":"Wasabi","s3-endpoint":"s3.example.com"}}}}`
	if err := os.WriteFile(savedActionAliases, []byte(seed), 0o644); err != nil {
		t.Fatal(err)
	}
	_, ctx := parseCLI(t, []string{"config", "prune", "oldy", "--apply"})
	out := captureStdout(t, func() {
		if err := ctx.Run(); err != nil {
			t.Fatalf("prune --apply: %v", err)
		}
	})
	if !strings.Contains(out, "Migrated persisted S3 credentials") {
		t.Errorf("migration line missing; got:\n%s", out)
	}
	kf, err := parseKeysFile(filepath.Join(accorderConfigDir, "keys", "oldy.s3.keys"))
	if err != nil || kf.AccessKey != "AK" || kf.SecretKey != "SK" {
		t.Errorf("creds not preserved in keys file: kf=%+v err=%v", kf, err)
	}
	data, _ := os.ReadFile(savedActionAliases)
	if gjson.GetBytes(data, "oldy.lib.upload.s3-access-key").Exists() {
		t.Error("cred key still in alias file after migration")
	}
}
