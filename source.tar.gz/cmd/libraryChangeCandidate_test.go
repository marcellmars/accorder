package cmd

import (
	"bytes"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"accorder/pkg/calibre"
	"accorder/pkg/libraryflow"
	"accorder/pkg/torshare"
)

func TestLibBuildPreservesPublishedGenerationForCandidate(t *testing.T) {
	root := testSetup(t)
	if err := os.WriteFile(filepath.Join(root, "metadata.db"), []byte("catalog"), 0o644); err != nil {
		t.Fatal(err)
	}
	jsonlPath := filepath.Join(root, "books.jsonl")
	f, err := os.Create(jsonlPath)
	if err != nil {
		t.Fatal(err)
	}
	book := generationCandidateBook()
	if err := json.NewEncoder(f).Encode(book); err != nil {
		_ = f.Close()
		t.Fatal(err)
	}
	if err := f.Close(); err != nil {
		t.Fatal(err)
	}
	future := time.Now().Add(time.Second)
	if err := os.Chtimes(jsonlPath, future, future); err != nil {
		t.Fatal(err)
	}
	build := func() {
		t.Helper()
		command := &LibBuildCmd{}
		command.ActionAlias = "preserve-generation"
		command.CalibreDirectory = root
		command.LibraryID = book.LibraryUUID
		command.Librarian = book.Librarian
		command.JsonLPath = jsonlPath
		command.IndexPath = filepath.Join(root, "static", "library_index")
		command.Index = new(bool)
		if err := command.Run(nil); err != nil {
			t.Fatal(err)
		}
	}

	build()
	first, err := loadLocalChangeCandidate(root)
	if err != nil {
		t.Fatal(err)
	}
	mf, err := calibre.ReadExistingManifest(filepath.Join(root, "static", "library_index"))
	if err != nil {
		t.Fatal(err)
	}
	published := torshare.EncodeGeneration(mf.BaseGeneration, 77)
	if err := os.WriteFile(filepath.Join(root, libraryflow.GenerationPath), published, 0o644); err != nil {
		t.Fatal(err)
	}
	if err := saveBaseline("preserve-generation", libraryBaseline{
		LibraryID: book.LibraryUUID, RemoteSourceFingerprint: first.TargetSourceFingerprint,
		LocalSourceFingerprint: first.TargetSourceFingerprint, Generation: 77,
		GenerationToken: hex.EncodeToString(published), CatalogChecksum: first.ToCatalogChecksum,
		ContentLedgerVersion: 1, ContentLedger: first.ContentLedger,
	}); err != nil {
		t.Fatal(err)
	}

	build()
	got, err := os.ReadFile(filepath.Join(root, libraryflow.GenerationPath))
	if err != nil || !bytes.Equal(got, published) {
		t.Fatalf("generation after unchanged build=%x err=%v, want %x", got, err, published)
	}
	second, err := loadLocalChangeCandidate(root)
	if err != nil {
		t.Fatal(err)
	}
	if second.Scope != calibre.GenerationChangeScopeExact || second.FromGeneration != hex.EncodeToString(published) {
		t.Fatalf("second candidate scope=%s from=%s reason=%s", second.Scope, second.FromGeneration, second.Reason)
	}
}

func TestLibBuildRepeatedBeforePublishReusesCheckpoint(t *testing.T) {
	root := testSetup(t)
	metadataPath := filepath.Join(root, "metadata.db")
	if err := os.WriteFile(metadataPath, []byte("catalog"), 0o644); err != nil {
		t.Fatal(err)
	}
	payloadPath := filepath.Join(root, "Author", "Book (1)", "book.epub")
	if err := os.MkdirAll(filepath.Dir(payloadPath), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(payloadPath, []byte("old!"), 0o644); err != nil {
		t.Fatal(err)
	}
	jsonlPath := filepath.Join(root, "books.jsonl")
	f, err := os.Create(jsonlPath)
	if err != nil {
		t.Fatal(err)
	}
	book := generationCandidateBook()
	if err := json.NewEncoder(f).Encode(book); err != nil {
		_ = f.Close()
		t.Fatal(err)
	}
	if err := f.Close(); err != nil {
		t.Fatal(err)
	}
	future := time.Now().Add(time.Second)
	if err := os.Chtimes(jsonlPath, future, future); err != nil {
		t.Fatal(err)
	}

	alias := "repeat-before-publish"
	memberGeneration := generationChangeMemberToken(6)
	if err := os.WriteFile(filepath.Join(root, libraryflow.GenerationPath), memberGeneration, 0o644); err != nil {
		t.Fatal(err)
	}
	if err := saveBaseline(alias, libraryBaseline{
		LibraryID: book.LibraryUUID, RemoteSourceFingerprint: strings.Repeat("a", 64),
		LocalSourceFingerprint: strings.Repeat("a", 64), Generation: 6,
		UpdatedAt: time.Now().UTC().Add(-time.Hour),
	}); err != nil {
		t.Fatal(err)
	}
	indexPath := filepath.Join(root, "static", "library_index")
	newBuild := func() *LibBuildCmd {
		command := &LibBuildCmd{}
		command.ActionAlias = alias
		command.CalibreDirectory = root
		command.LibraryID = book.LibraryUUID
		command.Librarian = book.Librarian
		command.JsonLPath = jsonlPath
		command.IndexPath = indexPath
		command.Index = new(bool)
		return command
	}
	if err := newBuild().Run(nil); err != nil {
		t.Fatal(err)
	}
	first, err := loadLocalChangeCandidate(root)
	if err != nil {
		t.Fatal(err)
	}
	if first.Scope != calibre.GenerationChangeScopeCoarse || first.Reason != "missing-content-baseline" || !first.CompleteOverwrite ||
		first.FromLiveCount == nil || *first.FromLiveCount != 0 || first.ToLiveCount != 1 {
		t.Fatalf("first checkpoint=%+v", first)
	}

	// Give an accidental rebuild an unmistakable timestamp while leaving the
	// candidate usable through its small index-digest verification fallback.
	old := time.Unix(1_700_000_000, 0)
	if err := os.Chtimes(indexPath+".zst", old, old); err != nil {
		t.Fatal(err)
	}
	originalHasher := contentLedgerHashFile
	t.Cleanup(func() { contentLedgerHashFile = originalHasher })
	hashCalls := 0
	contentLedgerHashFile = func(path string, _ func(int64)) (string, error) {
		hashCalls++
		return "", fmt.Errorf("unexpected source rehash: %s", path)
	}
	if err := newBuild().Run(nil); err != nil {
		t.Fatal(err)
	}
	if hashCalls != 0 {
		t.Fatalf("unchanged repeated build hashed %d source files", hashCalls)
	}
	second, err := loadLocalChangeCandidate(root)
	if err != nil {
		t.Fatal(err)
	}
	if second.FromLiveCount == nil || *second.FromLiveCount != 0 || second.ToLiveCount != 1 ||
		second.FromCatalogChecksum != first.FromCatalogChecksum || second.ToCatalogChecksum != first.ToCatalogChecksum {
		t.Fatalf("repeated build lost original transition: first=%+v second=%+v", first, second)
	}
	info, err := os.Stat(indexPath + ".zst")
	if err != nil {
		t.Fatal(err)
	}
	if !info.ModTime().Equal(old) {
		t.Fatalf("unchanged repeated build rewrote index: mtime=%v", info.ModTime())
	}

	// `lib publish` calls this same build pipeline. It must consume the local
	// checkpoint rather than repeat the source scan performed by explicit
	// `lib build`.
	publish := &LibPublishCmd{}
	publish.ActionAlias = alias
	publish.CalibreDirectory = root
	publish.LibraryID = book.LibraryUUID
	publish.Librarian = book.Librarian
	publish.JsonLPath = jsonlPath
	publish.IndexPath = indexPath
	publish.Index = new(bool)
	if _, err := buildPublishCandidate(nil, publish); err != nil {
		t.Fatal(err)
	}
	if hashCalls != 0 {
		t.Fatalf("publish build phase hashed %d unchanged source files", hashCalls)
	}

	// Reuse is only an accelerator. A same-size/same-mtime payload rewrite must
	// return to byte hashing and advance the index generation once, even though
	// its catalog record is unchanged.
	payloadInfo, err := os.Stat(payloadPath)
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(payloadPath, []byte("new!"), 0o644); err != nil {
		t.Fatal(err)
	}
	if err := os.Chtimes(payloadPath, payloadInfo.ModTime(), payloadInfo.ModTime()); err != nil {
		t.Fatal(err)
	}
	hashCalls = 0
	contentLedgerHashFile = func(path string, _ func(int64)) (string, error) {
		hashCalls++
		return hashLocalFile(path)
	}
	if err := newBuild().Run(nil); err != nil {
		t.Fatal(err)
	}
	if hashCalls != 0 {
		t.Fatalf("changed stat identity hashed %d source files, want 0", hashCalls)
	}
	info, err = os.Stat(indexPath + ".zst")
	if err != nil {
		t.Fatal(err)
	}
	if info.ModTime().Equal(old) {
		t.Fatal("payload-only change did not advance the index generation")
	}
}

func TestComposeLocalBuildCandidatePreservesRemoteRelativeChanges(t *testing.T) {
	oldBook := generationCandidateBook()
	middleBook := *oldBook
	middleBook.Title = "Middle title"
	finalBook := middleBook
	finalBook.Title = "Final title"
	addedBook := *oldBook
	addedBook.Id = "00000000-0000-4000-8000-000000000903"
	addedBook.Title = "Added book"
	addedBook.TitleSort = "Added book"
	addedBook.CoverUrl = "Author/Added (2)/cover.jpg"
	addedBook.Formats = []*calibre.File{{Format: "epub", DirectoryPath: "Author/Added (2)", Name: "added.epub", Size: 5}}

	records := func(books ...*calibre.Book) map[string]calibre.CatalogRecordInfo {
		t.Helper()
		result := make(map[string]calibre.CatalogRecordInfo, len(books))
		for _, book := range books {
			info, err := calibre.CatalogRecordInfoForBook(book)
			if err != nil {
				t.Fatal(err)
			}
			result[book.Id] = info
		}
		return result
	}
	diffAB, err := calibre.CompileCatalogDiffFromRecordInfos([]*calibre.Book{&middleBook}, records(oldBook))
	if err != nil {
		t.Fatal(err)
	}
	diffAB.Changes[0].PayloadChanged = true
	diffBC, err := calibre.CompileCatalogDiffFromRecordInfos([]*calibre.Book{&finalBook, &addedBook}, records(&middleBook))
	if err != nil {
		t.Fatal(err)
	}
	fromGeneration := hex.EncodeToString(generationChangeMemberToken(6))
	ledger := []libraryflow.Object{{Path: "metadata.db", Size: 7, Hash: strings.Repeat("a", 64)}}
	prior := localChangeCandidate{
		LibraryUUID: oldBook.LibraryUUID, Scope: calibre.GenerationChangeScopeExact,
		FromGeneration: fromGeneration, FromLiveCount: uint32ptr(diffAB.FromCount),
		FromCatalogChecksum: diffAB.FromChecksum, ToLiveCount: diffAB.ToCount,
		ToCatalogChecksum: diffAB.ToChecksum, Changes: diffAB.Changes,
		ContentLedgerVersion: 1, ContentLedger: ledger,
	}
	delta := localChangeCandidate{
		LibraryUUID: oldBook.LibraryUUID, Scope: calibre.GenerationChangeScopeExact,
		FromGeneration: fromGeneration, FromLiveCount: uint32ptr(diffBC.FromCount),
		FromCatalogChecksum: diffBC.FromChecksum, ToLiveCount: diffBC.ToCount,
		ToCatalogChecksum: diffBC.ToChecksum, Changes: diffBC.Changes,
		ContentLedgerVersion: 1, ContentLedger: ledger,
	}
	combined, err := composeLocalBuildCandidate(prior, delta)
	if err != nil {
		t.Fatal(err)
	}
	if combined.FromLiveCount == nil || *combined.FromLiveCount != diffAB.FromCount ||
		combined.ToLiveCount != diffBC.ToCount || combined.FromCatalogChecksum != diffAB.FromChecksum ||
		combined.ToCatalogChecksum != diffBC.ToChecksum || len(combined.Changes) != 2 {
		t.Fatalf("combined transition=%+v", combined)
	}
	for _, change := range combined.Changes {
		if change.ID == oldBook.Id {
			if change.Kind != "edited" || change.OldRecordDigest != diffAB.Changes[0].OldRecordDigest ||
				change.NewRecordDigest != diffBC.Changes[0].NewRecordDigest || !change.PayloadChanged {
				t.Fatalf("combined edit=%+v", change)
			}
		}
	}
}

func TestContentLedgerDetectsSameSizeSameMtimeRewrite(t *testing.T) {
	root := t.TempDir()
	path := filepath.Join(root, "Author", "Book (1)", "book.epub")
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		t.Fatal(err)
	}
	stamp := time.Unix(1_700_000_000, 123_000_000)
	if err := os.WriteFile(path, []byte("old!"), 0o644); err != nil {
		t.Fatal(err)
	}
	if err := os.Chtimes(path, stamp, stamp); err != nil {
		t.Fatal(err)
	}
	objects := []libraryflow.Object{localObjectForTest(t, root, path)}
	first, changed, _, err := buildContentLedger(root, objects, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	if len(changed) != 1 {
		t.Fatalf("initial changed paths = %v", changed)
	}

	if err := os.WriteFile(path, []byte("new!"), 0o644); err != nil {
		t.Fatal(err)
	}
	if err := os.Chtimes(path, stamp, stamp); err != nil {
		t.Fatal(err)
	}
	objects = []libraryflow.Object{localObjectForTest(t, root, path)}
	second, changed, _, err := buildContentLedger(root, objects, nil, first)
	if err != nil {
		t.Fatal(err)
	}
	if len(changed) != 1 || changed[0] != "Author/Book (1)/book.epub" {
		t.Fatalf("same-size/same-mtime changed paths = %v", changed)
	}
	if first[0].Hash == second[0].Hash {
		t.Fatal("content digest did not change")
	}
}

func TestLegacyBaselineUpgradeForcesOnlyPostBaselinePaths(t *testing.T) {
	base := [16]byte{1}
	prior := hex.EncodeToString(torshare.EncodeGeneration(base, 6))
	cutoff := time.Now().UTC().Add(-time.Hour)
	baseline := &libraryBaseline{
		LibraryID:               "550e8400-e29b-41d4-a716-446655440000",
		RemoteSourceFingerprint: strings.Repeat("a", 64),
		LocalSourceFingerprint:  strings.Repeat("a", 64),
		Generation:              6, UpdatedAt: cutoff,
	}
	ledger := []libraryflow.Object{
		{Path: "Author/Old (1)/old.epub", Size: 1, ModTime: cutoff.Add(-time.Hour), ChangeTime: cutoff.Add(-time.Hour).UnixNano(), Hash: strings.Repeat("b", 64)},
		{Path: "Author/New (2)/new.epub", Size: 1, ModTime: cutoff.Add(time.Minute), ChangeTime: cutoff.Add(time.Minute).UnixNano(), Hash: strings.Repeat("c", 64)},
	}
	changed, ok := legacyBaselineUpgradeChanges(baseline, prior, ledger)
	if !ok || len(changed) != 1 || changed[0] != "Author/New (2)/new.epub" {
		t.Fatalf("changed=%v ok=%t", changed, ok)
	}
	ledger[0].ChangeTime = 0
	if _, ok := legacyBaselineUpgradeChanges(baseline, prior, ledger); ok {
		t.Fatal("filesystem without change time unexpectedly qualified for bounded upgrade")
	}
}

func TestContentLedgerReusesOnlyTrustworthyStatIdentity(t *testing.T) {
	root := t.TempDir()
	path := filepath.Join(root, "metadata.db")
	if err := os.WriteFile(path, []byte("catalog"), 0o644); err != nil {
		t.Fatal(err)
	}
	current := localObjectForTest(t, root, path)
	first, _, _, err := buildContentLedger(root, []libraryflow.Object{current}, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	second, changed, _, err := buildContentLedger(root, []libraryflow.Object{current}, nil, first)
	if err != nil {
		t.Fatal(err)
	}
	if len(changed) != 0 || second[0].Hash != first[0].Hash {
		t.Fatalf("unchanged ledger = %#v, changed = %v", second, changed)
	}

	withoutChangeTime := current
	withoutChangeTime.ChangeTime = 0
	third, changed, _, err := buildContentLedger(root, []libraryflow.Object{withoutChangeTime}, nil, first)
	if err != nil {
		t.Fatal(err)
	}
	if len(changed) != 0 || third[0].Hash != first[0].Hash {
		t.Fatalf("rehash fallback changed bytes: ledger = %#v, changed = %v", third, changed)
	}
}

func TestContentLedgerReportsHashAndReuseProgress(t *testing.T) {
	root := t.TempDir()
	paths := []string{
		filepath.Join(root, "Author", "First (1)", "first.epub"),
		filepath.Join(root, "Author", "Second (2)", "second.epub"),
	}
	for index, path := range paths {
		if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(path, bytes.Repeat([]byte{byte('a' + index)}, index+3), 0o644); err != nil {
			t.Fatal(err)
		}
	}
	objects := []libraryflow.Object{
		localObjectForTest(t, root, paths[0]),
		localObjectForTest(t, root, paths[1]),
	}
	previous, _, _, err := buildContentLedger(root, objects, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	objects[1].ChangeTime = 0
	var updates []contentLedgerProgress
	_, _, _, err = buildContentLedgerWithProgress(root, objects, nil, previous, func(progress contentLedgerProgress) {
		updates = append(updates, progress)
	})
	if err != nil {
		t.Fatal(err)
	}
	if len(updates) < 3 {
		t.Fatalf("progress updates=%d, want initial plan, byte progress, and hashed-file completion", len(updates))
	}
	initial, final := updates[0], updates[len(updates)-1]
	if initial.TotalFiles != 2 || initial.HashFiles != 1 || initial.ReusedFiles != 1 || initial.HashBytes != objects[1].Size {
		t.Fatalf("initial checksum progress=%+v", initial)
	}
	if final.HashedFiles != 1 || final.HashedBytes != objects[1].Size {
		t.Fatalf("final checksum progress=%+v", final)
	}
}

func TestLibUploadDryRunMissingCandidateRequiresBuild(t *testing.T) {
	command := &LibUploadCmd{
		GroupLib: GroupLib{GroupLibDir: GroupLibDir{CalibreDirectory: t.TempDir()}},
		DryRun:   true,
	}
	command.ActionAlias = "VirtueTheCat"
	_, _, err := command.prepareUploadCandidate(nil, nil)
	if err == nil || !strings.Contains(err.Error(), "accorder lib build VirtueTheCat") {
		t.Fatalf("missing-candidate dry-run guidance=%v", err)
	}
	if strings.Contains(err.Error(), "allow-full-reupload") {
		t.Fatalf("missing-candidate guidance suggests unsafe bypass: %v", err)
	}
}

func TestCandidateWithNewBookRequiresBuildWithoutLegacyFullRehash(t *testing.T) {
	root := t.TempDir()
	for path, body := range map[string]string{
		"metadata.db":                        "metadata",
		"Author/Existing (1)/book.epub":      "payload",
		"static/library_index.zst":           "index",
		"static/library_index.jsonl.zst":     "jsonl",
		"static/library_index.manifest.json": "{}",
	} {
		fullPath := filepath.Join(root, filepath.FromSlash(path))
		if err := os.MkdirAll(filepath.Dir(fullPath), 0o755); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(fullPath, []byte(body), 0o644); err != nil {
			t.Fatal(err)
		}
	}
	objects, err := listLocalObjects(root)
	if err != nil {
		t.Fatal(err)
	}
	ledger, _, _, err := buildContentLedger(root, objects, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	fingerprint, err := sourceFingerprintFromContentLedger(ledger)
	if err != nil {
		t.Fatal(err)
	}
	indexPath := filepath.Join(root, "static", "library_index.zst")
	indexInfo, err := os.Stat(indexPath)
	if err != nil {
		t.Fatal(err)
	}
	indexArtifact := libraryflow.NewLocalObjectAt("static/library_index.zst", indexPath, indexInfo)
	indexArtifact.Hash, err = hashLocalFile(indexPath)
	if err != nil {
		t.Fatal(err)
	}
	change := localChangeCandidate{
		Version: localChangeCandidateVersion, LibraryUUID: "550e8400-e29b-41d4-a716-446655440000",
		Scope: calibre.GenerationChangeScopeCoarse, Reason: "test-baseline",
		TargetSourceFingerprint: fingerprint, ToLiveCount: 1,
		ToCatalogChecksum:    strings.Repeat("a", 64),
		ContentLedgerVersion: 1, ContentLedger: ledger, IndexArtifact: indexArtifact,
	}
	if err := saveLocalChangeCandidate(root, change); err != nil {
		t.Fatal(err)
	}
	newPath := filepath.Join(root, "Author", "New Book (2)", "new.epub")
	if err := os.MkdirAll(filepath.Dir(newPath), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(newPath, []byte("new payload"), 0o644); err != nil {
		t.Fatal(err)
	}

	originalHasher := contentLedgerHashFile
	t.Cleanup(func() { contentLedgerHashFile = originalHasher })
	hashCalls := 0
	contentLedgerHashFile = func(path string, _ func(int64)) (string, error) {
		hashCalls++
		return "", fmt.Errorf("unexpected checksum before build: %s", path)
	}
	fresh, err := captureExistingCandidate(root, nil)
	if err != nil {
		t.Fatal(err)
	}
	if hashCalls != 0 {
		t.Fatalf("stale candidate hashed %d files before asking for a build", hashCalls)
	}
	if fresh.Change != nil {
		t.Fatal("candidate remained attached after a new book was added")
	}
	command := &LibUploadCmd{
		GroupLib: GroupLib{GroupLibDir: GroupLibDir{CalibreDirectory: root}},
		DryRun:   true,
	}
	command.ActionAlias = "VirtueTheCat"
	if _, _, err := command.prepareUploadCandidate(nil, nil); err == nil || !strings.Contains(err.Error(), "lib build VirtueTheCat") {
		t.Fatalf("stale-candidate dry-run guidance=%v", err)
	}
}

func TestLibBuildLedgerUsesNewPrivateExcludeSet(t *testing.T) {
	root := testSetup(t)
	if err := os.WriteFile(filepath.Join(root, "metadata.db"), []byte("catalog"), 0o644); err != nil {
		t.Fatal(err)
	}
	payloadPath := filepath.Join(root, "Author", "Book (1)", "book.epub")
	if err := os.MkdirAll(filepath.Dir(payloadPath), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(payloadPath, []byte("now public"), 0o644); err != nil {
		t.Fatal(err)
	}
	if err := writeUploadExcludes(root, []string{"/Author/Book (1)/**"}); err != nil {
		t.Fatal(err)
	}

	jsonlPath := filepath.Join(root, "books.jsonl")
	f, err := os.Create(jsonlPath)
	if err != nil {
		t.Fatal(err)
	}
	book := generationCandidateBook()
	if err := json.NewEncoder(f).Encode(book); err != nil {
		_ = f.Close()
		t.Fatal(err)
	}
	if err := f.Close(); err != nil {
		t.Fatal(err)
	}
	future := time.Now().Add(time.Second)
	if err := os.Chtimes(jsonlPath, future, future); err != nil {
		t.Fatal(err)
	}

	command := &LibBuildCmd{}
	command.ActionAlias = "private-to-public"
	command.CalibreDirectory = root
	command.LibraryID = book.LibraryUUID
	command.Librarian = book.Librarian
	command.JsonLPath = jsonlPath
	command.IndexPath = filepath.Join(root, "static", "library_index")
	command.Index = new(bool)
	if err := command.Run(nil); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(filepath.Join(root, uploadExcludesFile)); !os.IsNotExist(err) {
		t.Fatalf("old private exclusion was not cleared: %v", err)
	}
	candidate, err := loadLocalChangeCandidate(root)
	if err != nil {
		t.Fatal(err)
	}
	for _, object := range candidate.ContentLedger {
		if object.Path == "Author/Book (1)/book.epub" {
			return
		}
	}
	t.Fatalf("newly public payload is absent from candidate ledger: %+v", candidate.ContentLedger)
}

func TestCompileLocalChangeCandidatePayloadOnlyExact(t *testing.T) {
	book := generationCandidateBook()
	priorInfo, err := calibre.CatalogRecordInfoForBook(book)
	if err != nil {
		t.Fatal(err)
	}
	diff, err := calibre.CompileCatalogDiffFromRecordInfos([]*calibre.Book{book}, map[string]calibre.CatalogRecordInfo{book.Id: priorInfo})
	if err != nil {
		t.Fatal(err)
	}
	priorGeneration := hex.EncodeToString(generationChangeMemberToken(1))
	ledger := []libraryflow.Object{
		{Path: "Author/Book (1)/book.epub", Size: 4, Hash: strings.Repeat("a", 64)},
		{Path: "Author/Book (1)/cover.jpg", Size: 4, Hash: strings.Repeat("b", 64)},
		{Path: "metadata.db", Size: 4, Hash: strings.Repeat("c", 64)},
	}
	baseline := &libraryBaseline{
		GenerationToken: priorGeneration, CatalogChecksum: diff.FromChecksum,
		ContentLedgerVersion: 1, ContentLedger: ledger,
	}
	candidate := compileLocalChangeCandidate(
		book.LibraryUUID, priorGeneration, strings.Repeat("d", 64), diff, ledger,
		[]string{"Author/Book (1)/book.epub"}, nil, baseline,
	)
	candidate.IndexArtifact = libraryflow.Object{
		Path: "static/library_index.zst", Size: 1, Hash: strings.Repeat("f", 64),
	}
	if candidate.Scope != calibre.GenerationChangeScopeExact || candidate.CompleteOverwrite {
		t.Fatalf("candidate scope=%s complete=%v reason=%s", candidate.Scope, candidate.CompleteOverwrite, candidate.Reason)
	}
	if len(candidate.Changes) != 1 || candidate.Changes[0].Kind != "edited" || !candidate.Changes[0].PayloadChanged || candidate.Changes[0].OldRecordDigest != candidate.Changes[0].NewRecordDigest {
		t.Fatalf("payload-only changes=%+v", candidate.Changes)
	}
	wantPaths := []string{"Author/Book (1)/book.epub", "Author/Book (1)/cover.jpg"}
	for _, want := range wantPaths {
		if !containsString(candidate.ForcePaths, want) {
			t.Fatalf("force paths %v do not contain %q", candidate.ForcePaths, want)
		}
	}
	if err := candidate.validate(); err != nil {
		t.Fatal(err)
	}
}

func TestCompileLocalChangeCandidateAmbiguousPayloadIsCoarse(t *testing.T) {
	book := generationCandidateBook()
	priorInfo, err := calibre.CatalogRecordInfoForBook(book)
	if err != nil {
		t.Fatal(err)
	}
	diff, err := calibre.CompileCatalogDiffFromRecordInfos([]*calibre.Book{book}, map[string]calibre.CatalogRecordInfo{book.Id: priorInfo})
	if err != nil {
		t.Fatal(err)
	}
	priorGeneration := hex.EncodeToString(generationChangeMemberToken(1))
	baseline := &libraryBaseline{GenerationToken: priorGeneration, CatalogChecksum: diff.FromChecksum, ContentLedgerVersion: 1}
	candidate := compileLocalChangeCandidate(
		book.LibraryUUID, priorGeneration, strings.Repeat("d", 64), diff, nil,
		[]string{"Unknown/Tree/payload.bin"}, nil, baseline,
	)
	if candidate.Scope != calibre.GenerationChangeScopeCoarse || !candidate.CompleteOverwrite || candidate.Reason != "unmapped-payload-change" {
		t.Fatalf("candidate=%+v", candidate)
	}
}

func TestLocalChangeCandidateRejectsProtectedForcePath(t *testing.T) {
	candidate := localChangeCandidate{
		Version: localChangeCandidateVersion, LibraryUUID: "00000000-0000-4000-8000-000000000902",
		Scope: calibre.GenerationChangeScopeCoarse, Reason: "test",
		TargetSourceFingerprint: strings.Repeat("d", 64), ToCatalogChecksum: strings.Repeat("e", 64),
		ForcePaths: []string{libraryflow.GenerationPath}, ContentLedgerVersion: 1,
		ContentLedger: []libraryflow.Object{{Path: libraryflow.GenerationPath, Hash: strings.Repeat("a", 64)}},
		IndexArtifact: libraryflow.Object{Path: "static/library_index.zst", Hash: strings.Repeat("b", 64)},
	}
	if err := candidate.validate(); err == nil || !strings.Contains(err.Error(), "not a publishable library file") {
		t.Fatalf("protected force candidate validation error=%v", err)
	}
}

func TestLoadBaselineRejectsInvalidReusableLedger(t *testing.T) {
	testSetup(t)
	if err := saveBaseline("invalid-ledger", libraryBaseline{
		LibraryID:               "00000000-0000-4000-8000-000000000902",
		RemoteSourceFingerprint: strings.Repeat("a", 64), LocalSourceFingerprint: strings.Repeat("a", 64),
		Generation: 1, GenerationToken: hex.EncodeToString(generationChangeMemberToken(1)),
		CatalogChecksum: strings.Repeat("b", 64), ContentLedgerVersion: 1,
		ContentLedger: []libraryflow.Object{{Path: libraryflow.GenerationPath, Hash: strings.Repeat("c", 64)}},
	}); err != nil {
		t.Fatal(err)
	}
	if _, err := loadBaseline("invalid-ledger"); err == nil || !strings.Contains(err.Error(), "not a publishable library file") {
		t.Fatalf("invalid reusable ledger load error=%v", err)
	}
}

func TestCandidateCarryForwardUsesFinalFederationProjection(t *testing.T) {
	book := generationCandidateBook()
	book.BaseURL, book.LibraryUrl = calibre.FilesBaseURL("member")
	prior, err := calibre.CatalogRecordInfoForBook(book)
	if err != nil {
		t.Fatal(err)
	}
	book.CoverFingerprint = ""
	current, err := calibre.CatalogRecordInfoForBook(book)
	if err != nil {
		t.Fatal(err)
	}
	carried := candidateCarryForward(
		map[string]calibre.CatalogRecordInfo{book.Id: prior},
		map[string]calibre.CatalogRecordInfo{book.Id: current}, nil,
	)
	if carried[book.Id] != prior.CoverFingerprint {
		t.Fatalf("carried fingerprint=%q, want %q", carried[book.Id], prior.CoverFingerprint)
	}
}

func TestGenerationChangeReasonsHavePlainLanguageExplanations(t *testing.T) {
	tests := map[string]string{
		"legacy-content-baseline-upgrade": "older Accorder version",
		"missing-content-baseline":        "no saved file-change history",
		"unmapped-payload-change":         "could not be matched to books",
		"remote-predecessor-mismatch":     "remote library changed",
	}
	for reason, want := range tests {
		details := generationChangeReasonDetails(reason)
		if !strings.Contains(details, want) || !strings.Contains(details, "diagnostic: "+reason) {
			t.Errorf("generationChangeReasonDetails(%q) = %q, want plain explanation containing %q and diagnostic code", reason, details, want)
		}
	}
}

func generationCandidateBook() *calibre.Book {
	return &calibre.Book{
		Abstract: "", Authors: []string{"Author"}, LibraryUrl: "library",
		CoverUrl: "Author/Book (1)/cover.jpg", Formats: []*calibre.File{{
			Format: "epub", DirectoryPath: "Author/Book (1)", Name: "book.epub", Size: 4,
		}},
		Id: "00000000-0000-4000-8000-000000000901", Identifiers: []*calibre.Identifier{},
		Languages: []string{}, LastModified: "2026-09-03T00:00:00Z",
		Librarian: "member", LibraryUUID: "00000000-0000-4000-8000-000000000902",
		Pubdate: "", Publisher: "", Series: "", Tags: []string{}, Title: "Book", TitleSort: "Book",
		CoverFingerprint: "fingerprint",
	}
}

func containsString(values []string, want string) bool {
	for _, value := range values {
		if value == want {
			return true
		}
	}
	return false
}

func localObjectForTest(t *testing.T, root, path string) libraryflow.Object {
	t.Helper()
	info, err := os.Stat(path)
	if err != nil {
		t.Fatal(err)
	}
	rel, err := filepath.Rel(root, path)
	if err != nil {
		t.Fatal(err)
	}
	return libraryflow.NewLocalObjectAt(filepath.ToSlash(rel), path, info)
}
