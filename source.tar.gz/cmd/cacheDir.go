package cmd

import "path/filepath"

func accorderCacheDir() string {
	return filepath.Join(accorderConfigDir, "cache")
}
