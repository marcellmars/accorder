package cmd

import (
	"accorder/pkg/calibre"
	"accorder/pkg/torshare"
	"bufio"
	"context"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"

	"github.com/goccy/go-json"
)

// ---------- helpers (reuse production primitives per spike_validation_coverage rule 6) ----------

// spikeSeedBooks generates n books with deterministic UUIDs for spike tests.
func spikeSeedBooks(n int) []*calibre.Book {
	titles := []string{
		"The Art of Programming",
		"Discourse Networks, 1800/1900",
		"A Brief History of Time",
		"Capital in the Twenty-First Century",
		"Critique of Pure Reason",
	}
	authors := [][]string{
		{"Donald Knuth"},
		{"Friedrich Kittler"},
		{"Stephen Hawking"},
		{"Thomas Piketty"},
		{"Immanuel Kant"},
	}
	tags := [][]string{
		{"computer science", "algorithms"},
		{"media theory", "german literature"},
		{"physics", "cosmology"},
		{"economics", "inequality"},
		{"philosophy", "epistemology"},
	}
	books := make([]*calibre.Book, n)
	for i := range n {
		idx := i % len(titles)
		books[i] = &calibre.Book{
			Title:        titles[idx],
			Authors:      authors[idx],
			Tags:         tags[idx],
			Id:           fmt.Sprintf("00000000-0000-4000-8000-spike%06d", i),
			LastModified: fmt.Sprintf("2024-01-%02dT00:00:00+00:00", (i%28)+1),
			LibraryUUID:  "spike-lib-uuid",
			Librarian:    "spikelib",
		}
	}
	return books
}

// spikeWriteJSONL writes books to a JSONL file and returns its path.
func spikeWriteJSONL(t *testing.T, books []*calibre.Book, dir, name string) string {
	t.Helper()
	path := filepath.Join(dir, name)
	f, err := os.Create(path)
	if err != nil {
		t.Fatalf("create jsonl: %v", err)
	}
	defer f.Close()
	w := bufio.NewWriter(f)
	defer w.Flush()
	for _, b := range books {
		data, _ := json.Marshal(b)
		_, _ = w.Write(data)
		_ = w.WriteByte('\n')
	}
	return path
}

// buildMinimalIndex creates a minimal MWSC container in dir/static/library_index.zst
// and a _GENERATION sentinel in dir/_GENERATION, returning the book count.
func buildMinimalIndex(t *testing.T, dir string) int {
	t.Helper()
	staticDir := filepath.Join(dir, "static")
	if err := os.MkdirAll(staticDir, 0o755); err != nil {
		t.Fatalf("mkdir static: %v", err)
	}

	books := spikeSeedBooks(10)
	jsonlPath := spikeWriteJSONL(t, books, dir, "books.jsonl")

	indexPath := filepath.Join(dir, "idx")
	ms := &calibre.MotwSearch{JsonlPath: jsonlPath, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex: %v", err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatalf("CompressToFile: %v", err)
	}

	// Copy .zst to the path http.FileServer expects.
	src := indexPath + ".zst"
	dst := filepath.Join(staticDir, "library_index.zst")
	data, err := os.ReadFile(src)
	if err != nil {
		t.Fatalf("read zst: %v", err)
	}
	if err := os.WriteFile(dst, data, 0o644); err != nil {
		t.Fatalf("write zst: %v", err)
	}

	// Write _GENERATION sentinel.
	mf, err := calibre.ReadExistingManifest(indexPath)
	if err != nil {
		t.Fatalf("ReadExistingManifest: %v", err)
	}
	genBytes := torshare.EncodeGeneration(mf.BaseGeneration, mf.Generation)
	if err := os.WriteFile(filepath.Join(dir, "_GENERATION"), genBytes, 0o644); err != nil {
		t.Fatalf("write _GENERATION: %v", err)
	}

	return len(books)
}

// ---------- A1: index-artifact routes serve a fetchable MWSC container ----------

func TestSpike_A1_IndexArtifactFetchAndParse(t *testing.T) {
	dir := t.TempDir()
	bookCount := buildMinimalIndex(t, dir)

	// Wire the artifact routes on an httptest.Server — same wiring as libShareLive.runLocal (public mode).
	mux := http.NewServeMux()
	fileServer := http.FileServer(http.Dir(dir))
	registerIndexArtifactRoutes(mux, fileServer, nil) // no auth (public mode)
	srv := httptest.NewServer(mux)
	defer srv.Close()

	// 1. Fetch _GENERATION — assert 24 bytes.
	resp, err := http.Get(srv.URL + "/_GENERATION")
	if err != nil {
		t.Fatalf("GET /_GENERATION: %v", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		t.Fatalf("GET /_GENERATION: status %d", resp.StatusCode)
	}
	genData, _ := io.ReadAll(resp.Body)
	if len(genData) != 24 {
		t.Fatalf("_GENERATION: expected 24 bytes, got %d", len(genData))
	}
	base, gen, err := torshare.DecodeGeneration(genData)
	if err != nil {
		t.Fatalf("DecodeGeneration: %v", err)
	}
	t.Logf("_GENERATION: base=%x gen=%d", base, gen)

	// 2. Fetch /static/library_index.zst — write to temp file.
	resp2, err := http.Get(srv.URL + "/static/library_index.zst")
	if err != nil {
		t.Fatalf("GET /static/library_index.zst: %v", err)
	}
	defer resp2.Body.Close()
	if resp2.StatusCode != 200 {
		t.Fatalf("GET /static/library_index.zst: status %d", resp2.StatusCode)
	}
	fetchedDir := t.TempDir()
	fetchedIndex := filepath.Join(fetchedDir, "fetched")
	fetchedZst := fetchedIndex + ".zst"
	zstData, _ := io.ReadAll(resp2.Body)
	if len(zstData) == 0 {
		t.Fatal("fetched library_index.zst is empty")
	}
	if err := os.WriteFile(fetchedZst, zstData, 0o644); err != nil {
		t.Fatalf("write fetched zst: %v", err)
	}

	// 3. Parse the fetched container with AllBooksFromIndex — the critical round-trip.
	allBooks, err := calibre.AllBooksFromIndex(fetchedIndex)
	if err != nil {
		t.Fatalf("AllBooksFromIndex: %v", err)
	}
	if len(allBooks) != bookCount {
		t.Fatalf("AllBooksFromIndex: expected %d books, got %d", bookCount, len(allBooks))
	}
	t.Logf("AllBooksFromIndex returned %d books — MWSC round-trip intact", len(allBooks))

	// 4. Also verify we can Open and Search (deeper than AllBooksFromIndex).
	ms := &calibre.MotwSearch{IndexPath: fetchedIndex}
	opened, err := ms.Open()
	if err != nil {
		t.Fatalf("Open: %v", err)
	}
	defer opened.Close()
	results, stats, err := opened.Search(context.Background(),
		calibre.SearchQuery{Field: calibre.FieldTitle, Text: "the"},
		calibre.SearchOptions{})
	if err != nil {
		t.Fatalf("Search: %v", err)
	}
	t.Logf("Search 'the': %d results, %d segments scanned", len(results), stats.SegmentsCandidate)
}

// ---------- A2: grant token authenticates artifact routes ----------

func TestSpike_A2_GrantBearerAuthArtifactRoutes(t *testing.T) {
	dir := t.TempDir()
	buildMinimalIndex(t, dir)

	// Set up a grant registry in a temp state dir.
	authStateDir := filepath.Join(t.TempDir(), "auth-state")
	reg, err := newGrantRegistry(authStateDir)
	if err != nil {
		t.Fatalf("newGrantRegistry: %v", err)
	}

	// Issue a grant — this is the production primitive.
	token, err := reg.issue("test-operator", nil)
	if err != nil {
		t.Fatalf("issue grant: %v", err)
	}

	// Wire artifact routes with auth middleware (offline-private mode).
	mux := http.NewServeMux()
	fileServer := http.FileServer(http.Dir(dir))
	registerIndexArtifactRoutes(mux, fileServer, func(h http.Handler) http.Handler {
		return withAuth(h, reg)
	})
	srv := httptest.NewServer(mux)
	defer srv.Close()

	// Sub-test 1: Unauthorized request → 401.
	t.Run("unauthorized_rejected", func(t *testing.T) {
		resp, err := http.Get(srv.URL + "/_GENERATION")
		if err != nil {
			t.Fatalf("GET: %v", err)
		}
		resp.Body.Close()
		if resp.StatusCode != http.StatusUnauthorized {
			t.Fatalf("expected 401, got %d", resp.StatusCode)
		}
	})

	// Sub-test 2: Forged token → 401.
	t.Run("forged_token_rejected", func(t *testing.T) {
		client := newBrowseClearnetHTTPClient("forged-token-value", "")
		resp, err := client.Get(srv.URL + "/_GENERATION")
		if err != nil {
			t.Fatalf("GET: %v", err)
		}
		resp.Body.Close()
		if resp.StatusCode != http.StatusUnauthorized {
			t.Fatalf("expected 401, got %d", resp.StatusCode)
		}
	})

	// Sub-test 3: Valid grant token → 200 + correct _GENERATION body.
	t.Run("valid_grant_authorized", func(t *testing.T) {
		client := newBrowseClearnetHTTPClient(token, "")
		resp, err := client.Get(srv.URL + "/_GENERATION")
		if err != nil {
			t.Fatalf("GET: %v", err)
		}
		defer resp.Body.Close()
		if resp.StatusCode != http.StatusOK {
			t.Fatalf("expected 200, got %d", resp.StatusCode)
		}
		body, _ := io.ReadAll(resp.Body)
		if len(body) != 24 {
			t.Fatalf("expected 24 bytes, got %d", len(body))
		}
	})

	// Sub-test 4: Valid token fetches the full .zst and it parses.
	t.Run("valid_grant_full_index_fetch", func(t *testing.T) {
		client := newBrowseClearnetHTTPClient(token, "")
		resp, err := client.Get(srv.URL + "/static/library_index.zst")
		if err != nil {
			t.Fatalf("GET: %v", err)
		}
		defer resp.Body.Close()
		if resp.StatusCode != http.StatusOK {
			t.Fatalf("expected 200, got %d", resp.StatusCode)
		}
		zstData, _ := io.ReadAll(resp.Body)
		fetchedDir := t.TempDir()
		fetchedIndex := filepath.Join(fetchedDir, "fetched")
		if err := os.WriteFile(fetchedIndex+".zst", zstData, 0o644); err != nil {
			t.Fatalf("write: %v", err)
		}
		books, err := calibre.AllBooksFromIndex(fetchedIndex)
		if err != nil {
			t.Fatalf("AllBooksFromIndex: %v", err)
		}
		if len(books) == 0 {
			t.Fatal("AllBooksFromIndex returned 0 books")
		}
		t.Logf("authenticated fetch → %d books parsed successfully", len(books))
	})

	// Sub-test 5: Revoked grant → 401.
	t.Run("revoked_grant_rejected", func(t *testing.T) {
		if err := reg.revoke("test-operator"); err != nil {
			t.Fatalf("revoke: %v", err)
		}
		client := newBrowseClearnetHTTPClient(token, "")
		resp, err := client.Get(srv.URL + "/_GENERATION")
		if err != nil {
			t.Fatalf("GET: %v", err)
		}
		resp.Body.Close()
		if resp.StatusCode != http.StatusUnauthorized {
			t.Fatalf("expected 401 after revoke, got %d", resp.StatusCode)
		}
	})
}
