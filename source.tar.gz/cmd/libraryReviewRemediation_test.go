//go:build !tailscale

package cmd

import (
	"bytes"
	"encoding/hex"
	"image"
	"image/color"
	"image/draw"
	"image/jpeg"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"sync"
	"testing"

	"accorder/pkg/calibre"
	"accorder/pkg/libraryflow"
)

func TestReviewBaselineSaveRejectsUnreadableState(t *testing.T) {
	testSetup(t)
	valid := libraryBaseline{LibraryID: fastBuildLibraryID, LocalSourceFingerprint: "local", RemoteSourceFingerprint: "remote", Generation: 1}
	if err := saveBaseline("review", valid); err != nil {
		t.Fatal(err)
	}
	before, err := os.ReadFile(baselineStatePath("review"))
	if err != nil {
		t.Fatal(err)
	}
	for _, mutate := range []func(*libraryBaseline){
		func(b *libraryBaseline) { b.LibraryID = "" },
		func(b *libraryBaseline) { b.ContentLedgerVersion = 99 },
		func(b *libraryBaseline) { b.ContentLedgerVersion = 1 },
		func(b *libraryBaseline) {
			b.ContentLedgerVersion = 1
			b.GenerationToken = hex.EncodeToString(generationChangeMemberToken(1))
			b.CatalogChecksum = strings.Repeat("a", 64)
			b.ContentLedger = []libraryflow.Object{{Path: libraryflow.GenerationPath, Hash: strings.Repeat("b", 64)}}
		},
	} {
		bad := valid
		mutate(&bad)
		if err := saveBaseline("review", bad); err == nil {
			t.Fatalf("invalid save succeeded: %+v", bad)
		}
		after, err := os.ReadFile(baselineStatePath("review"))
		if err != nil || !bytes.Equal(before, after) {
			t.Fatalf("rejected save replaced readable baseline: %v", err)
		}
		if _, err := loadBaseline("review"); err != nil {
			t.Fatal(err)
		}
	}
}

func TestReviewCatalogCoverFingerprintNativePath(t *testing.T) {
	root := testSetup(t)
	seedPublishCalibreLibrary(t, root)
	fastBuildSQL(t, root, "ALTER TABLE books ADD COLUMN has_cover INTEGER DEFAULT 1")
	cover := filepath.Join("Author", "Book (1)", "cover.jpg")
	build := fastBuildCommand(root)
	var previous string
	for _, shade := range []color.RGBA{{R: 220, A: 255}, {B: 220, A: 255}} {
		img := image.NewRGBA(image.Rect(0, 0, 16, 16))
		draw.Draw(img, img.Bounds(), &image.Uniform{C: shade}, image.Point{}, draw.Src)
		var raw bytes.Buffer
		if err := jpeg.Encode(&raw, img, nil); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(filepath.Join(root, cover), raw.Bytes(), 0600); err != nil {
			t.Fatal(err)
		}
		fastBuildCalibreEdit(t, root, 1)
		if err := build.Run(nil); err != nil {
			t.Fatal(err)
		}
		want, ok := calibre.LocalCoverFingerprint(root, cover)
		if !ok || want == previous {
			t.Fatal("fixture must produce distinct nonempty fingerprints")
		}
		records, err := calibre.ReadCatalogRecordInfos(build.IndexPath)
		if err != nil || len(records) != 1 {
			t.Fatalf("catalog: %v", err)
		}
		for _, record := range records {
			if record.CoverFingerprint != want {
				t.Fatalf("native cover skipped: got %q want %q", record.CoverFingerprint, want)
			}
		}
		previous = want
	}
}

func TestReviewHistoricalOPFResetsSelectionFromInput(t *testing.T) {
	root := testSetup(t)
	seedPublishCalibreLibrary(t, root)
	if err := fastBuildCommand(root).Run(nil); err != nil {
		t.Fatal(err)
	}
	prior := addHistoricalCatalogOPF(t, root)
	prior.Evidence.Catalog.Selection = "historical-selection"
	input := &sourceInventory{Root: filepath.Clean(root), Objects: prior.ContentLedger, Catalog: prior.Evidence.Catalog}
	before := append([]calibre.SourceCatalogFile(nil), input.Catalog.Files...)
	_, evidence, _, _, err := buildCatalogEvidence(root, input, nil, nil, nil, prior.Evidence.Provenance.Seat)
	if err != nil {
		t.Fatal(err)
	}
	if evidence.Catalog.Selection != "" || !reflect.DeepEqual(before, input.Catalog.Files) || input.Catalog.Selection != "historical-selection" {
		t.Fatal("historical input was mutated or wrongly labeled reusable")
	}
	if err := validateCatalogEvidence(nil, nil); err == nil {
		t.Fatal("nil evidence accepted")
	}
	if _, _, _, _, err := buildCatalogEvidence(root, nil, nil, nil, nil, ""); err == nil {
		t.Fatal("nil inventory accepted")
	}
}

func TestReviewCatalogObserverConcurrentCalls(t *testing.T) {
	counts := catalogWorkCounts(t)
	observer := libraryWorkObserver
	var wg sync.WaitGroup
	for i := 0; i < 20; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for j := 0; j < 100; j++ {
				observer("parallel", 0, 1)
				_ = counts.count("parallel")
				_ = counts.String()
			}
		}()
	}
	wg.Wait()
	if counts.count("parallel") != 2000 {
		t.Fatalf("lost calls: %v", counts)
	}
}

func TestReviewNativePublishHasThreeInventoryBoundaries(t *testing.T) {
	root := testSetup(t)
	seedPublishCalibreLibrary(t, root)
	withLocalCommandRemote(t, t.TempDir())
	if err := fastBuildCommand(root).Run(nil); err != nil {
		t.Fatal(err)
	}
	candidate, err := captureExistingCandidate(root, resolveUploadExcludes(root, nil))
	if err != nil {
		t.Fatal(err)
	}
	inventory, err := parallelInventory(root, 16, true)
	if err != nil {
		t.Fatal(err)
	}
	installation, err := loadInstallation()
	if err != nil {
		t.Fatal(err)
	}
	ledger, evidence, changed, _, err := buildSourceEvidence(root, inventory.Objects, candidate.Excludes, nil, nil, installation.SeatID, inventory)
	if err != nil {
		t.Fatal(err)
	}
	if err := requireSourceCoherence(root, ledger, evidence); err != nil {
		t.Skipf("native filesystem required: %v", err)
	}
	fingerprint, err := sourceFingerprintForEvidence(ledger, evidence)
	if err != nil {
		t.Fatal(err)
	}
	candidate.SourceContract, candidate.SourceFingerprint = "", fingerprint
	candidate.Change.Evidence, candidate.Change.ContentLedger = evidence, ledger
	candidate.Change.TargetSourceFingerprint, candidate.Change.ForcePaths = fingerprint, changed
	if err := saveLocalChangeCandidate(root, *candidate.Change); err != nil {
		t.Fatal(err)
	}
	counts := countLibraryScans(t, func() error {
		return publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: 25})
	})
	if counts["inventory"] != 3 || counts["publish-coherence"] != 3 {
		t.Fatalf("publish checks: %v", counts)
	}
}

func TestReviewCatalogSyncGenerationOnlyPreservesCoverage(t *testing.T) {
	root, remoteRoot, build := fastBuildPublishedFixture(t)
	before, err := loadBaseline("alice")
	if err != nil {
		t.Fatal(err)
	}
	remote := &libraryRemote{fsPath: remoteRoot}
	advanced := advanceCleanupRemote(t, remote)
	if advanced.Err != nil {
		t.Fatal(advanced.Err)
	}
	payload, err := os.Stat(filepath.Join(root, fastBuildPayload))
	if err != nil {
		t.Fatal(err)
	}
	command := &LibSyncCmd{GroupLib: build.GroupLib}
	command.ActionAlias = "alice"
	counts := countLibraryScans(t, func() error { return command.Run(nil) })
	after, err := loadBaseline("alice")
	if err != nil {
		t.Fatal(err)
	}
	if after.Generation != advanced.Generation || !reflect.DeepEqual(before.ContentLedger, after.ContentLedger) ||
		!reflect.DeepEqual(before.Evidence, after.Evidence) || !before.UpdatedAt.Equal(after.UpdatedAt) {
		t.Fatal("refresh lost earned coverage")
	}
	now, err := os.Stat(filepath.Join(root, fastBuildPayload))
	if err != nil || !os.SameFile(payload, now) || counts["inventory"] != 0 {
		t.Fatal("generation-only sync replaced or walked payload")
	}
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	candidate, err := captureExistingCandidate(root, resolveUploadExcludes(root, nil))
	if err != nil || candidate.Change == nil || candidate.Change.CompleteOverwrite || candidate.Change.FromGeneration != after.GenerationToken {
		t.Fatalf("refresh did not yield bounded next publication: %+v %v", candidate, err)
	}
	if err := publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: 25}); err != nil {
		t.Fatal(err)
	}
}

func TestReviewCatalogSyncDoesNotHideChangedLocalMarker(t *testing.T) {
	root, remoteRoot, build := fastBuildPublishedFixture(t)
	advanceCleanupRemote(t, &libraryRemote{fsPath: remoteRoot})
	writeTestFile(t, root, libraryflow.GenerationPath, string(generationChangeMemberToken(999)))
	release, err := acquireLibraryExecutionLock("alice")
	if err != nil {
		t.Fatal(err)
	}
	release()
	before := fastBuildSnapshot(t, root, accorderConfigDir, remoteRoot)
	command := &LibSyncCmd{GroupLib: build.GroupLib}
	command.ActionAlias = "alice"
	if err := command.Run(nil); err == nil || !strings.Contains(err.Error(), "local publication marker") {
		t.Fatalf("unrecognized marker was silently rebound: %v", err)
	}
	if after := fastBuildSnapshot(t, root, accorderConfigDir, remoteRoot); after != before {
		t.Fatal("refused refresh modified source or history")
	}
}

func TestReviewBootstrapCatalogCanSyncAndPublishWithoutFullReupload(t *testing.T) {
	root := testSetup(t)
	seedPublishCalibreLibrary(t, root)
	build := fastBuildCommand(root)
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	remoteRoot := t.TempDir()
	withLocalCommandRemote(t, remoteRoot)
	if err := copyDirectory(root, remoteRoot); err != nil {
		t.Fatal(err)
	}
	for _, path := range []string{memberPointerPath, libraryflow.GenerationPath} {
		if err := os.Remove(filepath.Join(remoteRoot, filepath.FromSlash(path))); err != nil {
			t.Fatal(err)
		}
	}
	mf, err := calibre.ReadExistingManifest(build.IndexPath)
	if err != nil {
		t.Fatal(err)
	}
	fingerprint, err := localSourceFingerprintForContract(root, nil, calibre.CatalogSourceContract)
	if err != nil {
		t.Fatal(err)
	}
	if err := uploadIndexAndGeneration(filepath.Dir(build.IndexPath), filepath.Base(build.IndexPath)+".zst", remoteRoot, mf, fingerprint); err != nil {
		t.Fatal(err)
	}
	destination := filepath.Join(t.TempDir(), "downloaded")
	command := &LibSyncCmd{GroupLib: build.GroupLib}
	command.ActionAlias, command.CalibreDirectory = "alice", destination
	if err := command.Run(nil); err != nil {
		t.Fatal(err)
	}
	if err := fastBuildCommand(destination).Run(nil); err != nil {
		t.Fatal(err)
	}
	candidate, err := captureExistingCandidate(destination, resolveUploadExcludes(destination, nil))
	if err != nil || candidate.Change == nil || candidate.Change.CompleteOverwrite {
		t.Fatalf("bootstrap cannot establish narrow publication: %+v %v", candidate, err)
	}
	if err := publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: 25}); err != nil {
		t.Fatal(err)
	}
}

func TestReviewLegacyCatalogUpgradeBoundedByPublishedIndex(t *testing.T) {
	for _, comparable := range []bool{true, false} {
		name := "matched-index"
		if !comparable {
			name = "unknown-index"
		}
		t.Run(name, func(t *testing.T) {
			root, remoteRoot, build := fastBuildPublishedFixture(t)
			baseline, err := loadBaseline("alice")
			if err != nil {
				t.Fatal(err)
			}
			legacyFP, _, err := libraryflow.SourceFingerprint(root, resolveUploadExcludes(root, nil))
			if err != nil {
				t.Fatal(err)
			}
			pointer, err := calibre.ReadPointerFile(filepath.Join(remoteRoot, memberPointerPath))
			if err != nil {
				t.Fatal(err)
			}
			pointer.SourceContract, pointer.SourceFingerprint = "", legacyFP
			if !comparable {
				pointer.CatalogChecksum = ""
			}
			if err := calibre.WritePointerDocument(filepath.Join(remoteRoot, memberPointerPath), pointer); err != nil {
				t.Fatal(err)
			}
			if err := os.Remove(baselineStatePath("alice")); err != nil {
				t.Fatal(err)
			}
			if err := os.Remove(localChangeCandidateFile(root)); err != nil {
				t.Fatal(err)
			}
			if err := saveBaseline("alice", libraryBaseline{LibraryID: fastBuildLibraryID, LocalSourceFingerprint: legacyFP, RemoteSourceFingerprint: legacyFP, Generation: baseline.Generation}); err != nil {
				t.Fatal(err)
			}
			fastBuildAddSecondBook(t, root)
			for i := 0; i < 2; i++ {
				if err := build.Run(nil); err != nil {
					t.Fatal(err)
				}
			}
			candidate, err := captureExistingCandidate(root, resolveUploadExcludes(root, nil))
			if err != nil || candidate.Change == nil {
				t.Fatal(err)
			}
			if candidate.Change.CompleteOverwrite || containsString(candidate.Change.ForcePaths, fastBuildPayload) || !containsString(candidate.Change.ForcePaths, "Author/Second (2)/Second - Author.epub") {
				t.Fatalf("legacy upgrade lost bounded paths across build retry: %+v", candidate.Change)
			}
			err = publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: 25})
			if !comparable {
				if err == nil || !strings.Contains(err.Error(), "--allow-full-reupload") {
					t.Fatalf("unknown remote index accepted: %v", err)
				}
				return
			}
			if err != nil {
				t.Fatal(err)
			}
			got, err := os.ReadFile(filepath.Join(remoteRoot, "Author/Second (2)/Second - Author.epub"))
			if err != nil || string(got) != "epub" {
				t.Fatalf("new book missing: %q %v", got, err)
			}
		})
	}
}
