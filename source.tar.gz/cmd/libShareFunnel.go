//go:build tailscale

package cmd

import (
	"accorder/pkg/liveshare"
	"strings"

	"github.com/alecthomas/kong"
)

type LibShareFunnelCmd struct {
	CommonCommandFields
	TailscaleAuthKey string `short:"k" help:"Tailscale's auth key." json:"tailscale-auth-key" validate:"required"`
	GroupLib
}

func (c *LibShareFunnelCmd) Run(ctx *kong.Context) error {
	if c.HandleShowConfig(c) {
		return nil
	}
	if err := c.EnsureCalibreDir(ctx, c.ActionAlias); err != nil {
		return err
	}
	subdomain := strings.Join(strings.Fields(c.Librarian), "")
	liveshare.Run(subdomain, c.TailscaleAuthKey, c.CalibreDirectory, AccorderConfigDir())
	return nil
}
