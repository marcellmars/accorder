package cmd

import (
	"bytes"
	"io"
	"strings"
	"testing"
)

// progressReader must be a transparent io.Reader: it counts bytes for the bar
// but must never alter, drop, or duplicate the stream feeding io.Copy/splice.
func TestProgressReaderPassThrough(t *testing.T) {
	const payload = "the quick brown fox jumps over the lazy dog, repeatedly. "
	src := strings.Repeat(payload, 1000)
	pr := newProgressReader(bytes.NewReader([]byte(src)), int64(len(src)), "  index")

	got, err := io.ReadAll(pr)
	if err != nil {
		t.Fatalf("ReadAll: %v", err)
	}
	if string(got) != src {
		t.Fatalf("stream corrupted: got %d bytes, want %d", len(got), len(src))
	}
	if pr.read != int64(len(src)) {
		t.Errorf("byte count = %d, want %d", pr.read, len(src))
	}
}

// Unknown total (Content-Length -1, chunked) must not panic — the indeterminate
// branch is exercised and the stream still passes through intact.
func TestProgressReaderUnknownTotal(t *testing.T) {
	src := []byte("chunked body without content-length")
	pr := newProgressReader(bytes.NewReader(src), -1, "  index")
	got, err := io.ReadAll(pr)
	if err != nil {
		t.Fatalf("ReadAll: %v", err)
	}
	if !bytes.Equal(got, src) {
		t.Fatalf("stream corrupted")
	}
	pr.finish() // safe on a non-TTY / already-finished reader
}

func TestHumanIEC(t *testing.T) {
	cases := []struct {
		n    int64
		want string
	}{
		{0, "0 B"},
		{512, "512 B"},
		{1024, "1.0 KiB"},
		{1536, "1.5 KiB"},
		{1048576, "1.0 MiB"},
		{52428800, "50.0 MiB"},
		{1073741824, "1.0 GiB"},
	}
	for _, c := range cases {
		if got := humanIEC(c.n); got != c.want {
			t.Errorf("humanIEC(%d) = %q, want %q", c.n, got, c.want)
		}
	}
}
