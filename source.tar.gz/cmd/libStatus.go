package cmd

import (
	"accorder/pkg/libraryflow"
	"errors"
	"fmt"
	"os"
	"path/filepath"
)

type LibStatusCmd struct {
	CommonCommandFields
	GroupLib
	GroupS3Credentials
	Passphrase string `name:"passphrase" json:"-" help:"Passphrase for the local secrets store (or set ACCORDER_SECRETS_PASSPHRASE)." env:"ACCORDER_SECRETS_PASSPHRASE" secret:"redact"`
}

func (c *LibStatusCmd) Run() error {
	if c.HandleShowConfig(c) {
		return nil
	}
	installation, err := loadInstallation()
	if err != nil && !os.IsNotExist(err) {
		return fmt.Errorf("lib status: %w", err)
	}
	if _, err := os.Stat(publishRecoveryPath(c.ActionAlias)); err == nil {
		fmt.Println("Bookkeeping: a committed publish may need recovery; the next `lib publish` will verify pointer/source/generation before repairing it")
	}
	remote, err := openLibraryRemoteForCommand(c.ActionAlias, c.GroupS3Credentials)
	if err != nil {
		return fmt.Errorf("lib status: offline/unreadable remote: %w", err)
	}
	defer remote.Close()
	snapshot := remote.commitState()
	if snapshot.Err != nil {
		if snapshot.Legacy {
			fmt.Printf("Library %s: legacy/unverified remote\n", c.ActionAlias)
			fmt.Println("Remote: published content exists; last remote update is only an object-time estimate")
			fmt.Println("Sync: refused until the writer publishes once with a current Accorder client")
			_ = printWriterState(c.ActionAlias, installation, snapshot.Writer)
			return nil
		}
		if errors.Is(snapshot.Err, errRemoteObjectNotFound) {
			fmt.Printf("Library %s: no published library\n", c.ActionAlias)
			_ = printWriterState(c.ActionAlias, installation, snapshot.Writer)
			return nil
		}
		fmt.Printf("Library %s: interrupted/uncommitted remote publish\n", c.ActionAlias)
		fmt.Printf("Remote: %v\n", snapshot.Err)
		_ = printWriterState(c.ActionAlias, installation, snapshot.Writer)
		return nil
	}
	if !snapshot.Committed {
		fmt.Printf("Library %s: no published library\n", c.ActionAlias)
		_ = printWriterState(c.ActionAlias, installation, snapshot.Writer)
		return nil
	}
	if c.LibraryID != "" && snapshot.Pointer.Library.UUID != c.LibraryID {
		fmt.Printf("Library %s: identity mismatch\n", c.ActionAlias)
		fmt.Printf("Remote UUID: %s; active alias UUID: %s\n", snapshot.Pointer.Library.UUID, c.LibraryID)
		_ = printWriterState(c.ActionAlias, installation, snapshot.Writer)
		return nil
	}

	localFingerprint := ""
	if c.CalibreDirectory != "" {
		if _, statErr := os.Stat(filepath.Join(c.CalibreDirectory, "metadata.db")); statErr == nil {
			localFingerprint, _, err = libraryflow.SourceFingerprint(c.CalibreDirectory, resolveUploadExcludes(c.CalibreDirectory, nil))
			if err != nil {
				return fmt.Errorf("lib status: local source: %w", err)
			}
		}
	}
	baseline, err := loadBaseline(c.ActionAlias)
	if err != nil {
		return fmt.Errorf("lib status: %w", err)
	}
	state := classifyLibraryState(localFingerprint, snapshot.SourceFingerprint, baseline)
	fmt.Printf("Library %s: %s\n", c.ActionAlias, state)
	when := ""
	if snapshot.Writer.Kind == "valid" && snapshot.Writer.Marker.PublishedAt != nil {
		when = ", published " + snapshot.Writer.Marker.PublishedAt.UTC().Format("2006-01-02T15:04:05Z")
	}
	fmt.Printf("Remote: %d published books, generation %d%s\n", snapshot.Pointer.Index.NumBooks, snapshot.Generation, when)
	_ = printWriterState(c.ActionAlias, installation, snapshot.Writer)
	privateDirs := privateDirsFromExcludes(resolveUploadExcludes(c.CalibreDirectory, nil))
	if len(privateDirs) > 0 {
		fmt.Printf("Private: %d local-only book director%s (not recoverable from the bucket)\n", len(privateDirs), plural(len(privateDirs), "y", "ies"))
	} else {
		fmt.Println("Private: no local-only book directories recorded")
	}
	if snapshot.Pointer.Version == 2 {
		fmt.Println("Compatibility: older publishing binaries can still bypass seat and shrink protection")
	}
	return nil
}

func classifyLibraryState(local, remote string, baseline *libraryBaseline) string {
	if local == "" {
		return "remote available; local library missing"
	}
	if baseline == nil {
		if local == remote {
			return "current (no baseline; fingerprints converge)"
		}
		return "unbaselined; choose remote-wins or local-wins"
	}
	remoteChanged := remote != baseline.RemoteSourceFingerprint
	localChanged := local != baseline.LocalSourceFingerprint
	switch {
	case !remoteChanged && !localChanged:
		return "current"
	case !remoteChanged && localChanged:
		return "local ahead"
	case remoteChanged && !localChanged:
		return "remote ahead"
	case local == remote:
		return "current (already converged)"
	default:
		return "diverged"
	}
}
