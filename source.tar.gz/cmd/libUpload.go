package cmd

import (
	"accorder/pkg/calibre"
	"accorder/pkg/libraryflow"
	"accorder/pkg/rclonexfer"
	"accorder/pkg/torshare"
	"bufio"
	"bytes"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"github.com/alecthomas/kong"
)

type GroupS3Credentials struct {
	Bucket      string `name:"bucket" json:"bucket" propagate:"-" help:"S3 bucket name." validate:"required"`
	S3AccessKey string `name:"s3-access-key" json:"s3-access-key" alias:"-" help:"S3 access key." validate:"required" sharedgroup:"s3creds" secret:"redact,fingerprint"`
	S3SecretKey string `name:"s3-secret-key" json:"s3-secret-key" alias:"-" help:"S3 secret key." validate:"required" sharedgroup:"s3creds" secret:"redact,fingerprint"`
	S3Provider  string `name:"s3-provider" json:"s3-provider" alias:"-" help:"S3 provider (e.g. Wasabi, AWS)." validate:"required" sharedgroup:"s3creds"`
	S3Endpoint  string `name:"s3-endpoint" json:"s3-endpoint" alias:"-" help:"S3 endpoint URL." validate:"required" sharedgroup:"s3creds"`
	KeysFile    string `name:"keys-file" json:"keys-file" help:"Path to the operator S3 keys-file (default: keys/<alias>.s3.keys). When set, creds resolve from the keys-file instead of the encrypted secrets store." validate:"omitempty"`
}

type LibUploadCmd struct {
	CommonCommandFields
	Files    []string `name:"files" sep:"," help:"Comma-separated list of files to upload (relative to --calibrepath). Additive copy, no delete." json:"-"`
	ListFile string   `name:"list" help:"Path to a text file listing files to upload (one per line, # comments ok)." json:"-" validate:"omitempty,filepath"`
	GroupLib
	GroupS3Credentials
	Passphrase string `name:"passphrase" json:"-" help:"Passphrase for the local secrets store (or set ACCORDER_SECRETS_PASSPHRASE)." env:"ACCORDER_SECRETS_PASSPHRASE" secret:"redact"`
	TeaOutputs

	ExcludeGlobs             []string `kong:"-" json:"-"`
	DryRun                   bool     `name:"dry-run" help:"Print the complete upload plan without changing local or remote state." json:"-"`
	FinishInterruptedPublish bool     `name:"finish-interrupted-publish" help:"Finish an interrupted private-file cleanup using the snapshot already uploaded. Later local edits stay pending; publish again to upload them." json:"-"`
	MaxDeletes               int      `name:"max-deletes" help:"Maximum remote file removals across the mirror and private-book cleanup; zero forbids removals. The mirror may stop after partial work." default:"25" json:"-"`
	LocalWins                bool     `name:"local-wins" help:"Upload the local snapshot after explicit divergence review." json:"-"`
	AllowCompleteOverwrite   bool     `name:"allow-full-reupload" help:"Allow Accorder to upload every public library file again when it cannot safely identify only the changed files. This can take much longer and use substantial bandwidth." json:"-"`
	Verbose                  bool     `name:"verbose" help:"Print every planned deletion." json:"-"`
	RcloneLogLevel           string   `name:"rclone-log-level" json:"-" help:"Log level for the embedded rclone (EMERGENCY..DEBUG, OFF). Empty keeps rclone's default NOTICE. Use DEBUG to see every request the remote inspection issues, which is how you tell what a slow publish is actually waiting on. Never remembered by the action alias (diagnostic class)." enum:"EMERGENCY,ALERT,CRITICAL,ERROR,WARNING,NOTICE,INFO,DEBUG,OFF," default:""`
}

func (c *LibUploadCmd) Run(ctx *kong.Context) error {
	c.Header = ".◟◜motw upload◝◞."
	// The -s gate precedes EnsureCalibreDir deliberately: that helper
	// prompts interactively and persists the answer, which a read-only
	// diagnostic must never do.
	if c.HandleShowConfig(c) {
		return nil
	}
	if c.FinishInterruptedPublish && (c.DryRun || len(c.Files) > 0 || c.ListFile != "") {
		return fmt.Errorf("--finish-interrupted-publish cannot be combined with --dry-run or --files/--list; no files were changed")
	}

	if err := c.EnsureCalibreDir(ctx, c.ActionAlias); err != nil {
		return err
	}

	if len(c.Files) > 0 || c.ListFile != "" {
		if c.DryRun {
			return fmt.Errorf("lib upload --files/--list: --dry-run is only supported for a complete publish plan; no files were changed")
		}
		release, err := acquireLibraryExecutionLock(c.ActionAlias)
		if err != nil {
			return fmt.Errorf("lib upload --files/--list: %w", err)
		}
		defer release()
		return c.runCopyMode()
	}

	return c.runSyncModeWithContext(ctx)
}

func (c *LibUploadCmd) runSyncMode() error {
	return c.runSyncModeWithContext(nil)
}

func (c *LibUploadCmd) runSyncModeWithContext(ctx *kong.Context) error {
	if !isScopedBucket(c.Bucket) {
		return fmt.Errorf("lib upload: refusing bare bucket %q; expected <bucket>/<prefix>", c.Bucket)
	}
	excludes := resolveUploadExcludes(c.CalibreDirectory, c.ExcludeGlobs)
	if !c.DryRun {
		release, err := acquireLibraryExecutionLock(c.ActionAlias)
		if err != nil {
			return fmt.Errorf("lib upload: %w", err)
		}
		defer release()
		if recovered, err := resumeBeforeBuild(c.ActionAlias, c.LibraryID, c.CalibreDirectory, c.GroupS3Credentials, publishOptions{MaxDeletes: c.MaxDeletes, FinishInterruptedPublish: c.FinishInterruptedPublish}); err != nil {
			return err
		} else if recovered {
			fmt.Println("Recovered the previously committed publication.")
			if c.FinishInterruptedPublish {
				fmt.Println("Later local edits were not uploaded. Run lib publish again to publish those edits.")
			}
			return nil
		}
	}
	candidate, excludes, err := c.prepareUploadCandidate(ctx, excludes)
	if err != nil {
		return err
	}
	return publishCandidate(c.ActionAlias, c.LibraryID, c.GroupS3Credentials, candidate, publishOptions{
		DryRun: c.DryRun, MaxDeletes: c.MaxDeletes, LocalWins: c.LocalWins,
		AllowCompleteOverwrite: c.AllowCompleteOverwrite, Verbose: c.Verbose,
		RcloneLogLevel: c.RcloneLogLevel,
	})
}

func (c *LibUploadCmd) prepareUploadCandidate(ctx *kong.Context, excludes []string) (*libraryCandidate, []string, error) {
	finish := beginLibraryWork("upload-preparation")
	defer finish(1)
	buildReason := "no current build was found"
	change, changeErr := loadLocalChangeCandidate(c.CalibreDirectory)
	upgrade := false
	if changeErr == nil && !isCatalogEvidence(change.Evidence) {
		database, err := observeBuildDatabase(c.CalibreDirectory)
		if err != nil {
			return nil, nil, err
		}
		upgrade = database != nil && database.SQLite
		if upgrade {
			buildReason = "the older build needs Calibre-based change tracking"
		}
	}
	if changeErr == nil && !upgrade {
		if err := requireClosedCalibre(c.CalibreDirectory); err != nil {
			return nil, nil, err
		}
		candidate := &libraryCandidate{Root: c.CalibreDirectory, Excludes: append([]string(nil), excludes...)}
		captureErr := refreshLoadedCandidateIdentity(candidate, change, nil)
		if captureErr != nil {
			return nil, nil, fmt.Errorf("lib upload: inspect the current build: %w", captureErr)
		}
		if candidate.Change != nil {
			return candidate, excludes, nil
		}
		buildReason = "the library changed after its last build"
	}
	if c.DryRun {
		return nil, nil, fmt.Errorf("lib upload --dry-run: %s; run `accorder lib build %s` before previewing the upload", buildReason, c.ActionAlias)
	}
	if err := requireClosedCalibre(c.CalibreDirectory); err != nil {
		return nil, nil, fmt.Errorf("lib upload: %w", err)
	}
	fmt.Fprintf(os.Stderr, "lib upload: %s; running lib build first\n", buildReason)
	build := &LibBuildCmd{GroupLib: c.GroupLib}
	build.ActionAlias = c.ActionAlias
	build.InPipeline = true
	if err := build.Run(ctx); err != nil {
		return nil, nil, fmt.Errorf("lib upload: build library before uploading: %w", err)
	}
	excludes = resolveUploadExcludes(c.CalibreDirectory, build.PrivateExcludes)
	candidate, err := captureExistingCandidate(c.CalibreDirectory, excludes)
	if err != nil {
		return nil, nil, fmt.Errorf("lib upload: inspect the completed build: %w", err)
	}
	if candidate.Change == nil {
		return nil, nil, fmt.Errorf("lib upload: lib build finished, but its saved build record does not match the library; upload stopped—run `accorder lib build %s` again and report the error if it repeats", c.ActionAlias)
	}
	return candidate, excludes, nil
}

func (c *LibUploadCmd) runCopyMode() error {
	allFiles := append([]string{}, c.Files...)
	if c.ListFile != "" {
		listed, err := parseListFile(c.ListFile)
		if err != nil {
			return err
		}
		allFiles = append(allFiles, listed...)
	}

	seen := make(map[string]struct{}, len(allFiles))
	deduped := allFiles[:0]
	for _, f := range allFiles {
		f = filepath.Clean(f)
		if _, ok := seen[f]; !ok {
			seen[f] = struct{}{}
			deduped = append(deduped, f)
		}
	}
	allFiles = deduped

	if len(allFiles) == 0 {
		return fmt.Errorf("--files/--list: no files specified")
	}

	if err := validateRelativePaths(allFiles); err != nil {
		return err
	}

	return c.runDerivedRepair(allFiles)
}

func (c *LibUploadCmd) runDerivedRepair(files []string) error {
	if err := requireClosedCalibre(c.CalibreDirectory); err != nil {
		return err
	}
	indexRel := indexSiblingRel(c.CalibreDirectory, c.IndexPath, ".zst")
	jsonlRel := indexSiblingRel(c.CalibreDirectory, c.IndexPath, ".jsonl.zst")
	pointerRel := indexSiblingRel(c.CalibreDirectory, c.IndexPath, ".manifest.json")
	if indexRel == "" || pointerRel == "" {
		return fmt.Errorf("lib upload --files/--list: index artifacts must be contained by --calibrepath")
	}
	// The remote layout is fixed regardless of where --index-path put the local
	// artifacts; uploading them under their local relative path would publish a
	// pointer naming an object that does not exist at static/.
	allowed := map[string]string{indexRel: "static/library_index.zst"}
	if jsonlRel != "" {
		allowed[jsonlRel] = "static/library_index.jsonl.zst"
	}
	selected := make(map[string]bool, len(files))
	for _, file := range files {
		path := filepath.ToSlash(filepath.Clean(file))
		if libraryflow.IsProtectedPath(path) || allowed[path] == "" {
			return fmt.Errorf("lib upload --files/--list: %s is source, coordination, or unclassified; use `accorder lib publish %s`", path, c.ActionAlias)
		}
		selected[path] = true
	}
	if !selected[indexRel] {
		return fmt.Errorf("lib upload --files/--list: derived repair requires the complete index family, including %s", indexRel)
	}
	pointer, _, err := readAndValidateDerivedFamily(c.CalibreDirectory, indexRel)
	if err != nil {
		return fmt.Errorf("lib upload --files/--list: validate complete derived family: %w", err)
	}
	if pointer.Index.JsonlURL != "" && !selected[jsonlRel] {
		return fmt.Errorf("lib upload --files/--list: derived repair requires %s because the pointer declares JSONL lineage", jsonlRel)
	}
	for path := range selected {
		if _, err := os.Stat(filepath.Join(c.CalibreDirectory, filepath.FromSlash(path))); err != nil {
			return fmt.Errorf("lib upload --files/--list: %s: %w", path, err)
		}
	}

	remote, err := openLibraryRemoteForCommand(c.ActionAlias, c.GroupS3Credentials)
	if err != nil {
		return fmt.Errorf("lib upload --files/--list: %w", err)
	}
	defer remote.Close()
	if recovered, err := recoverDerivedEvidenceRepair(c.ActionAlias, c.LibraryID, c.CalibreDirectory, remote); err != nil {
		return err
	} else if recovered {
		return nil
	}
	before := remote.commitState()
	if before.Err != nil || !before.Committed {
		return fmt.Errorf("lib upload --files/--list: derived repair requires a coherent version 2 remote snapshot: %v", before.Err)
	}
	if pointer.Library.UUID != before.Pointer.Library.UUID {
		return fmt.Errorf("lib upload --files/--list: local pointer UUID %s does not match remote %s", pointer.Library.UUID, before.Pointer.Library.UUID)
	}
	localFingerprint, err := localSourceFingerprintForContract(c.CalibreDirectory, resolveUploadExcludes(c.CalibreDirectory, nil), before.Pointer.SourceContract)
	if err != nil {
		return fmt.Errorf("lib upload --files/--list: local source: %w", err)
	}
	if localFingerprint != before.SourceFingerprint {
		return fmt.Errorf("lib upload --files/--list: source changed; use `accorder lib publish %s`", c.ActionAlias)
	}
	if before.Writer.Kind == "invalid" || before.Writer.Kind == "unreadable" {
		return fmt.Errorf("lib upload --files/--list: invalid/unreadable _WRITER: %w", before.Writer.Err)
	}
	ready := remote.commitState()
	if ready.Err != nil || !sameRemoteApproval(before, ready) || !bytes.Equal(before.Writer.Raw, remote.readWriter().Raw) {
		return fmt.Errorf("lib upload --files/--list: remote changed before derived upload; retry")
	}
	nextGeneration := before.Generation + 1
	pointer, err = calibre.BindPointerCommit(pointer, before.SourceFingerprint, nextGeneration)
	pointer.SourceContract = before.Pointer.SourceContract
	if err != nil {
		return err
	}
	base, _, err := torshare.DecodeGeneration(before.GenerationRaw)
	if err != nil {
		return err
	}
	committedGeneration := torshare.EncodeGeneration(base, nextGeneration)
	repair, err := prepareDerivedEvidenceRepair(c.ActionAlias, c.CalibreDirectory, before, pointer, committedGeneration, indexRel)
	if err != nil {
		return err
	}

	ordered := make([]string, 0, len(selected))
	for path := range selected {
		ordered = append(ordered, path)
	}
	sort.Strings(ordered)
	for _, path := range ordered {
		target := allowed[path]
		localInfo, statErr := os.Stat(filepath.Join(c.CalibreDirectory, filepath.FromSlash(path)))
		if statErr != nil {
			return fmt.Errorf("lib upload --files/--list: %s: %w", path, statErr)
		}
		if err := remote.uploadFileAs(c.CalibreDirectory, path, target); err != nil {
			return fmt.Errorf("lib upload --files/--list: upload %s: %w", path, err)
		}
		remoteInfo, statErr := rclonexfer.StatObject(remote.fsPath, target)
		if statErr != nil || remoteInfo == nil || remoteInfo.Size != localInfo.Size() {
			return fmt.Errorf("lib upload --files/--list: verify %s failed", target)
		}
	}
	afterPayload := remote.commitState()
	if afterPayload.Err != nil || afterPayload.SourceFingerprint != before.SourceFingerprint ||
		afterPayload.Generation != before.Generation || !bytes.Equal(afterPayload.PointerRaw, before.PointerRaw) {
		return fmt.Errorf("lib upload --files/--list: remote source changed during repair")
	}
	if !bytes.Equal(before.Writer.Raw, remote.readWriter().Raw) {
		return fmt.Errorf("lib upload --files/--list: writer marker changed during repair")
	}
	if err := verifyRecoverySource(c.CalibreDirectory, repair.Source); err != nil {
		return err
	}
	if err := writeJSONAtomic(derivedEvidenceRepairPath(c.ActionAlias), repair); err != nil {
		return err
	}
	if err := remote.write(memberPointerPath, repair.Pointer); err != nil {
		return fmt.Errorf("lib upload --files/--list: upload pointer: %w", err)
	}
	if err := verifyRecoverySource(c.CalibreDirectory, repair.Source); err != nil {
		return err
	}
	if !bytes.Equal(before.Writer.Raw, remote.readWriter().Raw) {
		return errors.New("publishing access changed during derived repair")
	}
	if err := remote.write(libraryflow.GenerationPath, committedGeneration); err != nil {
		return fmt.Errorf("lib upload --files/--list: upload final generation: %w", err)
	}
	if !bytes.Equal(before.Writer.Raw, remote.readWriter().Raw) {
		return fmt.Errorf("lib upload --files/--list: writer marker was not preserved")
	}
	committed := remote.commitState()
	if committed.Err != nil || !committed.Committed || committed.Generation != nextGeneration ||
		committed.SourceFingerprint != before.SourceFingerprint || committed.Pointer.Library.UUID != before.Pointer.Library.UUID {
		return fmt.Errorf("lib upload --files/--list: final derived commit verification failed: %v", committed.Err)
	}
	if err := finishDerivedEvidenceRepair(remote, repair); err != nil {
		return err
	}
	fmt.Fprintf(os.Stderr, "lib upload: repaired complete derived family; generation %d; writer unchanged.\n", nextGeneration)
	return nil
}

func parseListFile(path string) ([]string, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, fmt.Errorf("--list: %w", err)
	}
	defer f.Close()

	var paths []string
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		paths = append(paths, line)
	}
	if err := sc.Err(); err != nil {
		return nil, fmt.Errorf("--list: read error: %w", err)
	}
	return paths, nil
}

func validateRelativePaths(paths []string) error {
	for _, p := range paths {
		if filepath.IsAbs(p) {
			return fmt.Errorf("--files/--list: absolute path not allowed: %s", p)
		}
		if strings.Contains(p, "..") {
			return fmt.Errorf("--files/--list: path traversal not allowed: %s", p)
		}
	}
	return nil
}
