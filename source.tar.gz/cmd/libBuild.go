package cmd

import (
	"accorder/pkg/bubble"
	"accorder/pkg/calibre"
	"accorder/pkg/libraryflow"
	"accorder/pkg/rclonexfer"
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"reflect"
	"runtime"
	"sort"
	"sync"
	"sync/atomic"
	"time"

	"github.com/alecthomas/kong"
	xxhash "github.com/cespare/xxhash/v2"
	"golang.org/x/term"
)

type GroupSandpoints struct {
	Json     *bool  `name:"json-export" short:"j" json:"-" help:"If the flag is provided, export the Calibre catalog to the JSON file." validate:"omitempty"`
	JsonPath string `name:"json-path" json:"json-path" help:"Path to the JSON file where the Calibre catalog will be exported." validate:"required_with=Json,omitempty,filepath"`
}

type GroupLibDir struct {
	// The tag deliberately lacks the `dir` validator: `lib sync` activates into
	// a destination that does not exist yet, and `lib status` reports on a
	// machine that has no local tree at all. Commands that need a real library
	// call EnsureCalibreDir (or RequireExistingCalibreDir), which restores the
	// early, readable failure for a mistyped path.
	CalibreDirectory string `name:"calibrepath" short:"c" json:"calibrepath" help:"Path to the Calibre library directory (created by recovery when absent)." validate:"omitempty" sharedgroup:"lib"`
}

// RequireExistingCalibreDir verifies a non-empty --calibrepath names an
// existing directory. This is the per-command replacement for the shared
// struct's former `validate:"dir"` tag; without it a typo surfaces much later
// as an opaque SQLite or fingerprint error.
func (g *GroupLibDir) RequireExistingCalibreDir() error {
	if g.CalibreDirectory == "" {
		return nil
	}
	info, err := os.Stat(g.CalibreDirectory)
	if err != nil || !info.IsDir() {
		return fmt.Errorf("--calibrepath: %q is not an existing directory", g.CalibreDirectory)
	}
	return nil
}

func (g *GroupLibDir) EnsureCalibreDir(ctx *kong.Context, alias string) error {
	if g.CalibreDirectory != "" {
		return g.RequireExistingCalibreDir()
	}

	if !term.IsTerminal(int(os.Stdin.Fd())) {
		return fmt.Errorf("missing required flag: --calibrepath")
	}

	fmt.Fprintf(os.Stderr, "No Calibre library configured. Search for one? [Y/n] ")
	var resp string
	fmt.Scanln(&resp)
	if resp != "" && resp != "Y" && resp != "y" {
		return fmt.Errorf("missing required flag: --calibrepath")
	}

	selectedPath, err := resolveCalibrePathInteractive("", alias)
	if err != nil {
		return fmt.Errorf("missing required flag: --calibrepath")
	}

	g.CalibreDirectory = selectedPath

	if ctx != nil && alias != "" {
		persistCalibrePath(ctx, alias, selectedPath)
		fmt.Fprintf(os.Stderr, "Set calibrepath=%s for alias %q\n", selectedPath, alias)
	}

	return nil
}

type GroupLib struct {
	GroupLibDir
	BaseURL   *string `name:"baseurl" short:"u" json:"baseurl" help:"Public base URL where this library will be served; baked into book, cover and download links in the generated site." validate:"omitempty,url" sharedgroup:"lib"`
	Librarian string  `short:"l" json:"librarian" help:"The catalog's librarian name (auto-generated when omitted)." validate:"omitempty,personname" sharedgroup:"lib" gen:"librarian"`
	LibraryID string  `name:"libraryID" short:"i" json:"libraryID" help:"The catalog's UUID (auto-generated when omitted)." validate:"omitempty,uuid" sharedgroup:"lib" gen:"uuid"`
	// No sharedgroup tag, deliberately. An explicitly-passed --dictID already
	// reaches its siblings via propagateGroupField, and tagging these would
	// swap that for propagateSharedField — the two are mutually exclusive in
	// AfterApply — with a different reach and no demonstrated need. What was
	// missing is the other direction: a subcommand that has never run took
	// neither value from its siblings, and libBuild's guard cannot catch that
	// because it fires on FedlibPrefix != "" && DictID < 2, and here both are
	// lost together. See the adoption in setupDefaults.go.
	DictID          uint32 `name:"dictID" json:"dictID" help:"Per-member dictionary ID for v5 composition. Normally set by 'lib join' from the invite; operators pass it for direct server-side recompiles. Must be unique per federation member (0/1 are reserved)." validate:"omitempty"`
	FedlibPrefix    string `name:"fedlibPrefix" json:"fedlibPrefix" help:"Fedlib S3 prefix; bakes /files/<prefix> into each book's BaseURL at build time so spliced regions carry correct links. Normally set by 'lib join'." validate:"omitempty"`
	JsonL           *bool  `name:"jsonl-export" json:"-" help:"If the flag is provided, export the Calibre catalog to the JSONL file." validate:"omitempty"`
	JsonLPath       string `name:"jsonl-path" json:"jsonl-path" help:"Path to the JSONL for the Calibre catalog: exported here from metadata.db, and read back as the build input when no metadata.db is present (default: cache/<alias>.jsonl under the config dir)." validate:"omitempty,filepath"`
	Index           *bool  `name:"index" json:"-" help:"If the flag is provided, create ONLY the search index (a bare build renders the site and builds the index)." validate:"omitempty"`
	IndexPath       string `name:"index-path" json:"index-path" help:"Path to the file where the index from Calibre catalog will be created (default: <calibrepath>/static/library_index)." validate:"omitempty,filepath" sharedgroup:"lib"`
	Append          *bool  `name:"append" json:"-" help:"Append delta to the existing index instead of a full rebuild." xor:"build_mode" validate:"omitempty"`
	Compact         *bool  `name:"compact" json:"-" help:"Full rebuild; preserves the index identity (so incremental followers can re-sync) and resets tombstones." xor:"build_mode" validate:"omitempty"`
	CompactIfNeeded *bool  `name:"compact-if-needed" json:"-" help:"Auto-compact if region count or tombstone ratio exceeds threshold." xor:"build_mode" validate:"omitempty"`
	LibraryName     string `name:"library-name" json:"library-name" help:"Human name for this library (stamped into the pointer file for remote browsers)." validate:"omitempty" sharedgroup:"lib"`
}

type LibBuildCmd struct {
	CommonCommandFields
	GroupLib
	GroupSandpoints
	TeaOutputs

	FetchCovers *bool  `name:"fetch-covers" json:"-" help:"Fetch missing covers from S3 for fingerprinting (requires --keys-file or S3 credentials)." validate:"omitempty"`
	KeysFile    string `name:"keys-file" json:"keys-file" help:"Path to the operator S3 keys-file (default: keys/<alias>.s3.keys under the config dir)." validate:"omitempty"`
	S3AccessKey string `name:"s3-access-key" json:"s3-access-key" alias:"-" help:"S3 access key." validate:"omitempty" sharedgroup:"s3creds" secret:"redact,fingerprint"`
	S3SecretKey string `name:"s3-secret-key" json:"s3-secret-key" alias:"-" help:"S3 secret key." validate:"omitempty" sharedgroup:"s3creds" secret:"redact,fingerprint"`
	S3Provider  string `name:"s3-provider" json:"s3-provider" alias:"-" help:"S3 provider." validate:"omitempty" sharedgroup:"s3creds"`
	S3Endpoint  string `name:"s3-endpoint" json:"s3-endpoint" alias:"-" help:"S3 endpoint URL." validate:"omitempty" sharedgroup:"s3creds"`
	Bucket      string `name:"bucket" json:"bucket" propagate:"-" help:"S3 bucket (with prefix, e.g. motw/prefix)." validate:"omitempty"`

	PrivateExcludes []string `kong:"-" json:"-"`
}

func jsonlNeedsExport(jsonlPath, calibreDir string) bool {
	ji, err := os.Stat(jsonlPath)
	if err != nil {
		return true
	}
	di, err := os.Stat(filepath.Join(calibreDir, "metadata.db"))
	if err != nil {
		fmt.Fprintf(os.Stderr, "lib build: reusing cached JSONL %s — no metadata.db under %q to check staleness; pass --calibrepath (or delete the cached JSONL) if the library changed\n", jsonlPath, calibreDir)
		return false
	}
	return !di.ModTime().Before(ji.ModTime())
}

func contentLedgerProgressPrinter() func(contentLedgerProgress) {
	started := false
	lastPrinted := time.Time{}
	return func(progress contentLedgerProgress) {
		now := time.Now()
		if !started {
			started = true
			lastPrinted = now
			if progress.HashFiles == 0 {
				fmt.Fprintf(os.Stderr, "lib build: reused saved checksums for all %d publishable files; no file contents need reading\n", progress.TotalFiles)
				return
			}
			fmt.Fprintf(os.Stderr,
				"lib build: checking file contents — %d of %d publishable files (%s of %s) must be read; unchanged saved checksums will be reused\n",
				progress.HashFiles, progress.TotalFiles, formatByteSize(progress.HashBytes), formatByteSize(progress.TotalBytes))
			return
		}
		if progress.HashFiles == 0 {
			return
		}
		complete := progress.HashedFiles == progress.HashFiles
		if !complete && now.Sub(lastPrinted) < 2*time.Second {
			return
		}
		lastPrinted = now
		fmt.Fprintf(os.Stderr,
			"lib build: file checksums %d/%d, %s/%s read (%d saved checksums reused)\n",
			progress.HashedFiles, progress.HashFiles,
			formatByteSize(progress.HashedBytes), formatByteSize(progress.HashBytes),
			progress.ReusedFiles)
	}
}

// buildSourceStageHook injects source changes around catalog compilation.
// Production leaves it nil.
var buildSourceStageHook func(string) error

func runBuildSourceStageHook(stage string) error {
	if buildSourceStageHook != nil {
		return buildSourceStageHook(stage)
	}
	return nil
}

func (c *LibBuildCmd) Run(ctx *kong.Context) error {
	finishBuild := beginLibraryWork("build-command")
	defer finishBuild(1)
	c.Header = ".◟◜lib build◝◞."
	if c.HandleShowConfig(c) {
		return nil
	}
	if err := c.EnsureCalibreDir(ctx, c.ActionAlias); err != nil {
		return err
	}
	c.applyBuildDefaults()
	if !c.InPipeline && c.ActionAlias != "" {
		release, err := acquireLibraryExecutionLock(c.ActionAlias)
		if err != nil {
			return err
		}
		defer release()
	}
	if _, err := os.Stat(derivedEvidenceRepairPath(c.ActionAlias)); err == nil {
		return fmt.Errorf("lib build: finish the interrupted index repair with `accorder lib publish %s` before rebuilding", c.ActionAlias)
	} else if !os.IsNotExist(err) {
		return err
	}
	if _, err := os.Stat(publishRecoveryPath(c.ActionAlias)); err == nil {
		return fmt.Errorf("lib build: finish the interrupted publication with `accorder lib publish %s` before rebuilding; the saved index and recovery information were preserved", c.ActionAlias)
	} else if !os.IsNotExist(err) {
		return err
	}
	// Retain the last durable checkpoint until its replacement is complete.
	// Attachment validates the source and index; deleting this record before
	// building loses pending paths and reusable hashes on an interrupted build.
	previousBuildCandidate := loadReusableBuildCandidate(c.CalibreDirectory, c.LibraryID, c.IndexPath)
	retainedBuildCandidate, checkpointErr := loadLocalChangeCandidate(c.CalibreDirectory)
	if checkpointErr != nil && localChangeCandidateFile(c.CalibreDirectory) == evidenceStatePath(legacyChangeCandidateFile(c.CalibreDirectory)) {
		return fmt.Errorf("lib build: saved build checkpoint was retained for inspection; cannot replace it: %w", checkpointErr)
	}
	if retainedBuildCandidate != nil && retainedBuildCandidate.LibraryUUID != c.LibraryID {
		retainedBuildCandidate = nil
	}

	if c.FetchCovers != nil {
		if c.S3AccessKey == "" || c.S3SecretKey == "" {
			return fmt.Errorf("lib build: --fetch-covers requires S3 credentials (provide --keys-file or --s3-access-key/--s3-secret-key)")
		}
		if c.Bucket == "" {
			return fmt.Errorf("lib build: --fetch-covers requires --bucket")
		}
	}

	if c.FedlibPrefix != "" && c.DictID < 2 {
		return fmt.Errorf("lib build: federation-member build (--fedlibPrefix %q) requires a unique --dictID >= 2 (got %d); DictID 0/1 are reserved and collide at aggregate compose. `lib join` sets it from the invite; to repair an existing member run `accorder fedlib members reindex`", c.FedlibPrefix, c.DictID)
	}

	pointerName := c.LibraryName
	if pointerName == "" {
		pointerName = c.Librarian
	}

	motwApp := &calibre.MotwStandaloneApp{
		CalibreDirectory: c.CalibreDirectory,
		Librarian:        c.Librarian,
		LibraryUUID:      c.LibraryID,
	}

	if c.BaseURL != nil {
		motwApp.BaseURL = *c.BaseURL
	}

	var renderOutput string
	var buildChangeCandidate *localChangeCandidate
	var buildEvidence *sourceEvidence
	databaseBefore, err := observeBuildDatabase(c.CalibreDirectory)
	if err != nil {
		return fmt.Errorf("lib build: inspect catalog source: %w", err)
	}
	bareBuild := c.Index == nil
	if bareBuild {
		finishRender := beginLibraryWork("render")
		renderOutput = motwApp.Render()
		finishRender(1)
		c.PrivateExcludes = motwApp.PrivateExcludes
		if err := os.MkdirAll(filepath.Dir(c.JsonLPath), 0o755); err != nil {
			return fmt.Errorf("lib build: create JSONL dir: %w", err)
		}
		if err := motwApp.JsonLE(c.JsonLPath); err != nil {
			return fmt.Errorf("lib build: export JSONL: %w", err)
		}
	} else if jsonlNeedsExport(c.JsonLPath, c.CalibreDirectory) ||
		(databaseBefore != nil && databaseBefore.SQLite && !cachedCatalogDatabaseMatches(databaseBefore, previousBuildCandidate)) {
		fmt.Fprintf(os.Stderr, "lib build: JSONL %s missing or stale — re-exporting from %s first\n", c.JsonLPath, c.CalibreDirectory)
		if err := motwApp.LoadBooksE(); err != nil {
			return fmt.Errorf("lib build: load books for JSONL export: %w", err)
		}
		if err := os.MkdirAll(filepath.Dir(c.JsonLPath), 0o755); err != nil {
			return fmt.Errorf("lib build: create JSONL dir: %w", err)
		}
		if err := motwApp.JsonLE(c.JsonLPath); err != nil {
			return fmt.Errorf("lib build: export JSONL: %w", err)
		}
	}
	{
		motwSearch := &calibre.MotwSearch{
			JsonlPath:            c.JsonLPath,
			IndexPath:            c.IndexPath,
			DictID:               c.DictID,
			IndexAggregateFields: c.DictID != 0,
		}
		var motwLibraries map[string]calibre.MotwLibrary
		motwLibrariesFile, err := os.ReadFile(filepath.Join(accorderConfigDir, "motw_libraries.json"))
		switch {
		case err == nil:
			if err := json.Unmarshal(motwLibrariesFile, &motwLibraries); err != nil {
				return fmt.Errorf("parse motw_libraries.json: %w", err)
			}
			if c.LibraryID != "" {
				if _, ok := motwLibraries[c.LibraryID]; !ok {
					motwLibraries[c.LibraryID] = calibre.MotwLibrary{Librarian: c.Librarian, State: "ready"}
				}
			}
		case os.IsNotExist(err):
			if c.LibraryID == "" {
				return fmt.Errorf("lib build --index: no motw_libraries.json found and --libraryID is empty")
			}
			motwLibraries = map[string]calibre.MotwLibrary{
				c.LibraryID: {Librarian: c.Librarian, State: "ready"},
			}
		default:
			return fmt.Errorf("read motw_libraries.json: %w", err)
		}

		books, err := motwSearch.GetBooksJSONL(motwLibraries)
		if err != nil {
			return fmt.Errorf("get books from %s: %w", c.JsonLPath, err)
		}

		before := len(books)
		var privateGlobs []string
		books, privateGlobs = calibre.PartitionPrivateBooks(books)
		if !bareBuild {
			c.PrivateExcludes = privateGlobs
		}
		if dropped := before - len(books); dropped > 0 {
			fmt.Fprintf(os.Stderr, "lib build: excluded %d book(s) tagged \"private\" from the published index\n", dropped)
		}
		if err := runBuildSourceStageHook("after-catalog-read"); err != nil {
			return err
		}
		if err := verifyBuildDatabase(c.CalibreDirectory, databaseBefore); err != nil {
			return err
		}
		for _, book := range books {
			// The canonical record protocol requires arrays to remain present even
			// when Calibre or an older JSONL fixture supplies nil. Establish that
			// invariant in the authoritative index, not only in checksum projection.
			if book.Authors == nil {
				book.Authors = []string{}
			}
			if book.Languages == nil {
				book.Languages = []string{}
			}
			if book.Tags == nil {
				book.Tags = []string{}
			}
			if book.Formats == nil {
				book.Formats = []*calibre.File{}
			}
			if book.Identifiers == nil {
				book.Identifiers = []*calibre.Identifier{}
			}
		}

		motwApp.Books = books

		sourceCandidateEligible := false
		if metadataInfo, statErr := os.Stat(filepath.Join(c.CalibreDirectory, "metadata.db")); statErr == nil {
			sourceCandidateEligible = !metadataInfo.IsDir()
		} else if !os.IsNotExist(statErr) {
			return fmt.Errorf("lib build: inspect metadata.db: %w", statErr)
		}
		var baseline *libraryBaseline
		candidateFallbackReason := ""
		priorGeneration := ""
		var ledger []libraryflow.Object
		var changedCurrent, removedPaths []string
		if sourceCandidateEligible {
			if c.ActionAlias != "" {
				baseline, err = loadBaseline(c.ActionAlias)
				if err != nil {
					fmt.Fprintf(os.Stderr, "lib build: saved file-change history is unreadable; precise changed-book tracking is unavailable for this build: %v\n", err)
					baseline = nil
					candidateFallbackReason = "invalid-content-baseline"
				}
				if baseline != nil && baseline.LibraryID != c.LibraryID {
					fmt.Fprintln(os.Stderr, "lib build: saved file-change history belongs to another library; precise changed-book tracking is unavailable for this build")
					baseline = nil
					candidateFallbackReason = "content-baseline-library-mismatch"
				}
			}
			var generationErr error
			priorGeneration, generationErr = readLocalGenerationHex(c.CalibreDirectory)
			if os.IsNotExist(generationErr) && baseline != nil && baseline.ContentLedgerVersion >= 1 {
				// A verified sync deliberately excludes the remote sentinel from
				// the mirror. Its activated baseline supplies the full predecessor.
				priorGeneration = baseline.GenerationToken
			}
			if generationErr != nil && !os.IsNotExist(generationErr) {
				fmt.Fprintf(os.Stderr, "lib build: local publication marker is unreadable; precise changed-book tracking is unavailable for this build: %v\n", generationErr)
				candidateFallbackReason = "invalid-local-generation"
			}
		}
		var previousRecords map[string]calibre.CatalogRecordInfo
		var legacyFingerprintMap map[string]string
		if _, statErr := os.Stat(c.IndexPath + ".zst"); statErr == nil {
			finishCatalog := beginLibraryWork("catalog-read")
			previousRecords, err = calibre.ReadCatalogRecordInfos(c.IndexPath)
			finishCatalog(len(previousRecords))
			if err != nil {
				fmt.Fprintf(os.Stderr, "lib build: previous library index cannot be compared; precise changed-book tracking is unavailable for this build: %v\n", err)
				previousRecords = nil
				candidateFallbackReason = "invalid-local-predecessor"
				// External JSONL-only builds have no source tree, cannot publish
				// exact evidence, and historically reused opaque fingerprints from
				// older indexes whose required arrays may be null. Preserve that
				// display optimization without granting exact manifest scope.
				if !sourceCandidateEligible {
					if priorBooks, legacyErr := calibre.AllBooksFromIndex(c.IndexPath); legacyErr == nil {
						legacyFingerprintMap = make(map[string]string, len(priorBooks))
						for _, book := range priorBooks {
							if book.CoverFingerprint != "" {
								legacyFingerprintMap[book.Id] = book.CoverFingerprint
							}
						}
					}
				}
			}
		} else if !os.IsNotExist(statErr) {
			return fmt.Errorf("lib build: inspect prior index: %w", statErr)
		}
		if sourceCandidateEligible {
			inventory, err := scanSourceObjects(c.CalibreDirectory)
			if err != nil {
				return fmt.Errorf("lib build: list publishable library files: %w", err)
			}
			var previousLedger []libraryflow.Object
			if previousBuildCandidate != nil {
				previousLedger = previousBuildCandidate.ContentLedger
			} else if retainedBuildCandidate != nil {
				previousLedger = retainedBuildCandidate.ContentLedger
				candidateFallbackReason = "invalid-local-candidate-chain"
			} else if baseline != nil && baseline.ContentLedgerVersion >= 1 {
				previousLedger = baseline.ContentLedger
			}
			var previousEvidence *sourceEvidence
			if previousBuildCandidate != nil {
				previousEvidence = previousBuildCandidate.Evidence
			} else if retainedBuildCandidate != nil {
				previousEvidence = retainedBuildCandidate.Evidence
			} else if baseline != nil {
				previousEvidence = baseline.Evidence
			}
			installation, installErr := loadOrCreateInstallation()
			if installErr != nil {
				return fmt.Errorf("lib build: load local change-tracking identity: %w", installErr)
			}
			ledger, buildEvidence, changedCurrent, removedPaths, err = buildSourceEvidence(
				c.CalibreDirectory, inventory.Objects,
				currentUploadExcludes(c.PrivateExcludes), previousLedger,
				previousEvidence, installation.SeatID, inventory,
			)
			if err != nil {
				return fmt.Errorf("lib build: check publishable library files: %w", err)
			}
			if len(previousLedger) == 0 {
				fmt.Fprintln(os.Stderr, "lib build: recording file information without reading every book")
			} else {
				for _, object := range previousLedger {
					if object.Hash != "" {
						fmt.Fprintln(os.Stderr, "lib build: reusing saved checksums; checking files for changes")
						break
					}
				}
			}
			fmt.Fprintf(os.Stderr, "lib build: checked metadata for %d publishable files; %d added or possibly changed, %d removed; no book-format checksums required\n", len(ledger), len(changedCurrent), len(removedPaths))
			if baseline != nil && baseline.LocalSourceFingerprint != baseline.RemoteSourceFingerprint {
				baseline = nil
				candidateFallbackReason = "missing-content-baseline"
			}
			if previousEvidence != nil && previousEvidence.Provenance != buildEvidence.Provenance {
				candidateFallbackReason = "source-provenance-changed"
			}
			if !hasUsableSourceSignals(ledger, buildEvidence) {
				candidateFallbackReason = "source-coherence-unavailable"
			}
		}
		currentBeforeFingerprint := make(map[string]calibre.CatalogRecordInfo, len(books))
		comparisonBaseURL, comparisonLibraryURL := "", ""
		if c.FedlibPrefix != "" {
			comparisonBaseURL, comparisonLibraryURL = calibre.FilesBaseURL(c.FedlibPrefix)
		}
		for _, book := range books {
			comparisonBook := *book
			if c.FedlibPrefix != "" {
				comparisonBook.BaseURL = comparisonBaseURL
				comparisonBook.LibraryUrl = comparisonLibraryURL
			}
			info, infoErr := calibre.CatalogRecordInfoForBook(&comparisonBook)
			if infoErr != nil {
				return fmt.Errorf("lib build: compare current book record: %w", infoErr)
			}
			currentBeforeFingerprint[book.Id] = info
		}
		payloadIDs, _ := payloadChangedIDs(changedCurrent, removedPaths, currentBeforeFingerprint, previousRecords)

		var fpMap map[string]string
		var carryForwardLoaded bool
		if c.Compact == nil && (len(previousRecords) > 0 || legacyFingerprintMap != nil) {
			if len(previousRecords) > 0 {
				fpMap = candidateCarryForward(previousRecords, currentBeforeFingerprint, payloadIDs)
			} else {
				fpMap = legacyFingerprintMap
			}
			carryForwardLoaded = true
		}
		if fpMap == nil {
			fpMap = make(map[string]string)
		}

		fetchCovers := c.FetchCovers != nil
		var s3Src string
		var fpTempDir string
		if fetchCovers {
			remoteName := "accorder-fetchcovers-" + c.ActionAlias
			if err := rclonexfer.SetCacheDir(accorderCacheDir()); err != nil {
				return fmt.Errorf("lib build: set cache dir: %w", err)
			}
			rclonexfer.Initialize()
			defer rclonexfer.Finalize()

			_ = rclonexfer.DeleteRemote(remoteName)
			if err := rclonexfer.ConfigS3Remote(remoteName, rclonexfer.S3RemoteConfig{
				Provider:  c.S3Provider,
				AccessKey: c.S3AccessKey,
				SecretKey: c.S3SecretKey,
				Endpoint:  c.S3Endpoint,
			}); err != nil {
				return fmt.Errorf("lib build: config s3 remote: %w", err)
			}
			defer func() { _ = rclonexfer.DeleteRemote(remoteName) }()

			s3Src = remoteName + ":" + c.Bucket
			fpTempDir, err = os.MkdirTemp("", "accorder-fetchcovers-*")
			if err != nil {
				return fmt.Errorf("lib build: create temp dir for cover fetches: %w", err)
			}
			defer os.RemoveAll(fpTempDir)
		}

		if fpWorkers := min(runtime.NumCPU(), len(books)); fpWorkers > 0 {
			var fpHits, fpMisses, fpFetched, fpFetchErrors atomic.Int64
			bookCh := make(chan *calibre.Book, fpWorkers)
			var fpWG sync.WaitGroup
			for w := 0; w < fpWorkers; w++ {
				fpWG.Add(1)
				go func() {
					defer fpWG.Done()
					for book := range bookCh {
						if cached := fpMap[book.Id]; cached != "" {
							book.CoverFingerprint = cached
							fpHits.Add(1)
							continue
						}
						fpMisses.Add(1)
						if fetchCovers {
							fp := fetchAndFingerprint(s3Src, book.CoverUrl, fpTempDir)
							if !calibre.IsZeroFingerprint(fp) {
								book.CoverFingerprint = calibre.EncodeFingerprintBase64(fp)
								fpFetched.Add(1)
							} else {
								fpFetchErrors.Add(1)
							}
						} else if fp, ok := calibre.LocalCoverFingerprint(c.CalibreDirectory, book.CoverUrl); ok {
							book.CoverFingerprint = fp
						}
					}
				}()
			}
			for _, book := range books {
				bookCh <- book
			}
			close(bookCh)
			fpWG.Wait()

			hits, misses := fpHits.Load(), fpMisses.Load()
			if fetchCovers {
				fetched, fetchErrs := fpFetched.Load(), fpFetchErrors.Load()
				fmt.Fprintf(os.Stderr, "lib build: cover checksums — %d reused, %d calculated from covers downloaded from S3\n", hits, fetched)
				if fetchErrs > 0 {
					fmt.Fprintf(os.Stderr, "lib build: could not download %d covers; those books will use an empty cover checksum\n", fetchErrs)
				}
				if misses > 0 && fetchErrs*100/misses > 50 {
					fmt.Fprintf(os.Stderr, "WARNING: %d/%d cover fetches failed — check --bucket and S3 credentials\n", fetchErrs, misses)
				}
			} else if carryForwardLoaded {
				fmt.Fprintf(os.Stderr, "lib build: cover checksums — %d reused, %d calculated locally\n", hits, misses)
			}
		}

		if bareBuild {
			dataBooks := append([]*calibre.Book(nil), motwApp.Books...)
			sort.Sort(sort.Reverse(calibre.CalibreBooksByLastModified(dataBooks)))
			calibre.WriteBrowseDataJS(filepath.Join(c.CalibreDirectory, "static"), dataBooks)
		}

		// The fedlib files prefix belongs to the *index* books only — the
		// aggregate serves them under /files/<prefix>/. It must be applied after
		// the data*.js write above: the static site and the solo share resolve
		// files relative to the web root, so data*.js keeps unprefixed URLs.
		if c.FedlibPrefix != "" {
			baseURL, libURL := calibre.FilesBaseURL(c.FedlibPrefix)
			for _, b := range books {
				b.BaseURL = baseURL
				b.LibraryUrl = libURL
			}
		}

		if err := os.MkdirAll(filepath.Dir(c.IndexPath), 0o755); err != nil {
			return fmt.Errorf("lib build: create index dir: %w", err)
		}
		mergedPath := c.IndexPath + ".jsonl"

		finishDiff := beginLibraryWork("catalog-diff")
		catalogDiff, err := calibre.CompileCatalogDiffFromRecordInfos(books, previousRecords)
		finishDiff(len(books))
		if err != nil {
			return fmt.Errorf("lib build: compare this build with the previous library index: %w", err)
		}
		if sourceCandidateEligible {
			// TargetSourceFingerprint is unconditionally overwritten with the
			// real value below once the built index artifact is known; nothing
			// reads it before then, so it starts empty rather than as a
			// SHA-256-shaped placeholder that could be mistaken for meaningful
			// data (e.g. an empty-catalog sentinel).
			var candidate localChangeCandidate
			if canChainLocalBuildCandidate(previousBuildCandidate, priorGeneration, catalogDiff) {
				// Compile only B->C against the previous local build, then compose
				// it with the checkpoint's unpublished A->B transition. The real
				// published baseline remains the authority at upload binding.
				localBaseline := &libraryBaseline{
					GenerationToken: priorGeneration, CatalogChecksum: catalogDiff.FromChecksum,
					ContentLedgerVersion: 1,
				}
				delta := compileLocalChangeCandidate(
					c.LibraryID, priorGeneration, "", catalogDiff, ledger,
					changedCurrent, removedPaths, localBaseline,
				)
				candidate, err = composeLocalBuildCandidate(*previousBuildCandidate, delta)
				if err != nil {
					fmt.Fprintf(os.Stderr, "lib build: previous unpublished build cannot be continued; precise changed-book tracking is unavailable for this build: %v\n", err)
					candidate = delta
					candidate.makeCoarse("invalid-local-candidate-chain", true)
				}
			} else {
				candidate = compileLocalChangeCandidate(
					c.LibraryID, priorGeneration, "", catalogDiff, ledger,
					changedCurrent, removedPaths, baseline,
				)
			}
			if candidateFallbackReason != "" {
				candidate.makeCoarse(candidateFallbackReason, true)
			}
			if candidate.Reason == "legacy-content-baseline-upgrade" {
				// v0 timestamps may have been refreshed without any payload sync.
				// Preserve local hashes, but do not inherit that coverage claim.
				candidate.makeCoarse("legacy-content-baseline-upgrade", true)
			}
			candidate.Version, candidate.ContentLedgerVersion = sourceEvidenceVersion, sourceEvidenceVersion
			candidate.Evidence = buildEvidence
			// Without a published baseline, a changed local generation marker
			// is not evidence that these pending uploads reached the remote.
			// Likewise retain them when the index chain was interrupted.
			if retainedBuildCandidate != nil && (previousBuildCandidate == nil || baseline == nil || retainedBuildCandidate.FromGeneration == priorGeneration) {
				candidate.ForcePaths = mergeCandidateForcePaths(candidate.ForcePaths, retainedBuildCandidate.ForcePaths, ledger)
			}
			buildChangeCandidate = &candidate
		}

		skipRebuild := false
		if c.Append == nil && c.Compact == nil && c.CompactIfNeeded == nil {
			checkpointAlreadyAdvanced := canChainLocalBuildCandidate(previousBuildCandidate, priorGeneration, catalogDiff) &&
				len(catalogDiff.Changes) == 0 && len(changedCurrent) == 0 && len(removedPaths) == 0
			needsGenerationAdvance := buildChangeCandidate != nil &&
				(buildChangeCandidate.Scope != calibre.GenerationChangeScopeExact || len(changedCurrent) > 0 || len(removedPaths) > 0) &&
				!checkpointAlreadyAdvanced
			if ok, existingMf := indexUpToDate(books, c.IndexPath, mergedPath); ok && !needsGenerationAdvance {
				lib := calibre.PointerFileLibrary{UUID: c.LibraryID, Librarian: c.Librarian, Name: pointerName}
				if pf, err := calibre.ReadPointerFile(c.IndexPath + ".manifest.json"); err != nil || pf.Library != lib {
					if pfErr := calibre.WritePointerFile(c.IndexPath, existingMf, lib, false); pfErr != nil {
						return fmt.Errorf("no-change build: refresh pointer file: %w", pfErr)
					}
				}
				fmt.Fprintln(os.Stderr, "lib build: no changes detected — index artifacts left untouched (pass --compact to force a rebuild)")
				skipRebuild = true
			}
		}

		if !skipRebuild {
			motwApp.JsonL(mergedPath)

			if cErr := compressFileZstd(mergedPath, c.IndexPath+".jsonl.zst"); cErr != nil {
				log.Printf("lib build: compress jsonl: %v (non-fatal)", cErr)
			}
		}

		motwSearch.JsonlPath = mergedPath

		appendDone := skipRebuild
		if c.Append != nil {
			existingDisplay, err := calibre.ReadDisplayJSONL(c.IndexPath)
			if err != nil {
				if !os.IsNotExist(err) {
					return fmt.Errorf("read existing display for diff: %w", err)
				}
				fmt.Fprintf(os.Stderr, "Append: no existing index at %s.zst — falling back to full build.\n", c.IndexPath)
			} else {
				delta, tombstones, err := calibre.DiffBooks(books, bytes.NewReader(existingDisplay))
				if err != nil {
					return fmt.Errorf("diff books: %w", err)
				}
				if len(delta) == 0 && len(tombstones) == 0 {
					fmt.Fprintln(os.Stderr, "Append: no changes detected — index unchanged.")
					if existingMf, mErr := calibre.ReadExistingManifest(c.IndexPath); mErr == nil {
						lib := calibre.PointerFileLibrary{UUID: c.LibraryID, Librarian: c.Librarian, Name: pointerName}
						if pfErr := calibre.EnsurePointerFile(c.IndexPath, existingMf, lib); pfErr != nil {
							return fmt.Errorf("append no-change: ensure pointer file: %w", pfErr)
						}
					} else {
						fmt.Fprintf(os.Stderr, "Append: no changes, but could not read manifest to ensure pointer file: %v\n", mErr)
					}
					appendDone = true
				} else {
					deltaPath := c.IndexPath + ".delta.jsonl"
					motwApp.Books = delta
					motwApp.JsonL(deltaPath)
					motwSearch.JsonlPath = deltaPath
					idx, err := motwSearch.BuildIndex()
					if err != nil {
						return fmt.Errorf("build delta index: %w", err)
					}
					if err := motwSearch.AppendToFile(idx, tombstones); err != nil {
						return fmt.Errorf("append to %s.zst: %w", c.IndexPath, err)
					}
					if mf, mErr := calibre.ReadExistingManifest(c.IndexPath); mErr == nil {
						fmt.Fprintf(os.Stderr, "Append: +%d books, %d tombstones — generation=%d, %d regions, %d books total.\n",
							len(delta), len(tombstones), mf.Generation, len(mf.Regions), mf.NumBooks)
						lib := calibre.PointerFileLibrary{UUID: c.LibraryID, Librarian: c.Librarian, Name: pointerName}
						if pfErr := calibre.WritePointerFile(c.IndexPath, mf, lib, false); pfErr != nil {
							return fmt.Errorf("append: write pointer file: %w", pfErr)
						}
						if shouldHintCompact(mf) {
							fmt.Fprintf(os.Stderr, "  hint: %d regions, %d tombstones — consider --compact to GC dead bytes.\n",
								len(mf.Regions), len(mf.Tombstones))
						}
					} else {
						fmt.Fprintf(os.Stderr, "Append: +%d books, %d tombstones (manifest readback failed: %v)\n",
							len(delta), len(tombstones), mErr)
					}
					appendDone = true
				}
			}
		}

		if c.CompactIfNeeded != nil && !appendDone {
			existingMf, readErr := calibre.ReadExistingManifest(c.IndexPath)
			if readErr != nil {
				fmt.Fprintf(os.Stderr, "Compact-if-needed: no existing index — performing full build.\n")
			} else if shouldAutoCompact(existingMf, false) {
				fmt.Fprintf(os.Stderr, "Compact-if-needed: %d regions, %d tombstones — compacting.\n",
					len(existingMf.Regions), len(existingMf.Tombstones))
				c.Compact = new(bool)
				motwSearch.BaseGeneration = &existingMf.BaseGeneration
			} else {
				fmt.Fprintf(os.Stderr, "Compact-if-needed: %d regions, %d tombstones — no compaction needed.\n",
					len(existingMf.Regions), len(existingMf.Tombstones))
				lib := calibre.PointerFileLibrary{UUID: c.LibraryID, Librarian: c.Librarian, Name: pointerName}
				if err := calibre.EnsurePointerFile(c.IndexPath, existingMf, lib); err != nil {
					return fmt.Errorf("compact-if-needed no-op: ensure pointer file: %w", err)
				}
				appendDone = true
			}
		}

		if !appendDone {
			idx, err := motwSearch.BuildIndex()
			if err != nil {
				return fmt.Errorf("build index: %w", err)
			}
			if c.Compact != nil && motwSearch.BaseGeneration == nil {
				existingMf, readErr := calibre.ReadExistingManifest(c.IndexPath)
				if readErr == nil {
					motwSearch.BaseGeneration = &existingMf.BaseGeneration
				}
			}
			if err := motwSearch.CompressToFile(idx); err != nil {
				return fmt.Errorf("compress index to %s.zst: %w", c.IndexPath, err)
			}
			if mf, mErr := calibre.ReadExistingManifest(c.IndexPath); mErr == nil {
				lib := calibre.PointerFileLibrary{UUID: c.LibraryID, Librarian: c.Librarian, Name: pointerName}
				isCompacted := c.Compact != nil
				if pfErr := calibre.WritePointerFile(c.IndexPath, mf, lib, isCompacted); pfErr != nil {
					return fmt.Errorf("compress: write pointer file: %w", pfErr)
				}
			}
		}

		pointerPath := c.IndexPath + ".manifest.json"
		pointer, pointerErr := calibre.ReadPointerFile(pointerPath)
		if pointerErr != nil {
			return fmt.Errorf("lib build: read generated library-index metadata: %w", pointerErr)
		}
		pointer.CatalogChecksum = catalogDiff.ToChecksum
		if err := calibre.WritePointerDocument(pointerPath, pointer); err != nil {
			return fmt.Errorf("lib build: save generated library-index checksum: %w", err)
		}
		if !sourceCandidateEligible || priorGeneration == "" {
			if err := stampMemberGeneration(c.CalibreDirectory, c.IndexPath); err != nil {
				fmt.Fprintf(os.Stderr, "lib build: save local publication marker: %v\n", err)
			}
		}
	}

	if c.Index == nil || len(c.PrivateExcludes) > 0 || len(readUploadExcludes(c.CalibreDirectory)) > 0 {
		if err := writeUploadExcludes(c.CalibreDirectory, c.PrivateExcludes); err != nil {
			fmt.Fprintf(os.Stderr, "lib build: write upload-excludes manifest: %v\n", err)
		}
	}
	if buildChangeCandidate != nil {
		if err := runBuildSourceStageHook("before-checkpoint"); err != nil {
			return err
		}
		if err := verifyBuildDatabase(c.CalibreDirectory, databaseBefore); err != nil {
			return err
		}
		if hasUsableSourceSignals(buildChangeCandidate.ContentLedger, buildEvidence) {
			inventory, err := scanSourceObjects(c.CalibreDirectory)
			if err != nil {
				return err
			}
			_, _, changed, removed, err := refreshSourceEvidence(c.CalibreDirectory, inventory.Objects,
				currentUploadExcludes(c.PrivateExcludes), buildChangeCandidate.ContentLedger, buildEvidence, inventory)
			if err != nil {
				return err
			}
			if len(changed) != 0 || len(removed) != 0 {
				return fmt.Errorf("lib build: library files changed during build; build again; previous checkpoint was preserved")
			}
		}
		indexRel := indexSiblingRel(c.CalibreDirectory, c.IndexPath, ".zst")
		if indexRel == "" {
			return fmt.Errorf("lib build: the generated index must be inside --calibrepath so it can be published safely")
		}
		indexInfo, err := os.Stat(c.IndexPath + ".zst")
		if err != nil {
			return fmt.Errorf("lib build: inspect generated compressed index: %w", err)
		}
		indexArtifact := libraryflow.NewLocalObjectAt(indexRel, c.IndexPath+".zst", indexInfo)
		indexDigest := ""
		if previousBuildCandidate != nil && canReuseContentDigest(indexArtifact, previousBuildCandidate.IndexArtifact) {
			indexDigest = previousBuildCandidate.IndexArtifact.Hash
		} else {
			indexDigest, err = hashLocalFile(c.IndexPath + ".zst")
			if err != nil {
				return fmt.Errorf("lib build: checksum generated compressed index: %w", err)
			}
		}
		buildChangeCandidate.IndexArtifact = indexArtifact
		buildChangeCandidate.IndexArtifact.Hash = indexDigest
		fingerprint, err := sourceFingerprintFromContentLedger(buildChangeCandidate.ContentLedger)
		if err != nil {
			return fmt.Errorf("lib build: checksum publishable library files: %w", err)
		}
		buildChangeCandidate.TargetSourceFingerprint = fingerprint
		if err := saveLocalChangeCandidate(c.CalibreDirectory, *buildChangeCandidate); err != nil {
			return fmt.Errorf("lib build: save information needed for the next publish: %w", err)
		}
		if buildChangeCandidate.Scope == calibre.GenerationChangeScopeExact && len(buildChangeCandidate.Changes) == 0 {
			fmt.Fprintln(os.Stderr, "lib build: no book changes found; the next publish will verify that the remote library index is current")
		} else if buildChangeCandidate.Scope == calibre.GenerationChangeScopeExact {
			fmt.Fprintf(os.Stderr, "lib build: prepared an update for %d changed %s; after publication, the server will refresh only the affected cache directories\n",
				len(buildChangeCandidate.Changes), plural(len(buildChangeCandidate.Changes), "book", "books"))
		} else {
			fmt.Fprintf(os.Stderr, "lib build: an exact changed-book list is unavailable, so after publication the server will refresh this library's whole cache (%s)\n",
				generationChangeReasonDetails(buildChangeCandidate.Reason))
		}
		if forced := len(buildChangeCandidate.ForcePaths); forced > 0 {
			fmt.Fprintf(os.Stderr, "lib build: %d changed %s will be uploaded again even if the file size is unchanged\n",
				forced, plural(forced, "file", "files"))
		}
		if buildChangeCandidate.CompleteOverwrite {
			fmt.Fprintln(os.Stderr, "lib build: publishing this build may require uploading every public library file again; Accorder will ask for --allow-full-reupload")
		}
	}

	var updateMsg bubble.CalibreProgressMsg

	updateMsg.CalibreOutput = renderOutput
	if c.InPipeline {
		updateMsg.CalibreHeader = c.Header
	}

	if c.Json != nil {
		motwApp.SandpointsCatalog(c.JsonPath)
	}

	if c.JsonL != nil {
		motwApp.JsonL(c.JsonLPath)
	}

	fmt.Println(bubble.RenderCalibreOutput(updateMsg.CalibreHeader, updateMsg.CalibreOutput))

	return nil
}

func (c *LibBuildCmd) applyBuildDefaults() { c.ResolveEffective() }

// ResolveEffective derives the paths lib build computes from other
// settings. Pure and idempotent; no descriptor or credential access.
func (c *LibBuildCmd) ResolveEffective() []FieldIssue {
	prov := c.provenanceTable()
	self := reflect.ValueOf(c).Elem()

	if c.IndexPath == "" && c.CalibreDirectory != "" {
		c.IndexPath = filepath.Join(c.CalibreDirectory, "static", "library_index")
		prov.StampField(self, "IndexPath", OriginDerived, "from --calibrepath")
	}
	if c.JsonLPath == "" {
		alias := c.ActionAlias
		if alias == "" {
			alias = "default"
		}
		c.JsonLPath = filepath.Join(accorderCacheDir(), alias+".jsonl")
		prov.StampField(self, "JsonLPath", OriginDerived, "cache dir + alias")
	}
	return nil
}

func indexUpToDate(books []*calibre.Book, indexPath, mergedPath string) (bool, calibre.Manifest) {
	var mf calibre.Manifest
	mergedInfo, err := os.Stat(mergedPath)
	if err != nil {
		return false, mf
	}
	zstInfo, err := os.Stat(indexPath + ".jsonl.zst")
	if err != nil || zstInfo.ModTime().Before(mergedInfo.ModTime()) {
		return false, mf
	}
	mf, err = calibre.ReadExistingManifest(indexPath)
	if err != nil {
		return false, mf
	}
	if len(mf.Tombstones) > 0 || uint64(len(books)) != uint64(mf.NumBooks) {
		return false, mf
	}
	existingDisplay, err := calibre.ReadDisplayJSONL(indexPath)
	if err != nil {
		return false, mf
	}
	existing := make(map[string]uint64, len(books))
	sc := bufio.NewScanner(bytes.NewReader(existingDisplay))
	sc.Buffer(make([]byte, 1<<20), 1<<20)
	lines := 0
	for sc.Scan() {
		line := sc.Bytes()
		if len(line) == 0 {
			continue
		}
		var stub struct {
			Id string `json:"_id"`
		}
		if err := json.Unmarshal(line, &stub); err != nil || stub.Id == "" {
			return false, mf
		}
		existing[stub.Id] = xxhash.Sum64(line)
		lines++
	}
	if sc.Err() != nil || lines != len(books) {
		return false, mf
	}
	for _, b := range books {
		data, err := json.Marshal(b)
		if err != nil {
			return false, mf
		}
		if h, ok := existing[b.Id]; !ok || h != xxhash.Sum64(data) {
			return false, mf
		}
	}
	return true, mf
}

func shouldAutoCompact(mf calibre.Manifest, isAggregate bool) bool {
	if !isAggregate && len(mf.Regions) > 5 {
		return true
	}
	if mf.NumBooks > 0 && uint32(len(mf.Tombstones))*3 > mf.NumBooks {
		return true
	}
	return false
}

func shouldHintCompact(mf calibre.Manifest) bool {
	if len(mf.Regions) > 3 {
		return true
	}
	if mf.NumBooks > 0 && uint32(len(mf.Tombstones))*4 > mf.NumBooks {
		return true
	}
	return false
}

func fetchAndFingerprint(s3Src, coverUrl, tempDir string) [calibre.FingerprintSize]byte {
	var zero [calibre.FingerprintSize]byte

	tmp, err := os.CreateTemp(tempDir, "cover-*.jpg")
	if err != nil {
		return zero
	}
	tmpPath := tmp.Name()
	tmp.Close()
	defer os.Remove(tmpPath)

	if err := rclonexfer.CopyFile(s3Src, coverUrl, tempDir, filepath.Base(tmpPath)); err != nil {
		return zero
	}

	f, err := os.Open(tmpPath)
	if err != nil {
		return zero
	}
	defer f.Close()

	return calibre.CoverFingerprintFromReader(f)
}

func stampMemberGeneration(calibreDir, indexPath string) error {
	if calibreDir == "" || indexPath == "" {
		return fmt.Errorf("stampMemberGeneration: empty calibreDir or indexPath")
	}
	mf, err := calibre.ReadExistingManifest(indexPath)
	if err != nil {
		return fmt.Errorf("read manifest: %w", err)
	}
	return writeGenerationSentinel(calibreDir, mf.BaseGeneration, mf)
}
