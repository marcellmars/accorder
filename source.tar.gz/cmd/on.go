package cmd

import (
	"fmt"
	"os"
	"os/exec"
	"strings"

	"github.com/alecthomas/kong"
)

type onFlagInterceptor string

func stripOnFlag(args []string) []string {
	out := make([]string, 0, len(args))
	skip := false
	for _, arg := range args {
		if skip {
			skip = false
			continue
		}
		if arg == "--on" {
			skip = true
			continue
		}
		if strings.HasPrefix(arg, "--on=") {
			continue
		}
		out = append(out, arg)
	}
	return out
}

func extractOnValue(args []string) string {
	for i, arg := range args {
		if arg == "--on" {
			if i+1 < len(args) {
				return args[i+1]
			}
			return ""
		}
		if strings.HasPrefix(arg, "--on=") {
			return strings.TrimPrefix(arg, "--on=")
		}
	}
	return ""
}

func shellQuote(s string) string {
	return "'" + strings.ReplaceAll(s, "'", `'\''`) + "'"
}

func (o onFlagInterceptor) BeforeApply(app *kong.Kong) error {
	server := extractOnValue(os.Args[1:])
	if server == "" {
		return nil
	}

	remote := "accorder"
	for _, a := range stripOnFlag(os.Args[1:]) {
		remote += " " + shellQuote(a)
	}

	cmd := exec.Command("ssh", server, remote)
	cmd.Stdin = os.Stdin
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	if err := cmd.Run(); err != nil {
		if exitErr, ok := err.(*exec.ExitError); ok {
			app.Exit(exitErr.ExitCode())
		}
		fmt.Fprintf(os.Stderr, "on %s: %v\n", server, err)
		app.Exit(1)
	}
	app.Exit(0)
	return nil
}
