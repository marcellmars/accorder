package cmd

import (
	"fmt"
	"os"
	"path/filepath"

	"github.com/alecthomas/kong"
)

type FedlibShareRevokeClearnetCmd struct {
	CommonCommandFields
	Friend string `name:"friend" help:"Friend name to revoke." validate:"required,personname"`
}

func (c *FedlibShareRevokeClearnetCmd) Run(ctx *kong.Context) error {
	if c.HandleShowConfig(c) {
		return nil
	}

	stateDir := filepath.Join(accorderConfigDir, "clearnet", c.ActionAlias)
	reg, err := newGrantRegistry(stateDir)
	if err != nil {
		return fmt.Errorf("fedlib share revoke-grant: %w", err)
	}
	if err := reg.revoke(c.Friend); err != nil {
		return fmt.Errorf("fedlib share revoke-grant: %w", err)
	}
	fmt.Fprintf(os.Stderr, "fedlib share revoke-grant: revoked grants for %s\n", c.Friend)
	return nil
}
