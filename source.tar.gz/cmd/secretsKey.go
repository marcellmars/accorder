package cmd

import (
	"accorder/pkg/secrets"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"filippo.io/age"
)

func secretsKeyPath() string {
	return filepath.Join(accorderConfigDir, "secrets.key")
}

func secretsStorePath() string {
	return filepath.Join(accorderConfigDir, "secrets.age")
}

func loadOrGenerateSecretsKey(generate bool) (*age.X25519Identity, error) {
	path := secretsKeyPath()
	data, err := os.ReadFile(path)
	if err == nil {
		for _, line := range strings.Split(string(data), "\n") {
			line = strings.TrimSpace(line)
			if line == "" || strings.HasPrefix(line, "#") {
				continue
			}
			id, perr := age.ParseX25519Identity(line)
			if perr != nil {
				return nil, fmt.Errorf("secrets key %s: %w", path, perr)
			}
			return id, nil
		}
		return nil, fmt.Errorf("secrets key %s: no identity line found", path)
	}
	if !os.IsNotExist(err) {
		return nil, fmt.Errorf("secrets key %s: %w", path, err)
	}
	if !generate {
		return nil, err
	}

	id, err := age.GenerateX25519Identity()
	if err != nil {
		return nil, fmt.Errorf("generate secrets key: %w", err)
	}
	content := "# created by accorder — identity for the local secrets store (secrets.age)\n" + id.String() + "\n"
	if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
		return nil, fmt.Errorf("generate secrets key: %w", err)
	}
	if err := os.WriteFile(path, []byte(content), 0o600); err != nil {
		return nil, fmt.Errorf("generate secrets key: %w", err)
	}
	fmt.Fprintf(os.Stderr, "secrets: generated key file %s (0600) — back it up; it decrypts %s\n", path, secretsStorePath())
	return id, nil
}

func resolveJoinSecretsStore(provided string) (*secrets.Store, error) {
	storePath := secretsStorePath()
	if provided == "" {
		provided = os.Getenv("ACCORDER_SECRETS_PASSPHRASE")
	}
	if provided != "" {
		return secrets.NewStore(storePath, provided), nil
	}

	id, err := loadOrGenerateSecretsKey(false)
	if err == nil {
		return secrets.NewStoreWithIdentity(storePath, id), nil
	}
	if !os.IsNotExist(err) {
		return nil, err
	}

	if _, serr := os.Stat(storePath); os.IsNotExist(serr) {
		id, gerr := loadOrGenerateSecretsKey(true)
		if gerr != nil {
			return nil, gerr
		}
		return secrets.NewStoreWithIdentity(storePath, id), nil
	}

	passphrase, perr := promptSecretsPassphrase("")
	if perr != nil {
		return nil, perr
	}
	return secrets.NewStore(storePath, passphrase), nil
}
