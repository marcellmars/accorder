//go:build !tailscale

package cmd

// ca-127 table: every selected command's validator tags run whether or not
// it embeds an action alias; names and invocation hints use the CLI's own
// spelling (flags as --name, positionals as <name>); values recalled by
// fedlib members invite validate again before the descriptor is saved.
// (BeforeApply --on forwarding order is pinned by the operator-seat spike.)

import (
	"os"
	"strings"
	"testing"
)

func TestSelectedValidation_AliasFreeRequiredValues(t *testing.T) {
	testSetup(t)
	_, _, err := parseCLIErr(t, []string{"fedlib", "restore"})
	if err == nil {
		t.Fatal("bare `fedlib restore` reached Run with an empty --input")
	}
	for _, want := range []string{
		"missing required values: --input",
		"tip: accorder fedlib restore --input=<value>",
	} {
		if !strings.Contains(err.Error(), want) {
			t.Errorf("error lacks %q:\n%v", want, err)
		}
	}
	// Alias-free tip must not smuggle in a nonexistent alias positional.
	if strings.Contains(err.Error(), "save them") {
		t.Errorf("alias-free error carries the alias-bearing tip: %v", err)
	}
}

func TestSelectedValidation_ExplicitInvalidURLFailsAtParse(t *testing.T) {
	testSetup(t)
	_, _, err := parseCLIErr(t, []string{"fedlib", "members", "invite", "fed", "Alice",
		"--prefix", "alice", "--endpoint", "notaurl"})
	if err == nil || !strings.Contains(err.Error(), "--endpoint (url)") {
		t.Fatalf("want `--endpoint (url)` validation error, got %v", err)
	}
}

// The positional renders as <name> in positional spelling, never --Name.
// Uses config delete, whose positional keeps the alias format check (its
// Run-level cache reclaim has always required a conforming name); config
// show deliberately dropped the check so legacy '.'/'_' aliases stay
// inspectable.
func TestSelectedValidation_InvalidAliasPositional(t *testing.T) {
	testSetup(t)
	_, _, err := parseCLIErr(t, []string{"config", "delete", "bad name"})
	if err == nil || !strings.Contains(err.Error(), "validation errors: <name> (alias)") {
		t.Fatalf("want `validation errors: <name> (alias)`, got %v", err)
	}
	if strings.Contains(err.Error(), "--Name") || strings.Contains(err.Error(), "--name") {
		t.Errorf("positional rendered as a flag: %v", err)
	}
}

// The existing alias-bearing contract stays recognizable.
func TestSelectedValidation_AliasedUploadContractPreserved(t *testing.T) {
	testSetup(t)
	_, _, err := parseCLIErr(t, []string{"lib", "upload", "partial"})
	if err == nil {
		t.Fatal("credential-less `lib upload` parsed without validation error")
	}
	for _, want := range []string{"missing required flags", "--bucket", "accorder lib upload partial"} {
		if !strings.Contains(err.Error(), want) {
			t.Errorf("alias-bearing contract lost %q:\n%v", want, err)
		}
	}
}

// -s keeps its validation skip: a fresh or partial alias still renders.
func TestSelectedValidation_ShowConfigSkipRetained(t *testing.T) {
	testSetup(t)
	out := captureShowConfig(t, []string{"lib", "upload", "partial", "-s"})
	if !strings.Contains(out, "--bucket") {
		t.Errorf("-s render missing --bucket row:\n%s", out)
	}
}

// An invalid endpoint recalled from the descriptor fails after recall and
// before saveFedlibDescriptor: fedlibs.json stays byte-identical.
func TestSelectedValidation_RecalledInviteEndpointFailsBeforeSave(t *testing.T) {
	testSetup(t)
	seedDescriptor(t, "fed", fedlibDescriptor{
		Bucket: "b", S3Provider: "Wasabi", S3Endpoint: "https://s3.example.com",
		Endpoint: "notaurl",
	})
	before, err := os.ReadFile(fedlibDescriptorPath())
	if err != nil {
		t.Fatal(err)
	}

	// Production dispatch: the hook's pre-recall validation passes
	// (endpoint is omitempty and empty), the post-recall check fails.
	_, ctx := parseCLI(t, []string{"fedlib", "members", "invite", "fed", "Alice", "--prefix", "alice"})
	runErr := ctx.Run()
	if runErr == nil || !strings.Contains(runErr.Error(), "--endpoint (url)") {
		t.Fatalf("want post-recall `--endpoint (url)` error, got %v", runErr)
	}

	after, err := os.ReadFile(fedlibDescriptorPath())
	if err != nil {
		t.Fatal(err)
	}
	if string(before) != string(after) {
		t.Errorf("fedlibs.json changed although the recalled endpoint was invalid:\nbefore: %s\nafter: %s", before, after)
	}
}

// Direct unit callers pass nil and get struct-tag spelling.
func TestSelectedValidation_NilContextFallbackSpelling(t *testing.T) {
	testSetup(t)
	seedDescriptor(t, "fed", fedlibDescriptor{
		Bucket: "b", S3Provider: "Wasabi", S3Endpoint: "https://s3.example.com",
		Endpoint: "notaurl",
	})
	c := &FedlibMembersInviteCmd{FedlibID: "fed", Label: "Alice", Prefix: "alice"}
	_, _, err := captureInviteOutput(t, runNilCtx(c.Run))
	if err == nil || !strings.Contains(err.Error(), "--endpoint (url)") {
		t.Fatalf("nil-context fallback spelling wrong: %v", err)
	}
}

// Invalid validator configuration surfaces as an error, never a logged
// success that silently disables the contract.
func TestSelectedValidation_InvalidSetupIsError(t *testing.T) {
	testSetup(t)
	err := validateSelectedTarget(nil, 42, "bogus cmd", "")
	if err == nil || !strings.Contains(err.Error(), "validation setup error") {
		t.Fatalf("want validation setup error, got %v", err)
	}
}
