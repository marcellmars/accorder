//go:build !tailscale

package cmd

import (
	"os"
	"testing"
)

func TestRegistrySetGet_RoundTrip(t *testing.T) {
	testSetup(t)

	entry := SourceEntry{
		UUID:     "uuid-1111",
		Endpoint: "https://alice.example.com/",
	}
	if err := registrySet("alice", entry); err != nil {
		t.Fatal(err)
	}

	got, ok := registryGet("alice")
	if !ok {
		t.Fatal("registryGet returned false for existing entry")
	}
	if got.UUID != entry.UUID {
		t.Errorf("UUID = %q, want %q", got.UUID, entry.UUID)
	}
	if got.Endpoint != entry.Endpoint {
		t.Errorf("Endpoint = %q, want %q", got.Endpoint, entry.Endpoint)
	}
}

func TestRegistrySet_DifferentUUID_Error(t *testing.T) {
	testSetup(t)

	if err := registrySet("alice", SourceEntry{UUID: "uuid-1111"}); err != nil {
		t.Fatal(err)
	}
	err := registrySet("alice", SourceEntry{UUID: "uuid-2222"})
	if err == nil {
		t.Fatal("expected error for different-UUID collision, got nil")
	}
}

func TestRegistrySet_SameUUID_Update(t *testing.T) {
	testSetup(t)

	if err := registrySet("alice", SourceEntry{
		UUID:     "uuid-1111",
		Endpoint: "https://old.example.com/",
		Invite:   "old-invite",
	}); err != nil {
		t.Fatal(err)
	}

	// Update with same UUID but different fields — should replace.
	if err := registrySet("alice", SourceEntry{
		UUID:     "uuid-1111",
		Endpoint: "https://new.example.com/",
	}); err != nil {
		t.Fatal(err)
	}
	got, _ := registryGet("alice")
	if got.Endpoint != "https://new.example.com/" {
		t.Errorf("Endpoint = %q, want updated value", got.Endpoint)
	}

	// Stale invite should be cleared (delete-then-replace).
	if got.Invite != "" {
		t.Errorf("Invite = %q, want empty (stale field should be cleared)", got.Invite)
	}
}

func TestRegistrySet_BothUUIDsEmpty_Error(t *testing.T) {
	testSetup(t)

	if err := registrySet("alice", SourceEntry{Endpoint: "https://a.com/"}); err != nil {
		t.Fatal(err)
	}
	err := registrySet("alice", SourceEntry{Endpoint: "https://b.com/"})
	if err == nil {
		t.Fatal("expected error for both-UUIDs-empty collision, got nil")
	}
}

func TestRegistrySet_OneUUIDEmpty_Update(t *testing.T) {
	testSetup(t)

	// Create an entry with no UUID (e.g., from lib index add).
	if err := registrySet("alice", SourceEntry{Endpoint: "https://a.com/"}); err != nil {
		t.Fatal(err)
	}

	// First sync populates UUID — should succeed.
	if err := registrySet("alice", SourceEntry{UUID: "uuid-1111", Endpoint: "https://a.com/"}); err != nil {
		t.Fatalf("expected success for one-UUID-empty update, got: %v", err)
	}
	got, _ := registryGet("alice")
	if got.UUID != "uuid-1111" {
		t.Errorf("UUID = %q, want %q", got.UUID, "uuid-1111")
	}
}

func TestRegistryDelete_Existing(t *testing.T) {
	testSetup(t)

	registrySet("alice", SourceEntry{UUID: "uuid-1111"})
	if err := registryDelete("alice"); err != nil {
		t.Fatal(err)
	}
	if _, ok := registryGet("alice"); ok {
		t.Fatal("entry still exists after delete")
	}
}

func TestRegistryDelete_Missing_Error(t *testing.T) {
	testSetup(t)

	err := registryDelete("nonexistent")
	if err == nil {
		t.Fatal("expected error for deleting missing entry, got nil")
	}
}

func TestRegistryRename_Existing(t *testing.T) {
	testSetup(t)

	registrySet("alice", SourceEntry{UUID: "uuid-1111"})
	if err := registryRename("alice", "bob"); err != nil {
		t.Fatal(err)
	}
	if _, ok := registryGet("alice"); ok {
		t.Fatal("old name still exists after rename")
	}
	got, ok := registryGet("bob")
	if !ok {
		t.Fatal("new name not found after rename")
	}
	if got.UUID != "uuid-1111" {
		t.Errorf("UUID = %q, want %q", got.UUID, "uuid-1111")
	}
}

func TestRegistryRename_ToExisting_Error(t *testing.T) {
	testSetup(t)

	registrySet("alice", SourceEntry{UUID: "uuid-1111"})
	registrySet("bob", SourceEntry{UUID: "uuid-2222"})
	err := registryRename("alice", "bob")
	if err == nil {
		t.Fatal("expected error for rename to existing name, got nil")
	}
}

func TestRegistryFindByEndpoint_Hit(t *testing.T) {
	testSetup(t)

	registrySet("alice", SourceEntry{UUID: "uuid-1111", Endpoint: "https://alice.example.com/"})

	// Query without trailing slash — should still match.
	name, entry, ok := registryFindByEndpoint("https://alice.example.com")
	if !ok {
		t.Fatal("registryFindByEndpoint returned false for existing entry")
	}
	if name != "alice" {
		t.Errorf("name = %q, want %q", name, "alice")
	}
	if entry.UUID != "uuid-1111" {
		t.Errorf("UUID = %q, want %q", entry.UUID, "uuid-1111")
	}
}

func TestRegistryFindByEndpoint_Miss(t *testing.T) {
	testSetup(t)

	registrySet("alice", SourceEntry{UUID: "uuid-1111", Endpoint: "https://alice.example.com/"})
	_, _, ok := registryFindByEndpoint("https://bob.example.com/")
	if ok {
		t.Fatal("registryFindByEndpoint returned true for non-matching endpoint")
	}
}

func TestRegistryList_Empty(t *testing.T) {
	testSetup(t)

	entries := registryList()
	if len(entries) != 0 {
		t.Errorf("registryList() returned %d entries, want 0", len(entries))
	}
}

func TestRegistryList_Populated(t *testing.T) {
	testSetup(t)

	registrySet("alice", SourceEntry{UUID: "uuid-1111"})
	registrySet("bob", SourceEntry{UUID: "uuid-2222"})
	entries := registryList()
	if len(entries) != 2 {
		t.Errorf("registryList() returned %d entries, want 2", len(entries))
	}
}

func TestRegisterOrUpdate_SameUUID_UpdateInPlace(t *testing.T) {
	testSetup(t)

	registrySet("alice", SourceEntry{UUID: "uuid-1111", Endpoint: "https://old.com/"})
	saved := registerOrUpdate("alice", SourceEntry{UUID: "uuid-1111", Endpoint: "https://new.com/"})
	if saved != "alice" {
		t.Errorf("registerOrUpdate returned %q, want %q", saved, "alice")
	}
	got, _ := registryGet("alice")
	if got.Endpoint != "https://new.com/" {
		t.Errorf("Endpoint = %q, want updated value", got.Endpoint)
	}
}

func TestRegisterOrUpdate_DifferentUUID_Suffix(t *testing.T) {
	testSetup(t)

	registrySet("alice", SourceEntry{UUID: "uuid-1111"})
	saved := registerOrUpdate("alice", SourceEntry{UUID: "uuid-2222"})
	if saved != "alice-2" {
		t.Errorf("registerOrUpdate returned %q, want %q", saved, "alice-2")
	}

	// Original entry preserved.
	orig, _ := registryGet("alice")
	if orig.UUID != "uuid-1111" {
		t.Error("original entry was clobbered")
	}

	// Suffixed entry exists.
	suffixed, ok := registryGet("alice-2")
	if !ok {
		t.Fatal("suffixed entry not found")
	}
	if suffixed.UUID != "uuid-2222" {
		t.Errorf("suffixed UUID = %q, want %q", suffixed.UUID, "uuid-2222")
	}
}

func TestRegisterOrUpdate_EmptyUUID_UpdateInPlace(t *testing.T) {
	testSetup(t)

	// Create entry with no UUID.
	registrySet("alice", SourceEntry{Endpoint: "https://a.com/"})
	saved := registerOrUpdate("alice", SourceEntry{UUID: "uuid-1111", Endpoint: "https://a.com/"})
	if saved != "alice" {
		t.Errorf("registerOrUpdate returned %q, want %q", saved, "alice")
	}
	got, _ := registryGet("alice")
	if got.UUID != "uuid-1111" {
		t.Errorf("UUID = %q, want %q", got.UUID, "uuid-1111")
	}
}

func TestRegisterOrUpdate_StaleFieldReplacement(t *testing.T) {
	testSetup(t)

	// Onion source with invite.
	registrySet("alice", SourceEntry{UUID: "uuid-1111", Invite: "accorder-invite:xxx"})

	// Update as clearnet — invite should be cleared.
	saved := registerOrUpdate("alice", SourceEntry{UUID: "uuid-1111", Endpoint: "https://alice.example.com/"})
	if saved != "alice" {
		t.Errorf("registerOrUpdate returned %q, want %q", saved, "alice")
	}
	got, _ := registryGet("alice")
	if got.Invite != "" {
		t.Errorf("Invite = %q, want empty (stale field should be cleared)", got.Invite)
	}
	if got.Endpoint != "https://alice.example.com/" {
		t.Errorf("Endpoint = %q, want updated value", got.Endpoint)
	}
}

func TestRegistryGet_Missing(t *testing.T) {
	testSetup(t)

	_, ok := registryGet("nonexistent")
	if ok {
		t.Fatal("registryGet returned true for missing entry")
	}
}

func TestOfflineCacheDir_RegistryFallback(t *testing.T) {
	tmpDir := testSetup(t)

	alias := "testbrowse"
	cacheBase := tmpDir

	// Set up browse source with an endpoint but no source-uuid.
	persistBrowseSource(alias, "", "https://alice.example.com/", "aggregator", "")

	// Register the source in the registry with a UUID.
	registrySet("alice", SourceEntry{UUID: "uuid-1111", Endpoint: "https://alice.example.com/"})

	// Create the cache dir so the function finds it.
	_ = os.MkdirAll(cacheBase+"/uuid-1111/static", 0755)

	dir, err := offlineCacheDir(alias, cacheBase)
	if err != nil {
		t.Fatalf("offlineCacheDir: %v", err)
	}
	want := cacheBase + "/uuid-1111"
	if dir != want {
		t.Errorf("offlineCacheDir = %q, want %q", dir, want)
	}
}

func TestRegistryUpdateFrom_UUIDMismatch_Error(t *testing.T) {
	testSetup(t)

	// Create entry with UUID A.
	if err := registrySet("alice", SourceEntry{UUID: "uuid-aaaa"}); err != nil {
		t.Fatal(err)
	}

	// Attempt to update via --from with UUID B — should error.
	err := registrySet("alice", SourceEntry{UUID: "uuid-bbbb"})
	if err == nil {
		t.Fatal("expected error for --from UUID mismatch, got nil")
	}
}

func TestRegisterOrUpdate_MultipleSuffixes(t *testing.T) {
	testSetup(t)

	registrySet("alice", SourceEntry{UUID: "uuid-1111"})
	registerOrUpdate("alice", SourceEntry{UUID: "uuid-2222"})
	saved := registerOrUpdate("alice", SourceEntry{UUID: "uuid-3333"})
	if saved != "alice-3" {
		t.Errorf("registerOrUpdate returned %q, want %q", saved, "alice-3")
	}
}
