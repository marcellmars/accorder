package cmd

import (
	"accorder/pkg/calibre"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"strings"
)

type LibSearchCmd struct {
	CommonCommandFields
	IndexPath string `name:"index-path" json:"index-path" help:"Path to the search index file (without .zst extension)." validate:"required,filepath" sharedgroup:"lib"`
	Query     string `name:"query" short:"q" json:"-" help:"Search query in field:value format (fields: title, author, tag)." validate:"required"`
	Limit     int    `name:"limit" json:"-" help:"Maximum number of results to return." default:"0"`
	Offset    int    `name:"offset" json:"-" help:"Number of results to skip." default:"0"`
	Sort      string `name:"sort" json:"-" help:"Sort order: relevance (BM25), newest, oldest, none."`
	Json      *bool  `name:"json" json:"-" help:"Output results as JSON array."`
	Verbose   *bool  `name:"verbose" json:"-" help:"Print index summary and detailed search stats to stderr."`
	TeaOutputs
}

func parseSearchQuery(s string) (calibre.SearchQuery, error) {
	return calibre.ParseSearchQuery(s)
}

func (c *LibSearchCmd) Run() error {
	c.Header = ".◟◜calibre search◝◞."
	if c.HandleShowConfig(c) {
		return nil
	}

	query, err := parseSearchQuery(c.Query)
	if err != nil {
		return err
	}

	indexPath := strings.TrimSuffix(c.IndexPath, ".zst")

	if c.Verbose != nil {
		if mf, mErr := calibre.ReadExistingManifest(indexPath); mErr == nil {
			fmt.Fprintf(os.Stderr, "Index: %d regions, %d books (%d live after %d tombstones), generation %d\n",
				len(mf.Regions), mf.NumBooks, int64(mf.NumBooks)-int64(len(mf.Tombstones)), len(mf.Tombstones), mf.Generation)
		} else {
			fmt.Fprintf(os.Stderr, "Index: (manifest read failed: %v)\n", mErr)
		}
	}

	var sortMode calibre.SortMode
	if c.Sort != "" {
		var sErr error
		sortMode, sErr = calibre.ParseSortMode(c.Sort)
		if sErr != nil {
			return sErr
		}
	} else {
		sortMode = calibre.SortNewest // CLI default: newest first
	}

	motwSearch := &calibre.MotwSearch{IndexPath: indexPath}
	opts := calibre.SearchOptions{Limit: c.Limit, Offset: c.Offset, SortMode: sortMode}
	books, stats, err := motwSearch.Search(context.Background(), query, opts)
	if err != nil {
		return fmt.Errorf("search: %w", err)
	}

	if c.Offset > 0 && c.Offset < len(books) {
		books = books[c.Offset:]
	} else if c.Offset >= len(books) && c.Offset > 0 {
		books = nil
	}
	if c.Limit > 0 && c.Limit < len(books) {
		books = books[:c.Limit]
	}

	if c.Json != nil {
		enc := json.NewEncoder(os.Stdout)
		enc.SetIndent("", "  ")
		if err := enc.Encode(books); err != nil {
			return fmt.Errorf("encode JSON: %w", err)
		}
	} else {
		for _, b := range books {
			fmt.Printf("%s — %s — %s\n", b.Title, strings.Join(b.Authors, ", "), b.LastModified)
		}
	}

	if c.Verbose != nil {
		fmt.Fprintf(os.Stderr, "Stats: %d matched, %d scanned, %d candidate / %d total segments, %d postings narrowed, %d clusters read, %d bytes decompressed\n",
			stats.BooksMatched, stats.BooksScanned, stats.SegmentsCandidate, stats.SegmentsTotal, stats.PostingsNarrowed, stats.ClustersRead, stats.BytesDecompressed)
	} else if stats.PostingsNarrowed > 0 {
		fmt.Fprintf(os.Stderr, "%d matched, %d scanned, %d postings-narrowed, %d clusters\n",
			stats.BooksMatched, stats.BooksScanned, stats.PostingsNarrowed, stats.ClustersRead)
	} else {
		fmt.Fprintf(os.Stderr, "%d matched, %d scanned, %d segments, %d clusters\n",
			stats.BooksMatched, stats.BooksScanned, stats.SegmentsCandidate, stats.ClustersRead)
	}
	return nil
}
