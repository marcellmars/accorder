//go:build !tailscale && !tor

package cmd

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// The alias store stopped being created eagerly at init() when --show-config
// was made read-only (ca-120). That made "file absent" reachable on paths
// which previously could only ever see "file present", and the cache-reclaim
// gate reported the absence as "unreadable" — alarming, and untrue.
//
// Both states must still FAIL CLOSED: an absent alias store makes every cache
// tree look unowned, which is precisely when deleting them would be most
// destructive. Only the wording differs.
func TestAliasLoadFailureReason_DistinguishesAbsentFromUnreadable(t *testing.T) {
	testSetup(t)

	if err := os.Remove(savedActionAliases); err != nil && !os.IsNotExist(err) {
		t.Fatal(err)
	}
	absent := aliasLoadFailureReason()
	if strings.Contains(absent, "unreadable") {
		t.Errorf("absent store reported as unreadable: %q", absent)
	}
	if !strings.Contains(absent, "no alias store") {
		t.Errorf("absent store reason does not say the store is missing: %q", absent)
	}

	if err := os.WriteFile(savedActionAliases, []byte("NOT JSON{{{"), 0o644); err != nil {
		t.Fatal(err)
	}
	unreadable := aliasLoadFailureReason()
	if !strings.Contains(unreadable, "unreadable") {
		t.Errorf("corrupt store not reported as unreadable: %q", unreadable)
	}
	if absent == unreadable {
		t.Error("absent and unreadable produce the same message; the distinction was lost")
	}
}

// The safety property the wording change must not disturb.
func TestStrictLoadAliasSet_StillFailsClosedWhenStoreAbsent(t *testing.T) {
	testSetup(t)
	if err := os.Remove(savedActionAliases); err != nil && !os.IsNotExist(err) {
		t.Fatal(err)
	}

	set, err := strictLoadAliasSet()
	if err == nil {
		t.Fatalf("strictLoadAliasSet returned nil error for an absent store (set=%v); "+
			"an empty alias set makes every cache tree look unowned and eligible for deletion", set)
	}
	if !os.IsNotExist(err) {
		t.Errorf("expected an IsNotExist error, got %v", err)
	}
}

// The accorder config dir holds secrets.age, keys/*.s3.keys and
// motw_libraries.json. Those files are 0600, but a world-readable directory
// still enumerates them — keys/motw.s3.keys names a federation and reveals
// that credentials for it live here. Three MkdirAll sites used to disagree
// (0755 vs writeFileDurable's 0700), so the mode depended on which writer
// created the directory first.
func TestConfigDirIsNotWorldReadable(t *testing.T) {
	if configDirPerm != 0o700 {
		t.Fatalf("configDirPerm = %#o, want 0700", configDirPerm)
	}

	dir := t.TempDir()
	target := filepath.Join(dir, "nested", "action_aliases.json")
	if err := ensureConfigDir(target); err != nil {
		t.Fatal(err)
	}
	info, err := os.Stat(filepath.Dir(target))
	if err != nil {
		t.Fatal(err)
	}
	if perm := info.Mode().Perm(); perm != 0o700 {
		t.Errorf("config dir created with mode %#o, want 0700 (group/other must not enumerate keys/)", perm)
	}
}

// Every writer into the config dir must route through ensureConfigDir, or
// the mode goes back to depending on execution order.
func TestConfigDirCreationIsCentralized(t *testing.T) {
	for _, f := range []string{"configuration.go", "aliasConfigLock.go", "fedlibDescriptor.go"} {
		src, err := os.ReadFile(f)
		if err != nil {
			t.Fatal(err)
		}
		body := string(src)
		if strings.Contains(body, "MkdirAll(filepath.Dir(savedActionAliases)") ||
			strings.Contains(body, "MkdirAll(filepath.Dir(path), 0o755)") ||
			strings.Contains(body, "MkdirAll(filepath.Dir(lockPath)") {
			t.Errorf("%s creates the config dir directly; route it through ensureConfigDir", f)
		}
	}
}
