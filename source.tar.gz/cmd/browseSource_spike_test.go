//go:build !tailscale

package cmd

import (
	"os"
	"path/filepath"
	"testing"

	"github.com/tidwall/gjson"
)

// ═══════════════════════════════════════════════════════════════════
// Spike: named-source-indices — Phase 0 discovery
//

// A1: Validate that the browse-source persistence helpers
//     (persistBrowseSource, persistBrowseSourceUUID, loadBrowseSource,
//     offlineCacheDir) operate on independent JSON key paths, so a
//     new --from registry lookup can coexist with the per-alias
//     source-uuid bookmark that bare --offline relies on.
//

// A2: Validate that the cache dir layout (cacheBase/<uuid>/static/
//     library_index.zst) is derivable — specifically that file size
//     and last-synced (mtime) can be read from the on-disk structure
//     using standard os.Stat / filepath.Walk.
// ═══════════════════════════════════════════════════════════════════

// TestSpike_PersistBrowseSourceClobbersUUID asserts that
// persistBrowseSource DELETES source-uuid because "source-uuid" is
// in the browseSourceKeys delete set. This means the two helpers are
// NOT independent: calling persistBrowseSource wipes any previously
// stored source-uuid. The current code survives because Run() calls
// persistBrowseSource first (line 194), then persistBrowseSourceUUID
// later (line 277) — temporal ordering, not structural independence.
//

// Implication for --from: a registry-based 4th branch must NOT call
// persistBrowseSource (which would clobber the UUID). It should
// either call persistBrowseSourceUUID directly, or the proposal
// should refactor browseSourceKeys to exclude "source-uuid" from
// the delete set.
func TestSpike_PersistBrowseSourceClobbersUUID(t *testing.T) {
	testSetup(t)

	alias := "spike-a1"

	// Step 1: Persist source-uuid first.
	persistBrowseSourceUUID(alias, "uuid-1111")

	// Verify it's stored.
	data, _ := os.ReadFile(savedActionAliases)
	base := alias + ".lib.browse."
	if got := gjson.GetBytes(data, base+"source-uuid").String(); got != "uuid-1111" {
		t.Fatalf("source-uuid not stored: %q", got)
	}

	// Step 2: Call persistBrowseSource (simulates re-browse with new invite).
	persistBrowseSource(alias, "abc.onion", "", "per_library", "Alice")

	// Assert: source-uuid is GONE because browseSourceKeys includes
	// "source-uuid" and persistBrowseSource deletes all of them.
	data, _ = os.ReadFile(savedActionAliases)
	gotUUID := gjson.GetBytes(data, base+"source-uuid").String()
	if gotUUID != "" {
		t.Errorf("source-uuid after persistBrowseSource = %q, want empty (should be clobbered)", gotUUID)
	}

	// Source fields ARE set.
	if got := gjson.GetBytes(data, base+"onion").String(); got != "abc.onion" {
		t.Errorf("onion = %q, want abc.onion", got)
	}
}

// TestSpike_RunTemporalOrder validates the production temporal ordering:
// persistBrowseSource runs first, then persistBrowseSourceUUID later.
// The UUID survives because it's written AFTER the clobber.
func TestSpike_RunTemporalOrder(t *testing.T) {
	testSetup(t)

	alias := "spike-temporal"
	base := alias + ".lib.browse."

	// Simulate Run()'s order: persist source first, UUID second.
	persistBrowseSource(alias, "x.onion", "https://lib.example.com/", "per_library", "Test")
	persistBrowseSourceUUID(alias, "uuid-after")

	// UUID survives because it was written after the clobber.
	data, _ := os.ReadFile(savedActionAliases)
	if got := gjson.GetBytes(data, base+"source-uuid").String(); got != "uuid-after" {
		t.Errorf("source-uuid = %q, want uuid-after", got)
	}

	// Source fields also present.
	if got := gjson.GetBytes(data, base+"onion").String(); got != "x.onion" {
		t.Errorf("onion = %q, want x.onion", got)
	}
}

// TestSpike_PersistBrowseSourceUUIDDoesNotClobberSourceFields asserts
// that persistBrowseSourceUUID only writes source-uuid and does NOT
// touch the other source fields (onion, endpoint, etc.).
func TestSpike_PersistBrowseSourceUUIDDoesNotClobberSourceFields(t *testing.T) {
	testSetup(t)

	alias := "spike-uuid-only"
	base := alias + ".lib.browse."

	// Set source fields first.
	persistBrowseSource(alias, "z.onion", "https://z.example.com/", "aggregator", "Zoe")

	// Then set UUID.
	persistBrowseSourceUUID(alias, "uuid-safe")

	// Assert: source fields are untouched.
	data, _ := os.ReadFile(savedActionAliases)
	checks := map[string]string{
		"onion":          "z.onion",
		"endpoint":       "https://z.example.com/",
		"publisher-type": "aggregator",
		"source-label":   "Zoe",
		"source-uuid":    "uuid-safe",
	}
	for key, want := range checks {
		got := gjson.GetBytes(data, base+key).String()
		if got != want {
			t.Errorf("%s = %q, want %q", key, got, want)
		}
	}
}

// TestSpike_OfflineCacheDirUsesUUIDNotSourceFields asserts that
// offlineCacheDir resolves via source-uuid (the bookmark), completely
// independently of the source fields (onion, endpoint, etc.).
//

// CRITICAL FINDING: persistBrowseSource CLOBBERS source-uuid (it's in
// browseSourceKeys). So after a source re-persist, the UUID is gone and
// offlineCacheDir falls through to the alias-based fallback (which also
// fails if no <alias>/static/ dir exists). This proves the two helpers
// are NOT independent — the --from branch must avoid calling
// persistBrowseSource, or the proposal must refactor browseSourceKeys.
func TestSpike_OfflineCacheDirUsesUUIDNotSourceFields(t *testing.T) {
	testSetup(t)

	alias := "spike-offline"
	cacheBase := t.TempDir()

	// Persist ONLY source-uuid, no source fields.
	persistBrowseSourceUUID(alias, "cache-uuid-42")

	dir, err := offlineCacheDir(alias, cacheBase)
	if err != nil {
		t.Fatalf("offlineCacheDir with UUID-only: %v", err)
	}
	want := filepath.Join(cacheBase, "cache-uuid-42")
	if dir != want {
		t.Errorf("offlineCacheDir = %q, want %q", dir, want)
	}

	// Now call persistBrowseSource — this CLOBBERS source-uuid.
	persistBrowseSource(alias, "some.onion", "", "per_library", "Test")

	// offlineCacheDir should FAIL because source-uuid was deleted.
	_, err = offlineCacheDir(alias, cacheBase)
	if err == nil {
		t.Fatal("expected error after persistBrowseSource clobbered source-uuid, got nil")
	}
	t.Logf("CONFIRMED: offlineCacheDir fails after source clobber: %v", err)

	// Re-persist UUID to restore — simulating Run()'s temporal ordering.
	persistBrowseSourceUUID(alias, "cache-uuid-42")
	dir, err = offlineCacheDir(alias, cacheBase)
	if err != nil {
		t.Fatalf("offlineCacheDir after UUID re-persist: %v", err)
	}
	if dir != want {
		t.Errorf("offlineCacheDir after UUID re-persist = %q, want %q", dir, want)
	}
}

// TestSpike_BrowseSourceKeysIncludesUUID asserts the exact set of keys
// that persistBrowseSource deletes+rewrites. Critically, "source-uuid"
// IS in this set — which means persistBrowseSource deletes the UUID
// bookmark as a side effect. The proposal must account for this.
func TestSpike_BrowseSourceKeysIncludesUUID(t *testing.T) {
	want := []string{"onion", "endpoint", "publisher-type", "source-label", "source-uuid"}
	if len(browseSourceKeys) != len(want) {
		t.Fatalf("browseSourceKeys has %d entries, want %d: %v",
			len(browseSourceKeys), len(want), browseSourceKeys)
	}
	for i, k := range want {
		if browseSourceKeys[i] != k {
			t.Errorf("browseSourceKeys[%d] = %q, want %q", i, browseSourceKeys[i], k)
		}
	}

	// Confirm source-uuid is present (the critical finding).
	found := false
	for _, k := range browseSourceKeys {
		if k == "source-uuid" {
			found = true
			break
		}
	}
	if !found {
		t.Fatal("source-uuid NOT in browseSourceKeys — assumption changed")
	}
}

// TestSpike_CacheDirLayoutAndDerivableMetadata creates a fake cache
// directory matching the expected layout (cacheBase/<uuid>/static/
// library_index.zst) and verifies that:
// 1. The path construction matches what offlineCacheDir returns.
// 2. File size is derivable via os.Stat.
// 3. Last-synced is derivable via mtime of the index file.
// 4. Total cache dir size is derivable via filepath.Walk.
func TestSpike_CacheDirLayoutAndDerivableMetadata(t *testing.T) {
	testSetup(t)

	cacheBase := t.TempDir()
	uuid := "550e8400-e29b-41d4-a716-446655440000"

	// Persist the UUID so offlineCacheDir can resolve.
	persistBrowseSourceUUID("spike-cache", uuid)

	// Create the expected directory structure.
	staticDir := filepath.Join(cacheBase, uuid, "static")
	if err := os.MkdirAll(staticDir, 0755); err != nil {
		t.Fatal(err)
	}

	// Write a fake index file.
	indexPath := filepath.Join(staticDir, "library_index.zst")
	fakeData := make([]byte, 12345)
	if err := os.WriteFile(indexPath, fakeData, 0644); err != nil {
		t.Fatal(err)
	}

	// Also write a fake JSONL display file to simulate a populated cache.
	displayPath := filepath.Join(staticDir, "library_display.jsonl.zst")
	displayData := make([]byte, 5678)
	if err := os.WriteFile(displayPath, displayData, 0644); err != nil {
		t.Fatal(err)
	}

	// 1. Path construction: offlineCacheDir returns cacheBase/<uuid>.
	dir, err := offlineCacheDir("spike-cache", cacheBase)
	if err != nil {
		t.Fatalf("offlineCacheDir: %v", err)
	}
	wantDir := filepath.Join(cacheBase, uuid)
	if dir != wantDir {
		t.Errorf("offlineCacheDir = %q, want %q", dir, wantDir)
	}

	// 2. Index file size via os.Stat.
	fi, err := os.Stat(indexPath)
	if err != nil {
		t.Fatalf("stat index: %v", err)
	}
	if fi.Size() != 12345 {
		t.Errorf("index size = %d, want 12345", fi.Size())
	}

	// 3. Last-synced signal: mtime of the index file.
	mtime := fi.ModTime()
	if mtime.IsZero() {
		t.Error("index mtime is zero")
	}

	// 4. Total cache dir size via filepath.Walk.
	var totalSize int64
	err = filepath.Walk(dir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if !info.IsDir() {
			totalSize += info.Size()
		}
		return nil
	})
	if err != nil {
		t.Fatalf("walk: %v", err)
	}
	wantTotal := int64(12345 + 5678)
	if totalSize != wantTotal {
		t.Errorf("total cache size = %d, want %d", totalSize, wantTotal)
	}
}
