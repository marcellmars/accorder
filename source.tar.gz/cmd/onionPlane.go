package cmd

import (
	"bufio"
	"fmt"
	"net"
	"net/http"
	"strconv"
	"strings"
	"time"
)

type proxyProtoConn struct {
	net.Conn
	r    *bufio.Reader
	addr net.Addr
}

func (c *proxyProtoConn) Read(b []byte) (int, error) { return c.r.Read(b) }
func (c *proxyProtoConn) RemoteAddr() net.Addr       { return c.addr }

type proxyProtoListener struct{ net.Listener }

func (l *proxyProtoListener) Accept() (net.Conn, error) {
	for {
		c, err := l.Listener.Accept()
		if err != nil {
			return nil, err
		}
		pc, perr := readProxyHeader(c)
		if perr != nil {
			_ = c.Close()
			continue
		}
		return pc, nil
	}
}

func readProxyHeader(c net.Conn) (net.Conn, error) {
	_ = c.SetReadDeadline(time.Now().Add(10 * time.Second))
	br := bufio.NewReader(c)
	line, err := br.ReadString('\n')
	if err != nil || !strings.HasPrefix(line, "PROXY ") {
		return nil, fmt.Errorf("onion plane: missing PROXY header")
	}
	_ = c.SetReadDeadline(time.Time{})
	f := strings.Fields(strings.TrimSpace(line))
	addr := c.RemoteAddr()
	if len(f) >= 6 {
		if ip := net.ParseIP(f[2]); ip != nil {
			port, _ := strconv.Atoi(f[4])
			addr = &net.TCPAddr{IP: ip, Port: port}
		}
	}
	return &proxyProtoConn{Conn: c, r: br, addr: addr}, nil
}

func stripForwardedHeaders(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		r.Header.Del("X-Forwarded-For")
		r.Header.Del("X-Real-IP")
		next.ServeHTTP(w, r)
	})
}

func startOnionPlane(h http.Handler) (target string, srv *http.Server, err error) {
	oln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return "", nil, err
	}
	srv = &http.Server{Handler: stripForwardedHeaders(h)}
	go func() { _ = srv.Serve(&proxyProtoListener{Listener: oln}) }()
	return torLoopbackTarget(oln.Addr().String()), srv, nil
}
