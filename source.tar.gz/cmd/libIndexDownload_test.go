package cmd

import (
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"
)

// TestDownloadFullAtomicOnError guards review finding #2: a failed download
// (non-200) must NOT clobber the previously-good cached file, and must leave no
// stray temp file.
func TestDownloadFullAtomicOnError(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusNotFound)
	}))
	defer srv.Close()

	dir := t.TempDir()
	local := filepath.Join(dir, "lib.zst")
	if err := os.WriteFile(local, []byte("OLD-GOOD"), 0o644); err != nil {
		t.Fatal(err)
	}

	if err := downloadFull(srv.URL, local, srv.Client()); err == nil {
		t.Fatal("expected error on 404 download")
	}
	got, err := os.ReadFile(local)
	if err != nil || string(got) != "OLD-GOOD" {
		t.Fatalf("prior good copy clobbered: %q (err=%v)", got, err)
	}
	if _, err := os.Stat(local + ".tmp"); !os.IsNotExist(err) {
		t.Fatalf("temp file left behind: %v", err)
	}
}

// TestDownloadFullSuccess verifies the happy path replaces the file atomically
// (no stray temp).
func TestDownloadFullSuccess(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte("NEW-DATA"))
	}))
	defer srv.Close()

	dir := t.TempDir()
	local := filepath.Join(dir, "lib.zst")
	if err := os.WriteFile(local, []byte("OLD"), 0o644); err != nil {
		t.Fatal(err)
	}
	if err := downloadFull(srv.URL, local, srv.Client()); err != nil {
		t.Fatal(err)
	}
	got, _ := os.ReadFile(local)
	if string(got) != "NEW-DATA" {
		t.Fatalf("got %q want NEW-DATA", got)
	}
	if _, err := os.Stat(local + ".tmp"); !os.IsNotExist(err) {
		t.Fatalf("temp file left behind: %v", err)
	}
}
