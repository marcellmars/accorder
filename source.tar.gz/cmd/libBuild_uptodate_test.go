//go:build !tailscale

package cmd

// Tests for the default-build no-change skip (indexUpToDate). The skip must
// be content-aware: an unchanged book set skips, but metadata edits to
// existing books (same ID set), added/removed books, and stale sibling
// artifacts must all force the normal rebuild.

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"

	"accorder/pkg/calibre"
)

func seedBuiltIndex(t *testing.T, n int) (books []*calibre.Book, indexPath, mergedPath string) {
	t.Helper()
	dir := t.TempDir()
	indexPath = filepath.Join(dir, "library_index")
	mergedPath = indexPath + ".jsonl"

	for i := 0; i < n; i++ {
		books = append(books, &calibre.Book{
			Id:           fmt.Sprintf("00000000-0000-4000-8000-%012d", i),
			UUID:         fmt.Sprintf("book-uuid-%d", i),
			Title:        fmt.Sprintf("Book %d", i),
			Authors:      []string{fmt.Sprintf("Author %d", i)},
			Tags:         []string{"test"},
			LastModified: fmt.Sprintf("2024-01-%02dT00:00:00+00:00", (i%28)+1),
			LibraryUUID:  "lib-test",
			Librarian:    "testlib",
		})
	}

	f, err := os.Create(mergedPath)
	if err != nil {
		t.Fatal(err)
	}
	w := bufio.NewWriter(f)
	for _, b := range books {
		data, err := json.Marshal(b)
		if err != nil {
			t.Fatal(err)
		}
		_, _ = w.Write(data)
		_ = w.WriteByte('\n')
	}
	_ = w.Flush()
	_ = f.Close()

	ms := &calibre.MotwSearch{JsonlPath: mergedPath, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex: %v", err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatalf("CompressToFile: %v", err)
	}
	// sibling the build would have derived from the merged JSONL
	if err := os.WriteFile(indexPath+".jsonl.zst", []byte("zst"), 0o644); err != nil {
		t.Fatal(err)
	}
	return books, indexPath, mergedPath
}

func TestIndexUpToDate(t *testing.T) {
	books, indexPath, mergedPath := seedBuiltIndex(t, 3)

	if ok, mf := indexUpToDate(books, indexPath, mergedPath); !ok {
		t.Fatal("unchanged book set: want up-to-date")
	} else if mf.NumBooks != 3 {
		t.Fatalf("manifest NumBooks = %d; want 3", mf.NumBooks)
	}

	// Metadata edit with an unchanged ID set must defeat the skip.
	origTitle := books[1].Title
	books[1].Title = "Renamed Book"
	if ok, _ := indexUpToDate(books, indexPath, mergedPath); ok {
		t.Fatal("metadata edit must not be reported as up-to-date")
	}
	books[1].Title = origTitle

	// Added book.
	extra := &calibre.Book{Id: "00000000-0000-4000-8000-999999999999", Title: "New", LastModified: "2024-02-01T00:00:00+00:00"}
	if ok, _ := indexUpToDate(append(append([]*calibre.Book{}, books...), extra), indexPath, mergedPath); ok {
		t.Fatal("added book must not be reported as up-to-date")
	}

	// Removed book.
	if ok, _ := indexUpToDate(books[:2], indexPath, mergedPath); ok {
		t.Fatal("removed book must not be reported as up-to-date")
	}

	// Missing sibling .jsonl.zst.
	zst := indexPath + ".jsonl.zst"
	if err := os.Rename(zst, zst+".away"); err != nil {
		t.Fatal(err)
	}
	if ok, _ := indexUpToDate(books, indexPath, mergedPath); ok {
		t.Fatal("missing .jsonl.zst must not be reported as up-to-date")
	}
	if err := os.Rename(zst+".away", zst); err != nil {
		t.Fatal(err)
	}

	// Stale sibling (older than the merged JSONL it derives from): a prior
	// non-fatal compression failure must be healed by a rebuild, not frozen.
	old := time.Now().Add(-time.Hour)
	if err := os.Chtimes(zst, old, old); err != nil {
		t.Fatal(err)
	}
	if ok, _ := indexUpToDate(books, indexPath, mergedPath); ok {
		t.Fatal("stale .jsonl.zst must not be reported as up-to-date")
	}
}
