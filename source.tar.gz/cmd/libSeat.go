package cmd

import (
	"accorder/pkg/libraryflow"
	"bytes"
	"fmt"
	"time"
)

type LibSeatCmd struct {
	Show    LibSeatShowCmd    `cmd:"" help:"Show the active writer seat." json:"show"`
	Claim   LibSeatClaimCmd   `cmd:"" help:"Claim the writer seat for this machine." json:"claim"`
	Release LibSeatReleaseCmd `cmd:"" help:"Release this machine's writer seat." json:"release"`
}

type LibSeatShowCmd struct {
	CommonCommandFields
	GroupS3Credentials
	Passphrase string `name:"passphrase" json:"-" help:"Passphrase for the local secrets store (or set ACCORDER_SECRETS_PASSPHRASE)." env:"ACCORDER_SECRETS_PASSPHRASE" secret:"redact"`
}

func (c *LibSeatShowCmd) Run() error {
	if c.HandleShowConfig(c) {
		return nil
	}
	installation, err := loadOrCreateInstallation()
	if err != nil {
		return fmt.Errorf("lib seat show: %w", err)
	}
	remote, err := openLibraryRemoteForCommand(c.ActionAlias, c.GroupS3Credentials)
	if err != nil {
		return fmt.Errorf("lib seat show: %w", err)
	}
	defer remote.Close()
	return printWriterState(c.ActionAlias, installation, remote.readWriter())
}

type LibSeatClaimCmd struct {
	CommonCommandFields
	GroupS3Credentials
	Passphrase string `name:"passphrase" json:"-" help:"Passphrase for the local secrets store (or set ACCORDER_SECRETS_PASSPHRASE)." env:"ACCORDER_SECRETS_PASSPHRASE" secret:"redact"`
	Force      bool   `name:"force" help:"Take the seat from another valid holder whose machine is unavailable." json:"-"`
}

func (c *LibSeatClaimCmd) Run() error {
	if c.HandleShowConfig(c) {
		return nil
	}
	installation, err := loadOrCreateInstallation()
	if err != nil {
		return fmt.Errorf("lib seat claim: %w", err)
	}
	remote, err := openLibraryRemoteForCommand(c.ActionAlias, c.GroupS3Credentials)
	if err != nil {
		return fmt.Errorf("lib seat claim: %w", err)
	}
	defer remote.Close()
	current := remote.readWriter()
	switch current.Kind {
	case "invalid", "unreadable":
		return fmt.Errorf("lib seat claim: refusing invalid/unreadable _WRITER: %w", current.Err)
	case "valid":
		if current.Marker.State == "claimed" && current.Marker.SeatID == installation.SeatID {
			fmt.Printf("Writer: %q (this seat)\n", current.Marker.SeatLabel)
			return nil
		}
		if current.Marker.State == "claimed" && !c.Force {
			return fmt.Errorf("lib seat claim: writer is %q on another seat; if that machine is gone, run `accorder lib seat claim %s --force`", current.Marker.SeatLabel, c.ActionAlias)
		}
	}
	marker := libraryflow.ClaimWriter(installation.SeatID, installation.SeatLabel, time.Now(), markerIfValid(current))
	if err := writeAndVerifyWriter(remote, marker); err != nil {
		return fmt.Errorf("lib seat claim: %w", err)
	}
	if current.Kind == "valid" && current.Marker.State == "claimed" {
		fmt.Printf("Writer seat taken over from %q; now %q (this seat).\n", current.Marker.SeatLabel, installation.SeatLabel)
	} else {
		fmt.Printf("Writer: %q (this seat)\n", installation.SeatLabel)
	}
	return nil
}

type LibSeatReleaseCmd struct {
	CommonCommandFields
	GroupS3Credentials
	Passphrase string `name:"passphrase" json:"-" help:"Passphrase for the local secrets store (or set ACCORDER_SECRETS_PASSPHRASE)." env:"ACCORDER_SECRETS_PASSPHRASE" secret:"redact"`
}

func (c *LibSeatReleaseCmd) Run() error {
	if c.HandleShowConfig(c) {
		return nil
	}
	installation, err := loadOrCreateInstallation()
	if err != nil {
		return fmt.Errorf("lib seat release: %w", err)
	}
	remote, err := openLibraryRemoteForCommand(c.ActionAlias, c.GroupS3Credentials)
	if err != nil {
		return fmt.Errorf("lib seat release: %w", err)
	}
	defer remote.Close()
	current := remote.readWriter()
	if current.Kind == "absent" || (current.Kind == "valid" && current.Marker.State == "free") {
		fmt.Println("Writer: free")
		return nil
	}
	if current.Kind == "invalid" || current.Kind == "unreadable" {
		return fmt.Errorf("lib seat release: refusing invalid/unreadable _WRITER: %w", current.Err)
	}
	if current.Marker.SeatID != installation.SeatID {
		return fmt.Errorf("lib seat release: writer is %q on another seat; only that seat may release it", current.Marker.SeatLabel)
	}
	marker := libraryflow.ReleaseWriter(time.Now(), current.Marker)
	if err := writeAndVerifyWriter(remote, marker); err != nil {
		return fmt.Errorf("lib seat release: %w", err)
	}
	fmt.Println("Writer: free")
	return nil
}

func markerIfValid(state remoteWriterState) *libraryflow.WriterMarker {
	if state.Kind != "valid" {
		return nil
	}
	marker := state.Marker
	return &marker
}

func writeAndVerifyWriter(remote *libraryRemote, marker libraryflow.WriterMarker) error {
	raw, err := marker.Marshal()
	if err != nil {
		return err
	}
	if err := remote.write(libraryflow.WriterPath, raw); err != nil {
		return err
	}
	readback := remote.readWriter()
	if readback.Kind != "valid" || !bytes.Equal(readback.Raw, raw) {
		return errorsForWriterReadback(readback)
	}
	return nil
}

func errorsForWriterReadback(state remoteWriterState) error {
	if state.Err != nil {
		return fmt.Errorf("_WRITER readback failed: %w", state.Err)
	}
	return fmt.Errorf("_WRITER readback did not match the requested state")
}

func printWriterState(alias string, installation libraryInstallation, writer remoteWriterState) error {
	switch writer.Kind {
	case "absent":
		fmt.Println("Writer: free (legacy marker absent)")
	case "invalid", "unreadable":
		fmt.Printf("Writer: %s (%v)\n", writer.Kind, writer.Err)
	case "valid":
		switch writer.Marker.State {
		case "free":
			fmt.Println("Writer: free")
		case "claimed":
			if writer.Marker.SeatID == installation.SeatID {
				fmt.Printf("Writer: %q (this seat)\n", writer.Marker.SeatLabel)
			} else {
				fmt.Printf("Writer: %q (another seat)\n", writer.Marker.SeatLabel)
				fmt.Printf("Take over only if it is unavailable: accorder lib seat claim %s --force\n", alias)
			}
		}
	default:
		return fmt.Errorf("unknown writer state %q", writer.Kind)
	}
	return nil
}
