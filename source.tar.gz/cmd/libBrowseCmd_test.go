package cmd

import (
	"accorder/pkg/torshare"
	"crypto/sha256"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"testing"
)

// TestIdentityFromGeneration verifies that a per_library identity is derived
// from the BaseGeneration portion of a _GENERATION sentinel (first 16 bytes,
// formatted as hex).
func TestIdentityFromGeneration(t *testing.T) {
	var base [16]byte
	copy(base[:], []byte{0xde, 0xad, 0xbe, 0xef, 0x01, 0x02, 0x03, 0x04,
		0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c})
	gen := uint64(42)

	encoded := torshare.EncodeGeneration(base, gen)
	decodedBase, decodedGen, err := torshare.DecodeGeneration(encoded)
	if err != nil {
		t.Fatalf("DecodeGeneration: %v", err)
	}
	if decodedBase != base {
		t.Fatalf("base mismatch: got %x, want %x", decodedBase, base)
	}
	if decodedGen != gen {
		t.Fatalf("gen mismatch: got %d, want %d", decodedGen, gen)
	}

	identity := fmt.Sprintf("%x", decodedBase)
	want := "deadbeef0102030405060708090a0b0c"
	if identity != want {
		t.Fatalf("identity: got %s, want %s", identity, want)
	}
}

// TestAggregateIdentityDerivation verifies that the aggregate identity is a
// deterministic sha256(NUL-joined sorted loaded-member UUIDs)[:16].
func TestAggregateIdentityDerivation(t *testing.T) {
	computeIdentity := func(uuids []string) [16]byte {
		sorted := make([]string, len(uuids))
		copy(sorted, uuids)
		sort.Strings(sorted)
		h := sha256.New()
		for _, u := range sorted {
			fmt.Fprintf(h, "%s\x00", u)
		}
		var id [16]byte
		copy(id[:], h.Sum(nil))
		return id
	}

	t.Run("deterministic", func(t *testing.T) {
		uuids := []string{"aaa-111", "bbb-222", "ccc-333"}
		id1 := computeIdentity(uuids)
		id2 := computeIdentity(uuids)
		if id1 != id2 {
			t.Fatalf("identity not deterministic: %x vs %x", id1, id2)
		}
	})

	t.Run("order_independent", func(t *testing.T) {
		id1 := computeIdentity([]string{"bbb-222", "aaa-111", "ccc-333"})
		id2 := computeIdentity([]string{"ccc-333", "aaa-111", "bbb-222"})
		if id1 != id2 {
			t.Fatalf("identity depends on input order: %x vs %x", id1, id2)
		}
	})

	t.Run("membership_change", func(t *testing.T) {
		id1 := computeIdentity([]string{"aaa-111", "bbb-222"})
		id2 := computeIdentity([]string{"aaa-111", "bbb-222", "ccc-333"})
		if id1 == id2 {
			t.Fatal("adding a member should change the identity")
		}
	})

	t.Run("removal_changes_identity", func(t *testing.T) {
		id1 := computeIdentity([]string{"aaa-111", "bbb-222", "ccc-333"})
		id2 := computeIdentity([]string{"aaa-111", "ccc-333"})
		if id1 == id2 {
			t.Fatal("removing a member should change the identity")
		}
	})
}

// TestIdentityResolutionCacheDir verifies that identity resolution produces
// hex-based cache directory paths.
func TestIdentityResolutionCacheDir(t *testing.T) {
	cacheBase := t.TempDir()

	t.Run("per_library_identity_keyed", func(t *testing.T) {
		var base [16]byte
		copy(base[:], []byte{0xab, 0xcd, 0xef, 0x01, 0x02, 0x03, 0x04, 0x05,
			0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d})
		identity := fmt.Sprintf("%x", base)
		cacheDir := filepath.Join(cacheBase, identity)
		if err := os.MkdirAll(cacheDir, 0700); err != nil {
			t.Fatal(err)
		}

		// Verify it's a hex path, not a label path.
		wantDir := filepath.Join(cacheBase, "abcdef0102030405060708090a0b0c0d")
		if cacheDir != wantDir {
			t.Fatalf("cacheDir: got %s, want %s", cacheDir, wantDir)
		}

		// Verify no label-named dir exists.
		labelDir := filepath.Join(cacheBase, "my-library")
		if _, err := os.Stat(labelDir); err == nil {
			t.Fatal("label-keyed dir should not exist")
		}
	})

	t.Run("aggregator_identity_from_file", func(t *testing.T) {
		identityBytes := []byte{0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08,
			0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10}
		identity := fmt.Sprintf("%x", identityBytes)
		cacheDir := filepath.Join(cacheBase, identity)
		if err := os.MkdirAll(cacheDir, 0700); err != nil {
			t.Fatal(err)
		}
		wantDir := filepath.Join(cacheBase, "0102030405060708090a0b0c0d0e0f10")
		if cacheDir != wantDir {
			t.Fatalf("cacheDir: got %s, want %s", cacheDir, wantDir)
		}
	})

	t.Run("aggregator_fallback_to_label", func(t *testing.T) {

		// When _IDENTITY fetch fails, identity falls back to label.
		label := "my-library"
		identity := label // simulate fallback
		cacheDir := filepath.Join(cacheBase, identity)
		if err := os.MkdirAll(cacheDir, 0700); err != nil {
			t.Fatal(err)
		}
		wantDir := filepath.Join(cacheBase, "my-library")
		if cacheDir != wantDir {
			t.Fatalf("fallback cacheDir: got %s, want %s", cacheDir, wantDir)
		}
	})
}
