package cmd

import (
	"accorder/pkg/calibre"
	"os"
	"path/filepath"
	"testing"

	"github.com/goccy/go-json"
)

// ---------------------------------------------------------------------------
// WF2 Health Monitor Tests: retired state, health tracking, state transitions,
// buildMemberPollSet inclusion, HasRcloneMembers, status command, mutateLocked.
// ---------------------------------------------------------------------------

func TestIsActive_RetiredReturnsFalse(t *testing.T) {
	m := calibre.LibraryMeta{State: "retired"}
	if m.IsActive() {
		t.Error("IsActive() should return false for retired state")
	}
}

func TestIsMemberActive_RetiredReturnsFalse(t *testing.T) {
	if isMemberActive("retired") {
		t.Error("isMemberActive(\"retired\") should return false")
	}
}

func TestHasRcloneMembers_RetiredIncluded(t *testing.T) {
	registry := map[string]calibre.LibraryMeta{
		"a": {Kind: "rclone", State: "retired", Prefix: "alice"},
	}
	if !calibre.HasRcloneMembers(registry) {
		t.Error("HasRcloneMembers should return true when only retired rclone members exist")
	}
}

func TestHasRcloneMembers_DisabledExcluded(t *testing.T) {
	registry := map[string]calibre.LibraryMeta{
		"a": {Kind: "rclone", State: "disabled", Prefix: "alice"},
	}
	if calibre.HasRcloneMembers(registry) {
		t.Error("HasRcloneMembers should return false when only disabled rclone members exist")
	}
}

func TestBuildMemberPollSet_IncludesRetired(t *testing.T) {
	registry := map[string]calibre.LibraryMeta{
		"a": {Prefix: "alice", State: "retired"},
		"b": {Prefix: "bob", State: "ready"},
		"c": {Prefix: "carol", State: "disabled"},
		"d": {Prefix: "dave", Kind: "local", LocalPath: "/tmp"},
	}
	pollSet := buildMemberPollSet(registry)

	if _, ok := pollSet["a"]; !ok {
		t.Error("buildMemberPollSet should include retired members")
	}
	if _, ok := pollSet["b"]; !ok {
		t.Error("buildMemberPollSet should include ready members")
	}
	if _, ok := pollSet["c"]; ok {
		t.Error("buildMemberPollSet should exclude disabled members")
	}
	if _, ok := pollSet["d"]; ok {
		t.Error("buildMemberPollSet should exclude local members")
	}
}

func TestBuildMemberPollSet_RetiredStatePreserved(t *testing.T) {
	registry := map[string]calibre.LibraryMeta{
		"a": {Prefix: "alice", State: "retired"},
	}
	pollSet := buildMemberPollSet(registry)
	entry, ok := pollSet["a"]
	if !ok {
		t.Fatal("expected retired member in poll set")
	}
	if entry.State != "retired" {
		t.Errorf("expected State=%q, got %q", "retired", entry.State)
	}
}

func TestActiveUUIDs_ExcludesRetired(t *testing.T) {
	registry := map[string]calibre.LibraryMeta{
		"a": {Prefix: "alice", State: "ready"},
		"b": {Prefix: "bob", State: "retired"},
		"c": {Prefix: "carol", State: "disabled"},
		"d": {Prefix: "dave", State: ""},
	}

	var activeUUIDs []string
	for u, meta := range registry {
		if isMemberActive(meta.State) {
			activeUUIDs = append(activeUUIDs, u)
		}
	}

	active := make(map[string]bool)
	for _, u := range activeUUIDs {
		active[u] = true
	}

	if !active["a"] {
		t.Error("ready member should be active")
	}
	if active["b"] {
		t.Error("retired member should NOT be active")
	}
	if active["c"] {
		t.Error("disabled member should NOT be active")
	}
	if !active["d"] {
		t.Error("empty-state member should be active (backward compat)")
	}
}

func TestRefreshPollSet_PrunesHealthEntries(t *testing.T) {
	tmp := t.TempDir()
	registryPath := filepath.Join(tmp, "members.json")

	registry := map[string]calibre.LibraryMeta{
		"a": {Prefix: "alice", State: "ready"},
	}
	data, _ := json.Marshal(registry)
	os.WriteFile(registryPath, data, 0o600)

	mpc := &memberPollContext{
		pollSet:      buildMemberPollSet(registry),
		registryPath: registryPath,
		lastKnownGen: make(map[string][24]byte),
		healthState: map[string]*memberHealth{
			"a":       {},
			"removed": {}, // should be pruned
		},
		registryPrefixes: make(map[string]string),
	}

	mpc.refreshPollSet()

	if _, ok := mpc.healthState["a"]; !ok {
		t.Error("health entry for existing member 'a' should be preserved")
	}
	if _, ok := mpc.healthState["removed"]; ok {
		t.Error("health entry for removed member should be pruned")
	}
}

func TestMutateMembersRegistryLocked_BasicMutation(t *testing.T) {
	tmp := t.TempDir()
	registryPath := filepath.Join(tmp, "members.json")

	registry := map[string]calibre.LibraryMeta{
		"a": {Prefix: "alice", State: "ready", Librarian: "Alice"},
	}
	data, _ := json.Marshal(registry)
	os.WriteFile(registryPath, data, 0o600)

	err := mutateMembersRegistryLocked(registryPath, func(reg map[string]calibre.LibraryMeta) error {
		m := reg["a"]
		m.State = "retired"
		reg["a"] = m
		return nil
	})
	if err != nil {
		t.Fatalf("mutateMembersRegistryLocked: %v", err)
	}

	// Re-read and verify
	reloaded, _, err := loadMembersRegistryFromPath(registryPath)
	if err != nil {
		t.Fatalf("reload: %v", err)
	}
	if reloaded["a"].State != "retired" {
		t.Errorf("expected state=retired, got %q", reloaded["a"].State)
	}
}

func TestMutateMembersRegistryLocked_NonexistentFile(t *testing.T) {
	tmp := t.TempDir()
	registryPath := filepath.Join(tmp, "nonexistent.json")

	err := mutateMembersRegistryLocked(registryPath, func(reg map[string]calibre.LibraryMeta) error {
		reg["new"] = calibre.LibraryMeta{Prefix: "new", State: "ready"}
		return nil
	})
	if err != nil {
		t.Fatalf("mutateMembersRegistryLocked on nonexistent file: %v", err)
	}

	reloaded, _, err := loadMembersRegistryFromPath(registryPath)
	if err != nil {
		t.Fatalf("reload: %v", err)
	}
	if _, ok := reloaded["new"]; !ok {
		t.Error("expected newly added member to be persisted")
	}
}

func TestPersistRetire(t *testing.T) {
	tmp := t.TempDir()
	registryPath := filepath.Join(tmp, "members.json")

	registry := map[string]calibre.LibraryMeta{
		"a": {Prefix: "alice", State: "ready", Librarian: "Alice"},
	}
	data, _ := json.Marshal(registry)
	os.WriteFile(registryPath, data, 0o600)

	if err := persistMemberState(registryPath, "a", "retired"); err != nil {
		t.Fatalf("persistMemberState(retired): %v", err)
	}

	reloaded, _, _ := loadMembersRegistryFromPath(registryPath)
	if reloaded["a"].State != "retired" {
		t.Errorf("expected state=retired after persistMemberState, got %q", reloaded["a"].State)
	}
}

func TestPersistPromote(t *testing.T) {
	tmp := t.TempDir()
	registryPath := filepath.Join(tmp, "members.json")

	registry := map[string]calibre.LibraryMeta{
		"a": {Prefix: "alice", State: "retired", Librarian: "Alice"},
	}
	data, _ := json.Marshal(registry)
	os.WriteFile(registryPath, data, 0o600)

	if err := persistMemberState(registryPath, "a", "ready"); err != nil {
		t.Fatalf("persistMemberState(ready): %v", err)
	}

	reloaded, _, _ := loadMembersRegistryFromPath(registryPath)
	if reloaded["a"].State != "ready" {
		t.Errorf("expected state=ready after persistMemberState, got %q", reloaded["a"].State)
	}
}

func TestHealthConstants(t *testing.T) {
	if retireThreshold < 1 {
		t.Error("retireThreshold must be >= 1")
	}
	if promoteThreshold < 1 {
		t.Error("promoteThreshold must be >= 1")
	}
}

func TestMemberHealth_GetOrCreate(t *testing.T) {
	mpc := &memberPollContext{
		healthState: make(map[string]*memberHealth),
	}

	h1 := mpc.getOrCreateHealth("a")
	if h1 == nil {
		t.Fatal("getOrCreateHealth should return non-nil")
	}
	if h1.Since.IsZero() {
		t.Error("Since should be set on creation")
	}

	// Second call should return the same pointer.
	h2 := mpc.getOrCreateHealth("a")
	if h1 != h2 {
		t.Error("getOrCreateHealth should return the same health object for the same UUID")
	}
}

func TestFedlibMembersStatus_OutputFormat(t *testing.T) {
	tmp := t.TempDir()
	registryPath := filepath.Join(tmp, "members.json")

	registry := map[string]calibre.LibraryMeta{
		"aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee": {Prefix: "alice", State: "ready", Librarian: "Alice"},
		"11111111-2222-3333-4444-555555555555": {Prefix: "bob", State: "retired", Librarian: "Bob"},
	}
	data, _ := json.Marshal(registry)
	os.WriteFile(registryPath, data, 0o600)

	cmd := &FedlibMembersStatusCmd{FedlibPath: tmp}
	if err := cmd.Run(); err != nil {
		t.Fatalf("FedlibMembersStatusCmd.Run: %v", err)
	}
}
