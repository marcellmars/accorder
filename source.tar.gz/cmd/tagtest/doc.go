// Package tagtest holds build-tag-gated structural assertions over the cmd
// package's Kong structs. It predates cq-41 (config-safety-followups,
// 2026-08-23): the cmd test harness was //go:build !tailscale then, so
// tailscale-only pins could live nowhere else. The harness helpers are
// build-generic now (cmd/testHelpers_test.go) and the full cmd suite —
// including the command-matrix pins in cmd/commandMatrix*_test.go —
// compiles and runs under every tag, so new cross-variant assertions
// belong in cmd itself; this package remains for pins that deliberately
// need no harness.
//
// Run the tailscale assertions with:
//
//	go test -tags tailscale ./cmd/tagtest/
//
// This untagged doc.go keeps the package valid in every build configuration.
package tagtest
