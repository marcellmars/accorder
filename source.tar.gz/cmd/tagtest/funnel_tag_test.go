//go:build tailscale

package tagtest_test

import (
	"reflect"
	"testing"

	"accorder/cmd"
)

// ca-122 structural pin for the tailscale build: FedlibShareFunnelCmd only
// compiles under -tags tailscale, where the cmd behavioral test harness does
// not compile, so the funnel half of the never-persist fix is pinned here by
// reflection instead. A revert of json:"-" on the funnel's RcloneLogLevel
// would reintroduce the sticky-diagnostic-flag incident for tailscale
// operators with every other build's tests still green.
func TestFunnelRcloneLogLevelIsNeverPersist(t *testing.T) {
	f, ok := reflect.TypeOf(cmd.FedlibShareFunnelCmd{}).FieldByName("RcloneLogLevel")
	if !ok {
		t.Fatal("FedlibShareFunnelCmd.RcloneLogLevel field is gone; the ca-122 never-persist pin no longer covers the funnel serve")
	}
	if got := f.Tag.Get("json"); got != "-" {
		t.Errorf("FedlibShareFunnelCmd.RcloneLogLevel json tag = %q, want \"-\" (never persisted to the action alias; ca-122)", got)
	}
	if got := f.Tag.Get("name"); got != "rclone-log-level" {
		t.Errorf("FedlibShareFunnelCmd.RcloneLogLevel kong name = %q, want \"rclone-log-level\" (CLI surface must stay stable)", got)
	}
}
