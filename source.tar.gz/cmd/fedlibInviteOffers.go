package cmd

import (
	"accorder/pkg/calibre"
	"accorder/pkg/fedlibinvite"
	"fmt"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"

	"github.com/goccy/go-json"
)

type ipRateLimiter struct {
	mu       sync.Mutex
	buckets  map[string]*ipBucket
	burst    float64
	interval time.Duration
}

type ipBucket struct {
	tokens float64
	last   time.Time
}

const ipRateLimiterMaxBuckets = 4096

func newIPRateLimiter(burst int, interval time.Duration) *ipRateLimiter {
	return &ipRateLimiter{
		buckets:  make(map[string]*ipBucket),
		burst:    float64(burst),
		interval: interval,
	}
}

func (l *ipRateLimiter) allow(ip string) bool {
	now := time.Now()
	l.mu.Lock()
	defer l.mu.Unlock()

	b, ok := l.buckets[ip]
	if !ok {
		if len(l.buckets) >= ipRateLimiterMaxBuckets {
			l.sweepLocked(now)
		}
		b = &ipBucket{tokens: l.burst, last: now}
		l.buckets[ip] = b
	}

	b.tokens += now.Sub(b.last).Seconds() / l.interval.Seconds()
	if b.tokens > l.burst {
		b.tokens = l.burst
	}
	b.last = now

	if b.tokens < 1 {
		return false
	}
	b.tokens--
	return true
}

func (l *ipRateLimiter) sweepLocked(now time.Time) {
	idle := time.Duration(l.burst) * l.interval
	for ip, b := range l.buckets {
		if now.Sub(b.last) > idle {
			delete(l.buckets, ip)
		}
	}
}

type inviteClaimResponse struct {
	Version int    `json:"version"`
	Invite  string `json:"invite"`
}

type peerClaimRequest struct {
	LibraryUUID string `json:"library_uuid"`
	Endpoint    string `json:"endpoint"`
	GrantToken  string `json:"grant_token"`
}

func makeInviteHandler(offersDir string, limiter *ipRateLimiter, registryPath ...string) http.Handler {
	var regPath string
	if len(registryPath) > 0 {
		regPath = registryPath[0]
	}
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if !limiter.allow(clientIP(r)) {
			http.Error(w, "rate limited", http.StatusTooManyRequests)
			return
		}

		rest := strings.TrimPrefix(r.URL.Path, "/invite/")
		token, tail, hasTail := strings.Cut(rest, "/")
		if !fedlibinvite.ValidOfferToken(token) {
			http.NotFound(w, r)
			return
		}

		switch {
		case !hasTail && r.Method == http.MethodGet:
			handleInviteInfo(w, r, offersDir, token)
		case hasTail && tail == "claim" && r.Method == http.MethodPost:
			handleInviteClaim(w, r, offersDir, token, regPath)
		default:
			http.NotFound(w, r)
		}
	})
}

func handleInviteInfo(w http.ResponseWriter, r *http.Request, offersDir, token string) {
	offer, err := fedlibinvite.ReadOffer(offersDir, token)
	if err != nil || offer.Expired(time.Now()) {
		http.NotFound(w, r)
		return
	}
	claimURL := "https://" + r.Host + "/invite/" + token

	kind := "operator"
	if offer.IsPeerOffer() {
		kind = "peer"
	}

	if strings.Contains(r.Header.Get("Accept"), "application/json") {
		info := map[string]string{
			"kind":         kind,
			"prefix":       offer.Prefix,
			"display_name": offer.DisplayName,
		}
		if offer.IsPeerOffer() {
			if fedlibID, derr := fedlibinvite.OpenOffer(token, offer); derr == nil && fedlibID != "" {
				info["fedlib_id"] = fedlibID
			}
		}
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(info)
		return
	}

	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	fmt.Fprintf(w, "accorder federation invite\n\n")
	fmt.Fprintf(w, "  member:  %s\n", offer.DisplayName)
	fmt.Fprintf(w, "  prefix:  %s\n", offer.Prefix)
	if offer.IsPeerOffer() {
		fmt.Fprintf(w, "  kind:    peer\n")
	}
	fmt.Fprintf(w, "  expires: %s\n\n", offer.Expires.Format(time.RFC3339))
	if offer.IsPeerOffer() {
		fmt.Fprintf(w, "On the machine hosting the library (where 'lib share live' runs):\n\n")
		fmt.Fprintf(w, "  %s\n", joinCommandLine(offer.Prefix, claimURL, "--endpoint 'https://your-host/'"))
	} else {
		fmt.Fprintf(w, "On the machine holding the Calibre library:\n\n")
		fmt.Fprintf(w, "  %s\n", joinCommandLine(offer.Prefix, claimURL, "-c /path/to/calibre/library"))
	}
}

func handleInviteClaim(w http.ResponseWriter, r *http.Request, offersDir, token, registryPath string) {
	peek, err := fedlibinvite.ReadOffer(offersDir, token)
	if err != nil || peek.Expired(time.Now()) {
		http.NotFound(w, r)
		return
	}

	if peek.IsPeerOffer() {
		handlePeerClaim(w, r, offersDir, token, registryPath)
		return
	}

	offer, err := fedlibinvite.ClaimOffer(offersDir, token)
	if err != nil || offer.Expired(time.Now()) {
		http.NotFound(w, r)
		return
	}
	blob, err := fedlibinvite.OpenOffer(token, offer)
	if err != nil {
		http.NotFound(w, r)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(inviteClaimResponse{Version: 1, Invite: blob})
}

func handlePeerClaim(w http.ResponseWriter, r *http.Request, offersDir, token, registryPath string) {
	if registryPath == "" {
		http.Error(w, "peer claims not configured", http.StatusInternalServerError)
		return
	}

	var req peerClaimRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "invalid request body", http.StatusBadRequest)
		return
	}
	req.Endpoint = strings.TrimRight(req.Endpoint, "/")
	if req.LibraryUUID == "" || req.Endpoint == "" || req.GrantToken == "" {
		http.Error(w, "library_uuid, endpoint, and grant_token are required", http.StatusBadRequest)
		return
	}
	if u, perr := url.Parse(req.Endpoint); perr != nil || (u.Scheme != "https" && u.Scheme != "http") || u.Host == "" {
		http.Error(w, "endpoint must be a valid http(s):// URL", http.StatusBadRequest)
		return
	}

	offer, err := fedlibinvite.ClaimOffer(offersDir, token)
	if err != nil || offer.Expired(time.Now()) {
		http.NotFound(w, r)
		return
	}

	fedlibID, _ := fedlibinvite.OpenOffer(token, offer)
	dictID, allocErr := allocateMemberDictID(fedlibID)
	if allocErr != nil {
		http.Error(w, "dictid allocation failed", http.StatusInternalServerError)
		return
	}

	meta := calibre.LibraryMeta{
		Librarian:  offer.DisplayName,
		Prefix:     offer.Prefix,
		Kind:       "peer",
		State:      "ready",
		Endpoint:   req.Endpoint,
		GrantToken: req.GrantToken,
		DictID:     dictID,
	}

	err = mutateMembersRegistryLocked(registryPath, func(reg map[string]calibre.LibraryMeta) error {
		if _, exists := reg[req.LibraryUUID]; exists {
			return fmt.Errorf("member %s already registered", req.LibraryUUID)
		}
		reg[req.LibraryUUID] = meta
		return nil
	})
	if err != nil {
		if strings.Contains(err.Error(), "already registered") {
			http.Error(w, err.Error(), http.StatusConflict)
		} else {
			http.Error(w, "registration failed", http.StatusInternalServerError)
		}
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	_ = json.NewEncoder(w).Encode(map[string]string{
		"status":  "registered",
		"prefix":  offer.Prefix,
		"kind":    "peer",
		"message": "Peer member registered successfully. The operator's poller will begin probing your endpoint.",
	})
}
