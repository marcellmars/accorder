//go:build !tailscale

package cmd

//

// Phase 5.4 — B4 passphrase-free secrets: fresh-seat key generation, key-file
// resolver, rekey round-trips, and the scrypt-store regression gate (never
// generate a key for an existing passphrase store).

import (
	"accorder/pkg/fedlibinvite"
	"accorder/pkg/secrets"
	"errors"
	"os"
	"reflect"
	"strings"
	"testing"
)

func b4Blob() string {
	return fedlibinvite.EncodeWriteInvite(&fedlibinvite.WriteInvite{
		FedlibID:  "fed-1",
		Backend:   "s3",
		Prefix:    "b4seat",
		AccessKey: "AK-B4",
		SecretKey: "SK-B4",
		Label:     "B4 Librarian",
		RemoteConfig: map[string]string{
			"provider": "Wasabi",
			"endpoint": "https://s3.test",
			"bucket":   "motw",
		},
	})
}

// Fresh seat: no store, no key file, no env/flag → join generates a 0600
// secrets.key and stores the credentials under it.
func TestJoinB4_FreshSeatGeneratesKeyFile(t *testing.T) {
	_ = testSetup(t)
	withLocalCommandRemote(t, t.TempDir())
	t.Setenv("ACCORDER_SECRETS_PASSPHRASE", "")

	blob := b4Blob()
	_, ctx := parseCLI(t, []string{"lib", "join", "b4seat", "--invite", blob})
	join := &LibJoinCmd{Invite: blob, CommonCommandFields: CommonCommandFields{ActionAlias: "b4seat"}}
	// A library-less join is deliberately incomplete — credentials and identity
	// are stored but nothing is published, which now reports non-zero. That is
	// only the vehicle here; the subject is the generated key file below.
	_, _, err := captureInviteOutput(t, func() error { return join.Run(ctx) })
	if !errors.Is(err, errJoinPublishedNothing) {
		t.Fatalf("lib join (passphrase-less): expected the incomplete-join report, got: %v", err)
	}

	info, err := os.Stat(secretsKeyPath())
	if err != nil {
		t.Fatalf("secrets.key not generated: %v", err)
	}
	if perm := info.Mode().Perm(); perm != 0o600 {
		t.Errorf("secrets.key mode = %o, want 0600", perm)
	}

	id, err := loadOrGenerateSecretsKey(false)
	if err != nil {
		t.Fatalf("re-load generated key: %v", err)
	}
	store := secrets.NewStoreWithIdentity(secretsStorePath(), id)
	got, err := store.Get("b4seat/write/access-key")
	if err != nil {
		t.Fatalf("read joined secret with key file: %v", err)
	}
	if got != "AK-B4" {
		t.Errorf("access-key = %q, want AK-B4", got)
	}
}

// Regression gate: an existing scrypt-encrypted secrets.age with no
// env/flag/key file must fall to the prompt (here: its actionable no-terminal
// error) and must NEVER generate secrets.key.
func TestJoinB4_ExistingScryptStoreNeverGeneratesKey(t *testing.T) {
	_ = testSetup(t)
	t.Setenv("ACCORDER_SECRETS_PASSPHRASE", "")

	// Seed a scrypt store (a passphrase seat from before B4).
	if err := secrets.NewStore(secretsStorePath(), "old-pp").Set("x/y", "z"); err != nil {
		t.Fatal(err)
	}

	blob := b4Blob()
	_, ctx := parseCLI(t, []string{"lib", "join", "b4seat", "--invite", blob})
	join := &LibJoinCmd{Invite: blob, CommonCommandFields: CommonCommandFields{ActionAlias: "b4seat"}}
	_, _, err := captureInviteOutput(t, func() error { return join.Run(ctx) })
	if err == nil {
		t.Fatal("join on scrypt store without passphrase succeeded; want prompt-path error")
	}
	if !strings.Contains(err.Error(), "ACCORDER_SECRETS_PASSPHRASE") {
		t.Errorf("error not actionable: %v", err)
	}
	if _, statErr := os.Stat(secretsKeyPath()); !os.IsNotExist(statErr) {
		t.Errorf("secrets.key was generated for an existing scrypt store (stat err=%v)", statErr)
	}

	// The scrypt store still opens with the old passphrase.
	if v, gerr := secrets.NewStore(secretsStorePath(), "old-pp").Get("x/y"); gerr != nil || v != "z" {
		t.Errorf("scrypt store damaged: %q, %v", v, gerr)
	}
}

// Key-file seat: bare publish-path resolution with no env var and no
// Passphrase field value.
func TestResolverB4_KeyFileSeatResolvesWithoutEnv(t *testing.T) {
	_ = testSetup(t)
	t.Setenv("ACCORDER_SECRETS_PASSPHRASE", "")

	id, err := loadOrGenerateSecretsKey(true)
	if err != nil {
		t.Fatal(err)
	}
	store := secrets.NewStoreWithIdentity(secretsStorePath(), id)
	for k, v := range map[string]string{
		"b4seat/write/access-key": "AK-B4",
		"b4seat/write/secret-key": "SK-B4",
		"b4seat/write/provider":   "Wasabi",
		"b4seat/write/endpoint":   "https://s3.test",
		"b4seat/write/bucket":     "motw",
		"b4seat/write/prefix":     "b4seat",
	} {
		if err := store.Set(k, v); err != nil {
			t.Fatal(err)
		}
	}

	type tgt struct {
		GroupS3Credentials
		Passphrase string
	}
	target := tgt{}
	resolveS3CredsFromSecretsStore(reflect.ValueOf(&target).Elem(), "b4seat", false)
	if target.S3AccessKey != "AK-B4" || target.S3SecretKey != "SK-B4" {
		t.Errorf("creds not resolved from key-file store: %+v", target.GroupS3Credentials)
	}
	if target.Bucket != "motw/b4seat" {
		t.Errorf("Bucket = %q, want motw/b4seat", target.Bucket)
	}
}

// Passphrase seats regress nowhere: env passphrase still wins even when a
// key file exists (resolution order unchanged ahead of the key file).
func TestResolverB4_EnvPassphraseStillWins(t *testing.T) {
	_ = testSetup(t)
	t.Setenv("ACCORDER_SECRETS_PASSPHRASE", "pp")

	if err := secrets.NewStore(secretsStorePath(), "pp").Set("al/write/access-key", "AK-PP"); err != nil {
		t.Fatal(err)
	}

	// A key file also exists (e.g. generated later for another purpose) — it
	// must NOT shadow the env passphrase.
	if _, err := loadOrGenerateSecretsKey(true); err != nil {
		t.Fatal(err)
	}

	type tgt struct {
		GroupS3Credentials
		Passphrase string
	}
	target := tgt{}
	resolveS3CredsFromSecretsStore(reflect.ValueOf(&target).Elem(), "al", false)
	if target.S3AccessKey != "AK-PP" {
		t.Errorf("env-passphrase store not used: S3AccessKey = %q, want AK-PP", target.S3AccessKey)
	}
}

func TestSecretsRekey_RoundTripsBothWays(t *testing.T) {
	_ = testSetup(t)
	t.Setenv("ACCORDER_SECRETS_PASSPHRASE", "")

	entries := map[string]string{
		"a/write/access-key": "AK",
		"a/write/secret-key": "SK",
		"b/write/bucket":     "motw",
	}
	scrypt := secrets.NewStore(secretsStorePath(), "first-pp")
	for k, v := range entries {
		if err := scrypt.Set(k, v); err != nil {
			t.Fatal(err)
		}
	}

	// scrypt → key file.
	toKey := &SecretsRekeyCmd{ToKeyFile: true, Passphrase: "first-pp"}
	if _, _, err := captureInviteOutput(t, toKey.Run); err != nil {
		t.Fatalf("rekey --to-key-file: %v", err)
	}
	id, err := loadOrGenerateSecretsKey(false)
	if err != nil {
		t.Fatalf("key file after rekey: %v", err)
	}
	keyStore := secrets.NewStoreWithIdentity(secretsStorePath(), id)
	for k, v := range entries {
		if got, err := keyStore.Get(k); err != nil || got != v {
			t.Errorf("after to-key-file, %s = %q (%v), want %q", k, got, err, v)
		}
	}

	// The old passphrase no longer opens the store.
	if _, err := secrets.NewStore(secretsStorePath(), "first-pp").Get("a/write/access-key"); err == nil {
		t.Error("old passphrase still decrypts after rekey to key file")
	}

	// key file → new passphrase.
	toPP := &SecretsRekeyCmd{ToPassphrase: true, Passphrase: "second-pp"}
	if _, _, err := captureInviteOutput(t, toPP.Run); err != nil {
		t.Fatalf("rekey --to-passphrase: %v", err)
	}
	ppStore := secrets.NewStore(secretsStorePath(), "second-pp")
	for k, v := range entries {
		if got, err := ppStore.Get(k); err != nil || got != v {
			t.Errorf("after to-passphrase, %s = %q (%v), want %q", k, got, err, v)
		}
	}

	// The key file no longer opens the store.
	if _, err := keyStore.Get("a/write/access-key"); err == nil {
		t.Error("key file still decrypts after rekey to passphrase")
	}
}

func TestSecretsRekey_Validation(t *testing.T) {
	_ = testSetup(t)
	t.Setenv("ACCORDER_SECRETS_PASSPHRASE", "")

	// No store at all.
	c := &SecretsRekeyCmd{ToKeyFile: true, Passphrase: "pp"}
	if _, _, err := captureInviteOutput(t, c.Run); err == nil || !strings.Contains(err.Error(), "no store") {
		t.Errorf("rekey without store: %v", err)
	}

	// Store exists, neither direction chosen.
	if err := secrets.NewStore(secretsStorePath(), "pp").Set("k", "v"); err != nil {
		t.Fatal(err)
	}
	c = &SecretsRekeyCmd{}
	if _, _, err := captureInviteOutput(t, c.Run); err == nil || !strings.Contains(err.Error(), "--to-key-file or --to-passphrase") {
		t.Errorf("rekey without direction: %v", err)
	}

	// --to-passphrase without a key file → actionable error, store untouched.
	c = &SecretsRekeyCmd{ToPassphrase: true, Passphrase: "new"}
	if _, _, err := captureInviteOutput(t, c.Run); err == nil || !strings.Contains(err.Error(), "already in passphrase mode") {
		t.Errorf("rekey to-passphrase without key file: %v", err)
	}
	if v, err := secrets.NewStore(secretsStorePath(), "pp").Get("k"); err != nil || v != "v" {
		t.Errorf("store damaged by failed rekey: %q, %v", v, err)
	}
}
