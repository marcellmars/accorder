//go:build tor

package cmd

import "testing"

// The tor build adds its transport beside the base set (cq-38).
func TestCommandMatrix_TorExtrasPresent(t *testing.T) {
	got := collectCommandPaths(t)
	for _, want := range []string{
		"lib.share.address",
		"lib.share.grant-tor",
		"fedlib.share.grant-tor",
	} {
		if !got[want] {
			t.Errorf("tor extra %q missing from the tor build", want)
		}
	}
}
