package cmd

import (
	"fmt"
	"os"
	"path/filepath"

	"github.com/alecthomas/kong"
)

type FedlibShareResetGrantsCmd struct {
	CommonCommandFields
}

func (c *FedlibShareResetGrantsCmd) Run(ctx *kong.Context) error {
	if c.HandleShowConfig(c) {
		return nil
	}

	stateDir := filepath.Join(accorderConfigDir, "clearnet", c.ActionAlias)
	reg, err := newGrantRegistry(stateDir)
	if err != nil {
		return fmt.Errorf("fedlib share reset-grants: %w", err)
	}

	if err := reg.reset(); err != nil {
		return fmt.Errorf("fedlib share reset-grants: %w", err)
	}
	fmt.Fprintln(os.Stderr, "fedlib share reset-grants: signing key rotated, all grants invalidated")
	return nil
}
