package cmd

import "testing"

// TestAggregateBaseGen_ContentSensitive guards the fix for the 2026-06-08 deploy
// bug: a content-only member rebuild (e.g. adding cover fingerprints) left book
// count + last-modified unchanged, so the aggregate generation was identical and
// both the serve hot-swap and the browse re-sync skipped the new aggregate.
// Folding the member index's own generation into the aggregate baseGen fixes it.
//

// NOTE: the old computeAggregateBaseGen is retained for backward compatibility
// (it folds per-member content signals). This test still validates its contract.
func TestAggregateBaseGen_ContentSensitive(t *testing.T) {
	base := []aggMemberGen{
		{uuid: "u1", bookCount: 10, lastModified: "2026-06-01", idxBaseGen: [16]byte{1, 2, 3}, idxGen: 0},
		{uuid: "u2", bookCount: 5, lastModified: "2026-05-01", idxBaseGen: [16]byte{4, 5, 6}, idxGen: 0},
	}
	g0 := computeAggregateBaseGen(base)

	// Deterministic: identical input -> identical generation (no spurious re-syncs).
	if computeAggregateBaseGen(base) != g0 {
		t.Fatal("computeAggregateBaseGen must be deterministic for identical input")
	}

	// Content-only member rebuild: same uuid/count/last-modified, but the member's
	// index generation changed -> the aggregate generation MUST change.
	changed := []aggMemberGen{
		{uuid: "u1", bookCount: 10, lastModified: "2026-06-01", idxBaseGen: [16]byte{9, 9, 9}, idxGen: 0},
		{uuid: "u2", bookCount: 5, lastModified: "2026-05-01", idxBaseGen: [16]byte{4, 5, 6}, idxGen: 0},
	}
	if computeAggregateBaseGen(changed) == g0 {
		t.Fatal("aggregate generation must change when a member's index generation changes (content-only update)")
	}

	// A member's incremental Generation bump must also change it.
	genBumped := []aggMemberGen{
		{uuid: "u1", bookCount: 10, lastModified: "2026-06-01", idxBaseGen: [16]byte{1, 2, 3}, idxGen: 7},
		{uuid: "u2", bookCount: 5, lastModified: "2026-05-01", idxBaseGen: [16]byte{4, 5, 6}, idxGen: 0},
	}
	if computeAggregateBaseGen(genBumped) == g0 {
		t.Fatal("aggregate generation must change when a member index Generation is bumped")
	}
}

// TestMembershipHashBaseGen verifies that computeMembershipHash:
// 1. Is deterministic for identical input.
// 2. Changes when a member joins or leaves.
// 3. Is STABLE when member content (book count, last-modified, generation) changes.
func TestMembershipHashBaseGen(t *testing.T) {
	uuids := []string{"u1", "u2"}
	g0 := computeMembershipHash(uuids)

	// Deterministic.
	if computeMembershipHash(uuids) != g0 {
		t.Fatal("computeMembershipHash must be deterministic for identical input")
	}

	// Order-independent (sorted internally).
	if computeMembershipHash([]string{"u2", "u1"}) != g0 {
		t.Fatal("computeMembershipHash must be order-independent")
	}

	// Member join → must change.
	joined := []string{"u1", "u2", "u3"}
	if computeMembershipHash(joined) == g0 {
		t.Fatal("membership hash must change when a member joins")
	}

	// Member leave → must change.
	left := []string{"u1"}
	if computeMembershipHash(left) == g0 {
		t.Fatal("membership hash must change when a member leaves")
	}

	// Content-only change (same UUIDs) → must be STABLE.
	// computeMembershipHash only takes UUIDs, so same input = same output.
	// This is the key semantic difference from the old computeAggregateBaseGen.
	if computeMembershipHash([]string{"u1", "u2"}) != g0 {
		t.Fatal("membership hash must be stable when member set is unchanged")
	}
}
