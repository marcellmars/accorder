package cmd

import (
	"accorder/pkg/calibre"
	"accorder/pkg/rclonexfer"
	"accorder/pkg/torshare"
	"bytes"
	"context"
	"fmt"
	"hash/fnv"
	"io"
	"log"
	"net"
	"net/http"
	"net/http/httputil"
	"net/url"
	"os"
	"path"
	"path/filepath"
	"reflect"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/goccy/go-json"
)

type FedlibShareLiveCmd struct {
	CommonCommandFields
	AggregatePath    string `name:"aggregate-path" json:"aggregate-path" help:"Local working dir for the cached aggregate (library_index.zst, libraries.json). Defaults to the descriptor's fedlib-path when omitted." validate:"omitempty"`
	S3AccessKey      string `name:"s3-access-key" json:"-" alias:"-" help:"S3 access key (read-only is enough for serve). Never remembered by the action alias; persist via the descriptor's keys file or the secrets store." validate:"omitempty" sharedgroup:"s3creds" secret:"redact,fingerprint"`
	S3SecretKey      string `name:"s3-secret-key" json:"-" alias:"-" help:"S3 secret key. Never remembered by the action alias; persist via the descriptor's keys file or the secrets store." validate:"omitempty" sharedgroup:"s3creds" secret:"redact,fingerprint"`
	CacheSize        string `name:"cache-size" json:"cache-size" help:"VFS books-pool size cap (e.g. 3000000000B, 3Gi)." default:"3000000000B"`
	CacheSizeAssets  string `name:"cache-size-assets" json:"cache-size-assets" help:"VFS assets-pool size cap for cover.jpg and member static/ objects." default:"5000000000B"`
	CacheMaxAge      string `name:"cache-max-age" json:"cache-max-age" help:"Max idle time before cache eviction (e.g. 8760h). NOTE: rclone treats 0 as evict-immediately-when-idle, not as unlimited." default:"8760h"`
	CacheMinFree     string `name:"cache-min-free" json:"cache-min-free" help:"Disk-safety floor: stop the VFS cache filling the disk below this free amount (e.g. 2Gi)." default:"2Gi"`
	DirCacheTime     string `name:"dir-cache-time" json:"dir-cache-time" help:"In-memory VFS directory metadata lifetime shared by books and assets; committed generations invalidate it early (requires --poll-interval > 0, otherwise this is the only refresh)." default:"24h"`
	RcloneLogLevel   string `name:"rclone-log-level" json:"-" help:"Log level for the embedded rclone (EMERGENCY..DEBUG, OFF). Empty keeps rclone's default NOTICE. Use INFO to surface the VFS cache cleaner's per-pass stats ('vfs cache: cleaned: ... in use K ... total size X'), which is how you tell whether cache-size eviction is keeping up. Chatty on a busy serve — a diagnostic, not a normal setting. Never remembered by the action alias (diagnostic class)." enum:"EMERGENCY,ALERT,CRITICAL,ERROR,WARNING,NOTICE,INFO,DEBUG,OFF," default:""`
	Listen           string `name:"listen" json:"listen" help:"HTTP listen address." default:"127.0.0.1:8723"`
	PprofListen      string `name:"pprof-listen" json:"-" help:"Loopback address for the Go pprof debug endpoint (e.g. 127.0.0.1:8724). Empty disables. Never expose publicly." default:""`
	PollInterval     int    `name:"poll-interval" json:"poll-interval" help:"Generation poll interval in seconds (0 disables hot-swap)." default:"60"`
	AllowFullRebuild bool   `name:"allow-full-rebuild" json:"allow-full-rebuild" help:"Let the daemon run the full (monolithic) aggregate rebuild when the fast incremental/splice path can't compose. The full rebuild materializes every book at once (several GB of RAM). Default off: the daemon stays bounded and keeps serving the last-good aggregate while you heal members with 'fedlib members reindex'. Turn ON only if your aggregator box has ample RAM to spare beyond the live serve."`
	OnlyTor          bool   `name:"only-tor" json:"-" help:"Tor only — do not expose an HTTP listener (requires a Tor-enabled build)."`
	OnlyHTTP         bool   `name:"only-http" json:"-" help:"HTTP only — skip Tor even if available (Tor-enabled build only)."`
	Mode             string `name:"mode" json:"-" help:"Access mode assertion: public (everything open), offline-private (browse open, index gated), private (everything gated). When the descriptor sets a mode, --mode must equal it (a different value is an error); when the descriptor sets none, the value applies to this invocation only. Never remembered by the action alias — the descriptor is the durable authority." enum:"public,offline-private,private,," default:""`

	descriptor   *fedlibDescriptor `kong:"-" json:"-"`
	prepared     bool              `kong:"-" json:"-"`
	Bucket       string            `kong:"-" json:"-"`
	UploadPrefix string            `kong:"-" json:"-"`
	S3Provider   string            `kong:"-" json:"-"`
	S3Endpoint   string            `kong:"-" json:"-"`
	KeysFile     string            `kong:"-" json:"-"`

	MeterWindow            time.Duration `name:"meter-window" json:"meter-window" help:"Rolling window for per-session distinct-file counting." default:"1h"`
	MeterMaxSessions       int           `name:"meter-max-sessions" json:"meter-max-sessions" help:"Cap on concurrent live sessions." default:"50000"`
	MeterBucketGranularity time.Duration `name:"meter-bucket-granularity" json:"meter-bucket-granularity" help:"Time granularity for rolling-window distinct-file counter." default:"60s"`
	MeterMaxDistinct       int           `name:"meter-max-distinct" json:"meter-max-distinct" help:"Cap on distinct path hashes tracked per session." default:"1000"`

	EgressMonthlyAllowance string  `name:"egress-monthly-allowance" json:"egress-monthly-allowance" help:"Monthly egress allowance (e.g. 500Gi). Sets token-bucket sustained rate." default:""`
	EgressBudgetUSD        float64 `name:"egress-budget-usd" json:"egress-budget-usd" help:"Daily USD budget for S3 egress (pay-as-you-go backends). Overrides monthly allowance." default:"0"`
	EgressPricePerGB       float64 `name:"egress-price-per-gb" json:"egress-price-per-gb" help:"Provider egress price in $/GB (used with --egress-budget-usd)." default:"0.04"`
	EgressLimit            string  `name:"egress-limit" json:"egress-limit" help:"Raw bytes/day egress limit (e.g. 50Gi). Highest precedence override." default:""`
	EgressBurst            string  `name:"egress-burst" json:"egress-burst" help:"Token bucket burst allowance (e.g. 10Gi). Default: 1h of sustained budget." default:""`
}

func (c *FedlibShareLiveCmd) RequireS3Creds() error {
	return requireS3Creds(c.Bucket, c.S3AccessKey, c.S3SecretKey, c.S3Provider, c.S3Endpoint)
}

type singleIndex struct {
	search     *calibre.OpenedSearch
	typeahead  calibre.TypeaheadIndex
	libraries  map[string]calibre.LibraryMeta
	librarians map[string]string
	baseGen    [16]byte
	gen        uint64
	wg         sync.WaitGroup
	versionDir string
	data1JS    []byte
}

func (s *singleIndex) close() {
	if s == nil {
		return
	}
	if s.typeahead != nil {
		_ = s.typeahead.Close()
	}
	if s.search != nil {
		_ = s.search.Close()
	}
}

type serveState struct {
	mu      sync.Mutex
	current *singleIndex
}

func (s *serveState) snapshot() (*singleIndex, func()) {
	s.mu.Lock()
	idx := s.current
	idx.wg.Add(1)
	s.mu.Unlock()
	return idx, sync.OnceFunc(idx.wg.Done)
}

func (s *serveState) hotSwap(next *singleIndex, onPublished func()) {
	s.mu.Lock()
	old := s.current
	s.current = next
	s.mu.Unlock()
	if onPublished != nil {
		onPublished()
	}
	if old != nil {
		old.wg.Wait()
		old.close()
	}
}

func (c *FedlibShareLiveCmd) aggregateServeParams() AggregateServeParams {
	// A descriptor-selected keys path is config-dir-relative, but both
	// params consumers (the child-rebuild --keys-file handoff and the
	// in-process FedlibBuildCmd) treat the value with explicit-flag
	// semantics, i.e. CWD-relative. Hand every consumer one absolute
	// convention (ca-132).
	keysFile := c.KeysFile
	if keysFile != "" && !filepath.IsAbs(keysFile) {
		keysFile = filepath.Join(accorderConfigDir, keysFile)
	}
	remotes := liveCacheRemoteNames(c.ActionAlias)
	return AggregateServeParams{
		CommandName:            "fedlib share live",
		RemoteName:             remotes.Books,
		AssetsRemoteName:       remotes.Assets,
		ActionAlias:            c.ActionAlias,
		AggregatePath:          c.AggregatePath,
		UploadPrefix:           c.UploadPrefix,
		Bucket:                 c.Bucket,
		KeysFile:               keysFile,
		S3AccessKey:            c.S3AccessKey,
		S3SecretKey:            c.S3SecretKey,
		S3Provider:             c.S3Provider,
		S3Endpoint:             c.S3Endpoint,
		CacheSize:              c.CacheSize,
		CacheSizeAssets:        c.CacheSizeAssets,
		CacheMaxAge:            c.CacheMaxAge,
		CacheMinFree:           c.CacheMinFree,
		DirCacheTime:           c.DirCacheTime,
		RcloneLogLevel:         c.RcloneLogLevel,
		PollInterval:           c.PollInterval,
		MeterWindow:            c.MeterWindow,
		MeterMaxSessions:       c.MeterMaxSessions,
		MeterBucketGranularity: c.MeterBucketGranularity,
		MeterMaxDistinct:       c.MeterMaxDistinct,
		EgressMonthlyAllowance: c.EgressMonthlyAllowance,
		EgressBudgetUSD:        c.EgressBudgetUSD,
		EgressPricePerGB:       c.EgressPricePerGB,
		EgressLimit:            c.EgressLimit,
		EgressBurst:            c.EgressBurst,
		AllowFullRebuild:       c.AllowFullRebuild,
	}
}

func (c *FedlibShareLiveCmd) ResolvedMode() string {
	if c.Mode == "" {
		return "public"
	}
	return c.Mode
}

func (c *FedlibShareLiveCmd) ResolveEffective() []FieldIssue {
	issues := c.descriptorPreflight()
	issues = append(issues, c.completeAggregatePath()...)
	issues = append(issues, c.fillCredentials()...)
	return issues
}

func (c *FedlibShareLiveCmd) descriptorPreflight() []FieldIssue {
	var issues []FieldIssue
	prov := c.provenanceTable()
	self := reflect.ValueOf(c).Elem()

	desc, err := requireFedlibDescriptor("fedlib share live", c.ActionAlias)
	if err != nil {
		return append(issues, FieldIssue{
			FieldPtr: fieldAddr(self, "Bucket"),
			Message:  "unresolved: " + err.Error(),
			Blocking: true,
		})
	}
	c.descriptor = &desc

	for _, f := range []struct {
		name   string
		target *string
		source string
	}{
		{"Bucket", &c.Bucket, desc.Bucket},
		{"UploadPrefix", &c.UploadPrefix, desc.UploadPrefix},
		{"S3Provider", &c.S3Provider, desc.S3Provider},
		{"S3Endpoint", &c.S3Endpoint, desc.S3Endpoint},
		{"KeysFile", &c.KeysFile, desc.KeysFile},
	} {
		*f.target = f.source
		prov.StampField(self, f.name, OriginDescriptor, "fedlibs.json:"+c.ActionAlias)
	}

	if desc.Mode != "" {
		switch desc.Mode {
		case "public", "offline-private", "private":
			if c.Mode != "" && c.Mode != desc.Mode {
				issues = append(issues, FieldIssue{
					FieldPtr: fieldAddr(self, "Mode"),
					Message: fmt.Sprintf("--mode=%s conflicts with descriptor mode %q (drop --mode or change it via 'fedlib config set %s --mode ...')",
						c.Mode, desc.Mode, c.ActionAlias),
					Blocking: true,
				})
			}

			c.Mode = desc.Mode
			prov.StampField(self, "Mode", OriginDescriptor, "fedlibs.json:"+c.ActionAlias+".mode")
		default:
			issues = append(issues, FieldIssue{
				FieldPtr: fieldAddr(self, "Mode"),
				Message: fmt.Sprintf("descriptor for fedlib %q has invalid mode %q (want public, offline-private, or private)",
					c.ActionAlias, desc.Mode),
				Blocking: true,
			})
		}
	}
	if c.Mode == "" {
		c.Mode = c.ResolvedMode()
		prov.StampField(self, "Mode", OriginDerived, "default when unset")
	}
	return issues
}

func (c *FedlibShareLiveCmd) completeAggregatePath() []FieldIssue {
	self := reflect.ValueOf(c).Elem()
	if c.AggregatePath == "" && c.descriptor != nil {
		c.AggregatePath = c.descriptor.FedlibPath
		if c.AggregatePath != "" {
			c.provenanceTable().StampField(self, "AggregatePath", OriginDescriptor, "fedlibs.json:"+c.ActionAlias+".fedlib_path")
		}
	}
	if c.AggregatePath == "" {
		return []FieldIssue{{
			FieldPtr: fieldAddr(self, "AggregatePath"),
			Message: fmt.Sprintf("--aggregate-path is required (or set fedlib-path in the descriptor: 'fedlib config set %s --fedlib-path ...')",
				c.ActionAlias),
			Blocking: true,
		}}
	}
	return nil
}

func (c *FedlibShareLiveCmd) fillCredentials() []FieldIssue {
	var issues []FieldIssue
	prov := c.provenanceTable()
	self := reflect.ValueOf(c).Elem()

	for _, e := range []struct{ field, env string }{
		{"S3AccessKey", "S3_ACCESS_KEY"},
		{"S3SecretKey", "S3_SECRET_KEY"},
	} {
		if fieldStringValue(self, e.field) == "" {
			if v := os.Getenv(e.env); v != "" {
				setFieldString(self, e.field, v)
				prov.StampField(self, e.field, OriginEnv, e.env)
			}
		}
	}

	if c.S3AccessKey == "" || c.S3SecretKey == "" {
		kfPath := c.KeysFile
		descriptorSelected := kfPath != ""
		if kfPath == "" {
			kfPath = defaultKeysFilePath(c.ActionAlias)
		}
		if !filepath.IsAbs(kfPath) {
			kfPath = filepath.Join(accorderConfigDir, kfPath)
		}
		if kf, err := parseKeysFile(kfPath); err == nil {
			if c.S3AccessKey == "" && kf.AccessKey != "" {
				c.S3AccessKey = kf.AccessKey
				prov.StampField(self, "S3AccessKey", OriginKeysFile, kfPath)
			}
			if c.S3SecretKey == "" && kf.SecretKey != "" {
				c.S3SecretKey = kf.SecretKey
				prov.StampField(self, "S3SecretKey", OriginKeysFile, kfPath)
			}
		} else if descriptorSelected {

			issues = append(issues, FieldIssue{
				FieldPtr: fieldAddr(self, "S3AccessKey"),
				Message:  "keys-file unreadable: " + kfPath,
			})
		}
	}

	if c.S3AccessKey == "" || c.S3SecretKey == "" {
		resolveS3CredsFromSecretsStore(reflect.ValueOf(c), c.ActionAlias, false,
			&resolveCtx{prov: prov, readOnly: true, credentialOnly: true})
	}
	return issues
}

func (c *FedlibShareLiveCmd) ShowConfigDerived() []DerivedField {
	self := reflect.ValueOf(c).Elem()
	out := []DerivedField{}
	for _, f := range []struct{ name, display, value string }{
		{"Bucket", "bucket", c.Bucket},
		{"UploadPrefix", "upload-prefix", c.UploadPrefix},
		{"S3Provider", "s3-provider", c.S3Provider},
		{"S3Endpoint", "s3-endpoint", c.S3Endpoint},
		{"KeysFile", "keys-file", c.KeysFile},
	} {
		out = append(out, DerivedField{
			Name:  f.display,
			Value: f.value,
			Addr:  fieldAddr(self, f.name),
		})
	}
	return out
}

func (c *FedlibShareLiveCmd) Run() error {
	if c.HandleShowConfig(c) {
		return nil
	}

	if c.OnlyTor && c.OnlyHTTP {
		return fmt.Errorf("fedlib share live: --only-tor and --only-http are mutually exclusive")
	}

	if !c.prepared {
		if err := blockingIssueError("fedlib share live", c.ResolveEffective()); err != nil {
			return err
		}
	}
	desc := *c.descriptor

	registryPath := ""
	if desc.FedlibPath != "" {
		registryPath = filepath.Join(desc.FedlibPath, "members.json")
	}

	hasRclone, localMembers, err := scanMembersForServe(c.AggregatePath, registryPath)
	if err != nil {
		return fmt.Errorf("fedlib share live: read members registry: %w", err)
	}
	if hasRclone {
		if err := c.RequireS3Creds(); err != nil {
			return fmt.Errorf("fedlib share live: %w", err)
		}
	}

	params := c.aggregateServeParams()
	params.HasRcloneMembers = hasRclone
	params.LocalMembers = localMembers
	mode := c.ResolvedMode()
	params.Mode = mode

	if !c.OnlyTor {
		params.AuthStateDir = filepath.Join(accorderConfigDir, "clearnet", c.ActionAlias)
	}
	params.InviteOffersDir = filepath.Join(accorderConfigDir, "clearnet", c.ActionAlias, "invites")
	params.RegistryPath = registryPath

	ln, err := net.Listen("tcp", c.Listen)
	if err != nil {
		return fmt.Errorf("fedlib share live: listen %s: %w", c.Listen, err)
	}

	var res *AggregateServeResources
	defer func() {
		if res != nil {
			res.Cleanup()
		}
	}()

	if c.PprofListen != "" {
		if err := startPprofListener(c.PprofListen); err != nil {
			return fmt.Errorf("fedlib share live: %w", err)
		}
	}

	var pollerWG sync.WaitGroup
	var backgroundWG sync.WaitGroup

	if !c.OnlyHTTP && startTorFn != nil {
		if err := reconcileTorPublicAuthState(filepath.Join(accorderConfigDir, "tor", c.ActionAlias), mode); err != nil {
			return fmt.Errorf("fedlib share live: %w", err)
		}
	}
	serveOpts := ServeOptions{
		CommandName:    "fedlib share live",
		ServiceName:    "the aggregator",
		OnlyTor:        c.OnlyTor,
		OnlyHTTP:       c.OnlyHTTP,
		TorAlias:       c.ActionAlias,
		StartTorFn:     startTorFn,
		StartDualTorFn: startDualTorFn,

		WarmUp: func(_ context.Context) (*http.ServeMux, *http.ServeMux, error) {
			r, werr := setupAggregateServe(params)
			if werr != nil {
				return nil, nil, werr
			}
			res = r
			return r.Mux, r.BrowserMux, nil
		},
		PreServe: func(ctx context.Context) {
			if c.PollInterval > 0 && (hasRclone || calibre.HasPeerMembers(res.Registry)) {
				pollerWG.Add(1)
				go func() {
					defer pollerWG.Done()
					pollAggregateGeneration(ctx, res.BucketFS, res.VFS, c.UploadPrefix, c.AggregatePath, res.CacheDir, res.State,
						res.RegistryPrefixes, time.Duration(c.PollInterval)*time.Second,
						&params, res.Registry, res.RegistryPath, res.Lease)
				}()
			}
			backgroundWG.Add(1)
			go func() {
				defer backgroundWG.Done()
				res.Meter.startSweep(ctx)
			}()
			if res.Breaker != nil {
				backgroundWG.Add(1)
				go func() {
					defer backgroundWG.Done()
					res.Breaker.pollLoop(ctx, 30*time.Second)
				}()
				log.Printf("fedlib share live: egress breaker enabled (sustained=%.0f bytes/s, burst=%.0f bytes)",
					res.Breaker.sustainedRate, res.Breaker.bucketCapacity)
			}
		},
		OnShutdown: func() {
			runShutdownStep("fedlib share live", "member-poller-stop", pollerWG.Wait)
			runShutdownStep("fedlib share live", "meter-breaker-stop", backgroundWG.Wait)
		},
	}
	if mode == "offline-private" && startDualTorFn != nil {
		serveOpts.DualOnionCfg = &DualOnionConfig{
			BrowserPublic: true,
			IndexPublic:   false,
		}
	}

	return serveHTTPWithTransport(ln, nil, serveOpts)
}

var aggregateFiles = []struct {
	remote string
	local  string
}{
	{"/static/library_index.zst", "library_index.zst"},
	{"/_GENERATION", "_GENERATION"},
}

func fetchAggregateVersion(bucketFS, prefix, localDir string) (string, error) {
	if err := os.MkdirAll(localDir, 0o755); err != nil {
		return "", fmt.Errorf("fetchAggregateVersion: mkdir %s: %w", localDir, err)
	}

	if cur := currentVersionPath(localDir); cur != "" {
		if aggregateVersionCurrent(bucketFS, prefix, localDir, cur) {
			log.Printf("fedlib share live: local aggregate matches remote generation — skipping re-download")
			return cur, nil
		}
	}

	versionDir, err := os.MkdirTemp(localDir, "v-")
	if err != nil {
		return "", fmt.Errorf("fetchAggregateVersion: mkdtemp: %w", err)
	}
	for _, p := range aggregateFiles {
		if err := rclonexfer.CopyFile(bucketFS, prefix+p.remote, versionDir, p.local); err != nil {
			_ = os.RemoveAll(versionDir)
			return "", fmt.Errorf("fetchAggregateVersion: fetch %s: %w", prefix+p.remote, err)
		}
	}
	if err := rclonexfer.CopyFile(bucketFS, prefix+"/_IDENTITY", versionDir, "_IDENTITY"); err != nil {
		log.Printf("fetchAggregateVersion: _IDENTITY not available (old aggregate?): %v", err)
	}
	if err := rclonexfer.CopyFile(bucketFS, prefix+"/static/library_index.manifest.json", versionDir, "library_index.manifest.json"); err != nil {
		log.Printf("fetchAggregateVersion: pointer file not available (old aggregate?): %v", err)
	}
	if err := rclonexfer.CopyFile(bucketFS, prefix+"/static/library_index.jsonl.zst", versionDir, "library_index.jsonl.zst"); err != nil {
		log.Printf("fetchAggregateVersion: jsonl.zst not available (non-fatal): %v", err)
	}
	return versionDir, nil
}

func aggregateVersionCurrent(bucketFS, prefix, localDir, curDir string) bool {
	if _, err := os.Stat(filepath.Join(curDir, "library_index.zst")); err != nil {
		return false
	}
	if v, err := calibre.ReadContainerVersion(filepath.Join(curDir, "library_index")); err != nil || v != calibre.CurrentContainerVersion {
		log.Printf("fedlib share live: cached aggregate is container v%d (this binary uses v%d) — re-downloading", v, calibre.CurrentContainerVersion)
		return false
	}
	localToken, err := readAggregateGenerationToken(curDir)
	if err != nil {
		return false
	}
	localBase, localGen := localToken.parts()

	probe, err := os.MkdirTemp(localDir, "gen-")
	if err != nil {
		return false
	}
	defer os.RemoveAll(probe)
	if err := rclonexfer.CopyFile(bucketFS, prefix+"/_GENERATION", probe, "_GENERATION"); err != nil {
		return false
	}
	remoteBytes, err := os.ReadFile(filepath.Join(probe, "_GENERATION"))
	if err != nil {
		return false
	}
	remoteBase, remoteGen, err := torshare.DecodeGeneration(remoteBytes)
	if err != nil {
		return false
	}
	return localBase == remoteBase && localGen == remoteGen
}

func commitVersion(localDir, versionDir string) (oldVersionDir string, err error) {
	cur := filepath.Join(localDir, "current")
	if t, lerr := os.Readlink(cur); lerr == nil {
		oldVersionDir = t
		if !filepath.IsAbs(oldVersionDir) {
			oldVersionDir = filepath.Join(localDir, oldVersionDir)
		}
	}

	target := filepath.Base(versionDir)
	tmpLink := filepath.Join(localDir, "current.tmp")
	_ = os.Remove(tmpLink)
	if err := os.Symlink(target, tmpLink); err != nil {
		return "", fmt.Errorf("commitVersion: symlink: %w", err)
	}
	if err := os.Rename(tmpLink, cur); err != nil {
		_ = os.Remove(tmpLink)
		return "", fmt.Errorf("commitVersion: rename current: %w", err)
	}
	return oldVersionDir, nil
}

func pruneVersion(path string) {
	if path == "" {
		return
	}
	if err := os.RemoveAll(path); err != nil {
		log.Printf("fedlib share live: prune old version %s: %v", path, err)
	}
}

func reapStaleVersions(localDir string) {
	keep := ""
	if t, err := os.Readlink(filepath.Join(localDir, "current")); err == nil {
		keep = filepath.Base(t)
	}
	entries, err := os.ReadDir(localDir)
	if err != nil {
		return
	}
	for _, e := range entries {
		n := e.Name()
		if !e.IsDir() || n == keep {
			continue
		}
		if strings.HasPrefix(n, "v-") || strings.HasPrefix(n, "gen-") {
			if err := os.RemoveAll(filepath.Join(localDir, n)); err != nil {
				log.Printf("fedlib share live: reap version %s: %v", n, err)
			}
		}
	}
}

func reapStaleProbes(cacheDir string) {
	entries, err := os.ReadDir(cacheDir)
	if err != nil {
		return
	}
	for _, e := range entries {
		if e.IsDir() && strings.HasPrefix(e.Name(), "gen-probe-") {
			_ = os.RemoveAll(filepath.Join(cacheDir, e.Name()))
		}
	}
}

func currentVersionPath(localDir string) string {
	cur := filepath.Join(localDir, "current")
	t, err := os.Readlink(cur)
	if err != nil {
		return ""
	}
	if !filepath.IsAbs(t) {
		t = filepath.Join(localDir, t)
	}
	return t
}

func openLeasedTypeahead(opened *calibre.OpenedSearch, cacheDir string, lease *serveLease) (calibre.TypeaheadIndex, string, error) {
	if lease == nil {
		ta, err := opened.Typeahead(cacheDir)
		if err != nil {
			log.Printf("fedlib share live: typeahead unavailable: %v", err)
			return nil, "", nil
		}
		return ta, "", nil
	}
	m := opened.Manifest()
	expected := calibre.TypeaheadCacheName(m.BaseGeneration, m.Generation)
	var ta calibre.TypeaheadIndex
	var dictName string
	err := withGCLock(func() error {
		if perr := lease.setPendingLocked(expected); perr != nil {
			return fmt.Errorf("lease pending publication: %w", perr)
		}
		var info calibre.TypeaheadCacheInfo
		var terr error
		ta, info, terr = opened.TypeaheadDetailed(cacheDir)
		if terr != nil {
			log.Printf("fedlib share live: typeahead unavailable: %v", terr)
			ta = nil
			return lease.clearPendingLocked()
		}
		if info.Path == "" {
			return lease.clearPendingLocked()
		}
		if aerr := appendLedgerRecord(ledgerRecord{
			Type: "dict-write", DictFile: filepath.Base(info.Path),
			Adopted: !info.Created, Cmd: "serve",
		}); aerr != nil {
			if ta != nil {
				ta.Close()
				ta = nil
			}
			_ = lease.clearPendingLocked()
			return fmt.Errorf("dict ledger registration: %w", aerr)
		}

		dictName = filepath.Base(info.Path)
		return nil
	})
	if err != nil {
		return nil, "", err
	}
	return ta, dictName, nil
}

func openSingleIndex(versionDir, cacheDir string, registryPrefixes map[string]string, lease *serveLease) (*singleIndex, error) {
	indexPath := filepath.Join(versionDir, "library_index")
	ms := &calibre.MotwSearch{IndexPath: indexPath}
	opened, err := ms.Open()
	if err != nil {
		return nil, fmt.Errorf("open MWSC: %w", err)
	}

	token, err := readAggregateGenerationToken(versionDir)
	if err != nil {
		_ = opened.Close()
		return nil, fmt.Errorf("read _GENERATION: %w", err)
	}
	base, gen := token.parts()

	ta, dictName, err := openLeasedTypeahead(opened, cacheDir, lease)
	if err != nil {

		_ = opened.Close()
		return nil, err
	}

	committed := false
	defer func() {
		if lease != nil && dictName != "" && !committed {
			_ = withGCLock(lease.clearPendingLocked)
		}
	}()

	libraries, err := opened.LibraryMetadata(context.Background())
	if err != nil {
		_ = opened.Close()
		return nil, fmt.Errorf("derive library metadata: %w", err)
	}
	if libraries == nil {
		libraries = make(map[string]calibre.LibraryMeta)
	}

	for uuid, meta := range libraries {
		if meta.Prefix == "" {
			if rp, ok := registryPrefixes[uuid]; ok && rp != "" {
				meta.Prefix = rp
				libraries[uuid] = meta
				log.Printf("fedlib share live: using registry prefix %q for UUID %s (index BaseURL empty)", rp, uuid)
			}
		}
	}

	librarians := make(map[string]string, len(libraries))
	for uuid, m := range libraries {
		librarians[uuid] = m.Librarian
	}

	books, total, err := opened.PageBooks(context.Background(), 0, 24)
	if err != nil {
		log.Printf("fedlib share live: data1.js synthesis: %v (data1.js will be empty)", err)
		books = []*calibre.Book{}
		total = 0
	}
	d1 := calibre.DataJS{Portable: false, Total: total, Books: books}
	j1, _ := json.Marshal(&d1)
	data1JS := append([]byte("CALIBRE_BOOKS1="), j1...)

	if lease != nil && dictName != "" {
		if err := withGCLock(func() error { return lease.commitPendingLocked(dictName) }); err != nil {
			if ta != nil {
				ta.Close()
			}
			_ = opened.Close()
			return nil, fmt.Errorf("lease commit: %w", err)
		}
	}
	committed = true

	return &singleIndex{
		search:     opened,
		typeahead:  ta,
		libraries:  libraries,
		librarians: librarians,
		baseGen:    base,
		gen:        gen,
		versionDir: versionDir,
		data1JS:    data1JS,
	}, nil
}

func pollAggregateGeneration(ctx context.Context, bucketFS string, vfs aggregateVFSResources, prefix, localDir, cacheDir string,
	state *serveState, registryPrefixes map[string]string, interval time.Duration,
	serveParams *AggregateServeParams, fullRegistry map[string]calibre.LibraryMeta, registryPath string,
	lease *serveLease) {
	reapStaleProbes(cacheDir)
	reapStaleVersions(localDir)
	if cur, release := state.snapshot(); cur != nil {
		reapStaleDicts(cacheDir)
		release()
	} else {
		release()
	}
	probeDir, err := os.MkdirTemp(cacheDir, "gen-probe-*")
	if err != nil {
		log.Printf("fedlib share live: poll setup: %v", err)
		return
	}
	defer os.RemoveAll(probeDir)

	var mpc *memberPollContext
	if fullRegistry != nil && serveParams != nil {
		initialPollSet := buildMemberPollSet(fullRegistry)
		mpc = &memberPollContext{
			pollSet:          initialPollSet,
			registryPrefixes: registryPrefixes,
			registryPath:     registryPath,
			lastKnownGen:     make(map[string][24]byte),
			lastMemberDigest: computeMemberDigest(initialPollSet),
			healthState:      make(map[string]*memberHealth),
		}
		if len(mpc.pollSet) > 0 {
			log.Printf("fedlib share live: member poller tracking %d member(s)", len(mpc.pollSet))
		}
	}
	invalidator := newAggregateVFSInvalidator(vfs)
	var publicationIntent aggregatePublicationIntent

	t := time.NewTicker(interval)
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
		}
		invalidator.retry()

		if mpc != nil {
			mpc.refreshPollSet()
		}
		if mpc != nil && len(mpc.pollSet) > 0 {
			memberChanged, changedUUIDs := pollMemberGenerations(ctx, bucketFS, probeDir, mpc)
			if memberChanged || mpc.membershipChanged {
				capturedUUIDs := changedUUIDs
				capturedTransitions := mpc.observedTransitions(changedUUIDs)
				capturedMembershipChanged := mpc.membershipChanged
				capturedScope := publicationScope(capturedMembershipChanged, mpc.lastTickChanges)
				capturedResidualScope := residualPublicationScope(mpc.lastTickChanges, mpc.registryPrefixes, capturedTransitions)
				mpc.membershipChanged = false
				ran := runGuardedRebuild(func() {
					if capturedMembershipChanged {
						log.Printf("fedlib share live: membership change detected; spawning full aggregate rebuild")
					} else {
						log.Printf("fedlib share live: member change detected (%v); spawning aggregate rebuild child", capturedUUIDs)
					}
					spawned, err := runSubprocessBuildWithChanges(ctx, *serveParams, capturedMembershipChanged, capturedTransitions...)
					if !spawned {
						log.Printf("fedlib share live: %v; falling back to in-process rebuild", err)
						err = runInProcessBuild(*serveParams, bucketFS, capturedTransitions...)
					}
					if err != nil {
						mpc.rollback(capturedMembershipChanged)
						log.Printf("fedlib share live: aggregate rebuild failed (will retry next tick): %v", err)
					} else {
						if token, tokenErr := readAggregateGenerationToken(localDir); tokenErr != nil {
							publicationIntent.record(aggregateGenerationToken{}, fullAggregateInvalidation())
							log.Printf("fedlib share live: bind aggregate invalidation scope: %v; next generation will use full scope", tokenErr)
						} else {
							scope := capturedScope
							if !capturedMembershipChanged {
								if derived, incorporated, reportErr := readAggregateChangeScope(localDir, token, capturedTransitions); reportErr != nil {
									log.Printf("fedlib share live: targeted cache-refresh plan unavailable; refreshing the changed member's whole library: %v", reportErr)
								} else {
									scope = derived.merge(capturedResidualScope)
									for prefix, generation := range incorporated {
										mpc.lastKnownGen[prefix] = generation
									}
								}
							}
							publicationIntent.record(token, scope)
						}
						log.Printf("fedlib share live: aggregate rebuild + upload complete")
					}
				})
				if !ran {
					mpc.rollback(capturedMembershipChanged)
					log.Printf("fedlib share live: aggregate rebuild already in flight; will retry next tick")
				}
			}
		}

		if err := rclonexfer.CopyFile(bucketFS, prefix+"/_GENERATION", probeDir, "_GENERATION"); err != nil {
			log.Printf("fedlib share live: probe _GENERATION: %v", err)
			continue
		}
		genBytes, err := os.ReadFile(filepath.Join(probeDir, "_GENERATION"))
		if err != nil {
			log.Printf("fedlib share live: read probe: %v", err)
			continue
		}
		remoteToken, err := decodeAggregateGenerationToken(genBytes)
		if err != nil {
			log.Printf("fedlib share live: decode probe: %v", err)
			continue
		}
		remoteBase, remoteGen := remoteToken.parts()
		cur, release := state.snapshot()
		same := cur != nil && cur.baseGen == remoteBase && cur.gen == remoteGen
		release()
		if same {
			continue
		}
		log.Printf("fedlib share live: detected new generation (gen=%d); staging + swapping", remoteGen)
		nextVersionDir, err := fetchAggregateVersion(bucketFS, prefix, localDir)
		if err != nil {
			log.Printf("fedlib share live: refetch: %v", err)
			continue
		}
		next, err := openSingleIndex(nextVersionDir, cacheDir, registryPrefixes, lease)
		if err != nil {
			log.Printf("fedlib share live: reopen: %v", err)
			_ = os.RemoveAll(nextVersionDir)
			continue
		}
		if err := ctx.Err(); err != nil {
			_ = next.search.Close()
			_ = os.RemoveAll(nextVersionDir)
			return
		}
		oldVersionDir, err := commitVersion(localDir, nextVersionDir)
		if err != nil {
			log.Printf("fedlib share live: commit: %v", err)
			_ = next.search.Close()
			_ = os.RemoveAll(nextVersionDir)
			continue
		}
		// Consume the bound scope only now: every earlier failure path retries
		// this same generation next tick, and consuming before commit would
		// have downgraded that retry to a full forget.
		invalidationScope := publicationIntent.consume(remoteToken)
		state.hotSwap(next, func() {
			invalidator.invalidate(invalidationScope)
		})
		if oldVersionDir != "" && oldVersionDir != nextVersionDir {
			pruneVersion(oldVersionDir)
		}
		reapStaleVersions(localDir)
		reapStaleDicts(cacheDir)
		mf := next.search.Manifest()
		log.Printf("fedlib share live: hot-swap complete (%d books, gen=%d)", mf.NumBooks, next.gen)
	}
}

func browserPlaneWrap(authReg *grantRegistry, mode string) func(http.Handler) http.Handler {
	if authReg != nil && mode == "private" {
		return func(h http.Handler) http.Handler { return withAuth(h, authReg) }
	}
	return nil
}

func applyWrap(wrap func(http.Handler) http.Handler, h http.Handler) http.Handler {
	if wrap == nil {
		return h
	}
	return wrap(h)
}

func registerAggregateRoutes(mux *http.ServeMux, state *serveState, vfsAddrs aggregateVFSAddresses, meter *sessionMeter, breaker *egressBreaker, authReg *grantRegistry, mode string, inviteOffersDir string, peerTable *peerEndpointTable, browserOnly bool, registryPath ...string) {

	catalogWrap := browserPlaneWrap(authReg, mode)
	catalog := func(pattern string, h http.HandlerFunc) {
		mux.Handle(pattern, applyWrap(catalogWrap, h))
	}
	catalog("/info", makeInfoHandler(state))
	catalog("/librarians", makeLibrariansHandler(state, false))
	catalog("/librarians/", makeLibrariansHandler(state, true))
	catalog("/search", makeSearchHandler(state))
	catalog("/search/", makeSearchEVEHandler(state))
	catalog("/books", makeBooksHandler(state))
	catalog("/books/", makeBooksEVEHandler(state))
	catalog("/book/", makeBookHandler(state))
	catalog("/autocomplete/", makeAutocompleteHandler(state))

	if !browserOnly {
		indexZstHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			idx, release := state.snapshot()
			defer release()
			http.ServeFile(w, r, filepath.Join(idx.versionDir, "library_index.zst"))
		})
		generationHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			idx, release := state.snapshot()
			defer release()
			http.ServeFile(w, r, filepath.Join(idx.versionDir, "_GENERATION"))
		})
		identityHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			idx, release := state.snapshot()
			defer release()
			http.ServeFile(w, r, filepath.Join(idx.versionDir, "_IDENTITY"))
		})
		manifestHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			idx, release := state.snapshot()
			defer release()
			http.ServeFile(w, r, filepath.Join(idx.versionDir, "library_index.manifest.json"))
		})
		jsonlZstHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			idx, release := state.snapshot()
			defer release()
			p := filepath.Join(idx.versionDir, "library_index.jsonl.zst")
			if _, err := os.Stat(p); err != nil {
				http.NotFound(w, r)
				return
			}
			http.ServeFile(w, r, p)
		})
		if authReg != nil && (mode == "offline-private" || mode == "private") {
			mux.Handle("/static/library_index.zst", withAuth(indexZstHandler, authReg))
			mux.Handle("/static/library_index.jsonl.zst", withAuth(jsonlZstHandler, authReg))
			mux.Handle("/static/library_index.manifest.json", withAuth(manifestHandler, authReg))
			mux.Handle("/_GENERATION", withAuth(generationHandler, authReg))
			mux.Handle("/_IDENTITY", withAuth(identityHandler, authReg))
		} else {
			mux.Handle("/static/library_index.zst", indexZstHandler)
			mux.Handle("/static/library_index.jsonl.zst", jsonlZstHandler)
			mux.Handle("/static/library_index.manifest.json", manifestHandler)
			mux.Handle("/_GENERATION", generationHandler)
			mux.Handle("/_IDENTITY", identityHandler)
		}
		if inviteOffersDir != "" {
			limiter := newIPRateLimiter(5, 2*time.Second)
			mux.Handle("/invite/", makeInviteHandler(inviteOffersDir, limiter, registryPath...))
		}
	}
	catalog("/static/data1.js", func(w http.ResponseWriter, r *http.Request) {
		idx, release := state.snapshot()
		defer release()
		etag := fmt.Sprintf(`"data1-%s"`, catalogVersion(idx))
		if ifNoneMatch(w, r, etag) {
			return
		}
		w.Header().Set("Content-Type", "application/javascript")
		w.Header().Set("Cache-Control", "public, max-age=60")
		w.Write(idx.data1JS)
	})

	if authReg != nil {
		mux.HandleFunc("/redeem", makeRedeemHandler(authReg))
	}

	if vfsAddrs.Books != "" || vfsAddrs.Assets != "" || peerTable != nil {
		newFileProxy := func(addr string) *httputil.ReverseProxy {
			if addr == "" {
				return nil
			}
			vfsURL, _ := url.Parse("http://" + addr)
			proxy := httputil.NewSingleHostReverseProxy(vfsURL)
			proxy.ModifyResponse = func(resp *http.Response) error {
				ct := resp.Header.Get("Content-Type")
				if !strings.Contains(ct, "xml") {
					return nil
				}
				body, err := io.ReadAll(resp.Body)
				if err != nil {
					return err
				}
				_ = resp.Body.Close()
				rewritten := bytes.ReplaceAll(body, []byte("<D:href>/"), []byte("<D:href>/files/"))
				resp.Body = io.NopCloser(bytes.NewReader(rewritten))
				resp.ContentLength = int64(len(rewritten))
				resp.Header.Set("Content-Length", strconv.Itoa(len(rewritten)))
				return nil
			}
			return proxy
		}
		booksProxy := newFileProxy(vfsAddrs.Books)
		assetsProxy := newFileProxy(vfsAddrs.Assets)
		filesHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			cleaned := path.Clean(strings.TrimPrefix(r.URL.Path, "/files/"))
			if cleaned == "." || strings.HasPrefix(cleaned, "..") {
				http.NotFound(w, r)
				return
			}
			idx, release := state.snapshot()
			memberPrefix := aggregateMemberPrefix(idx.libraries, cleaned)
			release()
			if memberPrefix == "" {
				http.NotFound(w, r)
				return
			}
			if isSensitiveServePath(cleaned) {
				http.NotFound(w, r)
				return
			}
			if px := peerTable.proxyFor(memberPrefix); px != nil {
				px.ServeHTTP(w, r)
				return
			}
			// Classify against the FULL matched member prefix, not the
			// first path segment: a multi-segment prefix ("org/member")
			// would otherwise leave "member/static/..." unmatched and route
			// genuine static assets through the books pool.
			fileProxy := booksProxy
			if aggregateAssetPath(cleaned, memberPrefix) {
				fileProxy = assetsProxy
			}
			if fileProxy == nil {
				http.NotFound(w, r)
				return
			}
			r.URL.Path = "/" + cleaned
			r.URL.RawPath = ""
			fileProxy.ServeHTTP(w, r)
		})
		var filesHandlerWrapped http.Handler
		filesHandlerWrapped = withEndpointProtection(filesHandler, meter, breaker)
		if authReg != nil {
			if mode == "private" {
				filesHandlerWrapped = withAuth(filesHandlerWrapped, authReg)
			} else {
				filesHandlerWrapped = withAuthTag(filesHandlerWrapped, authReg)
			}
		}
		mux.Handle("/files/", filesHandlerWrapped)
	}
}

func aggregateMemberPrefix(libraries map[string]calibre.LibraryMeta, cleaned string) string {
	best := ""
	for _, lib := range libraries {
		prefix := lib.Prefix
		if prefix == "" || (cleaned != prefix && !strings.HasPrefix(cleaned, prefix+"/")) {
			continue
		}
		if len(prefix) > len(best) {
			best = prefix
		}
	}
	return best
}

func aggregateAssetPath(cleaned, memberPrefix string) bool {
	relative := strings.TrimPrefix(cleaned, memberPrefix)
	relative = strings.TrimPrefix(relative, "/")
	return relative == "static" || strings.HasPrefix(relative, "static/") ||
		relative == "cover.jpg" || strings.HasSuffix(relative, "/cover.jpg")
}

func catalogVersion(idx *singleIndex) string {
	h := fnv.New64a()
	fmt.Fprintf(h, "%x-%d-%d", idx.baseGen, idx.gen, len(idx.libraries))
	return strconv.FormatUint(h.Sum64(), 16)
}

func ifNoneMatch(w http.ResponseWriter, r *http.Request, etag string) bool {
	if match := r.Header.Get("If-None-Match"); match == etag {
		w.WriteHeader(http.StatusNotModified)
		return true
	}
	w.Header().Set("ETag", etag)
	return false
}

func makeInfoHandler(state *serveState) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		idx, release := state.snapshot()
		defer release()
		mf := idx.search.Manifest()
		etag := `"` + catalogVersion(idx) + `"`
		if ifNoneMatch(w, r, etag) {
			return
		}
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Cache-Control", "public, max-age=60")
		_ = json.NewEncoder(w).Encode(map[string]any{
			"num_books":    mf.NumBooks,
			"num_segments": mf.NumSegments,
			"num_regions":  len(mf.Regions),
			"libraries":    len(idx.libraries),
			"generation":   idx.gen,
		})
	}
}

func makeLibrariansHandler(state *serveState, hasSlash bool) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		idx, release := state.snapshot()
		defer release()
		etag := `"librarians-` + catalogVersion(idx) + `"`
		if ifNoneMatch(w, r, etag) {
			return
		}
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Cache-Control", "public, max-age=60")
		type libInfo struct {
			UUID      string `json:"uuid"`
			Librarian string `json:"librarian"`
		}
		libs := make([]libInfo, 0, len(idx.librarians))
		for uuid, name := range idx.librarians {
			libs = append(libs, libInfo{UUID: uuid, Librarian: name})
		}
		sort.Slice(libs, func(i, j int) bool { return libs[i].Librarian < libs[j].Librarian })
		if hasSlash {
			names := make([]string, len(libs))
			for i, l := range libs {
				names[i] = l.Librarian
			}
			_ = json.NewEncoder(w).Encode(struct {
				Items []string `json:"_items"`
			}{Items: names})
			return
		}
		_ = json.NewEncoder(w).Encode(libs)
	}
}

func parseSearchParams(r *http.Request) (calibre.SearchQuery, calibre.SearchOptions, int, int, error) {
	q := r.URL.Query()
	text := q.Get("q")
	fieldStr := q.Get("field")
	if fieldStr == "" {
		fieldStr = string(calibre.FieldTitle)
	}
	field, err := calibre.ParseSearchField(calibre.PluralToSingularField(fieldStr))
	if err != nil {
		return calibre.SearchQuery{}, calibre.SearchOptions{}, 0, 0, err
	}
	mode := calibre.ModeExact
	switch strings.ToLower(q.Get("mode")) {
	case "prefix":
		mode = calibre.ModePrefix
	case "fuzzy":
		mode = calibre.ModeFuzzy
	}
	var sortMode calibre.SortMode
	if sortStr := q.Get("sort"); sortStr != "" {
		var err error
		sortMode, err = calibre.ParseSortMode(sortStr)
		if err != nil {
			return calibre.SearchQuery{}, calibre.SearchOptions{}, 0, 0, err
		}
	} else if q.Get("ranked") == "1" || strings.EqualFold(q.Get("ranked"), "true") {
		sortMode = calibre.SortRelevance
	} else {
		sortMode = calibre.SortNewest
	}
	limit, _ := strconv.Atoi(q.Get("limit"))
	offset, _ := strconv.Atoi(q.Get("offset"))
	if limit <= 0 {
		limit = calibre.EveDefaultPageSize
	}
	if offset < 0 {
		offset = 0
	}
	return calibre.SearchQuery{Text: text, Field: field, Mode: mode},
		calibre.SearchOptions{SortMode: sortMode, Limit: limit, Offset: offset},
		offset, limit, nil
}

func makeSearchHandler(state *serveState) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		idx, release := state.snapshot()
		defer release()
		sq, opts, offset, limit, err := parseSearchParams(r)
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
		etag := fmt.Sprintf(`"search-%s-%s-%s-%d-%s-%d-%d"`,
			catalogVersion(idx), sq.Field, sq.Text, sq.Mode, opts.ResolvedSortMode(), offset, limit)
		if ifNoneMatch(w, r, etag) {
			return
		}
		books, stats, err := idx.search.Search(r.Context(), sq, opts)
		if err != nil {
			log.Printf("/search: %v", err)
			http.Error(w, "search error", http.StatusInternalServerError)
			return
		}
		total := stats.BooksMatched
		page := paginate(books, offset, limit)
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Cache-Control", "public, max-age=60")
		_ = json.NewEncoder(w).Encode(calibre.EveEnvelope{
			Items: page,
			Meta:  calibre.EveMeta{Total: total, Page: (offset / limit) + 1, MaxResults: limit},
			Links: buildEveLinks("/search", offset, limit, total),
		})
	}
}

func makeSearchEVEHandler(state *serveState) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		idx, release := state.snapshot()
		defer release()
		rest := strings.TrimPrefix(r.URL.EscapedPath(), "/search/")
		parts := strings.SplitN(rest, "/", 2)
		if len(parts) < 2 {
			http.Error(w, `{"error":"expected /search/<field>/<query>"}`, http.StatusBadRequest)
			return
		}
		decoded, err := url.PathUnescape(parts[1])
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
		q := r.URL.Query()
		limit, _ := strconv.Atoi(q.Get("limit"))
		offset, _ := strconv.Atoi(q.Get("offset"))
		if limit <= 0 {
			limit = calibre.EveDefaultPageSize
		}
		if offset < 0 {
			offset = 0
		}

		fieldRaw := calibre.PluralToSingularField(parts[0])

		sortToken := "relevance"
		if fieldRaw == "librarian" {
			sortToken = "newest"
		}
		etag := fmt.Sprintf(`"searchEVE-%s-%s-%s-%s-%d-%d"`,
			catalogVersion(idx), fieldRaw, decoded, sortToken, offset, limit)
		if ifNoneMatch(w, r, etag) {
			return
		}

		var books []*calibre.Book
		var total int
		if fieldRaw == "librarian" {
			bs, err := idx.search.BooksByLibrarian(r.Context(), decoded)
			if err != nil {
				log.Printf("/search/librarian: BooksByLibrarian(%s): %v", decoded, err)
				http.Error(w, "search error", http.StatusInternalServerError)
				return
			}
			sort.Sort(sort.Reverse(calibre.CalibreBooksByLastModified(bs)))
			books = bs
			total = len(books)
		} else {
			field, err := calibre.ParseSearchField(fieldRaw)
			if err != nil {
				http.Error(w, err.Error(), http.StatusBadRequest)
				return
			}
			sq := calibre.SearchQuery{Text: decoded, Field: field, Mode: calibre.ModeExact}
			var stats calibre.SearchStats
			books, stats, err = idx.search.Search(r.Context(), sq,
				calibre.SearchOptions{SortMode: calibre.SortRelevance, Limit: limit, Offset: offset})
			if err != nil {
				log.Printf("/search/: %v", err)
				http.Error(w, "search error", http.StatusInternalServerError)
				return
			}
			total = stats.BooksMatched
		}

		page := paginate(books, offset, limit)
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Cache-Control", "public, max-age=60")
		_ = json.NewEncoder(w).Encode(calibre.EveEnvelope{
			Items: page,
			Meta:  calibre.EveMeta{Total: total, Page: (offset / limit) + 1, MaxResults: limit},
			Links: buildEveLinks("/search/"+parts[0]+"/"+parts[1], offset, limit, total),
		})
	}
}

func makeBooksHandler(state *serveState) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		idx, release := state.snapshot()
		defer release()
		q := r.URL.Query()
		limit, _ := strconv.Atoi(q.Get("limit"))
		offset, _ := strconv.Atoi(q.Get("offset"))
		if limit <= 0 {
			limit = calibre.EveDefaultPageSize
		}
		if offset < 0 {
			offset = 0
		}
		etag := fmt.Sprintf(`"books-%s-%d-%d"`, catalogVersion(idx), offset, limit)
		if ifNoneMatch(w, r, etag) {
			return
		}
		books, total, err := idx.search.PageBooks(r.Context(), offset, limit)
		if err != nil {
			log.Printf("/books: %v", err)
			http.Error(w, "books error", http.StatusInternalServerError)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Cache-Control", "public, max-age=60")
		_ = json.NewEncoder(w).Encode(calibre.EveEnvelope{
			Items: books,
			Meta:  calibre.EveMeta{Total: total, Page: (offset / limit) + 1, MaxResults: limit},
			Links: buildEveLinks("/books", offset, limit, total),
		})
	}
}

func makeBooksEVEHandler(state *serveState) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		idx, release := state.snapshot()
		defer release()
		rest := strings.TrimPrefix(r.URL.EscapedPath(), "/books/")
		limit := calibre.EveDefaultPageSize
		offset := 0
		if strings.HasPrefix(rest, "page/") {
			n, err := strconv.Atoi(strings.TrimPrefix(rest, "page/"))
			if err == nil && n > 0 {
				offset = (n - 1) * limit
			}
		}
		books, total, err := idx.search.PageBooks(r.Context(), offset, limit)
		if err != nil {
			log.Printf("/books/: %v", err)
			http.Error(w, "books error", http.StatusInternalServerError)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(calibre.EveEnvelope{
			Items: books,
			Meta:  calibre.EveMeta{Total: total, Page: (offset / limit) + 1, MaxResults: limit},
			Links: buildEveLinks("/books", offset, limit, total),
		})
	}
}

func makeBookHandler(state *serveState) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		idx, release := state.snapshot()
		defer release()
		id := strings.TrimPrefix(r.URL.Path, "/book/")
		if id == "" {
			http.Error(w, `{"error":"missing book id"}`, http.StatusBadRequest)
			return
		}
		etag := `"book-` + catalogVersion(idx) + `-` + id + `"`
		if ifNoneMatch(w, r, etag) {
			return
		}
		book, err := idx.search.LookupByID(r.Context(), id)
		if err != nil {
			log.Printf("/book/%s: %v", id, err)
			http.Error(w, "lookup error", http.StatusInternalServerError)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Cache-Control", "public, max-age=300")
		if book == nil {
			w.WriteHeader(http.StatusNotFound)
			_ = json.NewEncoder(w).Encode(map[string]string{"error": "not found"})
			return
		}
		_ = json.NewEncoder(w).Encode(book)
	}
}

func makeAutocompleteHandler(state *serveState) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		idx, release := state.snapshot()
		defer release()
		rest := strings.TrimPrefix(r.URL.EscapedPath(), "/autocomplete/")
		parts := strings.SplitN(rest, "/", 2)
		if len(parts) < 2 {
			http.Error(w, `{"error":"expected /autocomplete/<field>/<prefix>"}`, http.StatusBadRequest)
			return
		}
		decoded, err := url.PathUnescape(parts[1])
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
		field := calibre.PluralToSingularField(parts[0])
		sf, ferr := calibre.ParseSearchField(field)
		if ferr != nil {
			http.Error(w, `{"error":"unknown field"}`, http.StatusBadRequest)
			return
		}
		limit, _ := strconv.Atoi(r.URL.Query().Get("limit"))
		if limit <= 0 {
			limit = 10
		}
		lowerPrefix := strings.ToLower(strings.TrimSpace(decoded))

		etag := fmt.Sprintf(`"ac-%s-%s-%s-%d"`, catalogVersion(idx), field, lowerPrefix, limit)
		if ifNoneMatch(w, r, etag) {
			return
		}

		ents, err := calibre.SuggestEntities(idx.typeahead, sf, lowerPrefix, limit)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		if ents == nil {
			ents = []string{}
		}
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Cache-Control", "public, max-age=60")
		_ = json.NewEncoder(w).Encode(struct {
			Items []string `json:"_items"`
		}{Items: ents})
	}
}

func paginate(books []*calibre.Book, offset, limit int) []*calibre.Book {
	if offset >= len(books) {
		return nil
	}
	end := offset + limit
	if end > len(books) {
		end = len(books)
	}
	return books[offset:end]
}

func isLoopback(addr string) bool {
	host, _, err := net.SplitHostPort(addr)
	if err != nil {
		return false
	}
	if host == "localhost" {
		return true
	}
	ip := net.ParseIP(host)
	return ip != nil && ip.IsLoopback()
}

func torLoopbackTarget(addr string) string {
	host, port, err := net.SplitHostPort(addr)
	if err != nil {
		return addr
	}
	ip := net.ParseIP(host)
	if ip == nil || ip.IsUnspecified() || !ip.IsLoopback() {
		return net.JoinHostPort("127.0.0.1", port)
	}
	return addr
}

func buildEveLinks(base string, offset, limit, total int) calibre.EveLinks {
	links := calibre.EveLinks{Self: calibre.EveLink{Href: base, Title: base}}
	if limit <= 0 {
		return links
	}
	page := (offset / limit) + 1
	if offset+limit < total {
		links.Next = &calibre.EveLink{Href: fmt.Sprintf("%s?offset=%d&limit=%d", base, offset+limit, limit), Title: "next"}
	}
	if page > 1 {
		links.Prev = &calibre.EveLink{Href: fmt.Sprintf("%s?offset=%d&limit=%d", base, (page-2)*limit, limit), Title: "prev"}
	}
	lastPage := (total + limit - 1) / limit
	if lastPage > 0 {
		links.Last = &calibre.EveLink{Href: fmt.Sprintf("%s?offset=%d&limit=%d", base, (lastPage-1)*limit, limit), Title: "last"}
	}
	return links
}
