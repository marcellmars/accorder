package cmd

import (
	"bytes"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"
)

//

type ledgerRecord struct {
	V    int    `json:"v"`
	Type string `json:"type"` // serve-start | dict-write | rename | delete
	TS   string `json:"ts"`

	Remote string `json:"remote,omitempty"`
	Root   string `json:"root,omitempty"`

	FromRemote string `json:"fromRemote,omitempty"`
	FromRoot   string `json:"fromRoot,omitempty"`
	ToRemote   string `json:"toRemote,omitempty"`
	ToRoot     string `json:"toRoot,omitempty"`

	DictFile string `json:"dictFile,omitempty"`
	Adopted  bool   `json:"adopted,omitempty"`

	Alias string `json:"alias,omitempty"`
	Cmd   string `json:"cmd,omitempty"`
}

func validRemoteName(name string) bool {
	if !strings.HasPrefix(name, "accorder-") {
		return false
	}
	if strings.ContainsAny(name, "/\\") || name == "." || name == ".." {
		return false
	}
	if strings.Contains(name, "..") {
		return false
	}
	return filepath.Base(name) == name && !filepath.IsAbs(name)
}

func validRemoteRoot(root string) bool {
	if root == "" {
		return false
	}
	if filepath.IsAbs(root) || strings.HasPrefix(root, "/") || strings.Contains(root, "\\") {
		return false
	}
	for _, seg := range strings.Split(root, "/") {
		if seg == "" || seg == "." || seg == ".." {
			return false
		}
	}
	return true
}

func validDictFile(name string) bool {
	return name != "" && filepath.Base(name) == name && !filepath.IsAbs(name) &&
		strings.HasSuffix(name, ".dict") && !strings.ContainsAny(name, "/\\")
}

func (r ledgerRecord) validate() error {
	switch r.Type {
	case "serve-start":
		if !validRemoteName(r.Remote) || !validRemoteRoot(r.Root) {
			return fmt.Errorf("ledger: invalid serve-start identity %q:%q", r.Remote, r.Root)
		}
	case "rename":
		if !validRemoteName(r.FromRemote) || !validRemoteRoot(r.FromRoot) ||
			!validRemoteName(r.ToRemote) || !validRemoteRoot(r.ToRoot) {
			return fmt.Errorf("ledger: invalid rename record %q:%q -> %q:%q", r.FromRemote, r.FromRoot, r.ToRemote, r.ToRoot)
		}
	case "delete":
		if r.DictFile != "" {
			if !validDictFile(r.DictFile) {
				return fmt.Errorf("ledger: invalid dict delete %q", r.DictFile)
			}
		} else if !validRemoteName(r.Remote) || !validRemoteRoot(r.Root) {
			return fmt.Errorf("ledger: invalid delete identity %q:%q", r.Remote, r.Root)
		}
	case "dict-write":
		if !validDictFile(r.DictFile) {
			return fmt.Errorf("ledger: invalid dict-write %q", r.DictFile)
		}
	default:
		return fmt.Errorf("ledger: unknown record type %q", r.Type)
	}
	return nil
}

func appendLedgerRecord(rec ledgerRecord) error {
	return appendLedgerRecords([]ledgerRecord{rec})
}

func appendLedgerRecords(records []ledgerRecord) error {
	if len(records) == 0 {
		return nil
	}
	now := time.Now().UTC().Format(time.RFC3339)
	lines := make([][]byte, 0, len(records))
	for i := range records {
		records[i].V = 1
		if records[i].TS == "" {
			records[i].TS = now
		}
		if err := records[i].validate(); err != nil {
			return err
		}
		line, err := json.Marshal(records[i])
		if err != nil {
			return err
		}
		lines = append(lines, line)
	}
	path := identityLedgerPath()
	if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
		return err
	}
	data, err := os.ReadFile(path)
	if err != nil {
		if !os.IsNotExist(err) {
			return err
		}
		data = nil
	}
	if len(data) > 0 && data[len(data)-1] != '\n' {
		keep := 0
		if i := bytes.LastIndexByte(data, '\n'); i >= 0 {
			keep = i + 1
		}
		data = data[:keep]
	}
	for _, line := range lines {
		data = append(data, line...)
		data = append(data, '\n')
	}
	return writeFileDurable(path, data, 0o600)
}

func readLedger() (records []ledgerRecord, malformed bool, err error) {
	data, err := os.ReadFile(identityLedgerPath())
	if err != nil {
		if os.IsNotExist(err) {
			return nil, false, nil
		}
		return nil, false, err
	}
	lines := bytes.Split(data, []byte("\n"))
	completeThrough := len(lines)
	if len(data) > 0 && data[len(data)-1] != '\n' {
		completeThrough--
	}
	for i := 0; i < completeThrough; i++ {
		line := bytes.TrimSpace(lines[i])
		if len(line) == 0 {
			continue
		}
		var rec ledgerRecord
		if uerr := json.Unmarshal(line, &rec); uerr != nil {
			return records, true, nil
		}
		if verr := rec.validate(); verr != nil {
			return records, true, nil
		}
		records = append(records, rec)
	}
	return records, false, nil
}

func identityKey(remote, root string) string { return remote + ":" + root }

type ledgerView struct {
	activeRoots map[string]map[string]bool

	knownRemotes map[string]bool

	activeDicts map[string]bool

	knownDicts map[string]bool
}

func replayLedger(records []ledgerRecord) *ledgerView {
	v := &ledgerView{
		activeRoots:  make(map[string]map[string]bool),
		knownRemotes: make(map[string]bool),
		activeDicts:  make(map[string]bool),
		knownDicts:   make(map[string]bool),
	}
	activate := func(remote, root string) {
		v.knownRemotes[remote] = true
		if v.activeRoots[remote] == nil {
			v.activeRoots[remote] = make(map[string]bool)
		}
		v.activeRoots[remote][root] = true
	}
	tombstone := func(remote, root string) {
		v.knownRemotes[remote] = true
		if v.activeRoots[remote] != nil {
			delete(v.activeRoots[remote], root)
		}
	}
	for _, r := range records {
		switch r.Type {
		case "serve-start":
			activate(r.Remote, r.Root)
		case "rename":
			tombstone(r.FromRemote, r.FromRoot)
			activate(r.ToRemote, r.ToRoot)
		case "delete":
			if r.DictFile != "" {
				v.knownDicts[r.DictFile] = true
				delete(v.activeDicts, r.DictFile)
			} else {
				tombstone(r.Remote, r.Root)
			}
		case "dict-write":
			v.knownDicts[r.DictFile] = true
			v.activeDicts[r.DictFile] = true
		}
	}
	return v
}
