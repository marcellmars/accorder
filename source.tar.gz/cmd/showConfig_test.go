//go:build !tailscale && !tor

package cmd

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// captureShowConfig and snapshotDir live in showConfigTestHelpers_test.go
// (!tailscale) so the tor-inclusive suites can use them too.

// Verification Plan §2: the flagship case. A descriptor whose mode and
// bucket differ from what the CLI supplied must render the DESCRIPTOR's
// values with descriptor provenance — this is the divergence that made
// `-s` actively misleading before (study Finding 4).
func TestShowConfig_ServeRendersDescriptorTruth(t *testing.T) {
	testSetup(t)
	seedDescriptor(t, "fed", fedlibDescriptor{
		Bucket:       "BUCKET_FROM_DESCRIPTOR",
		S3Provider:   "Wasabi",
		S3Endpoint:   "https://desc.example.com",
		UploadPrefix: "PREFIX_FROM_DESCRIPTOR",
		Mode:         "private",
		FedlibPath:   "/PATH_FROM_DESCRIPTOR",
	})

	out := captureShowConfig(t, []string{"fedlib", "share", "live", "fed",
		"--aggregate-path", "/PATH_FROM_FLAG", "--mode", "public", "-s"})

	// The command line said public; the descriptor says private and wins.
	// Before this change the view reported "public" for a serve that ran
	// private, with no way to tell.
	if !strings.Contains(out, "--mode") || !strings.Contains(out, "private") {
		t.Errorf("mode not rendered as the descriptor's value:\n%s", out)
	}
	for _, line := range strings.Split(out, "\n") {
		if strings.HasPrefix(strings.TrimSpace(line), "--mode ") {
			if !strings.Contains(line, "descriptor") {
				t.Errorf("--mode line lacks descriptor provenance: %q", line)
			}
			if strings.Contains(line, "public") {
				t.Errorf("--mode still reports the discarded flag value: %q", line)
			}
		}
	}
	// ca-125: the contradictory --mode is no longer silently discarded —
	// -s renders descriptor truth plus an explicit conflict note.
	if !strings.Contains(out, "conflicts with descriptor mode") {
		t.Errorf("-s did not annotate the --mode conflict:\n%s", out)
	}

	// The five kong:"-" storage fields are invisible to a flag walk; the
	// derived registry is what makes the serve's bucket knowable at all.
	for _, want := range []string{
		"BUCKET_FROM_DESCRIPTOR", "PREFIX_FROM_DESCRIPTOR", "https://desc.example.com",
	} {
		if !strings.Contains(out, want) {
			t.Errorf("descriptor-backed value %q missing from the view:\n%s", want, out)
		}
	}
	if !strings.Contains(out, "--aggregate-path") || !strings.Contains(out, "/PATH_FROM_FLAG") {
		t.Errorf("explicit flag not rendered:\n%s", out)
	}
	if !strings.Contains(out, "nothing was written") {
		t.Errorf("read-only contract not stated in the output:\n%s", out)
	}
}

// Verification Plan §3: -s writes nothing, on any command, including a
// config dir that does not exist yet.
func TestShowConfig_IsReadOnly(t *testing.T) {
	for _, tc := range []struct {
		name string
		args []string
	}{
		{"lib build", []string{"lib", "build", "fresh1", "-s"}},
		{"lib upload", []string{"lib", "upload", "fresh2", "-s"}},
		{"lib publish", []string{"lib", "publish", "fresh3", "-s"}},
		{"fedlib build", []string{"fedlib", "build", "fresh4", "-s"}},
		{"lib join", []string{"lib", "join", "fresh5", "-s"}},
	} {
		t.Run(tc.name, func(t *testing.T) {
			testSetup(t)
			// Start from a genuinely empty config dir: the point is that a
			// diagnostic on a fresh machine creates nothing at all.
			_ = os.Remove(savedActionAliases)
			before := snapshotDir(t, accorderConfigDir)

			captureShowConfig(t, tc.args)

			after := snapshotDir(t, accorderConfigDir)
			for p := range after {
				if _, existed := before[p]; !existed {
					t.Errorf("-s created %s", p)
				}
			}
			for p, b := range before {
				if after[p] != b {
					t.Errorf("-s modified %s", p)
				}
			}
			if _, err := os.Stat(savedActionAliases); err == nil {
				t.Errorf("-s created the alias store at %s", savedActionAliases)
			}
			if _, err := os.Stat(filepath.Join(accorderConfigDir, "keys")); err == nil {
				t.Errorf("-s created a keys directory")
			}
		})
	}
}

// Verification Plan §4: no credential value reaches the output, including
// credentials the operator never typed (resolved from a keys file).
func TestShowConfig_NeverLeaksCredentials(t *testing.T) {
	const (
		accessKey = "AKIA_NEVER_PRINT_ME"
		secretKey = "SECRET_NEVER_PRINT_ME"
		phrase    = "passphrase-never-print-me"
	)
	testSetup(t)
	keysPath := defaultKeysFilePath("leak")
	if err := writeKeysFile(keysPath, s3KeysFile{
		AccessKey: accessKey, SecretKey: secretKey,
		Provider: "Wasabi", Endpoint: "https://s3.example.com",
	}); err != nil {
		t.Fatal(err)
	}

	for _, tc := range []struct {
		name string
		args []string
	}{
		{"typed on the command line", []string{"lib", "upload", "leak",
			"--calibrepath", t.TempDir(), "--bucket", "b/p",
			"--s3-access-key", accessKey, "--s3-secret-key", secretKey,
			"--s3-provider", "W", "--s3-endpoint", "https://e",
			"--passphrase", phrase, "-s"}},
		// The dangerous form: nothing secret is typed, yet the resolvers
		// populate the fields from keys/<alias>.s3.keys before rendering.
		{"resolved from a keys file", []string{"lib", "build", "leak",
			"--calibrepath", t.TempDir(), "-s"}},
	} {
		t.Run(tc.name, func(t *testing.T) {
			out := captureShowConfig(t, tc.args)
			for _, secret := range []string{accessKey, secretKey, phrase} {
				if strings.Contains(out, secret) {
					t.Errorf("credential %q appears in --show-config output:\n%s", secret, out)
				}
			}
			if !strings.Contains(out, "<redacted") {
				t.Errorf("no redaction marker in output; is the credential rendered at all?\n%s", out)
			}
		})
	}
}

// A fingerprint must let an operator compare two machines without either
// value leaving them.
func TestShowConfig_FingerprintComparesAcrossRuns(t *testing.T) {
	testSetup(t)
	dir := t.TempDir()
	args := []string{"lib", "upload", "fp", "--calibrepath", dir, "--bucket", "b/p",
		"--s3-access-key", "AK", "--s3-secret-key", "SAME_KEY",
		"--s3-provider", "W", "--s3-endpoint", "https://e", "-s"}
	first := captureShowConfig(t, args)

	testSetup(t)
	dir2 := t.TempDir()
	args2 := append([]string{}, args...)
	args2[4] = dir2
	second := captureShowConfig(t, args2)

	fp := func(out string) string {
		for _, line := range strings.Split(out, "\n") {
			if strings.Contains(line, "--s3-secret-key") {
				return line[strings.Index(line, "<redacted"):]
			}
		}
		return ""
	}
	a, b := fp(first), fp(second)
	if a == "" || a != b {
		t.Errorf("same secret produced different fingerprints across runs: %q vs %q", a, b)
	}
}

// Provenance must name the source, not merely that a value exists.
func TestShowConfig_ProvenanceDistinguishesFlagFromAlias(t *testing.T) {
	testSetup(t)
	dir := t.TempDir()
	// ca-125: seeded before the first parse — live serve validates
	// descriptor existence at parse time now.
	seedDescriptor(t, "prov", fedlibDescriptor{FedlibPath: dir, Mode: "public"})

	// A normal (non -s) run persists --cache-size under the alias.
	parseCLI(t, []string{"fedlib", "share", "live", "prov",
		"--aggregate-path", dir, "--cache-size", "3Gi"})
	out := captureShowConfig(t, []string{"fedlib", "share", "live", "prov",
		"--listen", "127.0.0.1:9999", "-s"})

	for _, tc := range []struct{ flag, wantOrigin string }{
		{"--listen", "flag"},      // typed now
		{"--cache-size", "alias"}, // recalled from the earlier run
		{"--poll-interval", "default"},
	} {
		var found bool
		for _, line := range strings.Split(out, "\n") {
			if strings.HasPrefix(strings.TrimSpace(line), tc.flag+" ") {
				found = true
				if !strings.Contains(line, "<- "+tc.wantOrigin) {
					t.Errorf("%s: want origin %q, got line %q", tc.flag, tc.wantOrigin, line)
				}
			}
		}
		if !found {
			t.Errorf("%s missing from output:\n%s", tc.flag, out)
		}
	}
}
