//go:build !tailscale

package cmd

import (
	"bytes"
	"database/sql"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
	"time"

	"accorder/pkg/calibre"
	"accorder/pkg/libraryflow"
	"accorder/pkg/torshare"
)

func fastBuildSQL(t *testing.T, root, statement string) {
	t.Helper()
	db, err := sql.Open("sqlite", filepath.Join(root, "metadata.db"))
	if err != nil {
		t.Fatal(err)
	}
	_, execErr := db.Exec(statement)
	closeErr := db.Close()
	if execErr != nil {
		t.Fatal(execErr)
	}
	if closeErr != nil {
		t.Fatal(closeErr)
	}
}

func TestFastBuildLocalBuildAllowsUnavailableFileSignals(t *testing.T) {
	root := testSetup(t)
	seedPublishCalibreLibrary(t, root)
	probe := sourceLocalFileEvidence
	sourceLocalFileEvidence = func(path string) (string, string) {
		id, capability := probe(path)
		if strings.HasSuffix(path, ".epub") {
			capability = ""
		}
		return id, capability
	}
	t.Cleanup(func() { sourceLocalFileEvidence = probe })
	build := fastBuildCommand(root)
	for i := 0; i < 2; i++ {
		if err := build.Run(nil); err != nil {
			t.Fatalf("local build refused unavailable format signals: %v", err)
		}
	}
	_, err := captureExistingCandidate(root, resolveUploadExcludes(root, nil))
	if err == nil || !strings.Contains(err.Error(), "cannot safely verify") {
		t.Fatalf("publication did not refuse missing format signals: %v", err)
	}
}

func fastBuildPublishedFixture(t *testing.T, member ...bool) (string, string, *LibBuildCmd) {
	t.Helper()
	root := testSetup(t)
	seedPublishCalibreLibrary(t, root)
	writeTestFile(t, root, fastBuildPayload, "old!")
	fastBuildSQL(t, root, "UPDATE data SET uncompressed_size=4 WHERE id=1")
	remote := t.TempDir()
	withLocalCommandRemote(t, remote)
	build := fastBuildCommand(root)
	if len(member) > 0 && member[0] {
		build.FedlibPrefix = "alice"
		build.DictID = 2
	}
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	candidate, err := captureExistingCandidate(root, resolveUploadExcludes(root, nil))
	if err != nil {
		t.Fatal(err)
	}
	if err := publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: 25}); err != nil {
		t.Fatal(err)
	}
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	return root, remote, build
}

func fastBuildAddSecondBook(t *testing.T, root string) {
	t.Helper()
	fastBuildSQL(t, root, `INSERT INTO books(id,title,sort,pubdate,last_modified,uuid,path) VALUES (2,'Second','Second','2020-01-01T00:00:00+00:00','2026-09-06T00:00:00+00:00','second-uuid','Author/Second (2)');
INSERT INTO data(id,book,format,uncompressed_size,name) VALUES (2,2,'EPUB',4,'Second - Author'),(3,2,'PDF',4,'Second - Author');
INSERT INTO books_authors_link(book,author) VALUES (2,1);`)
	writeTestFile(t, root, "Author/Second (2)/Second - Author.epub", "epub")
	writeTestFile(t, root, "Author/Second (2)/Second - Author.pdf", "pdf!")
}

func TestFastBuildV1UpgradeCommandMatrix(t *testing.T) {
	for _, member := range []bool{false, true} {
		for _, pending := range []bool{false, true} {
			t.Run(fmt.Sprintf("member=%v/pending=%v", member, pending), func(t *testing.T) {
				root, remote, build := fastBuildPublishedFixture(t, member)
				baseline, err := loadBaseline("alice")
				if err != nil {
					t.Fatal(err)
				}
				for i := range baseline.ContentLedger {
					object := &baseline.ContentLedger[i]
					object.Hash, err = hashLocalFile(filepath.Join(root, filepath.FromSlash(object.Path)))
					if err != nil {
						t.Fatal(err)
					}
				}
				if err := os.Remove(baselineStatePath("alice")); err != nil {
					t.Fatal(err)
				}
				baseline.Evidence = nil
				baseline.LegacyDigest = ""
				baseline.ContentLedgerVersion = 1
				baseline.Version = 1
				if err := saveBaseline("alice", *baseline); err != nil {
					t.Fatal(err)
				}
				if pending {
					writeTestFile(t, root, fastBuildPayload, "new!")
					if err := build.Run(nil); err != nil {
						t.Fatal(err)
					}
				}
				candidate, err := loadLocalChangeCandidate(root)
				if err != nil {
					t.Fatal(err)
				}
				for i := range candidate.ContentLedger {
					object := &candidate.ContentLedger[i]
					object.Hash, err = hashLocalFile(filepath.Join(root, filepath.FromSlash(object.Path)))
					if err != nil {
						t.Fatal(err)
					}
				}
				if err := os.Remove(localChangeCandidateFile(root)); err != nil {
					t.Fatal(err)
				}
				candidate.Evidence = nil
				candidate.LegacyDigest = ""
				candidate.ContentLedgerVersion = 1
				candidate.Version = 1
				if err := saveLocalChangeCandidate(root, *candidate); err != nil {
					t.Fatal(err)
				}
				oldCandidate, err := os.ReadFile(legacyChangeCandidateFile(root))
				if err != nil {
					t.Fatal(err)
				}
				oldBaseline, err := os.ReadFile(legacyBaselineStatePath("alice"))
				if err != nil {
					t.Fatal(err)
				}
				fastBuildAddSecondBook(t, root)
				for i := 0; i < 2; i++ {
					_, stderr, err := captureInviteOutput(t, func() error { return build.Run(nil) })
					if err != nil {
						t.Fatal(err)
					}
					if !strings.Contains(stderr, "lib build: reusing saved checksums; checking files for changes") {
						t.Fatalf("missing reuse explanation: %s", stderr)
					}
				}
				updated, err := loadLocalChangeCandidate(root)
				if err != nil {
					t.Fatal(err)
				}
				if updated.Scope != calibre.GenerationChangeScopeExact || updated.CompleteOverwrite {
					t.Fatalf("upgrade lost exact coverage: %+v", updated)
				}
				for _, old := range candidate.ContentLedger {
					if old.Path == "metadata.db" {
						continue
					}
					for _, current := range updated.ContentLedger {
						if current.Path == old.Path && current.Hash != old.Hash {
							t.Fatalf("lost saved hash for %s", old.Path)
						}
					}
				}
				for _, path := range []string{"Author/Second (2)/Second - Author.epub", "Author/Second (2)/Second - Author.pdf"} {
					if !containsString(updated.ForcePaths, path) {
						t.Fatalf("missing new format %s", path)
					}
					for _, object := range updated.ContentLedger {
						if object.Path == path && object.Hash != "" {
							t.Fatalf("new format was hashed: %s", path)
						}
					}
				}
				if pending && !containsString(updated.ForcePaths, fastBuildPayload) {
					t.Fatal("lost older unpublished edit")
				}
				retained, err := os.ReadFile(legacyChangeCandidateFile(root))
				if err != nil || !bytes.Equal(retained, oldCandidate) {
					t.Fatalf("rewrote legacy candidate: %v", err)
				}
				retained, err = os.ReadFile(legacyBaselineStatePath("alice"))
				if err != nil || !bytes.Equal(retained, oldBaseline) {
					t.Fatalf("rewrote legacy baseline: %v", err)
				}
				upload := &LibUploadCmd{GroupLib: build.GroupLib, GroupS3Credentials: GroupS3Credentials{Bucket: "bucket/alice"}, MaxDeletes: 25}
				upload.ActionAlias = "alice"
				if err := upload.Run(nil); err != nil {
					t.Fatal(err)
				}
				for _, path := range []string{fastBuildPayload, "Author/Second (2)/Second - Author.epub", "Author/Second (2)/Second - Author.pdf"} {
					local, err := os.ReadFile(filepath.Join(root, filepath.FromSlash(path)))
					if err != nil {
						t.Fatal(err)
					}
					got, err := os.ReadFile(filepath.Join(remote, filepath.FromSlash(path)))
					if err != nil || !bytes.Equal(local, got) {
						t.Fatalf("published bytes differ for %s: %v", path, err)
					}
				}
			})
		}
	}
}

func TestFastBuildPrivateAndFileTransitions(t *testing.T) {
	root, remote, build := fastBuildPublishedFixture(t)
	format := "Author/Second (2)/Second - Author.epub"
	pdf := "Author/Second (2)/Second - Author.pdf"
	for _, transition := range []string{"add-two-formats", "edit", "move", "private", "public", "delete"} {
		t.Run(transition, func(t *testing.T) {
			switch transition {
			case "add-two-formats":
				fastBuildAddSecondBook(t, root)
			case "edit":
				writeTestFile(t, root, format, "edit")
			case "move":
				if err := os.Rename(filepath.Join(root, "Author/Second (2)"), filepath.Join(root, "Author/Moved (2)")); err != nil {
					t.Fatal(err)
				}
				fastBuildSQL(t, root, `UPDATE books SET path='Author/Moved (2)',title='Moved',sort='Moved' WHERE id=2`)
				format = "Author/Moved (2)/Second - Author.epub"
				pdf = "Author/Moved (2)/Second - Author.pdf"
			case "private":
				fastBuildSQL(t, root, `INSERT INTO tags(id,name) VALUES(1,'private'); INSERT INTO books_tags_link(book,tag) VALUES(2,1)`)
			case "public":
				fastBuildSQL(t, root, `DELETE FROM books_tags_link WHERE book=2`)
			case "delete":
				fastBuildSQL(t, root, `DELETE FROM data WHERE book=2; DELETE FROM books_authors_link WHERE book=2; DELETE FROM books WHERE id=2`)
				for _, path := range []string{format, pdf} {
					if err := os.Remove(filepath.Join(root, filepath.FromSlash(path))); err != nil {
						t.Fatal(err)
					}
				}
			}
			if err := build.Run(nil); err != nil {
				t.Fatal(err)
			}
			candidate, err := loadLocalChangeCandidate(root)
			if err != nil {
				t.Fatal(err)
			}
			if candidate.Scope != calibre.GenerationChangeScopeExact || len(candidate.Changes) != 1 || candidate.CompleteOverwrite {
				t.Fatalf("transition did not stay exact: %+v", candidate)
			}
			if containsString(candidate.ForcePaths, fastBuildPayload) {
				t.Fatal("unrelated book forced into update")
			}
			if err := build.Run(nil); err != nil {
				t.Fatal(err)
			}
			repeated, err := loadLocalChangeCandidate(root)
			if err != nil || !reflect.DeepEqual(candidate.Changes, repeated.Changes) || !reflect.DeepEqual(candidate.ForcePaths, repeated.ForcePaths) {
				t.Fatalf("repeated build lost pending transition: %v", err)
			}
			upload := &LibUploadCmd{GroupLib: build.GroupLib, GroupS3Credentials: GroupS3Credentials{Bucket: "bucket/alice"}, MaxDeletes: 25}
			upload.ActionAlias = "alice"
			if err := upload.Run(nil); err != nil {
				t.Fatal(err)
			}
			for _, path := range []string{format, pdf} {
				got, err := os.ReadFile(filepath.Join(remote, filepath.FromSlash(path)))
				if transition == "private" || transition == "delete" {
					if !os.IsNotExist(err) {
						t.Fatalf("removed/private format still published: %s %v", path, err)
					}
				} else {
					local, localErr := os.ReadFile(filepath.Join(root, filepath.FromSlash(path)))
					if err != nil || localErr != nil || !bytes.Equal(local, got) {
						t.Fatalf("wrong bytes for %s: %v %v", path, err, localErr)
					}
				}
			}
			if transition == "move" {
				if _, err := os.Stat(filepath.Join(remote, "Author/Second (2)/Second - Author.epub")); !os.IsNotExist(err) {
					t.Fatalf("old endpoint remains: %v", err)
				}
			}
			untouched, err := os.ReadFile(filepath.Join(remote, filepath.FromSlash(fastBuildPayload)))
			if err != nil || string(untouched) != "old!" {
				t.Fatalf("untouched book changed: %v", err)
			}
		})
	}
}

func TestFastBuildSyncPreservesCoverageAcrossRemotePayloadEdit(t *testing.T) {
	root, remote, build := fastBuildPublishedFixture(t)
	writeTestFile(t, root, fastBuildPayload, "new!")
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	baseline, err := os.ReadFile(baselineStatePath("alice"))
	if err != nil {
		t.Fatal(err)
	}
	candidate, err := loadLocalChangeCandidate(root)
	if err != nil || !containsString(candidate.ForcePaths, fastBuildPayload) {
		t.Fatalf("missing local pending edit: %v", err)
	}
	before := fastBuildSnapshot(t, root)
	snapshot := (&libraryRemote{fsPath: remote}).commitState()
	if snapshot.Err != nil {
		t.Fatal(snapshot.Err)
	}
	base, generation, err := torshare.DecodeGeneration(snapshot.GenerationRaw)
	if err != nil {
		t.Fatal(err)
	}
	writeTestFile(t, remote, fastBuildPayload, "rem!")
	snapshot.Pointer.Generation = generation + 1
	if err := calibre.WritePointerDocument(filepath.Join(remote, filepath.FromSlash(memberPointerPath)), snapshot.Pointer); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(remote, libraryflow.GenerationPath), torshare.EncodeGeneration(base, generation+1), 0644); err != nil {
		t.Fatal(err)
	}
	localFP, _, err := libraryflow.SourceFingerprint(root, resolveUploadExcludes(root, nil))
	if err != nil {
		t.Fatal(err)
	}
	remoteFP, _, err := libraryflow.SourceFingerprint(remote, nil)
	if err != nil || localFP != remoteFP {
		t.Fatalf("fixture does not reproduce equal portable fingerprints: %v", err)
	}
	sync := &LibSyncCmd{GroupLib: build.GroupLib}
	sync.ActionAlias = "alice"
	if err := sync.Run(nil); err == nil || !strings.Contains(err.Error(), "Matching names and sizes") {
		t.Fatalf("sync accepted an observed predecessor: %v", err)
	}
	if before != fastBuildSnapshot(t, root) {
		t.Fatal("sync refusal changed local files or pending checkpoint")
	}
	retained, err := os.ReadFile(baselineStatePath("alice"))
	if err != nil || !bytes.Equal(baseline, retained) {
		t.Fatalf("sync rebound prior coverage: %v", err)
	}
	sync.RemoteWins = true
	if err := sync.Run(nil); err != nil {
		t.Fatal(err)
	}
	data, err := os.ReadFile(filepath.Join(root, filepath.FromSlash(fastBuildPayload)))
	if err != nil || string(data) != "rem!" {
		t.Fatalf("explicit activation has wrong bytes: %q %v", data, err)
	}
	activated, err := loadBaseline("alice")
	if err != nil || activated.Generation != generation+1 {
		t.Fatalf("activation baseline: %+v %v", activated, err)
	}
}

func fastBuildSnapshot(t *testing.T, roots ...string) string {
	t.Helper()
	var snapshot strings.Builder
	for _, root := range roots {
		data, err := snapshotTree(root)
		if err != nil {
			t.Fatal(err)
		}
		snapshot.WriteString(data)
		err = filepath.Walk(root, func(path string, info os.FileInfo, err error) error {
			if err != nil {
				return err
			}
			fmt.Fprintf(&snapshot, "%s %v %d %d\n", path, info.Mode(), info.Size(), info.ModTime().UnixNano())
			return nil
		})
		if err != nil {
			t.Fatal(err)
		}
	}
	return snapshot.String()
}

func TestFastBuildDryRunCommandMatrix(t *testing.T) {
	for _, action := range []string{"upload", "publish"} {
		for _, scenario := range []string{"same-size", "unknown-blocked", "unknown-authorized", "predecessor", "other-base", "occupied", "free", "absent", "recovery", "stale-source", "stale-index", "missing-candidate"} {
			t.Run(action+"/"+scenario, func(t *testing.T) {
				root, remote, build := fastBuildPublishedFixture(t)
				allow := scenario == "unknown-authorized" || scenario == "stale-index"
				blocker := ""
				switch scenario {
				case "same-size", "stale-source", "recovery":
					info, err := os.Stat(filepath.Join(root, filepath.FromSlash(fastBuildPayload)))
					if err != nil {
						t.Fatal(err)
					}
					writeTestFile(t, root, fastBuildPayload, "new!")
					if err := os.Chtimes(filepath.Join(root, filepath.FromSlash(fastBuildPayload)), info.ModTime(), info.ModTime()); err != nil {
						t.Fatal(err)
					}
					if scenario == "stale-source" {
						blocker = "lib build"
						break
					}
					if err := build.Run(nil); err != nil {
						t.Fatal(err)
					}
					if scenario == "recovery" {
						interrupted := errors.New("interrupted publication")
						publishCommitStageHook = func(stage string) error {
							if stage == "after-manifest" {
								return interrupted
							}
							return nil
						}
						t.Cleanup(func() { publishCommitStageHook = nil })
						candidate, err := captureExistingCandidate(root, resolveUploadExcludes(root, nil))
						if err != nil {
							t.Fatal(err)
						}
						if err := publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: 25}); !errors.Is(err, interrupted) {
							t.Fatal(err)
						}
						publishCommitStageHook = nil
						blocker = "interrupted"
					}
				case "unknown-blocked", "unknown-authorized":
					if err := os.Remove(baselineStatePath("alice")); err != nil {
						t.Fatal(err)
					}
					if err := build.Run(nil); err != nil {
						t.Fatal(err)
					}
					if !allow {
						blocker = "--allow-full-reupload"
					}
				case "predecessor", "other-base":
					snapshot := (&libraryRemote{fsPath: remote}).commitState()
					if snapshot.Err != nil {
						t.Fatal(snapshot.Err)
					}
					base, generation, err := torshare.DecodeGeneration(snapshot.GenerationRaw)
					if err != nil {
						t.Fatal(err)
					}
					if scenario == "other-base" {
						base[0]++
					} else {
						generation++
						snapshot.Pointer.Generation = generation
					}
					if err := calibre.WritePointerDocument(filepath.Join(remote, filepath.FromSlash(memberPointerPath)), snapshot.Pointer); err != nil {
						t.Fatal(err)
					}
					if err := os.WriteFile(filepath.Join(remote, libraryflow.GenerationPath), torshare.EncodeGeneration(base, generation), 0644); err != nil {
						t.Fatal(err)
					}
					blocker = "--allow-full-reupload"
				case "occupied", "free":
					writer := (&libraryRemote{fsPath: remote}).readWriter()
					if writer.Kind != "valid" {
						t.Fatalf("writer: %+v", writer)
					}
					marker := libraryflow.ReleaseWriter(time.Now(), writer.Marker)
					if scenario == "occupied" {
						marker = libraryflow.ClaimWriter("another-seat", "Other seat", time.Now(), &writer.Marker)
						blocker = "another seat"
					}
					data, err := marker.Marshal()
					if err != nil {
						t.Fatal(err)
					}
					if err := os.WriteFile(filepath.Join(remote, libraryflow.WriterPath), data, 0600); err != nil {
						t.Fatal(err)
					}
				case "absent":
					if err := os.Remove(filepath.Join(remote, libraryflow.WriterPath)); err != nil {
						t.Fatal(err)
					}
				case "stale-index":
					writeTestFile(t, root, "static/library_index.zst", "damaged index")
					blocker = "lib build"
				case "missing-candidate":
					if err := os.Remove(localChangeCandidateFile(root)); err != nil {
						t.Fatal(err)
					}
					blocker = "lib build"
				}
				run := func(dry bool) error {
					if action == "publish" {
						command := &LibPublishCmd{GroupLib: build.GroupLib, DryRun: dry, AllowCompleteOverwrite: allow, MaxDeletes: 25}
						command.ActionAlias = "alice"
						return command.Run(nil)
					}
					command := &LibUploadCmd{GroupLib: build.GroupLib, GroupS3Credentials: GroupS3Credentials{Bucket: "bucket/alice"}, DryRun: dry, AllowCompleteOverwrite: allow, MaxDeletes: 25}
					command.ActionAlias = "alice"
					return command.Run(nil)
				}
				before := fastBuildSnapshot(t, root, remote, accorderConfigDir)
				stdout, _, err := captureInviteOutput(t, func() error { return run(true) })
				if blocker != "" {
					if err == nil || !strings.Contains(err.Error(), blocker) || strings.Contains(stdout, "Result: publish allowed") {
						t.Fatalf("preview error=%v output=%s", err, stdout)
					}
					if scenario == "unknown-blocked" && !strings.Contains(err.Error(), "No library files were uploaded.") {
						t.Fatalf("missing pre-transfer explanation: %v", err)
					}
				} else if err != nil || !strings.Contains(stdout, "Result: publish allowed") {
					t.Fatalf("preview error=%v output=%s", err, stdout)
				}
				if before != fastBuildSnapshot(t, root, remote, accorderConfigDir) {
					t.Fatal("preview changed persistent bytes or metadata")
				}
				if scenario == "same-size" && !strings.Contains(stdout, "Forced uploads: 1 file, 4 bytes") {
					t.Fatalf("missing same-size byte plan: %s", stdout)
				}
				if scenario == "unknown-authorized" && (!strings.Contains(stdout, "Full library re-upload authorized") || !strings.Contains(stdout, fastBuildPayload)) {
					t.Fatalf("full reupload undisclosed: %s", stdout)
				}
				remoteBefore := fastBuildSnapshot(t, remote)
				err = run(false)
				if scenario == "unknown-blocked" || scenario == "predecessor" || scenario == "other-base" || scenario == "occupied" {
					if err == nil || !strings.Contains(err.Error(), blocker) {
						t.Fatalf("execution error=%v; expected %s", err, blocker)
					}
					if remoteBefore != fastBuildSnapshot(t, remote) {
						t.Fatal("blocked execution changed remote")
					}
					return
				}
				if err != nil {
					t.Fatalf("execution failed after preview: %v", err)
				}
				if scenario == "same-size" || scenario == "stale-source" || scenario == "recovery" {
					data, err := os.ReadFile(filepath.Join(remote, filepath.FromSlash(fastBuildPayload)))
					if err != nil || string(data) != "new!" {
						t.Fatalf("edited bytes not uploaded: %q %v", data, err)
					}
				}
			})
		}
	}
}

func TestFastBuildCatalogCoherence(t *testing.T) {
	for _, stage := range []string{"after-catalog-read", "before-checkpoint"} {
		for _, source := range []string{"database", "format"} {
			t.Run(stage+"/"+source, func(t *testing.T) {
				root := testSetup(t)
				seedPublishCalibreLibrary(t, root)
				build := fastBuildCommand(root)
				if err := build.Run(nil); err != nil {
					t.Fatal(err)
				}
				checkpoint, err := os.ReadFile(localChangeCandidateFile(root))
				if err != nil {
					t.Fatal(err)
				}
				buildSourceStageHook = func(at string) error {
					if at != stage {
						return nil
					}
					path := filepath.Join(root, "metadata.db")
					if source == "format" {
						path = filepath.Join(root, filepath.FromSlash(fastBuildPayload))
					}
					info, err := os.Stat(path)
					if err != nil {
						return err
					}
					if source == "database" {
						fastBuildSQL(t, root, "UPDATE books SET title='Look', sort='Look' WHERE id=1")
					} else {
						writeTestFile(t, root, fastBuildPayload, "changed")
					}
					return os.Chtimes(path, info.ModTime(), info.ModTime())
				}
				t.Cleanup(func() { buildSourceStageHook = nil })
				err = build.Run(nil)
				buildSourceStageHook = nil
				// A format change before inventory capture is permitted: it is
				// included in that capture. A later edit must reject the checkpoint.
				if source == "format" && stage == "after-catalog-read" {
					if err != nil {
						t.Fatal(err)
					}
					candidate, err := loadLocalChangeCandidate(root)
					if err != nil || !containsString(candidate.ForcePaths, fastBuildPayload) {
						t.Fatalf("lost format edit: %+v %v", candidate, err)
					}
					return
				}
				if err == nil || !strings.Contains(err.Error(), "changed during build") {
					t.Fatalf("build coherence error=%v", err)
				}
				retained, err := os.ReadFile(localChangeCandidateFile(root))
				if err != nil || !bytes.Equal(checkpoint, retained) {
					t.Fatalf("lost prior checkpoint: %v", err)
				}
				if err := build.Run(nil); err != nil {
					t.Fatalf("retry: %v", err)
				}
				if source == "database" {
					books, err := calibre.AllBooksFromIndex(build.IndexPath)
					if err != nil || len(books) != 1 || books[0].Title != "Look" {
						t.Fatalf("retry reused stale catalog: %+v %v", books, err)
					}
				}
			})
		}
	}
}

func TestFastBuildRestoredDatabaseMtimeInvalidatesCachedCatalog(t *testing.T) {
	root := testSetup(t)
	seedPublishCalibreLibrary(t, root)
	build := fastBuildCommand(root)
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(root, "metadata.db")
	info, err := os.Stat(path)
	if err != nil {
		t.Fatal(err)
	}
	fastBuildSQL(t, root, "UPDATE books SET title='Look', sort='Look' WHERE id=1")
	if err := os.Chtimes(path, info.ModTime(), info.ModTime()); err != nil {
		t.Fatal(err)
	}
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	books, err := calibre.AllBooksFromIndex(build.IndexPath)
	if err != nil || len(books) != 1 || books[0].Title != "Look" {
		t.Fatalf("stale catalog after database edit: %+v %v", books, err)
	}
}

func TestFastBuildInterruptedInitialBuildRetries(t *testing.T) {
	root := testSetup(t)
	seedPublishCalibreLibrary(t, root)
	build := fastBuildCommand(root)
	interrupted := errors.New("interrupted first build")
	buildSourceStageHook = func(stage string) error {
		if stage == "before-checkpoint" {
			return interrupted
		}
		return nil
	}
	t.Cleanup(func() { buildSourceStageHook = nil })
	if err := build.Run(nil); !errors.Is(err, interrupted) {
		t.Fatal(err)
	}
	if _, err := os.Stat(localChangeCandidateFile(root)); !os.IsNotExist(err) {
		t.Fatalf("partial initial checkpoint: %v", err)
	}
	buildSourceStageHook = nil
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	if _, err := loadLocalChangeCandidate(root); err != nil {
		t.Fatal(err)
	}
}

func TestFastBuildFirstBuildExplanation(t *testing.T) {
	root := testSetup(t)
	seedPublishCalibreLibrary(t, root)
	_, stderr, err := captureInviteOutput(t, func() error { return fastBuildCommand(root).Run(nil) })
	if err != nil || !strings.Contains(stderr, "lib build: recording file information without reading every book") {
		t.Fatalf("first-build explanation: %s %v", stderr, err)
	}
}
