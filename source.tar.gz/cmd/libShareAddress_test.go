//go:build tor && !tailscale

package cmd

// Tests for `lib share address` (C1). Run with: go test -tags tor ./cmd/
//

import (
	"os"
	"path/filepath"
	"strings"
	"testing"

	"accorder/pkg/torshare"
)

func TestShareAddress_SingleOnion(t *testing.T) {
	testSetup(t)
	stateDir := torshare.StateDir(accorderConfigDir, "solo")
	if err := os.MkdirAll(stateDir, 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(stateDir, "hostname"), []byte("abcdefonion.onion\n"), 0o600); err != nil {
		t.Fatal(err)
	}

	c := &LibShareAddressCmd{}
	c.ActionAlias = "solo"
	if err := c.Run(); err != nil {
		t.Fatalf("address single-onion: %v", err)
	}
}

func TestShareAddress_DualOnion(t *testing.T) {
	testSetup(t)
	stateDir := torshare.StateDir(accorderConfigDir, "dual")
	for _, sub := range []string{"browser", "index"} {
		if err := os.MkdirAll(filepath.Join(stateDir, sub), 0o700); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(filepath.Join(stateDir, sub, "hostname"), []byte(sub+"onion.onion\n"), 0o600); err != nil {
			t.Fatal(err)
		}
	}
	if err := os.WriteFile(filepath.Join(stateDir, ".serve-dual"), []byte("1\n"), 0o644); err != nil {
		t.Fatal(err)
	}

	browser, index, err := torshare.ReadDualOnionAddrs(accorderConfigDir, "dual")
	if err != nil {
		t.Fatalf("ReadDualOnionAddrs: %v", err)
	}
	if browser != "browseronion.onion" || index != "indexonion.onion" {
		t.Errorf("dual addrs = %q/%q", browser, index)
	}

	c := &LibShareAddressCmd{}
	c.ActionAlias = "dual"
	if err := c.Run(); err != nil {
		t.Fatalf("address dual-onion: %v", err)
	}
}

func TestShareAddress_HelpfulErrorWhenAbsent(t *testing.T) {
	testSetup(t)
	c := &LibShareAddressCmd{}
	c.ActionAlias = "nonexistent"
	err := c.Run()
	if err == nil {
		t.Fatal("expected error for missing onion state")
	}
	if !strings.Contains(err.Error(), "nonexistent") || !strings.Contains(err.Error(), "lib share live") {
		t.Errorf("error should name the alias and hint the share command, got: %v", err)
	}
}
