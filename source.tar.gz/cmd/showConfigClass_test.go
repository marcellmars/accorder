//go:build !tailscale && !tor

package cmd

import (
	"strings"
	"testing"

	"github.com/alecthomas/kong"
)

// walkFlags visits every flag of every command in the grammar.
func walkFlags(t *testing.T, visit func(cmdPath string, f *kong.Flag)) {
	t.Helper()
	app, err := kong.New(&CLI{}, kong.Name("accorder"), kong.Exit(func(int) {}))
	if err != nil {
		t.Fatalf("kong.New: %v", err)
	}
	var walk func(n *kong.Node)
	walk = func(n *kong.Node) {
		if n == nil {
			return
		}
		for _, f := range n.Flags {
			visit(n.Path(), f)
		}
		for _, c := range n.Children {
			walk(c)
		}
	}
	walk(app.Model.Node)
}

// Deny-by-default, Layer 1: every renderable flag is affirmatively
// classified. An unclassified flag is not a leak (it renders <redacted>)
// but it IS a defect — the operator loses a diagnostic without being told.
// This test names it so the safe list is a deliberate act.
func TestShowConfig_EveryFlagIsClassified(t *testing.T) {
	seen := map[string]bool{}
	var unclassified []string
	walkFlags(t, func(cmdPath string, f *kong.Flag) {
		if f.Name == "show-config" || f.Name == "help" || f.Name == "version" || f.Name == "on" {
			return
		}
		if seen[f.Name] {
			return
		}
		seen[f.Name] = true
		spec := ""
		if f.Value != nil && f.Value.Tag != nil {
			spec = f.Value.Tag.Get("secret")
		}
		if spec == "" && !safeFlagNames[f.Name] {
			unclassified = append(unclassified, "--"+f.Name+"  ("+cmdPath+")")
		}
	})
	if len(unclassified) > 0 {
		t.Errorf("%d flag(s) are neither in safeFlagNames nor tagged secret:, so they render <redacted>.\n"+
			"Add each to safeFlagNames in showConfigClass.go, or tag the field secret:\"redact\":\n  %s",
			len(unclassified), strings.Join(unclassified, "\n  "))
	}
}

// Layer 2 safety net: a flag whose NAME suggests credential content must
// never be classified safe. This catches the reflex of adding a new
// credential flag to the safe list.
func TestShowConfig_CredentialNamesAreNeverSafe(t *testing.T) {
	walkFlags(t, func(cmdPath string, f *kong.Flag) {
		if !credentialNamePattern.MatchString(f.Name) {
			return
		}
		spec := ""
		if f.Value != nil && f.Value.Tag != nil {
			spec = f.Value.Tag.Get("secret")
		}
		// An explicit secret:"safe" tag is a deliberate, reviewable
		// declaration next to the field (e.g. --to-passphrase is a mode
		// selector, not a secret). The net catches the OTHER path to
		// safe: a reflexive addition to the central registry.
		if spec == "" && safeFlagNames[f.Name] {
			t.Errorf("--%s (%s) has a credential-shaped name but is safe-listed in showConfigClass.go; "+
				"if it really is not a secret, tag the field secret:\"safe\" so the exemption is visible at the declaration",
				f.Name, cmdPath)
		}
	})
}

// The credential flags that motivated this work must redact on EVERY
// command that offers them, not merely on the one that was tested.
func TestShowConfig_KnownCredentialFlagsRedactEverywhere(t *testing.T) {
	want := map[string]redactClass{
		"s3-access-key": classFingerprint,
		"s3-secret-key": classFingerprint,
		"passphrase":    classRedact,
	}
	found := map[string]int{}
	walkFlags(t, func(cmdPath string, f *kong.Flag) {
		wantClass, ok := want[f.Name]
		if !ok {
			return
		}
		found[f.Name]++
		spec := ""
		if f.Value != nil && f.Value.Tag != nil {
			spec = f.Value.Tag.Get("secret")
		}
		if got := classifyFlag(f.Name, spec); got != wantClass {
			t.Errorf("--%s on %s: class %d, want %d (tag %q)", f.Name, cmdPath, got, wantClass, spec)
		}
	})
	for name := range want {
		if found[name] == 0 {
			t.Errorf("--%s never appeared in the grammar; test is not exercising what it claims", name)
		}
	}
}

// A fingerprint must be stable (so two boxes can be compared) and must not
// contain the secret.
func TestShowConfig_FingerprintStableAndOpaque(t *testing.T) {
	const secret = "SUPERSECRETVALUE"
	a := renderValue(secret, classFingerprint)
	b := renderValue(secret, classFingerprint)
	if a != b {
		t.Errorf("fingerprint not stable: %q vs %q", a, b)
	}
	if strings.Contains(a, secret) {
		t.Errorf("fingerprint leaked the secret: %q", a)
	}
	if other := renderValue(secret+"x", classFingerprint); other == a {
		t.Errorf("distinct secrets share a fingerprint: %q", a)
	}
	if got := renderValue(secret, classRedact); got != "<redacted>" {
		t.Errorf("plain redact rendered %q", got)
	}
	if got := renderValue("", classSafe); got != "(unset)" {
		t.Errorf("empty value rendered %q, want (unset)", got)
	}
}
