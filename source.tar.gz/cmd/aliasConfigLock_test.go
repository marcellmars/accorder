package cmd

import (
	"fmt"
	"sync"
	"testing"

	"github.com/tidwall/gjson"
	"github.com/tidwall/sjson"
)

// TestConcurrentAliasWriters_NoLostUpdate is the ca-111 acceptance test:
// two concurrent writers doing read-modify-write cycles under the
// alias-config lock must both have every update preserved. (POSIX-only
// guarantee; on Windows the flock is a no-op and only the in-process mutex
// serializes — which this test also exercises.)
func TestConcurrentAliasWriters_NoLostUpdate(t *testing.T) {
	testSetup(t)
	const perWriter = 25
	var wg sync.WaitGroup
	for w := 0; w < 2; w++ {
		wg.Add(1)
		go func(w int) {
			defer wg.Done()
			for i := 0; i < perWriter; i++ {
				key := fmt.Sprintf("alias-w%d-i%d", w, i)
				err := withAliasConfigLock(func() error {
					data := loadActionAliases()
					data, serr := sjson.SetBytes(data, key+".lib.build.librarian", "x")
					if serr != nil {
						return serr
					}
					saveActionAliases(data)
					return nil
				})
				if err != nil {
					t.Errorf("writer %d: %v", w, err)
					return
				}
			}
		}(w)
	}
	wg.Wait()

	data := loadActionAliases()
	for w := 0; w < 2; w++ {
		for i := 0; i < perWriter; i++ {
			key := fmt.Sprintf("alias-w%d-i%d", w, i)
			if !gjson.GetBytes(data, key).Exists() {
				t.Fatalf("lost update: %s missing", key)
			}
		}
	}
}
