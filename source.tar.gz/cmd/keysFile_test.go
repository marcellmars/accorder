//go:build !tailscale

package cmd

// Tests for B1 single-sink credentials: the Phase 0 keys-file fixture
// parse check (wasabi_full.keys format), resolver precedence, the
// one-time alias-file credential migration, and the two-alias regression.
//

import (
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	"github.com/tidwall/gjson"
)

// ═══════════════════════════════════════════════════════════════════
// Phase 0: fixture parse check. The fixture mirrors the deploy's
// wasabi_full.keys format: `access-key=…`/`secret-key=…` (+ optional
// provider/endpoint/bucket lines), whitespace-tolerant, # comments.
// ═══════════════════════════════════════════════════════════════════

func TestKeysFile_ParsesWasabiFullKeysFixture(t *testing.T) {
	dir := t.TempDir()
	fixture := filepath.Join(dir, "wasabi_full.keys")
	content := "# operator credentials\naccess-key= AKIAFIXTURE \nsecret-key =sk-fixture-secret\nprovider=Wasabi\nendpoint=s3.wasabisys.com\nbucket=motw\n\nunknown-key=ignored\n"
	if err := os.WriteFile(fixture, []byte(content), 0o600); err != nil {
		t.Fatal(err)
	}

	kf, err := parseKeysFile(fixture)
	if err != nil {
		t.Fatalf("parseKeysFile: %v", err)
	}
	if kf.AccessKey != "AKIAFIXTURE" {
		t.Errorf("AccessKey = %q (whitespace tolerance)", kf.AccessKey)
	}
	if kf.SecretKey != "sk-fixture-secret" {
		t.Errorf("SecretKey = %q", kf.SecretKey)
	}
	if kf.Provider != "Wasabi" || kf.Endpoint != "s3.wasabisys.com" || kf.Bucket != "motw" {
		t.Errorf("provider/endpoint/bucket = %q/%q/%q", kf.Provider, kf.Endpoint, kf.Bucket)
	}
}

func TestKeysFile_MinimalDeployFormat(t *testing.T) {

	// The actual deploy file carries only the two key lines.
	dir := t.TempDir()
	fixture := filepath.Join(dir, "minimal.keys")
	if err := os.WriteFile(fixture, []byte("access-key=AK\nsecret-key=SK\n"), 0o600); err != nil {
		t.Fatal(err)
	}
	kf, err := parseKeysFile(fixture)
	if err != nil {
		t.Fatalf("parseKeysFile: %v", err)
	}
	if kf.AccessKey != "AK" || kf.SecretKey != "SK" {
		t.Errorf("got %+v", kf)
	}
	if kf.Provider != "" || kf.Bucket != "" {
		t.Errorf("absent fields must stay empty: %+v", kf)
	}
}

func TestKeysFile_WriteRoundTripAndPermissions(t *testing.T) {
	testSetup(t)
	path := defaultKeysFilePath("rt")
	in := s3KeysFile{AccessKey: "AK", SecretKey: "SK", Provider: "Wasabi", Endpoint: "ep"}
	if err := writeKeysFile(path, in); err != nil {
		t.Fatalf("writeKeysFile: %v", err)
	}
	st, err := os.Stat(path)
	if err != nil {
		t.Fatal(err)
	}
	if st.Mode().Perm() != 0o600 {
		t.Errorf("keys-file mode = %v, want 0600", st.Mode().Perm())
	}
	out, err := parseKeysFile(path)
	if err != nil {
		t.Fatal(err)
	}
	if out != in {
		t.Errorf("round trip: got %+v, want %+v", out, in)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Resolver precedence: flags > env > keys-file > secrets store.
// ═══════════════════════════════════════════════════════════════════

func TestResolveOperatorS3Creds_KeysFileFillsEmptyFlagsWin(t *testing.T) {
	testSetup(t)
	if err := writeKeysFile(defaultKeysFilePath("op"), s3KeysFile{
		AccessKey: "AK-file", SecretKey: "SK-file", Provider: "Wasabi", Endpoint: "ep-file", Bucket: "motw/agg",
	}); err != nil {
		t.Fatal(err)
	}

	cmd := &FedlibBuildCmd{S3AccessKey: "AK-flag"} // explicit flag wins
	cmd.ActionAlias = "op"
	resolveOperatorS3Creds(reflect.ValueOf(cmd), "op", map[string]struct{}{})

	if cmd.S3AccessKey != "AK-flag" {
		t.Errorf("explicit access key overridden: %q", cmd.S3AccessKey)
	}
	if cmd.S3SecretKey != "SK-file" || cmd.S3Provider != "Wasabi" || cmd.S3Endpoint != "ep-file" {
		t.Errorf("keys-file did not fill empty fields: %+v", cmd)
	}
	if cmd.Bucket != "motw/agg" {
		t.Errorf("keys-file bucket not used for empty bucket: %q", cmd.Bucket)
	}
}

func TestResolveOperatorS3Creds_EnvBeatsKeysFile(t *testing.T) {
	testSetup(t)
	if err := writeKeysFile(defaultKeysFilePath("envop"), s3KeysFile{AccessKey: "AK-file", SecretKey: "SK-file"}); err != nil {
		t.Fatal(err)
	}
	t.Setenv("S3_ACCESS_KEY", "AK-env")
	t.Setenv("S3_SECRET_KEY", "SK-env")

	cmd := &FedlibBuildCmd{}
	cmd.ActionAlias = "envop"
	resolveOperatorS3Creds(reflect.ValueOf(cmd), "envop", map[string]struct{}{})

	if cmd.S3AccessKey != "AK-env" || cmd.S3SecretKey != "SK-env" {
		t.Errorf("env should beat keys-file: %q/%q", cmd.S3AccessKey, cmd.S3SecretKey)
	}
}

func TestResolveOperatorS3Creds_WriteThroughPersistsToKeysFile(t *testing.T) {
	testSetup(t)
	cmd := &FedlibBuildCmd{
		S3AccessKey: "AK-w", S3SecretKey: "SK-w", S3Provider: "Wasabi", S3Endpoint: "ep",
	}
	cmd.ActionAlias = "writethrough"
	provided := map[string]struct{}{
		"s3-access-key": {}, "s3-secret-key": {}, "s3-provider": {}, "s3-endpoint": {},
	}
	resolveOperatorS3Creds(reflect.ValueOf(cmd), "writethrough", provided)

	kf, err := parseKeysFile(defaultKeysFilePath("writethrough"))
	if err != nil {
		t.Fatalf("write-through did not create keys-file: %v", err)
	}
	if kf.AccessKey != "AK-w" || kf.SecretKey != "SK-w" || kf.Provider != "Wasabi" || kf.Endpoint != "ep" {
		t.Errorf("write-through content: %+v", kf)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Two-alias regression: two operator aliases with different S3 settings
// write distinct keys-files and never cross-read each other's creds.
// ═══════════════════════════════════════════════════════════════════

func TestResolveOperatorS3Creds_TwoAliasesStayIsolated(t *testing.T) {
	testSetup(t)
	for alias, ak := range map[string]string{"opA": "AK-A", "opB": "AK-B"} {
		cmd := &FedlibBuildCmd{S3AccessKey: ak, S3SecretKey: "SK-" + alias, S3Provider: "Wasabi", S3Endpoint: "ep"}
		cmd.ActionAlias = alias
		resolveOperatorS3Creds(reflect.ValueOf(cmd), alias, map[string]struct{}{"s3-access-key": {}})
	}

	cmdA := &FedlibBuildCmd{}
	cmdA.ActionAlias = "opA"
	resolveOperatorS3Creds(reflect.ValueOf(cmdA), "opA", map[string]struct{}{})
	cmdB := &FedlibBuildCmd{}
	cmdB.ActionAlias = "opB"
	resolveOperatorS3Creds(reflect.ValueOf(cmdB), "opB", map[string]struct{}{})

	if cmdA.S3AccessKey != "AK-A" || cmdB.S3AccessKey != "AK-B" {
		t.Errorf("cross-alias leak: A=%q B=%q", cmdA.S3AccessKey, cmdB.S3AccessKey)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Migration: credential keys in action_aliases.json are imported into
// the alias keys-file and scrubbed from the alias file.
// ═══════════════════════════════════════════════════════════════════

// An alias-stored keys-file is a durable opt-in to operator mode: after a run
// that passed --keys-file explicitly (persisting it to the alias), a bare
// re-run of the same alias must still resolve creds from that keys-file
// instead of falling through to the secrets store and dying on
// "missing required flags: --s3-*" (the documented one-liner re-publish).
func TestAliasStoredKeysFileRoutesToOperatorResolver(t *testing.T) {
	libDir := testSetup(t)

	keysPath := filepath.Join(t.TempDir(), "op.s3.keys")
	fixture := "access-key=AKALIAS\nsecret-key=SKALIAS\nprovider=Wasabi\nendpoint=s3.wasabisys.com\n"
	if err := os.WriteFile(keysPath, []byte(fixture), 0o600); err != nil {
		t.Fatal(err)
	}

	// Run 1: explicit --keys-file (operator opt-in); kong saves it to the alias.
	parseCLI(t, []string{
		"lib", "upload", "opkeys",
		"--calibrepath", libDir,
		"--bucket=test-bucket/opkeys",
		"--keys-file", keysPath,
	})
	if got := readAlias(t, "opkeys").Get("lib.upload.keys-file").String(); got != keysPath {
		t.Fatalf("keys-file not persisted to alias: %q", got)
	}

	// Run 2: bare one-liner — no flags. Must route to the operator resolver
	// via the alias-stored keys-file and pass required-flags validation.
	cli, _ := parseCLI(t, []string{"lib", "upload", "opkeys"})
	if cli.Lib.Upload.S3AccessKey != "AKALIAS" || cli.Lib.Upload.S3SecretKey != "SKALIAS" {
		t.Errorf("bare re-run did not resolve creds from alias-stored keys-file: access=%q secret=%q",
			cli.Lib.Upload.S3AccessKey, cli.Lib.Upload.S3SecretKey)
	}
}

func TestMigrateAliasCredentials_ScrubsAndPreserves(t *testing.T) {
	testSetup(t)
	seed := `{"oldlib":{"lib":{"upload":{"bucket":"motw/alice","s3-access-key":"AK-old","s3-secret-key":"SK-old","s3-provider":"Wasabi","s3-endpoint":"ep"},"publish":{"s3-access-key":"AK-old"}}}}`
	if err := os.WriteFile(savedActionAliases, []byte(seed), 0o644); err != nil {
		t.Fatal(err)
	}

	configBytes := loadActionAliases()
	if !migrateAliasCredentials(&configBytes) {
		t.Fatal("migration did not trigger")
	}

	// Scrubbed from the alias file (both memory and disk).
	onDisk, err := os.ReadFile(savedActionAliases)
	if err != nil {
		t.Fatal(err)
	}
	for _, credKey := range aliasCredKeys {
		if strings.Contains(string(onDisk), credKey) {
			t.Errorf("credential key %q still on disk after migration", credKey)
		}
	}

	// Bucket survives (per-command, not a secret).
	if got := gjson.GetBytes(onDisk, "oldlib.lib.upload.bucket").String(); got != "motw/alice" {
		t.Errorf("bucket = %q, want motw/alice (must survive migration)", got)
	}

	// Preserved into the keys-file.
	kf, err := parseKeysFile(defaultKeysFilePath("oldlib"))
	if err != nil {
		t.Fatalf("migrated keys-file missing: %v", err)
	}
	if kf.AccessKey != "AK-old" || kf.SecretKey != "SK-old" || kf.Provider != "Wasabi" || kf.Endpoint != "ep" {
		t.Errorf("migrated content: %+v", kf)
	}

	// Idempotent: second pass finds nothing.
	configBytes2 := loadActionAliases()
	if migrateAliasCredentials(&configBytes2) {
		t.Error("second migration pass should be a no-op")
	}
}

// ═══════════════════════════════════════════════════════════════════
// ca-77 end-to-end shape: after an operator-command parse with creds
// provided, none of the four excluded keys appears anywhere in
// action_aliases.json.
// ═══════════════════════════════════════════════════════════════════

func TestOperatorRun_NoCredentialKeysInAliasFile(t *testing.T) {
	testSetup(t)
	parseCLI(t, []string{
		"fedlib", "build", "opalias",
		"--output-path=/tmp/agg",
		"--bucket=motw/agg",
		"--s3-access-key=AKIAOP", "--s3-secret-key=SKOP",
		"--s3-provider=Wasabi", "--s3-endpoint=s3.wasabisys.com",
	})

	data, err := os.ReadFile(savedActionAliases)
	if err != nil {
		t.Fatal(err)
	}
	for _, credKey := range aliasCredKeys {
		if strings.Contains(string(data), credKey) {
			t.Errorf("credential key %q persisted in action_aliases.json: %s", credKey, data)
		}
	}

	// And the write-through put them in the keys-file instead.
	kf, err := parseKeysFile(defaultKeysFilePath("opalias"))
	if err != nil {
		t.Fatalf("keys-file not written by operator run: %v", err)
	}
	if kf.AccessKey != "AKIAOP" || kf.SecretKey != "SKOP" {
		t.Errorf("keys-file content: %+v", kf)
	}

	// Bucket persisted per-command only (propagate:"-").
	alias := readAlias(t, "opalias")
	if got := alias.Get("fedlib.build.bucket").String(); got != "motw/agg" {
		t.Errorf("fedlib.build.bucket = %q, want motw/agg", got)
	}
	if alias.Get("fedlib.share.live.bucket").Exists() {
		t.Error("bucket propagated to fedlib.share.live — propagate:\"-\" regressed")
	}
}
