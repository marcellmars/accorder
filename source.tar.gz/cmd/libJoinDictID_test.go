package cmd

import (
	"testing"

	"github.com/tidwall/gjson"
)

// TestStoreInviteDictID_PropagatesAsNumber is a regression test for the lib join
// bug where storeInviteDictID propagated the dictID to sibling lib.* alias paths
// (lib.upload, lib.publish, …) as a JSON STRING (via fmt.Sprintf("%d", …)), while
// the shared GroupLib.dictID field is a uint32. The stringified value made the
// next `lib publish` / `lib upload` fail to load the alias with:
//
//	json: cannot unmarshal string into Go struct field …GroupLib.dictID of type uint32
//
// lib.build (which stored the raw uint32) was fine; only the propagated siblings
// broke. Every lib.* path that carries dictID must store it as a JSON number.
func TestStoreInviteDictID_PropagatesAsNumber(t *testing.T) {
	libDir := testSetup(t)

	// Materialize the "kok" alias and get a kong.Context whose tree carries the
	// shared "lib" group across build/upload/publish (parse only, no Run).
	_, ctx := parseCLI(t, []string{"lib", "build", "kok", "--calibrepath=" + libDir})

	storeInviteDictID(ctx, "kok", 7)

	alias := readAlias(t, "kok")
	// lib.build is the source; lib.upload is the sibling that broke kok in-wild.
	for _, path := range []string{"lib.build.dictID", "lib.upload.dictID"} {
		got := alias.Get(path)
		if !got.Exists() {
			t.Fatalf("kok.%s missing — dictID did not propagate to the shared-group sibling", path)
		}
		if got.Type != gjson.Number {
			t.Errorf("kok.%s = %s (type %v), want a JSON number — regression: a stringified dictID breaks `lib publish`/`lib upload` alias unmarshal (uint32)", path, got.Raw, got.Type)
		}
		if got.Int() != 7 {
			t.Errorf("kok.%s = %d, want 7", path, got.Int())
		}
	}
}
