package cmd

import (
	"accorder/pkg/torinvite"
	"fmt"
	"os"
	"path/filepath"
	"time"

	"github.com/alecthomas/kong"
)

type FedlibShareGrantClearnetCmd struct {
	CommonCommandFields
	Friend   string `name:"friend" help:"Friend name (required for clearnet grants)." validate:"required,personname"`
	Endpoint string `name:"endpoint" help:"Clearnet URL of the aggregator (e.g. https://example.com/)." validate:"required,url"`
	Timeout  string `name:"timeout" json:"-" help:"Grant expiration (e.g. 72h, 168h). Empty = no expiration." default:""`
}

func (c *FedlibShareGrantClearnetCmd) Run(ctx *kong.Context) error {
	if c.HandleShowConfig(c) {
		return nil
	}

	stateDir := filepath.Join(accorderConfigDir, "clearnet", c.ActionAlias)
	reg, err := newGrantRegistry(stateDir)
	if err != nil {
		return fmt.Errorf("fedlib share grant: %w", err)
	}

	var expires *time.Time
	if c.Timeout != "" {
		d, err := time.ParseDuration(c.Timeout)
		if err != nil {
			return fmt.Errorf("fedlib share grant: --timeout: %w", err)
		}
		t := time.Now().Add(d)
		expires = &t
	}

	token, err := reg.issue(c.Friend, expires)
	if err != nil {
		return fmt.Errorf("fedlib share grant: %w", err)
	}

	blob := torinvite.EncodeV2Clearnet(c.Endpoint, c.ActionAlias, "aggregator", token)

	if expires != nil {
		fmt.Fprintf(os.Stderr, "fedlib share grant: issued invite for %s (expires %s)\n", c.Friend, expires.Format(time.RFC3339))
	} else {
		fmt.Fprintf(os.Stderr, "fedlib share grant: issued invite for %s\n", c.Friend)
	}
	fmt.Println(blob)
	return nil
}
