package cmd

import (
	"fmt"
	"strings"

	"github.com/tidwall/gjson"
)

// joinAliasClass names what `lib join` found in an alias before it claims an
// invite. The classification decides whether the invite's identity may replace
// what the alias already holds.
//
// The distinction that matters is between an alias that merely carries a
// locally minted libraryID (a plain `lib build`, never published anywhere) and
// one that is wired into a federation or a bucket. Refusing the first was the
// proxy that forced librarians onto a throwaway alias; refusing the second is
// the invariant that protects a published library from having its identity
// swapped underneath it.
type joinAliasClass string

const (
	// joinAliasFresh: no stored libraryID. Adopt the invite identity.
	joinAliasFresh joinAliasClass = "Fresh"
	// joinAliasLocalBuild: a locally minted libraryID with no protection
	// signal and a reachable Calibre source. Safe to adopt — nothing was
	// ever published under the prior UUID and the index can be rebuilt.
	joinAliasLocalBuild joinAliasClass = "LocalBuild"
	// joinAliasNoSource: a locally minted libraryID with no protection
	// signal, but no reachable metadata.db. Refused: adopting would strand
	// the cached JSONL, which may be the only catalog source.
	joinAliasNoSource joinAliasClass = "NoSource"
	// joinAliasProtectedIdentity: at least one protection signal present.
	// The alias is a federation member, a publisher, or an anomaly — the
	// post-claim UUID check decides, and a prefix mismatch refuses earlier.
	joinAliasProtectedIdentity joinAliasClass = "ProtectedIdentity"
)

// joinAliasDecision is the full prior-state snapshot taken before the claim.
// The classification is computed once and threaded through both identity
// gates so they cannot drift; the value fields feed the adoption
// compare-and-swap, which re-reads config under the alias lock and proceeds
// only if these are unchanged.
//
// HasWriteCreds is deliberately excluded from that CAS: storing the invite's
// credentials adds them by design between classification and adoption, so
// checking it would make every adoption fail against itself.
type joinAliasDecision struct {
	Class           joinAliasClass
	PriorUUID       string
	HasPrefix       bool
	PriorPrefix     string
	HasDictID       bool
	PriorDictID     uint32
	HasUploadBucket bool
	HasWriteCreds   bool
}

// Protected reports whether any protection signal was present.
func (d joinAliasDecision) Protected() bool {
	return d.HasPrefix || d.HasDictID || d.HasUploadBucket || d.HasWriteCreds
}

// aliasWriteCredPrefix is the secrets-store namespace `lib join` writes scoped
// credentials into. Only join writes it, which is what makes its presence a
// reliable membership signal.
func aliasWriteCredPrefix(alias string) string { return alias + "/write/" }

func hasKey(keyNames []string, name string) bool {
	for _, k := range keyNames {
		if k == name {
			return true
		}
	}
	return false
}

func hasAliasWriteCreds(keyNames []string, alias string) bool {
	prefix := aliasWriteCredPrefix(alias)
	for _, name := range keyNames {
		if strings.HasPrefix(name, prefix) {
			return true
		}
	}
	return false
}

// classifyJoinAlias inspects an alias's prior state and returns the join
// decision. It performs no I/O: the caller supplies the alias-config bytes,
// the secrets-store key names (from Store.List), and whether the alias's
// calibrepath holds a metadata.db, so the classification is reproducible from
// fixtures and cheap to call under a lock.
//
// Protection wins over everything else. An alias holding write credentials but
// no libraryID is anomalous — a prior incomplete join, or a hand edit — and is
// treated as protected rather than fresh.
//
// Note on existence vs value: fedlibPrefix and dictID are read as *key
// existence*, not truthiness. A key present with an empty or zero value is
// still a signal (and a change from absent to present-empty is a real config
// mutation the CAS must catch). Bucket keys are the exception: an empty bucket
// string carries no membership meaning.
func classifyJoinAlias(configBytes []byte, keyNames []string, alias string, calibreDBExists bool) joinAliasDecision {
	base := alias + ".lib."
	decision := joinAliasDecision{
		PriorUUID: gjson.GetBytes(configBytes, base+"build.libraryID").String(),
	}

	if r := gjson.GetBytes(configBytes, base+"build.fedlibPrefix"); r.Exists() {
		decision.HasPrefix = true
		decision.PriorPrefix = r.String()
	}
	if r := gjson.GetBytes(configBytes, base+"build.dictID"); r.Exists() {
		decision.HasDictID = true
		decision.PriorDictID = uint32(r.Uint())
	}
	// lib.build.bucket is deliberately not consulted: it serves --fetch-covers,
	// not publication, and can be present on a pure local build.
	for _, command := range []string{"upload", "publish"} {
		if r := gjson.GetBytes(configBytes, base+command+".bucket"); r.Exists() && r.String() != "" {
			decision.HasUploadBucket = true
			break
		}
	}
	// Write credentials mark a membership — except while a join for this same
	// alias is still pending. The join stores credentials and the pending
	// record together, atomically, before its identity gates run; a refused or
	// crashed join therefore leaves both behind. Counting those credentials as
	// protection would make the printed retry classify ProtectedIdentity and
	// burn a second offer against an unfollowable refusal. A completed join
	// clears the pending record, so a real member is never exempted.
	decision.HasWriteCreds = hasAliasWriteCreds(keyNames, alias) &&
		!hasKey(keyNames, pendingJoinKey(alias))

	switch {
	case decision.Protected():
		decision.Class = joinAliasProtectedIdentity
	case decision.PriorUUID == "":
		decision.Class = joinAliasFresh
	case !calibreDBExists:
		decision.Class = joinAliasNoSource
	default:
		decision.Class = joinAliasLocalBuild
	}
	return decision
}

// protectionSignals names the signals that made an alias protected, so a
// refusal can say which fact it acted on rather than asserting a verdict.
func (d joinAliasDecision) protectionSignals() string {
	var found []string
	if d.HasPrefix {
		found = append(found, fmt.Sprintf("fedlibPrefix=%q", d.PriorPrefix))
	}
	if d.HasDictID {
		found = append(found, fmt.Sprintf("dictID=%d", d.PriorDictID))
	}
	if d.HasUploadBucket {
		found = append(found, "a saved publish bucket")
	}
	if d.HasWriteCreds {
		found = append(found, "stored write credentials")
	}
	if len(found) == 0 {
		return "none"
	}
	return strings.Join(found, ", ")
}

// preflightJoinDecision refuses — before any single-use offer is claimed — the
// cases decidable from local state plus the offer's prefix.
//
// It deliberately cannot settle UUID conflicts: the burn-free informational
// payload carries no library UUID, so identity equality remains a post-claim
// check. What it can settle is structural: whether this alias already belongs
// somewhere else, and whether it has a catalog to rebuild from.
func preflightJoinDecision(alias string, d joinAliasDecision, invitePrefix string, prefixKnown bool, inviteRef string) error {
	switch d.Class {
	// joinAliasNoSource is deliberately NOT handled here. Whether it applies
	// depends on whether an adoption is about to happen, which needs the
	// invite's UUID — and the burn-free payload carries none. Refusing here
	// would reject a matching-UUID re-invite, which adopts nothing and has no
	// catalog to strand. See noSourceAdoptionRefusal, called after the claim.
	case joinAliasProtectedIdentity:
		if !prefixKnown {
			return fmt.Errorf("lib join: alias %q is already a federation member (%s) and the offer could not be read to compare\n"+
				"  refusing before claiming, so the invite is not spent\n"+
				"  to join a second federation, use a new alias: %s",
				alias, d.protectionSignals(), joinCommandLine("new-alias", inviteRef, "-c /path/to/calibre/library"))
		}
		if d.HasPrefix && d.PriorPrefix != invitePrefix {
			return fmt.Errorf("lib join: alias %q already belongs to prefix %q; this invite is for %q\n"+
				"  signals: %s\n"+
				"  the invite was NOT claimed and remains valid\n"+
				"  to join under the new prefix, use a new alias: %s",
				alias, d.PriorPrefix, invitePrefix, d.protectionSignals(), joinCommandLine("new-alias", inviteRef, "-c /path/to/calibre/library"))
		}
		if !d.HasPrefix && invitePrefix == "" {
			return fmt.Errorf("lib join: alias %q carries membership signals (%s) but neither it nor the invite names a prefix\n"+
				"  refusing before claiming rather than guessing which membership this invite is for\n"+
				"  use a new alias: %s",
				alias, d.protectionSignals(), joinCommandLine("new-alias", inviteRef, "-c /path/to/calibre/library"))
		}
	}
	return nil
}

// noSourceAdoptionRefusal refuses an adoption that would strand a cache-only
// catalog. It runs after the claim because its precondition — that an adoption
// is actually about to happen — needs the invite's UUID, which no burn-free
// payload carries.
//
// A matching-identity re-invite adopts nothing, so it is not refused here even
// when the alias has no reachable Calibre source.
func noSourceAdoptionRefusal(alias string, d joinAliasDecision, inviteID, inviteRef string) error {
	if d.Class != joinAliasNoSource || inviteID == "" || inviteID == d.PriorUUID {
		return nil
	}
	return fmt.Errorf("lib join: alias %q holds library %s and this invite carries %s, but no metadata.db was found at its Calibre path\n"+
		"  adopting the new identity would strand the cached catalog, which is keyed to the old UUID and cannot be regenerated without the Calibre library\n"+
		"  retry naming the library: %s\n"+
		"  (a single-use offer URL is spent by the claim — if the invite was a URL, ask the operator to re-issue it first)\n"+
		"  credentials were saved; the invite has already been claimed",
		alias, d.PriorUUID, inviteID, joinCommandLine(alias, inviteRef, "-c /path/to/calibre/library"))
}

// authorizeAdoption is the compare-and-swap that decides, under the
// alias-config lock, whether the invite's identity may replace what the alias
// holds.
//
// The classification was taken before the claim, and `lib build` does not take
// the library execution lock, so the alias can have changed since. Honoring a
// stale decision is exactly the race this guards: the alias is re-read here and
// adoption proceeds only while it still looks as it did when classified.
//
// HasWriteCreds is excluded by construction — storing the invite's credentials
// adds them between classification and this point, so re-reading them would
// make every adoption fail against itself. Passing nil key names leaves that
// signal false on both sides of the comparison.
func authorizeAdoption(configBytes []byte, alias string, d joinAliasDecision, stored, inviteID string) error {
	if d.Class != joinAliasLocalBuild {
		return fmt.Errorf("alias %q already belongs to library %s; invite carries %s", alias, stored, inviteID)
	}
	// A LocalBuild decision has no protection signals by construction, so the
	// CAS reduces to: the UUID is the one classified, and re-classifying the
	// re-read config still yields LocalBuild (calibreDBExists true and nil key
	// names mirror the classification this decision came from, per above).
	current := classifyJoinAlias(configBytes, nil, alias, true)
	if stored == d.PriorUUID && current.Class == joinAliasLocalBuild {
		return nil
	}
	return fmt.Errorf("lib join: alias %q changed while the invite was being claimed — refusing to replace its identity\n"+
		"  classified holding %s with no membership signals; it now holds %s (%s)\n"+
		"  nothing was built or published; settle the alias and re-run: %s",
		alias, d.PriorUUID, stored, current.protectionSignals(), joinCommandLine(alias, "<invite>", ""))
}

// adoptedAliasCalibrePath reads the calibrepath an alias already holds, for a
// join invoked without -c. The lib.join subtree is what normal recall loads; a
// legacy alias written before calibrepath entered sharedgroup:"lib" has only
// lib.build, and the generic backfill cannot reach LibJoinCmd (it sets the
// field by the Go name CalibreDirectory, which this command does not use), so
// the sibling value is read directly.
func adoptedAliasCalibrePath(configBytes []byte, alias string) string {
	for _, sub := range []string{"join", "build"} {
		if p := gjson.GetBytes(configBytes, alias+".lib."+sub+".calibrepath").String(); p != "" {
			return p
		}
	}
	return ""
}
