package cmd

import (
	"bytes"
	"encoding/hex"
	"errors"
	"fmt"
	"path"
	"path/filepath"
	"sort"
	"strings"

	"accorder/pkg/calibre"
	"accorder/pkg/libraryflow"
	"accorder/pkg/rclonexfer"

	uuid "github.com/satori/go.uuid"
)

const (
	memberChangeResultVersion   = 1
	memberChangeResultFile      = ".member_change_result.json"
	memberChangeMaxLinks        = 64
	memberChangeMaxTotalChanges = 10_000
)

var errMemberDirectoryLimit = errors.New("member directory limit exceeded")

type memberChangeResult struct {
	Version                int      `json:"version"`
	LibraryUUID            string   `json:"library_uuid"`
	Prefix                 string   `json:"prefix"`
	PreviousGeneration     string   `json:"previous_generation"`
	IncorporatedGeneration string   `json:"incorporated_generation"`
	Scope                  string   `json:"scope"`
	Reason                 string   `json:"reason,omitempty"`
	BooksDirectories       []string `json:"books_directories,omitempty"`
	AssetsDirectories      []string `json:"assets_directories,omitempty"`
}

func coarseMemberChangeResult(prefix, libraryUUID, previous, incorporated, reason string) memberChangeResult {
	return memberChangeResult{
		Version: memberChangeResultVersion, LibraryUUID: libraryUUID, Prefix: prefix,
		PreviousGeneration: previous, IncorporatedGeneration: incorporated,
		Scope: calibre.GenerationChangeScopeCoarse, Reason: reason,
	}
}

func deriveMemberChangeResult(bucketFS, libDir, stage, prefix, libraryUUID string, transition observedMemberTransition, target aggregateGenerationToken, targetPointer calibre.PointerFile) memberChangeResult {
	targetHex := transitionGenerationHex(target)
	manifestBytes := 0
	coarse := func(reason string) memberChangeResult {
		return coarseMemberChangeResult(prefix, libraryUUID, transition.PreviousGeneration, targetHex, reason)
	}
	if targetPointer.CatalogChecksum == "" {
		return coarse("target-pointer-without-checksum")
	}

	touched := make(map[string]calibre.GenerationChange)
	cursor := targetHex
	expectedChecksum := targetPointer.CatalogChecksum
	expectedCount := targetPointer.Index.NumBooks
	seenTokens := make(map[string]struct{})
	for link := 0; link < memberChangeMaxLinks; link++ {
		if _, seen := seenTokens[cursor]; seen {
			return coarse("manifest-cycle")
		}
		seenTokens[cursor] = struct{}{}
		localName := fmt.Sprintf(".member-change-%02d.json", link)
		remotePath := path.Join(prefix, generationChangeManifestPath(cursor))
		if err := rclonexfer.CopyFile(bucketFS, remotePath, stage, localName); err != nil {
			return coarse("manifest-missing")
		}
		remaining := calibre.DefaultGenerationChangeMaxBytes - manifestBytes
		if remaining <= 0 {
			return coarse("manifest-chain-byte-limit")
		}
		data, err := readFileBounded(filepath.Join(stage, localName), int64(remaining))
		if err != nil {
			if errors.Is(err, errBoundedFileTooLarge) {
				return coarse("manifest-chain-byte-limit")
			}
			return coarse("manifest-unreadable")
		}
		manifestBytes += len(data)
		if manifestBytes > calibre.DefaultGenerationChangeMaxBytes {
			return coarse("manifest-chain-byte-limit")
		}
		manifest, err := calibre.DecodeGenerationChangeManifest(data, calibre.GenerationChangeLimits{})
		if err != nil {
			return coarse("manifest-invalid")
		}
		if manifest.Scope != calibre.GenerationChangeScopeExact {
			return coarse("manifest-coarse")
		}
		if manifest.LibraryUUID != libraryUUID || manifest.ToGeneration != cursor || manifest.ToCatalogChecksum != expectedChecksum || manifest.ToLiveCount != expectedCount {
			return coarse("manifest-discontinuous")
		}
		if link == 0 && manifest.TargetSourceFingerprint != targetPointer.SourceFingerprint {
			return coarse("manifest-source-mismatch")
		}
		for _, change := range manifest.Changes {
			if _, repeated := touched[change.ID]; repeated {
				return coarse("manifest-repeated-id")
			}
			touched[change.ID] = change
			if len(touched) > memberChangeMaxTotalChanges {
				return coarse("manifest-chain-change-limit")
			}
		}
		if manifest.FromGeneration == transition.PreviousGeneration {
			expectedChecksum = manifest.FromCatalogChecksum
			expectedCount = *manifest.FromLiveCount
			break
		}
		cursor = manifest.FromGeneration
		expectedChecksum = manifest.FromCatalogChecksum
		expectedCount = *manifest.FromLiveCount
		if link == memberChangeMaxLinks-1 {
			return coarse("manifest-chain-link-limit")
		}
	}

	previousRaw, err := readFileBounded(filepath.Join(libDir, ".member_generation"), 24)
	if err != nil || hex.EncodeToString(previousRaw) != transition.PreviousGeneration {
		return coarse("previous-endpoint-missing")
	}
	previousPointerRaw, err := readFileBounded(filepath.Join(libDir, ".member_pointer"), 4<<20)
	if err != nil {
		return coarse("previous-pointer-missing")
	}
	previousPointer, err := calibre.DecodePointerFile(bytes.NewReader(previousPointerRaw))
	if err != nil || previousPointer.Library.UUID != libraryUUID || previousPointer.CatalogChecksum != expectedChecksum || previousPointer.Index.NumBooks != expectedCount {
		return coarse("previous-pointer-mismatch")
	}
	previousToken, err := decodeAggregateGenerationToken(previousRaw)
	if err != nil {
		return coarse("previous-generation-invalid")
	}
	_, previousGeneration := previousToken.parts()
	if err := calibre.ValidatePointerCommit(previousPointer, previousPointer.SourceFingerprint, previousGeneration); err != nil {
		return coarse("previous-pointer-unbound")
	}
	previousManifest, err := calibre.ReadExistingManifest(filepath.Join(libDir, "library_index"))
	if err != nil {
		return coarse("previous-index-unreadable")
	}
	if previousPointer.Index.BaseGeneration != hex.EncodeToString(previousManifest.BaseGeneration[:]) ||
		previousPointer.Index.NumBooks != previousManifest.NumBooks {
		return coarse("previous-index-mismatch")
	}
	previousChecksum, previousCount, err := calibre.CatalogChecksumFromIndex(filepath.Join(libDir, "library_index"))
	if err != nil || previousChecksum != previousPointer.CatalogChecksum || previousCount != previousPointer.Index.NumBooks {
		return coarse("previous-index-checksum-mismatch")
	}

	ids := make([]string, 0, len(touched))
	for id := range touched {
		ids = append(ids, id)
	}
	sort.Strings(ids)
	oldRecords, err := calibre.ReadCatalogRecordInfosByID(filepath.Join(libDir, "library_index"), ids)
	if err != nil {
		return coarse("previous-index-unreadable")
	}
	newRecords, err := calibre.ReadCatalogRecordInfosByID(filepath.Join(stage, "library_index"), ids)
	if err != nil {
		return coarse("target-index-unreadable")
	}
	books := make(map[string]struct{})
	assets := map[string]struct{}{path.Join(prefix, "static"): {}}
	for _, id := range ids {
		change := touched[id]
		oldRecord, oldOK := oldRecords[id]
		newRecord, newOK := newRecords[id]
		if (oldOK && oldRecord.LibraryUUID != libraryUUID) || (newOK && newRecord.LibraryUUID != libraryUUID) {
			return coarse("endpoint-library-mismatch")
		}
		switch change.Kind {
		case "added":
			if oldOK || !newOK || newRecord.RecordDigest != change.NewRecordDigest {
				return coarse("added-endpoint-mismatch")
			}
		case "edited":
			if !oldOK || !newOK || oldRecord.RecordDigest != change.OldRecordDigest || newRecord.RecordDigest != change.NewRecordDigest {
				return coarse("edited-endpoint-mismatch")
			}
		case "deleted":
			if !oldOK || newOK || oldRecord.RecordDigest != change.OldRecordDigest {
				return coarse("deleted-endpoint-mismatch")
			}
		}
		includeOldParent := change.Kind == "edited" || change.Kind == "deleted"
		if err := addRecordDirectories(prefix, oldRecord, oldOK, includeOldParent, books, assets); err != nil {
			if errors.Is(err, errMemberDirectoryLimit) {
				return coarse("member-directory-limit")
			}
			return coarse("endpoint-path-invalid")
		}
		includeNewParent := change.Kind == "added" || change.Kind == "edited"
		if err := addRecordDirectories(prefix, newRecord, newOK, includeNewParent, books, assets); err != nil {
			if errors.Is(err, errMemberDirectoryLimit) {
				return coarse("member-directory-limit")
			}
			return coarse("endpoint-path-invalid")
		}
	}
	result := memberChangeResult{
		Version: memberChangeResultVersion, LibraryUUID: libraryUUID, Prefix: prefix,
		PreviousGeneration: transition.PreviousGeneration, IncorporatedGeneration: targetHex,
		Scope:            calibre.GenerationChangeScopeExact,
		BooksDirectories: sortedKeys(books), AssetsDirectories: sortedKeys(assets),
	}
	return result
}

func addRecordDirectories(prefix string, record calibre.CatalogRecordInfo, present, includeParent bool, books, assets map[string]struct{}) error {
	if !present {
		return nil
	}
	for _, directory := range record.FormatDirectories {
		if _, err := addEndpointDirectory(books, prefix, directory); err != nil {
			return err
		}
		if len(books)+len(assets) > aggregateChangeMaxMemberDirs {
			return errMemberDirectoryLimit
		}
	}
	if record.CoverURL != "" {
		coverPath, err := libraryflow.NormalizePath(record.CoverURL)
		if err != nil || coverPath != record.CoverURL {
			return errors.New("cover path is not a normalized relative path")
		}
		if _, err := addEndpointDirectory(assets, prefix, path.Dir(coverPath)); err != nil {
			return err
		}
		if len(books)+len(assets) > aggregateChangeMaxMemberDirs {
			return errMemberDirectoryLimit
		}
	}
	if includeParent {
		for _, directory := range record.BookDirectories {
			joined, err := addEndpointDirectory(books, prefix, directory)
			if err != nil {
				return err
			}
			assets[joined] = struct{}{}
			parent := path.Dir(joined)
			books[parent] = struct{}{}
			assets[parent] = struct{}{}
			if len(books)+len(assets) > aggregateChangeMaxMemberDirs {
				return errMemberDirectoryLimit
			}
		}
	}
	return nil
}

func addEndpointDirectory(target map[string]struct{}, prefix, relative string) (string, error) {
	cleaned := ""
	if relative != "" && relative != "." {
		var err error
		cleaned, err = libraryflow.NormalizePath(relative)
		if err != nil || cleaned != relative {
			return "", errors.New("directory is not a normalized relative path")
		}
	}
	joined := prefix
	if cleaned != "" {
		joined = path.Join(prefix, cleaned)
	}
	if joined != prefix && !strings.HasPrefix(joined, prefix+"/") {
		return "", errors.New("directory escapes member prefix")
	}
	target[joined] = struct{}{}
	return joined, nil
}

func sortedKeys(values map[string]struct{}) []string {
	result := make([]string, 0, len(values))
	for value := range values {
		result = append(result, value)
	}
	sort.Strings(result)
	return result
}

func writeMemberChangeResult(libDir string, result memberChangeResult) error {
	if err := validateMemberChangeResult(result); err != nil {
		return err
	}
	return writeJSONAtomic(filepath.Join(libDir, memberChangeResultFile), result)
}

func readMemberChangeResult(libDir string) (memberChangeResult, error) {
	var result memberChangeResult
	if err := readJSONFile(filepath.Join(libDir, memberChangeResultFile), &result); err != nil {
		return result, err
	}
	if err := validateMemberChangeResult(result); err != nil {
		return result, err
	}
	return result, nil
}

func validateMemberChangeResult(result memberChangeResult) error {
	if result.Version != memberChangeResultVersion {
		return fmt.Errorf("member change result: unsupported version %d", result.Version)
	}
	parsed, err := uuid.FromString(result.LibraryUUID)
	if err != nil || parsed.String() != result.LibraryUUID || strings.ToLower(result.LibraryUUID) != result.LibraryUUID {
		return errors.New("member change result: library_uuid is not canonical")
	}
	prefix, err := libraryflow.NormalizePath(result.Prefix)
	if err != nil || prefix != result.Prefix {
		return errors.New("member change result: prefix is not normalized")
	}
	previous, err := decodeGenerationHex(result.PreviousGeneration)
	if err != nil {
		return fmt.Errorf("member change result: previous_generation: %w", err)
	}
	incorporated, err := decodeGenerationHex(result.IncorporatedGeneration)
	if err != nil {
		return fmt.Errorf("member change result: incorporated_generation: %w", err)
	}
	if previous == incorporated {
		return errors.New("member change result: generations are equal")
	}
	switch result.Scope {
	case calibre.GenerationChangeScopeExact:
		if result.Reason != "" {
			return errors.New("member change result: exact scope forbids a reason")
		}
		if err := validateMemberChangeDirectories(prefix, result.BooksDirectories); err != nil {
			return fmt.Errorf("member change result: books_directories: %w", err)
		}
		if err := validateMemberChangeDirectories(prefix, result.AssetsDirectories); err != nil {
			return fmt.Errorf("member change result: assets_directories: %w", err)
		}
	case calibre.GenerationChangeScopeCoarse:
		if result.Reason == "" {
			return errors.New("member change result: coarse scope requires a reason")
		}
		if len(result.BooksDirectories) != 0 || len(result.AssetsDirectories) != 0 {
			return errors.New("member change result: coarse scope forbids exact directories")
		}
	default:
		return fmt.Errorf("member change result: unsupported scope %q", result.Scope)
	}
	return nil
}

func validateMemberChangeDirectories(prefix string, directories []string) error {
	previous := ""
	for _, directory := range directories {
		cleaned, err := libraryflow.NormalizePath(directory)
		if err != nil || cleaned != directory || (directory != prefix && !strings.HasPrefix(directory, prefix+"/")) {
			return fmt.Errorf("directory %q is not a normalized member path", directory)
		}
		if previous != "" && directory <= previous {
			return errors.New("directories must be strictly sorted and unique")
		}
		previous = directory
	}
	return nil
}
