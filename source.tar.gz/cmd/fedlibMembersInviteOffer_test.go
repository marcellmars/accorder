package cmd

import (
	"accorder/pkg/fedlibinvite"
	"fmt"
	"net/url"
	"strings"
	"testing"
	"time"
)

func offerCmd(label, prefix, fedlibPath string) *FedlibMembersInviteCmd {
	c := reinviteCmd(label, prefix, fedlibPath)
	c.Offer = true
	c.Endpoint = "https://lib.example.org"
	c.OfferExpiry = "168h"
	// Seed the descriptor so --offer can resolve the offers dir from the id.
	_ = saveFedlibDescriptor(c.FedlibID, fedlibDescriptor{
		Version:  fedlibDescriptorVersion,
		Endpoint: "https://lib.example.org",
	})
	return c
}

// Offer-mode stdout contract: exactly one https://…/invite/<token> line.
// Blob-mode contract is asserted by TestInvite_StdoutBlobOnlyAndStderrJoinLines.
func TestInviteOffer_StdoutURLOnlyAndStderrHintWithoutExport(t *testing.T) {
	_ = testSetup(t)
	fedlibDir := t.TempDir()

	stdout, stderr, err := captureInviteOutput(t, runNilCtx(offerCmd("Carol", "carol", fedlibDir).Run))
	if err != nil {
		t.Fatalf("invite --offer: %v", err)
	}

	line := strings.TrimSuffix(stdout, "\n")
	if stdout != line+"\n" || strings.Contains(line, "\n") {
		t.Errorf("stdout is not exactly one line: %q", stdout)
	}
	if !strings.HasPrefix(line, "https://lib.example.org/invite/") {
		t.Errorf("stdout is not a claim URL: %q", line)
	}
	u, err := url.Parse(line)
	if err != nil {
		t.Fatalf("stdout line does not parse as URL: %v", err)
	}
	token := strings.TrimPrefix(u.Path, "/invite/")
	if !fedlibinvite.ValidOfferToken(token) {
		t.Errorf("URL token %q has wrong shape", token)
	}

	// Hint embeds the URL, not the blob, and carries no export line.
	wantJoin := "accorder lib join carol --invite '" + line + "' -c /path/to/calibre/library"
	if !strings.Contains(stderr, wantJoin) {
		t.Errorf("stderr missing URL join line %q\nstderr:\n%s", wantJoin, stderr)
	}
	if strings.Contains(stderr, "export ACCORDER_SECRETS_PASSPHRASE=") {
		t.Errorf("offer-mode stderr still carries the export line\nstderr:\n%s", stderr)
	}
	if !strings.Contains(stderr, "accorder lib publish carol") {
		t.Errorf("stderr missing publish line\nstderr:\n%s", stderr)
	}
	if strings.Contains(stdout, fedlibinvite.WriteInvitePrefix) || strings.Contains(stderr, fedlibinvite.WriteInvitePrefix) {
		t.Error("offer mode leaked the invite blob to stdout/stderr")
	}

	// Sealed offer is claimable with the URL token and round-trips the blob.
	dir := inviteOffersDir("fed-1")
	offer, err := fedlibinvite.ReadOffer(dir, token)
	if err != nil {
		t.Fatalf("offer not sealed under serve-alias dir: %v", err)
	}
	blob, err := fedlibinvite.OpenOffer(token, offer)
	if err != nil {
		t.Fatalf("OpenOffer with URL token: %v", err)
	}
	inv, err := fedlibinvite.DecodeWriteInvite(blob)
	if err != nil {
		t.Fatalf("decode sealed blob: %v", err)
	}
	if inv.Prefix != "carol" || inv.Label != "Carol" {
		t.Errorf("sealed invite = prefix %q label %q, want carol/Carol", inv.Prefix, inv.Label)
	}
	if offer.Prefix != "carol" || offer.DisplayName != "Carol" {
		t.Errorf("offer plain fields = %q/%q, want carol/Carol", offer.Prefix, offer.DisplayName)
	}
	wantExpiry := time.Now().Add(168 * time.Hour)
	if d := offer.Expires.Sub(wantExpiry); d < -time.Minute || d > time.Minute {
		t.Errorf("offer expiry %s not ~168h out", offer.Expires)
	}
}

func TestInviteOffer_RequiredFlagsAndExpiryValidation(t *testing.T) {
	_ = testSetup(t)
	fedlibDir := t.TempDir()

	cases := []struct {
		name   string
		mutate func(*FedlibMembersInviteCmd)
		want   string
	}{
		{"missing endpoint", func(c *FedlibMembersInviteCmd) {
			c.Endpoint = ""
			// Clear endpoint from descriptor so recall doesn't fill it back.
			_ = saveFedlibDescriptor(c.FedlibID, fedlibDescriptor{
				Version: fedlibDescriptorVersion,
			})
		}, "--endpoint"},
		{"plain-http endpoint", func(c *FedlibMembersInviteCmd) { c.Endpoint = "http://lib.example.org" }, "https://"},
		{"bad expiry", func(c *FedlibMembersInviteCmd) { c.OfferExpiry = "soon" }, "--offer-expiry"},
		{"negative expiry", func(c *FedlibMembersInviteCmd) { c.OfferExpiry = "-1h" }, "--offer-expiry"},
	}
	for i, tc := range cases {
		c := offerCmd("Carol", "carol", fedlibDir)
		// Distinct fedlib-id per case: the per-fedlib defaults write-through
		// would otherwise recall a flag an earlier case provided, masking the
		// validation error this case asserts.
		c.FedlibID = fmt.Sprintf("%s-case%d", c.FedlibID, i)
		// Re-seed descriptor for the distinct fedlib-id.
		_ = saveFedlibDescriptor(c.FedlibID, fedlibDescriptor{
			Version: fedlibDescriptorVersion, Endpoint: "https://lib.example.org",
		})
		tc.mutate(c)
		_, _, err := captureInviteOutput(t, runNilCtx(c.Run))
		if err == nil || !strings.Contains(err.Error(), tc.want) {
			t.Errorf("%s: err = %v, want mention of %q", tc.name, err, tc.want)
		}
	}
}

func TestInvitesListAndRevoke(t *testing.T) {
	_ = testSetup(t)
	fedlibDir := t.TempDir()

	if _, _, err := captureInviteOutput(t, runNilCtx(offerCmd("Carol", "carol", fedlibDir).Run)); err != nil {
		t.Fatalf("offer carol: %v", err)
	}
	if _, _, err := captureInviteOutput(t, runNilCtx(offerCmd("Dave", "dave", fedlibDir).Run)); err != nil {
		t.Fatalf("offer dave: %v", err)
	}

	list := &FedlibInvitesListCmd{FedlibID: "fed-1"}
	_, stderr, err := captureInviteOutput(t, list.Run)
	if err != nil {
		t.Fatalf("invites list: %v", err)
	}
	for _, want := range []string{"carol", "Carol", "dave", "Dave", "PREFIX", "EXPIRES"} {
		if !strings.Contains(stderr, want) {
			t.Errorf("list output missing %q:\n%s", want, stderr)
		}
	}

	revoke := &FedlibInvitesRevokeCmd{Prefix: "carol", FedlibID: "fed-1"}
	_, stderr, err = captureInviteOutput(t, revoke.Run)
	if err != nil {
		t.Fatalf("invites revoke: %v", err)
	}
	if !strings.Contains(stderr, "revoked 1 offer(s)") {
		t.Errorf("revoke output: %s", stderr)
	}

	dir := inviteOffersDir("fed-1")
	offers, err := fedlibinvite.ListOffers(dir)
	if err != nil {
		t.Fatal(err)
	}
	if len(offers) != 1 {
		t.Fatalf("after revoke: %d offers, want 1", len(offers))
	}
	for _, o := range offers {
		if o.Prefix != "dave" {
			t.Errorf("surviving offer prefix %q, want dave", o.Prefix)
		}
	}
}
