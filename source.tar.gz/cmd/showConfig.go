package cmd

import (
	"fmt"
	"os"
	"reflect"
	"sort"
	"strings"

	"github.com/alecthomas/kong"
)

// DerivedField is a renderable setting that is NOT a CLI flag on this
// command. The flag walk cannot see kong:"-" fields, so a command that
// resolves storage settings from its federation descriptor declares them
// here or the operator never learns which bucket a serve reads.
type DerivedField struct {
	Name  string
	Value string
	Note  string
	Addr  uintptr
}

// DerivedFieldLister is implemented by commands carrying flagless
// descriptor-backed settings.
type DerivedFieldLister interface {
	ShowConfigDerived() []DerivedField
}

// renderEffectiveConfig writes the effective configuration of cmd to w.
func renderEffectiveConfig(out *strings.Builder, cmd any, sc *showConfigContext) {
	node := sc.selectedNode
	path := "this command"
	if node != nil {
		path = node.Path()
	}
	fmt.Fprintf(out, "accorder %s — effective configuration\n", path)

	if alias := aliasOf(cmd); alias != "" {
		fmt.Fprintf(out, "alias: %s\n", alias)
	}
	out.WriteString("\n")

	rows := collectRows(cmd, sc)
	if len(rows) == 0 {
		out.WriteString("  (this command has no configurable settings)\n")
	}

	width := 0
	for _, r := range rows {
		if n := len(r.key); n > width {
			width = n
		}
	}
	valWidth := 0
	for _, r := range rows {
		if n := len(r.value); n > valWidth && n <= 32 {
			valWidth = n
		}
	}

	legend := false
	for _, r := range rows {
		key := r.key
		if r.derived {
			key += derivedMark
			legend = true
		}
		fmt.Fprintf(out, "  %-*s  %-*s  <- %s", width+len(derivedMark), key, valWidth, r.value, r.origin)
		if r.detail != "" {
			fmt.Fprintf(out, "  %s", r.detail)
		}
		out.WriteString("\n")
		if r.note != "" {
			fmt.Fprintf(out, "  %-*s  %s\n", width+len(derivedMark), "", r.note)
		}
	}

	if legend {
		fmt.Fprintf(out, "\n%s resolved from the federation descriptor; not a CLI flag on this command\n", derivedMark)
	}
	if sc.readOnly {
		out.WriteString("\nnothing was written; this command made no changes\n")
	}
}

type configRow struct {
	key     string
	value   string
	origin  string
	detail  string
	note    string
	derived bool
}

// derivedMark flags a setting that is resolved but not typeable as a flag
// on this command, so the output never implies an option that would be
// rejected as unknown.
const derivedMark = " †"

func collectRows(cmd any, sc *showConfigContext) []configRow {
	var rows []configRow
	seen := map[uintptr]bool{}

	if sc.selectedNode != nil {
		for _, f := range sc.selectedNode.Flags {
			if f.Name == "show-config" || f.Name == "help" {
				continue
			}
			if f.Value == nil || !f.Value.Target.IsValid() {
				continue
			}
			var addr uintptr
			if f.Value.Target.CanAddr() {
				addr = f.Value.Target.Addr().Pointer()
				seen[addr] = true
			}
			spec := ""
			if f.Value.Tag != nil {
				spec = f.Value.Tag.Get("secret")
			}
			raw := formatFieldValue(f.Value.Target)
			origin, detail := originFor(sc, addr, raw)
			rows = append(rows, configRow{
				key:    "--" + f.Name,
				value:  renderValue(raw, classifyFlag(f.Name, spec)),
				origin: origin,
				detail: detail,
				note:   issueNote(sc, addr),
			})
		}
	}

	if lister, ok := cmd.(DerivedFieldLister); ok {
		for _, d := range lister.ShowConfigDerived() {
			if seen[d.Addr] {
				continue
			}
			origin, detail := originFor(sc, d.Addr, d.Value)
			rows = append(rows, configRow{
				key:     "--" + d.Name,
				value:   renderValue(d.Value, classifyFlag(d.Name, "")),
				origin:  origin,
				detail:  detail,
				note:    issueNote(sc, d.Addr),
				derived: true,
			})
		}
	}

	sort.SliceStable(rows, func(i, j int) bool { return rows[i].key < rows[j].key })
	return rows
}

// originFor reports the recorded origin. An unstamped field that still
// holds a value is reported as "unknown" rather than guessed — a wrong
// provenance token is worse than an absent one in a diagnostic.
func originFor(sc *showConfigContext, addr uintptr, raw string) (string, string) {
	if e, ok := sc.provenance.lookup(addr); ok {
		return string(e.Origin), e.Detail
	}
	if raw == "" {
		return string(OriginDefault), ""
	}
	return "unknown", ""
}

func issueNote(sc *showConfigContext, addr uintptr) string {
	if sc == nil || addr == 0 {
		return ""
	}
	for _, is := range sc.issues {
		if is.FieldPtr == addr {
			return "(" + is.Message + ")"
		}
	}
	return ""
}

// formatFieldValue renders a field for display. Pointer flags print their
// pointee (nil is unset); slices join with commas; everything else uses Go
// formatting, which is already what an operator would type back.
func formatFieldValue(v reflect.Value) string {
	if !v.IsValid() {
		return ""
	}
	switch v.Kind() {
	case reflect.Ptr:
		if v.IsNil() {
			return ""
		}
		return formatFieldValue(v.Elem())
	case reflect.String:
		return v.String()
	case reflect.Bool:
		if !v.Bool() {
			return ""
		}
		return "true"
	case reflect.Slice:
		if v.Len() == 0 {
			return ""
		}
		parts := make([]string, v.Len())
		for i := range parts {
			parts[i] = formatFieldValue(v.Index(i))
		}
		return strings.Join(parts, ",")
	default:
		s := fmt.Sprintf("%v", v.Interface())
		if s == "0" || s == "0s" {
			return ""
		}
		return s
	}
}

// aliasOf reads the positional action alias, which is the addressing key
// for the whole view rather than a resolved setting, so it prints in the
// header without a provenance token.
func aliasOf(cmd any) string {
	v := reflect.ValueOf(cmd)
	if v.Kind() == reflect.Ptr {
		if v.IsNil() {
			return ""
		}
		v = v.Elem()
	}
	if v.Kind() != reflect.Struct {
		return ""
	}
	return fieldStringValue(v, "ActionAlias")
}

// showConfigNode is a test seam: production wiring comes from AfterApply.
func newShowConfigContext(p *ProvenanceTable, sel, root *kong.Node, readOnly bool) *showConfigContext {
	return &showConfigContext{provenance: p, selectedNode: sel, rootNode: root, readOnly: readOnly}
}

var showConfigOut = os.Stdout
