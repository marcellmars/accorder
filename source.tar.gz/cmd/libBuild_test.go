package cmd

import (
	"accorder/pkg/calibre"
	"testing"
)

func TestShouldAutoCompact(t *testing.T) {
	tests := []struct {
		name        string
		regions     int
		numBooks    uint32
		tombstones  int
		isAggregate bool
		want        bool
	}{
		{"4 regions, no tombstones", 4, 100, 0, false, false},
		{"5 regions, no tombstones", 5, 100, 0, false, false},
		{"6 regions, no tombstones", 6, 100, 0, false, true},
		{"1 region, low tombstones", 1, 100, 10, false, false},
		{"1 region, tombstones*3 == numBooks", 1, 30, 10, false, false},
		{"1 region, tombstones*3 > numBooks", 1, 29, 10, false, true},
		{"zero books, zero tombstones", 1, 0, 0, false, false},
		{"zero books, some tombstones", 1, 0, 5, false, false},
		{"high tombstone ratio", 2, 10, 4, false, true},

		// Aggregate context: region count is ignored
		{"aggregate: 6 regions, no tombstones", 6, 100, 0, true, false},
		{"aggregate: 10 regions, no tombstones", 10, 100, 0, true, false},

		// Aggregate context: tombstone ratio still triggers
		{"aggregate: tombstones*3 > numBooks", 1, 29, 10, true, true},
		{"aggregate: high tombstone ratio", 2, 10, 4, true, true},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mf := calibre.Manifest{
				NumBooks:   tt.numBooks,
				Regions:    make([]calibre.ManifestRegion, tt.regions),
				Tombstones: make([][16]byte, tt.tombstones),
			}
			got := shouldAutoCompact(mf, tt.isAggregate)
			if got != tt.want {
				t.Errorf("shouldAutoCompact(%d regions, %d books, %d tombstones, isAggregate=%v) = %v, want %v",
					tt.regions, tt.numBooks, tt.tombstones, tt.isAggregate, got, tt.want)
			}
		})
	}
}
