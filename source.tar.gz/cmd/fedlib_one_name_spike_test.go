//go:build !tailscale

package cmd

// ═══════════════════════════════════════════════════════════════════
// Spike: fedlib-one-name — Phase 0 validation (durable artifact for the
// study's Key Findings #4; first run 2026-07-07 during the study phase).
//
// Hypothesis: Kong accepts a REQUIRED positional followed by an OPTIONAL
// positional in the same command — the grammar `fedlib members invite
// <fedlib-id> [<label>]` depends on it. The inverse ordering is forbidden
// (howto/kong_sharedgroup_embedding.md "Commands with Required Positional
// Args Cannot Embed CommonCommandFields"); this pins that the forward
// ordering is legal, at struct-registration time and at parse time.
// ═══════════════════════════════════════════════════════════════════

import (
	"testing"

	"github.com/alecthomas/kong"
)

type spikeOneNameInviteCmd struct {
	FedlibID string `arg:"" name:"fedlib-id" help:"Federation identifier (required first positional)."`
	Label    string `arg:"" optional:"" help:"Librarian label (optional second positional)."`
}

func (z *spikeOneNameInviteCmd) Run() error { return nil }

type spikeOneNameCLI struct {
	Invite spikeOneNameInviteCmd `cmd:""`
}

func TestSpike_OneName_RequiredThenOptionalPositional(t *testing.T) {
	newApp := func(t *testing.T) (*spikeOneNameCLI, *kong.Kong) {
		t.Helper()
		cli := &spikeOneNameCLI{}
		app, err := kong.New(cli, kong.Name("spike"), kong.Exit(func(int) {}))
		if err != nil {
			t.Fatalf("kong.New rejects required-then-optional positional: %v", err)
		}
		return cli, app
	}

	t.Run("id_only", func(t *testing.T) {
		cli, app := newApp(t)
		if _, err := app.Parse([]string{"invite", "myfed"}); err != nil {
			t.Fatalf("parse id-only: %v", err)
		}
		if cli.Invite.FedlibID != "myfed" || cli.Invite.Label != "" {
			t.Fatalf("got id=%q label=%q", cli.Invite.FedlibID, cli.Invite.Label)
		}
	})

	t.Run("id_and_label", func(t *testing.T) {
		cli, app := newApp(t)
		if _, err := app.Parse([]string{"invite", "myfed", "Jane Doe"}); err != nil {
			t.Fatalf("parse id+label: %v", err)
		}
		if cli.Invite.FedlibID != "myfed" || cli.Invite.Label != "Jane Doe" {
			t.Fatalf("got id=%q label=%q", cli.Invite.FedlibID, cli.Invite.Label)
		}
	})

	t.Run("missing_required_id_errors", func(t *testing.T) {
		_, app := newApp(t)
		if _, err := app.Parse([]string{"invite"}); err == nil {
			t.Fatal("expected parse error when required fedlib-id positional is missing")
		}
	})
}
