//go:build tor

package cmd

import (
	"accorder/internal/sharegrant"
	"accorder/pkg/torshare"
	"fmt"
	"os"
	"path/filepath"

	"github.com/alecthomas/kong"
)

type FedlibShareGrantCmd struct {
	CommonCommandFields
	Friend string `name:"friend" help:"Friend name (omit for public invite)." validate:"omitempty,personname"`
}

func (c *FedlibShareGrantCmd) Run(ctx *kong.Context) error {
	if c.HandleShowConfig(c) {
		return nil
	}

	stateDir := torshare.StateDir(accorderConfigDir, c.ActionAlias)
	// offline-private serves a dual onion; the gated plane is the index onion,
	// whose hostname + authorized_clients live in the index/ subdir. The serve
	// writes a .serve-dual marker reflecting the CURRENT topology — grant against
	// the index onion only when it's set (a stale index/ dir from a prior
	// offline-private run must not redirect a single-onion private/public grant).
	if _, statErr := os.Stat(filepath.Join(stateDir, ".serve-dual")); statErr == nil {
		stateDir = filepath.Join(stateDir, "index")
	}

	publicSentinel := filepath.Join(stateDir, ".public")
	_, sentinelErr := os.Stat(publicSentinel)
	isPublic := sentinelErr == nil
	authFiles, _ := filepath.Glob(filepath.Join(stateDir, "authorized_clients", "*.auth"))

	if c.Friend != "" && isPublic {
		return fmt.Errorf("share-grant: aggregator alias is in public mode (.public sentinel exists); " +
			"remove the .public sentinel and restart 'fedlib share live' in a non-public mode to enable per-friend auth")
	}
	if c.Friend == "" && !isPublic && len(authFiles) > 0 {
		return fmt.Errorf("share-grant: aggregator alias is in per-friend mode "+
			"(authorized_clients/ has %d .auth file(s)); pass --friend NAME", len(authFiles))
	}
	needPublicSentinel := c.Friend == "" && !isPublic && len(authFiles) == 0

	result, err := sharegrant.Grant(stateDir, c.Friend, c.ActionAlias, "aggregator")
	if err != nil {
		return fmt.Errorf("share-grant: %w", err)
	}

	if needPublicSentinel {
		if err := os.MkdirAll(stateDir, 0700); err != nil {
			return fmt.Errorf("share-grant: mkdir state dir: %w", err)
		}
		if err := os.WriteFile(publicSentinel, []byte("public\n"), 0644); err != nil {
			return fmt.Errorf("share-grant: write .public sentinel: %w", err)
		}
	}

	fmt.Fprintln(os.Stderr, result.Message)
	fmt.Println(result.InviteBlob)
	return nil
}
