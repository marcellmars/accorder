//go:build !tailscale

package cmd

// ca-132 / ca-133 / ca-131-hint: the descriptor keys path reaches rebuild
// consumers as one absolute convention; `fedlib members offer` recalls
// endpoint/expiry from the descriptor read-only; an unreadable
// descriptor-selected keys file is loud on a normal serve run.

import (
	"bytes"
	"log"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// ca-132: a config-dir-relative descriptor keys path is absolutized at the
// params producer, so both the child-rebuild flag handoff and the
// in-process build receive a path that is valid regardless of CWD.
func TestAggregateServeParams_RelativeKeysPathAbsolutized(t *testing.T) {
	testSetup(t)
	c := &FedlibShareLiveCmd{KeysFile: filepath.Join("keys", "fed.s3.keys")}
	c.ActionAlias = "fed"

	p := c.aggregateServeParams()
	want := filepath.Join(accorderConfigDir, "keys", "fed.s3.keys")
	if p.KeysFile != want {
		t.Fatalf("params.KeysFile = %q, want config-dir-joined %q", p.KeysFile, want)
	}

	args := buildChildRebuildArgs(p)
	var got string
	for i, a := range args {
		if a == "--keys-file" && i+1 < len(args) {
			got = args[i+1]
		}
	}
	if got != want {
		t.Errorf("child rebuild --keys-file = %q, want %q", got, want)
	}
	if inProcessBuildCmd(p, "bucketfs").KeysFile != want {
		t.Errorf("in-process build KeysFile not absolutized")
	}

	// An absolute descriptor path and an empty path pass through verbatim.
	abs := filepath.Join(t.TempDir(), "x.s3.keys")
	c.KeysFile = abs
	if got := c.aggregateServeParams().KeysFile; got != abs {
		t.Errorf("absolute path rewritten to %q", got)
	}
	c.KeysFile = ""
	if got := c.aggregateServeParams().KeysFile; got != "" {
		t.Errorf("empty path rewritten to %q", got)
	}
}

// ca-133: offer recalls endpoint and expiry from the descriptor
// (read-only), fails closed with a named flag when neither source has an
// endpoint, and never writes an offer for a recalled invalid endpoint.
func TestFedlibMembersOffer_DescriptorEndpointRecall(t *testing.T) {
	offersFor := func(fedlibID string) int {
		entries, err := os.ReadDir(inviteOffersDir(fedlibID))
		if os.IsNotExist(err) {
			return 0
		}
		if err != nil {
			t.Fatal(err)
		}
		return len(entries)
	}

	t.Run("recalled_from_descriptor", func(t *testing.T) {
		testSetup(t)
		seedDescriptor(t, "fed", fedlibDescriptor{Endpoint: "https://agg.example.com", OfferExpiry: "72h"})
		before, err := os.ReadFile(fedlibDescriptorPath())
		if err != nil {
			t.Fatal(err)
		}

		c := &FedlibMembersOfferCmd{FedlibID: "fed", Prefix: "carol", Librarian: "Carol"}
		stdout, _, err := captureInviteOutput(t, runNilCtx(c.Run))
		if err != nil {
			t.Fatalf("offer with descriptor endpoint failed: %v", err)
		}
		if !strings.HasPrefix(stdout, "https://agg.example.com/invite/") {
			t.Errorf("claim URL = %q, want descriptor endpoint prefix", stdout)
		}
		after, err := os.ReadFile(fedlibDescriptorPath())
		if err != nil {
			t.Fatal(err)
		}
		if string(before) != string(after) {
			t.Error("offer wrote the descriptor — recall must be read-only")
		}
	})

	t.Run("explicit_flag_wins", func(t *testing.T) {
		testSetup(t)
		seedDescriptor(t, "fed", fedlibDescriptor{Endpoint: "https://stored.example.com"})
		c := &FedlibMembersOfferCmd{FedlibID: "fed", Prefix: "carol", Librarian: "Carol", Endpoint: "https://typed.example.com"}
		stdout, _, err := captureInviteOutput(t, runNilCtx(c.Run))
		if err != nil {
			t.Fatal(err)
		}
		if !strings.HasPrefix(stdout, "https://typed.example.com/invite/") {
			t.Errorf("claim URL = %q, want explicit endpoint to win", stdout)
		}
	})

	t.Run("neither_source_names_the_flag", func(t *testing.T) {
		testSetup(t)
		seedDescriptor(t, "fed", fedlibDescriptor{})
		c := &FedlibMembersOfferCmd{FedlibID: "fed", Prefix: "carol", Librarian: "Carol"}
		_, _, err := captureInviteOutput(t, runNilCtx(c.Run))
		want := "--endpoint is required (or set it in the descriptor"
		if err == nil || !strings.Contains(err.Error(), want) {
			t.Fatalf("want error containing %q, got %v", want, err)
		}
		if n := offersFor("fed"); n != 0 {
			t.Errorf("%d offer file(s) written on failure", n)
		}
	})

	t.Run("recalled_invalid_endpoint_fails_before_offer_write", func(t *testing.T) {
		testSetup(t)
		seedDescriptor(t, "fed", fedlibDescriptor{Endpoint: "notaurl"})
		c := &FedlibMembersOfferCmd{FedlibID: "fed", Prefix: "carol", Librarian: "Carol"}
		_, _, err := captureInviteOutput(t, runNilCtx(c.Run))
		if err == nil || !strings.Contains(err.Error(), "--endpoint (url)") {
			t.Fatalf("want `--endpoint (url)` validation error, got %v", err)
		}
		if n := offersFor("fed"); n != 0 {
			t.Errorf("%d offer file(s) written for an invalid recalled endpoint", n)
		}
	})
}

// ca-131 residue: a live serve whose descriptor names a keys file that
// cannot be read says so and names the resolved path — the serve reads no
// other keys path, so silence here becomes an unexplained RequireS3Creds
// failure later.
func TestFedlibShareLive_UnreadableDescriptorKeysPathIsLoud(t *testing.T) {
	testSetup(t)
	dir := t.TempDir()
	seedDescriptor(t, "fed", fedlibDescriptor{FedlibPath: dir, KeysFile: "keys/missing.s3.keys"})

	var buf bytes.Buffer
	prev := log.Writer()
	log.SetOutput(&buf)
	t.Cleanup(func() { log.SetOutput(prev) })

	parseCLI(t, []string{"fedlib", "share", "live", "fed"})

	wantPath := filepath.Join(accorderConfigDir, "keys", "missing.s3.keys")
	out := buf.String()
	if !strings.Contains(out, "descriptor-selected keys-file") || !strings.Contains(out, wantPath) {
		t.Errorf("no pointed warning naming %q in serve logs:\n%s", wantPath, out)
	}
}
