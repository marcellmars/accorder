package cmd

import (
	"net/http"
	"sync/atomic"
)

const warmingRetryAfter = "5"

type readinessGate struct {
	ready atomic.Pointer[http.ServeMux]
}

func (g *readinessGate) setReady(mux *http.ServeMux) {
	g.ready.Store(mux)
}

func (g *readinessGate) isReady() bool {
	return g.ready.Load() != nil
}

func (g *readinessGate) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if mux := g.ready.Load(); mux != nil {
		mux.ServeHTTP(w, r)
		return
	}
	w.Header().Set("Retry-After", warmingRetryAfter)
	http.Error(w, "warming up: loading aggregate index", http.StatusServiceUnavailable)
}
