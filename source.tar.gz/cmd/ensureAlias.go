package cmd

import (
	"fmt"
	"log"
	"path/filepath"
	"strings"
	"unicode"

	"accorder/pkg/librarianname"

	"github.com/alecthomas/kong"
	uuid "github.com/satori/go.uuid"
	"github.com/tidwall/gjson"
	"github.com/tidwall/sjson"
)

func slugifyAlias(name string) string {
	var b strings.Builder
	pendingDash := false
	for _, r := range strings.ToLower(name) {
		switch {
		case r >= 'a' && r <= 'z', r >= '0' && r <= '9', r == '.', r == '_':
			if pendingDash && b.Len() > 0 {
				b.WriteByte('-')
			}
			pendingDash = false
			b.WriteRune(r)
		case unicode.IsSpace(r), r == '-':
			pendingDash = true
		}
	}
	return b.String()
}

func ensureAliasSetup(root *kong.Node, alias, calibrePath, librarianHint string) (libraryID, librarian, storedCalibre string) {
	unlockAliasCfg := lockAliasConfigOrDie()
	defer unlockAliasCfg()
	buildNode := findNodeByPath(root, "lib.build")
	configBytes := loadActionAliases()
	persist := func(key, value string) {
		configBytes, _ = sjson.SetBytes(configBytes, alias+".lib.build."+key, value)
		if buildNode != nil {
			propagateSharedField(root, buildNode, alias, key, value, "lib", &configBytes)
		}
	}

	libraryID = gjson.GetBytes(configBytes, alias+".lib.build.libraryID").String()
	librarian = gjson.GetBytes(configBytes, alias+".lib.build.librarian").String()
	storedCalibre = gjson.GetBytes(configBytes, alias+".lib.build.calibrepath").String()
	changed := false
	if libraryID == "" {
		libraryID = uuid.NewV4().String()
		persist("libraryID", libraryID)
		changed = true
		log.Printf("[CFG] minted libraryID %s for alias %q (saved)", libraryID, alias)
	}
	if librarian == "" {
		if hint := strings.TrimSpace(librarianHint); hint != "" {
			librarian = hint
			persist("librarian", librarian)
			changed = true
			log.Printf("[CFG] librarian %q (saved) for alias %q", librarian, alias)
		} else {
			librarian = librarianname.Generate(libraryID, 0)
			persist("librarian", librarian)
			changed = true
			log.Printf("[CFG] librarian %q (generated; set --librarian to choose)", librarian)
		}
	}
	if storedCalibre == "" && calibrePath != "" {
		persist("calibrepath", calibrePath)
		storedCalibre = calibrePath
		changed = true
	}
	if changed {
		saveActionAliases(configBytes)
	}
	return libraryID, librarian, storedCalibre
}

func ensureAliasForBrowse(ctx *kong.Context, libraryName, libraryPath, librarian string) (string, error) {
	alias := slugifyAlias(libraryName)
	if alias == "" {
		return "", fmt.Errorf("library name %q yields an empty alias", libraryName)
	}
	root := ctx.Selected()
	for root != nil && root.Parent != nil {
		root = root.Parent
	}

	stored := gjson.GetBytes(loadActionAliases(), alias+".lib.build.calibrepath").String()
	if stored != "" && libraryPath != "" && filepath.Clean(stored) != filepath.Clean(libraryPath) {
		return alias, fmt.Errorf("alias %q already points at %s — not modified (pick another library name)", alias, stored)
	}

	libraryID, savedLibrarian, _ := ensureAliasSetup(root, alias, libraryPath, librarian)
	log.Printf("[CFG] alias %q ready (libraryID %s, librarian %q) — share it: accorder lib share live %s",
		alias, libraryID, savedLibrarian, alias)
	return alias, nil
}
