package cmd

import (
	"net"
)

var interfaceAddrsFn = net.InterfaceAddrs

func hintHost(listen string) (hostPort string, reachable bool, boundLoopback bool) {
	host, port, err := net.SplitHostPort(listen)
	if err != nil {

		return listen, false, false
	}

	if host != "" {
		if ip := net.ParseIP(host); ip != nil {
			switch {
			case ip.IsLoopback():
				return net.JoinHostPort(host, port), false, true
			case !ip.IsUnspecified():
				return net.JoinHostPort(host, port), true, false
			}
		} else {

			return net.JoinHostPort(host, port), true, false
		}
	}

	if substitute, ok := firstNonLoopbackAddr(); ok {
		return net.JoinHostPort(substitute, port), false, false
	}
	return net.JoinHostPort(host, port), false, false
}

func firstNonLoopbackAddr() (string, bool) {
	addrs, err := interfaceAddrsFn()
	if err != nil {
		return "", false
	}

	var v6 string
	for _, a := range addrs {
		ipNet, ok := a.(*net.IPNet)
		if !ok {
			continue
		}
		ip := ipNet.IP
		if ip == nil || ip.IsLoopback() || ip.IsLinkLocalUnicast() || ip.IsLinkLocalMulticast() {
			continue
		}
		if v4 := ip.To4(); v4 != nil {
			return v4.String(), true
		}
		if v6 == "" {
			v6 = ip.String()
		}
	}
	if v6 != "" {
		return v6, true
	}
	return "", false
}
