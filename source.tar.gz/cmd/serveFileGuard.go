package cmd

import (
	"net/http"
	"path/filepath"
	"strings"
)

func isSensitiveServePath(cleaned string) bool {
	for _, comp := range strings.Split(cleaned, "/") {
		if strings.HasPrefix(comp, ".") {
			return true
		}
	}
	base := strings.ToLower(filepath.Base(cleaned))
	ext := filepath.Ext(base)
	switch {
	case ext == ".db" || ext == ".db-wal" || ext == ".db-shm":
		return true
	case base == "metadata_db_prefs_backup.json":
		return true
	case base == "_identity" || base == "_writer":
		return true
	case ext == ".age":
		return true
	}
	return false
}

func guardedFileHandler(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		cleaned := filepath.Clean(strings.TrimPrefix(r.URL.Path, "/files/"))
		if isSensitiveServePath(cleaned) {
			http.NotFound(w, r)
			return
		}
		next.ServeHTTP(w, r)
	})
}
