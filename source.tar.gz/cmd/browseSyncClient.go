package cmd

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"time"

	"golang.org/x/net/proxy"
)

func newBrowseTorHTTPClient(socksAddr string) (*http.Client, error) {
	dialer, err := proxy.SOCKS5("tcp", socksAddr, nil, &net.Dialer{
		Timeout: 60 * time.Second,
	})
	if err != nil {
		return nil, err
	}
	contextDialer, ok := dialer.(proxy.ContextDialer)
	if !ok {

		return &http.Client{
			Transport: &announceTransport{base: &http.Transport{
				DialContext: func(ctx context.Context, network, addr string) (net.Conn, error) {
					return dialer.Dial(network, addr)
				},
				TLSHandshakeTimeout:   30 * time.Second,
				ResponseHeaderTimeout: 120 * time.Second,
				MaxIdleConnsPerHost:   4,
			}},
		}, nil
	}
	return &http.Client{
		Transport: &announceTransport{base: &http.Transport{
			DialContext:           contextDialer.DialContext,
			TLSHandshakeTimeout:   30 * time.Second,
			ResponseHeaderTimeout: 120 * time.Second,
			MaxIdleConnsPerHost:   4,
		}},
	}, nil
}

var announceNonce = func() string {
	b := make([]byte, 4)
	if _, err := rand.Read(b); err != nil {
		return "0"
	}
	return hex.EncodeToString(b)
}()

type announceTransport struct {
	host string
	base http.RoundTripper
}

func (t *announceTransport) RoundTrip(req *http.Request) (*http.Response, error) {
	if t.host != "" && req.URL.Host != t.host {
		return t.base.RoundTrip(req)
	}
	req2 := req.Clone(req.Context())
	req2.Header.Set("X-Accorder-Client", "lib-browse/"+cmdVersion+" r="+announceNonce)
	return t.base.RoundTrip(req2)
}

type bearerAuthTransport struct {
	token string
	host  string
	base  http.RoundTripper
}

func (t *bearerAuthTransport) RoundTrip(req *http.Request) (*http.Response, error) {
	if t.host != "" && req.URL.Host != t.host {
		return t.base.RoundTrip(req)
	}
	req2 := req.Clone(req.Context())
	req2.Header.Set("Authorization", "Bearer "+t.token)
	return t.base.RoundTrip(req2)
}

func newBrowseClearnetHTTPClient(token, host string) *http.Client {
	transport := &http.Transport{
		DialContext:           (&net.Dialer{Timeout: 10 * time.Second}).DialContext,
		TLSHandshakeTimeout:   10 * time.Second,
		ResponseHeaderTimeout: 30 * time.Second,
		MaxIdleConnsPerHost:   4,
	}
	var rt http.RoundTripper = &announceTransport{host: host, base: transport}
	if token == "" {
		return &http.Client{Transport: rt}
	}
	return &http.Client{
		Transport: &bearerAuthTransport{
			token: token,
			host:  host,
			base:  rt,
		},
	}
}

func fetchBrowseData1(data1URL, staticDir string, client *http.Client) error {
	resp, err := client.Get(data1URL)
	if err != nil {
		return fmt.Errorf("GET %s: %w", data1URL, err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("GET %s: status %d", data1URL, resp.StatusCode)
	}
	data, err := io.ReadAll(resp.Body)
	if err != nil {
		return fmt.Errorf("read %s: %w", data1URL, err)
	}
	return os.WriteFile(filepath.Join(staticDir, "data1.js"), data, 0o644)
}
