package cmd

import (
	"os"
	"path/filepath"
	"testing"
)

// Test helpers for the ca-120 reclaim suite. All assertions are on
// resulting DIRECTORY STATE (tree present/absent/moved), never on internal
// classification alone — the 9c0daf7 lesson: assert the observable, not the
// mechanism.

func seedAliasNames(t *testing.T, names ...string) {
	t.Helper()
	out := "{"
	for i, n := range names {
		if i > 0 {
			out += ","
		}
		out += `"` + n + `":{"lib":{"build":{"librarian":"x"}}}`
	}
	out += "}"
	if err := os.WriteFile(savedActionAliases, []byte(out), 0o644); err != nil {
		t.Fatal(err)
	}
}

func seedTreePair(t *testing.T, remoteName string, halves ...string) {
	t.Helper()
	if len(halves) == 0 {
		halves = []string{"vfs", "vfsMeta"}
	}
	for _, half := range halves {
		dir := filepath.Join(accorderCacheDir(), half, remoteName, "bucket")
		if err := os.MkdirAll(dir, 0o755); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(filepath.Join(dir, "blob"), []byte("0123456789"), 0o644); err != nil {
			t.Fatal(err)
		}
	}
}

func activateReclaim(t *testing.T) {
	t.Helper()
	if err := withGCLock(writeActivationMarker); err != nil {
		t.Fatalf("activate: %v", err)
	}
}

func ledgerServeStart(t *testing.T, remote, root string) {
	t.Helper()
	if err := withGCLock(func() error {
		return appendLedgerRecord(ledgerRecord{Type: "serve-start", Remote: remote, Root: root, Cmd: "test"})
	}); err != nil {
		t.Fatal(err)
	}
}

func treeExists(half, remoteName string) bool {
	return dirExists(filepath.Join(accorderCacheDir(), half, remoteName))
}

func findTree(t *testing.T, scan *cacheScanResult, remoteName string) cacheTreeInfo {
	t.Helper()
	for _, tr := range scan.Trees {
		if tr.RemoteName == remoteName {
			return tr
		}
	}
	t.Fatalf("tree %s not in scan", remoteName)
	return cacheTreeInfo{}
}

func TestScanClassification(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "motw", "serve-x")

	seedTreePair(t, "accorder-serve-motw")  // owned: alias motw
	seedTreePair(t, "accorder-serve-x")     // owned via BARE parse: alias serve-x exists
	seedTreePair(t, "accorder-serve-lib")   // stranded legacy (no ledger)
	seedTreePair(t, "accorder-serve-gone")  // stranded ledgered
	seedTreePair(t, "accorder-half", "vfs") // stranded legacy, half pair
	seedTreePair(t, "notaccorder")          // foreign
	ledgerServeStart(t, "accorder-serve-gone", "bucket")

	// Orphaned build snapshot vs owned one.
	_ = os.WriteFile(filepath.Join(accorderCacheDir(), "deadalias.jsonl"), []byte("{}"), 0o644)
	_ = os.WriteFile(filepath.Join(accorderCacheDir(), "motw.jsonl"), []byte("{}"), 0o644)

	scan, err := scanCacheTrees(defaultSizeBudget)
	if err != nil {
		t.Fatal(err)
	}
	if !scan.AliasesOK || !scan.LedgerOK {
		t.Fatalf("AliasesOK=%v LedgerOK=%v", scan.AliasesOK, scan.LedgerOK)
	}
	if got := findTree(t, scan, "accorder-serve-motw").Class; got != treeOwned {
		t.Errorf("accorder-serve-motw = %v, want owned", got)
	}
	if got := findTree(t, scan, "accorder-serve-x").Class; got != treeOwned {
		t.Errorf("accorder-serve-x = %v, want owned (ambiguous parse keeps alive)", got)
	}
	if got := findTree(t, scan, "accorder-serve-lib").Class; got != treeStrandedLegacy {
		t.Errorf("accorder-serve-lib = %v, want stranded legacy", got)
	}
	if got := findTree(t, scan, "accorder-serve-gone").Class; got != treeStrandedLedgered {
		t.Errorf("accorder-serve-gone = %v, want stranded ledgered", got)
	}
	half := findTree(t, scan, "accorder-half")
	if half.Class != treeStrandedLegacy || !half.HasVFS || half.HasMeta {
		t.Errorf("accorder-half = %v HasVFS=%v HasMeta=%v, want legacy half pair", half.Class, half.HasVFS, half.HasMeta)
	}
	if got := findTree(t, scan, "notaccorder").Class; got != treeForeign {
		t.Errorf("notaccorder = %v, want foreign", got)
	}
	if len(scan.RetainedJSONL) != 1 || filepath.Base(scan.RetainedJSONL[0]) != "deadalias.jsonl" {
		t.Errorf("RetainedJSONL = %v, want exactly deadalias.jsonl", scan.RetainedJSONL)
	}
	if findTree(t, scan, "accorder-serve-gone").SizeBytes == 0 {
		t.Error("stranded tree size not measured")
	}
}

func TestScan_MalformedLedgerDegradesToLegacy(t *testing.T) {
	testSetup(t)
	seedAliasNames(t)
	seedTreePair(t, "accorder-serve-gone")
	ledgerServeStart(t, "accorder-serve-gone", "bucket")

	// Corrupt an interior line: not a truncated tail, genuinely malformed.
	if err := os.WriteFile(identityLedgerPath(), []byte("{malformed}\n"), 0o600); err != nil {
		t.Fatal(err)
	}
	scan, err := scanCacheTrees(defaultSizeBudget)
	if err != nil {
		t.Fatal(err)
	}
	if scan.LedgerOK {
		t.Fatal("malformed ledger not detected")
	}
	if got := findTree(t, scan, "accorder-serve-gone").Class; got != treeStrandedLegacy {
		t.Errorf("class = %v, want legacy (ledgered unprovable under malformed ledger)", got)
	}
}

func TestDeleteStrandedTree_PreActivationReportOnly(t *testing.T) {
	testSetup(t)
	seedAliasNames(t)
	seedTreePair(t, "accorder-serve-gone")
	ledgerServeStart(t, "accorder-serve-gone", "bucket")
	scan, _ := scanCacheTrees(defaultSizeBudget)
	deleted, reason, err := deleteStrandedTree(findTree(t, scan, "accorder-serve-gone"), false)
	if err != nil {
		t.Fatal(err)
	}
	if deleted || reason == "" {
		t.Fatalf("pre-activation delete happened (deleted=%v reason=%q)", deleted, reason)
	}
	if !treeExists("vfs", "accorder-serve-gone") || !treeExists("vfsMeta", "accorder-serve-gone") {
		t.Fatal("tree touched pre-activation")
	}
}

func TestDeleteStrandedTree_LedgeredDeletedAndTombstoned(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "motw")
	seedTreePair(t, "accorder-serve-gone")
	ledgerServeStart(t, "accorder-serve-gone", "bucket")
	activateReclaim(t)
	scan, _ := scanCacheTrees(defaultSizeBudget)
	deleted, reason, err := deleteStrandedTree(findTree(t, scan, "accorder-serve-gone"), false)
	if err != nil || !deleted {
		t.Fatalf("deleted=%v reason=%q err=%v", deleted, reason, err)
	}
	if treeExists("vfs", "accorder-serve-gone") || treeExists("vfsMeta", "accorder-serve-gone") {
		t.Fatal("tree halves still present")
	}
	records, malformed, _ := readLedger()
	if malformed {
		t.Fatal("ledger malformed after tombstone")
	}
	view := replayLedger(records)
	if len(view.activeRoots["accorder-serve-gone"]) != 0 {
		t.Fatal("root not tombstoned")
	}
}

func TestDeleteStrandedTree_LegacyNeedsAttestation(t *testing.T) {
	testSetup(t)
	seedAliasNames(t)
	seedTreePair(t, "accorder-serve-lib")
	activateReclaim(t)
	scan, _ := scanCacheTrees(defaultSizeBudget)
	tree := findTree(t, scan, "accorder-serve-lib")

	deleted, reason, err := deleteStrandedTree(tree, false)
	if err != nil {
		t.Fatal(err)
	}
	if deleted || reason == "" {
		t.Fatalf("legacy tree deleted without attestation (reason=%q)", reason)
	}
	if !treeExists("vfs", "accorder-serve-lib") {
		t.Fatal("legacy tree touched without attestation")
	}

	deleted, _, err = deleteStrandedTree(tree, true)
	if err != nil || !deleted {
		t.Fatalf("attested legacy delete failed: deleted=%v err=%v", deleted, err)
	}
	if treeExists("vfs", "accorder-serve-lib") || treeExists("vfsMeta", "accorder-serve-lib") {
		t.Fatal("attested legacy tree still present")
	}
}

func TestDeleteStrandedTree_ContendedLockSkips(t *testing.T) {
	testSetup(t)
	seedAliasNames(t)
	seedTreePair(t, "accorder-serve-gone")
	ledgerServeStart(t, "accorder-serve-gone", "bucket")
	activateReclaim(t)

	// Simulate a running serve: hold the mutation lock from "outside".
	rel, ok, err := acquireMutationLock("accorder-serve-gone", "bucket")
	if err != nil || !ok {
		t.Fatalf("test lock: ok=%v err=%v", ok, err)
	}
	defer rel()

	scan, _ := scanCacheTrees(defaultSizeBudget)
	deleted, reason, err := deleteStrandedTree(findTree(t, scan, "accorder-serve-gone"), false)
	if err != nil {
		t.Fatal(err)
	}
	if deleted {
		t.Fatal("deleted a tree whose mutation lock was held")
	}
	if reason == "" || !treeExists("vfs", "accorder-serve-gone") {
		t.Fatalf("expected contended skip, reason=%q", reason)
	}
}

func TestDeleteStrandedTree_CorruptAliasesFailsClosed(t *testing.T) {
	testSetup(t)
	seedAliasNames(t)
	seedTreePair(t, "accorder-serve-gone")
	ledgerServeStart(t, "accorder-serve-gone", "bucket")
	activateReclaim(t)
	scan, _ := scanCacheTrees(defaultSizeBudget)
	tree := findTree(t, scan, "accorder-serve-gone")

	// Corrupt the alias file AFTER the scan: the pre-deletion revalidation
	// must fail closed.
	if err := os.WriteFile(savedActionAliases, []byte("{not json"), 0o644); err != nil {
		t.Fatal(err)
	}
	deleted, reason, err := deleteStrandedTree(tree, true)
	if err != nil {
		t.Fatal(err)
	}
	if deleted || !treeExists("vfs", "accorder-serve-gone") {
		t.Fatalf("deletion did not fail closed on corrupt aliases (reason=%q)", reason)
	}
}

func TestDeleteStrandedTree_BecameOwnedIsRetained(t *testing.T) {
	testSetup(t)
	seedAliasNames(t)
	seedTreePair(t, "accorder-serve-gone")
	ledgerServeStart(t, "accorder-serve-gone", "bucket")
	activateReclaim(t)
	scan, _ := scanCacheTrees(defaultSizeBudget)
	tree := findTree(t, scan, "accorder-serve-gone")

	// The alias appears between scan and apply: revalidation retains.
	seedAliasNames(t, "gone")
	deleted, reason, err := deleteStrandedTree(tree, true)
	if err != nil {
		t.Fatal(err)
	}
	if deleted || !treeExists("vfs", "accorder-serve-gone") {
		t.Fatalf("tree deleted although it became owned (reason=%q)", reason)
	}
}

func TestRemoteNameCandidates(t *testing.T) {
	got := remoteNameCandidates("accorder-serve-motw")
	want := map[string]bool{"motw": true, "serve-motw": true}
	if len(got) != 2 || !want[got[0]] || !want[got[1]] {
		t.Fatalf("candidates = %v", got)
	}
	if c := remoteNameCandidates("other-motw"); len(c) != 0 {
		t.Fatalf("non-accorder name produced candidates: %v", c)
	}
	got = remoteNameCandidates("accorder-serve-motw-assets")
	want = map[string]bool{"motw-assets": true, "motw": true, "serve-motw-assets": true}
	if len(got) != len(want) {
		t.Fatalf("assets candidates = %v, want %v", got, want)
	}
	for _, candidate := range got {
		if !want[candidate] {
			t.Fatalf("assets candidates = %v, unexpected %q", got, candidate)
		}
	}
}

func TestAssetsCacheRemoteCollisions(t *testing.T) {
	aliases := map[string]bool{
		"motw":                  true,
		"motw-assets":           true,
		"serve-motw-assets":     true,
		"funnel-motw-assets":    true,
		"unrelated-clean-alias": true,
	}
	collisions := assetsCacheRemoteCollisions(aliases)
	if len(collisions) != 4 {
		t.Fatalf("collisions=%v, want four assets-involved role pairs", collisions)
	}
	if err := validateAssetsCacheRemoteCollisions(aliases, "motw"); err == nil {
		t.Fatal("target alias collision accepted")
	}
	if err := validateAssetsCacheRemoteCollisions(aliases, "unrelated-clean-alias"); err != nil {
		t.Fatalf("unrelated clean alias blocked: %v", err)
	}
}

func TestServeCacheStartupManyLedgersBothIdentities(t *testing.T) {
	testSetup(t)
	release, err := serveCacheStartupMany("test aggregate", []cacheTreeIdentity{
		{RemoteName: "accorder-serve-motw", RemoteRoot: "bucket"},
		{RemoteName: "accorder-serve-motw-assets", RemoteRoot: "bucket"},
	})
	if err != nil {
		t.Fatal(err)
	}
	release()
	records, malformed, err := readLedger()
	if err != nil || malformed {
		t.Fatalf("read ledger: malformed=%v err=%v", malformed, err)
	}
	view := replayLedger(records)
	for _, remote := range []string{"accorder-serve-motw", "accorder-serve-motw-assets"} {
		if !view.activeRoots[remote]["bucket"] {
			t.Fatalf("missing ledger identity %s: %v", remote, view.activeRoots)
		}
	}
}
