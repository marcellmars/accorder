package cmd

import (
	"accorder/pkg/calibre"
	"encoding/hex"
	"fmt"
	"io"
	"log"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strings"

	"github.com/klauspost/compress/zstd"
)

func httpGet200(client *http.Client, url string) (*http.Response, error) {
	resp, err := client.Get(url)
	if err != nil {
		return nil, fmt.Errorf("GET %s: %w", url, err)
	}
	if resp.StatusCode != http.StatusOK {
		resp.Body.Close()
		return nil, fmt.Errorf("GET %s: status %d", url, resp.StatusCode)
	}
	return resp, nil
}

type LibIndexDownloadCmd struct {
	CommonCommandFields
	PointerURL string `name:"pointer-url" json:"pointer-url" help:"URL of the <lib>.manifest.json pointer file." validate:"omitempty,url" sharedgroup:"lib"`
	CacheDir   string `name:"cache-dir" json:"cache-dir" help:"Local directory for cached index files." validate:"omitempty" sharedgroup:"lib"`
	Mode       string `name:"mode" json:"-" help:"Sync mode: compact, append, or hybrid." default:"compact" enum:"compact,append,hybrid"`
	Force      *bool  `name:"force" json:"-" help:"Force re-download even if up to date."`
	TeaOutputs
}

var searchSyncHTTPClient = calibre.NewSyncHTTPClient()

func (c *LibIndexDownloadCmd) Run() error {
	c.Header = ".◟◜calibre search-sync◝◞."
	if c.HandleShowConfig(c) {
		return nil
	}
	if c.PointerURL == "" {
		return fmt.Errorf("missing required flag: --pointer-url")
	}
	if c.CacheDir == "" {
		return fmt.Errorf("missing required flag: --cache-dir")
	}
	if err := os.MkdirAll(c.CacheDir, 0o755); err != nil {
		return fmt.Errorf("create cache dir %s: %w", c.CacheDir, err)
	}

	pointerBase, err := url.Parse(c.PointerURL)
	if err != nil {
		return fmt.Errorf("parse pointer URL: %w", err)
	}
	pf, err := fetchPointerFile(c.PointerURL, searchSyncHTTPClient)
	if err != nil {
		return fmt.Errorf("fetch pointer file: %w", err)
	}
	if pf.Library.UUID == "" {
		return fmt.Errorf("pointer file has empty library.uuid; cannot key the local cache safely")
	}

	indexURL, err := calibre.ResolveRelativeURL(pointerBase, pf.Index.URL)
	if err != nil {
		return fmt.Errorf("resolve index URL: %w", err)
	}

	cachedState, err := calibre.LoadSyncState(c.CacheDir, pf.Library.UUID)
	if err != nil && !os.IsNotExist(err) {
		return fmt.Errorf("load sync state: %w", err)
	}

	action := calibre.DetermineSyncAction(cachedState, pf, c.Mode, c.Force != nil && *c.Force)

	localPath := filepath.Join(c.CacheDir, pf.Library.UUID+".zst")
	switch action.Kind {
	case calibre.SyncNoOp:
		fmt.Fprintf(os.Stderr, "Up to date — no sync needed. (%s)\n", action.Reason)
	case calibre.SyncFullDownload:
		fmt.Fprintf(os.Stderr, "Downloading %s (%s)...\n", indexURL, action.Reason)
		if err := downloadFull(indexURL, localPath, searchSyncHTTPClient); err != nil {
			return fmt.Errorf("download: %w", err)
		}
		fmt.Fprintf(os.Stderr, "Downloaded to %s\n", localPath)
	case calibre.SyncRangeFetch:
		fmt.Fprintf(os.Stderr, "Range-fetch %s (%s)...\n", indexURL, action.Reason)
		if err := rangeFetchTail(indexURL, localPath, cachedState, pf, searchSyncHTTPClient); err != nil {
			return fmt.Errorf("range fetch: %w", err)
		}
		fmt.Fprintf(os.Stderr, "Updated %s\n", localPath)
	}

	if action.Kind != calibre.SyncNoOp {
		if err := calibre.SaveSyncState(c.CacheDir, pf.Library.UUID, pf); err != nil {
			return fmt.Errorf("save sync state: %w", err)
		}
	}

	return nil
}

func fetchPointerFile(pointerURL string, client *http.Client) (calibre.PointerFile, error) {
	resp, err := httpGet200(client, pointerURL)
	if err != nil {
		return calibre.PointerFile{}, err
	}
	defer resp.Body.Close()
	pf, err := calibre.DecodePointerFile(resp.Body)
	if err != nil {
		return calibre.PointerFile{}, fmt.Errorf("GET %s: %w", pointerURL, err)
	}
	return pf, nil
}

func downloadFull(indexURL, localPath string, client *http.Client) error {
	resp, err := httpGet200(client, indexURL)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	tmp := localPath + ".tmp"
	f, err := os.Create(tmp)
	if err != nil {
		return fmt.Errorf("create %s: %w", tmp, err)
	}
	pr := newProgressReader(resp.Body, resp.ContentLength, "  index")
	if _, err := io.Copy(f, pr); err != nil {
		pr.finish()
		f.Close()
		os.Remove(tmp)
		return fmt.Errorf("write %s: %w", tmp, err)
	}
	if err := f.Sync(); err != nil {
		f.Close()
		os.Remove(tmp)
		return fmt.Errorf("sync %s: %w", tmp, err)
	}
	if err := f.Close(); err != nil {
		os.Remove(tmp)
		return fmt.Errorf("close %s: %w", tmp, err)
	}
	if err := os.Rename(tmp, localPath); err != nil {
		os.Remove(tmp)
		return fmt.Errorf("rename %s -> %s: %w", tmp, localPath, err)
	}
	clearCompiledMark(localPath)
	return nil
}

func compiledMarkPath(localPath string) string { return localPath + ".compiled" }

func markCompiled(localPath string) { _ = os.WriteFile(compiledMarkPath(localPath), nil, 0o644) }

func clearCompiledMark(localPath string) { _ = os.Remove(compiledMarkPath(localPath)) }

func isLocallyCompiled(localPath string) bool {
	_, err := os.Stat(compiledMarkPath(localPath))
	return err == nil
}

func rangeFetchAllowed(localPath string) bool {
	return !isLocallyCompiled(localPath)
}

func rangeFetchTail(indexURL, localPath string, cached *calibre.CachedSyncState, pf calibre.PointerFile, client *http.Client) error {
	_ = cached

	truncateAt, err := calibre.ComputeRangeFetchOffset(localPath)
	if err != nil {
		return fmt.Errorf("compute range-fetch offset: %w", err)
	}

	headResp, err := client.Head(indexURL)
	if err != nil {
		return fmt.Errorf("HEAD %s: %w", indexURL, err)
	}
	headResp.Body.Close()
	remoteSize := headResp.ContentLength
	if remoteSize < 0 {
		return fmt.Errorf("HEAD %s: no Content-Length", indexURL)
	}

	if remoteSize <= truncateAt {
		fmt.Fprintf(os.Stderr, "Range-fetch: remote size %d <= local truncation %d — full download.\n",
			remoteSize, truncateAt)
		return downloadFull(indexURL, localPath, client)
	}

	req, err := http.NewRequest("GET", indexURL, nil)
	if err != nil {
		return fmt.Errorf("range-fetch request: %w", err)
	}
	req.Header.Set("Range", fmt.Sprintf("bytes=%d-", truncateAt))
	resp, err := client.Do(req)
	if err != nil {
		return fmt.Errorf("range-fetch: %w", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusPartialContent {
		return fmt.Errorf("range-fetch: expected 206, got %d", resp.StatusCode)
	}

	tmp := localPath + ".tmp"
	pr := newProgressReader(resp.Body, remoteSize-truncateAt, "  index (delta)")
	if err := spliceToTemp(tmp, localPath, truncateAt, pr); err != nil {
		pr.finish()
		os.Remove(tmp)
		return err
	}

	mf, vErr := calibre.ReadManifestFromZst(tmp)
	if vErr != nil || hex.EncodeToString(mf.BaseGeneration[:]) != pf.Index.BaseGeneration {
		os.Remove(tmp)
		fmt.Fprintf(os.Stderr, "Range-fetch: spliced index failed validation (%v) — full download.\n", vErr)
		return downloadFull(indexURL, localPath, client)
	}

	if err := os.Rename(tmp, localPath); err != nil {
		os.Remove(tmp)
		return fmt.Errorf("rename %s -> %s: %w", tmp, localPath, err)
	}
	return nil
}

func compileFromJSONL(pf calibre.PointerFile, pointerBase *url.URL, localPath string, client *http.Client) error {
	jsonlURL, err := calibre.ResolveRelativeURL(pointerBase, pf.Index.JsonlURL)
	if err != nil {
		return fmt.Errorf("resolve JSONL URL: %w", err)
	}

	log.Printf("browse: compiling index from JSONL (%d books, %.1f MB JSONL)...",
		pf.Index.NumBooks, float64(pf.Index.JsonlBytes)/1e6)

	resp, err := httpGet200(client, jsonlURL)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	tmpDir := filepath.Dir(localPath)
	jsonlTmp, err := os.CreateTemp(tmpDir, "jsonl-compile-*.jsonl")
	if err != nil {
		return fmt.Errorf("create temp jsonl: %w", err)
	}
	jsonlTmpPath := jsonlTmp.Name()
	defer os.Remove(jsonlTmpPath)

	pr := newProgressReader(resp.Body, resp.ContentLength, "  jsonl")
	zr, zErr := zstd.NewReader(pr)
	if zErr != nil {
		pr.finish()
		jsonlTmp.Close()
		return fmt.Errorf("zstd reader: %w", zErr)
	}
	if _, err := io.Copy(jsonlTmp, zr); err != nil {
		zr.Close()
		pr.finish()
		jsonlTmp.Close()
		return fmt.Errorf("decompress JSONL: %w", err)
	}
	zr.Close()
	if err := jsonlTmp.Close(); err != nil {
		return fmt.Errorf("close temp jsonl: %w", err)
	}

	var baseGen [16]byte
	bgBytes, bgErr := hex.DecodeString(pf.Index.BaseGeneration)
	if bgErr != nil || len(bgBytes) != 16 {
		return fmt.Errorf("decode BaseGeneration %q: %w", pf.Index.BaseGeneration, bgErr)
	}
	copy(baseGen[:], bgBytes)

	indexPath := strings.TrimSuffix(localPath, ".zst")

	ms := &calibre.MotwSearch{
		JsonlPath:            jsonlTmpPath,
		IndexPath:            indexPath,
		BaseGeneration:       &baseGen,
		StartGeneration:      pf.Index.PointerGeneration,
		IndexAggregateFields: pf.Index.IndexAggregateFields,
		DictID:               pf.Index.DictID,
		ChunkSize:            int(pf.Index.ChunkSize),
	}

	if err := buildAndCompileLocal(ms, localPath); err != nil {
		return err
	}

	log.Printf("browse: index compiled (%d books)", pf.Index.NumBooks)
	return nil
}

func buildAndCompileLocal(ms *calibre.MotwSearch, localPath string) error {
	idx, err := ms.BuildIndex()
	if err != nil {
		return fmt.Errorf("BuildIndex: %w", err)
	}

	realBase := ms.IndexPath
	tmpBase := realBase + ".rebuild"
	ms.IndexPath = tmpBase
	defer func() { ms.IndexPath = realBase }()

	if err := ms.CompressToFile(idx); err != nil {
		os.Remove(tmpBase + ".zst")
		return fmt.Errorf("CompressToFile: %w", err)
	}
	if err := os.Rename(tmpBase+".zst", localPath); err != nil {
		os.Remove(tmpBase + ".zst")
		return fmt.Errorf("install index: %w", err)
	}

	markCompiled(localPath)
	return nil
}

func downloadIndexToBrowseCache(endpoint string) (uuid string, downloaded bool, err error) {
	baseURL := endpoint
	if !strings.HasSuffix(baseURL, "/") {
		baseURL += "/"
	}
	pointerURL := baseURL + "static/library_index.manifest.json"
	pf, err := fetchPointerFile(pointerURL, searchSyncHTTPClient)
	if err != nil {
		return "", false, fmt.Errorf("fetch pointer file: %w", err)
	}
	if pf.Library.UUID == "" {
		return "", false, fmt.Errorf("pointer file has empty library.uuid")
	}
	uuid = pf.Library.UUID

	cacheDir := filepath.Join(accorderConfigDir, "tor", "cache", uuid)
	staticDir := filepath.Join(cacheDir, "static")
	if cachedIndexUsable(staticDir) {
		return uuid, false, nil
	}
	if err := os.MkdirAll(staticDir, 0o755); err != nil {
		return "", false, fmt.Errorf("create cache dir: %w", err)
	}

	pointerBase, _ := url.Parse(pointerURL)
	indexURL := baseURL + "static/library_index.zst"
	if resolved, rErr := calibre.ResolveRelativeURL(pointerBase, pf.Index.URL); rErr == nil && resolved != "" {
		indexURL = resolved
	}

	fmt.Fprintf(os.Stderr, "Downloading index (%d books)...\n", pf.Index.NumBooks)
	localPath := filepath.Join(staticDir, "library_index.zst")
	if err := downloadFull(indexURL, localPath, searchSyncHTTPClient); err != nil {
		return "", false, err
	}
	if err := calibre.SaveSyncState(cacheDir, uuid, pf); err != nil {
		return uuid, true, fmt.Errorf("save sync state: %w", err)
	}
	return uuid, true, nil
}

func spliceToTemp(tmp, localPath string, truncateAt int64, tail io.Reader) error {
	src, err := os.Open(localPath)
	if err != nil {
		return fmt.Errorf("open local: %w", err)
	}
	defer src.Close()
	dst, err := os.Create(tmp)
	if err != nil {
		return fmt.Errorf("create temp: %w", err)
	}
	defer dst.Close()
	if _, err := io.CopyN(dst, src, truncateAt); err != nil {
		return fmt.Errorf("copy prefix: %w", err)
	}
	if _, err := io.Copy(dst, tail); err != nil {
		return fmt.Errorf("write tail: %w", err)
	}
	if err := dst.Sync(); err != nil {
		return fmt.Errorf("sync temp: %w", err)
	}
	return nil
}
