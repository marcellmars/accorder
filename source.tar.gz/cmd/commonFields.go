package cmd

import (
	"fmt"
	"strings"
)

type CommonCommandFields struct {
	ActionAlias string `arg:"" optional:"" json:"action_alias" help:"Alias for this configuration. If omitted, 'default' is used." default:"default" validate:"required,alias"`
	ShowConfig  *bool  `short:"s" help:"Print this command's effective configuration — every setting, its value, and where the value came from (flag, alias, descriptor, keys-file, env or default) — then exit without running or saving anything. Credentials are never printed as values." json:"-"`

	// showConfigCtx carries the provenance table and kong grammar nodes
	// from AfterApply, where kong.Context is in scope, to HandleShowConfig,
	// where it is not. Unexported so kong's struct walker and
	// json.Unmarshal both ignore it — no kong:"-" tag needed.
	showConfigCtx *showConfigContext
}

// showConfigRequested reports whether -s was passed. Read by AfterApply to
// enter read-only mode before any mutation happens.
func (c *CommonCommandFields) showConfigRequested() bool {
	return c.ShowConfig != nil && *c.ShowConfig
}

func (c *CommonCommandFields) setShowConfigContext(sc *showConfigContext) {
	c.showConfigCtx = sc
}

func (c *CommonCommandFields) showConfigContext() *showConfigContext {
	return c.showConfigCtx
}

// HandleShowConfig renders the effective configuration and reports whether
// the caller should return early. It resolves first: a command that fills
// fields from its federation descriptor or derives defaults must do so
// before rendering, or the view reports values the command would discard.
func (c *CommonCommandFields) HandleShowConfig(cmd any) bool {
	if !c.showConfigRequested() {
		return false
	}

	sc := c.showConfigCtx
	if sc == nil {
		// No AfterApply ran (direct construction in tests). Render what we
		// can rather than crashing; provenance shows as unknown.
		sc = &showConfigContext{provenance: newProvenanceTable(), readOnly: true}
	}

	if r, ok := cmd.(EffectiveResolver); ok {
		sc.addIssues(r.ResolveEffective()...)
	}

	var out strings.Builder
	renderEffectiveConfig(&out, cmd, sc)
	fmt.Fprint(showConfigOut, out.String())
	return true
}

type TeaOutputs struct {
	InPipeline bool   `kong:"-" json:"-"`
	Header     string `kong:"-" json:"-"`
}
