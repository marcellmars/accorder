package cmd

import (
	"fmt"
	"os"
	"path/filepath"

	"github.com/goccy/go-json"
)

const fedlibDescriptorVersion = 1

type fedlibDescriptor struct {
	Version      int    `json:"version,omitempty"`
	Bucket       string `json:"bucket,omitempty"`
	S3Provider   string `json:"s3_provider,omitempty"`
	S3Endpoint   string `json:"s3_endpoint,omitempty"`
	UploadPrefix string `json:"upload_prefix,omitempty"`
	KeysFile     string `json:"keys_file,omitempty"`
	Mode         string `json:"mode,omitempty"`
	Endpoint     string `json:"endpoint,omitempty"`
	OfferExpiry  string `json:"offer_expiry,omitempty"`
	FedlibPath   string `json:"fedlib_path,omitempty"`
	RootKeysFile string `json:"root_keys_file,omitempty"`
	IAMEndpoint  string `json:"iam_endpoint,omitempty"`
	NextDictID   uint32 `json:"next_dict_id,omitempty"`
}

func fedlibDescriptorPath() string {
	return filepath.Join(accorderConfigDir, "fedlibs.json")
}

func loadFedlibDescriptor(fedlibID string) fedlibDescriptor {
	data, err := os.ReadFile(fedlibDescriptorPath())
	if err != nil {
		return fedlibDescriptor{}
	}
	var all map[string]fedlibDescriptor
	if err := json.Unmarshal(data, &all); err != nil {
		return fedlibDescriptor{}
	}
	return all[fedlibID]
}

func requireFedlibDescriptor(cmdName, fedlibID string) (fedlibDescriptor, error) {
	desc := loadFedlibDescriptor(fedlibID)
	if desc.Version == 0 {
		return desc, fmt.Errorf("%s: %q names no federation descriptor — run 'fedlib config set %s ...' first", cmdName, fedlibID, fedlibID)
	}
	return desc, nil
}

func loadAllFedlibDescriptors() map[string]fedlibDescriptor {
	data, err := os.ReadFile(fedlibDescriptorPath())
	if err != nil {
		return nil
	}
	var all map[string]fedlibDescriptor
	if err := json.Unmarshal(data, &all); err != nil {
		return nil
	}
	return all
}

func saveFedlibDescriptor(fedlibID string, d fedlibDescriptor) error {
	path := fedlibDescriptorPath()
	all := map[string]fedlibDescriptor{}
	if data, err := os.ReadFile(path); err == nil {
		_ = json.Unmarshal(data, &all)
	}
	all[fedlibID] = d

	data, err := json.MarshalIndent(all, "", "  ")
	if err != nil {
		return fmt.Errorf("fedlib descriptor: marshal: %w", err)
	}
	if err := ensureConfigDir(path); err != nil {
		return fmt.Errorf("fedlib descriptor: %w", err)
	}
	if err := atomicWriteFile(path, data, 0o600); err != nil {
		return fmt.Errorf("fedlib descriptor: %w", err)
	}
	return nil
}

func allocateMemberDictID(fedlibID string) (uint32, error) {
	lockPath := fedlibDescriptorPath() + ".lock"
	if err := ensureConfigDir(lockPath); err != nil {
		return 0, fmt.Errorf("allocateMemberDictID: %w", err)
	}
	lockFile, err := os.OpenFile(lockPath, os.O_CREATE|os.O_RDWR, 0o600)
	if err != nil {
		return 0, fmt.Errorf("allocateMemberDictID: open lock: %w", err)
	}
	defer lockFile.Close()
	unlock, err := lockFileExclusive(lockFile)
	if err != nil {
		return 0, fmt.Errorf("allocateMemberDictID: lock: %w", err)
	}
	defer unlock()

	desc := loadFedlibDescriptor(fedlibID)
	if desc.NextDictID < 2 {
		desc.NextDictID = 2
	}
	id := desc.NextDictID
	desc.NextDictID++
	desc.Version = fedlibDescriptorVersion
	if err := saveFedlibDescriptor(fedlibID, desc); err != nil {
		return 0, err
	}
	return id, nil
}
