package cmd

import (
	"log"
	"os"
	"path/filepath"
	"strings"
)

func reapStaleDicts(cacheDir string) {
	if ok, _ := destructiveReclaimAllowed(); !ok {
		return
	}
	err := withGCLock(func() error {
		held, err := heldLeaseDicts()
		if err != nil {
			log.Printf("dict reaper: lease snapshot unavailable, reaping nothing: %v", err)
			return nil
		}
		records, malformed, err := readLedger()
		if err != nil || malformed {
			log.Printf("dict reaper: ledger unavailable or malformed, reaping nothing")
			return nil
		}
		view := replayLedger(records)
		entries, err := os.ReadDir(cacheDir)
		if err != nil {
			return nil
		}
		for _, e := range entries {
			name := e.Name()
			if e.IsDir() {
				continue
			}
			if strings.HasPrefix(name, "typeahead-") && strings.HasSuffix(name, ".dict.tmp") {
				if rerr := os.Remove(filepath.Join(cacheDir, name)); rerr == nil {
					log.Printf("dict reaper: removed crash-stranded temp %s", name)
				}
				continue
			}
			if !strings.HasSuffix(name, ".dict") || !validDictFile(name) {
				continue
			}
			if held[name] {
				continue
			}
			if !view.knownDicts[name] {
				continue
			}
			if rerr := os.Remove(filepath.Join(cacheDir, name)); rerr != nil {
				log.Printf("dict reaper: remove %s: %v", name, rerr)
				continue
			}
			if view.activeDicts[name] {
				if aerr := appendLedgerRecord(ledgerRecord{Type: "delete", DictFile: name, Cmd: "dict reaper"}); aerr != nil {
					log.Printf("dict reaper: tombstone %s: %v", name, aerr)
				}
			}
			log.Printf("dict reaper: removed stale dict %s", name)
		}
		return nil
	})
	if err != nil {
		log.Printf("dict reaper: %v", err)
	}
}

func reapLegacyDictsAttested(cacheDir string) (int64, int) {
	var reclaimed int64
	count := 0
	if ok, _ := destructiveReclaimAllowed(); !ok {
		return 0, 0
	}
	_ = withGCLock(func() error {
		held, err := heldLeaseDicts()
		if err != nil {
			log.Printf("legacy dict reap: lease snapshot unavailable, reaping nothing: %v", err)
			return nil
		}
		records, malformed, err := readLedger()
		if err != nil || malformed {
			log.Printf("legacy dict reap: ledger unavailable or malformed, reaping nothing")
			return nil
		}
		view := replayLedger(records)
		entries, err := os.ReadDir(cacheDir)
		if err != nil {
			return nil
		}
		for _, e := range entries {
			name := e.Name()
			if e.IsDir() || !strings.HasSuffix(name, ".dict") || !validDictFile(name) {
				continue
			}
			if held[name] || view.knownDicts[name] {
				continue
			}
			info, ierr := e.Info()
			if rerr := os.Remove(filepath.Join(cacheDir, name)); rerr != nil {
				log.Printf("legacy dict reap: remove %s: %v", name, rerr)
				continue
			}
			if ierr == nil {
				reclaimed += info.Size()
			}
			count++
		}
		return nil
	})
	return reclaimed, count
}
