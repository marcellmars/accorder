//go:build !windows

package cmd

import "os"

func tryLibraryLockExclusive(f *os.File) (release func(), ok bool, err error) {
	return tryLockFileExclusive(f)
}
