package cmd

import (
	"bytes"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"accorder/pkg/calibre"
	"accorder/pkg/libraryflow"
	"accorder/pkg/rclonexfer"
)

type boundGenerationPublication struct {
	ManifestPath      string
	ManifestBytes     []byte
	CatalogChecksum   string
	Scope             string
	Reason            string
	ForcePaths        []string
	CompleteOverwrite bool
	ContentLedger     []libraryflow.Object
}

func bindGenerationPublication(initial remoteLibrarySnapshot, pointer calibre.PointerFile, candidate *libraryCandidate, targetToken []byte, baselineRemoteSource string) (boundGenerationPublication, error) {
	bound := boundGenerationPublication{}
	if candidate.Change == nil {
		if candidate.SourceContract == calibre.CatalogSourceContract {
			return bound, errors.New("no current Calibre build is available; run `accorder lib build` before publishing or previewing")
		}
		// Compatibility path for a full upload made without a current build
		// candidate. It may commit using the legacy pointer contract, but it may
		// not claim exact invalidation and must overwrite all current bytes.
		bound.Scope = calibre.GenerationChangeScopeCoarse
		bound.Reason = "missing-build-candidate"
		bound.CatalogChecksum = pointer.CatalogChecksum
		bound.CompleteOverwrite = !remoteSnapshotEmpty(initial)
		return bound, nil
	}
	change := candidate.Change
	if change.ContentLedgerVersion == sourceEvidenceVersion {
		if err := requireSourceCoherence(candidate.Root, change.ContentLedger, change.Evidence); err != nil {
			return bound, err
		}
	}
	if change.LibraryUUID != pointer.Library.UUID ||
		change.TargetSourceFingerprint != candidate.SourceFingerprint || change.ToLiveCount != pointer.Index.NumBooks {
		return bound, errors.New("saved build information no longer matches the library; run `accorder lib build` again")
	}
	bound.CatalogChecksum = change.ToCatalogChecksum
	bound.Scope = calibre.GenerationChangeScopeCoarse
	bound.Reason = change.Reason
	bound.ForcePaths = append([]string(nil), change.ForcePaths...)
	bound.CompleteOverwrite = change.CompleteOverwrite && !remoteSnapshotEmpty(initial)
	bound.ContentLedger = append([]libraryflow.Object(nil), change.ContentLedger...)
	if change.ContentLedgerVersion == sourceEvidenceVersion && !remoteSnapshotEmpty(initial) &&
		(change.FromGeneration != hex.EncodeToString(initial.GenerationRaw) || baselineRemoteSource == "" || baselineRemoteSource != initial.SourceFingerprint) {
		bound.CompleteOverwrite = true
		bound.Reason = "remote-predecessor-mismatch"
	}

	manifest := calibre.GenerationChangeManifest{
		Version: calibre.GenerationChangeManifestVersion, Scope: calibre.GenerationChangeScopeCoarse,
		LibraryUUID: change.LibraryUUID, ToGeneration: hex.EncodeToString(targetToken),
		TargetSourceFingerprint: candidate.SourceFingerprint, ToLiveCount: change.ToLiveCount,
		ToCatalogChecksum: change.ToCatalogChecksum,
	}
	if len(initial.GenerationRaw) > 0 {
		fromCount := initial.Pointer.Index.NumBooks
		manifest.FromGeneration = hex.EncodeToString(initial.GenerationRaw)
		manifest.FromLiveCount = &fromCount
		manifest.FromCatalogChecksum = initial.Pointer.CatalogChecksum
	}
	exact := change.Scope == calibre.GenerationChangeScopeExact && initial.Committed &&
		baselineRemoteSource != "" && initial.SourceFingerprint == baselineRemoteSource &&
		change.FromGeneration == manifest.FromGeneration && change.FromLiveCount != nil &&
		*change.FromLiveCount == initial.Pointer.Index.NumBooks &&
		change.FromCatalogChecksum != "" && change.FromCatalogChecksum == initial.Pointer.CatalogChecksum
	if exact {
		manifest.Scope = calibre.GenerationChangeScopeExact
		bound.Scope = calibre.GenerationChangeScopeExact
		bound.Reason = ""
		manifest.Changes = make([]calibre.GenerationChange, len(change.Changes))
		copy(manifest.Changes, change.Changes)
	} else if change.Scope == calibre.GenerationChangeScopeExact {
		// A different remote predecessor invalidates the local narrow-transfer
		// proof as well as exact cache scope.
		if remoteSnapshotEmpty(initial) {
			bound.Reason = "first-publication"
		} else {
			bound.Reason = "remote-predecessor-mismatch"
		}
		bound.CompleteOverwrite = !remoteSnapshotEmpty(initial)
	}
	data, err := calibre.EncodeGenerationChangeManifest(manifest)
	if err != nil {
		return bound, fmt.Errorf("prepare changed-book list for publication: %w", err)
	}
	bound.ManifestPath = generationChangeManifestPath(manifest.ToGeneration)
	bound.ManifestBytes = data
	return bound, nil
}

func generationChangeManifestPath(targetGeneration string) string {
	return ".accorder/changes/" + targetGeneration + ".manifest.json"
}

func remoteSnapshotEmpty(snapshot remoteLibrarySnapshot) bool {
	return !snapshot.Committed && !snapshot.Legacy && len(snapshot.GenerationRaw) == 0 && len(snapshot.PointerRaw) == 0
}

func executeTransferCorrectness(candidate *libraryCandidate, remote *libraryRemote, bound boundGenerationPublication, excludes []string) error {
	if bound.CompleteOverwrite {
		if err := runPublishCommitStageHook("before-complete-overwrite"); err != nil {
			return err
		}
		jobID, err := rclonexfer.CopyAllOverwrite(candidate.Root, remote.fsPath, nil, rcloneUploadExcludes(excludes))
		if err != nil {
			return err
		}
		var renderErr error
		if interactiveTerminal() {
			renderErr = renderSyncProgress("Verifying all published bytes:", jobID)
		} else {
			renderErr = renderSyncProgressHeadless("Verifying all published bytes:", jobID)
		}
		if renderErr != nil {
			return renderErr
		}
		return runPublishCommitStageHook("after-complete-overwrite")
	}
	// The fast mirror is deliberately SizeOnly: asking S3 for a trustworthy
	// identity for every object made real-library publication take tens of
	// minutes. Derived indexes are allowed to change without changing size,
	// though (a rebuilt zstd container can replace only its lineage bytes), and
	// they are not part of the source-content ledger below. Always overwrite
	// the small pointer-declared derived family before committing its pointer.
	// This is bounded to the index and optional retained JSONL, not the library
	// payload.
	derivedPaths, err := localDerivedPublicationPaths(candidate)
	if err != nil {
		return err
	}
	for index, path := range derivedPaths {
		if err := runPublishCommitStageHook("before-force-copy"); err != nil {
			return err
		}
		if err := rclonexfer.CopyFileOverwrite(candidate.Root, path, remote.fsPath, path); err != nil {
			return fmt.Errorf("upload generated library-index file %d/%d: %w", index+1, len(derivedPaths), err)
		}
		if err := runPublishCommitStageHook("after-force-copy"); err != nil {
			return err
		}
	}
	for index, path := range bound.ForcePaths {
		if candidate.Change != nil && isCatalogEvidence(candidate.Change.Evidence) {
			exists, err := checkCatalogTransferPath(candidate.Root, path, catalogOptionalPath(candidate.Change.Evidence, path))
			if err != nil {
				return err
			}
			if !exists {
				continue
			}
		}
		if err := runPublishCommitStageHook("before-force-copy"); err != nil {
			return err
		}
		if err := rclonexfer.CopyFileOverwrite(candidate.Root, path, remote.fsPath, path); err != nil {
			return fmt.Errorf("upload changed library file %d/%d: %w", index+1, len(bound.ForcePaths), err)
		}
		if err := runPublishCommitStageHook("after-force-copy"); err != nil {
			return err
		}
	}
	return nil
}

// localDerivedPublicationPaths returns the complete derived family named by a
// validated change candidate. readAndValidateDerivedFamily has already proved
// that a present retained JSONL belongs to this index family before callers
// reach the transfer boundary.
func localDerivedPublicationPaths(candidate *libraryCandidate) ([]string, error) {
	if candidate.Change == nil {
		return nil, nil
	}
	indexPath := candidate.Change.IndexArtifact.Path
	paths := []string{indexPath}
	jsonlPath := strings.TrimSuffix(indexPath, ".zst") + ".jsonl.zst"
	_, err := os.Stat(filepath.Join(candidate.Root, filepath.FromSlash(jsonlPath)))
	switch {
	case err == nil:
		paths = append(paths, jsonlPath)
	case os.IsNotExist(err):
	default:
		return nil, fmt.Errorf("inspect generated JSONL index: %w", err)
	}
	return paths, nil
}

// remoteDerivedPublicationMatches prevents the no-op fast path from blessing
// a pointer/sentinel pair whose fixed-name index was retained by an earlier
// SizeOnly collision. Only a would-be no-op pays these two small downloads.
func remoteDerivedPublicationMatches(candidate *libraryCandidate, remote *libraryRemote) (bool, error) {
	paths, err := localDerivedPublicationPaths(candidate)
	if err != nil {
		return false, err
	}
	for _, path := range paths {
		localPath := filepath.Join(candidate.Root, filepath.FromSlash(path))
		info, err := os.Stat(localPath)
		if err != nil {
			return false, err
		}
		localDigest := ""
		if path == candidate.Change.IndexArtifact.Path {
			localDigest = candidate.Change.IndexArtifact.Hash
		} else {
			localDigest, err = hashLocalFile(localPath)
			if err != nil {
				return false, err
			}
		}
		remoteDigest, err := remote.hash(path, info.Size())
		if errors.Is(err, errRemoteObjectNotFound) {
			return false, nil
		}
		if err != nil {
			return false, err
		}
		if remoteDigest != localDigest {
			return false, nil
		}
	}
	return true, nil
}

func verifyLocalPublishCandidate(candidate *libraryCandidate) error {
	finish := beginLibraryWork("publish-coherence")
	defer finish(1)
	if candidate.Change == nil {
		fingerprint, _, err := libraryflow.SourceFingerprint(candidate.Root, candidate.Excludes)
		if err != nil {
			return err
		}
		if fingerprint != candidate.SourceFingerprint {
			return errors.New("library files changed while publishing; the remote update was not activated, so rebuild and publish again")
		}
		return nil
	}
	indexPath := filepath.Join(candidate.Root, filepath.FromSlash(candidate.Change.IndexArtifact.Path))
	info, err := os.Stat(indexPath)
	if err != nil {
		return fmt.Errorf("inspect generated compressed index: %w", err)
	}
	currentIndex := libraryflow.NewLocalObjectAt(candidate.Change.IndexArtifact.Path, indexPath, info)
	if !canReuseContentDigest(currentIndex, candidate.Change.IndexArtifact) {
		digest, hashErr := hashLocalFile(indexPath)
		if hashErr != nil {
			return fmt.Errorf("checksum generated compressed index: %w", hashErr)
		}
		if digest != candidate.Change.IndexArtifact.Hash {
			return errors.New("the generated library index changed while publishing; the remote update was not activated, so rebuild and publish again")
		}
	}
	inventory, err := inventoryForEvidence(candidate.Root, candidate.Change.Evidence, candidate.Change.ContentLedger)
	if err != nil {
		return err
	}
	ledger, _, changed, removed, err := refreshSourceEvidence(candidate.Root, inventory.Objects, candidate.Excludes, candidate.Change.ContentLedger, candidate.Change.Evidence, inventory)
	if err != nil {
		return err
	}
	if len(changed) > 0 || len(removed) > 0 {
		return errors.New("library files changed while publishing; the remote update was not activated, so rebuild and publish again")
	}
	fingerprint, err := sourceFingerprintForEvidence(ledger, candidate.Change.Evidence)
	if err != nil {
		return err
	}
	if fingerprint != candidate.SourceFingerprint {
		return errors.New("library files changed while publishing; the remote update was not activated, so rebuild and publish again")
	}
	loaded, err := loadLocalChangeCandidate(candidate.Root)
	if err != nil {
		return fmt.Errorf("reload saved build information: %w", err)
	}
	expected, err := json.Marshal(candidate.Change)
	if err != nil {
		return fmt.Errorf("verify saved build information: %w", err)
	}
	actual, err := json.Marshal(loaded)
	if err != nil {
		return fmt.Errorf("verify reloaded build information: %w", err)
	}
	if !bytes.Equal(actual, expected) {
		return errors.New("saved build information changed while publishing; the remote update was not activated, so rebuild and publish again")
	}
	return nil
}

func createGenerationChangeManifest(remote *libraryRemote, bound boundGenerationPublication) error {
	if len(bound.ManifestBytes) == 0 {
		return nil
	}
	created, err := remote.createImmutable(bound.ManifestPath, bound.ManifestBytes)
	if err != nil {
		return err
	}
	if created {
		return nil
	}
	existing, err := remote.read(bound.ManifestPath, int64(calibre.DefaultGenerationChangeMaxBytes)+1)
	if err != nil {
		return fmt.Errorf("check existing changed-book record: %w", err)
	}
	if !bytes.Equal(existing, bound.ManifestBytes) {
		return errors.New("a different changed-book record already exists for this publication version; sync and rebuild before publishing again")
	}
	return nil
}

func recoveryManifestMatches(remote *libraryRemote, record publishRecoveryRecord) error {
	if record.ManifestPath == "" && len(record.Manifest) == 0 {
		return nil
	}
	if record.ManifestPath == "" || len(record.Manifest) == 0 {
		return errors.New("saved information for resuming the interrupted publish has an incomplete changed-book record")
	}
	existing, err := remote.read(record.ManifestPath, int64(calibre.DefaultGenerationChangeMaxBytes)+1)
	if err != nil {
		return err
	}
	if !bytes.Equal(existing, record.Manifest) {
		return errors.New("the remote changed-book record differs from the interrupted publish")
	}
	return nil
}

func writeRecoveryStage(alias string, record publishRecoveryRecord, stage string) error {
	record.Stage = stage
	path := legacyPublishRecoveryPath(alias)
	if record.ContentLedgerVersion == sourceEvidenceVersion {
		record.Version = sourceEvidenceVersion
		if err := validateSourceEvidence(record.ContentLedger, record.Evidence); err != nil {
			return err
		}
		var err error
		record.LegacyDigest, err = legacyEvidenceDigest(path)
		if err != nil {
			return err
		}
		path = evidenceStatePath(path)
	}
	return writeJSONAtomic(path, record)
}

func readOptionalRemote(remote *libraryRemote, path string, limit int64) ([]byte, bool, error) {
	data, err := remote.read(path, limit)
	if errors.Is(err, errRemoteObjectNotFound) || errors.Is(err, os.ErrNotExist) {
		return nil, false, nil
	}
	return data, err == nil, err
}
