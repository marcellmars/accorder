package cmd

import (
	"strings"
	"testing"
)

// splitHintLine splits a rendered command line the way a shell would, honoring
// the single quotes the hints put around URLs. Deliberately minimal — it exists
// only to feed a printed line back into the parser.
func splitHintLine(t *testing.T, line string) []string {
	t.Helper()
	var args []string
	var current strings.Builder
	inQuote, started := false, false
	for _, r := range line {
		switch {
		case r == '\'':
			inQuote = !inQuote
			started = true
		case r == ' ' && !inQuote:
			if started || current.Len() > 0 {
				args = append(args, current.String())
				current.Reset()
				started = false
			}
		default:
			current.WriteRune(r)
		}
	}
	if started || current.Len() > 0 {
		args = append(args, current.String())
	}
	return args
}

// Every operator-facing hint renders through joinCommandLine, and what it
// prints must survive the parser. This is the guard the `--alias` regression
// went without: the flag was removed from the grammar, four hint sites kept
// emitting it, and nothing failed until an operator pasted one.
func TestJoinCommandLineParses(t *testing.T) {
	testSetup(t)
	tails := map[string]string{
		"operator (calibre path)": "-c /path/to/calibre/library",
		"peer (endpoint)":         "--endpoint 'https://your-host/'",
		"bare":                    "",
	}
	for name, tail := range tails {
		t.Run(name, func(t *testing.T) {
			line := joinCommandLine("biopolitics", "https://lib.example.org/invite/72spnmx5r7pmaf4q", tail)
			args := splitHintLine(t, line)
			if len(args) == 0 || args[0] != "accorder" {
				t.Fatalf("hint should invoke accorder: %q -> %v", line, args)
			}
			if _, _, err := parseCLIErr(t, args[1:]); err != nil {
				t.Fatalf("printed hint does not parse:\n  %s\n  %v", line, err)
			}
		})
	}
}

// The alias is a positional argument. A hint that prints it as a flag is the
// exact defect this workflow was opened for.
func TestJoinCommandLineUsesPositionalAlias(t *testing.T) {
	line := joinCommandLine("biopolitics", "https://lib.example.org/invite/abc", "-c /path")
	if strings.Contains(line, "--alias") {
		t.Errorf("hint prints the removed --alias flag: %q", line)
	}
	if !strings.HasPrefix(line, "accorder lib join biopolitics --invite ") {
		t.Errorf("hint should name the alias positionally then the invite: %q", line)
	}
}

// memberJoinHint and memberJoinHintURL wrap the same renderer; both blocks an
// operator copies from must parse.
func TestMemberJoinHintsParse(t *testing.T) {
	testSetup(t)
	for name, hint := range map[string]string{
		"blob": memberJoinHint("accorder-fedlib-invite:eyJ0ZXN0IjoxfQ", "biopolitics"),
		"url":  memberJoinHintURL("https://lib.example.org/invite/72spnmx5r7pmaf4q", "biopolitics"),
	} {
		t.Run(name, func(t *testing.T) {
			var joinLines int
			for _, line := range strings.Split(hint, "\n") {
				line = strings.TrimSpace(line)
				if !strings.HasPrefix(line, "accorder lib join") {
					continue
				}
				joinLines++
				if _, _, err := parseCLIErr(t, splitHintLine(t, line)[1:]); err != nil {
					t.Errorf("hint line does not parse:\n  %s\n  %v", line, err)
				}
			}
			if joinLines == 0 {
				t.Fatalf("no join line found in hint:\n%s", hint)
			}
		})
	}
}
