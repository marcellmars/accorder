package cmd

// Tests for the federation-member file-link shape on the solo share server.
// A fed-member index bakes /files/<prefix> into each book's BaseURL
// (cmd/libBuild.go), so `lib share live` must serve /files/<prefix>/... as an
// alias of /files/... — same handler chain, so the sensitive-path guard and
// gating apply identically — and indexFilesPrefix must recover the prefix
// from the index's display books.

import (
	"accorder/pkg/calibre"
	"bufio"
	"encoding/json"
	"net/http"
	"os"
	"path/filepath"
	"testing"
)

func TestRegisterPrefixedFilesRoute(t *testing.T) {
	dir := t.TempDir()
	bookDir := filepath.Join(dir, "Author", "Book (1)")
	if err := os.MkdirAll(bookDir, 0o755); err != nil {
		t.Fatal(err)
	}
	for _, f := range []string{"book.epub", "cover.jpg"} {
		if err := os.WriteFile(filepath.Join(bookDir, f), []byte("x"), 0o644); err != nil {
			t.Fatal(err)
		}
	}
	if err := os.WriteFile(filepath.Join(dir, "metadata.db"), []byte("x"), 0o644); err != nil {
		t.Fatal(err)
	}

	plain := guardedFileHandler(http.StripPrefix("/files/", http.FileServer(http.Dir(dir))))
	mux := http.NewServeMux()
	mux.Handle("/files/", plain)
	registerPrefixedFilesRoute(mux, "marcell", plain)
	registerPrefixedFilesRoute(mux, "", plain) // standalone library: must be a no-op

	cases := []struct {
		path string
		want int
	}{
		{"/files/Author/Book%20(1)/book.epub", http.StatusOK},
		{"/files/marcell/Author/Book%20(1)/book.epub", http.StatusOK},
		{"/files/marcell/Author/Book%20(1)/cover.jpg", http.StatusOK},
		{"/files/marcell/metadata.db", http.StatusNotFound}, // guard applies after the rewrite
		{"/files/metadata.db", http.StatusNotFound},
		{"/files/other/Author/Book%20(1)/book.epub", http.StatusNotFound},
	}
	for _, c := range cases {
		if got := codeFor(mux, c.path, nil); got != c.want {
			t.Errorf("GET %s: got %d, want %d", c.path, got, c.want)
		}
	}
}

func prefixedIndexFixture(t *testing.T, dir, baseURL, libraryURL string) string {
	t.Helper()
	jsonlPath := filepath.Join(dir, "books.jsonl")
	f, err := os.Create(jsonlPath)
	if err != nil {
		t.Fatal(err)
	}
	w := bufio.NewWriter(f)
	enc := json.NewEncoder(w)
	for i, title := range []string{"First Book", "Second Book"} {
		n := string(rune('1' + i))
		if err := enc.Encode(calibre.Book{
			Id:           "00000000-0000-0000-0000-00000000000" + n,
			Title:        title,
			Authors:      []string{"Author"},
			LastModified: "2024-01-15T10:30:00+00:00",
			LibraryUUID:  "test-uuid",
			Librarian:    "testlib",
			UUID:         "book-" + n,
			BaseURL:      baseURL,
			LibraryUrl:   libraryURL,
		}); err != nil {
			t.Fatal(err)
		}
	}
	if err := w.Flush(); err != nil {
		t.Fatal(err)
	}
	if err := f.Close(); err != nil {
		t.Fatal(err)
	}

	idxPath := filepath.Join(dir, "library_index")
	ms := &calibre.MotwSearch{JsonlPath: jsonlPath, IndexPath: idxPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex: %v", err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatalf("CompressToFile: %v", err)
	}
	return idxPath
}

func TestIndexFilesPrefix(t *testing.T) {
	member := prefixedIndexFixture(t, t.TempDir(), "/files/marcell", "/files/marcell/")
	if got := indexFilesPrefix(member); got != "marcell" {
		t.Errorf("member index: got %q, want %q", got, "marcell")
	}

	solo := prefixedIndexFixture(t, t.TempDir(), "", "")
	if got := indexFilesPrefix(solo); got != "" {
		t.Errorf("standalone index: got %q, want empty", got)
	}

	if got := indexFilesPrefix(filepath.Join(t.TempDir(), "missing_index")); got != "" {
		t.Errorf("missing index: got %q, want empty", got)
	}
}
