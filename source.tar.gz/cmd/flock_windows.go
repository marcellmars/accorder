//go:build windows

package cmd

import "os"

func lockFileExclusive(_ *os.File) (release func(), err error) {
	return func() {}, nil
}

func tryLockFileExclusive(_ *os.File) (release func(), ok bool, err error) {
	return nil, false, errFlockUnsupported
}
