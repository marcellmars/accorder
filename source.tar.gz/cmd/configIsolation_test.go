package cmd

import (
	"os"
	"path/filepath"
	"testing"
)

// TestMain repoints the config globals to a throwaway temp directory before
// any test in this package runs, so a test that forgets to call testSetup(t)
// still cannot touch the operator's real ~/.config/accorder. This is the
// default-safe baseline; assertNotRealConfig (configuration.go) is the hard
// backstop that panics if a global is ever pointed back at the real dir.
func TestMain(m *testing.M) {
	tmp, err := os.MkdirTemp("", "accorder-test-config-*")
	if err != nil {
		panic("TestMain: cannot create temp config dir: " + err.Error())
	}
	accorderConfigDir = tmp
	savedActionAliases = filepath.Join(tmp, "action_aliases.json")
	sourceRegistryPath = filepath.Join(tmp, "indices.json")
	_ = os.WriteFile(savedActionAliases, []byte("{}"), 0644)

	code := m.Run()
	_ = os.RemoveAll(tmp)
	os.Exit(code)
}

// TestSaveActionAliasesRefusesRealConfig proves the isolation guard: pointing
// savedActionAliases back at the operator's real config path — exactly the
// state a forgotten testSetup override leaves — must make saveActionAliases
// panic before it writes. On the old harness (no guard) it would write
// silently and this test fails (the expected-panic recover sees nil).
func TestSaveActionAliasesRefusesRealConfig(t *testing.T) {
	if realUserConfigDir == "" {
		t.Skip("no real user config dir resolved on this platform")
	}
	orig := savedActionAliases
	t.Cleanup(func() { savedActionAliases = orig })

	savedActionAliases = filepath.Join(realUserConfigDir, "action_aliases.json")

	defer func() {
		if r := recover(); r == nil {
			t.Fatal("saveActionAliases wrote to the real user config without panicking; " +
				"the isolation guard is not enforcing")
		}
	}()
	saveActionAliases([]byte(`{"leaked":true}`))
	t.Fatal("unreachable: saveActionAliases should have panicked")
}

// TestLoadActionAliasesRefusesRealConfig is the read-side counterpart: a test
// must not read the operator's real config (it would make results depend on
// the developer's machine state).
func TestLoadActionAliasesRefusesRealConfig(t *testing.T) {
	if realUserConfigDir == "" {
		t.Skip("no real user config dir resolved on this platform")
	}
	orig := savedActionAliases
	t.Cleanup(func() { savedActionAliases = orig })

	savedActionAliases = filepath.Join(realUserConfigDir, "action_aliases.json")

	defer func() {
		if r := recover(); r == nil {
			t.Fatal("loadActionAliases read the real user config without panicking; " +
				"the isolation guard is not enforcing")
		}
	}()
	_ = loadActionAliases()
	t.Fatal("unreachable: loadActionAliases should have panicked")
}
