package cmd

import (
	"testing"
)

// TestStoreInvitePrefix_PropagatesToSiblings is a regression test for the lib join
// bug where storeInvitePrefix wrote fedlibPrefix to ONLY lib.build.fedlibPrefix and
// skipped the propagateSharedField call its sibling storeInviteDictID makes. A later
// `lib publish <alias>` recalls lib.publish.fedlibPrefix (empty) and rebuilds with
// FilesBaseURL("") — so every book's /files/<prefix>/ base is empty and that
// op-hosted member's covers + downloads 404 after the republish. The wild
// browse-render leg surfaced it (a download URL missing the member prefix); the
// wild metadata assertions never caught it because they don't fetch member files.
func TestStoreInvitePrefix_PropagatesToSiblings(t *testing.T) {
	libDir := testSetup(t)

	// Materialize the "kok" alias + a kong.Context whose tree carries the shared
	// "lib" group across build/upload/publish (parse only, no Run).
	_, ctx := parseCLI(t, []string{"lib", "build", "kok", "--calibrepath=" + libDir})

	storeInvitePrefix(ctx, "kok", "kokpfx")

	alias := readAlias(t, "kok")
	// lib.build is the source; lib.publish is the sibling `lib publish` recalls.
	for _, path := range []string{"lib.build.fedlibPrefix", "lib.publish.fedlibPrefix"} {
		got := alias.Get(path)
		if !got.Exists() {
			t.Fatalf("kok.%s missing — fedlibPrefix did not propagate; `lib publish` would re-bake an empty BaseURL", path)
		}
		if got.String() != "kokpfx" {
			t.Errorf("kok.%s = %q, want %q", path, got.String(), "kokpfx")
		}
	}
}
