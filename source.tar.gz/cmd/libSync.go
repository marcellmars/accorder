package cmd

import (
	"accorder/pkg/calibre"
	"accorder/pkg/fedlibinvite"
	"accorder/pkg/libraryflow"
	"accorder/pkg/rclonexfer"
	"accorder/pkg/secrets"
	"encoding/hex"
	"fmt"
	"io"
	"io/fs"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/alecthomas/kong"
)

type LibSyncCmd struct {
	CommonCommandFields
	GroupLib
	GroupS3Credentials
	Passphrase string `name:"passphrase" json:"-" help:"Passphrase for the local secrets store (or set ACCORDER_SECRETS_PASSPHRASE)." env:"ACCORDER_SECRETS_PASSPHRASE" secret:"redact"`
	RemoteWins bool   `name:"remote-wins" help:"Replace a changed/unbaselined local tree with the committed published snapshot, retaining the old tree." json:"-"`

	ExpectedLibraryID string `kong:"-" json:"-"`
}

// syncAfterActivateHook injects a crash after rename but before bookkeeping.
// Production leaves it nil.
var syncAfterActivateHook func() error

func (c *LibSyncCmd) Run(ctx *kong.Context) error {
	if c.HandleShowConfig(c) {
		return nil
	}
	release, err := acquireLibraryExecutionLock(c.ActionAlias)
	if err != nil {
		return fmt.Errorf("lib sync: %w", err)
	}
	defer release()
	if err := recoverSyncActivation(c.ActionAlias); err != nil {
		return fmt.Errorf("lib sync: recover prior activation: %w", err)
	}
	var pending *pendingJoinIdentity
	var pendingStore *secrets.Store
	if c.ExpectedLibraryID == "" && c.LibraryID == "" {
		pending, pendingStore, err = loadPendingJoin(c.Passphrase, c.ActionAlias)
		if err != nil {
			return fmt.Errorf("lib sync: alias has no active library identity and no usable pending join: %w", err)
		}
		c.ExpectedLibraryID = pending.LibraryID
	}

	destination := c.CalibreDirectory
	if destination == "" {
		home, err := os.UserHomeDir()
		if err != nil {
			return fmt.Errorf("lib sync: determine default destination: %w", err)
		}
		destination = filepath.Join(home, "Calibre Libraries", c.ActionAlias)
	}
	destination, err = filepath.Abs(destination)
	if err != nil {
		return fmt.Errorf("lib sync: destination: %w", err)
	}

	remote, err := openLibraryRemoteForCommand(c.ActionAlias, c.GroupS3Credentials)
	if err != nil {
		return fmt.Errorf("lib sync: %w", err)
	}
	defer remote.Close()
	snapshot := remote.commitState()
	if snapshot.Err != nil {
		return fmt.Errorf("lib sync: remote snapshot is not safe to activate: %w", snapshot.Err)
	}
	if !snapshot.Committed {
		return fmt.Errorf("lib sync: no published library found")
	}
	expectedID := c.ExpectedLibraryID
	if expectedID == "" {
		expectedID = c.LibraryID
	}
	if expectedID != "" && snapshot.Pointer.Library.UUID != expectedID {
		return fmt.Errorf("lib sync: remote library UUID %s does not match expected %s", snapshot.Pointer.Library.UUID, expectedID)
	}

	baseline, err := loadBaseline(c.ActionAlias)
	if err != nil {
		return fmt.Errorf("lib sync: %w", err)
	}
	localFingerprint := ""
	localExists := false
	if _, err := os.Stat(destination); err == nil {
		localExists = true
		if _, err := os.Stat(filepath.Join(destination, "metadata.db")); err == nil {
			localFingerprint, err = localSourceFingerprintForContract(destination, resolveUploadExcludes(destination, nil), snapshot.Pointer.SourceContract)
			if err != nil {
				return fmt.Errorf("lib sync: local fingerprint: %w", err)
			}
		}
	} else if !os.IsNotExist(err) {
		return fmt.Errorf("lib sync: inspect destination: %w", err)
	}
	nonEmpty := false
	if localExists {
		nonEmpty, err = directoryHasEntries(destination)
		if err != nil {
			return fmt.Errorf("lib sync: inspect destination: %w", err)
		}
	}
	state := classifyLibraryState(localFingerprint, snapshot.SourceFingerprint, baseline)
	if localFingerprint != "" && localFingerprint == snapshot.SourceFingerprint && !c.RemoteWins {
		generationOnly := baseline != nil && isCatalogEvidence(baseline.Evidence) &&
			snapshot.Pointer.SourceContract == calibre.CatalogSourceContract && baseline.LibraryID == snapshot.Pointer.Library.UUID &&
			baseline.LocalSourceFingerprint == snapshot.SourceFingerprint && baseline.RemoteSourceFingerprint == snapshot.SourceFingerprint &&
			baseline.CatalogChecksum != "" && baseline.CatalogChecksum == snapshot.Pointer.CatalogChecksum
		if baseline == nil || (baseline.GenerationToken != hex.EncodeToString(snapshot.GenerationRaw) && !generationOnly) {
			return fmt.Errorf("lib sync: the remote version cannot be matched to this device's file-change history. Matching names and sizes do not prove matching contents. Local files and pending changes were preserved; review them before running `accorder lib sync %s --remote-wins`", c.ActionAlias)
		}
		inventory, err := inventoryForEvidence(destination, baseline.Evidence, baseline.ContentLedger)
		if err != nil {
			return err
		}
		_, _, changed, removed, err := refreshSourceEvidence(destination, inventory.Objects, resolveUploadExcludes(destination, nil), baseline.ContentLedger, baseline.Evidence, inventory)
		if err != nil {
			return err
		}
		if len(changed) != 0 || len(removed) != 0 {
			return fmt.Errorf("lib sync: local files have unpublished changes; publish them or explicitly choose --remote-wins; saved history was preserved")
		}
		if generationOnly && baseline.GenerationToken != hex.EncodeToString(snapshot.GenerationRaw) {
			for _, path := range []string{publishRecoveryPath(c.ActionAlias), derivedEvidenceRepairPath(c.ActionAlias)} {
				if _, err := os.Stat(path); err == nil {
					return fmt.Errorf("lib sync: finish the interrupted publication before refreshing its generation; saved history was preserved")
				} else if !os.IsNotExist(err) {
					return err
				}
			}
			if err := requireRemoteCommitBytes(remote, snapshot.PointerRaw, snapshot.GenerationRaw); err != nil {
				return err
			}
			if err := verifyCatalogDatabase(destination, baseline.Evidence); err != nil {
				return err
			}
			// Only ancestry changes; retain the earned ledger, evidence and
			// timestamp. A fresh build uses this baseline rather than an old
			// local sentinel, without clearing an unpublished checkpoint.
			refreshed := *baseline
			localToken, err := readLocalGenerationHex(destination)
			if err != nil && !os.IsNotExist(err) {
				return err
			}
			if localToken != "" && localToken != baseline.GenerationToken && localToken != baseline.SupersededLocalGeneration {
				return fmt.Errorf("lib sync: local publication marker differs from saved history; local files were preserved")
			}
			refreshed.SupersededLocalGeneration = localToken
			refreshed.Generation, refreshed.GenerationToken = snapshot.Generation, hex.EncodeToString(snapshot.GenerationRaw)
			if err := saveBaseline(c.ActionAlias, refreshed); err != nil {
				return err
			}
		}
		fmt.Printf("Library %s: current at generation %d; saved file-change history preserved.\n", c.ActionAlias, snapshot.Generation)
		return finishPendingSync(ctx, c.ActionAlias, destination, pending, pendingStore)
	}
	if nonEmpty && baseline == nil && !c.RemoteWins {
		return fmt.Errorf("lib sync: destination is non-empty with no sync baseline; keep it or run `accorder lib sync %s --remote-wins -c %q`", c.ActionAlias, destination)
	}
	if state == "local ahead" && !c.RemoteWins {
		return fmt.Errorf("lib sync: local library has unpublished changes; publish them or run `accorder lib sync %s --remote-wins -c %q`", c.ActionAlias, destination)
	}
	if state == "diverged" && !c.RemoteWins {
		return fmt.Errorf("lib sync: local and remote both changed; choose `accorder lib sync %s --remote-wins -c %q` or `accorder lib publish %s --local-wins`", c.ActionAlias, destination, c.ActionAlias)
	}

	if err := os.MkdirAll(filepath.Dir(destination), 0o755); err != nil {
		return fmt.Errorf("lib sync: create destination parent: %w", err)
	}
	stage, err := os.MkdirTemp(filepath.Dir(destination), "."+filepath.Base(destination)+"-incoming-*")
	if err != nil {
		return fmt.Errorf("lib sync: create staging directory: %w", err)
	}
	stageOwned := true
	defer func() {
		if stageOwned {
			_ = os.RemoveAll(stage)
		}
	}()

	excludes := []string{"/" + libraryflow.WriterPath, "/" + libraryflow.GenerationPath, "/_IDENTITY", "/.accorder/**"}
	jobID, err := rclonexfer.SyncCopyFiltered(remote.fsPath, stage, nil, rcloneUploadExcludes(excludes), true)
	if err != nil {
		return fmt.Errorf("lib sync: start transfer: %w", err)
	}
	if _, err := rclonexfer.WaitJob(jobID); err != nil {
		return fmt.Errorf("lib sync: transfer: %w", err)
	}
	for _, protected := range []string{libraryflow.WriterPath, libraryflow.GenerationPath, "_IDENTITY"} {
		_ = os.Remove(filepath.Join(stage, protected))
	}

	privateExcludes := resolveUploadExcludes(destination, nil)
	if localExists {
		for _, dir := range privateDirsFromExcludes(privateExcludes) {
			source := filepath.Join(destination, filepath.FromSlash(dir))
			if _, err := os.Stat(source); err == nil {
				if err := copyDirectory(source, filepath.Join(stage, filepath.FromSlash(dir))); err != nil {
					return fmt.Errorf("lib sync: preserve private directory %s: %w", dir, err)
				}
			}
		}
		if data, err := os.ReadFile(filepath.Join(destination, uploadExcludesFile)); err == nil {
			if err := os.WriteFile(filepath.Join(stage, uploadExcludesFile), data, 0o644); err != nil {
				return fmt.Errorf("lib sync: preserve private exclusion manifest: %w", err)
			}
		}
	}
	stagedFingerprint, err := localSourceFingerprintForContract(stage, privateExcludes, snapshot.Pointer.SourceContract)
	if err != nil {
		return fmt.Errorf("lib sync: verify staged source: %w", err)
	}
	if stagedFingerprint != snapshot.SourceFingerprint {
		return fmt.Errorf("lib sync: staged source fingerprint %s does not match inspected remote %s", stagedFingerprint, snapshot.SourceFingerprint)
	}
	// Did the remote move while we were downloading? A republish always bumps
	// _GENERATION and changes the published fingerprint, so these three catch
	// it. The inventory token is deliberately not compared: commitState does
	// not enumerate the bucket, so both sides would be empty and the clause
	// would read as a check while testing nothing. What it used to add was
	// detection of an object changed without a republish — an out-of-band edit
	// — and the staged fingerprint verified just above already re-derives the
	// source from the bytes actually downloaded.
	after := remote.commitState()
	if after.Err != nil || !after.Committed || !sameRemoteApproval(snapshot, after) {
		return fmt.Errorf("lib sync: remote changed during transfer; destination was not activated")
	}

	record := syncActivationRecord{
		Version: sourceEvidenceVersion, Alias: c.ActionAlias, LibraryID: snapshot.Pointer.Library.UUID,
		Destination: destination, Stage: stage, RemoteSourceFingerprint: snapshot.SourceFingerprint,
		Generation: snapshot.Generation, Baseline: baseline,
		GenerationToken: hex.EncodeToString(snapshot.GenerationRaw), CatalogChecksum: snapshot.Pointer.CatalogChecksum,
		SourceExcludes: privateExcludes,
		SourceContract: snapshot.Pointer.SourceContract,
	}
	if err := captureSyncStageEvidence(&record); err != nil {
		return fmt.Errorf("lib sync: record downloaded file evidence: %w", err)
	}
	if nonEmpty {
		record.RetainedOldPath, err = retainedLibraryPath(destination, time.Now())
		if err != nil {
			return fmt.Errorf("lib sync: choose retained path: %w", err)
		}
	}
	if err := writeJSONAtomic(syncActivationPath(c.ActionAlias), record); err != nil {
		return fmt.Errorf("lib sync: write activation record: %w", err)
	}
	if nonEmpty {
		if err := os.Rename(destination, record.RetainedOldPath); err != nil {
			// Nothing moved: the deferred cleanup discards the stage, so the
			// record must go with it. A record that outlives its stage would
			// make the next run's recovery mistake the untouched destination
			// for the activated snapshot.
			_ = removeStateFile(syncActivationPath(c.ActionAlias))
			return fmt.Errorf("lib sync: retain old library: %w", err)
		}
	} else if localExists {
		if err := os.Remove(destination); err != nil {
			_ = removeStateFile(syncActivationPath(c.ActionAlias))
			return fmt.Errorf("lib sync: remove empty destination: %w", err)
		}
	}
	if err := os.Rename(stage, destination); err != nil {
		if record.RetainedOldPath == "" {
			_ = removeStateFile(syncActivationPath(c.ActionAlias))
		} else if restoreErr := os.Rename(record.RetainedOldPath, destination); restoreErr == nil {
			_ = removeStateFile(syncActivationPath(c.ActionAlias))
		}
		return fmt.Errorf("lib sync: activate staged library: %w", err)
	}
	stageOwned = false
	if syncAfterActivateHook != nil {
		if err := syncAfterActivateHook(); err != nil {
			return err
		}
	}
	if ctx != nil {
		persistCalibrePath(ctx, c.ActionAlias, destination)
	}
	if err := saveActivatedSourceBaseline(c.ActionAlias, destination, record); err != nil {
		return fmt.Errorf("lib sync: save baseline: %w", err)
	}
	if err := removeStateFile(syncActivationPath(c.ActionAlias)); err != nil {
		return fmt.Errorf("lib sync: clear activation record: %w", err)
	}
	fmt.Printf("Restored %d published books; generation %d; seat unchanged.\n", snapshot.Pointer.Index.NumBooks, snapshot.Generation)
	if record.RetainedOldPath != "" {
		fmt.Printf("Previous local library retained at %s.\n", record.RetainedOldPath)
	}
	fmt.Println("Private book files were never uploaded and may be missing.")
	return finishPendingSync(ctx, c.ActionAlias, destination, pending, pendingStore)
}

func finishPendingSync(ctx *kong.Context, alias, destination string, pending *pendingJoinIdentity, store *secrets.Store) error {
	if pending == nil {
		return nil
	}
	invite := &fedlibinvite.WriteInvite{
		LibraryID: pending.LibraryID, DictID: pending.DictID,
		Prefix: pending.Prefix, Label: pending.Label,
	}
	// Classify the alias now, exactly as `lib join` would have. A zero decision
	// (Class "") makes authorizeAdoption refuse every adoption, which broke the
	// documented "resume with: accorder lib sync" path for an alias holding a
	// locally minted UUID. Key names are deliberately nil: the join already
	// stored this alias's write credentials, so counting them would classify
	// every resume as protected (the same exclusion authorizeAdoption applies).
	// The destination was just activated from the published snapshot, so its
	// metadata.db presence is the source check.
	decision := classifyJoinAlias(loadActionAliases(), nil, alias,
		joinFileExists(filepath.Join(destination, "metadata.db")))
	if err := activateInviteIdentity(ctx, alias, invite, decision); err != nil {
		return fmt.Errorf("activate pending join: %w", err)
	}
	if ctx != nil {
		persistCalibrePath(ctx, alias, destination)
	}
	clearPendingJoin(store, alias)
	return nil
}

func directoryHasEntries(path string) (bool, error) {
	dir, err := os.Open(path)
	if err != nil {
		return false, err
	}
	defer dir.Close()
	_, err = dir.Readdirnames(1)
	if err == io.EOF {
		return false, nil
	}
	return err == nil, err
}

func retainedLibraryPath(destination string, now time.Time) (string, error) {
	base := destination + ".local-" + now.UTC().Format("20060102T150405Z")
	for n := 0; n < 1000; n++ {
		candidate := base
		if n > 0 {
			candidate = fmt.Sprintf("%s-%d", base, n)
		}
		_, err := os.Stat(candidate)
		if os.IsNotExist(err) {
			return candidate, nil
		}
		if err != nil {
			// A stat that fails for any other reason (permissions, I/O) can
			// never become "does not exist"; spinning here would hang.
			return "", err
		}
	}
	return "", fmt.Errorf("no free retained-library path beside %s", destination)
}

func copyDirectory(source, destination string) error {
	return filepath.WalkDir(source, func(path string, entry fs.DirEntry, walkErr error) error {
		if walkErr != nil {
			return walkErr
		}
		rel, err := filepath.Rel(source, path)
		if err != nil {
			return err
		}
		target := filepath.Join(destination, rel)
		if entry.IsDir() {
			return os.MkdirAll(target, 0o755)
		}
		if entry.Type()&os.ModeSymlink != 0 {
			return fmt.Errorf("refusing symlink %s", path)
		}
		info, err := entry.Info()
		if err != nil {
			return err
		}
		in, err := os.Open(path)
		if err != nil {
			return err
		}
		out, err := os.OpenFile(target, os.O_CREATE|os.O_EXCL|os.O_WRONLY, info.Mode().Perm())
		if err != nil {
			_ = in.Close()
			return err
		}
		_, copyErr := io.Copy(out, in)
		inputCloseErr := in.Close()
		closeErr := out.Close()
		if copyErr != nil {
			return copyErr
		}
		if inputCloseErr != nil {
			return inputCloseErr
		}
		if closeErr != nil {
			return closeErr
		}
		return os.Chtimes(target, info.ModTime(), info.ModTime())
	})
}

func recoverSyncActivation(alias string) error {
	var record syncActivationRecord
	err := readJSONFile(syncActivationPath(alias), &record)
	if os.IsNotExist(err) {
		return nil
	}
	if err != nil {
		return err
	}
	if (record.Version != machineStateVersion && record.Version != sourceEvidenceVersion) || record.Alias != alias || record.Destination == "" || record.Stage == "" {
		return fmt.Errorf("invalid activation record for alias %q", alias)
	}
	if record.Version == sourceEvidenceVersion || record.GenerationToken != "" {
		// A full generation claim requires persisted transfer-time evidence,
		// including for records from the earlier implementation that lack it.
		if record.Version != sourceEvidenceVersion || record.StageEvidence == nil {
			return fmt.Errorf("interrupted sync lacks verified staged file information; recovery was retained for reconciliation")
		}
		_, destErr := os.Stat(record.Destination)
		_, stageErr := os.Stat(record.Stage)
		switch {
		case destErr == nil && stageErr == nil:
			// Activation never began. Discard only the identified incoming tree.
			id, _ := sourceLocalFileEvidence(record.Stage)
			if id == "" || id != record.StageRootID || !strings.Contains(filepath.Base(record.Stage), "-incoming-") {
				return fmt.Errorf("cannot identify interrupted sync stage; recovery was retained")
			}
			if err := os.RemoveAll(record.Stage); err != nil {
				return err
			}
			return removeStateFile(syncActivationPath(alias))
		case os.IsNotExist(destErr) && stageErr == nil:
			if err := os.Rename(record.Stage, record.Destination); err != nil {
				return err
			}
		case destErr == nil && os.IsNotExist(stageErr):
			// Already activated; validate against the saved stage below.
		default:
			return fmt.Errorf("cannot locate interrupted sync trees; recovery was retained")
		}
		if err := saveRecoveredSyncBaseline(alias, record); err != nil {
			return err
		}
		return removeStateFile(syncActivationPath(alias))
	}
	_, destinationErr := os.Stat(filepath.Join(record.Destination, "metadata.db"))
	_, stageErr := os.Stat(filepath.Join(record.Stage, "metadata.db"))
	if destinationErr == nil && stageErr == nil {
		// The record was durable but activation never began. The destination
		// is still the old tree, so keep its baseline and discard only our
		// owned stage.
		if strings.Contains(filepath.Base(record.Stage), "-incoming-") {
			_ = os.RemoveAll(record.Stage)
		}
		return removeStateFile(syncActivationPath(alias))
	}
	if stageErr == nil && destinationErr != nil {
		if _, destErr := os.Stat(record.Destination); os.IsNotExist(destErr) {
			// Interrupted between moving the old tree aside and installing the
			// stage. Rolling forward is the only outcome that leaves the
			// destination holding the recorded snapshot, so the baseline is
			// earned here rather than inferred from a later observation.
			if err := os.Rename(record.Stage, record.Destination); err != nil {
				return err
			}
			if err := saveRecoveredSyncBaseline(alias, record); err != nil {
				return err
			}
			return removeStateFile(syncActivationPath(alias))
		}
	}
	if destinationErr == nil && os.IsNotExist(stageErr) {
		// The stage is gone and the destination holds a library — but that is
		// also what an ABORTED activation looks like once the deferred cleanup
		// discarded the stage while the destination was never replaced. Record
		// the snapshot as this machine's baseline only when the destination
		// provably IS that snapshot; otherwise a stale local tree would later
		// be classified "local ahead" and published over the newer remote.
		fingerprint, _, fpErr := libraryflow.SourceFingerprint(record.Destination, resolveUploadExcludes(record.Destination, nil))
		if fpErr == nil && fingerprint == record.RemoteSourceFingerprint {
			if err := saveRecoveredSyncBaseline(alias, record); err != nil {
				return err
			}
		}
		return removeStateFile(syncActivationPath(alias))
	}
	// Alias/destination still names the old tree: abandon only the staging
	// directory owned by this record and preserve the old baseline.
	if strings.Contains(filepath.Base(record.Stage), "-incoming-") {
		_ = os.RemoveAll(record.Stage)
	}
	return removeStateFile(syncActivationPath(alias))
}
