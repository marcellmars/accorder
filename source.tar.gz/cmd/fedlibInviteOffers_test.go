package cmd

import (
	"accorder/pkg/fedlibinvite"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/goccy/go-json"
)

// writeTestOffer seals and persists an offer, returning the token and blob.
func writeTestOffer(t *testing.T, dir string, expires time.Time) (token, blob string) {
	t.Helper()
	token, err := fedlibinvite.NewOfferToken()
	if err != nil {
		t.Fatal(err)
	}
	blob = fedlibinvite.EncodeWriteInvite(&fedlibinvite.WriteInvite{
		FedlibID:  "fed-1",
		Backend:   "s3",
		Prefix:    "biopolitics",
		AccessKey: "AKIATESTACCESS",
		SecretKey: "testsecretkey",
		Label:     "Test Librarian",
	})
	offer, err := fedlibinvite.SealOffer(token, blob, "biopolitics", "Test Librarian", expires)
	if err != nil {
		t.Fatal(err)
	}
	if err := fedlibinvite.WriteOffer(dir, token, offer); err != nil {
		t.Fatal(err)
	}
	return token, blob
}

func newTestInviteHandler(dir string) http.Handler {

	// Generous limiter: rate limiting has its own test.
	return makeInviteHandler(dir, newIPRateLimiter(1000, time.Millisecond))
}

func TestInviteHandler_ClaimBurnsSecondClaim404(t *testing.T) {
	dir := t.TempDir()
	token, blob := writeTestOffer(t, dir, time.Now().Add(time.Hour))
	h := newTestInviteHandler(dir)

	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, httptest.NewRequest(http.MethodPost, "/invite/"+token+"/claim", nil))
	if rec.Code != http.StatusOK {
		t.Fatalf("first claim: status %d, want 200", rec.Code)
	}
	if ct := rec.Header().Get("Content-Type"); ct != "application/json" {
		t.Fatalf("first claim: Content-Type %q", ct)
	}
	var resp inviteClaimResponse
	if err := json.Unmarshal(rec.Body.Bytes(), &resp); err != nil {
		t.Fatalf("claim response parse: %v", err)
	}
	if resp.Version != 1 || resp.Invite != blob {
		t.Fatalf("claim response = %+v, want version 1 + original blob", resp)
	}

	rec = httptest.NewRecorder()
	h.ServeHTTP(rec, httptest.NewRequest(http.MethodPost, "/invite/"+token+"/claim", nil))
	if rec.Code != http.StatusNotFound {
		t.Fatalf("second claim: status %d, want 404", rec.Code)
	}
}

func TestInviteHandler_GETNeverBurns(t *testing.T) {
	dir := t.TempDir()
	token, _ := writeTestOffer(t, dir, time.Now().Add(time.Hour))
	h := newTestInviteHandler(dir)

	offerPath := filepath.Join(dir, fedlibinvite.OfferFileName(token))
	before, err := os.ReadFile(offerPath)
	if err != nil {
		t.Fatal(err)
	}

	// Link-preview simulation: repeated GETs must not consume the offer.
	for range 3 {
		rec := httptest.NewRecorder()
		h.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/invite/"+token, nil))
		if rec.Code != http.StatusOK {
			t.Fatalf("GET info: status %d, want 200", rec.Code)
		}
		body, _ := io.ReadAll(rec.Body)
		if !strings.Contains(string(body), "biopolitics") {
			t.Fatalf("GET info body missing prefix: %q", body)
		}
		if strings.Contains(string(body), "accorder-fedlib-invite:") {
			t.Fatal("GET info body leaks the invite blob")
		}
	}

	after, err := os.ReadFile(offerPath)
	if err != nil {
		t.Fatalf("offer file gone after GET: %v", err)
	}
	if string(before) != string(after) {
		t.Fatal("offer file changed by GET")
	}

	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, httptest.NewRequest(http.MethodPost, "/invite/"+token+"/claim", nil))
	if rec.Code != http.StatusOK {
		t.Fatalf("claim after GETs: status %d, want 200", rec.Code)
	}
}

func TestInviteHandler_Expired404(t *testing.T) {
	dir := t.TempDir()
	token, _ := writeTestOffer(t, dir, time.Now().Add(-time.Minute))
	h := newTestInviteHandler(dir)

	for _, req := range []*http.Request{
		httptest.NewRequest(http.MethodGet, "/invite/"+token, nil),
		httptest.NewRequest(http.MethodPost, "/invite/"+token+"/claim", nil),
	} {
		rec := httptest.NewRecorder()
		h.ServeHTTP(rec, req)
		if rec.Code != http.StatusNotFound {
			t.Fatalf("%s %s on expired offer: status %d, want 404", req.Method, req.URL.Path, rec.Code)
		}
	}
}

func TestInviteHandler_BadTokenAndMethod404(t *testing.T) {
	dir := t.TempDir()
	token, _ := writeTestOffer(t, dir, time.Now().Add(time.Hour))
	h := newTestInviteHandler(dir)

	cases := []struct{ method, path string }{
		{http.MethodGet, "/invite/../secrets.key"},
		{http.MethodGet, "/invite/SHOUTYTOKENNOTVALIDATALL26"},
		{http.MethodGet, "/invite/short"},
		{http.MethodPost, "/invite/" + token},           // POST on info
		{http.MethodGet, "/invite/" + token + "/claim"}, // GET on claim
		{http.MethodGet, "/invite/" + token + "/other"}, // unknown tail
		{http.MethodDelete, "/invite/" + token},         // unknown verb
	}
	for _, c := range cases {
		rec := httptest.NewRecorder()
		h.ServeHTTP(rec, httptest.NewRequest(c.method, c.path, nil))
		if rec.Code != http.StatusNotFound {
			t.Fatalf("%s %s: status %d, want 404", c.method, c.path, rec.Code)
		}
	}

	// None of the probing burned the offer.
	rec := httptest.NewRecorder()
	h.ServeHTTP(rec, httptest.NewRequest(http.MethodPost, "/invite/"+token+"/claim", nil))
	if rec.Code != http.StatusOK {
		t.Fatalf("claim after probes: status %d, want 200", rec.Code)
	}
}

func TestInviteHandler_RateLimit429(t *testing.T) {
	dir := t.TempDir()
	token, _ := writeTestOffer(t, dir, time.Now().Add(time.Hour))
	h := makeInviteHandler(dir, newIPRateLimiter(5, 2*time.Second))

	status := make([]int, 0, 7)
	for range 7 {
		rec := httptest.NewRecorder()
		h.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/invite/"+token, nil))
		status = append(status, rec.Code)
	}
	for i, code := range status[:5] {
		if code != http.StatusOK {
			t.Fatalf("request %d: status %d, want 200", i, code)
		}
	}
	for i, code := range status[5:] {
		if code != http.StatusTooManyRequests {
			t.Fatalf("request %d: status %d, want 429", i+5, code)
		}
	}
}

func TestIPRateLimiter_PerIPIsolationAndRefill(t *testing.T) {
	l := newIPRateLimiter(2, 10*time.Millisecond)
	for i := range 2 {
		if !l.allow("1.1.1.1") {
			t.Fatalf("burst exhausted too early (request %d)", i)
		}
	}
	if l.allow("1.1.1.1") {
		t.Fatal("third request allowed; want denied")
	}
	if !l.allow("2.2.2.2") {
		t.Fatal("second IP blocked by first IP's bucket")
	}
	time.Sleep(15 * time.Millisecond)
	if !l.allow("1.1.1.1") {
		t.Fatal("bucket did not refill")
	}
}

// The /invite/ pattern must register only on the main mux (!browserOnly) and
// must win over a SPA "/" catch-all (stdlib ServeMux precedence).
func TestInviteRoutes_BrowserOnlyGatingAndMuxPrecedence(t *testing.T) {
	dir := t.TempDir()
	token, _ := writeTestOffer(t, dir, time.Now().Add(time.Hour))
	meter := &sessionMeter{window: time.Minute, granularity: time.Second, maxSessions: 10, maxDistinct: 10}

	// browserOnly mux: buildAggregateBrowserMux passes "" for the offers dir;
	// registration is additionally gated on !browserOnly.
	bmux := http.NewServeMux()
	bmux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) { _, _ = w.Write([]byte("spa")) })
	registerAggregateRoutes(bmux, &serveState{}, aggregateVFSAddresses{}, meter, nil, nil, "offline-private", "", nil, true)

	rec := httptest.NewRecorder()
	bmux.ServeHTTP(rec, httptest.NewRequest(http.MethodPost, "/invite/"+token+"/claim", nil))
	if body := rec.Body.String(); rec.Code != http.StatusOK || body != "spa" {
		t.Fatalf("browser-only mux /invite/: status %d body %q, want SPA catch-all (no claim route)", rec.Code, body)
	}

	// Main mux: /invite/ registered, explicit pattern beats the catch-all.
	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) { _, _ = w.Write([]byte("spa")) })
	registerAggregateRoutes(mux, &serveState{}, aggregateVFSAddresses{}, meter, nil, nil, "public", dir, nil, false)

	rec = httptest.NewRecorder()
	mux.ServeHTTP(rec, httptest.NewRequest(http.MethodPost, "/invite/"+token+"/claim", nil))
	if rec.Code != http.StatusOK || !strings.Contains(rec.Body.String(), "accorder-fedlib-invite:") {
		t.Fatalf("main mux claim: status %d body %q, want claim envelope", rec.Code, rec.Body.String())
	}

	rec = httptest.NewRecorder()
	mux.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/", nil))
	if rec.Body.String() != "spa" {
		t.Fatalf("SPA catch-all broken: %q", rec.Body.String())
	}
}
