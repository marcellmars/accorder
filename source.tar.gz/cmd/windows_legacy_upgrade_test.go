//go:build windows

package cmd

import (
	"encoding/hex"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"accorder/pkg/calibre"
	"accorder/pkg/libraryflow"
	"accorder/pkg/torshare"
)

// A librarian who already completed the v0.20.1 checksum pass must not pay
// for it again. Import that durable v1 baseline, add a book, and prepare a
// bounded update over the existing non-empty remote without hashing formats.
func TestWindowsLegacyLibraryUpgradeWithNewBookAndNonEmptyRemote(t *testing.T) {
	root := testSetup(t)
	alias := "windows-legacy-upgrade"
	metadataPath := filepath.Join(root, "metadata.db")
	if err := os.WriteFile(metadataPath, []byte("legacy catalogue"), 0o644); err != nil {
		t.Fatal(err)
	}

	oldBook := generationCandidateBook()
	oldBook.LibraryUUID = "550e8400-e29b-41d4-a716-446655440000"
	oldBook.Librarian = "Windows Librarian"
	oldPayload := filepath.Join(root, "Author", "Old Book (1)", "old.epub")
	oldBook.Formats[0].DirectoryPath = "Author/Old Book (1)"
	oldBook.Formats[0].Name = "old.epub"
	oldBook.CoverUrl = ""
	if err := os.MkdirAll(filepath.Dir(oldPayload), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(oldPayload, []byte("old payload"), 0o644); err != nil {
		t.Fatal(err)
	}

	jsonlPath := filepath.Join(root, "books.jsonl")
	writeBooks := func(books ...*calibre.Book) {
		t.Helper()
		file, err := os.Create(jsonlPath)
		if err != nil {
			t.Fatal(err)
		}
		encoder := json.NewEncoder(file)
		for _, book := range books {
			if err := encoder.Encode(book); err != nil {
				_ = file.Close()
				t.Fatal(err)
			}
		}
		if err := file.Close(); err != nil {
			t.Fatal(err)
		}
		future := time.Now().Add(time.Second)
		if err := os.Chtimes(jsonlPath, future, future); err != nil {
			t.Fatal(err)
		}
	}
	indexPath := filepath.Join(root, "static", "library_index")
	build := func() {
		t.Helper()
		command := &LibBuildCmd{}
		command.ActionAlias = alias
		command.CalibreDirectory = root
		command.LibraryID = oldBook.LibraryUUID
		command.Librarian = oldBook.Librarian
		command.JsonLPath = jsonlPath
		command.IndexPath = indexPath
		command.Index = new(bool)
		if err := command.Run(nil); err != nil {
			t.Fatal(err)
		}
	}

	writeBooks(oldBook)
	build()
	oldFingerprint, _, err := libraryflow.SourceFingerprint(root, resolveUploadExcludes(root, nil))
	if err != nil {
		t.Fatal(err)
	}
	oldGeneration, err := os.ReadFile(filepath.Join(root, libraryflow.GenerationPath))
	if err != nil {
		t.Fatal(err)
	}
	base, generation, err := torshare.DecodeGeneration(oldGeneration)
	if err != nil {
		t.Fatal(err)
	}
	oldPointer, err := calibre.ReadPointerFile(indexPath + ".manifest.json")
	if err != nil {
		t.Fatal(err)
	}
	if err := os.Remove(localChangeCandidateFile(root)); err != nil {
		t.Fatal(err)
	}

	cutoff := time.Now().UTC()
	oldObjects, err := listLocalObjects(root)
	if err != nil {
		t.Fatal(err)
	}
	oldLedger, _, _, err := buildContentLedger(root, oldObjects, resolveUploadExcludes(root, nil), nil)
	if err != nil {
		t.Fatal(err)
	}
	if err := saveBaseline(alias, libraryBaseline{
		LibraryID:               oldBook.LibraryUUID,
		RemoteSourceFingerprint: oldFingerprint,
		LocalSourceFingerprint:  oldFingerprint,
		Generation:              generation, GenerationToken: hex.EncodeToString(oldGeneration),
		CatalogChecksum:      oldPointer.CatalogChecksum,
		ContentLedgerVersion: 1, ContentLedger: oldLedger, UpdatedAt: cutoff,
	}); err != nil {
		t.Fatal(err)
	}

	time.Sleep(20 * time.Millisecond)
	newBook := *generationCandidateBook()
	newBook.Id = "00000000-0000-4000-8000-000000000999"
	newBook.Title = "New Windows Book"
	newBook.TitleSort = newBook.Title
	newBook.LibraryUUID = oldBook.LibraryUUID
	newBook.Librarian = oldBook.Librarian
	newBook.CoverUrl = ""
	newBook.Formats = []*calibre.File{{
		Format: "epub", DirectoryPath: "Author/New Windows Book (2)",
		Name: "new.epub", Size: int64(len("new payload")),
	}}
	newPayloadRel := "Author/New Windows Book (2)/new.epub"
	newPayload := filepath.Join(root, filepath.FromSlash(newPayloadRel))
	if err := os.MkdirAll(filepath.Dir(newPayload), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(newPayload, []byte("new payload"), 0o644); err != nil {
		t.Fatal(err)
	}
	writeBooks(oldBook, &newBook)
	build()

	candidate, err := loadLocalChangeCandidate(root)
	if err != nil {
		t.Fatal(err)
	}
	if candidate.Scope != calibre.GenerationChangeScopeExact || candidate.ContentLedgerVersion != sourceEvidenceVersion || candidate.CompleteOverwrite {
		t.Fatalf("Windows legacy candidate scope=%s reason=%s complete_overwrite=%t", candidate.Scope, candidate.Reason, candidate.CompleteOverwrite)
	}
	if !containsString(candidate.ForcePaths, newPayloadRel) {
		t.Fatalf("Windows legacy candidate force paths=%v, want %s", candidate.ForcePaths, newPayloadRel)
	}

	initial := remoteLibrarySnapshot{
		Pointer: oldPointer, PointerRaw: []byte("non-empty"),
		GenerationRaw: oldGeneration, Generation: generation,
		SourceFingerprint: oldFingerprint, Committed: true,
	}
	pointer, err := calibre.ReadPointerFile(indexPath + ".manifest.json")
	if err != nil {
		t.Fatal(err)
	}
	local := &libraryCandidate{
		Root: root, SourceFingerprint: candidate.TargetSourceFingerprint,
		Change: candidate,
	}
	target := torshare.EncodeGeneration(base, generation+1)
	bound, err := bindGenerationPublication(initial, pointer, local, target, oldFingerprint)
	if err != nil {
		t.Fatal(err)
	}
	if bound.CompleteOverwrite || bound.Scope != calibre.GenerationChangeScopeExact || !containsString(bound.ForcePaths, newPayloadRel) {
		t.Fatalf("bound non-empty Windows upgrade=%+v", bound)
	}

	objects, err := listLocalObjects(root)
	if err != nil {
		t.Fatal(err)
	}
	local.Objects = objects
	if err := saveLocalChangeCandidate(root, *candidate); err != nil {
		t.Fatal(err)
	}
	originalHasher := contentLedgerHashFile
	t.Cleanup(func() { contentLedgerHashFile = originalHasher })
	contentLedgerHashFile = func(path string, _ func(int64)) (string, error) {
		return "", &unexpectedWindowsRehash{path: path}
	}
	attachLocalChangeCandidate(local)
	if local.Change == nil {
		t.Fatal("upload validation discarded the fresh Windows build candidate")
	}
}

type unexpectedWindowsRehash struct{ path string }

func (e *unexpectedWindowsRehash) Error() string {
	return "unexpected Windows source rehash: " + strings.TrimSpace(e.path)
}
