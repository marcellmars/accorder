package cmd

import (
	"accorder/pkg/bubble"
	"accorder/pkg/rclonexfer"
	"fmt"
	"os"

	tea "github.com/charmbracelet/bubbletea"
)

// runLibrarySync hands one mirror sync to rclone and follows it to completion.
//
// Following it is the point. rclone reports checks and transfers as it goes,
// and a publish that prints nothing while it works is indistinguishable from a
// publish that has hung — which is exactly how the enumeration this replaced
// presented itself for twenty-five minutes.
func runLibrarySync(header, localRoot, remoteFs string, excludes []string, options rclonexfer.SyncOptions) error {
	jobID, err := rclonexfer.SyncSync(localRoot, remoteFs, nil, rcloneUploadExcludes(excludes), options)
	if err != nil {
		return fmt.Errorf("mirror to %s: %w", remoteFs, err)
	}
	if interactiveTerminal() {
		return renderSyncProgress(header, jobID)
	}
	return renderSyncProgressHeadless(header, jobID)
}

// interactiveTerminal reports whether stdout is a terminal. Bubbletea opens
// /dev/tty, so it must not be started from a pipe, a cron job, or `--on`
// over SSH without a pty.
func interactiveTerminal() bool {
	info, err := os.Stdout.Stat()
	if err != nil {
		return false
	}
	return info.Mode()&os.ModeCharDevice != 0
}

func renderSyncProgress(header string, jobID int64) error {
	updates := rclonexfer.PollProgress(jobID)
	program := tea.NewProgram(bubble.RcloneProgressBarModel())
	done := make(chan error, 1)
	go func() {
		var last rclonexfer.SyncStats
		for stats := range updates {
			last = stats
			message := bubble.RcloneProgressMsg{RcloneHeader: header, Quitable: !stats.Finished}
			message.RcloneStatsInfo.Bytes = stats.Bytes
			message.RcloneStatsInfo.TotalBytes = stats.TotalBytes
			message.RcloneStatsInfo.Checks = stats.Checks
			message.RcloneStatsInfo.TotalChecks = stats.TotalChecks
			message.RcloneStatsInfo.Transfers = stats.Transfers
			if stats.TotalChecks > 0 {
				message.RcloneCheckPercent = float64(stats.Checks) / float64(stats.TotalChecks)
			}
			if stats.TotalBytes > 0 {
				message.RcloneTransferPercent = float64(stats.Bytes) / float64(stats.TotalBytes)
			}
			if stats.Finished && stats.Success {
				message.RcloneCheckPercent, message.RcloneTransferPercent = 1.0, 1.0
			}
			program.Send(message)
		}
		program.Quit()
		done <- syncOutcome(last)
	}()
	if _, err := program.Run(); err != nil {
		// A failed progress bar must not fail the publish: drain the poller
		// and report what the transfer actually did.
		fmt.Fprintf(os.Stderr, "lib publish: progress display unavailable: %v\n", err)
	}
	return <-done
}

func renderSyncProgressHeadless(header string, jobID int64) error {
	if header != "" {
		fmt.Fprintln(os.Stderr, header)
	}
	var last rclonexfer.SyncStats
	for stats := range rclonexfer.PollProgress(jobID) {
		last = stats
	}
	if err := syncOutcome(last); err != nil {
		return err
	}
	fmt.Fprintf(os.Stderr, "mirror: done — %d transfer(s), %d byte(s), %d deletion(s).\n",
		last.Transfers, last.Bytes, last.Deletes)
	return nil
}

func syncOutcome(stats rclonexfer.SyncStats) error {
	if !stats.Finished {
		return fmt.Errorf("mirror ended without a final status (%d transfer(s), %d byte(s))", stats.Transfers, stats.Bytes)
	}
	if !stats.Success {
		if stats.Error != "" {
			return fmt.Errorf("mirror failed: %s", stats.Error)
		}
		return fmt.Errorf("mirror failed after %d transfer(s), %d byte(s)", stats.Transfers, stats.Bytes)
	}
	return nil
}
