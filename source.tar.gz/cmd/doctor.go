package cmd

import (
	"fmt"
	"net/http"
	"os"
	"sort"
	"strings"
	"time"

	"github.com/alecthomas/kong"
	"github.com/tidwall/gjson"
)

type verdict int

const (
	vOK verdict = iota
	vWarn
	vNotReady
	vFailed
	vSkipped
)

func (v verdict) label() string {
	switch v {
	case vOK:
		return "ok"
	case vWarn:
		return "warn"
	case vNotReady:
		return "waiting"
	case vFailed:
		return "failed"
	default:
		return "skipped"
	}
}

func (v verdict) exitCode() int {
	switch v {
	case vOK, vSkipped:
		return 0
	case vWarn:
		return 1
	case vNotReady:
		return 2
	default:
		return 3
	}
}

type checkResult struct {
	name    string
	verdict verdict
	detail  string
}

type DoctorCmd struct {
	ActionAlias string        `arg:"" optional:"" help:"Alias to inspect. Defaults to 'default'." default:"default"`
	Wait        bool          `name:"wait" help:"Block until the serve reports ready, then exit. Turns this into a post-restart readiness gate."`
	Timeout     time.Duration `name:"timeout" help:"Budget for --wait." default:"10m"`
	Endpoint    string        `name:"endpoint" help:"Readiness URL to poll. Defaults to the serve's resolved --listen address. Point it at the public URL to exercise the whole proxy chain instead of just the serve."`
}

func (c *DoctorCmd) Run(kctx *kong.Context) error {
	if c.Wait {
		return c.runWait()
	}

	cacheResults := c.checkCachePlanes()
	results := []checkResult{
		c.checkVersion(),
		c.checkServe(),
	}
	results = append(results, cacheResults...)
	results = append(results,
		c.checkConfig(kctx),
		c.checkBackup(),
		checkResult{name: "serve errors", verdict: vSkipped,
			detail: "no service definition on this host — accorder installs none yet (ca-122)"},
	)

	worst := vOK
	width := 0
	for _, r := range results {
		if len(r.name) > width {
			width = len(r.name)
		}
		if r.verdict > worst && r.verdict != vSkipped {
			worst = r.verdict
		}
	}

	fmt.Printf("accorder doctor — alias %q\n\n", c.ActionAlias)
	for _, r := range results {
		fmt.Printf("  %-8s %-*s  %s\n", r.verdict.label(), width, r.name, r.detail)
	}

	var warns, skipped int
	for _, r := range results {
		switch r.verdict {
		case vSkipped:
			skipped++
		case vWarn, vNotReady, vFailed:
			warns++
		}
	}
	fmt.Printf("\n%d %s, %d skipped.\n", warns, plural(warns, "problem", "problems"), skipped)
	if code := worst.exitCode(); code != 0 {
		kctx.Exit(code)
	}
	return nil
}

func (c *DoctorCmd) checkVersion() checkResult {
	return checkResult{name: "version", verdict: vOK, detail: cmdVersion}
}

func (c *DoctorCmd) checkConfig(kctx *kong.Context) checkResult {
	data, err := tryLoadActionAliases()
	if os.IsNotExist(err) {
		return checkResult{name: "config", verdict: vOK, detail: "no alias store yet — nothing to check"}
	}
	if err != nil {
		return checkResult{name: "config", verdict: vFailed, detail: "alias store unreadable: " + err.Error()}
	}
	root := kctx.Model.Node
	counts := map[rotKind]int{}
	for _, f := range scanAliasRot(root, data, c.ActionAlias) {
		counts[f.Kind]++
	}

	elsewhere := 0
	for _, other := range GetAllAliases() {
		if other == c.ActionAlias {
			continue
		}
		elsewhere += len(scanAliasRot(root, data, other))
	}
	suffix := ""
	if elsewhere > 0 {
		suffix = fmt.Sprintf(" (+%d in other aliases; this check covers %q only)", elsewhere, c.ActionAlias)
	}

	if len(counts) == 0 {
		return checkResult{name: "config", verdict: vOK, detail: "no rot found" + suffix}
	}
	var parts []string
	for _, k := range sortedKinds(counts) {
		parts = append(parts, fmt.Sprintf("%d %s", counts[k], kindLabel(k, counts[k])))
	}
	return checkResult{name: "config", verdict: vWarn,
		detail: strings.Join(parts, ", ") + suffix + " — run 'accorder config prune'"}
}

func sortedKinds(m map[rotKind]int) []rotKind {
	out := make([]rotKind, 0, len(m))
	for k := range m {
		out = append(out, k)
	}
	sort.Slice(out, func(i, j int) bool { return out[i] < out[j] })
	return out
}

func (c *DoctorCmd) checkBackup() checkResult {
	entries, err := os.ReadDir(backupsDir())
	if err != nil {
		return checkResult{name: "backup", verdict: vWarn,
			detail: "no backup found — run 'accorder fedlib backup' (identity loss is unrecoverable)"}
	}
	var newest time.Time
	var name string
	for _, e := range entries {
		if e.IsDir() || !strings.HasSuffix(e.Name(), ".tar.zst") {
			continue
		}
		info, err := e.Info()
		if err != nil {
			continue
		}
		if info.ModTime().After(newest) {
			newest, name = info.ModTime(), e.Name()
		}
	}
	if name == "" {
		return checkResult{name: "backup", verdict: vWarn,
			detail: "no backup found — run 'accorder fedlib backup' (identity loss is unrecoverable)"}
	}
	age := time.Since(newest)
	detail := fmt.Sprintf("%s old (%s)", formatAge(age), name)
	if age > 30*24*time.Hour {
		return checkResult{name: "backup", verdict: vWarn, detail: detail + " — older than 30 days"}
	}
	return checkResult{name: "backup", verdict: vOK, detail: detail}
}

func formatAge(d time.Duration) string {
	switch days := int(d.Hours() / 24); {
	case days >= 1:
		return fmt.Sprintf("%d %s", days, plural(days, "day", "days"))
	case d.Hours() >= 1:
		return fmt.Sprintf("%d %s", int(d.Hours()), plural(int(d.Hours()), "hour", "hours"))
	default:
		return "less than an hour"
	}
}

func (c *DoctorCmd) readinessURL() string {
	if c.Endpoint != "" {
		return c.Endpoint
	}
	listen := gjsonAliasString(c.ActionAlias, "fedlib.share.live.listen")
	if listen == "" {
		listen = "127.0.0.1:8723"
	}
	return "http://" + listen + "/info"
}

func (c *DoctorCmd) probeServe() (verdict, string) {
	url := c.readinessURL()
	client := &http.Client{Timeout: 10 * time.Second}
	resp, err := client.Get(url)
	if err != nil {
		return vSkipped, "no serve reachable at " + url
	}
	defer resp.Body.Close()
	switch resp.StatusCode {
	case http.StatusOK:
		return vOK, "ready at " + url
	case http.StatusUnauthorized:
		return vOK, "ready at " + url + " (private mode)"
	case http.StatusServiceUnavailable:
		return vNotReady, "warming up at " + url + " (503 is expected while the aggregate loads)"
	default:
		return vWarn, fmt.Sprintf("unexpected status %d at %s", resp.StatusCode, url)
	}
}

func (c *DoctorCmd) checkServe() checkResult {
	v, detail := c.probeServe()
	return checkResult{name: "serve", verdict: v, detail: detail}
}

func (c *DoctorCmd) runWait() error {
	deadline := time.Now().Add(c.Timeout)
	url := c.readinessURL()
	fmt.Printf("waiting for %s (503 while loading is expected)\n", url)
	for {
		v, detail := c.probeServe()
		if v == vOK {
			fmt.Println("ready:", detail)
			return nil
		}
		if time.Now().After(deadline) {
			return fmt.Errorf("doctor --wait: not ready after %s — %s", c.Timeout, detail)
		}
		time.Sleep(10 * time.Second)
	}
}

func gjsonAliasString(alias, path string) string {
	data, err := tryLoadActionAliases()
	if err != nil {
		return ""
	}
	return gjson.GetBytes(data, alias+"."+path).String()
}

func kindLabel(k rotKind, n int) string {
	labels := map[rotKind][2]string{
		rotDeadKey:            {"dead key", "dead keys"},
		rotDeadSubtree:        {"unknown subtree", "unknown subtrees"},
		rotDefaultShadow:      {"default shadow", "default shadows"},
		rotDanglingPath:       {"dangling path", "dangling paths"},
		rotExcludedKey:        {"leaked secret key", "leaked secret keys"},
		rotEmptyNode:          {"empty node", "empty nodes"},
		rotForeignKey:         {"foreign key", "foreign keys"},
		rotCorruptEntry:       {"corrupt entry", "corrupt entries"},
		rotStaleCacheTree:     {"stranded cache tree", "stranded cache trees"},
		rotRetainedAliasJSONL: {"retained JSONL", "retained JSONLs"},
		rotDriftedKey:         {"drifted setting", "drifted settings"},
	}
	l, ok := labels[k]
	if !ok {
		return "finding"
	}
	if n == 1 {
		return l[0]
	}
	return l[1]
}
