package cmd

import (
	"archive/tar"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/klauspost/compress/zstd"
)

type FedlibBackupCmd struct {
	Output string `name:"output" help:"Output tarball path (.tar.zst). Defaults to <config-dir>/backups/accorder-backup-<timestamp>.tar.zst."`
}

func backupsDir() string { return filepath.Join(accorderConfigDir, "backups") }

func defaultBackupPath(now time.Time) string {
	return filepath.Join(backupsDir(), "accorder-backup-"+now.UTC().Format("20060102T150405Z")+".tar.zst")
}

func (c *FedlibBackupCmd) Run() error {
	files := enumerateBackupFiles(accorderConfigDir)
	if len(files) == 0 {
		return fmt.Errorf("fedlib backup: no identity files found under %s", accorderConfigDir)
	}

	if c.Output == "" {
		c.Output = defaultBackupPath(time.Now())
	}
	if err := ensureConfigDir(c.Output); err != nil {
		return fmt.Errorf("fedlib backup: create output dir: %w", err)
	}

	f, err := os.CreateTemp(filepath.Dir(c.Output), ".fedlib-backup-*")
	if err != nil {
		return fmt.Errorf("fedlib backup: create temp: %w", err)
	}
	tmpPath := f.Name()
	defer func() {
		f.Close()
		if tmpPath != "" {
			os.Remove(tmpPath)
		}
	}()

	zw, err := zstd.NewWriter(f)
	if err != nil {
		return fmt.Errorf("fedlib backup: zstd writer: %w", err)
	}
	tw := tar.NewWriter(zw)

	written := 0
	for _, abs := range files {
		rel, err := filepath.Rel(accorderConfigDir, abs)
		if err != nil {
			return fmt.Errorf("fedlib backup: rel path for %s: %w", abs, err)
		}

		info, err := os.Stat(abs)
		if err != nil {
			return fmt.Errorf("fedlib backup: stat %s: %w", abs, err)
		}

		hdr, err := tar.FileInfoHeader(info, "")
		if err != nil {
			return fmt.Errorf("fedlib backup: header for %s: %w", abs, err)
		}
		hdr.Name = rel

		if err := tw.WriteHeader(hdr); err != nil {
			return fmt.Errorf("fedlib backup: write header %s: %w", rel, err)
		}

		if !info.IsDir() {
			data, err := os.ReadFile(abs)
			if err != nil {
				return fmt.Errorf("fedlib backup: read %s: %w", abs, err)
			}
			if _, err := tw.Write(data); err != nil {
				return fmt.Errorf("fedlib backup: write %s: %w", rel, err)
			}
		}
		written++
	}

	if err := tw.Close(); err != nil {
		return fmt.Errorf("fedlib backup: close tar: %w", err)
	}
	if err := zw.Close(); err != nil {
		return fmt.Errorf("fedlib backup: close zstd: %w", err)
	}
	if err := f.Close(); err != nil {
		return fmt.Errorf("fedlib backup: close file: %w", err)
	}
	if err := os.Rename(tmpPath, c.Output); err != nil {
		return fmt.Errorf("fedlib backup: rename: %w", err)
	}
	tmpPath = ""

	fmt.Printf("backed up %d files (%s) to %s\n", written, categorizeBackupFiles(accorderConfigDir, files), c.Output)
	return nil
}

func enumerateBackupFiles(configDir string) []string {
	var files []string
	_ = filepath.WalkDir(configDir, func(path string, d fs.DirEntry, err error) error {
		if err != nil {
			return nil
		}
		rel, rerr := filepath.Rel(configDir, path)
		if rerr != nil || rel == "." {
			return nil
		}
		if d.IsDir() {
			if backupSkipDir(filepath.ToSlash(rel)) {
				return fs.SkipDir
			}
			return nil
		}
		if !d.Type().IsRegular() || backupSkipFile(filepath.Base(rel)) {
			return nil
		}
		files = append(files, path)
		return nil
	})
	return files
}

func backupSkipDir(rel string) bool {
	switch rel {
	case "cache", "backups", "indexes", "aggregate", "machine-state", "tor/cache":
		return true
	}
	return false
}

func backupSkipFile(base string) bool {
	if strings.HasSuffix(base, ".lock") || strings.HasSuffix(base, ".tmp") {
		return true
	}
	if strings.HasPrefix(base, "cached-") {
		return true
	}

	if strings.HasPrefix(base, "tailscaled.log") && strings.HasSuffix(base, ".txt") {
		return true
	}
	switch base {
	case "lock", "tor.log", "tor.pid", "control_port", "control_auth_cookie":
		return true
	}
	return false
}

func categorizeBackupFiles(configDir string, files []string) string {
	var torFiles, signingKeys, grants, registries, secretsFiles, keysFiles, tailscale, other int
	for _, f := range files {
		rel, err := filepath.Rel(configDir, f)
		if err != nil {
			other++
			continue
		}
		seg, _, _ := strings.Cut(filepath.ToSlash(rel), "/")
		base := filepath.Base(rel)
		switch {
		case base == "signing.key":
			signingKeys++
		case base == "grants.json":
			grants++
		case seg == "tor":
			torFiles++
		case base == "secrets.age" || base == "secrets.key":
			secretsFiles++
		case base == "fedlibs.json" || base == "aggregate_libraries.json" || base == "motw_libraries.json" || base == "indices.json":
			registries++
		case seg == "keys" || strings.HasSuffix(base, ".keys"):
			keysFiles++
		case seg == "tailscale_state":
			tailscale++
		default:
			other++
		}
	}
	var parts []string
	if torFiles > 0 {
		parts = append(parts, fmt.Sprintf("%d tor file(s)", torFiles))
	}
	if signingKeys > 0 {
		parts = append(parts, fmt.Sprintf("%d signing key(s)", signingKeys))
	}
	if grants > 0 {
		parts = append(parts, fmt.Sprintf("%d grant file(s)", grants))
	}
	if registries > 0 {
		parts = append(parts, fmt.Sprintf("%d registry file(s)", registries))
	}
	if secretsFiles > 0 {
		parts = append(parts, fmt.Sprintf("%d secrets-store file(s)", secretsFiles))
	}
	if keysFiles > 0 {
		parts = append(parts, fmt.Sprintf("%d credential key file(s)", keysFiles))
	}
	if tailscale > 0 {
		parts = append(parts, fmt.Sprintf("%d tailscale state file(s)", tailscale))
	}
	if other > 0 {
		parts = append(parts, fmt.Sprintf("%d other config file(s)", other))
	}
	if len(parts) == 0 {
		return "no identity files"
	}
	return strings.Join(parts, ", ")
}
