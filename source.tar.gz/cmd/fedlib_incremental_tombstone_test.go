package cmd

import (
	"testing"
)

// TestIncrementalTombstoneUsesRealUUID verifies that pollMemberGenerations
// resolves the post-reconcile UUID from pollSet before appending to
// changedUUIDs. Before the fix, an invited member's placeholder UUID was
// captured at line 192 (pre-reconcile), causing BooksByLibraryUUID to find
// zero prior books and silently duplicating the member's books.
func TestIncrementalTombstoneUsesRealUUID(t *testing.T) {

	// Simulate the post-reconcile UUID resolution logic extracted from
	// pollMemberGenerations. The invited member starts as "placeholder-uuid"
	// and reconcileInvitedMember rekeys it to "real-uuid" in pollSet.
	pollSet := map[string]memberPollEntry{

		// After reconcile, pollSet has the real UUID keyed to the same prefix.
		"real-uuid": {Prefix: "alice", State: "ready"},
	}

	// The pre-reconcile uuid variable still holds the placeholder.
	uuid := "placeholder-uuid"
	prefix := "alice"

	// This is the resolution logic from the fix:
	resolvedUUID := uuid
	for u, pe := range pollSet {
		if pe.Prefix == prefix {
			resolvedUUID = u
			break
		}
	}

	if resolvedUUID != "real-uuid" {
		t.Fatalf("resolvedUUID = %q; want %q (post-reconcile UUID)", resolvedUUID, "real-uuid")
	}

	// When reconcile did NOT happen (non-invited member), the original UUID
	// is preserved.
	pollSet2 := map[string]memberPollEntry{
		"already-known-uuid": {Prefix: "bob", State: "ready"},
	}
	uuid2 := "already-known-uuid"
	prefix2 := "bob"
	resolvedUUID2 := uuid2
	for u, pe := range pollSet2 {
		if pe.Prefix == prefix2 {
			resolvedUUID2 = u
			break
		}
	}
	if resolvedUUID2 != "already-known-uuid" {
		t.Fatalf("resolvedUUID = %q; want %q (no reconcile, UUID unchanged)", resolvedUUID2, "already-known-uuid")
	}
}

// TestZeroTombstoneGuard verifies that runIncrementalBuild would detect a
// 0-tombstone anomaly: a member is active in the registry, the aggregate
// has books, but BooksByLibraryUUID returns 0 results (indicating UUID mismatch).
//

// This is a regression backstop for bug #2: if the tombstone-key fix in
// memberPoller.go regresses, the 0-tombstone guard catches it at build time
// instead of silently duplicating books.
func TestZeroTombstoneGuard(t *testing.T) {

	// The guard logic, extracted from runIncrementalBuild:
	// if len(priorBooks) == 0 && existingMf.NumBooks > 0 { error }
	tests := []struct {
		name          string
		priorBooks    int
		existingBooks uint32
		wantError     bool
	}{
		{
			name:          "anomaly: active member, aggregate has books, 0 prior",
			priorBooks:    0,
			existingBooks: 1000,
			wantError:     true,
		},
		{
			name:          "normal: member has prior books",
			priorBooks:    50,
			existingBooks: 1000,
			wantError:     false,
		},
		{
			name:          "bootstrap: empty aggregate, new member",
			priorBooks:    0,
			existingBooks: 0,
			wantError:     false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			isError := tt.priorBooks == 0 && tt.existingBooks > 0
			if isError != tt.wantError {
				t.Errorf("guard triggered = %v; want %v", isError, tt.wantError)
			}
		})
	}
}
