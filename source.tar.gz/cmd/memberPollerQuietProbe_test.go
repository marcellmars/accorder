//go:build !tailscale

package cmd

import (
	"context"
	"os"
	"path/filepath"
	"testing"

	"accorder/pkg/calibre"
	"accorder/pkg/rclonexfer"
)

// newProbeContext builds a poll context with a single rclone-backed member in
// the given state, over a local directory standing in for the bucket.
func newProbeContext(t *testing.T, uuid, prefix, state string) *memberPollContext {
	t.Helper()
	return &memberPollContext{
		pollSet:          map[string]memberPollEntry{uuid: {Prefix: prefix, State: state}},
		registryPrefixes: map[string]string{uuid: prefix},
		registryPath:     filepath.Join(t.TempDir(), "members.json"),
		lastKnownGen:     make(map[string][24]byte),
		healthState:      make(map[string]*memberHealth),
	}
}

// An invited member has published nothing, so its _GENERATION is absent by
// definition until it joins. Probing with a copy made rclone log an ERROR every
// poll for the entire waiting period — indefinitely if the invite is never
// claimed — which during the 2026-08-30 outage read like a fault and cost
// triage time. The probe must be silent, and must not accrue health errors
// against a member that has not been asked to be reachable yet.
func TestPollMemberGenerations_InvitedMemberWaitsQuietly(t *testing.T) {
	rclonexfer.Initialize()
	defer rclonexfer.Finalize()

	bucket := t.TempDir() // no <prefix>/_GENERATION in it
	mpc := newProbeContext(t, "u-invited", "virtuethecat", "invited")

	changed, changedUUIDs := pollMemberGenerations(context.Background(), bucket, t.TempDir(), mpc)

	if changed || len(changedUUIDs) != 0 {
		t.Errorf("absent _GENERATION reported a change: changed=%v uuids=%v", changed, changedUUIDs)
	}
	if h := mpc.healthState["u-invited"]; h != nil && h.ConsecErrors != 0 {
		t.Errorf("waiting invited member accrued %d health errors; waiting is not failing", h.ConsecErrors)
	}
}

// The quiet path must not swallow the signal for members that ARE expected to
// be reachable: for a ready member a missing _GENERATION is a real fault, and
// the probe still records it so the retire logic can eventually act.
func TestPollMemberGenerations_ReadyMemberStillRecordsMissing(t *testing.T) {
	rclonexfer.Initialize()
	defer rclonexfer.Finalize()

	bucket := t.TempDir()
	mpc := newProbeContext(t, "u-ready", "biopolitics", "ready")

	pollMemberGenerations(context.Background(), bucket, t.TempDir(), mpc)

	h := mpc.healthState["u-ready"]
	if h == nil || h.ConsecErrors == 0 {
		t.Fatalf("ready member with no _GENERATION recorded no error: %+v", h)
	}
}

// A published sentinel without its index can occur during an incomplete or
// temporarily unreadable publication. Reconciliation must leave that generation
// pending so the identical token is retried after the index becomes available.
func TestPollMemberGenerations_InvitedMemberRetriesReconcile(t *testing.T) {
	rclonexfer.Initialize()
	defer rclonexfer.Finalize()

	bucket := t.TempDir()
	const (
		invitedUUID = "u-invited"
		memberUUID  = "real-member-uuid-0001"
		prefix      = "virtuethecat"
	)
	prefixDir := filepath.Join(bucket, prefix)
	if err := os.MkdirAll(prefixDir, 0o755); err != nil {
		t.Fatal(err)
	}
	// 24 bytes: the fixed-width _GENERATION frame the poller copies and decodes.
	generation := make([]byte, 24)
	if err := os.WriteFile(filepath.Join(prefixDir, "_GENERATION"), generation, 0o644); err != nil {
		t.Fatal(err)
	}

	probeDir := t.TempDir()
	mpc := newProbeContext(t, invitedUUID, prefix, "invited")
	if err := saveMembersRegistry(mpc.registryPath, map[string]calibre.LibraryMeta{
		invitedUUID: {Prefix: prefix, State: "invited"},
	}); err != nil {
		t.Fatalf("seed registry: %v", err)
	}
	changed, changedUUIDs := pollMemberGenerations(context.Background(), bucket, probeDir, mpc)

	// The quiet probe detected the sentinel, but the missing index prevented
	// admission. This must not trigger a no-op rebuild or consume the token.
	if _, err := os.Stat(filepath.Join(probeDir, prefix+"__GENERATION")); err != nil {
		t.Fatalf("first publish was not fetched by the quiet probe path: %v", err)
	}
	if changed || len(changedUUIDs) != 0 {
		t.Fatalf("failed reconcile reported a member change: changed=%v uuids=%v", changed, changedUUIDs)
	}
	if _, consumed := mpc.lastKnownGen[prefix]; consumed {
		t.Fatal("failed reconcile consumed the invited member generation")
	}
	if h := mpc.healthState[invitedUUID]; h != nil && h.ConsecErrors != 0 {
		t.Errorf("successful probe recorded %d errors", h.ConsecErrors)
	}
	if mpc.membershipChanged {
		t.Fatal("failed reconcile of an invited member was classified as a membership topology change")
	}

	// Finish the same publication without advancing its sentinel. The next poll
	// must retry reconciliation and admit it as a topology change.
	buildMinimalIndexWithUUID(t, prefixDir, memberUUID)
	if err := os.WriteFile(filepath.Join(prefixDir, "_GENERATION"), generation, 0o644); err != nil {
		t.Fatal(err)
	}
	changed, changedUUIDs = pollMemberGenerations(context.Background(), bucket, probeDir, mpc)
	if !changed || len(changedUUIDs) != 1 || changedUUIDs[0] != memberUUID {
		t.Fatalf("retried reconcile: changed=%v uuids=%v, want true [%s]", changed, changedUUIDs, memberUUID)
	}
	if !mpc.membershipChanged {
		t.Fatal("successful invited reconcile was not classified as a topology change")
	}
	if got := mpc.pollSet[memberUUID]; got.State != "ready" || got.Prefix != prefix {
		t.Fatalf("reconciled poll entry = %+v, want ready member at %s", got, prefix)
	}
}
