package cmd

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"syscall"
)

var errFlockUnsupported = errors.New("file locking is not supported on this platform; destructive cache reclaim is disabled (report-only)")

const (
	cacheLocksDirName    = "locks"
	gcLockName           = "gc.lock"
	activationMarkerName = "reclaim-activated"
	identityLedgerName   = "identity-ledger.jsonl"
	renameIntentName     = "rename-intent.json"
)

func cacheLocksDir() string        { return filepath.Join(accorderCacheDir(), cacheLocksDirName) }
func gcLockPath() string           { return filepath.Join(cacheLocksDir(), gcLockName) }
func activationMarkerPath() string { return filepath.Join(cacheLocksDir(), activationMarkerName) }
func identityLedgerPath() string   { return filepath.Join(cacheLocksDir(), identityLedgerName) }
func renameIntentPath() string     { return filepath.Join(cacheLocksDir(), renameIntentName) }

func mutationLockPath(remoteName string) string {
	return filepath.Join(cacheLocksDir(), "remote-"+remoteName+".lock")
}

func mutationStatePath(remoteName string) string {
	return filepath.Join(cacheLocksDir(), "remote-"+remoteName+".json")
}

func leaseLockPath(name string) string {
	return filepath.Join(cacheLocksDir(), "lease-"+name+".lock")
}

func leaseStatePath(name string) string {
	return filepath.Join(cacheLocksDir(), "lease-"+name+".json")
}

func openLockFile(path string) (*os.File, error) {
	if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
		return nil, err
	}
	return os.OpenFile(path, os.O_CREATE|os.O_RDONLY, 0o600)
}

func withGCLock(fn func() error) error {
	f, err := openLockFile(gcLockPath())
	if err != nil {
		return fmt.Errorf("gc lock: %w", err)
	}
	defer f.Close()
	release, err := lockFileExclusive(f)
	if err != nil {
		return fmt.Errorf("gc lock: %w", err)
	}
	defer release()
	return fn()
}

type mutationLockState struct {
	RemoteName string `json:"remoteName"`
	RemoteRoot string `json:"remoteRoot"`
}

func acquireMutationLock(remoteName, remoteRoot string) (release func(), ok bool, err error) {
	f, err := openLockFile(mutationLockPath(remoteName))
	if err != nil {
		return nil, false, err
	}
	rel, ok, err := tryLockFileExclusive(f)
	if err != nil || !ok {
		f.Close()
		return nil, ok, err
	}
	if remoteRoot != "" {
		st, merr := json.Marshal(mutationLockState{RemoteName: remoteName, RemoteRoot: remoteRoot})
		if merr == nil {
			merr = writeFileDurable(mutationStatePath(remoteName), st, 0o600)
		}
		if merr != nil {
			rel()
			f.Close()
			return nil, false, fmt.Errorf("mutation lock state for %s: %w", remoteName, merr)
		}
	}
	return func() { rel(); f.Close() }, true, nil
}

type serveLease struct {
	name  string
	f     *os.File
	rel   func()
	state serveLeaseState
}

type serveLeaseState struct {
	Current string `json:"current,omitempty"`
	Pending string `json:"pending,omitempty"`
}

func acquireServeLease(name string) (*serveLease, error) {
	f, err := openLockFile(leaseLockPath(name))
	if err != nil {
		return nil, err
	}
	rel, ok, err := tryLockFileExclusive(f)
	if err != nil {
		f.Close()

		if errors.Is(err, errFlockUnsupported) {
			return &serveLease{name: name, f: nil, rel: func() {}}, nil
		}
		return nil, fmt.Errorf("serve lease %s: %w", name, err)
	}
	if !ok {
		f.Close()
		return nil, fmt.Errorf("another serve already holds lease %q — same alias/serve running twice against one cache dir", name)
	}
	l := &serveLease{name: name, f: f, rel: rel}

	if err := withGCLock(func() error { return l.writeStateLocked() }); err != nil {
		l.Release()
		return nil, err
	}
	return l, nil
}

func (l *serveLease) setPendingLocked(name string) error {
	l.state.Pending = name
	return l.writeStateLocked()
}

func (l *serveLease) commitPendingLocked(current string) error {
	l.state.Current = current
	l.state.Pending = ""
	return l.writeStateLocked()
}

func (l *serveLease) clearPendingLocked() error {
	l.state.Pending = ""
	return l.writeStateLocked()
}

func (l *serveLease) writeStateLocked() error {
	if l.f == nil {
		return nil
	}
	st, err := json.Marshal(l.state)
	if err != nil {
		return err
	}
	return writeFileDurable(leaseStatePath(l.name), st, 0o600)
}

func (l *serveLease) Release() {
	if l.rel != nil {
		l.rel()
	}
	if l.f != nil {
		l.f.Close()
	}
}

func heldLeaseDicts() (map[string]bool, error) {
	held := make(map[string]bool)
	entries, err := os.ReadDir(cacheLocksDir())
	if err != nil {
		if os.IsNotExist(err) {
			return held, nil
		}
		return nil, err
	}
	for _, e := range entries {
		name := e.Name()
		if !strings.HasPrefix(name, "lease-") || !strings.HasSuffix(name, ".lock") {
			continue
		}
		leaseName := strings.TrimSuffix(strings.TrimPrefix(name, "lease-"), ".lock")
		f, err := openLockFile(filepath.Join(cacheLocksDir(), name))
		if err != nil {
			return nil, err
		}
		rel, ok, err := tryLockFileExclusive(f)
		if err != nil {
			f.Close()
			return nil, err
		}
		if ok {
			rel()
			f.Close()
			continue
		}
		f.Close()
		data, err := os.ReadFile(leaseStatePath(leaseName))
		if err != nil {
			if os.IsNotExist(err) {
				continue
			}
			return nil, err
		}
		var st serveLeaseState
		if err := json.Unmarshal(data, &st); err != nil {

			return nil, fmt.Errorf("lease %s state unreadable: %w", leaseName, err)
		}
		if st.Current != "" {
			held[st.Current] = true
		}
		if st.Pending != "" {
			held[st.Pending] = true
		}
	}
	return held, nil
}

func reclaimActivated() bool {
	if !platformLocksWork() {
		return false
	}
	_, err := os.Stat(activationMarkerPath())
	return err == nil
}

func platformLocksWork() bool {
	f, err := openLockFile(gcLockPath())
	if err != nil {
		return false
	}
	defer f.Close()
	rel, ok, err := tryLockFileExclusive(f)
	if err != nil {
		return false
	}
	if ok {
		rel()
	}
	return true
}

func writeActivationMarker() error {
	if !platformLocksWork() {
		return errFlockUnsupported
	}
	if err := writeFileDurable(activationMarkerPath(), []byte("activated\n"), 0o600); err != nil {
		return err
	}
	return syncDir(filepath.Dir(activationMarkerPath()))
}

func writeFileDurable(path string, data []byte, perm os.FileMode) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
		return err
	}
	tmp, err := os.CreateTemp(filepath.Dir(path), filepath.Base(path)+".tmp-*")
	if err != nil {
		return err
	}
	tmpPath := tmp.Name()
	cleanup := func() { tmp.Close(); os.Remove(tmpPath) }
	if err := tmp.Chmod(perm); err != nil {
		cleanup()
		return err
	}
	if _, err := tmp.Write(data); err != nil {
		cleanup()
		return err
	}
	if err := tmp.Sync(); err != nil {
		cleanup()
		return err
	}
	if err := tmp.Close(); err != nil {
		os.Remove(tmpPath)
		return err
	}
	if err := os.Rename(tmpPath, path); err != nil {
		os.Remove(tmpPath)
		return err
	}
	return syncDir(filepath.Dir(path))
}

func syncDir(dir string) error {
	d, err := os.Open(dir)
	if err != nil {
		return err
	}
	defer d.Close()

	if err := d.Sync(); err != nil {
		if runtime.GOOS == "windows" || errors.Is(err, syscall.EINVAL) || errors.Is(err, syscall.ENOTSUP) {
			return nil
		}
		return err
	}
	return nil
}
