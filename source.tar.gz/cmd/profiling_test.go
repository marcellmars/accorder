//go:build !tailscale

package cmd

import (
	"fmt"
	"io"
	"net"
	"net/http"
	"strings"
	"testing"
)

func TestStartPprofListener_LoopbackServesHeapProfile(t *testing.T) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	addr := ln.Addr().String()
	ln.Close()

	if err := startPprofListener(addr); err != nil {
		t.Fatalf("loopback bind refused: %v", err)
	}

	resp, err := http.Get(fmt.Sprintf("http://%s/debug/pprof/heap?debug=1", addr))
	if err != nil {
		t.Fatalf("GET heap profile: %v", err)
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	if resp.StatusCode != 200 || !strings.Contains(string(body), "heap profile") {
		t.Errorf("heap endpoint: status %d, body starts %q", resp.StatusCode, string(body[:min(80, len(body))]))
	}
}

func TestStartPprofListener_RefusesNonLoopback(t *testing.T) {
	for _, addr := range []string{"0.0.0.0:8724", "192.168.1.10:8724", "example.com:8724", "8724"} {
		if err := startPprofListener(addr); err == nil {
			t.Errorf("addr %q: want refusal, got nil", addr)
		}
	}
}
