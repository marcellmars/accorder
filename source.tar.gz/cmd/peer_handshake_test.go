package cmd

import (
	"accorder/pkg/calibre"
	"accorder/pkg/fedlibinvite"
	"bytes"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/goccy/go-json"
)

func TestPeerOfferCreate(t *testing.T) {
	offersDir := t.TempDir()

	token, err := fedlibinvite.NewOfferToken()
	if err != nil {
		t.Fatalf("NewOfferToken: %v", err)
	}

	offer, err := fedlibinvite.SealPeerOffer(token, "test-fed", "alice", "Alice", time.Now().Add(24*time.Hour))
	if err != nil {
		t.Fatalf("SealPeerOffer: %v", err)
	}
	offer.OfferKind = "peer"

	if err := fedlibinvite.WriteOffer(offersDir, token, offer); err != nil {
		t.Fatalf("WriteOffer: %v", err)
	}

	// Read it back and verify.
	readBack, err := fedlibinvite.ReadOffer(offersDir, token)
	if err != nil {
		t.Fatalf("ReadOffer: %v", err)
	}
	if !readBack.IsPeerOffer() {
		t.Error("expected IsPeerOffer() = true")
	}
	if readBack.Prefix != "alice" {
		t.Errorf("Prefix = %q, want %q", readBack.Prefix, "alice")
	}
	if readBack.DisplayName != "Alice" {
		t.Errorf("DisplayName = %q, want %q", readBack.DisplayName, "Alice")
	}
}

func TestPeerClaimHandler(t *testing.T) {
	offersDir := t.TempDir()
	registryDir := t.TempDir()
	registryPath := filepath.Join(registryDir, "members.json")

	// Write an empty registry.
	os.WriteFile(registryPath, []byte("{}"), 0o600)

	// Create a peer offer.
	token, err := fedlibinvite.NewOfferToken()
	if err != nil {
		t.Fatalf("NewOfferToken: %v", err)
	}
	offer, err := fedlibinvite.SealPeerOffer(token, "test-fed", "alice", "Alice", time.Now().Add(24*time.Hour))
	if err != nil {
		t.Fatalf("SealPeerOffer: %v", err)
	}
	offer.OfferKind = "peer"
	if err := fedlibinvite.WriteOffer(offersDir, token, offer); err != nil {
		t.Fatalf("WriteOffer: %v", err)
	}

	// Set up the handler.
	limiter := newIPRateLimiter(1000, time.Millisecond)
	handler := makeInviteHandler(offersDir, limiter, registryPath)
	srv := httptest.NewServer(handler)
	defer srv.Close()

	// Sub-test 1: GET info shows peer offer.
	t.Run("info_shows_peer", func(t *testing.T) {
		resp, err := http.Get(srv.URL + "/invite/" + token)
		if err != nil {
			t.Fatalf("GET: %v", err)
		}
		resp.Body.Close()
		if resp.StatusCode != http.StatusOK {
			t.Fatalf("expected 200, got %d", resp.StatusCode)
		}
	})

	// Sub-test 2: POST claim with peer payload → 201.
	t.Run("claim_peer", func(t *testing.T) {
		body := peerClaimRequest{
			LibraryUUID: "peer-lib-uuid-1234",
			Endpoint:    "http://peer.example.com",
			GrantToken:  "peer-grant-token",
		}
		bodyJSON, _ := json.Marshal(body)
		resp, err := http.Post(srv.URL+"/invite/"+token+"/claim", "application/json", bytes.NewReader(bodyJSON))
		if err != nil {
			t.Fatalf("POST: %v", err)
		}
		resp.Body.Close()
		if resp.StatusCode != http.StatusCreated {
			t.Fatalf("expected 201, got %d", resp.StatusCode)
		}

		// Verify the member was registered.
		registry, _, err := loadMembersRegistryFromPath(registryPath)
		if err != nil {
			t.Fatalf("load registry: %v", err)
		}
		meta, ok := registry["peer-lib-uuid-1234"]
		if !ok {
			t.Fatal("peer member not found in registry")
		}
		if meta.Kind != "peer" {
			t.Errorf("Kind = %q, want %q", meta.Kind, "peer")
		}
		if meta.Endpoint != "http://peer.example.com" {
			t.Errorf("Endpoint = %q, want %q", meta.Endpoint, "http://peer.example.com")
		}
		if meta.GrantToken != "peer-grant-token" {
			t.Errorf("GrantToken = %q, want %q", meta.GrantToken, "peer-grant-token")
		}
		if meta.Prefix != "alice" {
			t.Errorf("Prefix = %q, want %q", meta.Prefix, "alice")
		}
		if meta.Librarian != "Alice" {
			t.Errorf("Librarian = %q, want %q", meta.Librarian, "Alice")
		}
		if meta.State != "ready" {
			t.Errorf("State = %q, want %q", meta.State, "ready")
		}
	})

	// Sub-test 3: Claim again → 404 (claim-once).
	t.Run("claim_once", func(t *testing.T) {
		body := peerClaimRequest{
			LibraryUUID: "another-peer-uuid",
			Endpoint:    "http://other.example.com",
			GrantToken:  "other-token",
		}
		bodyJSON, _ := json.Marshal(body)
		resp, err := http.Post(srv.URL+"/invite/"+token+"/claim", "application/json", bytes.NewReader(bodyJSON))
		if err != nil {
			t.Fatalf("POST: %v", err)
		}
		resp.Body.Close()
		if resp.StatusCode != http.StatusNotFound {
			t.Fatalf("expected 404 (offer consumed), got %d", resp.StatusCode)
		}
	})
}

func TestPeerClaimHandler_DuplicateUUID(t *testing.T) {
	offersDir := t.TempDir()
	registryDir := t.TempDir()
	registryPath := filepath.Join(registryDir, "members.json")

	// Pre-populate registry with an existing member.
	registry := map[string]calibre.LibraryMeta{
		"existing-uuid": {Prefix: "bob", State: "ready", Kind: "rclone"},
	}
	data, _ := json.Marshal(registry)
	os.WriteFile(registryPath, data, 0o600)

	token, _ := fedlibinvite.NewOfferToken()
	offer, _ := fedlibinvite.SealPeerOffer(token, "test-fed", "alice", "Alice", time.Now().Add(24*time.Hour))
	offer.OfferKind = "peer"
	if err := fedlibinvite.WriteOffer(offersDir, token, offer); err != nil {
		t.Fatalf("write offer: %v", err)
	}

	limiter := newIPRateLimiter(1000, time.Millisecond)
	handler := makeInviteHandler(offersDir, limiter, registryPath)
	srv := httptest.NewServer(handler)
	defer srv.Close()

	body := peerClaimRequest{
		LibraryUUID: "existing-uuid",
		Endpoint:    "http://peer.example.com",
		GrantToken:  "peer-grant-token",
	}
	bodyJSON, _ := json.Marshal(body)
	resp, err := http.Post(srv.URL+"/invite/"+token+"/claim", "application/json", bytes.NewReader(bodyJSON))
	if err != nil {
		t.Fatalf("POST: %v", err)
	}
	resp.Body.Close()
	if resp.StatusCode != http.StatusConflict {
		t.Fatalf("expected 409 for duplicate UUID, got %d", resp.StatusCode)
	}
}

func TestPeerClaimHandler_MissingFields(t *testing.T) {
	offersDir := t.TempDir()
	registryDir := t.TempDir()
	registryPath := filepath.Join(registryDir, "members.json")
	os.WriteFile(registryPath, []byte("{}"), 0o600)

	token, _ := fedlibinvite.NewOfferToken()
	offer, _ := fedlibinvite.SealPeerOffer(token, "test-fed", "alice", "Alice", time.Now().Add(24*time.Hour))
	offer.OfferKind = "peer"
	if err := fedlibinvite.WriteOffer(offersDir, token, offer); err != nil {
		t.Fatalf("write offer: %v", err)
	}

	limiter := newIPRateLimiter(1000, time.Millisecond)
	handler := makeInviteHandler(offersDir, limiter, registryPath)
	srv := httptest.NewServer(handler)
	defer srv.Close()

	// Missing endpoint.
	body := peerClaimRequest{
		LibraryUUID: "uuid-1234",
		GrantToken:  "tok",
	}
	bodyJSON, _ := json.Marshal(body)
	resp, err := http.Post(srv.URL+"/invite/"+token+"/claim", "application/json", bytes.NewReader(bodyJSON))
	if err != nil {
		t.Fatalf("POST: %v", err)
	}
	resp.Body.Close()
	if resp.StatusCode != http.StatusBadRequest {
		t.Fatalf("expected 400 for missing fields, got %d", resp.StatusCode)
	}
}
