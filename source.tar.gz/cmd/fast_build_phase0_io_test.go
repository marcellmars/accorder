//go:build linux && !tailscale

package cmd

import (
	"bufio"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"syscall"
	"testing"
	"time"

	"accorder/pkg/calibre"
	"accorder/pkg/libraryflow"
	"accorder/pkg/rclonexfer"
)

// Subprocess-only probe: the parent owns all fixture creation, so byte counts
// describe the operation rather than test setup. No production hash seam is
// replaced. The escaped-read positive control bypasses that seam deliberately.
func TestFastBuildPhase0ReadProbe(t *testing.T) {
	mode := os.Getenv("ACCORDER_PHASE0_PROBE")
	if mode == "" {
		t.Skip("subprocess probe")
	}
	root := os.Getenv("ACCORDER_PHASE0_SOURCE")
	switch mode {
	case "command-pipeline", "command-pipeline-v1":
		accorderConfigDir = filepath.Join(os.Getenv("XDG_CONFIG_HOME"), "accorder")
		if config := os.Getenv("ACCORDER_PHASE0_CONFIG"); config != "" {
			accorderConfigDir = config
		}
		if err := os.MkdirAll(accorderConfigDir, 0o700); err != nil {
			t.Fatal(err)
		}
		build := fastBuildCommand(root)
		if err := build.Run(nil); err != nil {
			t.Fatal(err)
		}
		if err := build.Run(nil); err != nil {
			t.Fatal(err)
		}
		upload := &LibUploadCmd{GroupLib: build.GroupLib}
		upload.ActionAlias = "alice"
		candidate, _, err := upload.prepareUploadCandidate(nil, resolveUploadExcludes(root, nil))
		if err != nil || candidate.Change == nil {
			t.Fatalf("prepare upload: %v", err)
		}
	case "inventory":
		if _, _, _, err := phase0Inventory(root, nil, nil); err != nil {
			t.Fatal(err)
		}
	case "escaped-read":
		if _, err := os.ReadFile(filepath.Join(root, "book.epub")); err != nil {
			t.Fatal(err)
		}
	case "rclone":
		rclonexfer.Initialize()
		defer rclonexfer.Finalize()
		if err := rclonexfer.CopyFileOverwrite(root, "book.epub", os.Getenv("ACCORDER_PHASE0_DESTINATION"), "book.epub"); err != nil {
			t.Fatal(err)
		}
	default:
		t.Fatalf("unknown probe mode %q", mode)
	}
}

type phase0ReadAudit struct {
	ReadBytes     int64 `json:"read_bytes"`
	MappedBytes   int64 `json:"mapped_bytes"`
	MetadataCalls int   `json:"metadata_calls"`
}

func phase0ParseTrace(data []byte, path string) (phase0ReadAudit, error) {
	var result phase0ReadAudit
	reads := regexp.MustCompile(`^(read|pread64|readv|preadv|preadv2|sendfile|copy_file_range)\(`)
	returned := regexp.MustCompile(`\)\s+=\s+([0-9]+)`)
	mapped := regexp.MustCompile(`^mmap\([^,]+,\s*([0-9]+),`)
	pending := map[string]string{}
	for _, raw := range strings.Split(string(data), "\n") {
		pid, line, ok := strings.Cut(strings.TrimSpace(raw), " ")
		if !ok {
			continue
		}
		line = strings.TrimSpace(line)
		if at := strings.Index(line, "<unfinished ...>"); at >= 0 {
			if pending[pid] != "" {
				return result, fmt.Errorf("overlapping trace calls for pid %s", pid)
			}
			pending[pid] = line[:at]
			continue
		}
		if strings.HasPrefix(line, "<... ") {
			at := strings.Index(line, "resumed>")
			if at < 0 || pending[pid] == "" {
				return result, fmt.Errorf("unmatched resumed trace: %s", raw)
			}
			line = pending[pid] + line[at+len("resumed>"):]
			delete(pending, pid)
		}
		if !strings.Contains(line, path) {
			continue
		}
		if strings.HasPrefix(line, "newfstatat(") || strings.HasPrefix(line, "statx(") {
			result.MetadataCalls++
		}
		if reads.MatchString(line) {
			if match := returned.FindStringSubmatch(line); match != nil {
				count, err := strconv.ParseInt(match[1], 10, 64)
				if err != nil {
					return result, err
				}
				result.ReadBytes += count
			}
		}
		if match := mapped.FindStringSubmatch(line); match != nil && !strings.Contains(line, "= -1") {
			count, err := strconv.ParseInt(match[1], 10, 64)
			if err != nil {
				return result, err
			}
			result.MappedBytes += count // Conservative exposure, not observed page faults.
		}
	}
	if len(pending) != 0 {
		return result, fmt.Errorf("incomplete trace calls: %v", pending)
	}
	return result, nil
}

func TestFastBuildPhase0TraceParser(t *testing.T) {
	trace := "1 read(3</fixture/book.epub>, <unfinished ...>\n2 pread64(4</other>, ... , 2, 0) = 2\n1 <... read resumed> ... , 4) = 4\n1 mmap(NULL, 4096, PROT_READ, MAP_PRIVATE, 3</fixture/book.epub>, 0) = 0x1234\n"
	audit, err := phase0ParseTrace([]byte(trace), "/fixture/book.epub")
	if err != nil || audit.ReadBytes != 4 || audit.MappedBytes != 4096 {
		t.Fatalf("audit=%+v err=%v", audit, err)
	}
	if _, err := phase0ParseTrace([]byte("1 read(3</fixture/book.epub>, <unfinished ...>\n"), "/fixture/book.epub"); err == nil {
		t.Fatal("incomplete trace accepted")
	}
}

func TestFastBuildPhase0ActualReadAudit(t *testing.T) {
	if os.Getenv("ACCORDER_PHASE0_TRACE") != "1" {
		t.Skip("opt-in syscall tracing required")
	}
	tracer, err := exec.LookPath("strace")
	if err != nil {
		t.Fatal(err)
	}
	binary, err := os.Executable()
	if err != nil {
		t.Fatal(err)
	}
	for _, mode := range []string{"inventory", "escaped-read", "rclone", "command-pipeline", "command-pipeline-v1"} {
		t.Run(mode, func(t *testing.T) {
			root, destination := t.TempDir(), t.TempDir()
			config := ""
			bookPath := "book.epub"
			if strings.HasPrefix(mode, "command-pipeline") {
				if mode == "command-pipeline-v1" {
					root = testSetup(t)
					config = accorderConfigDir
				}
				seedPublishCalibreLibrary(t, root)
				bookPath = fastBuildPayload
				if mode == "command-pipeline-v1" {
					if err := fastBuildCommand(root).Run(nil); err != nil {
						t.Fatal(err)
					}
					candidate, err := loadLocalChangeCandidate(root)
					if err != nil {
						t.Fatal(err)
					}
					for i := range candidate.ContentLedger {
						object := &candidate.ContentLedger[i]
						object.Hash, err = hashLocalFile(filepath.Join(root, filepath.FromSlash(object.Path)))
						if err != nil {
							t.Fatal(err)
						}
					}
					if err := os.Remove(localChangeCandidateFile(root)); err != nil {
						t.Fatal(err)
					}
					candidate.Evidence = nil
					candidate.LegacyDigest = ""
					candidate.Version = 1
					candidate.ContentLedgerVersion = 1
					if err := saveLocalChangeCandidate(root, *candidate); err != nil {
						t.Fatal(err)
					}
					fastBuildAddSecondBook(t, root)
				}
			} else {
				writeTestFile(t, root, "metadata.db", "metadata")
				writeTestFile(t, root, "book.epub", strings.Repeat("x", 4096))
			}
			trace := filepath.Join(t.TempDir(), "trace.txt")
			command := exec.Command(tracer, "-f", "-qq", "-yy", "-s", "0", "-o", trace, "-e", "trace=read,pread64,readv,preadv,preadv2,sendfile,copy_file_range,mmap,newfstatat,statx", binary, "-test.run=^TestFastBuildPhase0ReadProbe$", "-test.count=1")
			command.Env = append(os.Environ(), "ACCORDER_PHASE0_PROBE="+mode, "ACCORDER_PHASE0_SOURCE="+root, "ACCORDER_PHASE0_DESTINATION="+destination,
				"XDG_CONFIG_HOME="+t.TempDir(), "XDG_CACHE_HOME="+t.TempDir(), "ACCORDER_PHASE0_CONFIG="+config)
			output, err := command.CombinedOutput()
			if err != nil {
				t.Fatalf("trace probe: %s %v", output, err)
			}
			data, err := os.ReadFile(trace)
			if err != nil {
				t.Fatal(err)
			}
			book, err := phase0ParseTrace(data, filepath.Join(root, filepath.FromSlash(bookPath)))
			if err != nil {
				t.Fatal(err)
			}
			metadata, err := phase0ParseTrace(data, filepath.Join(root, "metadata.db"))
			if err != nil {
				t.Fatal(err)
			}
			if strings.HasPrefix(mode, "command-pipeline") {
				if book.ReadBytes != 0 || book.MappedBytes != 0 || metadata.ReadBytes == 0 || book.MetadataCalls == 0 {
					t.Fatalf("command pipeline book=%+v metadata=%+v", book, metadata)
				}
				if mode == "command-pipeline-v1" {
					for _, format := range []string{"Author/Second (2)/Second - Author.epub", "Author/Second (2)/Second - Author.pdf"} {
						audit, err := phase0ParseTrace(data, filepath.Join(root, filepath.FromSlash(format)))
						if err != nil || audit.ReadBytes != 0 || audit.MappedBytes != 0 {
							t.Fatalf("new format read during imported build: %s %+v %v", format, audit, err)
						}
					}
				}
			} else if mode == "inventory" {
				if book.ReadBytes != 0 || book.MappedBytes != 0 || metadata.ReadBytes != 8 || book.MetadataCalls == 0 {
					t.Fatalf("inventory book=%+v metadata=%+v", book, metadata)
				}
			} else if book.ReadBytes < 4096 && book.MappedBytes < 4096 {
				t.Fatalf("positive control escaped audit: %+v", book)
			}
			if mode == "rclone" {
				copied, err := os.ReadFile(filepath.Join(destination, "book.epub"))
				if err != nil || !bytes.Equal(copied, bytes.Repeat([]byte("x"), 4096)) {
					t.Fatalf("rclone readback: %v", err)
				}
			}
			t.Logf("mode=%s book=%+v metadata=%+v", mode, book, metadata)
		})
	}
}

func TestFastBuildPhase0InventoryScale(t *testing.T) {
	if os.Getenv("ACCORDER_PHASE0_SCALE") != "1" {
		t.Skip("opt-in 37,158-file fixture")
	}
	root := t.TempDir()
	const count = 37158
	writeTestFile(t, root, "metadata.db", "metadata")
	paths := make([]string, count)
	for i := range paths {
		format := "epub"
		if i%2 == 1 {
			format = "pdf"
		}
		paths[i] = filepath.Join(root, fmt.Sprintf("Author %03d", (i/2)%300), fmt.Sprintf("Book %05d", i/2), "book."+format)
		if err := os.MkdirAll(filepath.Dir(paths[i]), 0o700); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(paths[i], []byte("tiny"), 0o600); err != nil {
			t.Fatal(err)
		}
	}
	var fs syscall.Statfs_t
	if err := syscall.Statfs(root, &fs); err != nil {
		t.Fatal(err)
	}
	for _, payloadSize := range []int64{4, (2626 * (1 << 30) / 10) / count} {
		if payloadSize != 4 {
			for _, path := range paths {
				if err := os.Truncate(path, payloadSize); err != nil {
					t.Fatal(err)
				}
			}
		}
		var previous []libraryflow.Object
		var previousEvidence *sourceEvidence
		for pass := 0; pass < 3; pass++ {
			var before, after syscall.Rusage
			if err := syscall.Getrusage(syscall.RUSAGE_SELF, &before); err != nil {
				t.Fatal(err)
			}
			start := time.Now()
			objects, err := listLocalObjects(root)
			if err != nil {
				t.Fatal(err)
			}
			current, evidence, changed, removed, err := buildSourceEvidence(root, objects, nil, previous, previousEvidence, "scale-fixture")
			elapsed := time.Since(start)
			if err != nil {
				t.Fatal(err)
			}
			if err := syscall.Getrusage(syscall.RUSAGE_SELF, &after); err != nil {
				t.Fatal(err)
			}
			if len(current) != count+1 || len(removed) != 0 || (pass > 0 && len(changed) != 0) {
				t.Fatalf("bad scale inventory current=%d changed=%d removed=%d", len(current), len(changed), len(removed))
			}
			row := map[string]any{"files": count, "logical_payload_bytes": payloadSize * count, "pass": pass, "wall_seconds": elapsed.Seconds(), "cpu_seconds": float64(after.Utime.Nano()+after.Stime.Nano()-before.Utime.Nano()-before.Stime.Nano()) / 1e9, "process_peak_rss_kib": after.Maxrss, "filesystem_type": fmt.Sprintf("%x", fs.Type), "metadata_cache": "freshly-created then warm; not cold-cache", "fixture": "sparse inventory only, not catalog throughput"}
			raw, err := json.Marshal(row)
			if err != nil {
				t.Fatal(err)
			}
			t.Log(string(raw))
			if elapsed > 5*time.Second {
				t.Fatalf("inventory exceeded provisional 5s gate: %s", elapsed)
			}
			previous, previousEvidence = current, evidence
		}
	}
}

func TestFastBuildPhase0CatalogControl(t *testing.T) {
	corpus := os.Getenv("ACCORDER_PHASE0_CATALOG")
	if corpus == "" {
		t.Skip("opt-in existing catalog sample required; no payload library scan")
	}
	input, err := os.Open(corpus)
	if err != nil {
		t.Fatal(err)
	}
	defer input.Close()
	root := t.TempDir()
	jsonlPath := filepath.Join(root, "sample.jsonl")
	output, err := os.Create(jsonlPath)
	if err != nil {
		t.Fatal(err)
	}
	defer output.Close()
	hash := sha256.New()
	scanner := bufio.NewScanner(input)
	scanner.Buffer(make([]byte, 64*1024), 8*1024*1024)
	const count = 18579
	var sourceBytes int64
	for i := 0; i < count; i++ {
		if !scanner.Scan() {
			t.Fatalf("sample has fewer than %d records: %v", count, scanner.Err())
		}
		line := append(append([]byte(nil), scanner.Bytes()...), '\n')
		var book calibre.Book
		if err := json.Unmarshal(line, &book); err != nil {
			t.Fatal(err)
		}
		if _, err := output.Write(line); err != nil {
			t.Fatal(err)
		}
		_, _ = hash.Write(line)
		sourceBytes += int64(len(line))
	}
	if err := output.Close(); err != nil {
		t.Fatal(err)
	}
	for pass := 0; pass < 3; pass++ {
		var before, after syscall.Rusage
		if err := syscall.Getrusage(syscall.RUSAGE_SELF, &before); err != nil {
			t.Fatal(err)
		}
		ms := &calibre.MotwSearch{JsonlPath: jsonlPath, IndexPath: filepath.Join(root, fmt.Sprintf("index-%d", pass))}
		start := time.Now()
		index, err := ms.BuildIndex()
		if err != nil {
			t.Fatal(err)
		}
		built := time.Now()
		if err := ms.CompressToFile(index); err != nil {
			t.Fatal(err)
		}
		finished := time.Now()
		if err := syscall.Getrusage(syscall.RUSAGE_SELF, &after); err != nil {
			t.Fatal(err)
		}
		row := map[string]any{"records": count, "sample_bytes": sourceBytes, "sample_sha256": hex.EncodeToString(hash.Sum(nil)), "pass": pass, "index_seconds": built.Sub(start).Seconds(), "compression_seconds": finished.Sub(built).Seconds(), "wall_seconds": finished.Sub(start).Seconds(), "cpu_seconds": float64(after.Utime.Nano()+after.Stime.Nano()-before.Utime.Nano()-before.Stime.Nano()) / 1e9, "process_peak_rss_kib": after.Maxrss, "control": "real catalog prefix; full index compile only, not SQL/render/no-change command"}
		raw, err := json.Marshal(row)
		if err != nil {
			t.Fatal(err)
		}
		t.Log(string(raw))
	}
}
