//go:build !tailscale

package cmd

// Production tests for one-name fedlib grammar (fedlib-one-name): the
// federation id is the ONLY name — it keys the descriptor, the action
// alias, and (positionally) every members/invites command. --fedlib-id,
// --serve-alias, and --tor-alias no longer exist.

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func seedDescriptor(t *testing.T, id string, desc fedlibDescriptor) {
	t.Helper()
	desc.Version = fedlibDescriptorVersion
	if err := saveFedlibDescriptor(id, desc); err != nil {
		t.Fatalf("seed descriptor %q: %v", id, err)
	}
}

// Honest-proof anchor (fails on old code, where --fedlib-id parsed):
// the deleted flags are Kong unknown-flag errors everywhere they lived.
func TestOneName_DeletedFlagsAreUnknown(t *testing.T) {
	_ = testSetup(t)

	for _, tc := range [][]string{
		{"fedlib", "build", "myfed", "--fedlib-id", "myfed"},
		{"fedlib", "share", "live", "myfed", "--fedlib-id", "myfed", "--aggregate-path", "/tmp/x"},
		{"fedlib", "share", "live", "myfed", "--tor-alias", "lib", "--aggregate-path", "/tmp/x"},
		{"fedlib", "members", "invite", "myfed", "--prefix", "p", "--fedlib-id", "myfed"},
		{"fedlib", "members", "reindex", "myfed", "--output-path", "/tmp/x", "--fedlib-id", "myfed"},
		{"fedlib", "config", "set", "myfed", "--serve-alias", "lib"},
	} {
		_, _, err := parseCLIErr(t, tc)
		if err == nil || !strings.Contains(err.Error(), "unknown flag") {
			t.Errorf("%s: want unknown-flag error, got %v", strings.Join(tc[:3], " "), err)
		}
	}
}

// Honest-proof anchor (fails on old code, where the first positional was
// the Label): `fedlib members invite <id> [<label>]`.
func TestOneName_InviteIDThenLabel(t *testing.T) {
	_ = testSetup(t)

	_, ctx := parseCLI(t, []string{
		"fedlib", "members", "invite", "myfed", "Jane Doe", "--prefix", "jane",
	})
	target := ctx.Selected().Target.Interface().(FedlibMembersInviteCmd)
	if target.FedlibID != "myfed" || target.Label != "Jane Doe" {
		t.Fatalf("got id=%q label=%q, want myfed/Jane Doe", target.FedlibID, target.Label)
	}

	// Label stays optional (re-invite path).
	_, ctx = parseCLI(t, []string{"fedlib", "members", "invite", "myfed", "--prefix", "jane"})
	target = ctx.Selected().Target.Interface().(FedlibMembersInviteCmd)
	if target.FedlibID != "myfed" || target.Label != "" {
		t.Fatalf("got id=%q label=%q, want myfed/(empty)", target.FedlibID, target.Label)
	}

	// The id is required.
	if _, _, err := parseCLIErr(t, []string{"fedlib", "members", "invite", "--prefix", "jane"}); err == nil {
		t.Fatal("expected error when required fedlib-id positional is missing")
	}
}

// The positional grammar across the members/invites family.
func TestOneName_PositionalGrammar(t *testing.T) {
	_ = testSetup(t)

	for _, tc := range []struct {
		args []string
		want string
	}{
		{[]string{"fedlib", "members", "offer", "myfed", "--prefix", "p", "--librarian", "L", "--endpoint", "https://x.example"}, "myfed"},
		{[]string{"fedlib", "members", "reindex", "myfed", "--output-path", "/tmp/x"}, "myfed"},
		{[]string{"fedlib", "members", "add", "myfed", "uuid-1", "-l", "Alice"}, "myfed"},
		{[]string{"fedlib", "members", "remove", "myfed", "uuid-1"}, "myfed"},
		{[]string{"fedlib", "members", "enable", "myfed", "uuid-1"}, "myfed"},
		{[]string{"fedlib", "members", "disable", "myfed", "uuid-1"}, "myfed"},
		{[]string{"fedlib", "members", "list", "myfed"}, "myfed"},
		{[]string{"fedlib", "members", "list"}, ""}, // optional: singleton/--fedlib-path fallback
		{[]string{"fedlib", "members", "status"}, ""},
		{[]string{"fedlib", "invites", "list", "myfed"}, "myfed"},
		{[]string{"fedlib", "invites", "revoke", "myfed", "jane"}, "myfed"},
	} {
		_, ctx := parseCLI(t, tc.args)
		if got := fieldStringValue(ctx.Selected().Target, "FedlibID"); got != tc.want {
			t.Errorf("%s: FedlibID = %q, want %q", strings.Join(tc.args, " "), got, tc.want)
		}
	}
}

// share live requires the positional to name a descriptor — since ca-125
// at parse time (descriptor preflight in AfterApply), before any alias
// write or migration.
func TestOneName_ShareLiveRequiresDescriptor(t *testing.T) {
	tmp := testSetup(t)

	_, _, err := parseCLIErr(t, []string{
		"fedlib", "share", "live", "nodesc",
		"--aggregate-path", filepath.Join(tmp, "agg"),
	})
	if err == nil || !strings.Contains(err.Error(), "names no federation descriptor") {
		t.Fatalf("want descriptor-required error from parse, got %v", err)
	}
}

// build: positional naming a descriptor recalls it (fill-if-empty);
// a positional naming none is the explicit-flags path and then
// --output-path is required.
func TestOneName_BuildDescriptorRecallAndExplicitPath(t *testing.T) {
	_ = testSetup(t)
	seedDescriptor(t, "myfed", fedlibDescriptor{Bucket: "b", FedlibPath: "/tmp/myfed-out", UploadPrefix: "aggregate"})

	// Recall path: descriptor fills OutputPath/Bucket.
	_, ctx := parseCLI(t, []string{"fedlib", "build", "myfed"})
	target := ctx.Selected().Target.Interface().(FedlibBuildCmd)
	if err := target.recallFromDescriptor(); err != nil {
		t.Fatalf("recall: %v", err)
	}
	if target.OutputPath != "/tmp/myfed-out" || target.Bucket != "b" {
		t.Fatalf("recall filled OutputPath=%q Bucket=%q", target.OutputPath, target.Bucket)
	}

	// Explicit-flags path (funnel child, e2e): no descriptor, output-path given.
	_, ctx = parseCLI(t, []string{"fedlib", "build", "plain", "--output-path", "/tmp/plain-out"})
	target = ctx.Selected().Target.Interface().(FedlibBuildCmd)
	if err := target.recallFromDescriptor(); err != nil {
		t.Fatalf("explicit-flags path: %v", err)
	}

	// No descriptor AND no output-path: actionable error. (Fresh alias —
	// "plain" above alias-persisted its --output-path, which is exactly the
	// recall-from-alias behavior a repeat user wants.)
	_, ctx = parseCLI(t, []string{"fedlib", "build", "plain2"})
	target = ctx.Selected().Target.Interface().(FedlibBuildCmd)
	err := target.recallFromDescriptor()
	if err == nil || !strings.Contains(err.Error(), "--output-path is required") {
		t.Fatalf("want output-path-required error, got %v", err)
	}
}

// Offers written by invite/offer land where the serve and invites list/revoke
// read them: clearnet/<fedlib-id>/invites (the serve_alias indirection is gone).
func TestOneName_OffersDirKeyedByID(t *testing.T) {
	_ = testSetup(t)
	seedDescriptor(t, "myfed", fedlibDescriptor{Bucket: "b"})
	if err := os.MkdirAll(inviteOffersDir("myfed"), 0o755); err != nil {
		t.Fatal(err)
	}

	if err := (&FedlibInvitesListCmd{FedlibID: "myfed"}).Run(); err != nil {
		t.Fatalf("invites list against id-keyed dir: %v", err)
	}
	if err := (&FedlibInvitesRevokeCmd{FedlibID: "myfed", Prefix: "jane"}).Run(); err != nil {
		t.Fatalf("invites revoke against id-keyed dir: %v", err)
	}

	// Descriptor-less id errors with the remedial command.
	err := (&FedlibInvitesListCmd{FedlibID: "nodesc"}).Run()
	if err == nil || !strings.Contains(err.Error(), "names no federation descriptor") {
		t.Fatalf("want descriptor-required error, got %v", err)
	}
}

// --offer against a federation with no descriptor fails loudly BEFORE the
// write-through can mint a descriptor for the typo — otherwise the offer is
// sealed into clearnet/<typo>/invites and the printed claim URL 404s on the
// real serve (the hazard the old serve_alias guard used to catch).
func TestOneName_InviteOfferRequiresDescriptor(t *testing.T) {
	_ = testSetup(t)

	cmd := &FedlibMembersInviteCmd{
		FedlibID: "motww", Label: "X", Prefix: "alice",
		Offer: true, Endpoint: "https://lib.example.org",
		Bucket: "motw", S3Provider: "Wasabi", S3Endpoint: "https://s3.example",
		S3AccessKey: "AK", S3SecretKey: "SK",
	}
	err := cmd.Run(nil)
	if err == nil || !strings.Contains(err.Error(), "names no federation descriptor") {
		t.Fatalf("want descriptor-required error, got %v", err)
	}
	if d := loadFedlibDescriptor("motww"); d.Version != 0 {
		t.Fatalf("typo'd --offer minted a descriptor: %+v", d)
	}
}
