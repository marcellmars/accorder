package cmd

import (
	"accorder/pkg/calibre"
	"accorder/pkg/rclonexfer"
	"accorder/pkg/torshare"
	"bytes"
	"encoding/hex"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestSpikeGenerationChangeObservedFetchRejectsStaleCache(t *testing.T) {
	const memberUUID = "00000000-0000-4000-8000-000000000123"
	remoteRoot := t.TempDir()
	prefix := "member"
	previous := generationChangeMemberToken(1)
	observed := generationChangeMemberToken(2)
	writeGenerationChangeMember(t, remoteRoot, prefix, memberUUID, 2, "new")
	if err := os.Remove(filepath.Join(remoteRoot, prefix, "static", "library_index.zst")); err != nil {
		t.Fatal(err)
	}

	libDir := t.TempDir()
	oldCache := []byte("old cached index")
	if err := os.WriteFile(filepath.Join(libDir, "library_index.zst"), oldCache, 0o644); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(libDir, ".member_generation"), previous, 0o644); err != nil {
		t.Fatal(err)
	}
	transition := observedMemberTransition{
		LibraryUUID: memberUUID, PreviousGeneration: hex.EncodeToString(previous),
		ObservedGeneration: hex.EncodeToString(observed),
	}

	rclonexfer.Initialize()
	defer rclonexfer.Finalize()
	if err := prepRcloneContainerObserved(remoteRoot, libDir, prefix, memberUUID, transition, true); err == nil {
		t.Fatal("observed changed-member fetch succeeded after target index was removed")
	}
	got, err := os.ReadFile(filepath.Join(libDir, "library_index.zst"))
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(got, oldCache) {
		t.Fatal("failed observed fetch replaced the last-good cached index")
	}
	gotGeneration, err := os.ReadFile(filepath.Join(libDir, ".member_generation"))
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(gotGeneration, previous) {
		t.Fatal("failed observed fetch consumed the changed generation")
	}
}

func TestSpikeGenerationChangeObservedFetchReportsStableLaterToken(t *testing.T) {
	const memberUUID = "00000000-0000-4000-8000-000000000124"
	remoteRoot := t.TempDir()
	prefix := "member"
	previous := generationChangeMemberToken(1)
	observed := generationChangeMemberToken(2)
	writeGenerationChangeMember(t, remoteRoot, prefix, memberUUID, 2, "new")
	transition := observedMemberTransition{
		LibraryUUID: memberUUID, PreviousGeneration: hex.EncodeToString(previous),
		ObservedGeneration: hex.EncodeToString(observed),
	}

	rclonexfer.Initialize()
	defer rclonexfer.Finalize()
	var later []byte
	memberFetchStageHook = func(stage string, attempt int) error {
		if stage == "after-index-fetch" && attempt == 1 {
			later = writeGenerationChangeMember(t, remoteRoot, prefix, memberUUID, 3, "later")
		}
		return nil
	}
	t.Cleanup(func() { memberFetchStageHook = nil })
	libDir := t.TempDir()
	if err := prepRcloneContainerObserved(remoteRoot, libDir, prefix, memberUUID, transition, true); err != nil {
		t.Fatal(err)
	}
	gotGeneration, err := os.ReadFile(filepath.Join(libDir, ".member_generation"))
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(gotGeneration, later) {
		t.Fatalf("incorporated generation=%x, want stable later generation=%x", gotGeneration, later)
	}
	books, err := calibre.AllBooksFromIndex(filepath.Join(libDir, "library_index"))
	if err != nil {
		t.Fatal(err)
	}
	if len(books) != 1 || books[0].Title != "later" {
		t.Fatalf("activated books=%+v", books)
	}
}

func TestGenerationChangeObservedFetchRejectsCatalogChecksumMismatch(t *testing.T) {
	const memberUUID = "00000000-0000-4000-8000-000000000126"
	remoteRoot := t.TempDir()
	prefix := "member"
	previous := generationChangeMemberToken(1)
	observed := writeGenerationChangeMember(t, remoteRoot, prefix, memberUUID, 2, "new")
	pointerPath := filepath.Join(remoteRoot, prefix, filepath.FromSlash(memberPointerPath))
	pointer, err := calibre.ReadPointerFile(pointerPath)
	if err != nil {
		t.Fatal(err)
	}
	pointer.CatalogChecksum = strings.Repeat("0", 64)
	if err := calibre.WritePointerDocument(pointerPath, pointer); err != nil {
		t.Fatal(err)
	}
	transition := observedMemberTransition{
		LibraryUUID: memberUUID, PreviousGeneration: hex.EncodeToString(previous),
		ObservedGeneration: hex.EncodeToString(observed),
	}
	libDir := t.TempDir()
	oldCache := []byte("old cached index")
	if err := os.WriteFile(filepath.Join(libDir, "library_index.zst"), oldCache, 0o644); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(libDir, ".member_generation"), previous, 0o644); err != nil {
		t.Fatal(err)
	}

	rclonexfer.Initialize()
	defer rclonexfer.Finalize()
	err = prepRcloneContainerObserved(remoteRoot, libDir, prefix, memberUUID, transition, true)
	if err == nil || !strings.Contains(err.Error(), "catalog checksum") {
		t.Fatalf("checksum-mismatched fetch error=%v", err)
	}
	got, readErr := os.ReadFile(filepath.Join(libDir, "library_index.zst"))
	if readErr != nil || !bytes.Equal(got, oldCache) {
		t.Fatalf("checksum failure replaced cache=%q err=%v", got, readErr)
	}
}

func TestGenerationChangeObservedFetchRejectsPointerLineageMismatch(t *testing.T) {
	const memberUUID = "00000000-0000-4000-8000-000000000127"
	remoteRoot := t.TempDir()
	prefix := "member"
	previous := generationChangeMemberToken(1)
	observed := writeGenerationChangeMember(t, remoteRoot, prefix, memberUUID, 2, "new")
	pointerPath := filepath.Join(remoteRoot, prefix, filepath.FromSlash(memberPointerPath))
	pointer, err := calibre.ReadPointerFile(pointerPath)
	if err != nil {
		t.Fatal(err)
	}
	pointer.Index.Regions++
	if err := calibre.WritePointerDocument(pointerPath, pointer); err != nil {
		t.Fatal(err)
	}
	transition := observedMemberTransition{
		LibraryUUID: memberUUID, PreviousGeneration: hex.EncodeToString(previous),
		ObservedGeneration: hex.EncodeToString(observed),
	}
	libDir := t.TempDir()
	oldCache := []byte("old cached index")
	if err := os.WriteFile(filepath.Join(libDir, "library_index.zst"), oldCache, 0o644); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(libDir, ".member_generation"), previous, 0o644); err != nil {
		t.Fatal(err)
	}

	rclonexfer.Initialize()
	defer rclonexfer.Finalize()
	err = prepRcloneContainerObserved(remoteRoot, libDir, prefix, memberUUID, transition, true)
	if err == nil || !strings.Contains(err.Error(), "published index metadata does not match") {
		t.Fatalf("lineage-mismatched fetch error=%v", err)
	}
	got, readErr := os.ReadFile(filepath.Join(libDir, "library_index.zst"))
	if readErr != nil || !bytes.Equal(got, oldCache) {
		t.Fatalf("lineage failure replaced cache=%q err=%v", got, readErr)
	}
}

func TestMemberChangeRequestStrictRoundTrip(t *testing.T) {
	transition := observedMemberTransition{
		LibraryUUID:        "00000000-0000-4000-8000-000000000125",
		PreviousGeneration: hex.EncodeToString(generationChangeMemberToken(1)),
		ObservedGeneration: hex.EncodeToString(generationChangeMemberToken(2)),
	}
	data, err := encodeMemberChangeRequest([]observedMemberTransition{transition})
	if err != nil {
		t.Fatal(err)
	}
	decoded, err := decodeMemberChangeRequest(data)
	if err != nil {
		t.Fatal(err)
	}
	if len(decoded) != 1 || decoded[0] != transition {
		t.Fatalf("decoded=%+v", decoded)
	}
	duplicate := bytes.Replace(data, []byte(`"version":1`), []byte(`"version":1,"version":1`), 1)
	if _, err := decodeMemberChangeRequest(duplicate); err == nil {
		t.Fatal("duplicate request field unexpectedly accepted")
	}
	path, err := writeMemberChangeRequest(t.TempDir(), []observedMemberTransition{transition})
	if err != nil {
		t.Fatal(err)
	}
	info, err := os.Stat(path)
	if err != nil {
		t.Fatal(err)
	}
	if info.Mode().Perm() != 0o600 {
		t.Fatalf("request mode=%o, want 0600", info.Mode().Perm())
	}
}

func TestGenerationChangeReadFileBoundedRejectsBeforeRead(t *testing.T) {
	path := filepath.Join(t.TempDir(), "oversized.json")
	if err := os.WriteFile(path, bytes.Repeat([]byte("x"), 9), 0o600); err != nil {
		t.Fatal(err)
	}
	if _, err := readFileBounded(path, 8); !errors.Is(err, errBoundedFileTooLarge) {
		t.Fatalf("bounded read error=%v, want %v", err, errBoundedFileTooLarge)
	}
}

func writeGenerationChangeMember(t *testing.T, root, prefix, memberUUID string, generation uint64, title string) []byte {
	t.Helper()
	static := filepath.Join(root, prefix, "static")
	if err := os.MkdirAll(static, 0o755); err != nil {
		t.Fatal(err)
	}
	book := &calibre.Book{
		Abstract: "", Authors: []string{"Author"}, LibraryUrl: "library",
		CoverUrl: "Author/Book (1)/cover.jpg", Formats: []*calibre.File{},
		Id: "00000000-0000-4000-8000-000000000999", Identifiers: []*calibre.Identifier{},
		Languages: []string{}, LastModified: "2026-09-03T00:00:00Z",
		Librarian: "member", LibraryUUID: memberUUID, Pubdate: "", Publisher: "",
		Series: "", Tags: []string{}, Title: title, TitleSort: title,
	}
	jsonl := filepath.Join(root, prefix, "books.jsonl")
	f, err := os.Create(jsonl)
	if err != nil {
		t.Fatal(err)
	}
	if err := json.NewEncoder(f).Encode(book); err != nil {
		_ = f.Close()
		t.Fatal(err)
	}
	if err := f.Close(); err != nil {
		t.Fatal(err)
	}
	base := generationChangeBase()
	indexPath := filepath.Join(static, "library_index")
	search := &calibre.MotwSearch{JsonlPath: jsonl, IndexPath: indexPath, BaseGeneration: &base, StartGeneration: generation}
	index, err := search.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := search.CompressToFile(index); err != nil {
		t.Fatal(err)
	}
	manifest, err := calibre.ReadExistingManifest(indexPath)
	if err != nil {
		t.Fatal(err)
	}
	if err := calibre.WritePointerFile(indexPath, manifest, calibre.PointerFileLibrary{UUID: memberUUID, Librarian: "member"}, true); err != nil {
		t.Fatal(err)
	}
	pointer, err := calibre.ReadPointerFile(indexPath + ".manifest.json")
	if err != nil {
		t.Fatal(err)
	}
	pointer, err = calibre.BindPointerCommit(pointer, "phase-zero-source", generation)
	if err != nil {
		t.Fatal(err)
	}
	checksum, err := calibre.CatalogChecksum([]*calibre.Book{book})
	if err != nil {
		t.Fatal(err)
	}
	pointer.CatalogChecksum = hex.EncodeToString(checksum[:])
	if err := calibre.WritePointerDocument(indexPath+".manifest.json", pointer); err != nil {
		t.Fatal(err)
	}
	token := torshare.EncodeGeneration(base, generation)
	if err := os.WriteFile(filepath.Join(root, prefix, "_GENERATION"), token, 0o644); err != nil {
		t.Fatal(err)
	}
	return token
}

func generationChangeBase() [16]byte { return [16]byte{9, 8, 7, 6} }

func generationChangeMemberToken(generation uint64) []byte {
	return torshare.EncodeGeneration(generationChangeBase(), generation)
}
