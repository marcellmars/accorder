package cmd

import (
	"fmt"
	"os"
	"path/filepath"

	"github.com/alecthomas/kong"
)

type LibShareRevokeClearnetCmd struct {
	CommonCommandFields
	Friend string `name:"friend" help:"Friend name to revoke." validate:"required,personname"`
}

func (c *LibShareRevokeClearnetCmd) Run(ctx *kong.Context) error {
	if c.HandleShowConfig(c) {
		return nil
	}

	stateDir := filepath.Join(accorderConfigDir, "clearnet-lib", c.ActionAlias)
	reg, err := newGrantRegistry(stateDir)
	if err != nil {
		return fmt.Errorf("lib share revoke-grant: %w", err)
	}
	if err := reg.revoke(c.Friend); err != nil {
		return fmt.Errorf("lib share revoke-grant: %w", err)
	}
	fmt.Fprintf(os.Stderr, "lib share revoke-grant: revoked grants for %s\n", c.Friend)
	return nil
}
