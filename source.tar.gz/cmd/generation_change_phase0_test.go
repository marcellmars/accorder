package cmd

import (
	"accorder/pkg/libraryflow"
	"bytes"
	"crypto/sha256"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

type phase0InventorySnapshot struct {
	fingerprint string
	objects     map[string]libraryflow.Object
	digests     map[string][sha256.Size]byte
}

func TestSpikeGenerationChangeCalibreInventory(t *testing.T) {
	calibredb, err := exec.LookPath("calibredb")
	if err != nil {
		t.Skip("calibredb is not installed")
	}

	root := t.TempDir()
	library := filepath.Join(root, "library")
	config := filepath.Join(root, "calibre-config")
	if err := os.MkdirAll(library, 0o755); err != nil {
		t.Fatal(err)
	}

	run := func(args ...string) string {
		t.Helper()
		cmd := exec.Command(calibredb, append([]string{"--with-library", library}, args...)...)
		cmd.Env = append(os.Environ(), "CALIBRE_CONFIG_DIRECTORY="+config)
		out, err := cmd.CombinedOutput()
		if err != nil {
			t.Fatalf("calibredb %s: %v\n%s", strings.Join(args, " "), err, out)
		}
		return strings.TrimSpace(string(out))
	}

	if got := run("add", "--empty", "--title", "Inventory Probe", "--authors", "Phase Zero"); !strings.Contains(got, "Added book ids: 1") {
		t.Fatalf("unexpected add output: %q", got)
	}

	formatA := bytes.Repeat([]byte("A"), 4096)
	formatB := bytes.Repeat([]byte("B"), len(formatA))
	formatC := bytes.Repeat([]byte("C"), len(formatA))
	formatSource := filepath.Join(root, "probe.epub")
	if err := os.WriteFile(formatSource, formatA, 0o644); err != nil {
		t.Fatal(err)
	}
	run("add_format", "1", formatSource)

	coverA, err := os.ReadFile(filepath.Join("..", "pkg", "calibre", "embResources", "static", "favicons", "favicon-32x32.png"))
	if err != nil {
		t.Fatal(err)
	}
	coverB, err := os.ReadFile(filepath.Join("..", "pkg", "calibre", "embResources", "static", "favicons", "favicon-16x16.png"))
	if err != nil {
		t.Fatal(err)
	}
	coverSource := filepath.Join(root, "cover.png")
	if err := os.WriteFile(coverSource, coverA, 0o644); err != nil {
		t.Fatal(err)
	}
	run("set_metadata", "--field", "cover:"+coverSource, "1")

	baseline := capturePhase0Inventory(t, library)
	formatPath := phase0SinglePathWithSuffix(t, baseline.objects, ".epub")
	coverPath := phase0SinglePathWithSuffix(t, baseline.objects, "/cover.jpg")
	if !strings.Contains(formatPath, " (1)/") || !strings.Contains(coverPath, " (1)/") {
		t.Fatalf("payload paths do not map to calibre id 1: format=%q cover=%q", formatPath, coverPath)
	}

	run("set_metadata", "--field", "title:Inventory Probe Renamed", "1")
	metadataEdit := capturePhase0Inventory(t, library)
	if metadataEdit.fingerprint == baseline.fingerprint {
		t.Fatal("metadata edit did not change SourceFingerprint")
	}
	if _, ok := metadataEdit.objects[formatPath]; ok {
		t.Fatalf("title edit left format at old path %q; move observation was expected", formatPath)
	}
	formatPath = phase0SinglePathWithSuffix(t, metadataEdit.objects, ".epub")
	coverPath = phase0SinglePathWithSuffix(t, metadataEdit.objects, "/cover.jpg")

	if err := os.WriteFile(coverSource, coverB, 0o644); err != nil {
		t.Fatal(err)
	}
	beforeCover := metadataEdit
	run("set_metadata", "--field", "cover:"+coverSource, "1")
	coverEdit := capturePhase0Inventory(t, library)
	phase0AssertObservedPayloadChange(t, "cover", coverPath, beforeCover, coverEdit)

	if err := os.WriteFile(formatSource, formatB, 0o644); err != nil {
		t.Fatal(err)
	}
	beforeFormat := coverEdit
	run("add_format", "1", formatSource)
	formatEdit := capturePhase0Inventory(t, library)
	phase0AssertObservedPayloadChange(t, "same-size format", formatPath, beforeFormat, formatEdit)

	// Deliberately bypass Calibre and preserve path, size, and mtime. This is the
	// adversarial boundary the ordinary source inventory does not claim to see.
	fullFormatPath := filepath.Join(library, filepath.FromSlash(formatPath))
	info, err := os.Stat(fullFormatPath)
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(fullFormatPath, formatC, info.Mode()); err != nil {
		t.Fatal(err)
	}
	if err := os.Chtimes(fullFormatPath, info.ModTime(), info.ModTime()); err != nil {
		t.Fatal(err)
	}
	adversarial := capturePhase0Inventory(t, library)
	beforeObject, afterObject := formatEdit.objects[formatPath], adversarial.objects[formatPath]
	if beforeObject.Identity() != afterObject.Identity() {
		t.Fatalf("same-size/same-mtime replacement unexpectedly changed inventory identity: %q -> %q", beforeObject.Identity(), afterObject.Identity())
	}
	if formatEdit.digests[formatPath] == adversarial.digests[formatPath] {
		t.Fatal("same-size/same-mtime replacement did not change payload bytes")
	}

	run("remove", "--permanent", "1")
	deleted := capturePhase0Inventory(t, library)
	if _, ok := deleted.objects[formatPath]; ok {
		t.Fatalf("deleted format remains in inventory: %s", formatPath)
	}
	if _, ok := deleted.objects[coverPath]; ok {
		t.Fatalf("deleted cover remains in inventory: %s", coverPath)
	}

	t.Logf("normal Calibre mutations changed metadata and/or path,size,mtime identity; direct same-size/same-mtime mutation did not (content ledger or complete overwrite required)")
}

func capturePhase0Inventory(t *testing.T, root string) phase0InventorySnapshot {
	t.Helper()
	fingerprint, objects, err := libraryflow.SourceFingerprint(root, nil)
	if err != nil {
		t.Fatalf("SourceFingerprint: %v", err)
	}
	snapshot := phase0InventorySnapshot{
		fingerprint: fingerprint,
		objects:     make(map[string]libraryflow.Object, len(objects)),
		digests:     make(map[string][sha256.Size]byte, len(objects)),
	}
	for _, object := range objects {
		snapshot.objects[object.Path] = object
		data, err := os.ReadFile(filepath.Join(root, filepath.FromSlash(object.Path)))
		if err != nil {
			t.Fatalf("read %s: %v", object.Path, err)
		}
		snapshot.digests[object.Path] = sha256.Sum256(data)
	}
	return snapshot
}

func phase0SinglePathWithSuffix(t *testing.T, objects map[string]libraryflow.Object, suffix string) string {
	t.Helper()
	var found string
	for path := range objects {
		if strings.HasSuffix(strings.ToLower(path), strings.ToLower(suffix)) {
			if found != "" {
				t.Fatalf("multiple inventory paths have suffix %q: %q, %q", suffix, found, path)
			}
			found = path
		}
	}
	if found == "" {
		t.Fatalf("no inventory path has suffix %q; objects=%v", suffix, objects)
	}
	return found
}

func phase0AssertObservedPayloadChange(t *testing.T, kind, path string, before, after phase0InventorySnapshot) {
	t.Helper()
	beforeObject, beforeOK := before.objects[path]
	afterObject, afterOK := after.objects[path]
	if !beforeOK || !afterOK {
		t.Fatalf("%s path missing across mutation: %q (before=%v after=%v)", kind, path, beforeOK, afterOK)
	}
	if before.digests[path] == after.digests[path] {
		t.Fatalf("%s did not change bytes at %q", kind, path)
	}
	if beforeObject.Identity() == afterObject.Identity() && before.fingerprint == after.fingerprint {
		t.Fatalf("%s changed bytes but neither inventory identity nor SourceFingerprint changed at %q", kind, path)
	}
}

func BenchmarkGenerationChangeInventory(b *testing.B) {
	root := b.TempDir()
	metadata := filepath.Join(root, "metadata.db")
	if err := os.WriteFile(metadata, []byte("phase-zero-metadata"), 0o644); err != nil {
		b.Fatal(err)
	}
	for i := 0; i < 1000; i++ {
		path := filepath.Join(root, "Author", fmt.Sprintf("Book (%d)", i), fmt.Sprintf("book-%d.epub", i))
		if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
			b.Fatal(err)
		}
		if err := os.WriteFile(path, bytes.Repeat([]byte{byte(i)}, 1024), 0o644); err != nil {
			b.Fatal(err)
		}
	}
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		if _, _, err := libraryflow.SourceFingerprint(root, nil); err != nil {
			b.Fatal(err)
		}
	}
}
