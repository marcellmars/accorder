package cmd

import (
	"accorder/pkg/calibre"
	"accorder/pkg/torshare"
	"context"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"

	"github.com/goccy/go-json"
)

func TestFetchPeerMemberIndex(t *testing.T) {

	// Build a minimal index that the peer will serve.
	libDir := t.TempDir()
	buildMinimalIndex(t, libDir)

	// Serve the static directory.
	srv := httptest.NewServer(http.FileServer(http.Dir(libDir)))
	defer srv.Close()

	destDir := t.TempDir()
	if err := fetchPeerMemberIndex(srv.URL, "", destDir); err != nil {
		t.Fatalf("fetchPeerMemberIndex: %v", err)
	}

	// Verify the file was written.
	zstPath := filepath.Join(destDir, "library_index.zst")
	info, err := os.Stat(zstPath)
	if err != nil {
		t.Fatalf("stat library_index.zst: %v", err)
	}
	if info.Size() == 0 {
		t.Fatal("library_index.zst is empty")
	}

	// Verify it parses.
	indexPath := filepath.Join(destDir, "library_index")
	books, err := calibre.AllBooksFromIndex(indexPath)
	if err != nil {
		t.Fatalf("AllBooksFromIndex: %v", err)
	}
	if len(books) == 0 {
		t.Fatal("AllBooksFromIndex returned 0 books")
	}
	t.Logf("fetched and parsed %d books from peer", len(books))
}

func TestFetchPeerMemberIndex_BearerAuth(t *testing.T) {
	libDir := t.TempDir()
	buildMinimalIndex(t, libDir)

	const validToken = "secret-token"
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		auth := r.Header.Get("Authorization")
		if auth != "Bearer "+validToken {
			w.WriteHeader(http.StatusUnauthorized)
			return
		}
		http.FileServer(http.Dir(libDir)).ServeHTTP(w, r)
	}))
	defer srv.Close()

	destDir := t.TempDir()
	if err := fetchPeerMemberIndex(srv.URL, validToken, destDir); err != nil {
		t.Fatalf("fetchPeerMemberIndex with valid token: %v", err)
	}

	// With bad token.
	destDir2 := t.TempDir()
	if err := fetchPeerMemberIndex(srv.URL, "wrong", destDir2); err == nil {
		t.Fatal("expected error with bad token")
	}
}

// buildMinimalIndexWithUUID creates a minimal MWSC container with a specific LibraryUUID.
func buildMinimalIndexWithUUID(t *testing.T, dir, libraryUUID string) int {
	t.Helper()
	staticDir := filepath.Join(dir, "static")
	if err := os.MkdirAll(staticDir, 0o755); err != nil {
		t.Fatalf("mkdir static: %v", err)
	}

	books := spikeSeedBooks(10)
	for _, b := range books {
		b.LibraryUUID = libraryUUID

		// Make book IDs unique per library to avoid collisions.
		b.Id = libraryUUID[:8] + "-" + b.Id[9:]
	}
	jsonlPath := spikeWriteJSONL(t, books, dir, "books.jsonl")

	indexPath := filepath.Join(dir, "idx")
	ms := &calibre.MotwSearch{JsonlPath: jsonlPath, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex: %v", err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatalf("CompressToFile: %v", err)
	}

	src := indexPath + ".zst"
	dst := filepath.Join(staticDir, "library_index.zst")
	data, err := os.ReadFile(src)
	if err != nil {
		t.Fatalf("read zst: %v", err)
	}
	if err := os.WriteFile(dst, data, 0o644); err != nil {
		t.Fatalf("write zst: %v", err)
	}

	mf, err := calibre.ReadExistingManifest(indexPath)
	if err != nil {
		t.Fatalf("ReadExistingManifest: %v", err)
	}
	genBytes := torshare.EncodeGeneration(mf.BaseGeneration, mf.Generation)
	if err := os.WriteFile(filepath.Join(dir, "_GENERATION"), genBytes, 0o644); err != nil {
		t.Fatalf("write _GENERATION: %v", err)
	}

	return len(books)
}

func TestPeerBuild_MonolithicPath(t *testing.T) {

	// Set up a peer member endpoint serving an index.
	peerDir := t.TempDir()
	bookCount := buildMinimalIndexWithUUID(t, peerDir, "peer-lib-uuid-0001")

	srv := httptest.NewServer(http.FileServer(http.Dir(peerDir)))
	defer srv.Close()

	// Set up a local member with a separate index.
	localDir := t.TempDir()
	localBookCount := buildMinimalIndexWithUUID(t, localDir, "local-lib-uuid-002")

	// Create output directory and registry.
	outputDir := t.TempDir()
	registry := map[string]calibre.LibraryMeta{
		"local-uuid": {
			Librarian: "Local Lib",
			Prefix:    "locallib",
			Kind:      "local",
			State:     "ready",
			LocalPath: localDir,
		},
		"peer-uuid": {
			Librarian:  "Peer Lib",
			Prefix:     "peerlib",
			Kind:       "peer",
			State:      "ready",
			Endpoint:   srv.URL,
			GrantToken: "",
		},
	}

	// Write registry.
	regPath := filepath.Join(outputDir, "members.json")
	regData, _ := json.Marshal(registry)
	os.WriteFile(regPath, regData, 0o600)

	// Build the aggregate using the monolithic path (no splice, no rclone).
	skipUpload := true
	buildCmd := &FedlibBuildCmd{
		OutputPath: outputDir,
		SkipUpload: &skipUpload,
	}

	if err := buildCmd.Run(); err != nil {
		t.Fatalf("FedlibBuildCmd.Run: %v", err)
	}

	// Read the aggregate index and verify both members' books are present.
	aggIndexPath := filepath.Join(outputDir, "library_index")
	aggBooks, err := calibre.AllBooksFromIndex(aggIndexPath)
	if err != nil {
		t.Fatalf("AllBooksFromIndex (aggregate): %v", err)
	}

	expectedTotal := bookCount + localBookCount
	if len(aggBooks) != expectedTotal {
		t.Fatalf("aggregate has %d books, want %d (local=%d + peer=%d)", len(aggBooks), expectedTotal, localBookCount, bookCount)
	}

	// Verify peer books have correct BaseURL.
	for _, b := range aggBooks {
		if b.Librarian == "spikelib" && b.BaseURL != "/files/peerlib" && b.BaseURL != "/files/locallib" {
			t.Errorf("book %q has unexpected BaseURL=%q", b.Title, b.BaseURL)
		}
	}

	// Verify search works across both members.
	ms := &calibre.MotwSearch{IndexPath: aggIndexPath}
	opened, err := ms.Open()
	if err != nil {
		t.Fatalf("Open: %v", err)
	}
	defer opened.Close()
	results, _, err := opened.Search(context.Background(),
		calibre.SearchQuery{Field: calibre.FieldTitle, Text: "the"},
		calibre.SearchOptions{})
	if err != nil {
		t.Fatalf("Search: %v", err)
	}
	if len(results) == 0 {
		t.Error("search returned 0 results — expected books from both members")
	}
	t.Logf("aggregate search 'the': %d results from %d total books", len(results), len(aggBooks))
}
