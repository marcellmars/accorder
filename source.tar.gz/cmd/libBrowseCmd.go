package cmd

import (
	"accorder/pkg/browselocal"
	"accorder/pkg/calibre"
	"accorder/pkg/rclonexfer"
	"accorder/pkg/torinvite"
	"errors"
	"fmt"
	"log"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strings"

	"github.com/alecthomas/kong"
)

type LibBrowseCmd struct {
	CommonCommandFields
	From         string `name:"from" help:"Browse a named source from the registry (see 'lib index list')." json:"-"`
	Invite       string `name:"invite" short:"I" help:"Invite blob (accorder-invite:...)." validate:"omitempty" json:"-" secret:"redact"`
	HTTPEndpoint string `name:"endpoint" aliases:"http-endpoint" help:"Browse an aggregate served over plain HTTP(S) (e.g. http://127.0.0.1:8724/) — no Tor." validate:"omitempty" json:"-"`
	CalibrePath  string `name:"calibrepath" short:"c" json:"calibrepath" help:"Path to local Calibre library (for import). Optional until import is used." validate:"omitempty,dir" sharedgroup:"lib"`
	Librarian    string `name:"librarian" short:"l" json:"librarian" help:"Your librarian name for the rendered catalog. Given here, browse skips the SETTINGS name prompt; shared with the alias's other lib actions." validate:"omitempty,personname" sharedgroup:"lib"`
	Offline      *bool  `name:"offline" help:"Skip re-sync, open cached library." json:"-"`
	DownloadDir  string `name:"download-dir" json:"download-dir" help:"Directory for batch downloads and built library." validate:"omitempty,dirpath"`
	NoCoverSync  *bool  `name:"no-cover-sync" help:"Skip syncing covers beyond front page." json:"-"`
	FilesRoot    string `name:"files-root" json:"-" help:"Local Calibre library dir holding the book files. QUEUE downloads then copy each book's folder from files-root + book path on disk (fully local, no network) instead of fetching from the remote." validate:"omitempty,dir"`
}

func cachedIndexUsable(staticDir string) bool {
	zst := filepath.Join(staticDir, "library_index.zst")
	if _, e := os.Stat(zst); e != nil {
		return false
	}
	base := filepath.Join(staticDir, "library_index")
	if _, e := calibre.ReadExistingManifest(base); e != nil {
		if f, oe := os.Open(zst); oe == nil {
			_ = f.Close()
			log.Printf("browse: cached index unreadable (%v) — re-downloading", e)
			return false
		}
		log.Printf("browse: cached index temporarily inaccessible (%v) — keeping cached copy", e)
		return true
	}
	return true
}

var compileGateConstants = struct {
	FloorMB     float64
	SlopeFactor float64
	Safety      float64
	Headroom    float64
	SizeCap     uint32
}{
	FloorMB:     1500,
	SlopeFactor: 1.5,
	Safety:      1.3,
	Headroom:    0.8,
	SizeCap:     80_000,
}

func shouldCompileFromJSONL(pf calibre.PointerFile, clearnet bool) bool {
	if clearnet {
		return false
	}
	if pf.Index.JsonlURL == "" || pf.Index.JsonlBytes == 0 || pf.Index.JsonlRawBytes == 0 {
		return false
	}
	if pf.Index.NumBooks > compileGateConstants.SizeCap {
		return false
	}
	jsonlMB := float64(pf.Index.JsonlRawBytes) / 1e6
	c := compileGateConstants
	estPeakBytes := uint64((c.FloorMB + c.SlopeFactor*jsonlMB) * c.Safety * 1e6)
	avail := calibre.MemAvailable()
	if avail == 0 {
		return false
	}
	return estPeakBytes < uint64(float64(avail)*c.Headroom)
}

func normalizeClearnetEndpoint(ep string) (string, error) {
	if !strings.HasSuffix(ep, "/") {
		ep += "/"
	}
	if u, perr := url.Parse(ep); perr != nil || (u.Scheme != "http" && u.Scheme != "https") || u.Host == "" {
		return "", fmt.Errorf("browse: endpoint %q is not a valid http(s):// URL — check the scheme (want e.g. https://library.memoryoftheworld.org)", strings.TrimSuffix(ep, "/"))
	}
	return ep, nil
}

func (c *LibBrowseCmd) Run(ctx *kong.Context) error {
	if c.HandleShowConfig(c) {
		return nil
	}

	alias := c.ActionAlias

	var inv *torinvite.InviteV2
	var baseURL, publisherType string
	var clearnet bool

	switch {
	case c.Invite != "":
		decoded, derr := torinvite.Decode(c.Invite)
		if derr != nil {
			return fmt.Errorf("browse: %w", derr)
		}
		inv = decoded

		if c.HTTPEndpoint != "" {
			nb, verr := normalizeClearnetEndpoint(c.HTTPEndpoint)
			if verr != nil {
				return verr
			}
			clearnet = true
			baseURL = nb
		} else if inv.Endpoint != "" && inv.Onion == "" {
			nb, verr := normalizeClearnetEndpoint(inv.Endpoint)
			if verr != nil {
				return verr
			}
			clearnet = true
			baseURL = nb
		} else if inv.Onion != "" {
			baseURL = "http://" + inv.Onion + "/"
		}
		publisherType = inv.PublisherType

	case c.HTTPEndpoint != "":
		nb, verr := normalizeClearnetEndpoint(c.HTTPEndpoint)
		if verr != nil {
			return verr
		}
		clearnet = true
		baseURL = nb
		publisherType = "aggregator"

	case c.From != "":
		entry, ok := registryGet(c.From)
		if !ok {
			return fmt.Errorf("browse: source %q not found in registry — see 'lib index list'", c.From)
		}
		if entry.Invite != "" {
			decoded, derr := torinvite.Decode(entry.Invite)
			if derr != nil {
				return fmt.Errorf("browse: decode stored invite for %q: %w", c.From, derr)
			}
			inv = decoded
			if entry.Endpoint != "" {
				nb, verr := normalizeClearnetEndpoint(entry.Endpoint)
				if verr != nil {
					return verr
				}
				clearnet = true
				baseURL = nb
			} else if inv.Onion != "" {
				baseURL = "http://" + inv.Onion + "/"
			}
			publisherType = inv.PublisherType
		} else if entry.Endpoint != "" {
			nb, verr := normalizeClearnetEndpoint(entry.Endpoint)
			if verr != nil {
				return verr
			}
			clearnet = true
			baseURL = nb
			publisherType = entry.PublisherType
		} else {
			return fmt.Errorf("browse: source %q has no endpoint or invite", c.From)
		}

	default:
		onion, endpoint, pt, _ := loadBrowseSource(alias)
		if onion == "" && endpoint == "" {
			return fmt.Errorf("browse: no source configured for alias %q — specify --invite or --endpoint on first use", alias)
		}
		publisherType = pt
		if onion != "" && endpoint == "" {
			baseURL = "http://" + onion + "/"
		} else {
			nb, verr := normalizeClearnetEndpoint(endpoint)
			if verr != nil {
				return verr
			}
			clearnet = true
			baseURL = nb
		}

		if onion != "" {
			scheme, token, keyPrivB32, aerr := loadBrowseAuth(alias, onion)
			if aerr != nil {
				return aerr
			}
			inv = &torinvite.InviteV2{
				Onion:         onion,
				Endpoint:      endpoint,
				PublisherType: pt,
			}
			if scheme != "" {
				inv.Auth = &torinvite.InviteAuth{Scheme: scheme, Token: token, KeyPrivB32: keyPrivB32}
			}
		} else if endpoint != "" {
			_, token, _, aerr := loadBrowseAuth(alias, "")
			if aerr != nil {
				return aerr
			}
			if token != "" {
				inv = &torinvite.InviteV2{
					Endpoint:      endpoint,
					PublisherType: pt,
					Auth:          &torinvite.InviteAuth{Scheme: "bearer", Token: token},
				}
			}
		}
	}

	if c.Invite != "" || c.HTTPEndpoint != "" {
		var pOnion, pEndpoint, pLabel string
		if clearnet {
			pEndpoint = baseURL
		} else if inv != nil {
			pOnion = inv.Onion
		}
		if inv != nil {
			pLabel = inv.Label
		}
		persistBrowseSource(alias, pOnion, pEndpoint, publisherType, pLabel)
		if inv != nil && inv.Auth != nil {
			if err := persistBrowseAuth(alias, inv.Auth.Scheme, inv.Auth.Token, inv.Auth.KeyPrivB32); err != nil {
				return err
			}
		}
	}

	cacheBase := filepath.Join(accorderConfigDir, "tor", "cache")
	var cacheDir string
	var staticDir string
	var indexCached bool

	isOffline := c.Offline != nil
	var socksAddrForBrowser string
	var torCleanup func()
	var browseClient *http.Client

	if isOffline {
		dir, oerr := offlineCacheDir(alias, cacheBase)
		if oerr != nil {
			return oerr
		}
		cacheDir = dir
		if err := os.MkdirAll(cacheDir, 0700); err != nil {
			return fmt.Errorf("browse: mkdir cache: %w", err)
		}
		staticDir = filepath.Join(cacheDir, "static")
		indexCached = cachedIndexUsable(staticDir)
	} else {
		if clearnet {
			log.Printf("browse: clearnet HTTP mode — %s (no Tor)", baseURL)
		} else {
			if browseTorDialFn == nil {
				return fmt.Errorf("browse: onion invites require building with -tags tor (or use --endpoint for clearnet)")
			}
			socksAddr, cleanup, dialErr := browseTorDialFn(inv, alias, accorderConfigDir)
			if dialErr != nil {
				return fmt.Errorf("browse: %w", dialErr)
			}
			torCleanup = cleanup
			defer torCleanup()

			socksAddrForBrowser = socksAddr
		}

		rclonexfer.Initialize()
		defer rclonexfer.Finalize()

		if socksAddrForBrowser != "" {
			var cErr error
			browseClient, cErr = newBrowseTorHTTPClient(socksAddrForBrowser)
			if cErr != nil {
				return fmt.Errorf("browse: Tor HTTP client: %w", cErr)
			}
		} else {
			var token string
			if inv != nil && inv.Auth != nil {
				token = inv.Auth.Token
			}
			var clientHost string
			if u, uErr := url.Parse(baseURL); uErr == nil {
				clientHost = u.Host
			}
			browseClient = newBrowseClearnetHTTPClient(token, clientHost)
		}

		if err := os.MkdirAll(cacheBase, 0700); err != nil {
			return fmt.Errorf("browse: mkdir cache base: %w", err)
		}

		pointerURL := baseURL + "static/library_index.manifest.json"
		pf, pfErr := fetchPointerFile(pointerURL, browseClient)

		var identity string
		var havePF bool

		var savedSource, sourceUUID string
		if pfErr != nil {
			log.Printf("browse: pointer file unavailable (%v) — using alias-keyed cache", pfErr)
			identity = alias
		} else {
			havePF = true
			sourceUUID = pf.Library.UUID
			if pf.Library.UUID != "" {
				identity = pf.Library.UUID
				persistBrowseSourceUUID(alias, pf.Library.UUID)
			} else {
				identity = alias
			}

			if pf.Library.UUID != "" {
				entry := SourceEntry{
					UUID:          pf.Library.UUID,
					PublisherType: publisherType,
					LibraryName:   pf.Library.Name,
					Librarian:     pf.Library.Librarian,
				}
				if clearnet {
					entry.Endpoint = baseURL
				}
				if c.Invite != "" {
					entry.Invite = c.Invite
				}

				if c.From != "" {
					if err := registrySet(c.From, entry); err != nil {
						return fmt.Errorf("browse --from %s: %w\n"+
							"The source at this endpoint has a different identity than expected.",
							c.From, err)
					}
					savedSource = c.From
					log.Printf("[REG] source %q updated (uuid %s)", c.From, pf.Library.UUID)
				} else {
					regName := calibre.SlugifySourceName(pf.Library.Name)
					if regName == "" {
						regName = calibre.SlugifySourceName(pf.Library.Librarian)
					}
					if regName == "" && baseURL != "" {
						if u, uerr := url.Parse(baseURL); uerr == nil {
							regName = calibre.SlugifySourceName(u.Hostname())
						}
					}
					if regName == "" {
						regName = pf.Library.UUID
					}

					saved := registerOrUpdate(regName, entry)
					savedSource = saved
					log.Printf("[REG] source %q registered (uuid %s)", saved, pf.Library.UUID)
				}
			}
		}

		cacheDir = filepath.Join(cacheBase, identity)
		if err := os.MkdirAll(cacheDir, 0700); err != nil {
			return fmt.Errorf("browse: mkdir identity cache: %w", err)
		}

		staticDir = filepath.Join(cacheDir, "static")
		if err := os.MkdirAll(staticDir, 0755); err != nil {
			return fmt.Errorf("browse: mkdir static: %w", err)
		}
		indexCached = cachedIndexUsable(staticDir)

		syncErr := func() error {
			localPath := filepath.Join(staticDir, "library_index.zst")
			indexURL := baseURL + "static/library_index.zst"

			if !havePF {
				log.Println("browse: syncing catalog (full download — no pointer file)...")
				if err := downloadFull(indexURL, localPath, browseClient); err != nil {
					return fmt.Errorf("browse: download index: %w", err)
				}
				log.Println("browse: catalog synced")
				return nil
			}

			cachedState, csErr := calibre.LoadSyncState(cacheDir, identity)
			if csErr != nil && !os.IsNotExist(csErr) {
				return fmt.Errorf("browse: load sync state: %w", csErr)
			}

			syncMode := "append"
			if publisherType == "aggregator" {
				syncMode = "hybrid"
			}
			action := calibre.DetermineSyncAction(cachedState, pf, syncMode, false)

			pointerBase, _ := url.Parse(pointerURL)
			resolvedURL, rErr := calibre.ResolveRelativeURL(pointerBase, pf.Index.URL)
			if rErr != nil {
				log.Printf("browse: malformed index URL %q in pointer file (%v) — using default location", pf.Index.URL, rErr)
			} else if resolvedURL != "" {
				indexURL = resolvedURL
			}

			fetchOrCompile := func() error {
				if shouldCompileFromJSONL(pf, clearnet) {
					if err := compileFromJSONL(pf, pointerBase, localPath, browseClient); err != nil {
						log.Printf("browse: compile from JSONL failed (%v) — falling back to full download", err)
						return downloadFull(indexURL, localPath, browseClient)
					}
					return nil
				}
				log.Printf("browse: downloading index (%s)...", action.Reason)
				return downloadFull(indexURL, localPath, browseClient)
			}

			switch action.Kind {
			case calibre.SyncNoOp:
				if indexCached {
					log.Printf("browse: index up to date (%s)", action.Reason)
				} else {
					log.Printf("browse: index up to date but local copy missing — downloading...")
					if err := fetchOrCompile(); err != nil {
						return fmt.Errorf("browse: download index: %w", err)
					}
				}
			case calibre.SyncFullDownload:
				if err := fetchOrCompile(); err != nil {
					return fmt.Errorf("browse: download index: %w", err)
				}
			case calibre.SyncRangeFetch:
				if !rangeFetchAllowed(localPath) {
					log.Printf("browse: local index is locally-compiled (JSONL-compiled or recompiled with descriptions) — re-syncing fully instead of range-fetch (%s)", action.Reason)
					if err := fetchOrCompile(); err != nil {
						return fmt.Errorf("browse: re-sync index: %w", err)
					}
				} else {
					log.Printf("browse: range-fetch index (%s)...", action.Reason)
					if err := rangeFetchTail(indexURL, localPath, cachedState, pf, browseClient); err != nil {
						return fmt.Errorf("browse: range-fetch index: %w", err)
					}
				}
			}

			if action.Kind != calibre.SyncNoOp {
				if err := calibre.SaveSyncState(cacheDir, identity, pf); err != nil {
					return fmt.Errorf("browse: save sync state: %w", err)
				}
			}

			if publisherType == "aggregator" {
				data1URL := baseURL + "static/data1.js"
				if err := fetchBrowseData1(data1URL, staticDir, browseClient); err != nil {
					log.Printf("browse: data1.js sync: %v (non-fatal)", err)
				}
			}

			log.Println("browse: catalog synced")
			return nil
		}()

		if syncErr != nil {
			if indexCached {
				log.Printf("browse: catalog sync failed (%v) — opening the cached library offline", syncErr)
			} else {
				return syncErr
			}
		}

		if _, terr := emitBrowseTeaching(alias, sourceUUID, baseURL, savedSource, os.Stderr); terr != nil {

			log.Printf("browse: could not record orientation marker: %v (non-fatal)", terr)
		}

		for i := 2; i <= 8; i++ {
			stub := fmt.Sprintf("CALIBRE_BOOKS%d={books:[]}", i)
			path := filepath.Join(staticDir, fmt.Sprintf("data%d.js", i))
			if err := os.WriteFile(path, []byte(stub), 0644); err != nil {
				log.Printf("browse: write data%d.js stub: %v", i, err)
			}
		}
		if publisherType == "per_library" {
			if err := os.WriteFile(filepath.Join(staticDir, "data1.js"),
				[]byte("CALIBRE_BOOKS1={portable:false,books:[]};"), 0644); err != nil {
				log.Printf("browse: write data1.js stub: %v", err)
			}
		} else if publisherType == "aggregator" {
			data1Path := filepath.Join(staticDir, "data1.js")
			if _, e := os.Stat(data1Path); os.IsNotExist(e) {
				if err := os.WriteFile(data1Path,
					[]byte("CALIBRE_BOOKS1={portable:false,books:[]};"), 0644); err != nil {
					log.Printf("browse: write data1.js stub: %v", err)
				}
			}
		}
	}

	if wantsDescriptionIndex(alias) {
		indexBase := filepath.Join(staticDir, "library_index")
		mf, mErr := calibre.ReadExistingManifest(indexBase)
		switch {
		case mErr != nil:
			log.Printf("browse: description search enabled but reading the index manifest failed: %v (serving the plain index)", mErr)
		case mf.IndexedFieldCount >= 4:

		default:
			if n, rErr := recompileIndexWithDescriptions(indexBase); rErr != nil {
				if errors.Is(rErr, errNoDescriptions) {
					log.Printf("browse: description search enabled but this library has no descriptions — skipping")
				} else {
					log.Printf("browse: re-applying description search failed: %v (continuing with the plain index)", rErr)
				}
			} else {
				log.Printf("browse: re-applied description search index (%d books)", n)
			}
		}
	}

	if err := calibre.CopyBrowseUIAssets(cacheDir); err != nil {
		return fmt.Errorf("browse: write UI assets: %w", err)
	}

	if publisherType == "aggregator" && c.FilesRoot != "" {
		log.Printf("browse: ignoring --files-root %q for an aggregate (use it only for single-library browse); fetching files from the remote", c.FilesRoot)
		c.FilesRoot = ""
	}

	opts := browselocal.Options{
		CalibrePath: c.CalibrePath,
		Librarian:   c.Librarian,
		DownloadDir: c.DownloadDir,
		Invite:      inv,
		FilesRoot:   c.FilesRoot,
		EnsureAlias: func(libraryName, libraryPath, librarian string) (string, error) {
			return ensureAliasForBrowse(ctx, libraryName, libraryPath, librarian)
		},
	}
	if publisherType == "per_library" {
		opts.RemoteFilesPrefix = "files"
	}
	if !isOffline && !clearnet {
		opts.SocksAddr = socksAddrForBrowser
	}
	if !isOffline && browseClient != nil {
		opts.HTTPClient = browseClient
		opts.BaseURL = baseURL
	}
	if inv != nil && inv.Auth != nil && inv.Auth.Token != "" && inv.Endpoint != "" {
		opts.RedeemURL = baseURL + "redeem?token=" + inv.Auth.Token
	}
	return browselocal.Run(cacheDir, opts)
}
