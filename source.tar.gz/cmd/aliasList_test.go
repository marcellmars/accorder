//go:build !tailscale

package cmd

// config-alias-ux tests: the `config list` curated views (families,
// per-family columns, dotted filters, profile narrowing), the compat
// `aliases` spelling, and the read-only invariant on action_aliases.json.

import (
	"bytes"
	"os"
	"strings"
	"testing"
)

// seedAliases writes a fixed profile store into the temp config dir
// created by testSetup.
func seedAliases(t *testing.T) {
	t.Helper()
	seed := `{
	  "biopolitics": {"lib": {"build": {"calibrepath": "/data/biopolitics", "librarian": "Ann", "libraryID": "bio-1"}}},
	  "serve-fed": {"fedlib": {"share": {"live": {"bucket": "motw", "upload-prefix": "pub/", "listen": ":8080", "mode": "ro"}}}},
	  "mixed": {"lib": {"build": {"calibrepath": "/data/mixed"}}, "fedlib": {"share": {"live": {"bucket": "motw2"}}}}
	}`
	if err := os.WriteFile(savedActionAliases, []byte(seed), 0644); err != nil {
		t.Fatalf("seed aliases: %v", err)
	}
}

// lineContaining returns the first output line containing substr.
func lineContaining(t *testing.T, output, substr string) string {
	t.Helper()
	for _, line := range strings.Split(output, "\n") {
		if strings.Contains(line, substr) {
			return line
		}
	}
	t.Fatalf("no line containing %q in:\n%s", substr, output)
	return ""
}

func runList(t *testing.T, filter string) (string, error) {
	t.Helper()
	cmd := &AliasListCmd{Filter: filter}
	stdout, _, err := captureInviteOutput(t, cmd.Run)
	return stdout, err
}

func TestConfigListNoFilter(t *testing.T) {
	testSetup(t)
	seedAliases(t)
	stdout, err := runList(t, "")
	if err != nil {
		t.Fatalf("run: %v", err)
	}
	for _, want := range []string{"PROFILE", "ACTIONS"} {
		if !strings.Contains(stdout, want) {
			t.Errorf("families view missing header %q:\n%s", want, stdout)
		}
	}
	if got := lineContaining(t, stdout, "biopolitics"); !strings.Contains(got, "lib") {
		t.Errorf("biopolitics row missing lib family: %q", got)
	}
	if got := lineContaining(t, stdout, "serve-fed"); !strings.Contains(got, "fedlib") {
		t.Errorf("serve-fed row missing fedlib family: %q", got)
	}
	mixedLine := lineContaining(t, stdout, "mixed")
	if !strings.Contains(mixedLine, "fedlib") || !strings.Contains(mixedLine, "lib") {
		t.Errorf("mixed row should carry both families: %q", mixedLine)
	}
}

func TestConfigListLibFilter(t *testing.T) {
	testSetup(t)
	seedAliases(t)
	stdout, err := runList(t, "lib")
	if err != nil {
		t.Fatalf("run: %v", err)
	}
	for _, want := range []string{"PROFILE", "CALIBREPATH", "LIBRARIAN", "LIBRARYID", "/data/biopolitics", "Ann", "bio-1"} {
		if !strings.Contains(stdout, want) {
			t.Errorf("lib filter output missing %q:\n%s", want, stdout)
		}
	}

	// providedFlags discipline: mixed has no librarian/libraryID -> "-" cells.
	mixedLine := lineContaining(t, stdout, "mixed")
	if got := strings.Count(mixedLine, "-"); got < 2 {
		t.Errorf("expected >=2 '-' cells on mixed row, got %d: %q", got, mixedLine)
	}
	if strings.Contains(stdout, "serve-fed") {
		t.Errorf("fedlib-only profile listed under lib filter:\n%s", stdout)
	}
}

func TestConfigListFedlibFilter(t *testing.T) {
	testSetup(t)
	seedAliases(t)
	stdout, err := runList(t, "fedlib")
	if err != nil {
		t.Fatalf("run: %v", err)
	}
	for _, want := range []string{"PROFILE", "BUCKET", "UPLOAD-PREFIX", "LISTEN", "MODE", "motw", "pub/", ":8080", "ro"} {
		if !strings.Contains(stdout, want) {
			t.Errorf("fedlib filter output missing %q:\n%s", want, stdout)
		}
	}

	// mixed carries only bucket under fedlib -> "-" cells for the rest.
	mixedLine := lineContaining(t, stdout, "mixed")
	if !strings.Contains(mixedLine, "motw2") {
		t.Errorf("mixed row missing bucket motw2: %q", mixedLine)
	}
	if got := strings.Count(mixedLine, "-"); got < 3 {
		t.Errorf("expected >=3 '-' cells on mixed row, got %d: %q", got, mixedLine)
	}
	if strings.Contains(stdout, "biopolitics") {
		t.Errorf("lib-only profile listed under fedlib filter:\n%s", stdout)
	}
}

func TestConfigListDottedFilter(t *testing.T) {
	testSetup(t)
	seedAliases(t)
	stdout, err := runList(t, "lib.build")
	if err != nil {
		t.Fatalf("run: %v", err)
	}

	// lib.build resolves to the lib column set; both lib carriers listed.
	for _, want := range []string{"CALIBREPATH", "biopolitics", "mixed"} {
		if !strings.Contains(stdout, want) {
			t.Errorf("lib.build filter output missing %q:\n%s", want, stdout)
		}
	}
	if strings.Contains(stdout, "serve-fed") {
		t.Errorf("fedlib-only profile listed under lib.build filter:\n%s", stdout)
	}
}

func TestConfigListProfileNarrowing(t *testing.T) {
	testSetup(t)
	seedAliases(t)
	stdout, err := runList(t, "lib.biopolitics")
	if err != nil {
		t.Fatalf("run: %v", err)
	}
	for _, want := range []string{"CALIBREPATH", "biopolitics", "/data/biopolitics", "Ann", "bio-1"} {
		if !strings.Contains(stdout, want) {
			t.Errorf("narrowed output missing %q:\n%s", want, stdout)
		}
	}

	// Exactly one data row: header + biopolitics + trailing newline.
	lines := strings.Split(strings.TrimRight(stdout, "\n"), "\n")
	if len(lines) != 2 {
		t.Errorf("expected header + 1 row, got %d lines:\n%s", len(lines), stdout)
	}
	if strings.Contains(stdout, "mixed") {
		t.Errorf("narrowed output leaked other profile:\n%s", stdout)
	}
}

func TestConfigListUnknownFilter(t *testing.T) {
	testSetup(t)
	seedAliases(t)
	_, err := runList(t, "nosuch")
	if err == nil {
		t.Fatal("expected error for unknown filter, got nil")
	}
	for _, want := range []string{"nosuch", "action path", "profile name"} {
		if !strings.Contains(err.Error(), want) {
			t.Errorf("error missing %q: %v", want, err)
		}
	}
}

func TestConfigListEmptyStore(t *testing.T) {
	testSetup(t)
	stdout, err := runList(t, "")
	if err != nil {
		t.Fatalf("run: %v", err)
	}
	if !strings.Contains(stdout, "No saved profiles.") {
		t.Errorf("empty store output = %q, want %q", stdout, "No saved profiles.")
	}
}

func TestConfigCompatSpelling(t *testing.T) {
	testSetup(t)
	seedAliases(t)
	var selected []string
	for _, args := range [][]string{{"config", "list"}, {"aliases", "list"}} {
		_, ctx := parseCLI(t, args)
		selected = append(selected, ctx.Command())
	}
	if selected[0] != selected[1] {
		t.Errorf("compat spellings selected different commands: %q vs %q", selected[0], selected[1])
	}
}

func TestConfigListReadOnly(t *testing.T) {
	testSetup(t)
	seedAliases(t)
	before, err := os.ReadFile(savedActionAliases)
	if err != nil {
		t.Fatalf("read store: %v", err)
	}
	for _, filter := range []string{"", "lib", "fedlib", "lib.build", "lib.biopolitics", "nosuch"} {
		_, _ = runList(t, filter)
	}
	after, err := os.ReadFile(savedActionAliases)
	if err != nil {
		t.Fatalf("read store: %v", err)
	}
	if !bytes.Equal(before, after) {
		t.Fatal("config list mutated action_aliases.json")
	}
}
