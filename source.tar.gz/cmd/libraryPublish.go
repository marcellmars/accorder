package cmd

import (
	"accorder/pkg/calibre"
	"accorder/pkg/libraryflow"
	"accorder/pkg/rclonexfer"
	"accorder/pkg/torshare"
	"bytes"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"github.com/alecthomas/kong"
)

type publishOptions struct {
	FinishInterruptedPublish bool
	DryRun                   bool
	MaxDeletes               int
	LocalWins                bool
	AllowCompleteOverwrite   bool
	Verbose                  bool
	RcloneLogLevel           string
}

type libraryCandidate struct {
	// Root is the librarian's own Calibre library. Publish reads and writes
	// it in place: the library on disk is the thing being published, and the
	// librarian closes Calibre before running the command.
	//
	// An earlier design copied the whole library into a throwaway sibling so
	// that Calibre could keep writing during a publish. Nobody asked for
	// that. On a real collection the copy cost tens of gigabytes and minutes
	// of wall clock per run, and the fingerprint check bracketing it aborted
	// the publish whenever Calibre touched metadata.db inside that window — a
	// window the copy itself had opened. requireClosedCalibre buys the same
	// guarantee for two stat calls.
	Root              string
	SourceFingerprint string
	Objects           []libraryflow.Object
	Excludes          []string
	Change            *localChangeCandidate
}

// publishBeforeExecuteHook is nil in production. Tests use the seam to prove
// that an object created after planning is never discovered as a delete target
// and prevents the commit marker through final inventory verification.
var publishBeforeExecuteHook func(*libraryRemote) error

// publishCommitStageHook is a fault-injection seam for the protected-write
// transaction. Production leaves it nil.
var publishCommitStageHook func(string) error

func runPublishCommitStageHook(stage string) error {
	if publishCommitStageHook == nil {
		return nil
	}
	return publishCommitStageHook(stage)
}

func requirePublishWriter(remote *libraryRemote, expected remoteWriterState, seatID string) (remoteWriterState, error) {
	current := remote.readWriter()
	if current.Kind != "valid" || current.Marker.State != "claimed" || current.Marker.SeatID != seatID || !bytes.Equal(current.Raw, expected.Raw) {
		return remoteWriterState{}, errors.New("publishing access changed while files were uploading; the remote update was not activated")
	}
	return current, nil
}

// calibreOpenMarkers are the SQLite sidecar files that exist only while a
// connection to metadata.db is open. SQLite removes both when the last
// connection closes, so their presence answers "is Calibre holding this
// library" without a process table, a lock protocol, or a race window.
var calibreOpenMarkers = []string{"metadata.db-wal", "metadata.db-shm"}

// requireClosedCalibre refuses to publish a library Calibre still has open.
// A marker left stale by a crash clears as soon as Calibre is opened and shut
// down again, which is what the message asks for in any case.
func requireClosedCalibre(library string) error {
	for _, marker := range calibreOpenMarkers {
		_, err := os.Stat(filepath.Join(library, marker))
		if err == nil {
			return fmt.Errorf("Calibre still has %s open (%s exists); close Calibre and run the command again", library, marker)
		}
		if !os.IsNotExist(err) {
			return err
		}
	}
	return nil
}

func captureExistingCandidate(source string, excludes []string) (*libraryCandidate, error) {
	if err := requireClosedCalibre(source); err != nil {
		return nil, err
	}
	candidate := &libraryCandidate{
		Root:     source,
		Excludes: append([]string(nil), excludes...),
	}
	if err := refreshCandidateIdentity(candidate); err != nil {
		return nil, err
	}
	return candidate, nil
}

func buildPublishCandidate(ctx *kong.Context, command *LibPublishCmd) (*libraryCandidate, error) {
	candidate, err := captureExistingCandidate(command.CalibreDirectory, resolveUploadExcludes(command.CalibreDirectory, nil))
	if err != nil {
		return nil, err
	}
	// --dry-run previews the upload, not the build: it plans against the
	// artifacts `lib build` has already written. Building here would mean a
	// command documented as changing nothing rewrote the browse site, the
	// index family and the retained catalog on every preview.
	if command.DryRun {
		return candidate, nil
	}
	build := &LibBuildCmd{GroupLib: command.GroupLib}
	build.ActionAlias = command.ActionAlias
	build.InPipeline = true
	if err := build.Run(ctx); err != nil {
		return nil, fmt.Errorf("build library: %w", err)
	}
	if err := reconcileCandidateExcludes(candidate, build.PrivateExcludes); err != nil {
		return nil, err
	}
	return candidate, nil
}

func refreshCandidateIdentity(candidate *libraryCandidate) error {
	objects, err := listLocalObjects(candidate.Root)
	if err != nil {
		return err
	}
	candidate.Objects = objects
	attached, err := attachLocalChangeCandidate(candidate)
	if err != nil {
		return err
	}
	if attached {
		return nil
	}
	candidate.SourceFingerprint, _, err = libraryflow.SourceFingerprint(candidate.Root, candidate.Excludes)
	return err
}

// attachLocalChangeCandidate returns true when the saved content ledger was
// complete enough to derive the current source fingerprint. A current ledger
// lets upload reuse its validated metadata.db checksum as well as every other
// content hash; it remains useful for deriving the fingerprint even when a
// changed file means the build candidate itself must be rejected.
func attachLocalChangeCandidate(candidate *libraryCandidate) (bool, error) {
	candidate.Change = nil
	change, err := loadLocalChangeCandidate(candidate.Root)
	if err != nil {
		if localChangeCandidateFile(candidate.Root) == evidenceStatePath(legacyChangeCandidateFile(candidate.Root)) {
			return false, fmt.Errorf("saved build checkpoint was retained; cannot prepare publication: %w", err)
		}
		return false, nil
	}
	// SourceFingerprint intentionally binds portable path/size metadata rather
	// than payload bytes. Revalidate the build's private content ledger at this
	// handoff so a same-size rewrite cannot keep a stale candidate attached and
	// poison every subsequent upload attempt.
	ledger, _, changed, removed, err := refreshSourceEvidence(candidate.Root, candidate.Objects, candidate.Excludes, change.ContentLedger, change.Evidence)
	if err != nil {
		return false, fmt.Errorf("verify library files before publication: %w", err)
	}
	fingerprint, err := sourceFingerprintFromContentLedger(ledger)
	if err != nil {
		return false, err
	}
	candidate.SourceFingerprint = fingerprint
	if change.TargetSourceFingerprint != fingerprint || len(changed) != 0 || len(removed) != 0 {
		return true, nil
	}
	if !localIndexArtifactMatches(candidate.Root, change.IndexArtifact) {
		return true, nil
	}
	candidate.Change = change
	return true, nil
}

// reconcileCandidateExcludes settles the exclude set and the source
// fingerprint once the build has run.
//
// Capture happens before the build knows which books are tagged private, so
// the two exclude sets differ whenever the private set moved — on the first
// publish of a library that has private books, most of all. The candidate
// adopts the set the build derived and re-derives its fingerprint under it.
// That second value is the one the remote reproduces from the objects it
// receives, which makes it the value commit verification compares against and
// the value the baseline records.
func reconcileCandidateExcludes(candidate *libraryCandidate, privateExcludes []string) error {
	candidate.Excludes = resolveUploadExcludes(candidate.Root, privateExcludes)
	return refreshCandidateIdentity(candidate)
}

func listLocalObjects(root string) ([]libraryflow.Object, error) {
	var objects []libraryflow.Object
	err := filepath.WalkDir(root, func(path string, entry fs.DirEntry, walkErr error) error {
		if walkErr != nil {
			return walkErr
		}
		if path == root || entry.IsDir() {
			return nil
		}
		if entry.Type()&os.ModeSymlink != 0 {
			return fmt.Errorf("refusing symlink in publish candidate: %s", path)
		}
		info, err := entry.Info()
		if err != nil {
			return err
		}
		rel, err := filepath.Rel(root, path)
		if err != nil {
			return err
		}
		objects = append(objects, libraryflow.NewLocalObjectAt(filepath.ToSlash(rel), path, info))
		return nil
	})
	sort.Slice(objects, func(i, j int) bool { return objects[i].Path < objects[j].Path })
	return objects, err
}

// publishCandidate mirrors the library to the bucket and then writes the
// commit record.
//
// The transfer is one rclone sync. rclone enumerates both sides in parallel
// while it transfers, which is the job it is built for and the job accorder
// gave it until bfd9e8b replaced it with a hand-rolled inventory, plan and
// per-object executor. That replacement had to walk the bucket itself before
// it could do anything: on a real collection one such walk ran past 25
// minutes, and a publish needed several.
//
// The commit record — pointer, generation sentinel, writer marker, baseline —
// stays. It is four small objects, it is what `lib status`, `lib sync` and
// `lib seat` read, and none of it ever needed the inventory: the fingerprint
// it binds is computed from the librarian's own library.
//
// Ordering is the safety property, and it is the same one the pre-bfd9e8b
// code had: _GENERATION is excluded from the sync and written last, so a
// half-finished transfer never looks committed.
func publishCandidate(alias, libraryID string, creds GroupS3Credentials, candidate *libraryCandidate, options publishOptions) error {
	if options.MaxDeletes < 0 {
		return errors.New("lib publish: --max-deletes cannot be negative")
	}
	remote, err := openLibraryRemoteForCommand(alias, creds)
	if err != nil {
		return fmt.Errorf("lib publish: %w", err)
	}
	defer remote.Close()
	if options.DryRun {
		if _, err := os.Stat(derivedEvidenceRepairPath(alias)); err == nil {
			return errors.New("an interrupted index repair needs recovery before a preview")
		} else if !os.IsNotExist(err) {
			return err
		}
		if _, err := os.Stat(publishRecoveryPath(alias)); err == nil {
			return errors.New("an interrupted publish needs recovery before a preview; run lib publish without --dry-run")
		} else if !os.IsNotExist(err) {
			return err
		}
		if candidate.Change == nil {
			return fmt.Errorf("run `accorder lib build %s` before previewing publication", alias)
		}
	}
	// After the remote is open: librclone.Initialize resets the log handler,
	// so the level has to be raised on this side of it (pkg/rclonexfer's
	// SetLogLevel documents the ordering). Empty is rclone's default NOTICE.
	if err := rclonexfer.SetLogLevel(options.RcloneLogLevel); err != nil {
		return fmt.Errorf("lib publish: %w", err)
	}
	if !options.DryRun {
		recovered, err := recoverPublishBookkeeping(alias, libraryID, remote, candidate.Root, options)
		if err != nil {
			return fmt.Errorf("lib publish: could not safely resume an interrupted publish; inspect `accorder lib status %s` before retrying: %w", alias, err)
		}
		if recovered {
			fmt.Println("Recovered the previously committed publication.")
			return nil
		}
	}

	initial := remote.commitState()
	if initial.Err != nil && !initial.Legacy {
		return fmt.Errorf("lib publish: remote snapshot is interrupted/uncommitted: %w", initial.Err)
	}
	if initial.Committed || initial.Legacy {
		if initial.Pointer.Library.UUID != "" && libraryID != "" && initial.Pointer.Library.UUID != libraryID {
			return fmt.Errorf("lib publish: remote library UUID %s does not match local %s", initial.Pointer.Library.UUID, libraryID)
		}
	}
	if initial.Writer.Kind == "invalid" || initial.Writer.Kind == "unreadable" {
		return fmt.Errorf("lib publish: refusing invalid/unreadable _WRITER: %w", initial.Writer.Err)
	}

	// Divergence is decided from the commit record the remote already carries,
	// not from a fresh walk of its objects.
	baseline, err := loadBaseline(alias)
	if err != nil {
		return fmt.Errorf("lib publish: %w", err)
	}
	if initial.SourceFingerprint != "" && initial.SourceFingerprint != candidate.SourceFingerprint {
		localChanged := baseline == nil || candidate.SourceFingerprint != baseline.LocalSourceFingerprint
		remoteChanged := baseline == nil || initial.SourceFingerprint != baseline.RemoteSourceFingerprint
		if remoteChanged && !localChanged && !options.LocalWins {
			return fmt.Errorf("lib publish: remote is ahead; run `accorder lib sync %s` before publishing", alias)
		}
		if remoteChanged && localChanged && !options.LocalWins {
			return fmt.Errorf("lib publish: local and remote both changed; run `accorder lib sync %s --remote-wins` or `accorder lib publish %s --local-wins`", alias, alias)
		}
	}

	// Everything libraryflow.IsProtectedPath names is withheld from the
	// mirror: the pointer, the generation sentinel, the writer marker and the
	// installation identity. Two reasons, and both matter. They are the commit
	// record, so they are written explicitly and in order afterwards — sentinel
	// last, exactly as the pre-bfd9e8b publish did. And _WRITER and _IDENTITY
	// exist only on the remote, so a mirror that could see them would delete
	// them as "not present locally", which is precisely how the first run of
	// this rewrite lost the writer seat.
	//
	// rclone applies a filter to both sides, so an excluded path is neither
	// transferred nor deleted.
	excludes := append([]string(nil), candidate.Excludes...)
	excludes = append(excludes,
		"/"+libraryflow.WriterPath,
		"/"+libraryflow.GenerationPath,
		"/_IDENTITY",
		"/.accorder/**",
		"**.manifest.json",
	)
	syncOptions := rclonexfer.SyncOptions{DryRun: options.DryRun, MaxDelete: options.MaxDeletes}

	var installation libraryInstallation
	if options.DryRun {
		installation, err = loadInstallation()
		if os.IsNotExist(err) {
			err = nil
		}
	} else {
		installation, err = loadOrCreateInstallation()
	}
	if err != nil {
		return fmt.Errorf("lib publish: %w", err)
	}
	if initial.Writer.Kind == "valid" && initial.Writer.Marker.State == "claimed" && initial.Writer.Marker.SeatID != installation.SeatID {
		return fmt.Errorf("lib publish: writer is %q on another seat; sync there, release it, or explicitly take over with `accorder lib seat claim %s --force`", initial.Writer.Marker.SeatLabel, alias)
	}

	// Read the commit artifacts BEFORE touching the bucket. A library with no
	// pointer or no _GENERATION (for example a tree restored by `lib sync`,
	// which never writes the sentinel) would otherwise be discovered only
	// after the mirror had already run, leaving the remote payload replaced
	// and uncommitted.
	pointerPath := filepath.Join(candidate.Root, filepath.FromSlash(memberPointerPath))
	pointer, err := calibre.ReadPointerFile(pointerPath)
	if err != nil {
		return fmt.Errorf("lib publish: library pointer: %w", err)
	}
	generationRaw, err := os.ReadFile(filepath.Join(candidate.Root, libraryflow.GenerationPath))
	if err != nil {
		return fmt.Errorf("lib publish: library generation: %w", err)
	}
	base, localGeneration, err := torshare.DecodeGeneration(generationRaw)
	if err != nil {
		return fmt.Errorf("lib publish: library generation: %w", err)
	}
	if candidate.Change != nil {
		if strings.TrimSuffix(candidate.Change.IndexArtifact.Path, ".zst")+".manifest.json" != memberPointerPath {
			return errors.New("lib publish: saved build information refers to an index that cannot be published; run `accorder lib build` again")
		}
		_, _, validateErr := readAndValidateDerivedFamily(candidate.Root, candidate.Change.IndexArtifact.Path)
		if validateErr != nil {
			return fmt.Errorf("lib publish: generated library-index files are incomplete or inconsistent; run `accorder lib build` again: %w", validateErr)
		}
		if pointer.CatalogChecksum != candidate.Change.ToCatalogChecksum || pointer.Index.NumBooks != candidate.Change.ToLiveCount {
			return errors.New("lib publish: saved build information does not match the generated library index; run `accorder lib build` again")
		}
		indexPath := filepath.Join(candidate.Root, filepath.FromSlash(strings.TrimSuffix(candidate.Change.IndexArtifact.Path, ".zst")))
		catalogChecksum, liveCount, checksumErr := calibre.CatalogChecksumFromIndex(indexPath)
		if checksumErr != nil {
			return fmt.Errorf("lib publish: verify built index catalog checksum: %w", checksumErr)
		}
		if catalogChecksum != candidate.Change.ToCatalogChecksum || liveCount != candidate.Change.ToLiveCount {
			return errors.New("lib publish: the generated library index changed after the build completed; run `accorder lib build` again")
		}
	}
	nextGeneration := localGeneration
	if initial.Generation >= nextGeneration {
		nextGeneration = initial.Generation + 1
	}
	committedGeneration := torshare.EncodeGeneration(base, nextGeneration)
	baselineRemoteSource := ""
	if baseline != nil && baseline.LibraryID == libraryID {
		baselineRemoteSource = baseline.RemoteSourceFingerprint
	}
	bound, err := bindGenerationPublication(initial, pointer, candidate, committedGeneration, baselineRemoteSource)
	if err != nil {
		return fmt.Errorf("lib publish: %w", err)
	}
	if candidate.Change != nil && candidate.Change.Reason == "legacy-content-baseline-upgrade" {
		if !initial.Committed || initial.SourceFingerprint != baselineRemoteSource ||
			candidate.Change.FromGeneration != hex.EncodeToString(initial.GenerationRaw) {
			return fmt.Errorf("lib publish: the remote library changed after this update was prepared; resolve it with `accorder lib sync %s`, rebuild, and publish again", alias)
		}
	}
	if bound.CompleteOverwrite && !options.AllowCompleteOverwrite {
		return fmt.Errorf("lib publish: Accorder cannot safely identify only the changed files for this existing remote library. No library files were uploaded. To upload every public file again, review the bandwidth cost and rerun with --allow-full-reupload. Reason: %s", generationChangeReasonDetails(bound.Reason))
	}
	if err := verifyLocalPublishCandidate(candidate); err != nil {
		return err
	}
	privateDirs, err := privateCleanupDirs(candidate.Excludes)
	if err != nil {
		return fmt.Errorf("lib publish: %w", err)
	}
	privateTargets, err := planPrivateCleanup(remote, privateDirs)
	if err != nil {
		return fmt.Errorf("lib publish: %w", err)
	}
	if len(privateTargets) > 0 && (candidate.Change == nil || candidate.Change.ContentLedgerVersion != sourceEvidenceVersion) {
		return fmt.Errorf("lib publish: run `accorder lib build %s` before removing previously published private files; this older build lacks the information needed to resume cleanup safely", alias)
	}
	if options.DryRun {
		fmt.Println("DRY RUN — no local or remote changes")
		for _, object := range privateTargets {
			fmt.Printf("Remove remotely published private file: %s (%d bytes; local file retained)\n", object.Path, object.Size)
		}
	}
	if len(privateTargets) > options.MaxDeletes {
		return fmt.Errorf("lib publish: removing private files needs %d remote deletions, exceeding --max-deletes=%d; no library files were uploaded; preview and raise the limit if these removals are intended", len(privateTargets), options.MaxDeletes)
	}
	if len(privateTargets) > 0 && len(bound.ManifestBytes) > 0 {
		// Old leaked files may belong to books absent from both catalog versions.
		// An exact current change list cannot describe all of those cache paths.
		manifest, err := calibre.DecodeGenerationChangeManifest(bound.ManifestBytes, calibre.GenerationChangeLimits{})
		if err != nil {
			return err
		}
		manifest.Scope, manifest.Changes = calibre.GenerationChangeScopeCoarse, nil
		bound.ManifestBytes, err = calibre.EncodeGenerationChangeManifest(manifest)
		if err != nil {
			return err
		}
		bound.Scope, bound.Reason = calibre.GenerationChangeScopeCoarse, "private-file-cleanup"
	}
	// Both phases share one budget. The mirror cannot consume the portion
	// reserved for explicit private cleanup, including when the remainder is 0.
	syncOptions.MaxDelete -= len(privateTargets)
	if options.DryRun {
		if err := runLibrarySync("Previewing publish:", candidate.Root, remote.fsPath, excludes, syncOptions); err != nil {
			return fmt.Errorf("lib publish: %w", err)
		}
		paths := append([]string(nil), bound.ForcePaths...)
		if bound.CompleteOverwrite {
			objects, filterErr := libraryflow.FilterInventory(candidate.Objects, candidate.Excludes, true)
			if filterErr != nil {
				return filterErr
			}
			paths = nil
			for _, object := range objects {
				paths = append(paths, object.Path)
			}
		}
		derived, err := localDerivedPublicationPaths(candidate)
		if err != nil {
			return err
		}
		paths = append(paths, derived...)
		seen := make(map[string]bool)
		var forcedBytes int64
		var sourceFiles int
		var sourceBytes int64
		for _, path := range paths {
			if seen[path] {
				continue
			}
			seen[path] = true
			info, err := os.Stat(filepath.Join(candidate.Root, filepath.FromSlash(path)))
			if err != nil {
				return err
			}
			forcedBytes += info.Size()
			if libraryflow.IsSourcePath(path) {
				sourceFiles++
				sourceBytes += info.Size()
			}
			fmt.Printf("Forced upload: %s (%d bytes; copied even when size is unchanged)\n", path, info.Size())
		}
		fmt.Printf("Forced uploads: %d %s, %d bytes\n", sourceFiles, plural(sourceFiles, "file", "files"), sourceBytes)
		fmt.Printf("Forced upload set: %d unique files, %d bytes (may overlap the mirror preview; do not add the totals).\n", len(seen), forcedBytes)
		if bound.CompleteOverwrite {
			fmt.Println("Full library re-upload authorized for this invocation.")
		}
		fmt.Println("Result: publish allowed; source, writer and remote version will be rechecked during execution")
		return nil
	}
	claimedByAttempt, transferStarted, completed := false, false, false
	defer func() {
		if claimedByAttempt && !transferStarted && !completed {
			current := remote.readWriter()
			if current.Kind == "valid" && current.Marker.State == "claimed" && current.Marker.SeatID == installation.SeatID {
				_ = writeAndVerifyWriter(remote, libraryflow.ReleaseWriter(time.Now(), current.Marker))
			}
		}
	}()
	expectedWriter := initial.Writer
	if initial.Writer.Kind == "absent" || (initial.Writer.Kind == "valid" && initial.Writer.Marker.State == "free") {
		if current := remote.readWriter(); !sameWriterObservation(initial.Writer, current) {
			return errors.New("lib publish: writer changed before auto-claim; retry")
		}
		claim := libraryflow.ClaimWriter(installation.SeatID, installation.SeatLabel, time.Now(), markerIfValid(initial.Writer))
		if err := writeAndVerifyWriter(remote, claim); err != nil {
			return fmt.Errorf("lib publish: auto-claim writer: %w", err)
		}
		claimedByAttempt = true
		expectedWriter = remote.readWriter()
	}
	if expectedWriter.Kind != "valid" || expectedWriter.Marker.State != "claimed" || expectedWriter.Marker.SeatID != installation.SeatID {
		return errors.New("lib publish: writer revalidation failed")
	}
	noOpCandidate := bound.Scope == calibre.GenerationChangeScopeExact && initial.Committed && initial.SourceFingerprint == candidate.SourceFingerprint && candidate.Change != nil &&
		candidate.Change.Scope == calibre.GenerationChangeScopeExact && len(candidate.Change.Changes) == 0 &&
		len(bound.ForcePaths) == 0 && len(privateTargets) == 0 && !bound.CompleteOverwrite &&
		initial.Pointer.Library == pointer.Library && initial.Pointer.Index == pointer.Index &&
		candidate.Change.FromGeneration == hex.EncodeToString(initial.GenerationRaw) &&
		candidate.Change.FromCatalogChecksum == initial.Pointer.CatalogChecksum &&
		candidate.Change.ToCatalogChecksum == initial.Pointer.CatalogChecksum
	indexRepair := false
	if noOpCandidate {
		// A no-op is safe only when the bytes named by the current pointer are
		// really the bytes this build produced. SizeOnly can retain a stale
		// same-size index, so pointer/source equality alone is insufficient.
		if err := verifyLocalPublishCandidate(candidate); err != nil {
			return fmt.Errorf("lib publish: local library changed after it was built; run `accorder lib build` again: %w", err)
		}
		derivedMatch, err := remoteDerivedPublicationMatches(candidate, remote)
		if err != nil {
			return fmt.Errorf("lib publish: verify the published library index before declaring it current: %w", err)
		}
		if !derivedMatch {
			fmt.Fprintln(os.Stderr, "lib publish: the published library index does not match this build; publishing a corrected copy as a new generation")
			indexRepair = true
		} else {
			if err := calibre.WritePointerDocument(pointerPath, initial.Pointer); err != nil {
				return fmt.Errorf("lib publish: restore local library-index metadata: %w", err)
			}
			if err := atomicWriteFile(filepath.Join(candidate.Root, libraryflow.GenerationPath), initial.GenerationRaw, 0o644); err != nil {
				return fmt.Errorf("lib publish: restore local publication marker: %w", err)
			}
			// Deliberately not "completed = true": nothing was published, so a
			// writer this attempt auto-claimed (claimedByAttempt) because the seat
			// was free must still be released by the deferred cleanup above rather
			// than left claimed forever by a no-op check.
			fmt.Printf("Already published generation %d: no source or catalog changes.\n", initial.Generation)
			return nil
		}
	}
	changeCount := 0
	if candidate.Change != nil {
		changeCount = len(candidate.Change.Changes)
	}
	if indexRepair {
		fmt.Fprintln(os.Stderr, "lib publish: no book files changed; the server will refresh only the cache directories affected by the corrected index")
	} else if bound.Scope == calibre.GenerationChangeScopeExact {
		fmt.Fprintf(os.Stderr, "lib publish: publishing an update for %d changed %s; the server will refresh only the affected cache directories\n",
			changeCount, plural(changeCount, "book", "books"))
	} else {
		fmt.Fprintf(os.Stderr, "lib publish: an exact changed-book list is unavailable, so the server will refresh this library's whole cache (%s)\n",
			generationChangeReasonDetails(bound.Reason))
	}
	if forced := len(bound.ForcePaths); forced > 0 {
		fmt.Fprintf(os.Stderr, "lib publish: %d changed %s will be uploaded again even if the file size is unchanged\n",
			forced, plural(forced, "file", "files"))
	}
	if bound.CompleteOverwrite {
		fmt.Fprintln(os.Stderr, "lib publish: full library re-upload authorized; every public library file will be uploaded again")
	}
	pointer, err = calibre.BindPointerCommit(pointer, candidate.SourceFingerprint, nextGeneration)
	if err != nil {
		return fmt.Errorf("lib publish: prepare library-index metadata: %w", err)
	}
	if bound.CatalogChecksum != "" {
		pointer.CatalogChecksum = bound.CatalogChecksum
	}
	pointerRaw, err := json.MarshalIndent(pointer, "", "  ")
	if err != nil {
		return fmt.Errorf("lib publish: prepare library-index metadata: %w", err)
	}
	contentLedgerVersion := 0
	if candidate.Change != nil {
		contentLedgerVersion = candidate.Change.ContentLedgerVersion
	}
	recovery := publishRecoveryRecord{
		Version: machineStateVersion, Alias: alias, LibraryID: libraryID,
		SourceFingerprint: candidate.SourceFingerprint, Generation: nextGeneration,
		GenerationToken: hex.EncodeToString(committedGeneration), CatalogChecksum: bound.CatalogChecksum,
		ManifestPath: bound.ManifestPath, Manifest: bound.ManifestBytes, Pointer: pointerRaw,
		ContentLedgerVersion: contentLedgerVersion, ContentLedger: bound.ContentLedger,
		Excludes:        append([]string(nil), candidate.Excludes...),
		PreviousPointer: append([]byte(nil), initial.PointerRaw...),
	}
	for _, object := range privateTargets {
		recovery.PrivateCleanupTargets = append(recovery.PrivateCleanupTargets, object.Path)
	}
	if len(initial.GenerationRaw) > 0 {
		recovery.PreviousGenerationToken = hex.EncodeToString(initial.GenerationRaw)
	}
	if contentLedgerVersion == sourceEvidenceVersion {
		recovery.Version = sourceEvidenceVersion
		recovery.Evidence = candidate.Change.Evidence
		recovery.IndexArtifact = candidate.Change.IndexArtifact
	}

	if publishBeforeExecuteHook != nil {
		if err := publishBeforeExecuteHook(remote); err != nil {
			return fmt.Errorf("lib publish: before-execute hook: %w", err)
		}
	}
	if err := writeRecoveryStage(alias, recovery, "prepared"); err != nil {
		return fmt.Errorf("lib publish: save information needed to resume an interrupted publish: %w", err)
	}
	if err := runPublishCommitStageHook("before-mirror"); err != nil {
		return fmt.Errorf("lib publish: before-mirror hook: %w", err)
	}
	if err := verifyLocalPublishCandidate(candidate); err != nil {
		return err
	}
	if _, err := requirePublishWriter(remote, expectedWriter, installation.SeatID); err != nil {
		return err
	}
	if current := remote.commitState(); !sameRemoteApproval(initial, current) {
		return errors.New("remote library changed before transfer; retry")
	}
	transferStarted = true
	if err := runLibrarySync("Publishing library:", candidate.Root, remote.fsPath, excludes, syncOptions); err != nil {
		return fmt.Errorf("lib publish: %w", err)
	}
	if err := writeRecoveryStage(alias, recovery, "mirror-complete"); err != nil {
		return fmt.Errorf("lib publish: save recovery progress after uploading the library: %w", err)
	}
	if err := runPublishCommitStageHook("after-mirror"); err != nil {
		return fmt.Errorf("lib publish: after-mirror hook: %w", err)
	}
	if err := executeTransferCorrectness(candidate, remote, bound, excludes); err != nil {
		return fmt.Errorf("lib publish: upload files that must be replaced: %w", err)
	}
	if err := verifyLocalPublishCandidate(candidate); err != nil {
		return fmt.Errorf("lib publish: %w", err)
	}

	writerAfterTransfer, err := requirePublishWriter(remote, expectedWriter, installation.SeatID)
	if err != nil {
		return fmt.Errorf("lib publish: %w", err)
	}
	if len(privateTargets) > 0 {
		if err := runPublishCommitStageHook("before-private-cleanup"); err != nil {
			return err
		}
		if err := verifyLocalPublishCandidate(candidate); err != nil {
			return err
		}
		if _, err := requirePublishWriter(remote, expectedWriter, installation.SeatID); err != nil {
			return err
		}
		if current := remote.commitState(); !sameRemoteApproval(initial, current) {
			return errors.New("remote library changed before private cleanup; retry")
		}
		if err := writeRecoveryStage(alias, recovery, "private-cleanup"); err != nil {
			return err
		}
		if err := executePrivateCleanup(remote, privateDirs, recovery.PrivateCleanupTargets, len(privateTargets), func() error {
			if _, err := requirePublishWriter(remote, expectedWriter, installation.SeatID); err != nil {
				return err
			}
			return requireRemoteCommitBytes(remote, initial.PointerRaw, initial.GenerationRaw)
		}); err != nil {
			return err
		}
	}
	// Never discover additional deletion targets after transfer. If new private
	// objects appeared, fail before activation and plan a bounded retry instead.
	remainingPrivate, err := planPrivateCleanup(remote, privateDirs)
	if err != nil {
		return err
	}
	if len(remainingPrivate) != 0 {
		return errors.New("lib publish: private files remain on the remote; the update was not activated; retry publishing")
	}
	if err := runPublishCommitStageHook("after-private-cleanup"); err != nil {
		return err
	}
	if err := writeRecoveryStage(alias, recovery, "payload-complete"); err != nil {
		return fmt.Errorf("lib publish: save recovery progress after uploading changed files: %w", err)
	}
	if err := runPublishCommitStageHook("before-manifest"); err != nil {
		return fmt.Errorf("lib publish: before-manifest hook: %w", err)
	}
	if err := verifyLocalPublishCandidate(candidate); err != nil {
		return err
	}
	if _, err := requirePublishWriter(remote, expectedWriter, installation.SeatID); err != nil {
		return fmt.Errorf("lib publish: %w", err)
	}
	if err := requireRemoteCommitBytes(remote, initial.PointerRaw, initial.GenerationRaw); err != nil {
		return err
	}
	if err := createGenerationChangeManifest(remote, bound); err != nil {
		return fmt.Errorf("lib publish: publish the changed-book record: %w", err)
	}
	if err := runPublishCommitStageHook("after-manifest"); err != nil {
		return fmt.Errorf("lib publish: after-manifest hook: %w", err)
	}
	if err := writeRecoveryStage(alias, recovery, "manifest-complete"); err != nil {
		return fmt.Errorf("lib publish: save recovery progress after publishing the changed-book record: %w", err)
	}
	if err := runPublishCommitStageHook("before-pointer"); err != nil {
		return fmt.Errorf("lib publish: before-pointer hook: %w", err)
	}
	if _, err := requirePublishWriter(remote, expectedWriter, installation.SeatID); err != nil {
		return fmt.Errorf("lib publish: %w", err)
	}
	if err := calibre.WritePointerDocument(pointerPath, pointer); err != nil {
		return fmt.Errorf("lib publish: save local library-index metadata: %w", err)
	}
	if err := requireRemoteCommitBytes(remote, initial.PointerRaw, initial.GenerationRaw); err != nil {
		return err
	}
	if err := remote.write(memberPointerPath, pointerRaw); err != nil {
		return fmt.Errorf("lib publish: upload library-index metadata: %w", err)
	}
	if err := runPublishCommitStageHook("after-pointer"); err != nil {
		return fmt.Errorf("lib publish: after-pointer hook: %w", err)
	}
	if err := writeRecoveryStage(alias, recovery, "pointer-complete"); err != nil {
		return fmt.Errorf("lib publish: save recovery progress after uploading library-index metadata: %w", err)
	}
	if err := runPublishCommitStageHook("before-sentinel"); err != nil {
		return fmt.Errorf("lib publish: before-sentinel hook: %w", err)
	}
	if err := verifyLocalPublishCandidate(candidate); err != nil {
		return fmt.Errorf("lib publish: confirm the local library did not change during publication: %w", err)
	}
	if _, err := requirePublishWriter(remote, expectedWriter, installation.SeatID); err != nil {
		return fmt.Errorf("lib publish: %w", err)
	}
	if err := requireRemoteCommitBytes(remote, pointerRaw, initial.GenerationRaw); err != nil {
		return err
	}
	if err := remote.write(libraryflow.GenerationPath, committedGeneration); err != nil {
		return fmt.Errorf("lib publish: activate the new remote publication: %w", err)
	}
	if err := runPublishCommitStageHook("after-sentinel"); err != nil {
		return fmt.Errorf("lib publish: after-sentinel hook: %w", err)
	}
	if err := writeRecoveryStage(alias, recovery, "committed"); err != nil {
		return fmt.Errorf("lib publish: the new remote publication is active, but saving local recovery progress failed: %w", err)
	}
	writerAfterTransfer, err = requirePublishWriter(remote, expectedWriter, installation.SeatID)
	if err != nil {
		return fmt.Errorf("lib publish: the new remote publication is active, but Accorder could not confirm publishing access before saving local state: %w", err)
	}
	now := time.Now().UTC()
	publishedWriter := writerAfterTransfer.Marker
	publishedWriter.PublishedAt = &now
	if err := writeAndVerifyWriter(remote, publishedWriter); err != nil {
		return fmt.Errorf("lib publish: the new remote publication is active, but updating its publishing-access timestamp failed: %w", err)
	}
	if err := saveBaseline(alias, libraryBaseline{
		Evidence:  recovery.Evidence,
		LibraryID: libraryID, RemoteSourceFingerprint: candidate.SourceFingerprint,
		LocalSourceFingerprint: candidate.SourceFingerprint, Generation: nextGeneration,
		GenerationToken: hex.EncodeToString(committedGeneration), CatalogChecksum: bound.CatalogChecksum,
		ContentLedgerVersion: contentLedgerVersion, ContentLedger: bound.ContentLedger, UpdatedAt: now,
	}); err != nil {
		return fmt.Errorf("lib publish: the new remote publication is active, but saving local publish history failed: %w", err)
	}
	if err := runPublishCommitStageHook("after-baseline"); err != nil {
		return fmt.Errorf("lib publish: after-baseline hook: %w", err)
	}
	completed = true

	// The build stamped the pre-commit generation into the library, so write
	// the committed bytes or the library disagrees with the bucket it just
	// published to. Reported and not returned — the publish did happen.
	if err := atomicWriteFile(filepath.Join(candidate.Root, libraryflow.GenerationPath), committedGeneration, 0o644); err != nil {
		return fmt.Errorf("lib publish: publication succeeded, but saving its active version in %s failed; recovery was retained: %w", candidate.Root, err)
	}
	if err := removeStateFile(publishRecoveryPath(alias)); err != nil {
		return fmt.Errorf("lib publish: publication succeeded, but clearing saved recovery information failed: %w", err)
	}
	fmt.Printf("Published generation %d: %d published books.\n", nextGeneration, pointer.Index.NumBooks)
	return nil
}

// sameRemoteApproval compares two observations of the same kind. The inventory
// token participates only when both came from inspect(); commitState() does not
// enumerate the bucket, so between two of those the clause is inert by
// construction rather than by accident. Never mix the two kinds in one call —
// a populated token against an empty one reads as "the remote changed".
func sameRemoteApproval(before, after remoteLibrarySnapshot) bool {
	return before.Committed == after.Committed && before.Legacy == after.Legacy &&
		bytes.Equal(before.PointerRaw, after.PointerRaw) && bytes.Equal(before.GenerationRaw, after.GenerationRaw) &&
		before.InventoryToken == after.InventoryToken && before.SourceFingerprint == after.SourceFingerprint
}

func sameWriterObservation(a, b remoteWriterState) bool {
	if a.Kind != b.Kind {
		return false
	}
	switch a.Kind {
	case "absent":
		return true
	case "valid", "invalid":
		return bytes.Equal(a.Raw, b.Raw)
	case "unreadable":
		return a.Err != nil && b.Err != nil && a.Err.Error() == b.Err.Error()
	default:
		return false
	}
}

func recoverPublishBookkeeping(alias, libraryID string, remote *libraryRemote, localRoot string, options publishOptions) (bool, error) {
	if options.MaxDeletes < 0 {
		return false, errors.New("--max-deletes cannot be negative")
	}
	var record publishRecoveryRecord
	recoveryPath := publishRecoveryPath(alias)
	err := readJSONFile(recoveryPath, &record)
	if os.IsNotExist(err) {
		return false, nil
	}
	if err != nil {
		return false, err
	}
	if recoveryPath == evidenceStatePath(legacyPublishRecoveryPath(alias)) && record.Version != sourceEvidenceVersion {
		return false, errors.New("interrupted publish retained for reconciliation: unsupported version in the new recovery file")
	}
	drop := func(reason string) (bool, error) {
		if record.Version >= sourceEvidenceVersion {
			return false, fmt.Errorf("interrupted publish retained for reconciliation: %s", reason)
		}
		fmt.Fprintf(os.Stderr, "lib publish: discarded unfinished state from an earlier publish: %s\n", reason)
		return false, removeStateFile(publishRecoveryPath(alias))
	}
	if (record.Version != machineStateVersion && (record.Version != sourceEvidenceVersion || record.Evidence == nil)) || record.Alias != alias || record.LibraryID != libraryID || record.SourceFingerprint == "" || record.Generation == 0 {
		return drop("the saved recovery information is unreadable")
	}
	if options.FinishInterruptedPublish && !canFinishUploadedCleanup(record) {
		return false, errors.New("--finish-interrupted-publish is only available after an interrupted private-file cleanup has finished uploading its snapshot; saved recovery was retained")
	}
	if record.Version == sourceEvidenceVersion {
		if err := checkLegacyEvidence(legacyPublishRecoveryPath(alias), record.LegacyDigest); err != nil {
			return false, err
		}
		if record.Stage == "prepared" || record.Stage == "mirror-complete" {
			return false, removeStateFile(publishRecoveryPath(alias))
		}
	}
	installation, err := loadInstallation()
	if err != nil {
		if os.IsNotExist(err) {
			return drop("this Accorder installation no longer has the same identity")
		}
		return false, err
	}
	writer := remote.readWriter()
	if writer.Kind != "valid" || writer.Marker.State != "claimed" || writer.Marker.SeatID != installation.SeatID {
		return drop("this machine no longer owns publishing access")
	}

	// Compatibility with recovery files written before generation manifests:
	// they can only finish bookkeeping after an already complete commit.
	if record.GenerationToken == "" || record.Stage == "" {
		snapshot := remote.commitState()
		if snapshot.Err != nil || !snapshot.Committed || snapshot.SourceFingerprint != record.SourceFingerprint || snapshot.Generation != record.Generation || snapshot.Pointer.Library.UUID != record.LibraryID {
			return drop("the remote library has changed since that publish")
		}
		now := time.Now().UTC()
		writer.Marker.PublishedAt = &now
		if err := writeAndVerifyWriter(remote, writer.Marker); err != nil {
			return false, err
		}
		if err := saveBaseline(alias, libraryBaseline{
			LibraryID: record.LibraryID, RemoteSourceFingerprint: record.SourceFingerprint,
			LocalSourceFingerprint: record.SourceFingerprint, Generation: record.Generation, UpdatedAt: now,
		}); err != nil {
			return false, err
		}
		return true, removeStateFile(publishRecoveryPath(alias))
	}

	if record.Stage != "private-cleanup" && record.Stage != "payload-complete" && record.Stage != "manifest-complete" && record.Stage != "pointer-complete" && record.Stage != "committed" {
		return drop("the earlier publish stopped before changing the active remote version")
	}
	if (record.ManifestPath == "") != (len(record.Manifest) == 0) {
		return false, errors.New("saved recovery information has an incomplete changed-book record")
	}
	if record.ManifestPath != "" && record.ManifestPath != generationChangeManifestPath(record.GenerationToken) {
		return false, errors.New("saved recovery information has an invalid changed-book-record path")
	}
	recoveryPointer, err := calibre.DecodePointerFile(bytes.NewReader(record.Pointer))
	if err != nil {
		return false, fmt.Errorf("read saved library-index metadata: %w", err)
	}
	if recoveryPointer.Library.UUID != record.LibraryID || recoveryPointer.SourceFingerprint != record.SourceFingerprint || recoveryPointer.Generation != record.Generation || recoveryPointer.CatalogChecksum != record.CatalogChecksum {
		return false, errors.New("saved library-index metadata does not describe this interrupted publish")
	}
	targetToken, err := hex.DecodeString(record.GenerationToken)
	if err != nil {
		return false, fmt.Errorf("read the saved target publication version: %w", err)
	}
	if _, generation, err := torshare.DecodeGeneration(targetToken); err != nil || generation != record.Generation {
		return false, errors.New("the saved target publication version is invalid")
	}
	if len(record.Manifest) > 0 {
		manifest, err := calibre.DecodeGenerationChangeManifest(record.Manifest, calibre.GenerationChangeLimits{})
		if err != nil {
			return false, err
		}
		if manifest.LibraryUUID != record.LibraryID || manifest.ToGeneration != record.GenerationToken || manifest.TargetSourceFingerprint != record.SourceFingerprint || manifest.ToCatalogChecksum != record.CatalogChecksum {
			return false, errors.New("the saved changed-book record does not describe this interrupted publish")
		}
	}
	if record.Stage == "private-cleanup" {
		// Transfer correctness finished before this durable stage. Resume only
		// the originally approved deletions, retaining even an empty plan's
		// obligation to publish the cache-refresh generation.
		if err := verifyPublishRecoverySource(localRoot, record, options); err != nil {
			return false, err
		}
		snapshot := remote.commitState()
		if snapshot.Err != nil || (record.PreviousGenerationToken == "" && !remoteSnapshotEmpty(snapshot)) ||
			(record.PreviousGenerationToken != "" && hex.EncodeToString(snapshot.GenerationRaw) != record.PreviousGenerationToken) {
			return false, errors.New("remote library changed before recovering private cleanup")
		}
		dirs, err := privateCleanupDirs(record.Excludes)
		if err != nil {
			return false, err
		}
		previousToken, err := hex.DecodeString(record.PreviousGenerationToken)
		if err != nil {
			return false, err
		}
		if err := executePrivateCleanup(remote, dirs, record.PrivateCleanupTargets, options.MaxDeletes, func() error {
			if _, err := requirePublishWriter(remote, writer, installation.SeatID); err != nil {
				return err
			}
			return requireRemoteCommitBytes(remote, record.PreviousPointer, previousToken)
		}); err != nil {
			return false, err
		}
		remaining, err := planPrivateCleanup(remote, dirs)
		if err != nil || len(remaining) != 0 {
			return false, fmt.Errorf("private cleanup changed during recovery; saved publication retained for reconciliation: remaining=%d, error=%v", len(remaining), err)
		}
		if err := writeRecoveryStage(alias, record, "payload-complete"); err != nil {
			return false, err
		}
		record.Stage = "payload-complete"
	}
	if record.Stage == "payload-complete" {
		// The immutable create happens immediately before the durable stage is
		// advanced. A crash in that interval leaves payload-complete behind even
		// though the generation key now exists. Replaying the recorded bytes is
		// idempotent: it accepts an existing byte-for-byte match and rejects a
		// conflicting object without overwriting it.
		if err := runPublishCommitStageHook("recovery-before-manifest"); err != nil {
			return false, fmt.Errorf("recover before-manifest hook: %w", err)
		}
		if _, err := requirePublishWriter(remote, writer, installation.SeatID); err != nil {
			return false, err
		}
		if record.Version == sourceEvidenceVersion {
			if err := verifyPublishRecoverySource(localRoot, record, options); err != nil {
				return false, err
			}
		}
		if len(record.PrivateCleanupTargets) > 0 {
			previousToken, err := hex.DecodeString(record.PreviousGenerationToken)
			if err != nil {
				return false, err
			}
			if err := requireRemoteCommitBytes(remote, record.PreviousPointer, previousToken); err != nil {
				return false, err
			}
		}
		if err := createGenerationChangeManifest(remote, boundGenerationPublication{
			ManifestPath: record.ManifestPath, ManifestBytes: record.Manifest,
		}); err != nil {
			return false, fmt.Errorf("restore the changed-book record: %w", err)
		}
		if err := writeRecoveryStage(alias, record, "manifest-complete"); err != nil {
			return false, err
		}
		record.Stage = "manifest-complete"
	}
	if err := recoveryManifestMatches(remote, record); err != nil {
		return false, err
	}
	remotePointer, present, err := readOptionalRemote(remote, memberPointerPath, 4<<20)
	if err != nil {
		return false, err
	}
	if !present || !bytes.Equal(remotePointer, record.Pointer) {
		if record.Stage == "manifest-complete" {
			snapshot := remote.commitState()
			predecessor := (snapshot.Committed || snapshot.Legacy) && record.PreviousGenerationToken != "" &&
				hex.EncodeToString(snapshot.GenerationRaw) == record.PreviousGenerationToken
			if remoteSnapshotEmpty(snapshot) || predecessor {
				if _, err := requirePublishWriter(remote, writer, installation.SeatID); err != nil {
					return false, err
				}
				if err := requireRemoteCommitBytes(remote, snapshot.PointerRaw, snapshot.GenerationRaw); err != nil {
					return false, err
				}
				if err := remote.write(memberPointerPath, record.Pointer); err != nil {
					return false, fmt.Errorf("restore the published library-index metadata: %w", err)
				}
				if err := writeRecoveryStage(alias, record, "pointer-complete"); err != nil {
					return false, err
				}
				record.Stage = "pointer-complete"
				remotePointer = record.Pointer
				present = true
			}
		}
		if !present || !bytes.Equal(remotePointer, record.Pointer) {
			return false, errors.New("the remote library changed since the interrupted publish")
		}
	}
	remoteGeneration, generationPresent, err := readOptionalRemote(remote, libraryflow.GenerationPath, 1<<20)
	if err != nil {
		return false, err
	}
	if !generationPresent || !bytes.Equal(remoteGeneration, targetToken) {
		if record.Stage == "committed" {
			return false, errors.New("the remote active version differs from the completed publish recorded locally")
		}
		if record.PreviousGenerationToken == "" {
			if generationPresent {
				return false, errors.New("a remote library appeared after the interrupted first publish")
			}
		} else if !generationPresent || hex.EncodeToString(remoteGeneration) != record.PreviousGenerationToken {
			return false, errors.New("the remote library is at an unexpected version for this interrupted publish")
		}
		if record.Version == sourceEvidenceVersion {
			if err := verifyPublishRecoverySource(localRoot, record, options); err != nil {
				return false, err
			}
		}
		if _, err := requirePublishWriter(remote, writer, installation.SeatID); err != nil {
			return false, err
		}
		if err := requireRemoteCommitBytes(remote, record.Pointer, remoteGeneration); err != nil {
			return false, err
		}
		if err := remote.write(libraryflow.GenerationPath, targetToken); err != nil {
			return false, err
		}
		if err := writeRecoveryStage(alias, record, "committed"); err != nil {
			return false, err
		}
	}
	now := time.Now().UTC()
	writer.Marker.PublishedAt = &now
	if err := writeAndVerifyWriter(remote, writer.Marker); err != nil {
		return false, err
	}
	if err := saveBaseline(alias, libraryBaseline{
		Evidence:  record.Evidence,
		LibraryID: record.LibraryID, RemoteSourceFingerprint: record.SourceFingerprint,
		LocalSourceFingerprint: record.SourceFingerprint, Generation: record.Generation,
		GenerationToken: record.GenerationToken, CatalogChecksum: record.CatalogChecksum,
		ContentLedgerVersion: record.ContentLedgerVersion, ContentLedger: record.ContentLedger,
		UpdatedAt: now,
	}); err != nil {
		return false, err
	}
	if err := calibre.WritePointerDocument(filepath.Join(localRoot, filepath.FromSlash(memberPointerPath)), recoveryPointer); err != nil {
		return false, err
	}
	if err := atomicWriteFile(filepath.Join(localRoot, libraryflow.GenerationPath), targetToken, 0o644); err != nil {
		return false, err
	}
	return true, removeStateFile(publishRecoveryPath(alias))
}
