package cmd

import (
	"accorder/pkg/calibre"
	"path/filepath"
	"strings"
	"testing"
)

// The serve daemon's rebuild path (NoMonolithicRebuild) must NEVER fall through to the
// monolithic full-rebuild: when splice cannot compose, it returns a "stay on last-good
// aggregate" error instead of materializing all books in process (the ~3.2 GB OOM path
// that killed the serving box). Monolithic remains available to an explicit operator
// build (NoMonolithicRebuild == false).
func TestFedlibBuild_NoMonolithicRebuild_NoFallback(t *testing.T) {
	dir := t.TempDir()
	// One active local member whose index does not exist → splice cannot compose,
	// so the build reaches the post-splice fork.
	reg := map[string]calibre.LibraryMeta{
		"uuid1": {
			Librarian: "alice", Prefix: "alice", Kind: "local", State: "ready",
			LocalPath: filepath.Join(dir, "missing-member"), DictID: 2,
		},
	}
	if err := saveMembersRegistry(filepath.Join(dir, "members.json"), reg); err != nil {
		t.Fatal(err)
	}
	skip := true

	bounded := &FedlibBuildCmd{OutputPath: dir, NoMonolithicRebuild: true, SkipUpload: &skip}
	bounded.ActionAlias = "test"
	if err := bounded.Run(); err == nil || !strings.Contains(err.Error(), "no-monolithic-rebuild") {
		t.Fatalf("no-monolithic mode: want a stay-on-last-good error, got %v", err)
	}

	// Same setup WITHOUT the guard must not hit that gate — the operator path is
	// allowed to take the monolithic / empty-bootstrap build.
	open := &FedlibBuildCmd{OutputPath: dir, SkipUpload: &skip}
	open.ActionAlias = "test"
	if err := open.Run(); err != nil && strings.Contains(err.Error(), "no-monolithic-rebuild") {
		t.Fatalf("operator mode: must not hit the no-monolithic-rebuild gate, got %v", err)
	}
}

// The daemon's in-process rebuild runs inside the serving process, so by default it must
// refuse the monolithic full-rebuild (no monolithic in that address space).
func TestInProcessBuildCmd_RefusesMonolithicByDefault(t *testing.T) {
	if cmd := inProcessBuildCmd(testServeParams(), "remote:bucket"); !cmd.NoMonolithicRebuild {
		t.Fatal("in-process daemon build must set NoMonolithicRebuild by default")
	}
}

// An operator with a roomy aggregator can opt the daemon into full rebuilds via
// --allow-full-rebuild; the in-process build then permits the monolithic path.
func TestInProcessBuildCmd_AllowFullRebuildOptsOut(t *testing.T) {
	p := testServeParams()
	p.AllowFullRebuild = true
	if cmd := inProcessBuildCmd(p, "remote:bucket"); cmd.NoMonolithicRebuild {
		t.Fatal("with --allow-full-rebuild, in-process build must NOT set NoMonolithicRebuild")
	}
}
