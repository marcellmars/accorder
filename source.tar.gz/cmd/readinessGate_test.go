package cmd

import (
	"net/http"
	"net/http/httptest"
	"sync"
	"testing"
)

func TestReadinessGate_ServesWarmingUntilReady(t *testing.T) {
	var g readinessGate

	if g.isReady() {
		t.Fatal("zero-value gate reports ready")
	}

	rec := httptest.NewRecorder()
	g.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/books", nil))

	if rec.Code != http.StatusServiceUnavailable {
		t.Errorf("warming status = %d, want %d", rec.Code, http.StatusServiceUnavailable)
	}
	if got := rec.Header().Get("Retry-After"); got != warmingRetryAfter {
		t.Errorf("Retry-After = %q, want %q", got, warmingRetryAfter)
	}

	mux := http.NewServeMux()
	mux.HandleFunc("/books", func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusTeapot)
	})
	g.setReady(mux)

	if !g.isReady() {
		t.Fatal("gate not ready after setReady")
	}

	rec = httptest.NewRecorder()
	g.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/books", nil))
	if rec.Code != http.StatusTeapot {
		t.Errorf("post-ready status = %d, want %d (real mux should handle it)", rec.Code, http.StatusTeapot)
	}
}

// TestReadinessGate_WarmingAppliesToEveryPath guards the decision that /info is
// NOT special-cased during warm-up: makeInfoHandler closes over aggregate state
// that does not exist yet, so it cannot answer early.
func TestReadinessGate_WarmingAppliesToEveryPath(t *testing.T) {
	var g readinessGate
	for _, path := range []string{"/", "/info", "/books", "/search?q=x", "/files/x/y.epub"} {
		rec := httptest.NewRecorder()
		g.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, path, nil))
		if rec.Code != http.StatusServiceUnavailable {
			t.Errorf("%s: status = %d, want %d", path, rec.Code, http.StatusServiceUnavailable)
		}
	}
}

// TestReadinessGate_ConcurrentSwap is the -race guard: readers hitting the gate
// while setReady lands must never tear or panic.
func TestReadinessGate_ConcurrentSwap(t *testing.T) {
	var g readinessGate
	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
	})

	var wg sync.WaitGroup
	for i := 0; i < 32; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for j := 0; j < 100; j++ {
				rec := httptest.NewRecorder()
				g.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/", nil))

				// Either state is valid mid-swap; only 503 or 200 may occur.
				if rec.Code != http.StatusServiceUnavailable && rec.Code != http.StatusOK {
					t.Errorf("unexpected status during swap: %d", rec.Code)
					return
				}
			}
		}()
	}
	wg.Add(1)
	go func() {
		defer wg.Done()
		g.setReady(mux)
	}()
	wg.Wait()

	if !g.isReady() {
		t.Fatal("gate not ready after concurrent swap")
	}
}
