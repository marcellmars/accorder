package cmd

import (
	"accorder/pkg/calibre"
	"testing"
)

func TestRebakeBaseURL(t *testing.T) {
	books := []*calibre.Book{
		{BaseURL: "/wrong", LibraryUrl: "/wrong/"},
		{BaseURL: "", LibraryUrl: ""},
		{BaseURL: "/files/other", LibraryUrl: "/files/other/"},
	}

	rebakeBaseURL(books, "alice")

	for i, b := range books {
		if b.BaseURL != "/files/alice" {
			t.Errorf("books[%d].BaseURL = %q, want %q", i, b.BaseURL, "/files/alice")
		}
		if b.LibraryUrl != "/files/alice/" {
			t.Errorf("books[%d].LibraryUrl = %q, want %q", i, b.LibraryUrl, "/files/alice/")
		}
	}
}

func TestRebakeBaseURL_EmptySlice(t *testing.T) {

	// Ensure no panic on empty input.
	rebakeBaseURL(nil, "alice")
	rebakeBaseURL([]*calibre.Book{}, "bob")
}
