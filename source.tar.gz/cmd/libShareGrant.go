//go:build tor

package cmd

import (
	"accorder/internal/sharegrant"
	"accorder/pkg/torshare"
	"fmt"
	"os"
	"path/filepath"

	"github.com/alecthomas/kong"
)

type LibShareGrantCmd struct {
	CommonCommandFields
	Friend string `name:"friend" help:"Friend name (omit for public invite)." validate:"omitempty,personname"`
}

func (c *LibShareGrantCmd) Run(ctx *kong.Context) error {
	if c.HandleShowConfig(c) {
		return nil
	}

	stateDir := torshare.StateDir(accorderConfigDir, c.ActionAlias)
	// offline-private serves a dual onion; grant against the index onion (the
	// gated plane) only when the serve's .serve-dual marker is set — a stale index/
	// dir from a prior offline-private run must not redirect a single-onion grant.
	if _, idxErr := os.Stat(filepath.Join(stateDir, ".serve-dual")); idxErr == nil {
		stateDir = filepath.Join(stateDir, "index")
	}

	publicSentinel := filepath.Join(stateDir, ".public")
	_, statErr := os.Stat(publicSentinel)
	isPublic := statErr == nil

	if c.Friend == "" && !isPublic {
		return fmt.Errorf("share-grant: per-library alias is not in public mode " +
			"(no .public sentinel); pass --friend NAME or restart 'lib share live --mode public'")
	}
	if c.Friend != "" && isPublic {
		return fmt.Errorf("share-grant: 'lib share live' was started with --mode public; " +
			"remove the .public sentinel and restart 'lib share live' in a non-public mode to enable per-friend auth")
	}

	result, err := sharegrant.Grant(stateDir, c.Friend, c.ActionAlias, "per_library")
	if err != nil {
		return fmt.Errorf("share-grant: %w", err)
	}
	fmt.Fprintln(os.Stderr, result.Message)
	fmt.Println(result.InviteBlob)
	return nil
}
