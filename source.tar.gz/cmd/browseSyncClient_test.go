package cmd

import (
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"
)

func announceProbe(t *testing.T) (*httptest.Server, *http.Header) {
	t.Helper()
	var last http.Header
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		last = r.Header.Clone()
		w.WriteHeader(http.StatusOK)
	}))
	t.Cleanup(srv.Close)
	return srv, &last
}

func TestAnnounceNonce_PresentAndStable(t *testing.T) {
	srv, last := announceProbe(t)
	u, _ := url.Parse(srv.URL)
	client := newBrowseClearnetHTTPClient("", u.Host)

	get := func() string {
		resp, err := client.Get(srv.URL + "/files/x.epub")
		if err != nil {
			t.Fatal(err)
		}
		resp.Body.Close()
		return last.Get("X-Accorder-Client")
	}
	v := get()
	if !strings.Contains(v, " r=") {
		t.Fatalf("announce header must carry a per-run nonce, got %q", v)
	}
	if v2 := get(); v != v2 {
		t.Fatalf("nonce must be stable within a run: %q vs %q", v, v2)
	}
}

func TestAnnounceTransport_MatchedHost(t *testing.T) {
	srv, last := announceProbe(t)
	u, _ := url.Parse(srv.URL)

	client := newBrowseClearnetHTTPClient("", u.Host)
	resp, err := client.Get(srv.URL + "/files/x.epub")
	if err != nil {
		t.Fatal(err)
	}
	resp.Body.Close()

	got := last.Get("X-Accorder-Client")
	if !strings.HasPrefix(got, "lib-browse/") {
		t.Fatalf("expected lib-browse/<version> announce header, got %q", got)
	}
	if last.Get("Authorization") != "" {
		t.Fatalf("tokenless client must not send Authorization, got %q", last.Get("Authorization"))
	}
}

func TestAnnounceTransport_ForeignHostNoHeader(t *testing.T) {
	srv, last := announceProbe(t)

	client := newBrowseClearnetHTTPClient("", "other.example:443")
	resp, err := client.Get(srv.URL + "/files/x.epub")
	if err != nil {
		t.Fatal(err)
	}
	resp.Body.Close()

	if got := last.Get("X-Accorder-Client"); got != "" {
		t.Fatalf("announce header leaked to foreign host: %q", got)
	}
}

func TestAnnounceTransport_ComposesWithBearer(t *testing.T) {
	srv, last := announceProbe(t)
	u, _ := url.Parse(srv.URL)

	client := newBrowseClearnetHTTPClient("tok123", u.Host)
	resp, err := client.Get(srv.URL + "/files/x.epub")
	if err != nil {
		t.Fatal(err)
	}
	resp.Body.Close()

	if got := last.Get("Authorization"); got != "Bearer tok123" {
		t.Fatalf("expected bearer to survive composition, got %q", got)
	}
	if got := last.Get("X-Accorder-Client"); !strings.HasPrefix(got, "lib-browse/") {
		t.Fatalf("expected announce header alongside bearer, got %q", got)
	}
}
