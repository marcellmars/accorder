package cmd

import (
	"os"
	"path/filepath"
	"testing"
)

func seedDict(t *testing.T, name string) string {
	t.Helper()
	path := filepath.Join(accorderCacheDir(), name)
	if err := os.MkdirAll(accorderCacheDir(), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(path, []byte("dictbytes"), 0o600); err != nil {
		t.Fatal(err)
	}
	return path
}

func ledgerDictWrite(t *testing.T, name string) {
	t.Helper()
	if err := withGCLock(func() error {
		return appendLedgerRecord(ledgerRecord{Type: "dict-write", DictFile: name, Cmd: "test"})
	}); err != nil {
		t.Fatal(err)
	}
}

func fileExists(path string) bool {
	_, err := os.Stat(path)
	return err == nil
}

func TestDictReaper_PreActivationReapsNothing(t *testing.T) {
	testSetup(t)
	stale := seedDict(t, "aaaa-1.dict")
	ledgerDictWrite(t, "aaaa-1.dict")
	tmp := seedDict(t, "typeahead-x.dict.tmp")

	reapStaleDicts(accorderCacheDir())
	if !fileExists(stale) || !fileExists(tmp) {
		t.Fatal("pre-activation reap touched files")
	}
}

func TestDictReaper_LeaseHeldKeptLedgeredUnreferencedReaped(t *testing.T) {
	testSetup(t)
	activateReclaim(t)

	held := seedDict(t, "held-1.dict")
	ledgerDictWrite(t, "held-1.dict")
	pending := seedDict(t, "pending-2.dict")
	ledgerDictWrite(t, "pending-2.dict")
	stale := seedDict(t, "stale-3.dict")
	ledgerDictWrite(t, "stale-3.dict")
	legacy := seedDict(t, "legacy-4.dict") // unledgered
	tmp := seedDict(t, "typeahead-x.dict.tmp")

	lease, err := acquireServeLease("test-serve")
	if err != nil {
		t.Fatal(err)
	}
	defer lease.Release()
	if err := withGCLock(func() error {
		if e := lease.commitPendingLocked("held-1.dict"); e != nil {
			return e
		}
		return lease.setPendingLocked("pending-2.dict")
	}); err != nil {
		t.Fatal(err)
	}

	reapStaleDicts(accorderCacheDir())

	if !fileExists(held) || !fileExists(pending) {
		t.Fatal("lease-referenced dict reaped — a live serve's dict was deleted")
	}
	if fileExists(stale) {
		t.Fatal("ledgered unreferenced dict not reaped")
	}
	if !fileExists(legacy) {
		t.Fatal("unledgered legacy dict reaped without attestation (two-flag rule violated)")
	}
	if fileExists(tmp) {
		t.Fatal("crash-stranded .dict.tmp not reaped post-activation")
	}

	// The reaped dict is tombstoned so replay stays consistent.
	records, malformed, _ := readLedger()
	if malformed {
		t.Fatal("ledger malformed after reap")
	}
	if view := replayLedger(records); view.activeDicts["stale-3.dict"] {
		t.Fatal("reaped dict not tombstoned")
	}
}

func TestDictReaper_ReleasedLeaseStateIsStale(t *testing.T) {
	testSetup(t)
	activateReclaim(t)
	stale := seedDict(t, "old-5.dict")
	ledgerDictWrite(t, "old-5.dict")

	// A lease that was held and released: its state file remains but the
	// lock is free, so its references no longer protect anything.
	lease, err := acquireServeLease("gone-serve")
	if err != nil {
		t.Fatal(err)
	}
	if err := withGCLock(func() error { return lease.commitPendingLocked("old-5.dict") }); err != nil {
		t.Fatal(err)
	}
	lease.Release()

	reapStaleDicts(accorderCacheDir())
	if fileExists(stale) {
		t.Fatal("released lease's stale state still protected a dict")
	}
}

func TestLegacyDictReap_AttestedOnly(t *testing.T) {
	testSetup(t)
	activateReclaim(t)
	legacy := seedDict(t, "legacy-9.dict")

	bytes, n := reapLegacyDictsAttested(accorderCacheDir())
	if n != 1 || bytes == 0 || fileExists(legacy) {
		t.Fatalf("attested legacy reap: n=%d bytes=%d exists=%v", n, bytes, fileExists(legacy))
	}
}

func TestServeLease_SameNameContentionFailsStartup(t *testing.T) {
	testSetup(t)
	l1, err := acquireServeLease("dup")
	if err != nil {
		t.Fatal(err)
	}
	defer l1.Release()
	if _, err := acquireServeLease("dup"); err == nil {
		t.Fatal("second lease acquisition on the same name succeeded")
	}
}

func TestMutationLock_SameRemoteContention(t *testing.T) {
	testSetup(t)
	rel, ok, err := acquireMutationLock("accorder-serve-x", "bucket")
	if err != nil || !ok {
		t.Fatal(err)
	}
	defer rel()
	_, ok2, err2 := acquireMutationLock("accorder-serve-x", "bucket")
	if err2 != nil {
		t.Fatal(err2)
	}
	if ok2 {
		t.Fatal("same-remote mutation lock acquired twice — two serves would share one cache tree")
	}
}
