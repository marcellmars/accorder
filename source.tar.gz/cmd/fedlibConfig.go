package cmd

import (
	"fmt"
	"os"
	"sort"
	"text/tabwriter"

	"github.com/goccy/go-json"
)

type FedlibConfigCmd struct {
	Set  FedlibConfigSetCmd  `cmd:"" help:"Create or update a federation descriptor."`
	Show FedlibConfigShowCmd `cmd:"" help:"Show a federation descriptor."`
	List FedlibConfigListCmd `cmd:"" help:"List federation descriptors."`
}

type FedlibConfigSetCmd struct {
	FedlibID     string `arg:"" help:"Federation identifier — a short name you choose for this federation (used by all other fedlib commands)."`
	Bucket       string `name:"bucket" help:"S3 bucket name." validate:"omitempty"`
	UploadPrefix string `name:"upload-prefix" help:"S3 prefix where the aggregate lives." validate:"omitempty"`
	S3Provider   string `name:"s3-provider" help:"S3 provider (e.g. Wasabi, AWS)." validate:"omitempty"`
	S3Endpoint   string `name:"s3-endpoint" help:"S3 endpoint URL." validate:"omitempty"`
	KeysFile     string `name:"keys-file" help:"Path to operator S3 keys-file." validate:"omitempty"`
	Mode         string `name:"mode" help:"Access mode: public (everything open), offline-private (browse open, index gated), private (everything gated)." enum:"public,offline-private,private,," default:"" validate:"omitempty"`
	Endpoint     string `name:"endpoint" help:"Public https:// base URL." validate:"omitempty,url"`
	FedlibPath   string `name:"fedlib-path" help:"Path to the fedlib output directory." validate:"omitempty"`
	OfferExpiry  string `name:"offer-expiry" help:"Default offer lifetime (e.g. 168h)." validate:"omitempty"`
}

func (c *FedlibConfigSetCmd) Run() error {
	desc := loadFedlibDescriptor(c.FedlibID)
	for _, f := range []struct {
		flag  *string
		saved *string
	}{
		{&c.Bucket, &desc.Bucket},
		{&c.UploadPrefix, &desc.UploadPrefix},
		{&c.S3Provider, &desc.S3Provider},
		{&c.S3Endpoint, &desc.S3Endpoint},
		{&c.KeysFile, &desc.KeysFile},
		{&c.Mode, &desc.Mode},
		{&c.Endpoint, &desc.Endpoint},
		{&c.FedlibPath, &desc.FedlibPath},
		{&c.OfferExpiry, &desc.OfferExpiry},
	} {
		if *f.flag != "" {
			*f.saved = *f.flag
		}
	}
	desc.Version = fedlibDescriptorVersion
	if err := saveFedlibDescriptor(c.FedlibID, desc); err != nil {
		return fmt.Errorf("fedlib config set: %w", err)
	}
	fmt.Fprintf(os.Stderr, "fedlib config: saved descriptor for %q to %s\n", c.FedlibID, fedlibDescriptorPath())
	return nil
}

type FedlibConfigShowCmd struct {
	FedlibID string `arg:"" help:"Federation identifier (see 'fedlib config set')." validate:"required"`
}

func (c *FedlibConfigShowCmd) Run() error {
	desc := loadFedlibDescriptor(c.FedlibID)
	if desc.Version == 0 {
		return fmt.Errorf("fedlib config show: no descriptor for %q", c.FedlibID)
	}
	data, err := json.MarshalIndent(desc, "", "  ")
	if err != nil {
		return fmt.Errorf("fedlib config show: %w", err)
	}
	fmt.Fprintln(os.Stdout, string(data))
	return nil
}

type FedlibConfigListCmd struct{}

func (c *FedlibConfigListCmd) Run() error {
	all := loadAllFedlibDescriptors()
	if len(all) == 0 {
		fmt.Fprintf(os.Stderr, "fedlib config: no federation descriptors in %s\n", fedlibDescriptorPath())
		return nil
	}
	ids := make([]string, 0, len(all))
	for id := range all {
		ids = append(ids, id)
	}
	sort.Strings(ids)

	w := tabwriter.NewWriter(os.Stdout, 2, 4, 2, ' ', 0)
	fmt.Fprintln(w, "FEDLIB-ID\tBUCKET\tMODE\tENDPOINT")
	for _, id := range ids {
		d := all[id]
		fmt.Fprintf(w, "%s\t%s\t%s\t%s\n", id, d.Bucket, d.Mode, d.Endpoint)
	}
	return w.Flush()
}
