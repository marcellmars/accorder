//go:build tor

package cmd

import (
	"accorder/pkg/torshare"
	"context"
)

func init() {
	startTorFn = torshare.WrapStartSupervisor
	startDualTorFn = func(ctx context.Context, browserAddr, indexAddr, alias, configDir string, dualCfg DualOnionConfig) (DualOnionResult, error) {
		tsCfg := torshare.DualOnionConfig{
			BrowserPublic: dualCfg.BrowserPublic,
			IndexPublic:   dualCfg.IndexPublic,
		}
		res, err := torshare.WrapStartDualSupervisor(ctx, browserAddr, indexAddr, alias, configDir, tsCfg)
		if err != nil {
			return DualOnionResult{}, err
		}
		return DualOnionResult{
			BrowserOnion: res.BrowserOnion,
			IndexOnion:   res.IndexOnion,
			StopFn:       res.StopFn,
		}, nil
	}
}
