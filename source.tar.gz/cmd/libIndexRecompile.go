package cmd

import (
	"accorder/pkg/calibre"
	"bufio"
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strings"

	"github.com/alecthomas/kong"
	"github.com/tidwall/gjson"
	"github.com/tidwall/sjson"
)

type LibIndexRecompileCmd struct {
	CommonCommandFields
	Descriptions *bool `name:"descriptions" help:"Include description/abstract in the search index." json:"-"`
}

var errNoDescriptions = errors.New("index has no descriptions to recompile")

const browseIndexDescriptionsKey = "index-descriptions"

func (c *LibIndexRecompileCmd) Run(ctx *kong.Context) error {
	if c.HandleShowConfig(c) {
		return nil
	}

	if c.Descriptions == nil || !*c.Descriptions {
		return fmt.Errorf("recompile: --descriptions flag is required (currently the only recompile mode)")
	}

	alias := c.ActionAlias
	if alias == "" {
		return fmt.Errorf("recompile: needs the browse action alias as a positional argument (the same one you pass to `lib browse`)")
	}

	cacheBase := filepath.Join(accorderConfigDir, "tor", "cache")

	cacheDir, err := offlineCacheDir(alias, cacheBase)
	if err != nil {
		return fmt.Errorf("recompile: no cached index for %q — browse it at least once first: %w", alias, err)
	}

	indexPath := filepath.Join(cacheDir, "static", "library_index")
	if _, serr := os.Stat(indexPath + ".zst"); os.IsNotExist(serr) {
		return fmt.Errorf("recompile: cached index not found at %s — browse %q at least once first", indexPath+".zst", alias)
	}

	log.Printf("recompile: reading index %s.zst...", indexPath)
	bookCount, err := recompileIndexWithDescriptions(indexPath)
	if errors.Is(err, errNoDescriptions) {
		return fmt.Errorf("recompile: no book in %q carries a description/abstract — the cached index likely predates description export; re-browse %q to refresh it first", alias, alias)
	}
	if err != nil {
		return fmt.Errorf("recompile: %w", err)
	}
	log.Printf("recompile: built index with descriptions (%d books)", bookCount)

	unlockAliasCfg := lockAliasConfigOrDie()
	configBytes := loadActionAliases()
	configBytes, _ = sjson.SetBytes(configBytes, alias+".lib.browse."+browseIndexDescriptionsKey, true)
	saveActionAliases(configBytes)
	unlockAliasCfg()

	log.Printf("recompile: done — index at %s.zst now has description search", indexPath)
	return nil
}

func recompileIndexWithDescriptions(indexPath string) (int, error) {
	localPath := indexPath + ".zst"

	displayJSONL, existingMf, err := calibre.FilteredDisplayJSONL(indexPath)
	if err != nil {
		return 0, fmt.Errorf("read index: %w", err)
	}

	bookCount, hasAbstract := scanJSONLAbstracts(displayJSONL)
	if !hasAbstract {
		return bookCount, errNoDescriptions
	}

	staticDir := filepath.Dir(localPath)
	jsonlTmp, err := os.CreateTemp(staticDir, "recompile-*.jsonl")
	if err != nil {
		return 0, fmt.Errorf("create temp JSONL: %w", err)
	}
	jsonlTmpPath := jsonlTmp.Name()
	defer os.Remove(jsonlTmpPath)

	if _, err := jsonlTmp.Write(displayJSONL); err != nil {
		jsonlTmp.Close()
		return 0, fmt.Errorf("write temp JSONL: %w", err)
	}
	if err := jsonlTmp.Close(); err != nil {
		return 0, fmt.Errorf("close temp JSONL: %w", err)
	}

	ms := &calibre.MotwSearch{
		JsonlPath:            jsonlTmpPath,
		IndexPath:            indexPath,
		BaseGeneration:       &existingMf.BaseGeneration,
		StartGeneration:      existingMf.Generation,
		IndexDescription:     true,
		IndexAggregateFields: true,
		ChunkSize:            int(existingMf.ChunkSize),
	}
	if len(existingMf.Regions) > 0 {
		ms.DictID = existingMf.Regions[0].DictID
	}

	if err := buildAndCompileLocal(ms, localPath); err != nil {
		return 0, err
	}
	return bookCount, nil
}

func wantsDescriptionIndex(alias string) bool {
	if alias == "" {
		return false
	}
	return gjson.GetBytes(loadActionAliases(), alias+".lib.browse.index-descriptions").Bool()
}

func scanJSONLAbstracts(jsonl []byte) (count int, hasAbstract bool) {
	scanner := bufio.NewScanner(bytes.NewReader(jsonl))
	scanner.Buffer(make([]byte, 1<<20), 1<<24)
	for scanner.Scan() {
		line := bytes.TrimSpace(scanner.Bytes())
		if len(line) == 0 {
			continue
		}
		count++
		if !hasAbstract {
			var b calibre.Book
			if err := json.Unmarshal(line, &b); err == nil && strings.TrimSpace(b.Abstract) != "" {
				hasAbstract = true
			}
		}
	}
	return count, hasAbstract
}
