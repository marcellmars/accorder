package cmd

import (
	"accorder/pkg/libraryflow"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	uuid "github.com/satori/go.uuid"
)

const machineStateVersion = 1

type libraryInstallation struct {
	Version   int    `json:"version"`
	SeatID    string `json:"seat_id"`
	SeatLabel string `json:"seat_label"`
}

type libraryBaseline struct {
	Evidence                *sourceEvidence      `json:"source_evidence,omitempty"`
	LegacyDigest            string               `json:"legacy_digest,omitempty"`
	Version                 int                  `json:"version"`
	LibraryID               string               `json:"library_id"`
	RemoteSourceFingerprint string               `json:"remote_source_fingerprint"`
	LocalSourceFingerprint  string               `json:"local_source_fingerprint"`
	Generation              uint64               `json:"generation"`
	GenerationToken         string               `json:"generation_token,omitempty"`
	CatalogChecksum         string               `json:"catalog_checksum,omitempty"`
	ContentLedgerVersion    int                  `json:"content_ledger_version,omitempty"`
	ContentLedger           []libraryflow.Object `json:"content_ledger,omitempty"`
	UpdatedAt               time.Time            `json:"updated_at"`
}

type syncActivationRecord struct {
	SourceContract          string               `json:"source_contract,omitempty"`
	StageLedger             []libraryflow.Object `json:"stage_ledger,omitempty"`
	StageEvidence           *sourceEvidence      `json:"stage_evidence,omitempty"`
	SourceExcludes          []string             `json:"source_excludes,omitempty"`
	StageRootID             string               `json:"stage_root_id,omitempty"`
	GenerationToken         string               `json:"generation_token,omitempty"`
	CatalogChecksum         string               `json:"catalog_checksum,omitempty"`
	Version                 int                  `json:"version"`
	Alias                   string               `json:"alias"`
	LibraryID               string               `json:"library_id"`
	Destination             string               `json:"destination"`
	Stage                   string               `json:"stage"`
	RetainedOldPath         string               `json:"retained_old_path,omitempty"`
	RemoteSourceFingerprint string               `json:"remote_source_fingerprint"`
	Generation              uint64               `json:"generation"`
	Baseline                *libraryBaseline     `json:"old_baseline,omitempty"`
}

type publishRecoveryRecord struct {
	PreviousPointer         []byte               `json:"previous_pointer,omitempty"`
	PrivateCleanupTargets   []string             `json:"private_cleanup_targets,omitempty"`
	IndexArtifact           libraryflow.Object   `json:"index_artifact,omitempty"`
	Excludes                []string             `json:"excludes,omitempty"`
	Evidence                *sourceEvidence      `json:"source_evidence,omitempty"`
	LegacyDigest            string               `json:"legacy_digest,omitempty"`
	Version                 int                  `json:"version"`
	Alias                   string               `json:"alias"`
	LibraryID               string               `json:"library_id"`
	SourceFingerprint       string               `json:"source_fingerprint"`
	Generation              uint64               `json:"generation"`
	GenerationToken         string               `json:"generation_token,omitempty"`
	CatalogChecksum         string               `json:"catalog_checksum,omitempty"`
	ManifestPath            string               `json:"manifest_path,omitempty"`
	Manifest                []byte               `json:"manifest,omitempty"`
	Pointer                 []byte               `json:"pointer,omitempty"`
	PreviousGenerationToken string               `json:"previous_generation_token,omitempty"`
	Stage                   string               `json:"stage,omitempty"`
	ContentLedgerVersion    int                  `json:"content_ledger_version,omitempty"`
	ContentLedger           []libraryflow.Object `json:"content_ledger,omitempty"`
}

func machineStateDir() string { return filepath.Join(accorderConfigDir, "machine-state") }

func installationStatePath() string { return filepath.Join(machineStateDir(), "installation.json") }

func baselineStatePath(alias string) string {
	return existingEvidencePath(legacyBaselineStatePath(alias))
}

func legacyBaselineStatePath(alias string) string {
	return filepath.Join(machineStateDir(), "baselines", alias+".json")
}

func syncActivationPath(alias string) string {
	return filepath.Join(machineStateDir(), "sync-activation", alias+".json")
}

func publishRecoveryPath(alias string) string {
	return existingEvidencePath(legacyPublishRecoveryPath(alias))
}

func legacyPublishRecoveryPath(alias string) string {
	return filepath.Join(machineStateDir(), "publish-recovery", alias+".json")
}

func libraryExecutionLockPath(alias string) string {
	return filepath.Join(machineStateDir(), "locks", alias+".lock")
}

func loadOrCreateInstallation() (libraryInstallation, error) {
	path := installationStatePath()
	state, err := loadInstallation()
	if err == nil {
		return state, nil
	}
	if !os.IsNotExist(err) {
		return libraryInstallation{}, err
	}
	if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
		return libraryInstallation{}, err
	}
	lock, err := os.OpenFile(filepath.Join(filepath.Dir(path), "installation.lock"), os.O_CREATE|os.O_RDWR, 0o600)
	if err != nil {
		return libraryInstallation{}, err
	}
	release, ok, err := tryLibraryLockExclusive(lock)
	if err != nil {
		_ = lock.Close()
		return libraryInstallation{}, err
	}
	if !ok {
		_ = lock.Close()
		return libraryInstallation{}, errors.New("another Accorder process is creating this machine's installation identity; retry")
	}
	defer func() {
		release()
		_ = lock.Close()
	}()
	// A concurrent process may have finished between the first read and our
	// lock acquisition. Reuse its durable identity instead of minting another.
	state, err = loadInstallation()
	if err == nil {
		return state, nil
	}
	if !os.IsNotExist(err) {
		return libraryInstallation{}, err
	}
	label, hostErr := os.Hostname()
	if hostErr != nil || strings.TrimSpace(label) == "" {
		label = "Accorder device"
	}
	state = libraryInstallation{
		Version:   machineStateVersion,
		SeatID:    uuid.NewV4().String(),
		SeatLabel: label,
	}
	if err := writeJSONAtomic(path, state); err != nil {
		return libraryInstallation{}, err
	}
	return state, nil
}

func loadInstallation() (libraryInstallation, error) {
	path := installationStatePath()
	var state libraryInstallation
	if err := readJSONFile(path, &state); err != nil {
		return libraryInstallation{}, err
	}
	if state.Version != machineStateVersion || strings.TrimSpace(state.SeatID) == "" || strings.TrimSpace(state.SeatLabel) == "" {
		return libraryInstallation{}, fmt.Errorf("invalid machine installation state %s", path)
	}
	return state, nil
}

func loadBaseline(alias string) (*libraryBaseline, error) {
	var baseline libraryBaseline
	if err := readJSONFile(baselineStatePath(alias), &baseline); err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, err
	}
	if baselineStatePath(alias) == evidenceStatePath(legacyBaselineStatePath(alias)) && baseline.Version != sourceEvidenceVersion {
		return nil, errors.New("new publish history contains an incompatible version; retained for inspection")
	}
	if (baseline.Version != machineStateVersion && baseline.Version != sourceEvidenceVersion) || baseline.LibraryID == "" || baseline.RemoteSourceFingerprint == "" || baseline.LocalSourceFingerprint == "" {
		return nil, fmt.Errorf("invalid baseline for alias %q", alias)
	}
	if baseline.ContentLedgerVersion != 0 && baseline.ContentLedgerVersion != 1 && baseline.ContentLedgerVersion != sourceEvidenceVersion {
		return nil, fmt.Errorf("saved publish history has an unsupported file-checksum format for alias %q", alias)
	}
	if baseline.ContentLedgerVersion == sourceEvidenceVersion {
		if baseline.Version != sourceEvidenceVersion {
			return nil, errors.New("new file-change evidence cannot use the old state version")
		}
		if err := checkLegacyEvidence(legacyBaselineStatePath(alias), baseline.LegacyDigest); err != nil {
			return nil, err
		}
		if err := validateSourceEvidence(baseline.ContentLedger, baseline.Evidence); err != nil {
			return nil, err
		}
	}
	if baseline.ContentLedgerVersion >= 1 {
		if _, err := decodeGenerationHex(baseline.GenerationToken); err != nil {
			return nil, fmt.Errorf("saved publish history has an invalid publication marker for alias %q", alias)
		}
		if (len(baseline.CatalogChecksum) != 64 || strings.ToLower(baseline.CatalogChecksum) != baseline.CatalogChecksum) && !(baseline.ContentLedgerVersion == sourceEvidenceVersion && baseline.CatalogChecksum == "") {
			return nil, fmt.Errorf("saved publish history has an invalid library-index checksum for alias %q", alias)
		}
		if _, err := hex.DecodeString(baseline.CatalogChecksum); err != nil {
			return nil, fmt.Errorf("saved publish history has an invalid library-index checksum for alias %q", alias)
		}
		if len(baseline.ContentLedger) == 0 {
			return nil, fmt.Errorf("saved publish history has no file checksums for alias %q", alias)
		}
		if err := validateSourceContentLedger(baseline.ContentLedger); baseline.ContentLedgerVersion == 1 && err != nil {
			return nil, fmt.Errorf("saved publish history contains invalid file checksums for alias %q: %w", alias, err)
		}
	}
	return &baseline, nil
}

func saveBaseline(alias string, baseline libraryBaseline) error {
	baseline.Version = machineStateVersion
	path := legacyBaselineStatePath(alias)
	if baseline.ContentLedgerVersion == sourceEvidenceVersion {
		baseline.Version = sourceEvidenceVersion
		var err error
		baseline.LegacyDigest, err = legacyEvidenceDigest(path)
		if err != nil {
			return err
		}
		if err := validateSourceEvidence(baseline.ContentLedger, baseline.Evidence); err != nil {
			return err
		}
		path = evidenceStatePath(path)
	}
	baseline.UpdatedAt = baseline.UpdatedAt.UTC()
	return writeJSONAtomic(path, baseline)
}

func readJSONFile(path string, target any) error {
	data, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	if err := json.Unmarshal(data, target); err != nil {
		return fmt.Errorf("parse %s: %w", path, err)
	}
	return nil
}

func writeJSONAtomic(path string, value any) error {
	data, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return fmt.Errorf("marshal %s: %w", path, err)
	}
	if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
		return fmt.Errorf("create state directory for %s: %w", path, err)
	}
	tmp, err := os.CreateTemp(filepath.Dir(path), "."+filepath.Base(path)+"-*.tmp")
	if err != nil {
		return fmt.Errorf("create temporary state %s: %w", path, err)
	}
	tmpName := tmp.Name()
	cleanup := func() {
		_ = tmp.Close()
		_ = os.Remove(tmpName)
	}
	if _, err := tmp.Write(data); err != nil {
		cleanup()
		return fmt.Errorf("write temporary state %s: %w", path, err)
	}
	if err := tmp.Chmod(0o600); err != nil {
		cleanup()
		return fmt.Errorf("chmod temporary state %s: %w", path, err)
	}
	if err := tmp.Sync(); err != nil {
		cleanup()
		return fmt.Errorf("sync temporary state %s: %w", path, err)
	}
	if err := tmp.Close(); err != nil {
		_ = os.Remove(tmpName)
		return fmt.Errorf("close temporary state %s: %w", path, err)
	}
	if err := os.Rename(tmpName, path); err != nil {
		_ = os.Remove(tmpName)
		return fmt.Errorf("activate state %s: %w", path, err)
	}
	if dir, err := os.Open(filepath.Dir(path)); err == nil {
		_ = dir.Sync()
		_ = dir.Close()
	}
	return nil
}

func removeStateFile(path string) error {
	err := os.Remove(path)
	if err != nil && !os.IsNotExist(err) {
		return err
	}
	return nil
}

func acquireLibraryExecutionLock(alias string) (func(), error) {
	if strings.TrimSpace(alias) == "" {
		return nil, errors.New("library execution lock: empty alias")
	}
	path := libraryExecutionLockPath(alias)
	if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
		return nil, err
	}
	f, err := os.OpenFile(path, os.O_CREATE|os.O_RDWR, 0o600)
	if err != nil {
		return nil, err
	}
	releaseLock, ok, err := tryLibraryLockExclusive(f)
	if err != nil {
		_ = f.Close()
		return nil, err
	}
	if !ok {
		_ = f.Close()
		return nil, fmt.Errorf("another sync or publish is already running for alias %q", alias)
	}
	return func() {
		releaseLock()
		_ = f.Close()
	}, nil
}
