//go:build !tailscale

package cmd

import (
	"accorder/pkg/calibre"
	"bufio"
	"context"
	"fmt"
	"os"
	"path/filepath"
	"testing"

	"github.com/goccy/go-json"
)

// ═══════════════════════════════════════════════════════════════════
// Test 1: ParsesWithQuery
// ═══════════════════════════════════════════════════════════════════

func TestLibSearch_ParsesWithQuery(t *testing.T) {
	libDir := testSetup(t)

	// Create a dummy index file so filepath validation passes.
	idxPath := filepath.Join(libDir, "test-idx")
	_ = os.WriteFile(idxPath, []byte{}, 0644)

	cli, _ := parseCLI(t, []string{
		"lib", "search", "test-alias",
		"--index-path=" + idxPath,
		"-q", "title:philosophy",
	})
	if cli.Lib.Search.Query != "title:philosophy" {
		t.Errorf("Query = %q, want title:philosophy", cli.Lib.Search.Query)
	}
	if cli.Lib.Search.IndexPath != idxPath {
		t.Errorf("IndexPath = %q, want %q", cli.Lib.Search.IndexPath, idxPath)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test 2: SharedGroupPropagation
// ═══════════════════════════════════════════════════════════════════

func TestLibSearch_SharedGroupPropagation(t *testing.T) {
	libDir := testSetup(t)
	idxPath := filepath.Join(libDir, "propagation-idx")
	_ = os.WriteFile(idxPath, []byte{}, 0644)

	// Save via lib build with --index-path.
	parseCLI(t, []string{
		"lib", "build", "prop-test",
		"--calibrepath=" + libDir,
		"--librarian=Alice",
		"--libraryID=550e8400-e29b-41d4-a716-446655440000",
		"--index-path=" + idxPath,
	})

	alias := readAlias(t, "prop-test")

	// Verify index-path propagated to lib.search.
	searchPath := alias.Get("lib.search.index-path")
	if searchPath.String() != idxPath {
		t.Errorf("lib.search.index-path = %q, want %q", searchPath.String(), idxPath)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test 3: QueryParsing
// ═══════════════════════════════════════════════════════════════════

func TestLibSearch_QueryParsing(t *testing.T) {
	tests := []struct {
		input   string
		want    calibre.SearchQuery
		wantErr bool
	}{
		{
			input: "title:philosophy",
			want:  calibre.SearchQuery{Field: calibre.FieldTitle, Text: "philosophy"},
		},
		{
			input: "author:foucault",
			want:  calibre.SearchQuery{Field: calibre.FieldAuthor, Text: "foucault"},
		},
		{
			input: "tag:history",
			want:  calibre.SearchQuery{Field: calibre.FieldTag, Text: "history"},
		},
		{

			// No colon — defaults to title.
			input: "philosophy",
			want:  calibre.SearchQuery{Field: calibre.FieldTitle, Text: "philosophy"},
		},
		{

			// Colon in value — split on first colon only.
			input: "title:foo:bar",
			want:  calibre.SearchQuery{Field: calibre.FieldTitle, Text: "foo:bar"},
		},
		{

			// Unknown field.
			input:   "isbn:12345",
			wantErr: true,
		},
		{

			// Empty value after colon.
			input:   "title:",
			wantErr: true,
		},

		// Prefix query.
		{
			input: "title:walt*",
			want:  calibre.SearchQuery{Field: calibre.FieldTitle, Text: "walt", Mode: calibre.ModePrefix},
		},

		// Fuzzy query, default distance.
		{
			input: "title:edit~",
			want:  calibre.SearchQuery{Field: calibre.FieldTitle, Text: "edit", Mode: calibre.ModeFuzzy, FuzzyDistance: 1},
		},

		// Fuzzy query, distance 2.
		{
			input: "title:edit~2",
			want:  calibre.SearchQuery{Field: calibre.FieldTitle, Text: "edit", Mode: calibre.ModeFuzzy, FuzzyDistance: 2},
		},

		// Fuzzy query, invalid distance 3.
		{
			input:   "title:edit~3",
			wantErr: true,
		},

		// Prefix with empty text.
		{
			input:   "title:*",
			wantErr: true,
		},

		// Fuzzy with empty text.
		{
			input:   "title:~",
			wantErr: true,
		},

		// Author prefix.
		{
			input: "author:knu*",
			want:  calibre.SearchQuery{Field: calibre.FieldAuthor, Text: "knu", Mode: calibre.ModePrefix},
		},
	}

	for _, tt := range tests {
		t.Run(tt.input, func(t *testing.T) {
			got, err := parseSearchQuery(tt.input)
			if tt.wantErr {
				if err == nil {
					t.Errorf("parseSearchQuery(%q) = %v, want error", tt.input, got)
				}
				return
			}
			if err != nil {
				t.Fatalf("parseSearchQuery(%q) error: %v", tt.input, err)
			}
			if got != tt.want {
				t.Errorf("parseSearchQuery(%q) = %v, want %v", tt.input, got, tt.want)
			}
		})
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test 4: EndToEnd — build an index and search it
// ═══════════════════════════════════════════════════════════════════

// seedTestJSONL writes a small JSONL corpus for end-to-end testing.
// This is self-contained because seedJSONL in pkg/calibre is package-private.
func seedTestJSONL(t *testing.T, dir string) string {
	t.Helper()
	path := filepath.Join(dir, "books.jsonl")
	f, err := os.Create(path)
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()

	w := bufio.NewWriter(f)
	defer w.Flush()

	books := []calibre.Book{
		{
			Title:        "The Philosophy of Freedom",
			Authors:      []string{"Rudolf Steiner"},
			Tags:         []string{"philosophy", "anthroposophy"},
			LastModified: "2024-01-15T10:30:00+00:00",
			LibraryUUID:  "test-uuid",
			Librarian:    "testlib",
			UUID:         "book-1",
		},
		{
			Title:        "Capital Volume I",
			Authors:      []string{"Karl Marx"},
			Tags:         []string{"economics", "philosophy"},
			LastModified: "2024-01-10T08:00:00+00:00",
			LibraryUUID:  "test-uuid",
			Librarian:    "testlib",
			UUID:         "book-2",
		},
		{
			Title:        "A Brief History of Time",
			Authors:      []string{"Stephen Hawking"},
			Tags:         []string{"physics", "cosmology"},
			LastModified: "2024-01-05T12:00:00+00:00",
			LibraryUUID:  "test-uuid",
			Librarian:    "testlib",
			UUID:         "book-3",
		},
	}

	for _, b := range books {
		data, err := json.Marshal(b)
		if err != nil {
			t.Fatal(err)
		}
		_, _ = w.Write(data)
		_ = w.WriteByte('\n')
	}
	return path
}

func TestLibSearch_EndToEnd(t *testing.T) {
	dir := t.TempDir()
	jsonlPath := seedTestJSONL(t, dir)
	idxPath := filepath.Join(dir, "test-index")

	// Build a search index from the JSONL corpus.
	motwSearch := &calibre.MotwSearch{
		JsonlPath: jsonlPath,
		IndexPath: idxPath,
	}
	idx, err := motwSearch.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex: %v", err)
	}
	if err := motwSearch.CompressToFile(idx); err != nil {
		t.Fatalf("CompressToFile: %v", err)
	}

	// Search for "philosophy" in title — should find "The Philosophy of Freedom".
	q := calibre.SearchQuery{Field: calibre.FieldTitle, Text: "philosophy"}
	books, stats, err := motwSearch.Search(context.Background(), q, calibre.SearchOptions{})
	if err != nil {
		t.Fatalf("Search: %v", err)
	}
	if stats.BooksMatched < 1 {
		t.Fatal("expected at least 1 match for title:philosophy")
	}

	found := false
	for _, b := range books {
		if b.Title == "The Philosophy of Freedom" {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("expected 'The Philosophy of Freedom' in results, got %d books", len(books))
	}

	// Search for author "marx" — should find "Capital Volume I".
	q2 := calibre.SearchQuery{Field: calibre.FieldAuthor, Text: "marx"}
	books2, _, err := motwSearch.Search(context.Background(), q2, calibre.SearchOptions{})
	if err != nil {
		t.Fatalf("Search author:marx: %v", err)
	}
	found = false
	for _, b := range books2 {
		if b.Title == "Capital Volume I" {
			found = true
			break
		}
	}
	if !found {
		titles := make([]string, len(books2))
		for i, b := range books2 {
			titles[i] = b.Title
		}
		t.Errorf("expected 'Capital Volume I' in author:marx results, got %v", titles)
	}

	// Search for tag "physics" — should find "A Brief History of Time".
	q3 := calibre.SearchQuery{Field: calibre.FieldTag, Text: "physics"}
	books3, _, err := motwSearch.Search(context.Background(), q3, calibre.SearchOptions{})
	if err != nil {
		t.Fatalf("Search tag:physics: %v", err)
	}
	if len(books3) == 0 {
		t.Fatal("expected at least 1 match for tag:physics")
	}

	found = false
	for _, b := range books3 {
		if b.Title == "A Brief History of Time" {
			found = true
			break
		}
	}
	if !found {
		t.Errorf("expected 'A Brief History of Time' in tag:physics results")
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test 5: DefaultQueryField
// ═══════════════════════════════════════════════════════════════════

func TestLibSearch_DefaultQueryField(t *testing.T) {
	libDir := testSetup(t)
	idxPath := filepath.Join(libDir, "default-field-idx")
	_ = os.WriteFile(idxPath, []byte{}, 0644)

	cli, _ := parseCLI(t, []string{
		"lib", "search", "default-test",
		"--index-path=" + idxPath,
		"-q", "philosophy",
	})

	// Without field prefix, should still parse successfully.
	if cli.Lib.Search.Query != "philosophy" {
		t.Errorf("Query = %q, want philosophy", cli.Lib.Search.Query)
	}

	// parseSearchQuery should default to title.
	q, err := parseSearchQuery(cli.Lib.Search.Query)
	if err != nil {
		t.Fatalf("parseSearchQuery: %v", err)
	}
	if q.Field != calibre.FieldTitle {
		t.Errorf("Field = %q, want %q", q.Field, calibre.FieldTitle)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test 6: LimitAndOffset
// ═══════════════════════════════════════════════════════════════════

func TestLibSearch_LimitAndOffset(t *testing.T) {
	libDir := testSetup(t)
	idxPath := filepath.Join(libDir, "limit-idx")
	_ = os.WriteFile(idxPath, []byte{}, 0644)

	cli, _ := parseCLI(t, []string{
		"lib", "search", "limit-test",
		"--index-path=" + idxPath,
		"-q", "title:test",
		"--limit=10",
		"--offset=5",
	})
	if cli.Lib.Search.Limit != 10 {
		t.Errorf("Limit = %d, want 10", cli.Lib.Search.Limit)
	}
	if cli.Lib.Search.Offset != 5 {
		t.Errorf("Offset = %d, want 5", cli.Lib.Search.Offset)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test 7: ShowConfig
// ═══════════════════════════════════════════════════════════════════

func TestLibSearch_ShowConfig(t *testing.T) {
	libDir := testSetup(t)
	idxPath := filepath.Join(libDir, "show-config-idx")
	_ = os.WriteFile(idxPath, []byte{}, 0644)

	cli, _ := parseCLI(t, []string{
		"lib", "search", "show-test",
		"--index-path=" + idxPath,
		"-q", "title:test",
		"-s",
	})
	if cli.Lib.Search.ShowConfig == nil {
		t.Fatal("ShowConfig should be non-nil")
	}
	if !*cli.Lib.Search.ShowConfig {
		t.Error("ShowConfig should be true")
	}
}

// Unused import guard — the fmt import is used by seedTestJSONL.
var _ = fmt.Sprintf
