//go:build !tailscale

package cmd

import (
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestIsSensitiveServePath(t *testing.T) {
	deny := []string{
		"biopolitics/metadata.db",
		"metadata.db",
		"biopolitics/metadata.db-wal",
		"biopolitics/metadata.db-shm",
		"biopolitics/metadata_db_prefs_backup.json",
		"biopolitics/_IDENTITY",
		"biopolitics/_WRITER",
		"biopolitics/secrets.age",
		"biopolitics/.caltrash/old.epub",
		".age/key",
	}
	allow := []string{
		"biopolitics/Michel Foucault/Discipline (1)/book.epub",
		"biopolitics/Michel Foucault/Discipline (1)/cover.jpg",
		"biopolitics/static/library_index.zst",
		"biopolitics/_GENERATION",
		"biopolitics",
	}
	for _, p := range deny {
		if !isSensitiveServePath(p) {
			t.Errorf("expected DENY, got allow: %q", p)
		}
	}
	for _, p := range allow {
		if isSensitiveServePath(p) {
			t.Errorf("expected ALLOW, got deny: %q", p)
		}
	}
}

func TestGuardedFileHandler(t *testing.T) {
	next := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { w.WriteHeader(http.StatusOK) })
	h := guardedFileHandler(next)

	for _, tc := range []struct {
		path string
		want int
	}{
		{"/files/biopolitics/metadata.db", http.StatusNotFound},
		{"/files/biopolitics/secrets.age", http.StatusNotFound},
		{"/files/biopolitics/_WRITER", http.StatusNotFound},
		{"/files/biopolitics/Author/Title-1/book.epub", http.StatusOK},
		{"/files/biopolitics/Author/Title-1/cover.jpg", http.StatusOK},
	} {
		rec := httptest.NewRecorder()
		h.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, tc.path, nil))
		if rec.Code != tc.want {
			t.Errorf("%s → %d, want %d", tc.path, rec.Code, tc.want)
		}
	}
}
