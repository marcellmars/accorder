package cmd

import (
	"bytes"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"

	"accorder/pkg/calibre"
	"accorder/pkg/libraryflow"
)

// This record is written only by the explicit derived-only transfer path.
// A sync observation cannot manufacture this A->B relationship.
type derivedEvidenceRepair struct {
	Version                      int `json:"version"`
	Alias, LibraryID, Root       string
	From, To                     string
	Pointer, Writer, FromPointer []byte
	Source                       publishRecoveryRecord
	Baseline                     *libraryBaseline
	Candidate                    *localChangeCandidate
}

func derivedEvidenceRepairPath(alias string) string {
	return filepath.Join(machineStateDir(), "derived-repair", alias+".json.v2")
}

func prepareDerivedEvidenceRepair(alias, root string, before remoteLibrarySnapshot, pointer calibre.PointerFile, token []byte, indexRel string) (derivedEvidenceRepair, error) {
	record := derivedEvidenceRepair{Version: sourceEvidenceVersion, Alias: alias, LibraryID: pointer.Library.UUID, Root: root,
		From: hex.EncodeToString(before.GenerationRaw), To: hex.EncodeToString(token), Writer: before.Writer.Raw, FromPointer: before.PointerRaw}
	baseline, err := loadBaseline(alias)
	if err != nil {
		return record, err
	}
	installation, err := loadOrCreateInstallation()
	if err != nil {
		return record, err
	}
	var inventory *sourceInventory
	if before.Pointer.SourceContract == "" {
		inventory, err = parallelInventory(root, 16, true)
	} else {
		inventory, err = scanSourceObjects(root)
	}
	if err != nil {
		return record, err
	}
	var old []libraryflow.Object
	var prior *sourceEvidence
	if baseline != nil {
		old, prior = baseline.ContentLedger, baseline.Evidence
	}
	excludes := resolveUploadExcludes(root, nil)
	ledger, evidence, changed, _, err := buildSourceEvidence(root, inventory.Objects, excludes, old, prior, installation.SeatID, inventory)
	if err != nil {
		return record, err
	}
	if err := requireSourceCoherence(root, ledger, evidence); err != nil {
		return record, err
	}
	info, err := os.Stat(filepath.Join(root, filepath.FromSlash(indexRel)))
	if err != nil {
		return record, err
	}
	index := libraryflow.NewLocalObjectAt(indexRel, filepath.Join(root, filepath.FromSlash(indexRel)), info)
	index.Hash, err = hashLocalFile(filepath.Join(root, filepath.FromSlash(indexRel)))
	if err != nil {
		return record, err
	}
	record.Source = publishRecoveryRecord{SourceFingerprint: before.SourceFingerprint, ContentLedgerVersion: sourceEvidenceVersion, ContentLedger: ledger, Evidence: evidence, Excludes: excludes, IndexArtifact: index}
	record.Pointer, err = json.MarshalIndent(pointer, "", "  ")
	if err != nil {
		return record, err
	}
	known := baseline != nil && baseline.ContentLedgerVersion >= 1 && baseline.GenerationToken == record.From && baseline.LibraryID == pointer.Library.UUID && baseline.LocalSourceFingerprint == baseline.RemoteSourceFingerprint && baseline.RemoteSourceFingerprint == before.SourceFingerprint
	if known && baseline.Evidence != nil {
		known = baseline.Evidence.Provenance == evidence.Provenance
	}
	if known {
		updated := *baseline
		updated.Generation, updated.GenerationToken = pointer.Generation, record.To
		updated.CatalogChecksum = pointer.CatalogChecksum
		// UpdatedAt and payload observations remain those of the last actual
		// payload activation, not the time of this derived-only operation.
		record.Baseline = &updated
	}
	if candidate, err := loadLocalChangeCandidate(root); err == nil && candidate.LibraryUUID == pointer.Library.UUID {
		candidate.Version, candidate.ContentLedgerVersion = sourceEvidenceVersion, sourceEvidenceVersion
		candidate.Evidence, candidate.ContentLedger, candidate.IndexArtifact = evidence, ledger, index
		candidate.ForcePaths = mergeCandidateForcePaths(candidate.ForcePaths, changed, ledger)
		candidate.FromGeneration, candidate.FromCatalogChecksum = record.To, pointer.CatalogChecksum
		candidate.FromLiveCount = uint32ptr(pointer.Index.NumBooks)
		candidate.ToLiveCount, candidate.ToCatalogChecksum = pointer.Index.NumBooks, pointer.CatalogChecksum
		candidate.TargetSourceFingerprint = before.SourceFingerprint
		candidate.makeCoarse("derived-repair-rebase", !known || candidate.CompleteOverwrite)
		record.Candidate = candidate
	}
	return record, nil
}

func finishDerivedEvidenceRepair(remote *libraryRemote, record derivedEvidenceRepair) error {
	if record.Version != sourceEvidenceVersion || record.Alias == "" || record.Root == "" {
		return errors.New("invalid saved derived repair")
	}
	snapshot := remote.commitState()
	if snapshot.Err != nil || !snapshot.Committed || hex.EncodeToString(snapshot.GenerationRaw) != record.To || !bytes.Equal(snapshot.PointerRaw, record.Pointer) || !bytes.Equal(remote.readWriter().Raw, record.Writer) {
		return errors.New("the remote version changed; derived-repair evidence was retained for reconciliation")
	}
	if err := verifyRecoverySource(record.Root, record.Source); err != nil {
		return err
	}
	// Candidate first: a crash before the baseline write leaves an explicitly
	// mismatched pair, never authority for a narrow transfer. This record can
	// replay both writes. Pending paths remain present throughout.
	if record.Candidate != nil {
		if err := saveLocalChangeCandidate(record.Root, *record.Candidate); err != nil {
			return err
		}
	}
	if record.Baseline != nil {
		if err := saveBaseline(record.Alias, *record.Baseline); err != nil {
			return err
		}
	}
	token, err := hex.DecodeString(record.To)
	if err != nil {
		return err
	}
	if err := atomicWriteFile(filepath.Join(record.Root, libraryflow.GenerationPath), token, 0o644); err != nil {
		return err
	}
	return removeStateFile(derivedEvidenceRepairPath(record.Alias))
}

func recoverDerivedEvidenceRepair(alias, libraryID, root string, remote *libraryRemote) (bool, error) {
	var record derivedEvidenceRepair
	if err := readJSONFile(derivedEvidenceRepairPath(alias), &record); os.IsNotExist(err) {
		return false, nil
	} else if err != nil {
		return false, err
	}
	if record.Version != sourceEvidenceVersion || record.Alias != alias || record.LibraryID != libraryID || record.Root != root {
		return false, errors.New("saved derived repair belongs to a different library or root")
	}
	if err := verifyRecoverySource(root, record.Source); err != nil {
		return false, err
	}
	snapshot := remote.commitState()
	if !bytes.Equal(remote.readWriter().Raw, record.Writer) {
		return false, errors.New("publishing access changed; derived repair was retained")
	}
	if hex.EncodeToString(snapshot.GenerationRaw) == record.From {
		if !bytes.Equal(snapshot.PointerRaw, record.FromPointer) && !bytes.Equal(snapshot.PointerRaw, record.Pointer) {
			return false, errors.New("remote pointer changed; derived repair was retained")
		}
		// The derived family was uploaded before this record became durable;
		// replay only the recorded protected pointer and sentinel.
		pointer, err := calibre.DecodePointerFile(bytes.NewReader(record.Pointer))
		if err != nil || pointer.Library.UUID != libraryID || pointer.SourceFingerprint != record.Source.SourceFingerprint {
			return false, errors.New("invalid derived repair pointer")
		}
		token, err := decodeGenerationHex(record.To)
		if err != nil {
			return false, err
		}
		_, generation := token.parts()
		if pointer.Generation != generation {
			return false, errors.New("derived repair token does not match its pointer")
		}
		if err := remote.write(memberPointerPath, record.Pointer); err != nil {
			return false, err
		}
		if err := verifyRecoverySource(root, record.Source); err != nil {
			return false, err
		}
		if !bytes.Equal(remote.readWriter().Raw, record.Writer) {
			return false, errors.New("publishing access changed during repair recovery")
		}
		raw, _ := hex.DecodeString(record.To)
		if err := remote.write(libraryflow.GenerationPath, raw); err != nil {
			return false, err
		}
	}
	if err := finishDerivedEvidenceRepair(remote, record); err != nil {
		return false, fmt.Errorf("resume derived-only repair: %w", err)
	}
	return true, nil
}
