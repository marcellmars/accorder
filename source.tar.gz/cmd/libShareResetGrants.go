package cmd

import (
	"fmt"
	"os"
	"path/filepath"

	"github.com/alecthomas/kong"
)

type LibShareResetGrantsCmd struct {
	CommonCommandFields
}

func (c *LibShareResetGrantsCmd) Run(ctx *kong.Context) error {
	if c.HandleShowConfig(c) {
		return nil
	}

	stateDir := filepath.Join(accorderConfigDir, "clearnet-lib", c.ActionAlias)
	reg, err := newGrantRegistry(stateDir)
	if err != nil {
		return fmt.Errorf("lib share reset-grants: %w", err)
	}

	if err := reg.reset(); err != nil {
		return fmt.Errorf("lib share reset-grants: %w", err)
	}
	fmt.Fprintln(os.Stderr, "lib share reset-grants: signing key rotated, all grants invalidated")
	return nil
}
