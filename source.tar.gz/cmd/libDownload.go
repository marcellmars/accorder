package cmd

import (
	"accorder/pkg/rclonexfer"
	"fmt"
	"os"
	"path/filepath"
)

type LibDownloadCmd struct {
	CommonCommandFields
	CalibreDirectory string   `name:"calibrepath" short:"c" json:"calibrepath" help:"Local directory to download into (created if missing)." validate:"omitempty"`
	Files            []string `name:"files" sep:"," help:"Comma-separated objects to download (relative to <bucket>/<prefix>); omit for a full copy." json:"-"`
	ListFile         string   `name:"list" help:"Path to a text file listing objects to download (one per line, # comments ok)." json:"-" validate:"omitempty,filepath"`
	GroupS3Credentials
	Passphrase string `name:"passphrase" json:"-" help:"Passphrase for the local secrets store (or set ACCORDER_SECRETS_PASSPHRASE)." env:"ACCORDER_SECRETS_PASSPHRASE" secret:"redact"`
	TeaOutputs
}

func (c *LibDownloadCmd) Run() error {
	c.Header = ".◟◜motw download◝◞."
	if c.HandleShowConfig(c) {
		return nil
	}
	if c.CalibreDirectory == "" {
		return fmt.Errorf("lib download: missing required flag: --calibrepath (the local destination)")
	}
	if !isScopedBucket(c.Bucket) {
		return fmt.Errorf("lib download: refusing to copy from bare bucket %q (no prefix); expected <bucket>/<prefix>", c.Bucket)
	}
	if err := os.MkdirAll(c.CalibreDirectory, 0o755); err != nil {
		return fmt.Errorf("lib download: create %s: %w", c.CalibreDirectory, err)
	}

	var allFiles []string
	allFiles = append(allFiles, c.Files...)
	if c.ListFile != "" {
		listed, err := parseListFile(c.ListFile)
		if err != nil {
			return err
		}
		allFiles = append(allFiles, listed...)
	}
	if err := validateRelativePaths(allFiles); err != nil {
		return err
	}
	var includePatterns []string
	for _, f := range allFiles {
		includePatterns = append(includePatterns, "/"+filepath.ToSlash(filepath.Clean(f)))
	}

	remoteName := "accorder-download-" + c.ActionAlias
	if err := rclonexfer.SetCacheDir(accorderCacheDir()); err != nil {
		return fmt.Errorf("lib download: set cache dir: %w", err)
	}
	rclonexfer.Initialize()
	defer rclonexfer.Finalize()

	_ = rclonexfer.DeleteRemote(remoteName)
	if err := rclonexfer.ConfigS3Remote(remoteName, rclonexfer.S3RemoteConfig{
		Provider:  c.S3Provider,
		AccessKey: c.S3AccessKey,
		SecretKey: c.S3SecretKey,
		Endpoint:  c.S3Endpoint,
	}); err != nil {
		return fmt.Errorf("lib download: config s3 remote: %w", err)
	}
	defer func() { _ = rclonexfer.DeleteRemote(remoteName) }()

	srcFs := remoteName + ":" + c.Bucket
	what := "all objects"
	if len(includePatterns) > 0 {
		what = fmt.Sprintf("%d selected object(s)", len(includePatterns))
	}
	fmt.Fprintf(os.Stderr, "lib download: copying %s from %s -> %s\n", what, c.Bucket, c.CalibreDirectory)
	jobID, err := rclonexfer.SyncCopy(srcFs, c.CalibreDirectory, includePatterns)
	if err != nil {
		return fmt.Errorf("lib download: copy: %w", err)
	}
	for stats := range rclonexfer.PollProgress(jobID) {
		if stats.Finished {
			if !stats.Success {
				return fmt.Errorf("lib download: copy failed (transferred %d bytes)", stats.Bytes)
			}
			break
		}
	}
	fmt.Fprintf(os.Stderr, "lib download: done.\n")
	return nil
}
