package cmd

import (
	"bytes"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"time"

	"accorder/pkg/libraryflow"
)

const sourceEvidenceVersion = 2

type buildDatabaseObservation struct {
	Object libraryflow.Object
	ID     string
	SQLite bool
}

// Only metadata.db is opened here, never a book format. The header distinguishes
// a Calibre database from the legacy external-JSONL build input convention.
func observeBuildDatabase(root string) (*buildDatabaseObservation, error) {
	path := filepath.Join(root, "metadata.db")
	info, err := os.Stat(path)
	if os.IsNotExist(err) {
		return nil, nil
	}
	if err != nil {
		return nil, err
	}
	file, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	var header [16]byte
	n, readErr := io.ReadFull(file, header[:])
	if err := file.Close(); err != nil {
		return nil, err
	}
	if readErr != nil && readErr != io.EOF && readErr != io.ErrUnexpectedEOF {
		return nil, readErr
	}
	id, _ := sourceLocalFileEvidence(path)
	observation := &buildDatabaseObservation{Object: libraryflow.NewLocalObjectAt("metadata.db", path, info), ID: id,
		SQLite: n == len(header) && bytes.Equal(header[:], []byte("SQLite format 3\x00"))}
	if id == "" || observation.Object.ChangeTime <= 0 {
		observation.Object.Hash, err = hashLocalFile(path)
	}
	return observation, err
}

func verifyBuildDatabase(root string, before *buildDatabaseObservation) error {
	after, err := observeBuildDatabase(root)
	if err != nil {
		return err
	}
	if before == nil && after == nil {
		return nil
	}
	if before == nil || after == nil || before.ID != after.ID || before.SQLite != after.SQLite ||
		before.Object.Size != after.Object.Size || !before.Object.ModTime.Equal(after.Object.ModTime) ||
		before.Object.ChangeTime != after.Object.ChangeTime || before.Object.Hash != after.Object.Hash {
		return errors.New("lib build: database changed during build; close Calibre and build again; previous checkpoint was preserved")
	}
	return nil
}

func cachedCatalogDatabaseMatches(before *buildDatabaseObservation, candidate *localChangeCandidate) bool {
	if before == nil || candidate == nil {
		return false
	}
	for i, object := range candidate.ContentLedger {
		if object.Path != "metadata.db" || !sameSourceStamp(before.Object, object) {
			continue
		}
		if candidate.Evidence == nil {
			return true
		} // Existing v1 reuse contract.
		return candidate.Evidence.Files[i].ID == before.ID
	}
	return false
}

// Tests can model missing native signals without requiring an unsupported disk.
var sourceLocalFileEvidence = func(path string) (string, string) {
	finish := beginLibraryWork("native-evidence")
	defer finish(1)
	return libraryflow.LocalFileEvidence(path)
}

func evidenceStatePath(legacy string) string { return legacy + ".v2" }

func existingEvidencePath(legacy string) string {
	if _, err := os.Stat(evidenceStatePath(legacy)); !os.IsNotExist(err) {
		return evidenceStatePath(legacy)
	}
	return legacy
}

func legacyEvidenceDigest(path string) (string, error) {
	digest, err := hashLocalFile(path)
	if os.IsNotExist(err) {
		return "absent", nil
	}
	return digest, err
}

func checkLegacyEvidence(path, expected string) error {
	got, err := legacyEvidenceDigest(path)
	if err != nil {
		return err
	}
	if expected == "" || got != expected {
		return errors.New("an older Accorder changed the retained publication history; rebuild without assuming the old remote history is current")
	}
	return nil
}

// sourceProvenance is prospective local evidence, never a proof of remote
// content. The durable installation ID is a seat ID, not a physical host ID.
type sourceProvenance struct {
	Seat       string `json:"seat"`
	Root       string `json:"root"`
	RootID     string `json:"root_id"`
	Capability string `json:"capability"`
}

type sourceFileEvidence struct {
	Path       string `json:"path"`
	ID         string `json:"id"`
	Capability string `json:"capability"`
}

type sourceEvidence struct {
	Provenance sourceProvenance     `json:"provenance"`
	Files      []sourceFileEvidence `json:"files"`
}

func captureSourceProvenance(root, seat string) (sourceProvenance, error) {
	root, err := filepath.Abs(root)
	if err != nil {
		return sourceProvenance{}, err
	}
	root, err = filepath.EvalSymlinks(root)
	if err != nil {
		return sourceProvenance{}, err
	}
	id, capability := sourceLocalFileEvidence(root)
	return sourceProvenance{Seat: seat, Root: root, RootID: id, Capability: capability}, nil
}

func sameSourceStamp(a, b libraryflow.Object) bool {
	return a.Path == b.Path && a.Size == b.Size && !a.ModTime.IsZero() &&
		a.ModTime.Equal(b.ModTime) && a.ChangeTime > 0 && a.ChangeTime == b.ChangeTime
}

func hasUsableSourceSignals(ledger []libraryflow.Object, evidence *sourceEvidence) bool {
	if evidence == nil || evidence.Provenance.Capability == "" || evidence.Provenance.RootID == "" || len(ledger) != len(evidence.Files) {
		return false
	}
	for i, file := range evidence.Files {
		if file.ID == "" || file.Capability == "" || ledger[i].ChangeTime <= 0 || ledger[i].ModTime.IsZero() {
			return false
		}
	}
	return true
}

// buildSourceEvidence never reads format bytes, even on the first build or on
// an unsupported filesystem. Only metadata.db has a required source digest.
// previousEvidence=nil imports the existing v1 ordinary-edit reuse contract.
func buildSourceEvidence(root string, objects []libraryflow.Object, excludes []string, previous []libraryflow.Object, previousEvidence *sourceEvidence, seat string, observed ...*sourceInventory) ([]libraryflow.Object, *sourceEvidence, []string, []string, error) {
	finish := beginLibraryWork("source-evidence")
	defer finish(len(objects))
	if len(observed) > 1 {
		return nil, nil, nil, nil, errors.New("only one inventory observation is allowed per boundary")
	}
	current, err := libraryflow.FilterInventory(objects, excludes, false)
	if err != nil {
		return nil, nil, nil, nil, err
	}
	provenance, err := captureSourceProvenance(root, seat)
	if err != nil {
		return nil, nil, nil, nil, err
	}
	evidence := &sourceEvidence{Provenance: provenance}
	old := make(map[string]libraryflow.Object, len(previous))
	for _, object := range previous {
		old[object.Path] = object
	}
	oldIDs := make(map[string]sourceFileEvidence)
	if previousEvidence != nil {
		for _, file := range previousEvidence.Files {
			oldIDs[file.Path] = file
		}
	}
	var changed, removed []string
	for i := range current {
		object := &current[i]
		path := filepath.Join(root, filepath.FromSlash(object.Path))
		var id, capability string
		if len(observed) != 0 {
			inventory := observed[0]
			if inventory == nil || inventory.Root != filepath.Clean(root) {
				return nil, nil, nil, nil, errors.New("file observation belongs to a different inventory root")
			}
			file, ok := inventory.Files[object.Path]
			if !ok || file.Object.Path != object.Path || file.Object.Size != object.Size || !file.Object.ModTime.Equal(object.ModTime) || file.Object.ChangeTime != object.ChangeTime {
				return nil, nil, nil, nil, errors.New("file observation does not match this inventory")
			}
			id, capability = file.Evidence.ID, file.Evidence.Capability
		} else {
			id, capability = sourceLocalFileEvidence(path)
		}
		evidence.Files = append(evidence.Files, sourceFileEvidence{object.Path, id, capability})
		prior, exists := old[object.Path]
		reusable := exists && sameSourceStamp(*object, prior) && id != "" && capability != ""
		if previousEvidence != nil {
			reusable = reusable && previousEvidence.Provenance == provenance && oldIDs[object.Path] == evidence.Files[len(evidence.Files)-1]
		}
		if reusable {
			object.Hash = prior.Hash
		} else {
			changed = append(changed, object.Path)
		}
		if object.Path == "metadata.db" && object.Hash == "" {
			object.Hash, err = hashLocalFile(path)
			if err != nil {
				return nil, nil, nil, nil, err
			}
		}
		delete(old, object.Path)
	}
	for path := range old {
		removed = append(removed, path)
	}
	sort.Strings(removed)
	return current, evidence, changed, removed, nil
}

func validateSourceEvidence(ledger []libraryflow.Object, evidence *sourceEvidence) error {
	if evidence == nil || evidence.Provenance.Root == "" || !filepath.IsAbs(evidence.Provenance.Root) || evidence.Provenance.Seat == "" || len(evidence.Files) != len(ledger) {
		return errors.New("saved file-change information is incomplete")
	}
	previous := ""
	metadata := false
	for i, object := range ledger {
		path, err := libraryflow.NormalizePath(object.Path)
		if err != nil || path != object.Path || (i > 0 && path <= previous) || !libraryflow.IsSourcePath(path) || object.Size < 0 || evidence.Files[i].Path != path {
			return errors.New("saved file-change paths are invalid")
		}
		if object.Hash != "" {
			if err := validateContentLedger([]libraryflow.Object{object}); err != nil {
				return err
			}
		}
		if path == "metadata.db" {
			metadata = object.Hash != ""
		}
		previous = path
	}
	if !metadata {
		return errors.New("saved file-change information is missing the catalog database checksum")
	}
	return nil
}

func requireSourceCoherence(root string, ledger []libraryflow.Object, evidence *sourceEvidence) error {
	if err := validateSourceEvidence(ledger, evidence); err != nil {
		return err
	}
	installation, err := loadInstallation()
	if err != nil {
		return err
	}
	current, err := captureSourceProvenance(root, installation.SeatID)
	if err != nil {
		return err
	}
	if current != evidence.Provenance || current.Capability == "" || current.RootID == "" {
		return errors.New("cannot safely verify this library's files on this device or filesystem; local builds are available, but publication is stopped")
	}
	for i, file := range evidence.Files {
		if file.ID == "" || file.Capability == "" || ledger[i].ChangeTime <= 0 || ledger[i].ModTime.IsZero() {
			return fmt.Errorf("cannot safely verify changes to %s on this filesystem; publication is stopped", file.Path)
		}
	}
	return nil
}

func refreshSourceEvidence(root string, objects []libraryflow.Object, excludes []string, previous []libraryflow.Object, evidence *sourceEvidence, observed ...*sourceInventory) ([]libraryflow.Object, *sourceEvidence, []string, []string, error) {
	installation, err := loadInstallation()
	if err != nil {
		if evidence != nil {
			return nil, nil, nil, nil, err
		}
		// A read-only preview of a v1 library must not create installation state.
		installation.SeatID = "unpersisted-v1-preview"
	}
	if evidence != nil {
		if err := requireSourceCoherence(root, previous, evidence); err != nil {
			return nil, nil, nil, nil, err
		}
	}
	return buildSourceEvidence(root, objects, excludes, previous, evidence, installation.SeatID, observed...)
}

func verifyRecoverySource(root string, record publishRecoveryRecord) error {
	inventory, err := scanSourceObjects(root)
	if err != nil {
		return err
	}
	_, _, changed, removed, err := refreshSourceEvidence(root, inventory.Objects, record.Excludes, record.ContentLedger, record.Evidence, inventory)
	if err != nil {
		return err
	}
	if len(changed) != 0 || len(removed) != 0 {
		return errors.New("library files changed since the interrupted publish; retained recovery requires explicit reconciliation")
	}
	if !libraryflow.IsDerivedPath(record.IndexArtifact.Path) {
		return errors.New("recovery is missing its index identity")
	}
	digest, err := hashLocalFile(filepath.Join(root, filepath.FromSlash(record.IndexArtifact.Path)))
	if err != nil {
		return err
	}
	if digest != record.IndexArtifact.Hash {
		return errors.New("the built index changed since the interrupted publish; retained recovery was not overwritten")
	}
	return nil
}

func resumeBeforeBuild(alias, libraryID, root string, creds GroupS3Credentials, options publishOptions) (bool, error) {
	if options.MaxDeletes < 0 {
		return false, errors.New("--max-deletes cannot be negative")
	}
	if _, err := os.Stat(publishRecoveryPath(alias)); os.IsNotExist(err) {
		if options.FinishInterruptedPublish {
			return false, errors.New("there is no interrupted private-file cleanup to finish")
		}
		if _, repairErr := os.Stat(derivedEvidenceRepairPath(alias)); os.IsNotExist(repairErr) {
			return false, nil
		} else if repairErr != nil {
			return false, repairErr
		}
	} else if err != nil {
		return false, err
	}
	remote, err := openLibraryRemoteForCommand(alias, creds)
	if err != nil {
		return false, err
	}
	defer remote.Close()
	if recovered, err := recoverDerivedEvidenceRepair(alias, libraryID, root, remote); err != nil || recovered {
		return recovered, err
	}
	return recoverPublishBookkeeping(alias, libraryID, remote, root, options)
}

// captureSyncStageEvidence records what was downloaded before renaming it.
// Recovery must never replace this evidence with fresh observations.
func captureSyncStageEvidence(record *syncActivationRecord) error {
	installation, err := loadOrCreateInstallation()
	if err != nil {
		return err
	}
	inventory, err := scanSourceObjects(record.Stage)
	if err != nil {
		return err
	}
	ledger, evidence, _, _, err := buildSourceEvidence(record.Stage, inventory.Objects, record.SourceExcludes, nil, nil, installation.SeatID, inventory)
	if err != nil {
		return err
	}
	if err := requireSourceCoherence(record.Stage, ledger, evidence); err != nil {
		return err
	}
	fingerprint, err := sourceFingerprintFromContentLedger(ledger)
	if err != nil {
		return err
	}
	if fingerprint != record.RemoteSourceFingerprint {
		return errors.New("downloaded library changed before its activation evidence was saved")
	}
	record.StageLedger, record.StageEvidence = ledger, evidence
	record.StageRootID, record.Stage = evidence.Provenance.RootID, evidence.Provenance.Root
	return nil
}

func saveActivatedSourceBaseline(alias, root string, record syncActivationRecord) error {
	if record.Version != sourceEvidenceVersion || record.StageEvidence == nil || record.GenerationToken == "" {
		return errors.New("interrupted sync lacks verified staged file information; recovery was retained for reconciliation")
	}
	evidence := *record.StageEvidence
	if evidence.Provenance.Root != record.Stage || record.StageRootID == "" || evidence.Provenance.RootID != record.StageRootID {
		return errors.New("saved staged library identity is inconsistent; recovery was retained")
	}
	installation, err := loadInstallation()
	if err != nil {
		return err
	}
	current, err := captureSourceProvenance(root, installation.SeatID)
	if err != nil {
		return err
	}
	// Only the root path may change during activation. Directory identity,
	// seat, filesystem and all source files must still match the saved stage.
	evidence.Provenance.Root = current.Root
	inventory, err := scanSourceObjects(root)
	if err != nil {
		return err
	}
	_, _, changed, removed, err := refreshSourceEvidence(root, inventory.Objects, record.SourceExcludes, record.StageLedger, &evidence, inventory)
	if err != nil {
		return err
	}
	if len(changed) != 0 || len(removed) != 0 {
		return errors.New("downloaded library files changed before sync bookkeeping completed; local files and recovery were retained for reconciliation")
	}
	fingerprint, err := sourceFingerprintFromContentLedger(record.StageLedger)
	if err != nil || fingerprint != record.RemoteSourceFingerprint {
		return errors.New("saved staged files do not match the downloaded publication; recovery was retained")
	}
	return saveBaseline(alias, libraryBaseline{LibraryID: record.LibraryID, RemoteSourceFingerprint: record.RemoteSourceFingerprint,
		LocalSourceFingerprint: record.RemoteSourceFingerprint, Generation: record.Generation, GenerationToken: record.GenerationToken,
		CatalogChecksum: record.CatalogChecksum, ContentLedgerVersion: sourceEvidenceVersion, ContentLedger: record.StageLedger, Evidence: &evidence, UpdatedAt: time.Now()})
}

func saveRecoveredSyncBaseline(alias string, record syncActivationRecord) error {
	if record.Version == machineStateVersion && record.GenerationToken == "" {
		return saveBaseline(alias, libraryBaseline{LibraryID: record.LibraryID, RemoteSourceFingerprint: record.RemoteSourceFingerprint,
			LocalSourceFingerprint: record.RemoteSourceFingerprint, Generation: record.Generation, UpdatedAt: time.Now()})
	}
	return saveActivatedSourceBaseline(alias, record.Destination, record)
}
