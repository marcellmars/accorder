package cmd

import (
	"log"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	"github.com/go-playground/validator/v10"
)

const AppName = "accorder"

var (
	accorderConfigDir  string
	savedActionAliases string
	validate           *validator.Validate
	realUserConfigDir  string
)

func init() {
	if savedActionAliases != "" {
		return
	}
	configDir, err := os.UserConfigDir()
	if err != nil {
		log.Fatalln("Cannot read user config directory path:", err)
	}

	accorderConfigDir = filepath.Join(configDir, AppName)
	savedActionAliases = filepath.Join(accorderConfigDir, "action_aliases.json")
	sourceRegistryPath = filepath.Join(accorderConfigDir, "indices.json")
	realUserConfigDir = accorderConfigDir

	// Deliberately does NOT create the config dir or an empty alias file.
	// init() runs before kong parses arguments, so it cannot know whether
	// this is a mutating run or a read-only --show-config diagnostic; a
	// diagnostic that creates files is not a diagnostic. Directory
	// creation moved to the mutation layer (lockAliasConfig and
	// trySaveActionAliases), which only runs when something is written.
	initValidator()
}

func assertNotRealConfig(path string) {
	if !testing.Testing() || realUserConfigDir == "" {
		return
	}
	clean := filepath.Clean(path)
	if clean == realUserConfigDir || strings.HasPrefix(clean, realUserConfigDir+string(filepath.Separator)) {
		panic("accorder test attempted to touch the real user config: " + path +
			" (call testSetup(t) to isolate config to a temp dir)")
	}
}

func initValidator() {
	if validate != nil {
		return
	}
	validate = validator.New(validator.WithRequiredStructEnabled())
	validate.RegisterTagNameFunc(func(fld reflect.StructField) string {
		name := strings.SplitN(fld.Tag.Get("json"), ",", 2)[0]
		if name == "-" {
			return ""
		}
		return name
	})
	_ = validate.RegisterValidation("alias", func(fl validator.FieldLevel) bool {
		s := fl.Field().String()
		if s == "" {
			return false
		}
		for _, r := range s {
			isLetter := (r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z')
			isDigit := r >= '0' && r <= '9'
			isHyphen := r == '-'
			if !isLetter && !isDigit && !isHyphen {
				return false
			}
		}
		return true
	})
	_ = validate.RegisterValidation("personname", func(fl validator.FieldLevel) bool {
		s := fl.Field().String()
		if strings.TrimSpace(s) == "" {
			return false
		}
		for _, r := range s {
			if r == '/' || r == '\\' || r < 0x20 || r == 0x7f {
				return false
			}
		}
		return true
	})
}

// configDirPerm is 0700, not 0755, because the accorder config directory
// holds secrets.age, keys/*.s3.keys and motw_libraries.json. Those files are
// individually 0600, but a world-readable directory still enumerates them —
// keys/motw.s3.keys names a federation and reveals that credentials for it
// live on this machine.
const configDirPerm = 0o700

// ensureConfigDir creates the directory containing path with the
// credential-bearing mode. Every writer into the accorder config dir routes
// through this, so the directory's mode cannot depend on which writer
// happened to create it first.
//
// Note this does NOT retighten a directory that already exists: MkdirAll
// leaves an existing mode alone, so installs created by earlier versions
// stay at whatever they were. Fixing those is a migration, not a constant.
func ensureConfigDir(path string) error {
	return os.MkdirAll(filepath.Dir(path), configDirPerm)
}

func tryLoadActionAliases() ([]byte, error) {
	assertNotRealConfig(savedActionAliases)
	return os.ReadFile(savedActionAliases)
}

func loadActionAliases() []byte {
	savedConfBytes, err := tryLoadActionAliases()
	if os.IsNotExist(err) {
		// First run, or a read-only run before anything was ever saved.
		return []byte("{}")
	}
	if err != nil {
		log.Fatalln(err)
	}
	return savedConfBytes
}

func trySaveActionAliases(content []byte) error {
	assertNotRealConfig(savedActionAliases)
	if err := ensureConfigDir(savedActionAliases); err != nil {
		return err
	}
	tmp := savedActionAliases + ".tmp"
	if err := os.WriteFile(tmp, content, 0644); err != nil {
		return err
	}
	return os.Rename(tmp, savedActionAliases)
}

func saveActionAliases(content []byte) {
	if err := trySaveActionAliases(content); err != nil {
		log.Fatalln(err)
	}
}

func AccorderConfigDir() string {
	return accorderConfigDir
}
