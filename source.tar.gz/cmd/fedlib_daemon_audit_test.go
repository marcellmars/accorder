package cmd

import (
	"reflect"
	"testing"
)

// TestDaemonAudit_NoCredentialCreep verifies that FedlibShareLiveCmd — the
// daemon struct — never acquires fields that would give it access to root keys,
// build keys, or operator credentials. The daemon's serve key
// (keys/lib.s3.keys) is scoped to aggregate/* only; broader credentials must
// remain off-daemon.
//

// If this test breaks, someone added a credential field to the daemon struct.
// That is almost certainly wrong — move it to the operator command instead.
func TestDaemonAudit_NoCredentialCreep(t *testing.T) {
	forbidden := []string{
		"RootKeysFile",
		"BuildKeysFile",
		"OperatorRootKeysFile",
	}

	typ := reflect.TypeOf(FedlibShareLiveCmd{})
	for _, name := range forbidden {
		if _, found := typ.FieldByName(name); found {
			t.Errorf("FedlibShareLiveCmd has forbidden field %q — daemon must not hold root/build/operator keys", name)
		}
	}
}
