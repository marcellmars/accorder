package cmd

import (
	"accorder/pkg/fedlibinvite"
	"fmt"
	"os"
	"time"

	"github.com/alecthomas/kong"
)

type FedlibMembersOfferCmd struct {
	FedlibID    string `arg:"" name:"fedlib-id" help:"Federation identifier (see 'fedlib config set')."`
	Prefix      string `name:"prefix" help:"Prefix for the peer member (used in the aggregate index)." validate:"required"`
	Librarian   string `name:"librarian" help:"Display name for the librarian." validate:"required"`
	Endpoint    string `name:"endpoint" help:"Public https:// base URL of the aggregate serve (for the claim-callback URL; recalled from the federation descriptor when omitted)." validate:"omitempty,url"`
	OfferExpiry string `name:"offer-expiry" help:"Offer lifetime (e.g. 72h, 168h; default 168h; recalled from the federation descriptor when omitted)."`
}

func (c *FedlibMembersOfferCmd) Run(kctx *kong.Context) error {
	if err := validateAliasSafePrefix(c.Prefix); err != nil {
		return err
	}

	desc, err := requireFedlibDescriptor("fedlib members offer", c.FedlibID)
	if err != nil {
		return err
	}

	recalled := false
	for _, f := range []struct {
		flag  *string
		saved string
	}{
		{&c.Endpoint, desc.Endpoint},
		{&c.OfferExpiry, desc.OfferExpiry},
	} {
		if *f.flag == "" && f.saved != "" {
			*f.flag = f.saved
			recalled = true
		}
	}
	if recalled {
		fmt.Fprintf(os.Stderr, "fedlib members offer: defaults for fedlib %q recalled from %s\n", c.FedlibID, fedlibDescriptorPath())
	}
	if c.Endpoint == "" {
		return fmt.Errorf("fedlib members offer: --endpoint is required (or set it in the descriptor via 'fedlib config set %s --endpoint ...')", c.FedlibID)
	}

	var selected *kong.Node
	if kctx != nil {
		selected = kctx.Selected()
	}
	if err := validateSelectedTarget(selected, c, "fedlib members offer", ""); err != nil {
		return err
	}
	offersDir := inviteOffersDir(c.FedlibID)

	token, err := fedlibinvite.NewOfferToken()
	if err != nil {
		return err
	}

	expiry := fedlibinvite.DefaultOfferTTL
	if c.OfferExpiry != "" {
		expiry, err = time.ParseDuration(c.OfferExpiry)
		if err != nil {
			return fmt.Errorf("fedlib members offer: parse expiry %q: %w", c.OfferExpiry, err)
		}
	}

	offer, err := fedlibinvite.SealPeerOffer(token, c.FedlibID, c.Prefix, c.Librarian, time.Now().Add(expiry))
	if err != nil {
		return fmt.Errorf("fedlib members offer: seal: %w", err)
	}
	offer.OfferKind = "peer"

	if err := fedlibinvite.WriteOffer(offersDir, token, offer); err != nil {
		return err
	}
	if _, err := fedlibinvite.SweepExpired(offersDir); err != nil {
		fmt.Fprintf(os.Stderr, "fedlib members offer: sweep expired offers: %v\n", err)
	}

	claimURL := c.Endpoint + "/invite/" + token
	fmt.Fprintln(os.Stdout, claimURL)

	fmt.Fprintf(os.Stderr, "fedlib members offer: peer offer created for %s (prefix: %s)\n", c.Librarian, c.Prefix)
	fmt.Fprintf(os.Stderr, "  claim URL: %s\n", claimURL)
	fmt.Fprintf(os.Stderr, "  expires: %s\n", offer.Expires.Format(time.RFC3339))
	fmt.Fprintf(os.Stderr, "\nThe librarian should run:\n")
	fmt.Fprintf(os.Stderr, "  %s\n", joinCommandLine(c.Prefix, claimURL, "--endpoint 'https://your-host/'"))

	return nil
}
