//go:build linux && !tailscale

package cmd

import (
	"accorder/pkg/calibre"
	"bufio"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"syscall"
	"testing"
	"time"
)

// Opt-in, separate-process whole-command measurement. Setup reads catalog text
// only and synthesizes sparse formats; it never opens a librarian's payloads.
func TestFastBuildRepresentativeCommand(t *testing.T) {
	mode, root := os.Getenv("ACCORDER_COMMAND_PERF_MODE"), os.Getenv("ACCORDER_COMMAND_PERF_ROOT")
	if mode == "" {
		t.Skip("explicit disposable fixture and catalog required")
	}
	if root == "" || !filepath.IsAbs(root) || filepath.Base(root) != "library" {
		t.Fatal("fixture must be an explicit absolute scratch/library directory")
	}
	if mode == "prepare" {
		prepareRepresentativeCommand(t, root)
		return
	}
	if _, err := os.Stat(filepath.Join(filepath.Dir(root), "fixture.json")); err != nil {
		t.Fatal("missing disposable fixture marker")
	}
	accorderConfigDir = filepath.Join(filepath.Dir(root), "config")
	if err := os.MkdirAll(accorderConfigDir, 0o700); err != nil {
		t.Fatal(err)
	}
	build := fastBuildCommand(root)
	build.Index, build.InPipeline = nil, false // normal build: SQL, render, index and evidence
	var before, after syscall.Rusage
	if err := syscall.Getrusage(syscall.RUSAGE_SELF, &before); err != nil {
		t.Fatal(err)
	}
	start := time.Now()
	switch mode {
	case "build":
		if err := build.Run(nil); err != nil {
			t.Fatal(err)
		}
	case "upload-preparation":
		upload := &LibUploadCmd{GroupLib: build.GroupLib}
		candidate, _, err := upload.prepareUploadCandidate(nil, resolveUploadExcludes(root, nil))
		if err != nil || candidate.Change == nil {
			t.Fatalf("prepare upload: %v", err)
		}
	case "index-control":
		search := &calibre.MotwSearch{JsonlPath: build.JsonLPath, IndexPath: filepath.Join(filepath.Dir(root), "control-index")}
		index, err := search.BuildIndex()
		if err != nil {
			t.Fatal(err)
		}
		if err := search.CompressToFile(index); err != nil {
			t.Fatal(err)
		}
	default:
		t.Fatalf("unknown measurement %q", mode)
	}
	elapsed := time.Since(start)
	if err := syscall.Getrusage(syscall.RUSAGE_SELF, &after); err != nil {
		t.Fatal(err)
	}
	row := map[string]any{"mode": mode, "wall_seconds": elapsed.Seconds(), "cpu_seconds": float64(after.Utime.Nano()+after.Stime.Nano()-before.Utime.Nano()-before.Stime.Nano()) / 1e9, "process_peak_rss_kib": after.Maxrss, "metadata_cache": os.Getenv("ACCORDER_COMMAND_PERF_CACHE"), "fixture_root": root}
	raw, err := json.Marshal(row)
	if err != nil {
		t.Fatal(err)
	}
	t.Log(string(raw))
}

func prepareRepresentativeCommand(t *testing.T, root string) {
	t.Helper()
	if _, err := os.Stat(root); !os.IsNotExist(err) {
		t.Fatal("refusing to replace an existing fixture")
	}
	if err := os.MkdirAll(root, 0o700); err != nil {
		t.Fatal(err)
	}
	corpus, err := os.Open(os.Getenv("ACCORDER_COMMAND_PERF_CATALOG"))
	if err != nil {
		t.Fatal(err)
	}
	defer corpus.Close()
	db, err := sql.Open("sqlite", filepath.Join(root, "metadata.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	if _, err := db.Exec(publishCalibreTestSchema); err != nil {
		t.Fatal(err)
	}
	tx, err := db.Begin()
	if err != nil {
		t.Fatal(err)
	}
	defer tx.Rollback()
	statements := map[string]*sql.Stmt{}
	execute := func(query string, values ...any) {
		t.Helper()
		statement := statements[query]
		if statement == nil {
			var err error
			statement, err = tx.Prepare(query)
			if err != nil {
				t.Fatal(err)
			}
			statements[query] = statement
		}
		if _, err := statement.Exec(values...); err != nil {
			t.Fatal(err)
		}
	}
	defer func() {
		for _, statement := range statements {
			_ = statement.Close()
		}
	}()
	const books = 18579
	const payloadSize = int64(2626*(1<<30)/10) / (2 * books)
	scanner := bufio.NewScanner(corpus)
	scanner.Buffer(make([]byte, 64*1024), 8*1024*1024)
	digest, bytes := sha256.New(), 0
	for id := 1; id <= books; id++ {
		if !scanner.Scan() {
			t.Fatalf("catalog ended early: %v", scanner.Err())
		}
		line := append(append([]byte(nil), scanner.Bytes()...), '\n')
		_, _ = digest.Write(line)
		bytes += len(line)
		var book calibre.Book
		if err := json.Unmarshal(line, &book); err != nil {
			t.Fatal(err)
		}
		directory := fmt.Sprintf("Author %03d/Book %05d", id%300, id)
		execute("INSERT INTO books VALUES(?,?,?,?,?,?,?)", id, book.Title, book.TitleSort, book.Pubdate, book.LastModified, fmt.Sprintf("perf-book-%d", id), directory)
		execute("INSERT INTO comments VALUES(?,?,?)", id, id, book.Abstract)
		for n, name := range book.Authors {
			key := id*100 + n
			execute("INSERT INTO authors VALUES(?,?)", key, name)
			execute("INSERT INTO books_authors_link VALUES(?,?)", id, key)
		}
		for n, name := range book.Tags {
			key := id*1000 + n
			execute("INSERT INTO tags VALUES(?,?)", key, name)
			execute("INSERT INTO books_tags_link VALUES(?,?)", id, key)
		}
		execute("INSERT INTO publishers VALUES(?,?)", id, book.Publisher)
		execute("INSERT INTO books_publishers_link VALUES(?,?)", id, id)
		execute("INSERT INTO series VALUES(?,?)", id, book.Series)
		execute("INSERT INTO books_series_link VALUES(?,?)", id, id)
		for n, name := range book.Languages {
			key := id*100 + n
			execute("INSERT INTO languages VALUES(?,?)", key, name)
			execute("INSERT INTO books_languages_link VALUES(?,?)", id, key)
		}
		for _, identifier := range book.Identifiers {
			execute("INSERT INTO identifiers VALUES(?,?,?)", id, identifier.Scheme, identifier.Code)
		}
		if err := os.MkdirAll(filepath.Join(root, directory), 0o700); err != nil {
			t.Fatal(err)
		}
		for n, format := range []string{"epub", "pdf"} {
			execute("INSERT INTO data VALUES(?,?,?,?,?)", 2*id+n, id, strings.ToUpper(format), payloadSize, "book")
			file, err := os.Create(filepath.Join(root, directory, "book."+format))
			if err != nil {
				t.Fatal(err)
			}
			if err := file.Truncate(payloadSize); err != nil {
				_ = file.Close()
				t.Fatal(err)
			}
			if err := file.Close(); err != nil {
				t.Fatal(err)
			}
		}
	}
	for _, table := range []string{"data", "comments", "identifiers", "books_authors_link", "books_tags_link", "books_publishers_link", "books_series_link", "books_languages_link"} {
		execute("CREATE INDEX " + table + "_book ON " + table + "(book)")
	}
	if err := tx.Commit(); err != nil {
		t.Fatal(err)
	}
	if err := db.Close(); err != nil {
		t.Fatal(err)
	}
	row := map[string]any{"books": books, "format_files": 2 * books, "logical_format_bytes": payloadSize * 2 * books, "catalog_sample_bytes": bytes, "catalog_sample_sha256": hex.EncodeToString(digest.Sum(nil)), "covers": "absent; no real cover payload copied", "fixture": "real catalog text in a generated indexed SQLite schema, synthetic paths and sparse two-format payloads"}
	raw, err := json.MarshalIndent(row, "", "  ")
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(filepath.Dir(root), "fixture.json"), raw, 0o600); err != nil {
		t.Fatal(err)
	}
	t.Log(string(raw))
}
