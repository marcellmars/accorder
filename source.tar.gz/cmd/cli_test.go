//go:build !tailscale

package cmd

import (
	"encoding/json"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	"github.com/alecthomas/kong"
)

// ═══════════════════════════════════════════════════════════════════
// Test 1: PersistsConfiguration
// ═══════════════════════════════════════════════════════════════════

func TestActionAlias_PersistsConfiguration(t *testing.T) {
	libDir := testSetup(t)

	args := []string{
		"lib", "build", "prod",
		"--calibrepath=" + libDir,
		"--librarian=Alice",
		"--libraryID=550e8400-e29b-41d4-a716-446655440000",
	}
	parseCLI(t, args)

	alias := readAlias(t, "prod")
	if !alias.Exists() {
		t.Fatal("alias 'prod' not found in config file")
	}

	build := alias.Get("lib.build")
	if !build.Exists() {
		t.Fatal("lib.build not found under alias 'prod'")
	}

	checks := map[string]string{
		"calibrepath": libDir,
		"librarian":   "Alice",
		"libraryID":   "550e8400-e29b-41d4-a716-446655440000",
	}
	for key, want := range checks {
		got := build.Get(key).String()
		if got != want {
			t.Errorf("prod.lib.build.%s = %q, want %q", key, got, want)
		}
	}
}

// Operator-settable v5 composition flags: --dictID and --fedlibPrefix were
// kong:"-" (join-only); they are now real CLI flags so the server-side recompile
// path (deploy COMPILE_INDEXES) can assign per-member DictIDs without going
// through invite/join. This asserts they bind and persist.
func TestActionAlias_PersistsDictIDAndFedlibPrefix(t *testing.T) {
	libDir := testSetup(t)

	args := []string{
		"lib", "build", "member7",
		"--calibrepath=" + libDir,
		"--librarian=Alice",
		"--dictID=7",
		"--fedlibPrefix=alice",
	}
	parseCLI(t, args)

	build := readAlias(t, "member7").Get("lib.build")
	if !build.Exists() {
		t.Fatal("lib.build not found under alias 'member7'")
	}
	if got := build.Get("dictID").Uint(); got != 7 {
		t.Errorf("dictID = %d, want 7", got)
	}
	if got := build.Get("fedlibPrefix").String(); got != "alice" {
		t.Errorf("fedlibPrefix = %q, want %q", got, "alice")
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test 2: ReusesConfiguration (no clobbering)
// ═══════════════════════════════════════════════════════════════════

func TestActionAlias_ReusesConfiguration(t *testing.T) {
	libDir := testSetup(t)

	// First run: save flags.
	args := []string{
		"lib", "build", "prod",
		"--calibrepath=" + libDir,
		"--librarian=Alice",
		"--libraryID=550e8400-e29b-41d4-a716-446655440000",
	}
	parseCLI(t, args)

	// Second run: alias-only (no explicit flags).
	cli, ctx := parseCLI(t, []string{"lib", "build", "prod"})

	// Verify the target has loaded saved values (not clobbered to zero).
	target := ctx.Selected().Target.Interface().(LibBuildCmd)
	if target.Librarian != "Alice" {
		t.Errorf("target.Librarian = %q, want Alice (clobbered?)", target.Librarian)
	}
	if target.CalibreDirectory != libDir {
		t.Errorf("target.CalibreDirectory = %q, want %s", target.CalibreDirectory, libDir)
	}

	// Also verify via CLI struct.
	if cli.Lib.Build.Librarian != "Alice" {
		t.Errorf("cli.Lib.Build.Librarian = %q, want Alice", cli.Lib.Build.Librarian)
	}

	// Verify config file still has the original values.
	alias := readAlias(t, "prod")
	if alias.Get("lib.build.librarian").String() != "Alice" {
		t.Error("config file clobbered: librarian is no longer Alice")
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test 3: SharesAcrossGroup (sharedgroup:"motw" and sharedgroup:"s3creds")
// ═══════════════════════════════════════════════════════════════════

func TestActionAlias_SharesAcrossGroup(t *testing.T) {
	libDir := testSetup(t)

	// Save via lib build — lib fields should propagate to peers.
	args := []string{
		"lib", "build", "shared-test",
		"--calibrepath=" + libDir,
		"--librarian=Bob",
		"--libraryID=550e8400-e29b-41d4-a716-446655440000",
	}
	parseCLI(t, args)

	alias := readAlias(t, "shared-test")

	// Check that lib upload inherited the lib fields.
	upload := alias.Get("lib.upload")
	if !upload.Exists() {
		t.Fatal("lib.upload not found — sharedgroup lib propagation failed")
	}
	if upload.Get("calibrepath").String() != libDir {
		t.Errorf("lib.upload.calibrepath = %q, want %s", upload.Get("calibrepath").String(), libDir)
	}
	if upload.Get("librarian").String() != "Bob" {
		t.Errorf("lib.upload.librarian = %q, want Bob", upload.Get("librarian").String())
	}

	// Check that lib import also got the lib fields.
	imp := alias.Get("lib.import")
	if !imp.Exists() {
		t.Fatal("lib.import not found — sharedgroup lib propagation failed")
	}
	if imp.Get("calibrepath").String() != libDir {
		t.Errorf("lib.import.calibrepath = %q, want %s", imp.Get("calibrepath").String(), libDir)
	}

	// B1/pq-21: credentials never persist to the alias file, and bucket
	// no longer inherits across commands via the s3creds sharedgroup.
	args2 := []string{
		"lib", "upload", "shared-test",
		"--bucket=test-bucket/prefix",
		"--s3-access-key=AKIATEST",
		"--s3-secret-key=secret123",
		"--s3-provider=Wasabi",
		"--s3-endpoint=s3.wasabisys.com",
	}
	parseCLI(t, args2)

	alias = readAlias(t, "shared-test")
	upload = alias.Get("lib.upload")
	if upload.Get("bucket").String() != "test-bucket/prefix" {
		t.Errorf("lib.upload.bucket = %q, want test-bucket/prefix (per-command persistence)", upload.Get("bucket").String())
	}
	publish := alias.Get("lib.publish")
	if publish.Get("bucket").String() == "test-bucket/prefix" {
		t.Error("lib.publish inherited bucket via sharedgroup — pq-21 de-share regressed")
	}
	raw := alias.Raw
	for _, credKey := range []string{"s3-access-key", "s3-secret-key", "s3-provider", "s3-endpoint"} {
		if strings.Contains(raw, credKey) {
			t.Errorf("credential key %q found in alias file — B1 alias:\"-\" exclusion regressed", credKey)
		}
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test 4: MergesIncrementalChanges
// ═══════════════════════════════════════════════════════════════════

func TestActionAlias_MergesIncrementalChanges(t *testing.T) {
	libDir := testSetup(t)

	// First run: set librarian and calibrepath.
	args1 := []string{
		"lib", "build", "incremental",
		"--calibrepath=" + libDir,
		"--librarian=Alice",
		"--libraryID=550e8400-e29b-41d4-a716-446655440000",
	}
	parseCLI(t, args1)

	// Second run: update only librarian.
	args2 := []string{
		"lib", "build", "incremental",
		"--librarian=Bob",
	}
	parseCLI(t, args2)

	alias := readAlias(t, "incremental")
	build := alias.Get("lib.build")

	// librarian should be updated.
	if build.Get("librarian").String() != "Bob" {
		t.Errorf("librarian = %q, want Bob", build.Get("librarian").String())
	}

	// calibrepath should be preserved (not clobbered).
	if build.Get("calibrepath").String() != libDir {
		t.Errorf("calibrepath = %q, want %s (clobbered by incremental update?)",
			build.Get("calibrepath").String(), libDir)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test 5: ValidatesRequiredFields
// ═══════════════════════════════════════════════════════════════════

func TestActionAlias_ValidatesRequiredFields(t *testing.T) {
	testSetup(t)

	// Run with only partial flags — missing required fields should produce validation errors.
	// Kong calls AfterApply automatically during Parse, so the validation error
	// surfaces as a Parse error.
	//

	// Note: lib build no longer has hard-required identity flags (the
	// setup-default mint fills librarian/libraryID); fedlib build's output-path
	// and fedlib share live's aggregate-path requiredness both moved to Run()
	// (descriptor recall happens there), so this exercises lib upload's
	// parse-required --bucket instead.
	cli := &CLI{}
	app, err := kong.New(cli,
		kong.Name("test"),
		kong.Exit(func(int) {}),
		kong.Bind(cli),
	)
	if err != nil {
		t.Fatalf("kong.New: %v", err)
	}

	// Provide no flags; --bucket is required.
	args := []string{
		"lib", "upload", "partial",
	}
	_, err = app.Parse(args)
	if err == nil {
		t.Fatal("expected validation error for missing required fields, got nil")
	}

	errMsg := err.Error()
	if !strings.Contains(errMsg, "missing required flags") {
		t.Errorf("expected 'missing required flags' in error, got: %s", errMsg)
	}

	// Should mention the missing fields.
	if !strings.Contains(errMsg, "--bucket") {
		t.Errorf("error should mention --bucket, got: %s", errMsg)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test 6: IsolatesAliases
// ═══════════════════════════════════════════════════════════════════

func TestActionAlias_IsolatesAliases(t *testing.T) {
	libDir := testSetup(t)

	// Create two separate directories for alpha and beta.
	alphaDir := filepath.Join(libDir, "alpha")
	betaDir := filepath.Join(libDir, "beta")
	_ = os.MkdirAll(alphaDir, 0755)
	_ = os.MkdirAll(betaDir, 0755)

	// Create alias "alpha".
	args1 := []string{
		"lib", "build", "alpha",
		"--calibrepath=" + alphaDir,
		"--librarian=AlphaUser",
		"--libraryID=550e8400-e29b-41d4-a716-446655440000",
	}
	parseCLI(t, args1)

	// Create alias "beta" with different values.
	args2 := []string{
		"lib", "build", "beta",
		"--calibrepath=" + betaDir,
		"--librarian=BetaUser",
		"--libraryID=660e8400-e29b-41d4-a716-446655440000",
	}
	parseCLI(t, args2)

	// Load "alpha" and verify it was not affected by "beta".
	alias := readAlias(t, "alpha")
	if alias.Get("lib.build.librarian").String() != "AlphaUser" {
		t.Error("alpha.lib.build.librarian was contaminated by beta")
	}
	if alias.Get("lib.build.calibrepath").String() != alphaDir {
		t.Error("alpha.lib.build.calibrepath was contaminated by beta")
	}

	// Load "beta" and verify correctness.
	beta := readAlias(t, "beta")
	if beta.Get("lib.build.librarian").String() != "BetaUser" {
		t.Error("beta.lib.build.librarian incorrect")
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test 7: NavigateByJSONPathInitializesPointers
// ═══════════════════════════════════════════════════════════════════

func TestNavigateByJSONPathInitializesPointers(t *testing.T) {

	// Test that navigateByJSONPath correctly navigates struct hierarchies
	// and initializes nil pointer fields along the path.
	type Inner struct {
		Value string `json:"value"`
	}
	type Middle struct {
		Inner *Inner `json:"inner"`
	}
	type Outer struct {
		Middle Middle `json:"middle"`
	}

	outer := &Outer{}
	result, err := navigateByJSONPath(reflect.ValueOf(outer), []string{"middle", "inner", "value"})
	if err != nil {
		t.Fatalf("navigateByJSONPath: %v", err)
	}
	if !result.IsValid() {
		t.Fatal("result is not valid")
	}

	// The nil *Inner should have been initialized.
	if outer.Middle.Inner == nil {
		t.Fatal("pointer was not initialized by navigateByJSONPath")
	}

	// Set a value through the result.
	result.SetString("hello")
	if outer.Middle.Inner.Value != "hello" {
		t.Errorf("value = %q, want hello", outer.Middle.Inner.Value)
	}

	// Test error case: invalid path.
	_, err = navigateByJSONPath(reflect.ValueOf(outer), []string{"nonexistent"})
	if err == nil {
		t.Fatal("expected error for nonexistent path, got nil")
	}

	// Test that the function also works with an already-used alias config
	// being unmarshalled into a CLI struct.
	cli := &CLI{}
	savedConfig := `{"lib":{"build":{"librarian":"TestUser","calibrepath":"/test/path","libraryID":"550e8400-e29b-41d4-a716-446655440000"}}}`
	if err := json.Unmarshal([]byte(savedConfig), cli); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}

	result, err = navigateByJSONPath(reflect.ValueOf(cli), []string{"lib", "build"})
	if err != nil {
		t.Fatalf("navigateByJSONPath for cli: %v", err)
	}
	if !result.IsValid() {
		t.Fatal("cli navigation result is not valid")
	}

	build := result.Interface().(LibBuildCmd)
	if build.Librarian != "TestUser" {
		t.Errorf("build.Librarian = %q, want TestUser", build.Librarian)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test 8: MotwUpload_FilesFlag
// ═══════════════════════════════════════════════════════════════════

func TestLibUpload_FilesFlag(t *testing.T) {
	libDir := testSetup(t)
	cli, _ := parseCLI(t, []string{
		"lib", "upload", "copy-test",
		"--calibrepath", libDir,
		"--bucket=test-bucket",
		"--s3-access-key=AK", "--s3-secret-key=SK",
		"--s3-provider=Wasabi", "--s3-endpoint=s3.example.com",
		"--librarian=TestLib", "--libraryID=550e8400-e29b-41d4-a716-446655440000",
		"--files", "static/library_index.zst,_GENERATION",
	})
	got := cli.Lib.Upload.Files
	if len(got) != 2 || got[0] != "static/library_index.zst" || got[1] != "_GENERATION" {
		t.Errorf("Files = %v, want [static/library_index.zst _GENERATION]", got)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test 9: MotwUpload_ListFlag
// ═══════════════════════════════════════════════════════════════════

func TestLibUpload_ListFlag(t *testing.T) {
	libDir := testSetup(t)
	listFile := filepath.Join(libDir, "upload-list.txt")
	os.WriteFile(listFile, []byte("# comment\nstatic/library_index.zst\n\n_GENERATION\n"), 0644)

	cli, _ := parseCLI(t, []string{
		"lib", "upload", "list-test",
		"--calibrepath", libDir,
		"--bucket=test-bucket",
		"--s3-access-key=AK", "--s3-secret-key=SK",
		"--s3-provider=Wasabi", "--s3-endpoint=s3.example.com",
		"--librarian=TestLib", "--libraryID=550e8400-e29b-41d4-a716-446655440000",
		"--list", listFile,
	})
	if cli.Lib.Upload.ListFile != listFile {
		t.Errorf("ListFile = %q, want %q", cli.Lib.Upload.ListFile, listFile)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test 10: MotwUpload_FilesFlagNotPersistedToAlias
// ═══════════════════════════════════════════════════════════════════

func TestLibUpload_FilesFlagNotPersistedToAlias(t *testing.T) {
	libDir := testSetup(t)
	parseCLI(t, []string{
		"lib", "upload", "persist-test",
		"--calibrepath", libDir,
		"--bucket=test-bucket",
		"--s3-access-key=AK", "--s3-secret-key=SK",
		"--s3-provider=Wasabi", "--s3-endpoint=s3.example.com",
		"--librarian=TestLib", "--libraryID=550e8400-e29b-41d4-a716-446655440000",
		"--files", "a.txt",
	})
	alias := readAlias(t, "persist-test")
	upload := alias.Get("lib.upload")
	if upload.Get("files").Exists() {
		t.Error("--files should not be persisted to alias (json:\"-\")")
	}
	if upload.Get("list").Exists() {
		t.Error("--list should not be persisted to alias (json:\"-\")")
	}

	// S3 credentials should still be persisted
	if upload.Get("bucket").String() != "test-bucket" {
		t.Errorf("bucket not persisted: got %q", upload.Get("bucket").String())
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test 11: ValidateRelativePaths
// ═══════════════════════════════════════════════════════════════════

func TestValidateRelativePaths(t *testing.T) {

	// Valid
	if err := validateRelativePaths([]string{"static/library_index.zst", "_GENERATION"}); err != nil {
		t.Errorf("valid paths rejected: %v", err)
	}

	// Absolute path
	if err := validateRelativePaths([]string{"/etc/passwd"}); err == nil {
		t.Error("absolute path should be rejected")
	}

	// Traversal
	if err := validateRelativePaths([]string{"../secret"}); err == nil {
		t.Error("path traversal should be rejected")
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test 12: ParseListFile
// ═══════════════════════════════════════════════════════════════════

func TestParseListFile(t *testing.T) {
	tmp := t.TempDir()
	listPath := filepath.Join(tmp, "list.txt")
	os.WriteFile(listPath, []byte("# header\nstatic/library_index.zst\n\n_GENERATION\n# footer\n"), 0644)

	got, err := parseListFile(listPath)
	if err != nil {
		t.Fatalf("parseListFile: %v", err)
	}
	want := []string{"static/library_index.zst", "_GENERATION"}
	if len(got) != len(want) {
		t.Fatalf("got %d paths, want %d", len(got), len(want))
	}
	for i := range want {
		if got[i] != want[i] {
			t.Errorf("path[%d] = %q, want %q", i, got[i], want[i])
		}
	}
}
