package cmd

import (
	"fmt"
	"io"
	"os"
	"time"

	"github.com/charmbracelet/bubbles/progress"
	"golang.org/x/term"
)

// progressReader wraps an io.Reader and renders an in-place download progress
// bar on stderr as bytes flow through it. The index-sync paths
// (downloadFull / rangeFetchTail) stream a remote MWSC index over a
// possibly-slow Tor circuit; without feedback a multi-MiB pull looks hung. This
// replaces the old rclone-stats line-after-line printer (removed with the rclone
// http backend) with a single, in-place bar.
//
// The bar is determinate when total > 0 (Content-Length known) and falls back to
// a byte/rate counter otherwise. Rendering is throttled (~10 fps) and TTY-gated:
// when stderr is not a terminal (piped, CI, tests) it draws nothing, so logs and
// test output stay clean.
type progressReader struct {
	r        io.Reader
	total    int64
	read     int64
	label    string
	bar      progress.Model
	tty      bool
	start    time.Time
	lastDraw time.Time
	open     bool // a bar line is currently on screen, awaiting a terminating newline
}

func newProgressReader(r io.Reader, total int64, label string) *progressReader {
	pr := &progressReader{
		r:     r,
		total: total,
		label: label,
		tty:   term.IsTerminal(int(os.Stderr.Fd())),
		start: time.Now(),
	}
	if pr.tty {
		pr.bar = progress.New(progress.WithDefaultGradient(), progress.WithoutPercentage())
		pr.bar.Width = 32
	}
	return pr
}

func (pr *progressReader) Read(p []byte) (int, error) {
	n, err := pr.r.Read(p)
	pr.read += int64(n)
	if err == io.EOF {
		pr.draw(true)
	} else if err == nil {
		pr.draw(false)
	}
	return n, err
}

func (pr *progressReader) draw(final bool) {
	if !pr.tty {
		return
	}
	now := time.Now()
	if !final && now.Sub(pr.lastDraw) < 100*time.Millisecond {
		return
	}
	pr.lastDraw = now
	pr.open = true

	rate := int64(0)
	if elapsed := now.Sub(pr.start).Seconds(); elapsed > 0 {
		rate = int64(float64(pr.read) / elapsed)
	}
	if pr.total > 0 {
		ratio := float64(pr.read) / float64(pr.total)
		if ratio > 1 {
			ratio = 1
		}
		fmt.Fprintf(os.Stderr, "\r%s %s %5.1f%%  %s / %s  %s/s     ",
			pr.label, pr.bar.ViewAs(ratio), ratio*100,
			humanIEC(pr.read), humanIEC(pr.total), humanIEC(rate))
	} else {
		fmt.Fprintf(os.Stderr, "\r%s  %s  %s/s     ", pr.label, humanIEC(pr.read), humanIEC(rate))
	}
	if final {
		fmt.Fprintln(os.Stderr)
		pr.open = false
	}
}

// finish terminates the bar line cleanly if one is still on screen — call it on
// an error path where EOF was never reached, so the next message starts on its
// own line. Safe to call multiple times and on a non-TTY.
func (pr *progressReader) finish() {
	if pr.tty && pr.open {
		fmt.Fprintln(os.Stderr)
		pr.open = false
	}
}

// humanIEC formats a byte count in IEC units (KiB, MiB, …).
func humanIEC(n int64) string {
	const unit = 1024
	if n < unit {
		return fmt.Sprintf("%d B", n)
	}
	div, exp := int64(unit), 0
	for v := n / unit; v >= unit; v /= unit {
		div *= unit
		exp++
	}
	return fmt.Sprintf("%.1f %ciB", float64(n)/float64(div), "KMGTPE"[exp])
}
