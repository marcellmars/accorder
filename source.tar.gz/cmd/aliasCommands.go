package cmd

import (
	"encoding/json"
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"reflect"
	"sort"
	"strings"

	"text/tabwriter"

	"github.com/alecthomas/kong"
	"github.com/tidwall/gjson"
	"github.com/tidwall/sjson"
	"golang.org/x/term"
)

type AliasesCmd struct {
	List        AliasListCmd         `cmd:"" help:"List saved action aliases, optionally filtered by action family."`
	Show        AliasShowCmd         `cmd:"" help:"Show the full saved tree of an action alias."`
	Delete      AliasDeleteCmd       `cmd:"" help:"Delete a saved action alias."`
	Rename      AliasRenameCmd       `cmd:"" help:"Rename a saved action alias."`
	Copy        AliasCopyCmd         `cmd:"" help:"Copy a saved action alias to a new name."`
	Validate    AliasValidateCmd     `cmd:"" help:"Validate all saved action aliases."`
	Prune       AliasPruneCmd        `cmd:"" help:"Detect and remove dead keys, default shadows, and empty nodes from saved action aliases (dry-run by default)."`
	FindCalibre ConfigFindCalibreCmd `cmd:"" help:"Find Calibre libraries interactively."`
}

type AliasListCmd struct {
	Filter string `arg:"" optional:"" help:"Filter by action family (e.g. lib, fedlib, lib.build) or narrow to one action alias (e.g. lib.biopolitics). An action alias is listed when it carries the subtree; one action alias can appear under several families."`
}

func (c *AliasListCmd) Run() error {
	data := loadActionAliases()
	names := GetAllAliases()
	if len(names) == 0 {
		fmt.Println("No saved profiles.")
		return nil
	}
	sort.Strings(names)

	if c.Filter == "" {
		renderProfileFamilies(data, names)
		return nil
	}

	matched := filterAliasesBySubtree(data, names, c.Filter)
	actionPath := c.Filter
	if len(matched) == 0 {
		prefixPath, candidate := "", c.Filter
		if idx := strings.LastIndex(c.Filter, "."); idx >= 0 {
			prefixPath, candidate = c.Filter[:idx], c.Filter[idx+1:]
		}
		pool := names
		if prefixPath != "" {
			pool = filterAliasesBySubtree(data, names, prefixPath)
		}
		matched = matchProfileName(pool, candidate)
		actionPath = prefixPath
	}
	if len(matched) == 0 {
		return fmt.Errorf("no profile matches %q (tried %q as an action path and as a profile name)", c.Filter, c.Filter)
	}
	if actionPath == "" {
		renderProfileFamilies(data, matched)
		return nil
	}
	renderProfileColumns(data, matched, actionPath)
	return nil
}

func filterAliasesBySubtree(data []byte, names []string, dotPath string) []string {
	var result []string
	for _, name := range names {
		if gjson.GetBytes(data, name+"."+dotPath).Exists() {
			result = append(result, name)
		}
	}
	return result
}

func matchProfileName(candidates []string, name string) []string {
	var prefix []string
	for _, c := range candidates {
		if c == name {
			return []string{c}
		}
		if strings.HasPrefix(c, name) {
			prefix = append(prefix, c)
		}
	}
	return prefix
}

var familyColumns = []struct {
	prefix  string
	headers []string
	paths   []string
}{
	{
		prefix:  "lib",
		headers: []string{"CALIBREPATH", "LIBRARIAN", "LIBRARYID"},
		paths:   []string{"lib.build.calibrepath", "lib.build.librarian", "lib.build.libraryID"},
	},
	{
		prefix:  "fedlib",
		headers: []string{"BUCKET", "UPLOAD-PREFIX", "LISTEN", "MODE"},
		paths: []string{"fedlib.share.live.bucket", "fedlib.share.live.upload-prefix",
			"fedlib.share.live.listen", "fedlib.share.live.mode"},
	},
}

func columnsFor(actionPath string) (headers, paths []string, ok bool) {
	best := -1
	for i, fc := range familyColumns {
		if actionPath == fc.prefix || strings.HasPrefix(actionPath, fc.prefix+".") {
			if best == -1 || len(fc.prefix) > len(familyColumns[best].prefix) {
				best = i
			}
		}
	}
	if best == -1 {
		return nil, nil, false
	}
	return familyColumns[best].headers, familyColumns[best].paths, true
}

func renderProfileFamilies(data []byte, names []string) {
	tw := tabwriter.NewWriter(os.Stdout, 0, 0, 2, ' ', 0)
	fmt.Fprintf(tw, "PROFILE\tACTIONS\n")
	for _, name := range names {
		var families []string
		gjson.GetBytes(data, name).ForEach(func(key, _ gjson.Result) bool {
			families = append(families, key.String())
			return true
		})
		sort.Strings(families)
		fmt.Fprintf(tw, "%s\t%s\n", name, strings.Join(families, ", "))
	}
	tw.Flush()
}

func renderProfileColumns(data []byte, names []string, actionPath string) {
	headers, paths, ok := columnsFor(actionPath)
	if !ok {
		renderProfileFamilies(data, names)
		return
	}
	tw := tabwriter.NewWriter(os.Stdout, 0, 0, 2, ' ', 0)
	fmt.Fprintf(tw, "PROFILE\t%s\n", strings.Join(headers, "\t"))
	for _, name := range names {
		row := []string{name}
		for _, p := range paths {
			if v := gjson.GetBytes(data, name+"."+p); v.Exists() {
				row = append(row, v.String())
			} else {
				row = append(row, "-")
			}
		}
		fmt.Fprintf(tw, "%s\n", strings.Join(row, "\t"))
	}
	tw.Flush()
}

type AliasShowCmd struct {
	Name string `arg:"" help:"Alias name to show." validate:"required"`
}

func (c *AliasShowCmd) Run(ctx *kong.Context) error {
	data := loadActionAliases()
	result := gjson.GetBytes(data, escapeGJSONKey(c.Name))
	if !result.Exists() {
		return fmt.Errorf("alias %q not found", c.Name)
	}

	var out strings.Builder
	fmt.Fprintf(&out, "Alias: %s\n", c.Name)
	if err := renderAliasTree(&out, kongRootNode(ctx), c.Name, result); err != nil {
		return err
	}
	fmt.Print(out.String())
	return nil
}

func renderAliasTree(out *strings.Builder, root *kong.Node, alias string, node gjson.Result) error {
	return renderAliasNode(out, root, alias, "", node, "  ")
}

func renderAliasNode(out *strings.Builder, gram *kong.Node, alias, path string, node gjson.Result, indent string) error {
	if !node.IsObject() {
		return invalidAliasStructureErr(alias, path)
	}
	type entry struct {
		key string
		val gjson.Result
	}
	var entries []entry
	node.ForEach(func(k, v gjson.Result) bool {
		entries = append(entries, entry{k.String(), v})
		return true
	})
	sort.Slice(entries, func(i, j int) bool { return entries[i].key < entries[j].key })

	for _, e := range entries {
		if child := childCommandNode(gram, e.key); child != nil {
			childPath := e.key
			if path != "" {
				childPath = path + "." + e.key
			}
			fmt.Fprintf(out, "%s%s:\n", indent, child.Name)
			if err := renderAliasNode(out, child, alias, childPath, e.val, indent+"  "); err != nil {
				return err
			}
			continue
		}
		if name, ok := recognizedAliasField(gram, e.key); ok {
			if e.val.IsObject() || e.val.IsArray() {

				fmt.Fprintf(out, "%s%s: <redacted>\n", indent, name)
				continue
			}
			fmt.Fprintf(out, "%s%s: %s\n", indent, name, renderAliasScalar(name, e.val))
			continue
		}

		fmt.Fprintf(out, "%s<redacted-key>: <redacted>\n", indent)
	}
	return nil
}

func childCommandNode(gram *kong.Node, key string) *kong.Node {
	if gram == nil {
		return nil
	}
	for _, ch := range gram.Children {
		if ch != nil && ch.Name == key {
			return ch
		}
	}
	return nil
}

func recognizedAliasField(gram *kong.Node, key string) (string, bool) {
	if gram == nil || !gram.Target.IsValid() {
		return "", false
	}
	t := gram.Target.Type()
	if t.Kind() == reflect.Ptr {
		t = t.Elem()
	}
	if t.Kind() != reflect.Struct {
		return "", false
	}
	tags, ok := getFieldTags(t, key)
	if !ok || tags.JSONName != key {
		return "", false
	}
	return tags.JSONName, true
}

func renderAliasScalar(name string, v gjson.Result) string {
	if classifyFlag(name, "") != classSafe {
		return "<redacted>"
	}
	return formatValue(v.Value())
}

func invalidAliasStructureErr(alias, path string) error {
	if path == "" {
		return fmt.Errorf("alias %q has invalid structure (expected a JSON object of saved commands)", alias)
	}
	return fmt.Errorf("alias %q has invalid structure at %s (expected a JSON object)", alias, path)
}

type AliasDeleteCmd struct {
	Name  string `arg:"" help:"Alias name to delete." validate:"required,alias"`
	Force bool   `short:"f" help:"Skip confirmation prompt."`
}

func (c *AliasDeleteCmd) Run() error {
	data := loadActionAliases()
	if !gjson.GetBytes(data, c.Name).Exists() {
		return fmt.Errorf("alias %q not found", c.Name)
	}

	if !c.Force && !promptYesNo(fmt.Sprintf("Delete alias %q?", c.Name)) {
		fmt.Println("Cancelled.")
		return nil
	}

	reclaimed, err := reclaimDeletedAliasCache(c.Name)
	if err != nil {
		return err
	}
	if reclaimed > 0 {
		fmt.Printf("Reclaimed %s of VFS cache.\n", formatByteSize(reclaimed))
	}
	fmt.Printf("Deleted alias %q.\n", c.Name)
	return nil
}

type AliasRenameCmd struct {
	OldName string `arg:"" help:"Current alias name." validate:"required,alias"`
	NewName string `arg:"" help:"New alias name." validate:"required,alias"`
}

func (c *AliasRenameCmd) Run() error {

	if err := migrateRenamedAliasCache(c.OldName, c.NewName); err != nil {
		return err
	}
	fmt.Printf("Renamed %q → %q.\n", c.OldName, c.NewName)
	return nil
}

type AliasCopyCmd struct {
	Source string `arg:"" help:"Source alias name." validate:"required,alias"`
	Target string `arg:"" help:"Target alias name." validate:"required,alias"`
}

func (c *AliasCopyCmd) Run() error {
	if !isValidAliasName(c.Source) || !isValidAliasName(c.Target) {
		return fmt.Errorf("invalid alias name (must be alphanumeric + hyphens)")
	}
	unlockAliasCfg := lockAliasConfigOrDie()
	defer unlockAliasCfg()
	data := loadActionAliases()
	src := gjson.GetBytes(data, c.Source)
	if !src.Exists() {
		return fmt.Errorf("alias %q not found", c.Source)
	}
	if gjson.GetBytes(data, c.Target).Exists() {
		return fmt.Errorf("alias %q already exists", c.Target)
	}

	var srcValue interface{}
	_ = json.Unmarshal([]byte(src.Raw), &srcValue)

	data, _ = sjson.SetBytes(data, c.Target, srcValue)
	aliases := cacheAliasSetFromBytes(data)
	if err := validateAssetsCacheRemoteCollisions(aliases, c.Target); err != nil {
		return err
	}
	saveActionAliases(data)
	fmt.Printf("Copied %q → %q.\n", c.Source, c.Target)
	return nil
}

type AliasValidateCmd struct{}

func (c *AliasValidateCmd) Run(ctx *kong.Context) error {
	data := loadActionAliases()
	var all map[string]interface{}
	if err := json.Unmarshal(data, &all); err != nil {
		return fmt.Errorf("corrupted alias file: %w", err)
	}
	if len(all) == 0 {
		fmt.Println("No aliases to validate.")
		return nil
	}

	names := make([]string, 0, len(all))
	for name := range all {
		names = append(names, name)
	}
	sort.Strings(names)

	errors := 0
	for _, name := range names {
		if !isValidAliasName(name) {
			fmt.Printf("  ✗ %q: invalid alias name (must be alphanumeric + hyphens)\n", name)
			errors++
		} else {
			fmt.Printf("  ✓ %s\n", name)
		}
	}

	root := kongRootNode(ctx)
	var findings []rotFinding
	for _, name := range names {
		for _, f := range scanAliasRot(root, data, name) {
			if f.Kind == rotEmptyNode {
				continue
			}
			findings = append(findings, f)
		}
	}
	if errors > 0 {
		if len(findings) > 0 {
			fmt.Printf("\n%d rot %s (run 'accorder config prune' to review):\n",
				len(findings), plural(len(findings), "warning", "warnings"))
			renderRotFindings(findings)
		}
		return fmt.Errorf("%d %s found", errors, plural(errors, "error", "errors"))
	}
	fmt.Println("All aliases valid.")
	if len(findings) > 0 {
		fmt.Printf("\n%d rot %s (run 'accorder config prune' to review, 'config prune --apply' to fix):\n",
			len(findings), plural(len(findings), "warning", "warnings"))
		renderRotFindings(findings)
	}
	return nil
}

func GetAllAliases() []string {
	data := loadActionAliases()
	var all map[string]interface{}
	if err := json.Unmarshal(data, &all); err != nil {
		log.Printf("Warning: cannot parse alias file: %v", err)
		return nil
	}
	names := make([]string, 0, len(all))
	for name := range all {
		names = append(names, name)
	}
	return names
}

func formatValue(v interface{}) string {
	switch val := v.(type) {
	case string:
		return fmt.Sprintf("%q", val)
	case float64:
		if val == float64(int(val)) {
			return fmt.Sprintf("%d", int(val))
		}
		return fmt.Sprintf("%g", val)
	case bool:
		return fmt.Sprintf("%v", val)
	default:
		return fmt.Sprintf("%v", val)
	}
}

func isValidAliasName(name string) bool {
	if name == "" {
		return false
	}
	for _, r := range name {
		isLetter := (r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z')
		isDigit := r >= '0' && r <= '9'
		isHyphen := r == '-'
		if !isLetter && !isDigit && !isHyphen {
			return false
		}
	}
	return true
}

func isatty(fd int) bool {
	return term.IsTerminal(fd)
}

func promptYesNo(prompt string) bool {
	if !isatty(int(os.Stdin.Fd())) {
		fmt.Println(prompt)
		fmt.Println("Non-interactive terminal — re-run with the relevant --yes flag to skip this prompt.")
		return false
	}
	fmt.Printf("%s [y/N] ", prompt)
	var answer string
	_, _ = fmt.Scanln(&answer)
	return strings.EqualFold(strings.TrimSpace(answer), "y")
}

func LogAliasSave(alias, command string, count int) {
	if isatty(int(os.Stdout.Fd())) {
		log.Printf("Saved %d %s to alias '%s' for '%s'",
			count, plural(count, "field", "fields"), alias, command)
	}
}

type ConfigFindCalibreCmd struct {
	Prefix string `kong:"optional,help='Directory to search (default: $HOME)'"`
	Alias  string `kong:"arg,optional,help='Alias to set calibrepath for (omit to list only)'"`
}

func (c *ConfigFindCalibreCmd) Run(ctx *kong.Context) error {
	if c.Alias == "" {
		prefix := c.Prefix
		if prefix == "" {
			home, err := os.UserHomeDir()
			if err != nil {
				return fmt.Errorf("get home dir: %w", err)
			}
			prefix = home
		}

		paths, err := findCalibreLibraries(prefix)
		if err != nil {
			return err
		}

		if len(paths) == 0 {
			fmt.Fprintf(os.Stderr, "No Calibre libraries found under %s\n", prefix)
			return nil
		}

		fmt.Fprintf(os.Stderr, "Found %d Calibre libraries:\n", len(paths))
		for i, p := range paths {
			fmt.Fprintf(os.Stderr, "  %d. %s\n", i+1, p)
		}
		return nil
	}

	selectedPath, err := resolveCalibrePathInteractive(c.Prefix, c.Alias)
	if err != nil {
		return err
	}

	persistCalibrePath(ctx, c.Alias, selectedPath)
	fmt.Fprintf(os.Stderr, "Set calibrepath=%s for alias %q\n", selectedPath, c.Alias)
	return nil
}

func persistCalibrePath(ctx *kong.Context, alias, path string) {
	unlockAliasCfg := lockAliasConfigOrDie()
	defer unlockAliasCfg()
	root := ctx.Selected()
	for root != nil && root.Parent != nil {
		root = root.Parent
	}
	buildNode := findNodeByPath(root, "lib.build")
	configBytes := loadActionAliases()
	configBytes, _ = sjson.SetBytes(configBytes, alias+".lib.build.calibrepath", path)
	if buildNode != nil {
		propagateSharedField(root, buildNode, alias, "calibrepath", path, "lib", &configBytes)
	}
	saveActionAliases(configBytes)
}

func resolveCalibrePathInteractive(initialPrefix, alias string) (string, error) {
	prefix := initialPrefix
	if prefix == "" {
		home, err := os.UserHomeDir()
		if err != nil {
			return "", fmt.Errorf("get home dir: %w", err)
		}
		prefix = home
	}
	for {
		paths, err := findCalibreLibraries(prefix)
		if err != nil {
			return "", err
		}

		if len(paths) == 0 {
			fmt.Fprintf(os.Stderr, "No Calibre libraries found under %s\n", prefix)
			fmt.Fprintf(os.Stderr, "Enter different search path (or empty to abort): ")
			var newPrefix string
			fmt.Scanln(&newPrefix)
			if newPrefix == "" {
				return "", fmt.Errorf("no Calibre library found")
			}
			prefix = newPrefix
			continue
		}

		var selectedPath string
		if len(paths) == 1 {
			fmt.Fprintf(os.Stderr, "Found: %s\n", paths[0])
			var prompt string
			if alias != "" {
				prompt = fmt.Sprintf("Set calibrepath for alias %q? [Y/n] ", alias)
			} else {
				prompt = "Use this library? [Y/n] "
			}
			fmt.Fprintf(os.Stderr, "%s", prompt)
			var resp string
			fmt.Scanln(&resp)
			if resp != "" && resp != "Y" && resp != "y" {
				return "", fmt.Errorf("user declined")
			}
			selectedPath = paths[0]
		} else {
			fmt.Fprintf(os.Stderr, "Found %d Calibre libraries:\n", len(paths))
			for i, p := range paths {
				fmt.Fprintf(os.Stderr, "  %d. %s\n", i+1, p)
			}
			fmt.Fprintf(os.Stderr, "Select [1-%d]: ", len(paths))
			var choice int
			_, err := fmt.Scanln(&choice)
			if err != nil || choice < 1 || choice > len(paths) {
				return "", fmt.Errorf("invalid choice")
			}
			selectedPath = paths[choice-1]
		}

		return selectedPath, nil
	}
}

func findCalibreLibraries(prefix string) ([]string, error) {
	var results []string
	visited := make(map[string]bool)

	skipDirs := map[string]bool{
		".git": true, "node_modules": true, "Trash": true,
	}

	err := filepath.Walk(prefix, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return nil
		}

		base := filepath.Base(path)
		if strings.HasPrefix(base, ".") || skipDirs[base] {
			if info.IsDir() {
				return filepath.SkipDir
			}
			return nil
		}

		if info.Mode()&os.ModeSymlink != 0 {
			realPath, err := filepath.EvalSymlinks(path)
			if err != nil {
				return nil
			}
			if visited[realPath] {
				return filepath.SkipDir
			}
			visited[realPath] = true
		}

		if base == "metadata.db" && !info.IsDir() {
			f, err := os.Open(path)
			if err != nil {
				return nil
			}
			defer f.Close()
			magic := make([]byte, 16)
			_, rerr := io.ReadFull(f, magic)
			if rerr == nil && string(magic) == "SQLite format 3\x00" {
				libPath := filepath.Dir(path)
				results = append(results, libPath)
				return filepath.SkipDir
			}
		}

		return nil
	})

	return results, err
}
