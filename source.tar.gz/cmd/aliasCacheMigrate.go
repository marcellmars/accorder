package cmd

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"sort"
	"strings"
	"time"

	"github.com/tidwall/gjson"
	"github.com/tidwall/sjson"
)

type renameIdentity struct {
	FromRemote string   `json:"fromRemote"`
	ToRemote   string   `json:"toRemote"`
	HasVFS     bool     `json:"hasVFS"`
	HasMeta    bool     `json:"hasMeta"`
	Roots      []string `json:"roots,omitempty"`
	SkipReason string   `json:"skipReason,omitempty"`
}

type renameIntent struct {
	V          int              `json:"v"`
	OldAlias   string           `json:"oldAlias"`
	NewAlias   string           `json:"newAlias"`
	Identities []renameIdentity `json:"identities"`
	JSONLFrom  string           `json:"jsonlFrom,omitempty"`
	JSONLTo    string           `json:"jsonlTo,omitempty"`
	TS         string           `json:"ts"`
}

func computeCachePlan(alias, newAlias string, aliases map[string]bool, view *ledgerView, ledgerOK bool) []renameIdentity {
	var out []renameIdentity
	cacheDir := accorderCacheDir()
	for _, variant := range reclaimRemoteVariants {
		from := variant.Prefix + alias + variant.Suffix
		hasVFS := dirExists(filepath.Join(cacheDir, "vfs", from))
		hasMeta := dirExists(filepath.Join(cacheDir, "vfsMeta", from))
		if !hasVFS && !hasMeta {
			continue
		}
		id := renameIdentity{FromRemote: from, HasVFS: hasVFS, HasMeta: hasMeta}
		if newAlias != "" {
			id.ToRemote = variant.Prefix + newAlias + variant.Suffix
		}
		ambiguous := false
		for _, cand := range remoteNameCandidates(from) {
			if cand != alias && aliases[cand] {
				ambiguous = true
				id.SkipReason = fmt.Sprintf("remote name also claimed by existing alias %q — possibly shared, not touched", cand)
				break
			}
		}
		if !ambiguous {
			if !ledgerOK {
				id.SkipReason = "identity ledger malformed — ledger-dependent migration is report-only"
			} else if roots := view.activeRoots[from]; len(roots) > 0 {
				for r := range roots {
					id.Roots = append(id.Roots, r)
				}
				sort.Strings(id.Roots)
			} else {
				id.SkipReason = "legacy (pre-ledger) tree — reported, not migrated"
			}
		}
		out = append(out, id)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].FromRemote < out[j].FromRemote })
	return out
}

func dirExists(path string) bool {
	info, err := os.Lstat(path)
	return err == nil && info.IsDir()
}

func probePlanLocks(ids []renameIdentity) (releaseAll func(), err error) {
	var releases []func()
	releaseAll = func() {
		for i := len(releases) - 1; i >= 0; i-- {
			releases[i]()
		}
	}
	for i := range ids {
		if ids[i].SkipReason != "" {
			continue
		}

		names := []string{ids[i].FromRemote}
		if ids[i].ToRemote != "" {
			names = append(names, ids[i].ToRemote)
		}
		for _, name := range names {
			rel, ok, lerr := acquireMutationLock(name, "")
			if lerr != nil {
				releaseAll()
				return func() {}, lerr
			}
			if !ok {
				ids[i].SkipReason = fmt.Sprintf("mutation lock on %s contended — a serve appears to be running on this remote name", name)
				break
			}
			releases = append(releases, rel)
		}
	}
	return releaseAll, nil
}

func plansEqual(a, b []renameIdentity) bool { return reflect.DeepEqual(a, b) }

func renameAliasConfigDurable(oldAlias, newAlias string) error {
	data := loadActionAliases()
	old := gjson.GetBytes(data, oldAlias)
	if !old.Exists() {
		return fmt.Errorf("alias %q not found", oldAlias)
	}
	var oldValue interface{}
	if err := json.Unmarshal([]byte(old.Raw), &oldValue); err != nil {
		return fmt.Errorf("parse alias %q: %w", oldAlias, err)
	}
	data, err := sjson.SetBytes(data, newAlias, oldValue)
	if err != nil {
		return err
	}
	data, err = sjson.DeleteBytes(data, oldAlias)
	if err != nil {
		return err
	}
	if err := trySaveActionAliasesDurable(data); err != nil {
		return fmt.Errorf("save aliases: %w", err)
	}
	return nil
}

func clonePlan(ids []renameIdentity) []renameIdentity {
	out := make([]renameIdentity, len(ids))
	copy(out, ids)
	for i := range out {
		out[i].Roots = append([]string(nil), ids[i].Roots...)
	}
	return out
}

func tentativePlan(alias, newAlias string, aliases map[string]bool, allowed bool, why string) ([]renameIdentity, bool) {
	records, malformed, lerr := readLedger()
	if lerr != nil {
		records, malformed = nil, true
	}
	plan := computeCachePlan(alias, newAlias, aliases, replayLedger(records), !malformed)
	blockReason := ""
	if !allowed {
		blockReason = why
	}
	if _, err := os.Stat(renameIntentPath()); err == nil {
		blockReason = "an unreconciled cache-tree migration marker exists — run 'accorder config prune --apply-cache-trees' first"
	}
	if blockReason != "" {
		for i := range plan {
			if plan[i].SkipReason == "" {
				plan[i].SkipReason = blockReason
			}
		}
	}
	return plan, blockReason != ""
}

func migrateRenamedAliasCache(oldAlias, newAlias string) error {

	if !isValidAliasName(oldAlias) || !isValidAliasName(newAlias) {
		return fmt.Errorf("invalid alias name (must be alphanumeric + hyphens)")
	}
	aliases, err := strictLoadAliasSet()
	if err != nil {
		return fmt.Errorf("load aliases for cache identity validation: %w", err)
	}
	delete(aliases, oldAlias)
	aliases[newAlias] = true
	if err := validateAssetsCacheRemoteCollisions(aliases, newAlias); err != nil {
		return err
	}
	allowed, why := destructiveReclaimAllowed()

	const maxAttempts = 3
	for attempt := 1; ; attempt++ {

		aliases, aerr := strictLoadAliasSet()
		if aerr != nil {
			return fmt.Errorf("config rename: %w", aerr)
		}
		plan, _ := tentativePlan(oldAlias, newAlias, aliases, allowed, why)

		probedPlan := clonePlan(plan)
		releaseLocks, perr := probePlanLocks(probedPlan)
		if perr != nil {
			return fmt.Errorf("config rename: lock probe: %w", perr)
		}

		retry := false
		err := withAliasConfigLock(func() error {
			aliases2, aerr2 := strictLoadAliasSet()
			if aerr2 != nil {
				return fmt.Errorf("config rename: %w", aerr2)
			}
			plan2, _ := tentativePlan(oldAlias, newAlias, aliases2, allowed, why)
			if !plansEqual(plan, plan2) {
				retry = true
				return nil
			}
			if !aliases2[oldAlias] {
				return fmt.Errorf("alias %q not found", oldAlias)
			}
			if aliases2[newAlias] {
				return fmt.Errorf("alias %q already exists", newAlias)
			}
			prospective := cloneAliasSet(aliases2)
			delete(prospective, oldAlias)
			prospective[newAlias] = true
			if verr := validateAssetsCacheRemoteCollisions(prospective, newAlias); verr != nil {
				return verr
			}
			return executeLockedRename(oldAlias, newAlias, probedPlan)
		})
		releaseLocks()
		if err != nil {
			return err
		}
		if !retry {
			return nil
		}
		if attempt >= maxAttempts {
			return fmt.Errorf("config rename: concurrent configuration churn — plan kept changing after %d attempts; no mutation performed", maxAttempts)
		}
	}
}

func cloneAliasSet(aliases map[string]bool) map[string]bool {
	out := make(map[string]bool, len(aliases))
	for alias, exists := range aliases {
		out[alias] = exists
	}
	return out
}

func executeLockedRename(oldAlias, newAlias string, plan []renameIdentity) error {
	cacheDir := accorderCacheDir()
	intent := renameIntent{
		V: 1, OldAlias: oldAlias, NewAlias: newAlias, Identities: plan,
		TS: time.Now().UTC().Format(time.RFC3339),
	}
	jsonlFrom := filepath.Join(cacheDir, oldAlias+".jsonl")
	jsonlTo := filepath.Join(cacheDir, newAlias+".jsonl")
	migrateJSONL := false

	migrationAllowed, _ := destructiveReclaimAllowed()
	if _, err := os.Lstat(jsonlFrom); err == nil && migrationAllowed {
		if _, err := os.Lstat(jsonlTo); err == nil {
			fmt.Printf("Cache: %s exists — %s left in place (retained data, never merged).\n", jsonlTo, jsonlFrom)
		} else {
			migrateJSONL = true
			intent.JSONLFrom = jsonlFrom
			intent.JSONLTo = jsonlTo
		}
	}

	anyMigration := migrateJSONL
	for i := range plan {
		if plan[i].SkipReason == "" {

			if dirExists(filepath.Join(cacheDir, "vfs", plan[i].ToRemote)) ||
				dirExists(filepath.Join(cacheDir, "vfsMeta", plan[i].ToRemote)) {
				plan[i].SkipReason = "destination tree already exists — never merged"
				intent.Identities[i].SkipReason = plan[i].SkipReason
			} else {
				anyMigration = true
			}
		}
	}

	if anyMigration {
		data, err := json.Marshal(intent)
		if err != nil {
			return err
		}
		if err := writeFileDurable(renameIntentPath(), data, 0o600); err != nil {
			return fmt.Errorf("config rename: write intent marker: %w", err)
		}
	}

	for i := range plan {
		id := &plan[i]
		if id.SkipReason != "" {
			fmt.Printf("Cache: %s not migrated: %s\n", id.FromRemote, id.SkipReason)
			continue
		}
		if err := moveTreePair(cacheDir, id); err != nil {
			id.SkipReason = err.Error()
			fmt.Printf("Cache: %s not migrated: %v\n", id.FromRemote, err)
			continue
		}
		for _, root := range id.Roots {
			if err := withGCLock(func() error {
				return appendLedgerRecord(ledgerRecord{
					Type: "rename", FromRemote: id.FromRemote, FromRoot: root,
					ToRemote: id.ToRemote, ToRoot: root, Alias: newAlias, Cmd: "config rename",
				})
			}); err != nil {
				return fmt.Errorf("config rename: ledger record for %s: %w", id.FromRemote, err)
			}
		}
		fmt.Printf("Cache: migrated %s → %s (vfs + vfsMeta, cache stays warm).\n", id.FromRemote, id.ToRemote)
	}

	if migrateJSONL {
		if err := os.Rename(jsonlFrom, jsonlTo); err != nil {
			fmt.Printf("Cache: %s not migrated: %v (retained data — left in place)\n", jsonlFrom, err)
		} else {
			fmt.Printf("Cache: migrated %s → %s.\n", filepath.Base(jsonlFrom), filepath.Base(jsonlTo))
		}
	}

	if err := renameAliasConfigDurable(oldAlias, newAlias); err != nil {
		return fmt.Errorf("config rename: %w", err)
	}

	if anyMigration {
		if err := os.Remove(renameIntentPath()); err != nil && !os.IsNotExist(err) {
			return fmt.Errorf("config rename: remove intent marker: %w", err)
		}
		_ = syncDir(filepath.Dir(renameIntentPath()))
	}
	return nil
}

func moveTreePair(cacheDir string, id *renameIdentity) error {
	vfsFrom := filepath.Join(cacheDir, "vfs", id.FromRemote)
	vfsTo := filepath.Join(cacheDir, "vfs", id.ToRemote)
	metaFrom := filepath.Join(cacheDir, "vfsMeta", id.FromRemote)
	metaTo := filepath.Join(cacheDir, "vfsMeta", id.ToRemote)
	if id.HasVFS {
		if err := os.Rename(vfsFrom, vfsTo); err != nil {
			return fmt.Errorf("move vfs half: %w", err)
		}
	}
	if id.HasMeta {
		if err := os.Rename(metaFrom, metaTo); err != nil {
			if id.HasVFS {
				if rbErr := os.Rename(vfsTo, vfsFrom); rbErr != nil {
					return fmt.Errorf("move vfsMeta half: %v; ROLLBACK OF vfs HALF ALSO FAILED: %v — reconcile via 'config prune --apply-cache-trees'", err, rbErr)
				}
			}
			return fmt.Errorf("move vfsMeta half (vfs half rolled back): %w", err)
		}
	}
	return nil
}

func reclaimDeletedAliasCache(alias string) (int64, error) {
	if !isValidAliasName(alias) {
		return 0, fmt.Errorf("invalid alias name (must be alphanumeric + hyphens)")
	}
	allowed, why := destructiveReclaimAllowed()

	const maxAttempts = 3
	for attempt := 1; ; attempt++ {
		aliases, aerr := strictLoadAliasSet()
		if aerr != nil {
			return 0, fmt.Errorf("config delete: %w", aerr)
		}
		plan, _ := tentativePlan(alias, "", aliases, allowed, why)

		probedPlan := clonePlan(plan)
		releaseLocks, perr := probePlanLocks(probedPlan)
		if perr != nil {
			return 0, fmt.Errorf("config delete: lock probe: %w", perr)
		}

		retry := false
		var reclaimed int64
		err := withAliasConfigLock(func() error {
			aliases2, aerr2 := strictLoadAliasSet()
			if aerr2 != nil {
				return fmt.Errorf("config delete: %w", aerr2)
			}
			plan2, _ := tentativePlan(alias, "", aliases2, allowed, why)
			if !plansEqual(plan, plan2) {
				retry = true
				return nil
			}
			if !aliases2[alias] {
				return fmt.Errorf("alias %q not found", alias)
			}
			cacheDir := accorderCacheDir()
			for i := range probedPlan {
				id := &probedPlan[i]
				vfsPath := filepath.Join(cacheDir, "vfs", id.FromRemote)
				metaPath := filepath.Join(cacheDir, "vfsMeta", id.FromRemote)
				size, lower := walkSize([]string{vfsPath, metaPath}, defaultSizeBudget, nil)
				if id.SkipReason != "" {
					sizeStr := formatByteSize(size)
					if lower {
						sizeStr = "≥" + sizeStr
					}
					fmt.Printf("Cache: %s (%s) not reclaimed: %s\n", id.FromRemote, sizeStr, id.SkipReason)
					continue
				}
				vfsGone, metaGone := true, true
				if id.HasVFS {
					if rerr := os.RemoveAll(vfsPath); rerr != nil {
						vfsGone = false
						fmt.Printf("Cache: %s vfs half not fully removed: %v — residual stays reclaimable via 'config prune'\n", id.FromRemote, rerr)
					}
				}
				if id.HasMeta {
					if rerr := os.RemoveAll(metaPath); rerr != nil {
						metaGone = false
						fmt.Printf("Cache: %s vfsMeta half not fully removed: %v — residual stays reclaimable via 'config prune'\n", id.FromRemote, rerr)
					}
				}
				if vfsGone && metaGone {
					reclaimed += size
					for _, root := range id.Roots {
						if gerr := withGCLock(func() error {
							return appendLedgerRecord(ledgerRecord{Type: "delete", Remote: id.FromRemote, Root: root, Cmd: "config delete"})
						}); gerr != nil {
							return fmt.Errorf("config delete: tombstone %s:%s: %w", id.FromRemote, root, gerr)
						}
					}
					fmt.Printf("Cache: reclaimed %s (%s).\n", id.FromRemote, formatByteSize(size))
				}
			}
			jsonl := filepath.Join(cacheDir, alias+".jsonl")
			if _, err := os.Lstat(jsonl); err == nil {
				fmt.Printf("Cache: retained %s — build snapshot data (may be the only catalog source); delete manually if unwanted.\n", jsonl)
			}

			data := loadActionAliases()
			data, derr := sjson.DeleteBytes(data, alias)
			if derr != nil {
				return fmt.Errorf("failed to delete alias: %w", derr)
			}
			if serr := trySaveActionAliasesDurable(data); serr != nil {
				return fmt.Errorf("config delete: save aliases: %w", serr)
			}
			return nil
		})
		releaseLocks()
		if err != nil {
			return reclaimed, err
		}
		if !retry {
			return reclaimed, nil
		}
		if attempt >= maxAttempts {
			return 0, fmt.Errorf("config delete: concurrent configuration churn — plan kept changing after %d attempts; no mutation performed", maxAttempts)
		}
	}
}

func reconcileRenameIntent() (handled bool, err error) {
	data, rerr := os.ReadFile(renameIntentPath())
	if os.IsNotExist(rerr) {
		return false, nil
	}
	if rerr != nil {
		return false, fmt.Errorf("read intent marker: %w", rerr)
	}
	var intent renameIntent
	if jerr := json.Unmarshal(data, &intent); jerr != nil {
		return false, fmt.Errorf("intent marker malformed: %v — resolve manually, then remove %s", jerr, renameIntentPath())
	}
	if ok, why := destructiveReclaimAllowed(); !ok {
		return false, fmt.Errorf("intent marker present but %s", why)
	}

	for _, id := range intent.Identities {
		if !validRemoteName(id.FromRemote) || (id.ToRemote != "" && !validRemoteName(id.ToRemote)) {
			return false, fmt.Errorf("intent marker contains invalid remote names — resolve manually, then remove %s", renameIntentPath())
		}
	}

	sorted := make([]renameIdentity, len(intent.Identities))
	copy(sorted, intent.Identities)
	sort.Slice(sorted, func(i, j int) bool { return sorted[i].FromRemote < sorted[j].FromRemote })
	var releases []func()
	defer func() {
		for i := len(releases) - 1; i >= 0; i-- {
			releases[i]()
		}
	}()
	for _, id := range sorted {
		if id.SkipReason != "" {
			continue
		}
		for _, name := range []string{id.FromRemote, id.ToRemote} {
			rel, ok, lerr := acquireMutationLock(name, "")
			if lerr != nil {
				return false, fmt.Errorf("recovery lock %s: %w", name, lerr)
			}
			if !ok {
				return false, fmt.Errorf("recovery: mutation lock %s contended — a serve appears to be running; apply branch aborted", name)
			}
			releases = append(releases, rel)
		}
	}

	err = withAliasConfigLock(func() error {
		aliases, aerr := strictLoadAliasSet()
		if aerr != nil {
			return fmt.Errorf("recovery: %w", aerr)
		}
		hasOld, hasNew := aliases[intent.OldAlias], aliases[intent.NewAlias]
		renameConfig := false
		switch {
		case hasNew && !hasOld:
			if verr := validateAssetsCacheRemoteCollisions(aliases, intent.NewAlias); verr != nil {
				return fmt.Errorf("recovery: %w", verr)
			}
		case hasOld && !hasNew:
			if !isValidAliasName(intent.OldAlias) || !isValidAliasName(intent.NewAlias) {
				return fmt.Errorf("recovery: journal alias names invalid — resolve manually then remove %s", renameIntentPath())
			}
			prospective := cloneAliasSet(aliases)
			delete(prospective, intent.OldAlias)
			prospective[intent.NewAlias] = true
			if verr := validateAssetsCacheRemoteCollisions(prospective, intent.NewAlias); verr != nil {
				return fmt.Errorf("recovery: %w", verr)
			}
			renameConfig = true
		default:
			return fmt.Errorf("recovery: alias config has old=%v new=%v — ambiguous, resolve manually then remove %s", hasOld, hasNew, renameIntentPath())
		}

		cacheDir := accorderCacheDir()
		for i := range intent.Identities {
			id := &intent.Identities[i]
			if id.SkipReason != "" {
				continue
			}
			vfsAtFrom := dirExists(filepath.Join(cacheDir, "vfs", id.FromRemote))
			vfsAtTo := dirExists(filepath.Join(cacheDir, "vfs", id.ToRemote))
			metaAtFrom := dirExists(filepath.Join(cacheDir, "vfsMeta", id.FromRemote))
			metaAtTo := dirExists(filepath.Join(cacheDir, "vfsMeta", id.ToRemote))
			if (vfsAtFrom && vfsAtTo) || (metaAtFrom && metaAtTo) {
				return fmt.Errorf("recovery: %s exists on BOTH sides — ambiguous, resolve manually then remove %s", id.FromRemote, renameIntentPath())
			}
			switch {
			case (!id.HasVFS || vfsAtTo) && (!id.HasMeta || metaAtTo):

			case (!id.HasVFS || vfsAtFrom) && (!id.HasMeta || metaAtFrom):
				if err := moveTreePair(cacheDir, id); err != nil {
					return fmt.Errorf("recovery: %w", err)
				}
			case id.HasVFS && id.HasMeta && vfsAtTo && metaAtFrom:
				if err := os.Rename(filepath.Join(cacheDir, "vfsMeta", id.FromRemote), filepath.Join(cacheDir, "vfsMeta", id.ToRemote)); err != nil {
					return fmt.Errorf("recovery: complete vfsMeta move: %w", err)
				}
			default:
				return fmt.Errorf("recovery: %s directory state matches no journal step — resolve manually then remove %s", id.FromRemote, renameIntentPath())
			}
			for _, root := range id.Roots {
				if err := withGCLock(func() error {
					return appendLedgerRecord(ledgerRecord{
						Type: "rename", FromRemote: id.FromRemote, FromRoot: root,
						ToRemote: id.ToRemote, ToRoot: root, Alias: intent.NewAlias, Cmd: "config prune (recovery)",
					})
				}); err != nil {
					return err
				}
			}
		}

		if intent.JSONLFrom != "" && intent.JSONLTo != "" {
			cacheRoot := filepath.Clean(accorderCacheDir()) + string(filepath.Separator)
			fromClean, toClean := filepath.Clean(intent.JSONLFrom), filepath.Clean(intent.JSONLTo)
			if !strings.HasPrefix(fromClean, cacheRoot) || !strings.HasPrefix(toClean, cacheRoot) {
				return fmt.Errorf("recovery: journal jsonl paths escape the cache dir — resolve manually then remove %s", renameIntentPath())
			}
			_, fromErr := os.Lstat(fromClean)
			_, toErr := os.Lstat(toClean)
			switch {
			case fromErr == nil && toErr == nil:
				fmt.Printf("Cache: both %s and %s exist — retained data, neither touched.\n", fromClean, toClean)
			case fromErr == nil:
				if err := os.Rename(fromClean, toClean); err != nil {
					fmt.Printf("Cache: recovery could not move %s: %v (retained data — left in place)\n", fromClean, err)
				}
			}
		}

		if renameConfig {
			if werr := renameAliasConfigDurable(intent.OldAlias, intent.NewAlias); werr != nil {
				return fmt.Errorf("recovery: %w", werr)
			}
		}
		if err := os.Remove(renameIntentPath()); err != nil && !os.IsNotExist(err) {
			return err
		}
		_ = syncDir(filepath.Dir(renameIntentPath()))
		return nil
	})
	if err != nil {
		return false, err
	}
	return true, nil
}
