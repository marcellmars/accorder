package cmd

import (
	"os"
	"strings"
	"testing"
)

func TestFedlibConfigSet_RoundTrip(t *testing.T) {
	testSetup(t)

	cmd := &FedlibConfigSetCmd{
		FedlibID:     "rt",
		Bucket:       "mybucket",
		UploadPrefix: "aggregate",
		S3Provider:   "Wasabi",
		S3Endpoint:   "s3.wasabisys.com",
		KeysFile:     "keys/lib.s3.keys",
		Mode:         "public",
		Endpoint:     "https://library.example.org",
		FedlibPath:   "/tmp/fedlib",
		OfferExpiry:  "168h",
	}
	if err := cmd.Run(); err != nil {
		t.Fatalf("set: %v", err)
	}

	desc := loadFedlibDescriptor("rt")
	if desc.Version != fedlibDescriptorVersion {
		t.Errorf("version = %d, want %d", desc.Version, fedlibDescriptorVersion)
	}
	for _, tc := range []struct{ name, got, want string }{
		{"Bucket", desc.Bucket, "mybucket"},
		{"UploadPrefix", desc.UploadPrefix, "aggregate"},
		{"S3Provider", desc.S3Provider, "Wasabi"},
		{"S3Endpoint", desc.S3Endpoint, "s3.wasabisys.com"},
		{"KeysFile", desc.KeysFile, "keys/lib.s3.keys"},
		{"Mode", desc.Mode, "public"},
		{"Endpoint", desc.Endpoint, "https://library.example.org"},
		{"FedlibPath", desc.FedlibPath, "/tmp/fedlib"},
		{"OfferExpiry", desc.OfferExpiry, "168h"},
	} {
		if tc.got != tc.want {
			t.Errorf("%s = %q, want %q", tc.name, tc.got, tc.want)
		}
	}
}

func TestFedlibConfigSet_MergesIntoExisting(t *testing.T) {
	testSetup(t)

	// Seed a descriptor with some fields.
	cmd1 := &FedlibConfigSetCmd{
		FedlibID: "merge",
		Bucket:   "mybucket",
		Mode:     "public",
	}
	if err := cmd1.Run(); err != nil {
		t.Fatalf("set 1: %v", err)
	}

	// Update only one field — others must survive.
	cmd2 := &FedlibConfigSetCmd{
		FedlibID:     "merge",
		UploadPrefix: "aggregate",
	}
	if err := cmd2.Run(); err != nil {
		t.Fatalf("set 2: %v", err)
	}

	desc := loadFedlibDescriptor("merge")
	if desc.Bucket != "mybucket" {
		t.Errorf("Bucket lost after partial update: %q", desc.Bucket)
	}
	if desc.Mode != "public" {
		t.Errorf("Mode lost after partial update: %q", desc.Mode)
	}
	if desc.UploadPrefix != "aggregate" {
		t.Errorf("UploadPrefix not set: %q", desc.UploadPrefix)
	}
}

func TestFedlibConfigShow_NoSecrets(t *testing.T) {
	testSetup(t)

	cmd := &FedlibConfigSetCmd{
		FedlibID:     "show",
		Bucket:       "mybucket",
		KeysFile:     "keys/lib.s3.keys",
		Mode:         "public",
		UploadPrefix: "aggregate",
	}
	if err := cmd.Run(); err != nil {
		t.Fatalf("set: %v", err)
	}

	stdout, _, err := captureInviteOutput(t, func() error {
		return (&FedlibConfigShowCmd{FedlibID: "show"}).Run()
	})
	if err != nil {
		t.Fatalf("show: %v", err)
	}
	// The output must contain the pointer (keys_file) but never an actual
	// access-key or secret-key value.
	if !strings.Contains(stdout, "keys/lib.s3.keys") {
		t.Errorf("keys_file path not shown:\n%s", stdout)
	}
	if !strings.Contains(stdout, "mybucket") {
		t.Errorf("bucket not shown:\n%s", stdout)
	}
	// Schema law: the descriptor struct has no credential-value fields, so
	// Show can never print one. This is validated structurally in
	// TestFedlibDescriptor_SchemaLaw_NoCredentialValues.
}

func TestFedlibConfigShow_MissingDescriptor(t *testing.T) {
	testSetup(t)
	err := (&FedlibConfigShowCmd{FedlibID: "nope"}).Run()
	if err == nil {
		t.Fatal("expected error for missing descriptor")
	}
	if !strings.Contains(err.Error(), "no descriptor") {
		t.Errorf("unexpected error: %v", err)
	}
}

func TestFedlibConfigList(t *testing.T) {
	testSetup(t)

	// Seed two descriptors.
	for _, id := range []string{"alpha", "beta"} {
		cmd := &FedlibConfigSetCmd{
			FedlibID: id,
			Bucket:   id + "-bucket",
			Mode:     "public",
		}
		if err := cmd.Run(); err != nil {
			t.Fatalf("set %s: %v", id, err)
		}
	}

	stdout, _, err := captureInviteOutput(t, func() error {
		return (&FedlibConfigListCmd{}).Run()
	})
	if err != nil {
		t.Fatalf("list: %v", err)
	}
	if !strings.Contains(stdout, "alpha") || !strings.Contains(stdout, "beta") {
		t.Errorf("list output missing descriptors:\n%s", stdout)
	}
}

func TestFedlibConfigList_Empty(t *testing.T) {
	testSetup(t)

	// Remove the fedlibs.json so the list is truly empty.
	_ = os.Remove(fedlibDescriptorPath())
	_, stderr, err := captureInviteOutput(t, func() error {
		return (&FedlibConfigListCmd{}).Run()
	})
	if err != nil {
		t.Fatalf("list: %v", err)
	}
	if !strings.Contains(stderr, "no federation descriptors") {
		t.Errorf("expected empty notice on stderr:\n%s", stderr)
	}
}
