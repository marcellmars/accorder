//go:build !tailscale

package cmd

import (
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"testing"

	"github.com/alecthomas/kong"
)

// ===========================================================================
// Phase 0 spike: fedlib-operator-seat
// (.sit/workflows/2026-06-15_fedlib-operator-seat/)
//

// A2: Can a --on <server> flag in AfterApply (or BeforeApply) intercept
//     Kong dispatch before validators fire?
// A5: Is a top-level `remote` subcommand less invasive than a --on global flag?
// A1: Does the IAM scoped policy restrict serve-key writes to member prefixes?
// A3: Is fedlib build structurally deterministic (same inputs → same output)?
// ===========================================================================

// ---------------------------------------------------------------------------
// A2: Kong global flag interception via BeforeApply
//

// Hypothesis: A global flag with a BeforeApply hook fires DURING kong.Parse,
// BEFORE AfterApply and before validators. This means an --on flag could
// intercept, re-exec over SSH, and call os.Exit — preventing local
// validators from rejecting server-only state (e.g., missing calibrepath).
//

// Test approach: Add a flag type with BeforeApply to a minimal CLI struct,
// verify it fires before AfterApply and before validation.
// ---------------------------------------------------------------------------

// spikeOnFlagInterceptor is the spike-only flag type that records when BeforeApply fires.
// Renamed from onFlagInterceptor to avoid conflict with the production type in cmd/on.go.
type spikeOnFlagInterceptor string

// spikeBeforeApplyFired is set to true by spikeOnFlagInterceptor.BeforeApply.
var spikeBeforeApplyFired bool

// spikeAfterApplyFired is set to true by spikeCLI_A2.AfterApply.
var spikeAfterApplyFired bool

// spikeCallOrder tracks call ordering.
var spikeCallOrder []string

func (o spikeOnFlagInterceptor) BeforeApply(app *kong.Kong) error {
	spikeBeforeApplyFired = true
	spikeCallOrder = append(spikeCallOrder, "BeforeApply:on")

	// In production, this would SSH re-exec and os.Exit.
	// For the spike we just record that it fired.
	return nil
}

// spikeCLI_A2 is a minimal CLI struct for testing --on flag interception.
type spikeCLI_A2 struct {
	On   spikeOnFlagInterceptor `name:"on" help:"Remote server to execute on." default:""`
	Echo struct {
		Message string `arg:"" help:"Message to echo."`
	} `cmd:"" help:"Echo a message."`
}

// Track AfterApply on the spike CLI.
func (c *spikeCLI_A2) AfterApply(ctx *kong.Context) error {
	spikeAfterApplyFired = true
	spikeCallOrder = append(spikeCallOrder, "AfterApply:cli")
	return nil
}

func TestSpike_A2_BeforeApplyFiresBeforeAfterApply(t *testing.T) {
	spikeBeforeApplyFired = false
	spikeAfterApplyFired = false
	spikeCallOrder = nil

	cli := &spikeCLI_A2{}
	app, err := kong.New(cli,
		kong.Name("spike-a2"),
		kong.Exit(func(int) {}),
		kong.Bind(cli),
	)
	if err != nil {
		t.Fatalf("kong.New: %v", err)
	}

	_, err = app.Parse([]string{"--on", "myserver", "echo", "hello"})
	if err != nil {
		t.Fatalf("kong.Parse: %v", err)
	}

	if !spikeBeforeApplyFired {
		t.Fatal("REFUTED: BeforeApply on --on flag did not fire")
	}
	if !spikeAfterApplyFired {
		t.Fatal("UNEXPECTED: AfterApply did not fire (expected it to fire AFTER BeforeApply)")
	}

	// Check ordering
	if len(spikeCallOrder) < 2 {
		t.Fatalf("expected at least 2 calls, got %v", spikeCallOrder)
	}
	if spikeCallOrder[0] != "BeforeApply:on" {
		t.Fatalf("REFUTED: BeforeApply did not fire first; order=%v", spikeCallOrder)
	}
	if spikeCallOrder[1] != "AfterApply:cli" {
		t.Fatalf("REFUTED: AfterApply did not fire second; order=%v", spikeCallOrder)
	}

	t.Logf("CONFIRMED: BeforeApply fires before AfterApply; call order: %v", spikeCallOrder)
	t.Logf("CONFIRMED: --on flag can intercept before validators/AfterApply run")
}

// ---------------------------------------------------------------------------
// A2 supplement: BeforeApply fires before validation
//

// If a struct has validate:"required" fields and --on is set, the BeforeApply
// should fire BEFORE the validator rejects missing required fields. This is
// critical: the --on flag must be able to re-exec before local validation
// fails on server-only state.
// ---------------------------------------------------------------------------

type spikeCLI_A2_Validation struct {
	On    spikeOnFlagInterceptor `name:"on" help:"Remote server." default:""`
	Build struct {
		OutputPath string `name:"output-path" help:"Required field." validate:"required"`
		Bucket     string `name:"bucket" help:"Required field." validate:"required"`
	} `cmd:"" help:"Build something."`
}

func (c *spikeCLI_A2_Validation) AfterApply(ctx *kong.Context) error {
	spikeCallOrder = append(spikeCallOrder, "AfterApply:validation-cli")

	// Simulate validation — in the real CLI this is in AfterApply via validate.Struct
	if c.Build.OutputPath == "" || c.Build.Bucket == "" {
		spikeCallOrder = append(spikeCallOrder, "ValidationFailed")

		// In real code this returns an error, but for the spike we just record it
	}
	return nil
}

func TestSpike_A2_BeforeApplyFiresBeforeValidation(t *testing.T) {
	spikeBeforeApplyFired = false
	spikeCallOrder = nil

	cli := &spikeCLI_A2_Validation{}
	app, err := kong.New(cli,
		kong.Name("spike-a2-val"),
		kong.Exit(func(int) {}),
		kong.Bind(cli),
	)
	if err != nil {
		t.Fatalf("kong.New: %v", err)
	}

	// Pass --on but omit required fields (output-path, bucket)
	_, err = app.Parse([]string{"--on", "myserver", "build"})
	if err != nil {
		t.Fatalf("kong.Parse: %v", err)
	}

	if !spikeBeforeApplyFired {
		t.Fatal("REFUTED: BeforeApply did not fire")
	}

	// Verify BeforeApply came before AfterApply (and thus before validation)
	beforeIdx := -1
	afterIdx := -1
	for i, call := range spikeCallOrder {
		if call == "BeforeApply:on" && beforeIdx == -1 {
			beforeIdx = i
		}
		if call == "AfterApply:validation-cli" && afterIdx == -1 {
			afterIdx = i
		}
	}
	if beforeIdx == -1 {
		t.Fatal("BeforeApply:on not found in call order")
	}
	if afterIdx == -1 {
		t.Fatal("AfterApply:validation-cli not found in call order")
	}
	if beforeIdx >= afterIdx {
		t.Fatalf("REFUTED: BeforeApply did not fire before AfterApply; order=%v", spikeCallOrder)
	}

	t.Logf("CONFIRMED: BeforeApply fires before AfterApply (which contains validation); order=%v", spikeCallOrder)
	t.Logf("CONFIRMED: --on flag can short-circuit (os.Exit) before validation rejects missing server-only state")
}

// ---------------------------------------------------------------------------
// A5: top-level `remote` subcommand vs --on global flag
//

// Hypothesis: A top-level `remote` subcommand is less invasive to Kong than
// a --on global flag, because subcommands don't require modifying Globals or
// adding BeforeApply hooks.
//

// Test: Build both shapes in minimal Kong structs, verify:
//   1. Both can parse successfully
//   2. The global flag shape requires a BeforeApply to intercept
//   3. The subcommand shape naturally gets its own Run() — no interception needed
//   4. Compare wiring complexity
// ---------------------------------------------------------------------------

// Shape 1: --on global flag (already tested above in A2)
// Shape 2: top-level `remote` subcommand

type spikeCLI_A5_Subcommand struct {
	Remote struct {
		Server string   `arg:"" help:"Server to run on."`
		Args   []string `arg:"" optional:"" help:"Command and args to run remotely."`
	} `cmd:"" help:"Execute a command on a remote server."`
	Echo struct {
		Message string `arg:"" help:"Message."`
	} `cmd:"" help:"Echo."`
}

func TestSpike_A5_SubcommandShapeParsesCleanly(t *testing.T) {
	cli := &spikeCLI_A5_Subcommand{}
	app, err := kong.New(cli,
		kong.Name("spike-a5"),
		kong.Exit(func(int) {}),
	)
	if err != nil {
		t.Fatalf("kong.New: %v", err)
	}

	// Test 1: remote subcommand with flags — Kong rejects flags in passthrough args
	_, err = app.Parse([]string{"remote", "myserver", "fedlib", "build", "--output-path", "/tmp"})
	if err != nil {
		t.Logf("FINDING: remote subcommand rejects flags in passthrough args: %v", err)
		t.Logf("FINDING: Kong []string arg captures positionals only; flags like --output-path are rejected as 'unknown flag'")
		t.Logf("IMPLICATION: remote subcommand shape requires kong.PassthroughMode or manual quoting to forward flags")
	} else {
		t.Logf("remote subcommand parsed flags successfully (unexpected)")
	}

	// Test 2: remote subcommand with positional-only args (no flags)
	cli2 := &spikeCLI_A5_Subcommand{}
	app2, _ := kong.New(cli2, kong.Name("spike-a5-2"), kong.Exit(func(int) {}))
	ctx, err := app2.Parse([]string{"remote", "myserver", "fedlib", "build"})
	if err != nil {
		t.Fatalf("remote subcommand with positional-only args failed: %v", err)
	}
	if cli2.Remote.Server != "myserver" {
		t.Fatalf("expected server=myserver, got %q", cli2.Remote.Server)
	}
	expected := []string{"fedlib", "build"}
	if len(cli2.Remote.Args) != len(expected) {
		t.Fatalf("expected args=%v, got %v", expected, cli2.Remote.Args)
	}
	for i, arg := range expected {
		if cli2.Remote.Args[i] != arg {
			t.Fatalf("args[%d]: expected %q, got %q", i, arg, cli2.Remote.Args[i])
		}
	}

	t.Logf("CONFIRMED: remote subcommand parses positional args cleanly; server=%q args=%v selected=%s",
		cli2.Remote.Server, cli2.Remote.Args, ctx.Command())
	t.Logf("FINDING: remote subcommand CANNOT forward flags without PassthroughMode — significant limitation vs. --on global flag")
}

func TestSpike_A5_GlobalFlagShapeDoesNotConflictWithSubcommands(t *testing.T) {

	// Test: --on global flag doesn't interfere with normal subcommand dispatch
	spikeBeforeApplyFired = false
	spikeCallOrder = nil

	cli := &spikeCLI_A2{}
	app, err := kong.New(cli,
		kong.Name("spike-a5-flag"),
		kong.Exit(func(int) {}),
		kong.Bind(cli),
	)
	if err != nil {
		t.Fatalf("kong.New: %v", err)
	}

	// Without --on, BeforeApply should still fire but with empty value
	_, err = app.Parse([]string{"echo", "hello"})
	if err != nil {
		t.Fatalf("parse without --on: %v", err)
	}

	// BeforeApply fires even for empty/default value — this is a key finding
	t.Logf("BeforeApply fired without --on: %v (order: %v)", spikeBeforeApplyFired, spikeCallOrder)
	t.Logf("FINDING: BeforeApply fires for default values too — the --on handler must check if value is non-empty before intercepting")
}

// ---------------------------------------------------------------------------
// A5 comparison: structural complexity
// ---------------------------------------------------------------------------

func TestSpike_A5_CompareWiringComplexity(t *testing.T) {
	findings := []string{
		"Global --on flag:",
		"  + Works across ALL subcommands (fedlib build, fedlib share live, lib build, etc.)",
		"  + Single interception point in BeforeApply",
		"  - Requires BeforeApply hook on flag type",
		"  - BeforeApply fires for default empty value; must guard with if-check",
		"  - Must be careful not to trigger AfterApply credential resolution for remote commands",
		"  - Flag is visible in --help for every command (noise for local-only commands)",
		"",
		"Top-level remote subcommand:",
		"  + Clean separation: remote vs. local execution is a command, not a flag",
		"  + Run() method handles SSH naturally; no hook interception needed",
		"  + No impact on existing AfterApply/validation",
		"  - Captures remaining args as []string; loses Kong parsing/validation on the remote side",
		"  - Cannot share alias persistence with local commands (different command path)",
		"  - Syntax: 'accorder remote myserver fedlib build ...' (extra word)",
		"  - Would need to re-serialize args for SSH; loses type safety",
		"",
		"Recommendation: --on global flag is LESS invasive for this use case because:",
		"  1. It reuses the existing command tree unchanged",
		"  2. BeforeApply fires before AfterApply, allowing clean SSH re-exec",
		"  3. The remote server runs the exact same command (just without --on)",
		"  4. No arg re-serialization needed — forward os.Args minus --on",
	}
	for _, f := range findings {
		t.Log(f)
	}
}

// ---------------------------------------------------------------------------
// A1: IAM scoped policy restricts serve-key to its own prefix
//

// Hypothesis: The serve key (keys/lib.s3.keys) uses credentials scoped to
// the aggregate prefix only. buildScopedPolicy() creates a policy that
// restricts writes to <bucket>/<prefix>/*. A serve key scoped to "aggregate"
// cannot write to member prefixes like "alice", "bob", etc.
//

// This is a code-reading spike: verify the policy document shape.
// ---------------------------------------------------------------------------

func TestSpike_A1_ScopedPolicyRestrictsToPrefix(t *testing.T) {
	policy := buildScopedPolicy("motw", "aggregate")

	policyJSON, err := json.MarshalIndent(policy, "", "  ")
	if err != nil {
		t.Fatalf("marshal policy: %v", err)
	}
	t.Logf("Scoped policy for bucket=motw, prefix=aggregate:\n%s", policyJSON)

	// Verify: AllowObjectOps only covers aggregate/ and aggregate/*
	objectOps := policy.Statement[0]
	if objectOps.Sid != "AllowObjectOps" {
		t.Fatalf("expected first statement Sid=AllowObjectOps, got %q", objectOps.Sid)
	}

	resources, ok := objectOps.Resource.([]string)
	if !ok {
		t.Fatalf("expected Resource to be []string, got %T", objectOps.Resource)
	}

	expectedResources := []string{
		"arn:aws:s3:::motw/aggregate",
		"arn:aws:s3:::motw/aggregate/*",
	}
	if len(resources) != len(expectedResources) {
		t.Fatalf("expected %d resources, got %d: %v", len(expectedResources), len(resources), resources)
	}
	for i, r := range expectedResources {
		if resources[i] != r {
			t.Fatalf("resource[%d]: expected %q, got %q", i, r, resources[i])
		}
	}

	// Verify: no resource covers member prefixes
	for _, r := range resources {
		if !strings.Contains(r, "/aggregate") {
			t.Fatalf("REFUTED: resource %q does not contain /aggregate — may cover member prefixes", r)
		}
	}

	// Verify: ListBucket has prefix condition
	listOps := policy.Statement[1]
	if listOps.Sid != "AllowListBucket" {
		t.Fatalf("expected second statement Sid=AllowListBucket, got %q", listOps.Sid)
	}
	prefixCond, ok := listOps.Condition["StringLike"]["s3:prefix"]
	if !ok {
		t.Fatal("REFUTED: ListBucket has no s3:prefix condition — can list all prefixes")
	}
	prefixes, ok := prefixCond.([]string)
	if !ok {
		t.Fatalf("expected prefix condition to be []string, got %T", prefixCond)
	}
	for _, p := range prefixes {
		if !strings.HasPrefix(p, "aggregate") {
			t.Fatalf("REFUTED: ListBucket prefix condition %q does not start with 'aggregate'", p)
		}
	}

	t.Logf("CONFIRMED: buildScopedPolicy('motw', 'aggregate') restricts all ops to arn:aws:s3:::motw/aggregate[/*]")
	t.Logf("CONFIRMED: A serve key scoped to 'aggregate' CANNOT write to member prefixes like 'alice/', 'bob/'")
	t.Logf("IMPLICATION: A separate build key with broader scope (or root key) IS needed to read member indexes during fedlib build")
}

// ---------------------------------------------------------------------------
// A1 supplement: verify that the serve key file used on the server defaults
// to the aggregate prefix, not the bucket root.
// ---------------------------------------------------------------------------

func TestSpike_A1_ServeKeyFileDoesNotScopeBucket(t *testing.T) {
	_ = testSetup(t)

	// Write a serve key file mimicking deploy script
	keysDir := filepath.Join(accorderConfigDir, "keys")
	if err := os.MkdirAll(keysDir, 0o755); err != nil {
		t.Fatalf("mkdir keys: %v", err)
	}
	kfPath := filepath.Join(keysDir, "lib.s3.keys")
	if err := writeKeysFile(kfPath, s3KeysFile{
		AccessKey: "AKIASERVEONLY",
		SecretKey: "serve-secret",
		Provider:  "Wasabi",
		Endpoint:  "https://s3.wasabisys.com",
		Bucket:    "motw",
	}); err != nil {
		t.Fatalf("writeKeysFile: %v", err)
	}

	// Parse fedlib build with alias "lib" (which maps to keys/lib.s3.keys)
	outputPath := t.TempDir()
	cli, _, err := parseCLIErr(t, []string{
		"fedlib", "build", "lib",
		"--output-path", outputPath,
	})
	if err != nil {
		t.Fatalf("parse: %v", err)
	}

	b := &cli.Fedlib.Build
	if b.Bucket != "motw" {
		t.Fatalf("expected Bucket=motw from keys file, got %q", b.Bucket)
	}
	if b.S3AccessKey != "AKIASERVEONLY" {
		t.Fatalf("expected access key from keys file, got %q", b.S3AccessKey)
	}

	t.Logf("CONFIRMED: serve keys file resolves bucket='motw' (unscoped) — IAM policy is the only enforcement")
	t.Logf("FINDING: If fedlib build runs with serve-key credentials, it will attempt writes to motw/aggregate/ (allowed by IAM)")
	t.Logf("FINDING: But fedlib build also READS from motw/<member-prefix>/static/library_index.zst — this requires s3:GetObject on member prefixes")

	// Verify: the scoped policy for "aggregate" does NOT grant s3:GetObject on member prefixes
	policy := buildScopedPolicy("motw", "aggregate")
	objOps := policy.Statement[0]
	resources := objOps.Resource.([]string)

	coversMembers := false
	for _, r := range resources {
		if r == "arn:aws:s3:::motw/*" || r == "arn:aws:s3:::motw" {
			coversMembers = true
		}
	}

	if coversMembers {
		t.Log("FINDING: scoped policy covers all of motw/* — members are readable")
	} else {
		t.Log("CONFIRMED: scoped policy for 'aggregate' does NOT cover member prefixes")
		t.Log("IMPLICATION: fedlib build on the server needs EITHER:")
		t.Log("  1. A key scoped to the whole bucket (root key / full-access key)")
		t.Log("  2. Separate scoped keys per member prefix (complex)")
		t.Log("  3. A key with a broader policy covering both aggregate/* and <member>/* for all members")
	}
}

// ---------------------------------------------------------------------------
// A3: fedlib build structural determinism
//

// Hypothesis: Given the same aggregate_libraries.json and the same member
// indexes, fedlib build produces a structurally identical output.
//

// Test: Verify the deterministic components: computeAggregateBaseGen and
// the identity hash computation.
// ---------------------------------------------------------------------------

func TestSpike_A3_AggregateBaseGenIsDeterministic(t *testing.T) {
	members := []aggMemberGen{
		{uuid: "aaa-111", bookCount: 10, lastModified: "2024-01-01", idxBaseGen: [16]byte{1, 2, 3}, idxGen: 1},
		{uuid: "bbb-222", bookCount: 5, lastModified: "2024-06-15", idxBaseGen: [16]byte{4, 5, 6}, idxGen: 2},
	}

	gen1 := computeAggregateBaseGen(members)
	gen2 := computeAggregateBaseGen(members)

	if gen1 != gen2 {
		t.Fatalf("REFUTED: computeAggregateBaseGen is not deterministic: %x != %x", gen1, gen2)
	}
	t.Logf("CONFIRMED: computeAggregateBaseGen is deterministic: %x", gen1)

	// Verify: changing a member's input changes the output
	members[0].bookCount = 11
	gen3 := computeAggregateBaseGen(members)
	if gen3 == gen1 {
		t.Fatal("REFUTED: changing bookCount did not change BaseGeneration — hash is too weak")
	}
	t.Logf("CONFIRMED: changing bookCount changes BaseGeneration: %x -> %x", gen1, gen3)

	// Verify: member order matters (members are pre-sorted by UUID)
	reversed := []aggMemberGen{members[1], members[0]}
	genReversed := computeAggregateBaseGen(reversed)
	if genReversed == gen3 {
		t.Log("FINDING: member order does NOT affect BaseGeneration — sort is external")
	} else {
		t.Log("CONFIRMED: member order affects BaseGeneration — callers must sort UUIDs first")
	}
}

func TestSpike_A3_AggregateIdentityIsDeterministic(t *testing.T) {

	// The identity hash in fedlibBuild.go:199-204 is:
	//   SHA256 of sorted UUIDs joined by \x00, truncated to [16]byte
	computeIdentity := func(uuids []string) [16]byte {
		sorted := make([]string, len(uuids))
		copy(sorted, uuids)
		sort.Strings(sorted)

		h := sha256.New()
		for _, u := range sorted {
			fmt.Fprintf(h, "%s\x00", u)
		}
		var id [16]byte
		copy(id[:], h.Sum(nil))
		return id
	}

	id1 := computeIdentity([]string{"bbb-222", "aaa-111"})
	id2 := computeIdentity([]string{"aaa-111", "bbb-222"})

	if id1 != id2 {
		t.Fatalf("REFUTED: identity hash is not order-independent after sort: %x != %x", id1, id2)
	}
	t.Logf("CONFIRMED: identity hash is deterministic and order-independent: %x", id1)

	// Adding a member changes the identity
	id3 := computeIdentity([]string{"aaa-111", "bbb-222", "ccc-333"})
	if id3 == id1 {
		t.Fatal("REFUTED: adding a member did not change identity")
	}
	t.Logf("CONFIRMED: adding a member changes identity: %x -> %x", id1, id3)

	t.Logf("IMPLICATION: fedlib build on server with same registry produces same Identity as laptop build")
	t.Logf("CAVEAT: Byte-level identity of library_index.zst is NOT guaranteed (zstd frame metadata, compression dict training)")
}
