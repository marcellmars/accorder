//go:build !tailscale

package cmd

// Phase 0 discovery tests for the config-prune-doctor workflow (study.md
// Phase 7: two unvalidated assumptions). Fixture rows are derived from the
// real pre-cleanup backup
// (~/.config/accorder/backups/action_aliases.json.bak-pre-marcellmarslib-cleanup-20260705);
// the values are inlined below so the tests never touch $HOME.

import (
	"path/filepath"
	"reflect"
	"testing"
)

// ═══════════════════════════════════════════════════════════════════
// Assumption 1: default-shadow equality (applyBuildDefaults,
// cmd/libBuild.go:493-504). A stored index-path is prunable iff it equals
// filepath.Join(calibrepath, "static", "library_index"). Join *cleans* its
// output, so naive string equality only matches already-clean stored
// values; filepath.Clean on both sides must flag every true shadow and no
// non-shadow (zero false positives).
// ═══════════════════════════════════════════════════════════════════

func TestPrunePhase0_DefaultShadowEquality(t *testing.T) {
	rows := []struct {
		name        string
		calibrepath string
		stored      string
		shadow      bool // ground truth: same location as the computed default
	}{

		// Real backup rows:
		{"backup: trailing-slash calibrepath, clean stored", "/home/w/CalibreLibraries/MarcellMarsBooks/", "/home/w/CalibreLibraries/MarcellMarsBooks/static/library_index", true},
		{"backup: deliberate other index (lib.import)", "/home/w/CalibreLibraries/MarcellMarsBooks/", "/tmp/fpv/library_index", false},
		{"backup: sibling-dir trap (aggbuild-biopolitics)", "/tmp/accorder-aggtest/biopolitics/cal", "/tmp/accorder-aggtest/biopolitics/static/library_index", false},
		{"backup: unrelated abs (default alias)", "/tmp/cvtest", "/home/w/agg-build/library_index", false},

		// Synthetic variants of the same shapes:
		{"redundant separators + dot segment in stored", "/lib/dir", "/lib/dir//static/./library_index", true},
		{"relative calibrepath, clean stored", "rel/dir", "rel/dir/static/library_index", true},
		{"relative calibrepath, ./-prefixed stored", "rel/dir", "./rel/dir/static/library_index", true},
		{"rel stored vs abs calibrepath must NOT match", "/abs/dir", "abs/dir/static/library_index", false},
	}
	naiveMisses := 0
	for _, r := range rows {
		def := filepath.Join(r.calibrepath, "static", "library_index")
		naive := r.stored == def
		clean := filepath.Clean(r.stored) == filepath.Clean(def)
		if naive && !r.shadow {
			t.Errorf("%s: naive equality FALSE POSITIVE (stored %q == computed %q)", r.name, r.stored, def)
		}
		if !naive && r.shadow {
			naiveMisses++ // naive false negative: shadow survives prune
		}
		if clean != r.shadow {
			t.Errorf("%s: Clean-equality = %v, want %v (stored %q vs computed %q)", r.name, clean, r.shadow, r.stored, def)
		}
	}
	t.Logf("naive equality false negatives: %d/8 rows", naiveMisses)
	if naiveMisses == 0 {
		t.Error("expected naive equality to miss at least one unclean shadow")
	}
}

// The JsonLPath default (config-dir cache path) is the same Join-vs-stored
// comparison; the real stored /tmp/marcell.jsonl must never be flagged.
func TestPrunePhase0_JsonlDefaultShadow(t *testing.T) {
	testSetup(t)
	def := filepath.Join(accorderConfigDir, "cache", "marcellmarslib.jsonl")
	if filepath.Clean("/tmp/marcell.jsonl") == filepath.Clean(def) {
		t.Error("real stored jsonl-path flagged as default shadow")
	}
	unclean := filepath.Join(accorderConfigDir, "cache") + "//./marcellmarslib.jsonl"
	if filepath.Clean(unclean) != filepath.Clean(def) {
		t.Errorf("unclean stored default not recognized: %q vs %q", unclean, def)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Assumption 2: fieldByJSONName (cmd/cli.go:159) as a read-only liveness
// oracle over a throwaway &CLI{}.
// ═══════════════════════════════════════════════════════════════════

// (a) Value-level fieldByJSONName: mutations (nil-pointer instantiation)
// are confined to the throwaway, but the scan is direct-fields-only — it
// reports promoted embedded-struct keys as ABSENT, and it panics on
// non-addressable values holding nil pointer fields.
func TestPrunePhase0_FieldByJSONName_ThrowawayValue(t *testing.T) {
	upload, err := navigateByJSONPath(reflect.ValueOf(&CLI{}), []string{"lib", "upload"})
	if err != nil {
		t.Fatalf("navigate lib.upload: %v", err)
	}
	if fieldByJSONName(upload, "keys-file").IsValid() {
		t.Error("unexpected: direct-field scan found promoted keys-file on LibUploadCmd")
	} else {
		t.Log("falsified: keys-file (embedded GroupS3Credentials) reported absent on lib.upload")
	}

	build, err := navigateByJSONPath(reflect.ValueOf(&CLI{}), []string{"lib", "build"})
	if err != nil {
		t.Fatalf("navigate lib.build: %v", err)
	}
	if !fieldByJSONName(build, "keys-file").IsValid() {
		t.Error("direct field keys-file on LibBuildCmd not found")
	}
	if fieldByJSONName(build, "librarian").IsValid() {
		t.Error("unexpected: found librarian (embedded GroupLib) via direct-field scan")
	}
	if fieldByJSONName(build, "no-such-flag").IsValid() {
		t.Error("absent key reported present")
	}

	// Pointer field on its declaring struct: found, with the documented
	// instantiation side effect — harmless on an addressable throwaway.
	g := &GroupLib{}
	if !fieldByJSONName(reflect.ValueOf(g).Elem(), "baseurl").IsValid() {
		t.Error("pointer field baseurl not found on GroupLib")
	}
	if g.BaseURL == nil {
		t.Error("expected nil-pointer instantiation side effect on throwaway")
	}

	// Non-addressable value + nil pointer field = panic (fv.Set).
	defer func() {
		if recover() == nil {
			t.Error("expected panic on non-addressable value with nil pointer field")
		}
	}()
	fieldByJSONName(reflect.ValueOf(GroupLib{}), "baseurl")
}

// (b) Type-level variant: the existing getFieldTags (cmd/cli.go:36) already
// walks reflect.Type, recurses into anonymous embeds, and never touches
// values. Exercised over direct, embedded, doubly-embedded, pointer, and
// absent cases — plus its caveat: it also matches Go field NAMES.
func TestPrunePhase0_TypeLevelLookup(t *testing.T) {
	cases := []struct {
		typ   reflect.Type
		key   string
		found bool
	}{
		{reflect.TypeOf(LibBuildCmd{}), "keys-file", true},     // direct field
		{reflect.TypeOf(LibUploadCmd{}), "keys-file", true},    // embedded GroupS3Credentials
		{reflect.TypeOf(LibBuildCmd{}), "librarian", true},     // embedded GroupLib
		{reflect.TypeOf(LibBuildCmd{}), "calibrepath", true},   // doubly embedded GroupLib→GroupLibDir
		{reflect.TypeOf(LibBuildCmd{}), "baseurl", true},       // pointer field via embed
		{reflect.TypeOf(LibBuildCmd{}), "no-such-flag", false}, // absent
	}
	for _, c := range cases {
		if _, ok := getFieldTags(c.typ, c.key); ok != c.found {
			t.Errorf("getFieldTags(%s, %q) found=%v, want %v", c.typ.Name(), c.key, ok, c.found)
		}
	}

	// Caveat: Go field-name match. A liveness walker feeding lowercase JSON
	// keys is unaffected, but the helper is not json-name-strict.
	if tags, ok := getFieldTags(reflect.TypeOf(LibUploadCmd{}), "Bucket"); !ok || tags.JSONName != "bucket" {
		t.Errorf("expected Go-name match Bucket→bucket, got ok=%v tags=%+v", ok, tags)
	}

	// Caveat: json:"-" fields match by Go name; a walker must treat
	// JSONName "-"/"" as not-live.
	if tags, ok := getFieldTags(reflect.TypeOf(LibUploadCmd{}), "Files"); !ok || tags.JSONName != "-" {
		t.Errorf("expected Files to resolve with JSONName \"-\", got ok=%v tags=%+v", ok, tags)
	}
}
