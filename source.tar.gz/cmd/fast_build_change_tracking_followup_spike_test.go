package cmd

import (
	"bytes"
	"encoding/hex"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
	"time"

	"accorder/pkg/calibre"
	"accorder/pkg/libraryflow"
	"accorder/pkg/torshare"
)

func TestSpikeFollowupCoverageWithoutRefreshedTimestampTrust(t *testing.T) {
	testSetup(t)
	const (
		alias     = "coverage"
		libraryID = "550e8400-e29b-41d4-a716-446655440000"
		payload   = "Author/Book (1)/book.epub"
	)

	remoteRoot := t.TempDir()
	writeTestFile(t, remoteRoot, "metadata.db", "metadata")
	writeTestFile(t, remoteRoot, payload, "old!")
	seedCommittedRemote(t, remoteRoot, 7)
	withLocalCommandRemote(t, remoteRoot)

	destination := filepath.Join(t.TempDir(), "Coverage Library")
	command := &LibSyncCmd{
		GroupLib: GroupLib{
			GroupLibDir: GroupLibDir{CalibreDirectory: destination},
			LibraryID:   libraryID,
		},
		ExpectedLibraryID: libraryID,
	}
	command.ActionAlias = alias
	if err := command.Run(nil); err != nil {
		t.Fatal(err)
	}

	before, err := loadBaseline(alias)
	if err != nil || before == nil {
		t.Fatalf("initial baseline=%+v err=%v", before, err)
	}
	// Seed the historical v0 fixture explicitly; new sync now creates v2.
	if err := os.Remove(baselineStatePath(alias)); err != nil {
		t.Fatal(err)
	}
	before.ContentLedgerVersion, before.ContentLedger, before.Evidence = 0, nil, nil
	before.GenerationToken = ""
	if err := saveBaseline(alias, *before); err != nil {
		t.Fatal(err)
	}
	remoteToken, err := os.ReadFile(filepath.Join(remoteRoot, libraryflow.GenerationPath))
	if err != nil {
		t.Fatal(err)
	}

	localPayload := filepath.Join(destination, filepath.FromSlash(payload))
	oldInfo, err := os.Stat(localPayload)
	if err != nil {
		t.Fatal(err)
	}
	time.Sleep(2 * time.Millisecond)
	if err := os.WriteFile(localPayload, []byte("new!"), 0o644); err != nil {
		t.Fatal(err)
	}
	if err := os.Chtimes(localPayload, oldInfo.ModTime(), oldInfo.ModTime()); err != nil {
		t.Fatal(err)
	}
	newInfo, err := os.Stat(localPayload)
	if err != nil {
		t.Fatal(err)
	}
	if newInfo.Size() != oldInfo.Size() || !newInfo.ModTime().Equal(oldInfo.ModTime()) {
		t.Fatalf("rewrite did not preserve size/mtime: before=(%d,%s) after=(%d,%s)", oldInfo.Size(), oldInfo.ModTime(), newInfo.Size(), newInfo.ModTime())
	}

	localFingerprint, _, err := libraryflow.SourceFingerprint(destination, nil)
	if err != nil {
		t.Fatal(err)
	}
	remoteSnapshot := (&libraryRemote{fsPath: remoteRoot}).commitState()
	if remoteSnapshot.Err != nil || !remoteSnapshot.Committed || localFingerprint != remoteSnapshot.SourceFingerprint {
		t.Fatalf("same-size rewrite did not reach converged branch: local=%q remote=%+v", localFingerprint, remoteSnapshot)
	}

	if err := command.Run(nil); err == nil {
		t.Fatal("unproved v0 convergence accepted")
	}
	after, err := loadBaseline(alias)
	if err != nil || after == nil {
		t.Fatalf("refreshed baseline=%+v err=%v", after, err)
	}
	if !after.UpdatedAt.Equal(before.UpdatedAt) || after.Generation != before.Generation || after.ContentLedgerVersion != 0 {
		t.Fatalf("unexpected before/after baseline: before=%+v after=%+v", before, after)
	}
	localBytes, err := os.ReadFile(localPayload)
	if err != nil {
		t.Fatal(err)
	}
	remoteBytes, err := os.ReadFile(filepath.Join(remoteRoot, filepath.FromSlash(payload)))
	if err != nil {
		t.Fatal(err)
	}
	if string(localBytes) != "new!" || string(remoteBytes) != "old!" || bytes.Equal(localBytes, remoteBytes) {
		t.Fatalf("byte readback did not preserve divergent no-transfer fixture: local=%q remote=%q", localBytes, remoteBytes)
	}

	objects, err := listLocalObjects(destination)
	if err != nil {
		t.Fatal(err)
	}
	ledger, _, _, err := buildContentLedger(destination, objects, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	changedBeforeRefresh, ok := legacyBaselineUpgradeChanges(before, hex.EncodeToString(remoteToken), ledger)
	if !ok || !reflect.DeepEqual(changedBeforeRefresh, []string{payload}) {
		t.Fatalf("pre-refresh cutoff changed=%v ok=%t, want rewritten payload", changedBeforeRefresh, ok)
	}
	changedAfterRefresh, ok := legacyBaselineUpgradeChanges(after, hex.EncodeToString(remoteToken), ledger)
	if !ok || !reflect.DeepEqual(changedAfterRefresh, changedBeforeRefresh) {
		t.Fatalf("refusal changed v0 cutoff: changed=%v ok=%t", changedAfterRefresh, ok)
	}

	_, generation, err := torshare.DecodeGeneration(remoteToken)
	if err != nil {
		t.Fatal(err)
	}
	var otherBase [16]byte
	otherBase[0] = 99
	otherBaseToken := torshare.EncodeGeneration(otherBase, generation)
	if changed, ok := legacyBaselineUpgradeChanges(after, hex.EncodeToString(otherBaseToken), ledger); !ok || !reflect.DeepEqual(changed, changedBeforeRefresh) {
		t.Fatalf("legacy helper did not expose numeric-generation-only boundary: changed=%v ok=%t", changed, ok)
	}
	if _, err := spikeImportProvenCoverage(after, hex.EncodeToString(remoteToken)); err == nil || !strings.Contains(err.Error(), "v0") {
		t.Fatalf("ambiguous refreshed v0 coverage was accepted: %v", err)
	}

	checksum := strings.Repeat("a", 64)
	v1 := libraryBaseline{
		LibraryID: libraryID, RemoteSourceFingerprint: localFingerprint, LocalSourceFingerprint: localFingerprint,
		Generation: generation, GenerationToken: hex.EncodeToString(remoteToken), CatalogChecksum: checksum,
		ContentLedgerVersion: 1, ContentLedger: ledger,
	}
	if err := saveBaseline("coverage-v1", v1); err != nil {
		t.Fatal(err)
	}
	loadedV1, err := loadBaseline("coverage-v1")
	if err != nil || loadedV1 == nil {
		t.Fatalf("load v1 baseline=%+v err=%v", loadedV1, err)
	}
	preserved, err := spikeImportProvenCoverage(loadedV1, hex.EncodeToString(remoteToken))
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(preserved, ledger) {
		t.Fatalf("v1 content evidence changed during adapter import: got=%+v want=%+v", preserved, ledger)
	}
	if _, err := spikeImportProvenCoverage(loadedV1, hex.EncodeToString(otherBaseToken)); err == nil || !strings.Contains(err.Error(), "full predecessor") {
		t.Fatalf("different-base token with generation %d was accepted: %v", generation, err)
	}

	fromCount := uint32(0)
	change := localChangeCandidate{
		Version: localChangeCandidateVersion, LibraryUUID: libraryID,
		Scope: calibre.GenerationChangeScopeExact, FromGeneration: hex.EncodeToString(remoteToken),
		FromLiveCount: &fromCount, FromCatalogChecksum: checksum,
		TargetSourceFingerprint: localFingerprint, ToLiveCount: 0, ToCatalogChecksum: checksum,
		ContentLedgerVersion: 1, ContentLedger: ledger,
	}
	pointer := calibre.PointerFile{
		Library: calibre.PointerFileLibrary{UUID: libraryID},
		Index:   calibre.PointerFileIndex{NumBooks: 0}, CatalogChecksum: checksum,
		SourceFingerprint: localFingerprint,
	}
	local := &libraryCandidate{SourceFingerprint: localFingerprint, Change: &change}
	targetToken := torshare.EncodeGeneration(generationChangeBase(), generation+1)
	exact, err := bindGenerationPublication(remoteLibrarySnapshot{
		Pointer: pointer, PointerRaw: []byte("non-empty"), GenerationRaw: remoteToken,
		Generation: generation, SourceFingerprint: localFingerprint, Committed: true,
	}, pointer, local, targetToken, localFingerprint)
	if err != nil {
		t.Fatal(err)
	}
	if exact.Scope != calibre.GenerationChangeScopeExact || exact.CompleteOverwrite {
		t.Fatalf("actual full-token predecessor did not bind exactly: %+v", exact)
	}
	mismatch, err := bindGenerationPublication(remoteLibrarySnapshot{
		Pointer: pointer, PointerRaw: []byte("non-empty"), GenerationRaw: otherBaseToken,
		Generation: generation, SourceFingerprint: localFingerprint, Committed: true,
	}, pointer, local, targetToken, localFingerprint)
	if err != nil {
		t.Fatal(err)
	}
	if mismatch.Scope != calibre.GenerationChangeScopeCoarse || !mismatch.CompleteOverwrite || mismatch.Reason != "remote-predecessor-mismatch" {
		t.Fatalf("different-base predecessor was not rejected by actual binding: %+v", mismatch)
	}

	t.Logf("real converged sync advanced v0 cutoff from %s to %s while byte readback remained local=%q remote=%q; strict v1 policy retained %d hashes and rejected same-generation token %x", before.UpdatedAt.UTC(), after.UpdatedAt.UTC(), localBytes, remoteBytes, len(preserved), otherBaseToken)
}

func TestSpikeFollowupDurableIdentityAndV1StateSupportBoundedMigration(t *testing.T) {
	t.Run("identity and production v1 loaders", func(t *testing.T) {
		testSetup(t)
		const (
			libraryID = "550e8400-e29b-41d4-a716-446655440000"
			payload   = "Author/Book (1)/book.epub"
		)

		installation, err := loadOrCreateInstallation()
		if err != nil {
			t.Fatal(err)
		}
		reloadedInstallation, err := loadInstallation()
		if err != nil || reloadedInstallation != installation {
			t.Fatalf("installation reload=%+v err=%v, want %+v", reloadedInstallation, err, installation)
		}
		originalConfigDir := accorderConfigDir
		t.Cleanup(func() { accorderConfigDir = originalConfigDir })
		installationRaw, err := os.ReadFile(installationStatePath())
		if err != nil {
			t.Fatal(err)
		}
		copiedConfigDir := t.TempDir()
		copiedInstallationPath := filepath.Join(copiedConfigDir, "machine-state", "installation.json")
		if err := os.MkdirAll(filepath.Dir(copiedInstallationPath), 0o700); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(copiedInstallationPath, installationRaw, 0o600); err != nil {
			t.Fatal(err)
		}
		accorderConfigDir = copiedConfigDir
		copiedInstallation, err := loadOrCreateInstallation()
		if err != nil {
			t.Fatal(err)
		}
		if copiedInstallation != installation {
			t.Fatalf("copied installation changed identity: copied=%+v original=%+v", copiedInstallation, installation)
		}
		accorderConfigDir = originalConfigDir

		sourceRoot := t.TempDir()
		writeTestFile(t, sourceRoot, "metadata.db", "metadata")
		writeTestFile(t, sourceRoot, payload, "same")
		objects, err := listLocalObjects(sourceRoot)
		if err != nil {
			t.Fatal(err)
		}
		ledger, _, _, err := buildContentLedger(sourceRoot, objects, nil, nil)
		if err != nil {
			t.Fatal(err)
		}
		if len(ledger) != 2 {
			t.Fatalf("source ledger=%+v, want metadata and payload", ledger)
		}

		var base [16]byte
		base[0] = 41
		predecessorToken := torshare.EncodeGeneration(base, 10)
		bookA := spikeBook("00000000-0000-4000-8000-000000000931", libraryID, "Author/Book (1)", "A")
		bookB := spikeCloneBook(bookA)
		bookB.Title, bookB.TitleSort = "B", "B"
		bookC := spikeCloneBook(bookB)
		bookC.Title, bookC.TitleSort = "C", "C"
		infoA, err := calibre.CatalogRecordInfoForBook(bookA)
		if err != nil {
			t.Fatal(err)
		}
		diffAB, err := calibre.CompileCatalogDiffFromRecordInfos([]*calibre.Book{bookB}, map[string]calibre.CatalogRecordInfo{bookA.Id: infoA})
		if err != nil {
			t.Fatal(err)
		}
		infoB, err := calibre.CatalogRecordInfoForBook(bookB)
		if err != nil {
			t.Fatal(err)
		}
		diffBC, err := calibre.CompileCatalogDiffFromRecordInfos([]*calibre.Book{bookC}, map[string]calibre.CatalogRecordInfo{bookB.Id: infoB})
		if err != nil {
			t.Fatal(err)
		}

		completed := libraryBaseline{
			LibraryID: libraryID, RemoteSourceFingerprint: strings.Repeat("a", 64), LocalSourceFingerprint: strings.Repeat("a", 64),
			Generation: 10, GenerationToken: hex.EncodeToString(predecessorToken), CatalogChecksum: diffAB.FromChecksum,
			ContentLedgerVersion: 1, ContentLedger: ledger,
		}
		if err := saveBaseline("migration", completed); err != nil {
			t.Fatal(err)
		}
		loadedBaseline, err := loadBaseline("migration")
		if err != nil || loadedBaseline == nil {
			t.Fatalf("production baseline loader=%+v err=%v", loadedBaseline, err)
		}

		prior := spikeCandidateFromDiff(diffAB, libraryID, hex.EncodeToString(predecessorToken), ledger[0])
		prior.ContentLedger = append([]libraryflow.Object(nil), ledger...)
		prior.ForcePaths = []string{payload}
		candidateRoot := t.TempDir()
		if err := saveLocalChangeCandidate(candidateRoot, prior); err != nil {
			t.Fatal(err)
		}
		loadedPrior, err := loadLocalChangeCandidate(candidateRoot)
		if err != nil {
			t.Fatal(err)
		}
		delta := spikeCandidateFromDiff(diffBC, libraryID, hex.EncodeToString(predecessorToken), ledger[0])
		delta.ContentLedger = append([]libraryflow.Object(nil), ledger...)
		delta.ForcePaths = []string{payload}
		composed, err := composeLocalBuildCandidate(*loadedPrior, delta)
		if err != nil {
			t.Fatal(err)
		}
		if err := saveLocalChangeCandidate(candidateRoot, composed); err != nil {
			t.Fatal(err)
		}
		loadedComposed, err := loadLocalChangeCandidate(candidateRoot)
		if err != nil {
			t.Fatal(err)
		}
		if !reflect.DeepEqual(loadedComposed.ContentLedger, ledger) || !reflect.DeepEqual(loadedComposed.ForcePaths, []string{payload}) {
			t.Fatalf("production candidate round trip lost hashes/force paths: %+v", loadedComposed)
		}
		if len(loadedComposed.Changes) != 1 || loadedComposed.Changes[0].OldRecordDigest != diffAB.Changes[0].OldRecordDigest || loadedComposed.Changes[0].NewRecordDigest != diffBC.Changes[0].NewRecordDigest {
			t.Fatalf("A->B->C composition was not preserved: %+v", loadedComposed.Changes)
		}

		originalHasher := contentLedgerHashFile
		t.Cleanup(func() { contentLedgerHashFile = originalHasher })
		hashCalls := 0
		contentLedgerHashFile = func(path string, _ func(int64)) (string, error) {
			hashCalls++
			return "", fmt.Errorf("unchanged source bytes were read: %s", path)
		}
		currentObjects, err := listLocalObjects(sourceRoot)
		if err != nil {
			t.Fatal(err)
		}
		reusedLedger, changed, removed, err := buildContentLedger(sourceRoot, currentObjects, nil, loadedBaseline.ContentLedger)
		contentLedgerHashFile = originalHasher
		if err != nil {
			t.Fatal(err)
		}
		if hashCalls != 0 || len(changed) != 0 || len(removed) != 0 || !reflect.DeepEqual(reusedLedger, ledger) {
			t.Fatalf("unchanged v1 reuse calls=%d changed=%v removed=%v ledger=%+v", hashCalls, changed, removed, reusedLedger)
		}

		adapted, err := spikeAdaptBoundedV1(installation, loadedBaseline, loadedComposed, hex.EncodeToString(predecessorToken), "root-fixture-1", currentObjects)
		if err != nil {
			t.Fatal(err)
		}
		if adapted.SeatID != installation.SeatID || adapted.RootProvenance != "root-fixture-1" || !reflect.DeepEqual(adapted.ContentLedger, ledger) || !reflect.DeepEqual(adapted.FileProvenance, currentObjects) || !reflect.DeepEqual(adapted.ForcePaths, []string{payload}) {
			t.Fatalf("bounded adapter lost durable evidence: %+v", adapted)
		}
		if _, err := spikeAdaptBoundedV1(copiedInstallation, loadedBaseline, loadedComposed, hex.EncodeToString(predecessorToken), "", currentObjects); err == nil || !strings.Contains(err.Error(), "root provenance") {
			t.Fatalf("copied installation without provenance was accepted: %v", err)
		}
		if _, err := spikeAdaptBoundedV1(installation, loadedBaseline, loadedComposed, hex.EncodeToString(predecessorToken), "root-fixture-1", currentObjects[:len(currentObjects)-1]); err == nil || !strings.Contains(err.Error(), "file provenance") {
			t.Fatalf("incomplete file provenance was accepted: %v", err)
		}
		legacy := *loadedBaseline
		legacy.ContentLedgerVersion = 0
		legacy.ContentLedger = nil
		if _, err := spikeAdaptBoundedV1(installation, &legacy, loadedComposed, hex.EncodeToString(predecessorToken), "root-fixture-1", currentObjects); err == nil || !strings.Contains(err.Error(), "coverage") {
			t.Fatalf("missing v1 coverage was accepted: %v", err)
		}
		advancedToken := torshare.EncodeGeneration(base, 11)
		if _, err := spikeAdaptBoundedV1(installation, loadedBaseline, loadedComposed, hex.EncodeToString(advancedToken), "root-fixture-1", currentObjects); err == nil || !strings.Contains(err.Error(), "remote advance") {
			t.Fatalf("remote advance was accepted: %v", err)
		}

		pointerA := calibre.PointerFile{
			Library: calibre.PointerFileLibrary{UUID: libraryID},
			Index:   calibre.PointerFileIndex{NumBooks: diffAB.FromCount}, CatalogChecksum: diffAB.FromChecksum,
			SourceFingerprint: strings.Repeat("a", 64),
		}
		pointerC := calibre.PointerFile{
			Library: calibre.PointerFileLibrary{UUID: libraryID},
			Index:   calibre.PointerFileIndex{NumBooks: diffBC.ToCount}, CatalogChecksum: diffBC.ToChecksum,
			SourceFingerprint: loadedComposed.TargetSourceFingerprint,
		}
		bound, err := bindGenerationPublication(remoteLibrarySnapshot{
			Pointer: pointerA, PointerRaw: []byte("non-empty"), GenerationRaw: predecessorToken,
			Generation: 10, SourceFingerprint: strings.Repeat("a", 64), Committed: true,
		}, pointerC, &libraryCandidate{SourceFingerprint: loadedComposed.TargetSourceFingerprint, Change: loadedComposed}, torshare.EncodeGeneration(base, 12), strings.Repeat("a", 64))
		if err != nil {
			t.Fatal(err)
		}
		manifest, err := calibre.DecodeGenerationChangeManifest(bound.ManifestBytes, calibre.GenerationChangeLimits{})
		if err != nil {
			t.Fatal(err)
		}
		if bound.Scope != calibre.GenerationChangeScopeExact || manifest.FromGeneration != hex.EncodeToString(predecessorToken) || len(manifest.Changes) != 1 {
			t.Fatalf("composed v1 evidence did not bind to exact A->C manifest: bound=%+v manifest=%+v", bound, manifest)
		}
		t.Logf("installation %s survived reload and an exact copied-state replay, showing seat identity is reusable but not host proof; adapter retained %d hashes and A->C force path %q", installation.SeatID, len(adapted.ContentLedger), adapted.ForcePaths)
	})

	t.Run("real interrupted publish preserves exact manifest bytes", func(t *testing.T) {
		testSetup(t)
		const libraryID = "550e8400-e29b-41d4-a716-446655440000"
		candidate := makePublishCandidate(t, libraryID, "payload")
		remoteRoot := t.TempDir()
		checksum := generationCandidateChecksum(t)
		fromToken := seedExactChangeRemote(t, remoteRoot, candidate, checksum)
		attachExactEmptyChange(t, candidate, fromToken, checksum)
		withLocalCommandRemote(t, remoteRoot)
		publishCommitStageHook = func(stage string) error {
			if stage == "after-manifest" {
				return errors.New("spike interruption after manifest")
			}
			return nil
		}
		t.Cleanup(func() { publishCommitStageHook = nil })

		err := publishCandidate("alice", libraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: libraryflow.DefaultMaxDeletes})
		if err == nil || !strings.Contains(err.Error(), "spike interruption after manifest") {
			t.Fatalf("interrupted publish error=%v", err)
		}
		var recovery publishRecoveryRecord
		if err := readJSONFile(publishRecoveryPath("alice"), &recovery); err != nil {
			t.Fatal(err)
		}
		if recovery.ContentLedgerVersion != 1 || recovery.Stage != "payload-complete" {
			t.Fatalf("unexpected recovery record=%+v", recovery)
		}
		if err := validateSourceContentLedger(recovery.ContentLedger); err != nil {
			t.Fatalf("recovery content evidence invalid: %v", err)
		}
		manifestPath := filepath.Join(remoteRoot, filepath.FromSlash(recovery.ManifestPath))
		manifestBefore, err := os.ReadFile(manifestPath)
		if err != nil || !bytes.Equal(manifestBefore, recovery.Manifest) {
			t.Fatalf("manifest before recovery=%q err=%v, saved=%q", manifestBefore, err, recovery.Manifest)
		}

		publishCommitStageHook = nil
		recovered, err := recoverPublishBookkeeping("alice", libraryID, &libraryRemote{fsPath: remoteRoot}, candidate.Root, publishOptions{})
		if err != nil || !recovered {
			t.Fatalf("real recovery recovered=%t err=%v", recovered, err)
		}
		manifestAfter, err := os.ReadFile(manifestPath)
		if err != nil || !bytes.Equal(manifestAfter, manifestBefore) {
			t.Fatalf("manifest bytes changed during recovery: before=%q after=%q err=%v", manifestBefore, manifestAfter, err)
		}
		baseline, err := loadBaseline("alice")
		if err != nil || baseline == nil {
			t.Fatalf("recovered baseline=%+v err=%v", baseline, err)
		}
		if baseline.GenerationToken != recovery.GenerationToken || baseline.CatalogChecksum != recovery.CatalogChecksum || !reflect.DeepEqual(baseline.ContentLedger, recovery.ContentLedger) {
			t.Fatalf("recovery did not preserve v1 evidence: baseline=%+v recovery=%+v", baseline, recovery)
		}
		if _, err := os.Stat(publishRecoveryPath("alice")); !os.IsNotExist(err) {
			t.Fatalf("recovery record remains after completion: %v", err)
		}
		t.Logf("real local-backend recovery committed generation %d and retained %d exact manifest bytes plus %d content hashes", recovery.Generation, len(manifestAfter), len(baseline.ContentLedger))
	})

	t.Run("real interrupted publish rejects remote advance", func(t *testing.T) {
		testSetup(t)
		const libraryID = "550e8400-e29b-41d4-a716-446655440000"
		candidate := makePublishCandidate(t, libraryID, "payload")
		remoteRoot := t.TempDir()
		checksum := generationCandidateChecksum(t)
		fromToken := seedExactChangeRemote(t, remoteRoot, candidate, checksum)
		attachExactEmptyChange(t, candidate, fromToken, checksum)
		withLocalCommandRemote(t, remoteRoot)
		publishCommitStageHook = func(stage string) error {
			if stage == "after-manifest" {
				return errors.New("spike interruption before remote advance")
			}
			return nil
		}
		t.Cleanup(func() { publishCommitStageHook = nil })

		err := publishCandidate("alice", libraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: libraryflow.DefaultMaxDeletes})
		if err == nil || !strings.Contains(err.Error(), "spike interruption before remote advance") {
			t.Fatalf("interrupted publish error=%v", err)
		}
		var recovery publishRecoveryRecord
		if err := readJSONFile(publishRecoveryPath("alice"), &recovery); err != nil {
			t.Fatal(err)
		}
		pointerPath := filepath.Join(remoteRoot, filepath.FromSlash(memberPointerPath))
		advancedPointer, err := calibre.ReadPointerFile(pointerPath)
		if err != nil {
			t.Fatal(err)
		}
		advancedPointer, err = calibre.BindPointerCommit(advancedPointer, advancedPointer.SourceFingerprint, 3)
		if err != nil {
			t.Fatal(err)
		}
		if err := calibre.WritePointerDocument(pointerPath, advancedPointer); err != nil {
			t.Fatal(err)
		}
		base, _, err := torshare.DecodeGeneration(fromToken)
		if err != nil {
			t.Fatal(err)
		}
		advancedToken := torshare.EncodeGeneration(base, 3)
		if err := os.WriteFile(filepath.Join(remoteRoot, libraryflow.GenerationPath), advancedToken, 0o644); err != nil {
			t.Fatal(err)
		}

		publishCommitStageHook = nil
		recovered, err := recoverPublishBookkeeping("alice", libraryID, &libraryRemote{fsPath: remoteRoot}, candidate.Root, publishOptions{})
		if err == nil || recovered || !strings.Contains(err.Error(), "remote library changed") {
			t.Fatalf("remote advance recovery result recovered=%t err=%v", recovered, err)
		}
		currentToken, readErr := os.ReadFile(filepath.Join(remoteRoot, libraryflow.GenerationPath))
		if readErr != nil || !bytes.Equal(currentToken, advancedToken) {
			t.Fatalf("rejected recovery altered advanced token: got=%x err=%v want=%x", currentToken, readErr, advancedToken)
		}
		if _, statErr := os.Stat(publishRecoveryPath("alice")); statErr != nil {
			t.Fatalf("rejected recovery discarded retry evidence: %v", statErr)
		}
		t.Logf("real recovery rejected remote token advance from %x to %x and left both remote state and recovery evidence intact", fromToken, advancedToken)
	})
}

func spikeImportProvenCoverage(baseline *libraryBaseline, observedPredecessor string) ([]libraryflow.Object, error) {
	if baseline == nil {
		return nil, errors.New("missing saved coverage")
	}
	if baseline.ContentLedgerVersion == 0 {
		return nil, errors.New("v0 timestamp coverage is ambiguous after a converged refresh")
	}
	if baseline.ContentLedgerVersion != 1 {
		return nil, fmt.Errorf("unsupported coverage version %d", baseline.ContentLedgerVersion)
	}
	if baseline.GenerationToken == "" || baseline.GenerationToken != observedPredecessor {
		return nil, errors.New("saved coverage does not agree with the actual full predecessor token")
	}
	if baseline.LocalSourceFingerprint == "" || baseline.LocalSourceFingerprint != baseline.RemoteSourceFingerprint {
		return nil, errors.New("saved coverage was not converged")
	}
	if err := validateSourceContentLedger(baseline.ContentLedger); err != nil {
		return nil, err
	}
	return append([]libraryflow.Object(nil), baseline.ContentLedger...), nil
}

type spikeBoundedV1State struct {
	SeatID          string
	RootProvenance  string
	Predecessor     string
	ContentLedger   []libraryflow.Object
	FileProvenance  []libraryflow.Object
	ForcePaths      []string
	CandidateChange []calibre.GenerationChange
}

func spikeAdaptBoundedV1(
	installation libraryInstallation,
	baseline *libraryBaseline,
	candidate *localChangeCandidate,
	observedPredecessor string,
	rootProvenance string,
	currentInventory []libraryflow.Object,
) (spikeBoundedV1State, error) {
	if installation.Version != machineStateVersion || strings.TrimSpace(installation.SeatID) == "" {
		return spikeBoundedV1State{}, errors.New("missing durable seat identity")
	}
	if strings.TrimSpace(rootProvenance) == "" {
		return spikeBoundedV1State{}, errors.New("missing prospective root provenance")
	}
	if baseline != nil && baseline.GenerationToken != "" && baseline.GenerationToken != observedPredecessor {
		return spikeBoundedV1State{}, errors.New("remote advance invalidates saved coverage")
	}
	ledger, err := spikeImportProvenCoverage(baseline, observedPredecessor)
	if err != nil {
		return spikeBoundedV1State{}, fmt.Errorf("missing migration coverage: %w", err)
	}
	if candidate == nil {
		return spikeBoundedV1State{}, errors.New("missing unpublished candidate")
	}
	if err := candidate.validate(); err != nil {
		return spikeBoundedV1State{}, err
	}
	if baseline.LibraryID != candidate.LibraryUUID {
		return spikeBoundedV1State{}, errors.New("candidate belongs to another library")
	}
	if candidate.FromGeneration != observedPredecessor {
		return spikeBoundedV1State{}, errors.New("remote advance invalidates the unpublished candidate")
	}
	current, err := libraryflow.FilterInventory(currentInventory, nil, false)
	if err != nil || len(current) != len(ledger) {
		return spikeBoundedV1State{}, errors.New("current file provenance does not cover the saved content ledger")
	}
	for index := range current {
		if current[index].Path != ledger[index].Path || !canReuseContentDigest(current[index], ledger[index]) {
			return spikeBoundedV1State{}, fmt.Errorf("current file provenance does not match saved coverage for %q", ledger[index].Path)
		}
	}
	return spikeBoundedV1State{
		SeatID: installation.SeatID, RootProvenance: rootProvenance, Predecessor: observedPredecessor,
		ContentLedger:   append([]libraryflow.Object(nil), ledger...),
		FileProvenance:  append([]libraryflow.Object(nil), current...),
		ForcePaths:      append([]string(nil), candidate.ForcePaths...),
		CandidateChange: append([]calibre.GenerationChange(nil), candidate.Changes...),
	}, nil
}
