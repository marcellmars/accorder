//go:build !tailscale

package cmd

import (
	"bytes"
	"encoding/hex"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"accorder/pkg/calibre"
	"accorder/pkg/libraryflow"
	"accorder/pkg/torshare"
)

func TestGenerationChangePublishWritesManifestPointerSentinel(t *testing.T) {
	testSetup(t)
	candidate := makePublishCandidate(t, "550e8400-e29b-41d4-a716-446655440000", "payload")
	remoteRoot := t.TempDir()
	checksum := generationCandidateChecksum(t)
	fromToken := seedExactChangeRemote(t, remoteRoot, candidate, checksum)
	attachExactEmptyChange(t, candidate, fromToken, checksum)
	localIndex, err := os.ReadFile(filepath.Join(candidate.Root, filepath.FromSlash(candidate.Change.IndexArtifact.Path)))
	if err != nil {
		t.Fatal(err)
	}
	// The production failure had a stale and fresh zstd index with exactly the
	// same size. Seed that collision so the SizeOnly mirror skips it and the
	// correctness lane must replace it before committing the pointer.
	staleIndex := bytes.Repeat([]byte{'x'}, len(localIndex))
	writeTestFile(t, remoteRoot, candidate.Change.IndexArtifact.Path, string(staleIndex))
	withLocalCommandRemote(t, remoteRoot)

	if err := publishCandidate("alice", candidate.Change.LibraryUUID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: libraryflow.DefaultMaxDeletes}); err != nil {
		t.Fatal(err)
	}
	snapshot := (&libraryRemote{fsPath: remoteRoot}).commitState()
	if snapshot.Err != nil || !snapshot.Committed || snapshot.Pointer.CatalogChecksum != checksum {
		t.Fatalf("published snapshot=%+v", snapshot)
	}
	remoteIndex, err := os.ReadFile(filepath.Join(remoteRoot, filepath.FromSlash(candidate.Change.IndexArtifact.Path)))
	if err != nil || !bytes.Equal(remoteIndex, localIndex) {
		t.Fatalf("published same-size index does not match built index: bytes=%d err=%v", len(remoteIndex), err)
	}
	manifestPath := filepath.Join(remoteRoot, filepath.FromSlash(generationChangeManifestPath(hex.EncodeToString(snapshot.GenerationRaw))))
	data, err := os.ReadFile(manifestPath)
	if err != nil {
		t.Fatal(err)
	}
	manifest, err := calibre.DecodeGenerationChangeManifest(data, calibre.GenerationChangeLimits{})
	if err != nil {
		t.Fatal(err)
	}
	if manifest.Scope != calibre.GenerationChangeScopeExact || manifest.FromGeneration != hex.EncodeToString(fromToken) || len(manifest.Changes) != 0 {
		t.Fatalf("manifest=%+v", manifest)
	}
	baseline, err := loadBaseline("alice")
	if err != nil || baseline == nil || baseline.GenerationToken != manifest.ToGeneration || baseline.CatalogChecksum != checksum || baseline.ContentLedgerVersion != 1 {
		t.Fatalf("baseline=%+v err=%v", baseline, err)
	}
}

func TestGenerationChangePublishNoOpsWhenExactSnapshotIsAlreadyCurrent(t *testing.T) {
	testSetup(t)
	candidate := makePublishCandidate(t, "550e8400-e29b-41d4-a716-446655440000", "payload")
	remoteRoot := t.TempDir()
	checksum := generationCandidateChecksum(t)
	fromToken := seedExactChangeRemote(t, remoteRoot, candidate, checksum)
	attachExactEmptyChange(t, candidate, fromToken, checksum)
	remotePointerPath := filepath.Join(remoteRoot, filepath.FromSlash(memberPointerPath))
	pointer, err := calibre.ReadPointerFile(filepath.Join(candidate.Root, filepath.FromSlash(memberPointerPath)))
	if err != nil {
		t.Fatal(err)
	}
	pointer, err = calibre.BindPointerCommit(pointer, candidate.SourceFingerprint, 1)
	if err != nil {
		t.Fatal(err)
	}
	pointer.CatalogChecksum = checksum
	if err := calibre.WritePointerDocument(remotePointerPath, pointer); err != nil {
		t.Fatal(err)
	}
	if err := saveBaseline("alice", libraryBaseline{
		LibraryID: pointer.Library.UUID, RemoteSourceFingerprint: candidate.SourceFingerprint,
		LocalSourceFingerprint: candidate.SourceFingerprint, Generation: 1,
		GenerationToken: hex.EncodeToString(fromToken), CatalogChecksum: checksum,
		ContentLedgerVersion: 1, ContentLedger: candidate.Change.ContentLedger,
	}); err != nil {
		t.Fatal(err)
	}
	for _, path := range []string{
		candidate.Change.IndexArtifact.Path,
		strings.TrimSuffix(candidate.Change.IndexArtifact.Path, ".zst") + ".jsonl.zst",
	} {
		data, err := os.ReadFile(filepath.Join(candidate.Root, filepath.FromSlash(path)))
		if err != nil {
			t.Fatal(err)
		}
		writeTestFile(t, remoteRoot, path, string(data))
	}
	withLocalCommandRemote(t, remoteRoot)

	if err := publishCandidate("alice", pointer.Library.UUID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: libraryflow.DefaultMaxDeletes}); err != nil {
		t.Fatal(err)
	}
	remoteToken, err := os.ReadFile(filepath.Join(remoteRoot, libraryflow.GenerationPath))
	if err != nil || !bytes.Equal(remoteToken, fromToken) {
		t.Fatalf("no-op token=%x err=%v, want %x", remoteToken, err, fromToken)
	}
	localToken, err := os.ReadFile(filepath.Join(candidate.Root, libraryflow.GenerationPath))
	if err != nil || !bytes.Equal(localToken, fromToken) {
		t.Fatalf("no-op local token=%x err=%v, want %x", localToken, err, fromToken)
	}
	localPointer, err := calibre.ReadPointerFile(filepath.Join(candidate.Root, filepath.FromSlash(memberPointerPath)))
	if err != nil || localPointer.Version != 2 || localPointer.SourceFingerprint != candidate.SourceFingerprint || localPointer.Generation != 1 {
		t.Fatalf("no-op local pointer=%+v err=%v", localPointer, err)
	}
	manifestPath := filepath.Join(remoteRoot, filepath.FromSlash(generationChangeManifestPath(hex.EncodeToString(fromToken))))
	if _, err := os.Stat(manifestPath); !os.IsNotExist(err) {
		t.Fatalf("no-op unexpectedly wrote target manifest: %v", err)
	}
}

func TestGenerationChangePublishRepairsSameSizeIndexInsteadOfNoOp(t *testing.T) {
	testSetup(t)
	candidate := makePublishCandidate(t, "550e8400-e29b-41d4-a716-446655440000", "payload")
	remoteRoot := t.TempDir()
	checksum := generationCandidateChecksum(t)
	fromToken := seedExactChangeRemote(t, remoteRoot, candidate, checksum)
	attachExactEmptyChange(t, candidate, fromToken, checksum)

	remotePointerPath := filepath.Join(remoteRoot, filepath.FromSlash(memberPointerPath))
	pointer, err := calibre.ReadPointerFile(filepath.Join(candidate.Root, filepath.FromSlash(memberPointerPath)))
	if err != nil {
		t.Fatal(err)
	}
	pointer, err = calibre.BindPointerCommit(pointer, candidate.SourceFingerprint, 1)
	if err != nil {
		t.Fatal(err)
	}
	pointer.CatalogChecksum = checksum
	if err := calibre.WritePointerDocument(remotePointerPath, pointer); err != nil {
		t.Fatal(err)
	}
	if err := saveBaseline("alice", libraryBaseline{
		LibraryID: pointer.Library.UUID, RemoteSourceFingerprint: candidate.SourceFingerprint,
		LocalSourceFingerprint: candidate.SourceFingerprint, Generation: 1,
		GenerationToken: hex.EncodeToString(fromToken), CatalogChecksum: checksum,
		ContentLedgerVersion: 1, ContentLedger: candidate.Change.ContentLedger,
	}); err != nil {
		t.Fatal(err)
	}
	localIndex, err := os.ReadFile(filepath.Join(candidate.Root, filepath.FromSlash(candidate.Change.IndexArtifact.Path)))
	if err != nil {
		t.Fatal(err)
	}
	writeTestFile(t, remoteRoot, candidate.Change.IndexArtifact.Path, string(bytes.Repeat([]byte{'z'}, len(localIndex))))
	jsonlPath := strings.TrimSuffix(candidate.Change.IndexArtifact.Path, ".zst") + ".jsonl.zst"
	jsonl, err := os.ReadFile(filepath.Join(candidate.Root, filepath.FromSlash(jsonlPath)))
	if err != nil {
		t.Fatal(err)
	}
	writeTestFile(t, remoteRoot, jsonlPath, string(jsonl))
	withLocalCommandRemote(t, remoteRoot)

	if err := publishCandidate("alice", pointer.Library.UUID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: libraryflow.DefaultMaxDeletes}); err != nil {
		t.Fatal(err)
	}
	snapshot := (&libraryRemote{fsPath: remoteRoot}).commitState()
	if snapshot.Err != nil || !snapshot.Committed || snapshot.Generation != 2 {
		t.Fatalf("repaired snapshot=%+v", snapshot)
	}
	remoteIndex, err := os.ReadFile(filepath.Join(remoteRoot, filepath.FromSlash(candidate.Change.IndexArtifact.Path)))
	if err != nil || !bytes.Equal(remoteIndex, localIndex) {
		t.Fatalf("repaired same-size index does not match built index: bytes=%d err=%v", len(remoteIndex), err)
	}
}

func TestGenerationChangePublishMatchingFingerprintWithoutBaselineDoesNotNoOp(t *testing.T) {
	testSetup(t)
	candidate := makePublishCandidate(t, "550e8400-e29b-41d4-a716-446655440000", "payload")
	remoteRoot := t.TempDir()
	checksum := generationCandidateChecksum(t)
	fromToken := seedExactChangeRemote(t, remoteRoot, candidate, checksum)
	attachExactEmptyChange(t, candidate, fromToken, checksum)
	remotePointerPath := filepath.Join(remoteRoot, filepath.FromSlash(memberPointerPath))
	pointer, err := calibre.ReadPointerFile(remotePointerPath)
	if err != nil {
		t.Fatal(err)
	}
	pointer.SourceFingerprint = candidate.SourceFingerprint
	if err := calibre.WritePointerDocument(remotePointerPath, pointer); err != nil {
		t.Fatal(err)
	}
	if err := os.Remove(baselineStatePath("alice")); err != nil {
		t.Fatal(err)
	}
	withLocalCommandRemote(t, remoteRoot)

	err = publishCandidate("alice", pointer.Library.UUID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: libraryflow.DefaultMaxDeletes})
	if err == nil || !strings.Contains(err.Error(), "No library files were uploaded.") || !strings.Contains(err.Error(), "--allow-full-reupload") {
		t.Fatalf("unapproved complete overwrite error=%v", err)
	}
	before, err := os.ReadFile(filepath.Join(remoteRoot, libraryflow.GenerationPath))
	if err != nil || !bytes.Equal(before, fromToken) {
		t.Fatalf("refused overwrite changed generation=%x err=%v", before, err)
	}
	if err := publishCandidate("alice", pointer.Library.UUID, GroupS3Credentials{}, candidate, publishOptions{
		MaxDeletes: libraryflow.DefaultMaxDeletes, AllowCompleteOverwrite: true,
	}); err != nil {
		t.Fatal(err)
	}
	snapshot := (&libraryRemote{fsPath: remoteRoot}).commitState()
	if snapshot.Err != nil || !snapshot.Committed || snapshot.Generation != 2 {
		t.Fatalf("published snapshot=%+v", snapshot)
	}
	manifestRaw, err := os.ReadFile(filepath.Join(remoteRoot, filepath.FromSlash(generationChangeManifestPath(hex.EncodeToString(snapshot.GenerationRaw)))))
	if err != nil {
		t.Fatal(err)
	}
	manifest, err := calibre.DecodeGenerationChangeManifest(manifestRaw, calibre.GenerationChangeLimits{})
	if err != nil {
		t.Fatal(err)
	}
	if manifest.Scope != calibre.GenerationChangeScopeCoarse {
		t.Fatalf("manifest scope=%s, want coarse baseline re-establishment", manifest.Scope)
	}
}

func TestGenerationChangePublishLocalWinsUsesCoarseCompleteOverwrite(t *testing.T) {
	testSetup(t)
	candidate := makePublishCandidate(t, "550e8400-e29b-41d4-a716-446655440000", "correct")
	remoteRoot := t.TempDir()
	checksum := generationCandidateChecksum(t)
	fromToken := seedExactChangeRemote(t, remoteRoot, candidate, checksum)
	attachExactEmptyChange(t, candidate, fromToken, checksum)
	remotePointerPath := filepath.Join(remoteRoot, filepath.FromSlash(memberPointerPath))
	pointer, err := calibre.ReadPointerFile(remotePointerPath)
	if err != nil {
		t.Fatal(err)
	}
	pointer.SourceFingerprint = strings.Repeat("f", 64)
	if err := calibre.WritePointerDocument(remotePointerPath, pointer); err != nil {
		t.Fatal(err)
	}
	withLocalCommandRemote(t, remoteRoot)

	if err := publishCandidate("alice", pointer.Library.UUID, GroupS3Credentials{}, candidate, publishOptions{
		LocalWins: true, MaxDeletes: libraryflow.DefaultMaxDeletes, AllowCompleteOverwrite: true,
	}); err != nil {
		t.Fatal(err)
	}
	snapshot := (&libraryRemote{fsPath: remoteRoot}).commitState()
	if snapshot.Err != nil || !snapshot.Committed {
		t.Fatalf("published snapshot=%+v", snapshot)
	}
	manifestRaw, err := os.ReadFile(filepath.Join(remoteRoot, filepath.FromSlash(generationChangeManifestPath(hex.EncodeToString(snapshot.GenerationRaw)))))
	if err != nil {
		t.Fatal(err)
	}
	manifest, err := calibre.DecodeGenerationChangeManifest(manifestRaw, calibre.GenerationChangeLimits{})
	if err != nil {
		t.Fatal(err)
	}
	if manifest.Scope != calibre.GenerationChangeScopeCoarse {
		t.Fatalf("local-wins manifest scope=%s, want coarse", manifest.Scope)
	}
	remotePayload, err := os.ReadFile(filepath.Join(remoteRoot, "Author", "Book (1)", "book.epub"))
	if err != nil || string(remotePayload) != "correct" {
		t.Fatalf("remote same-size payload=%q err=%v", remotePayload, err)
	}
}

func TestGenerationChangePublishRejectsCandidateChecksumNotBoundToIndex(t *testing.T) {
	testSetup(t)
	candidate := makePublishCandidate(t, "550e8400-e29b-41d4-a716-446655440000", "payload")
	remoteRoot := t.TempDir()
	checksum := generationCandidateChecksum(t)
	fromToken := seedExactChangeRemote(t, remoteRoot, candidate, checksum)
	attachExactEmptyChange(t, candidate, fromToken, checksum)
	tamperedChecksum := strings.Repeat("0", 64)
	pointerPath := filepath.Join(candidate.Root, filepath.FromSlash(memberPointerPath))
	pointer, err := calibre.ReadPointerFile(pointerPath)
	if err != nil {
		t.Fatal(err)
	}
	pointer.CatalogChecksum = tamperedChecksum
	if err := calibre.WritePointerDocument(pointerPath, pointer); err != nil {
		t.Fatal(err)
	}
	candidate.Change.ToCatalogChecksum = tamperedChecksum
	if err := saveLocalChangeCandidate(candidate.Root, *candidate.Change); err != nil {
		t.Fatal(err)
	}
	withLocalCommandRemote(t, remoteRoot)

	err = publishCandidate("alice", candidate.Change.LibraryUUID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: libraryflow.DefaultMaxDeletes})
	if err == nil || !strings.Contains(err.Error(), "generated library index changed after the build completed") {
		t.Fatalf("publish error=%v", err)
	}
	remoteToken, readErr := os.ReadFile(filepath.Join(remoteRoot, libraryflow.GenerationPath))
	if readErr != nil || !bytes.Equal(remoteToken, fromToken) {
		t.Fatalf("sentinel after checksum rejection=%x err=%v, want %x", remoteToken, readErr, fromToken)
	}
	remotePayload, readErr := os.ReadFile(filepath.Join(remoteRoot, "Author", "Book (1)", "book.epub"))
	if readErr != nil || string(remotePayload) != "payload" {
		t.Fatalf("payload after checksum rejection=%q err=%v", remotePayload, readErr)
	}
}

func TestGenerationChangePublishRetriesEveryPrecommitTransferBoundary(t *testing.T) {
	for _, test := range []struct {
		stage    string
		complete bool
	}{
		{stage: "before-mirror"},
		{stage: "after-mirror"},
		{stage: "before-force-copy"},
		{stage: "after-force-copy"},
		{stage: "before-complete-overwrite", complete: true},
		{stage: "after-complete-overwrite", complete: true},
		{stage: "before-manifest"},
		{stage: "after-manifest"},
		{stage: "before-pointer"},
	} {
		t.Run(test.stage, func(t *testing.T) {
			testSetup(t)
			candidate := makePublishCandidate(t, "550e8400-e29b-41d4-a716-446655440000", "payload")
			remoteRoot := t.TempDir()
			checksum := generationCandidateChecksum(t)
			fromToken := seedExactChangeRemote(t, remoteRoot, candidate, checksum)
			attachExactEmptyChange(t, candidate, fromToken, checksum)
			if test.complete {
				candidate.Change.makeCoarse("fault-boundary-test", true)
				candidate.Change.ForcePaths = nil
			} else {
				candidate.Change.ForcePaths = []string{"Author/Book (1)/book.epub"}
			}
			if err := saveLocalChangeCandidate(candidate.Root, *candidate.Change); err != nil {
				t.Fatal(err)
			}
			withLocalCommandRemote(t, remoteRoot)
			publishCommitStageHook = func(stage string) error {
				if stage == test.stage {
					return errors.New("injected " + test.stage)
				}
				return nil
			}
			t.Cleanup(func() { publishCommitStageHook = nil })

			options := publishOptions{MaxDeletes: libraryflow.DefaultMaxDeletes, AllowCompleteOverwrite: test.complete}
			err := publishCandidate("alice", candidate.Change.LibraryUUID, GroupS3Credentials{}, candidate, options)
			if err == nil || !strings.Contains(err.Error(), "injected "+test.stage) {
				t.Fatalf("first publish error=%v", err)
			}
			publishCommitStageHook = nil
			if err := publishCandidate("alice", candidate.Change.LibraryUUID, GroupS3Credentials{}, candidate, options); err != nil {
				t.Fatal(err)
			}
			if snapshot := (&libraryRemote{fsPath: remoteRoot}).commitState(); snapshot.Err != nil || !snapshot.Committed || snapshot.Generation != 2 {
				t.Fatalf("retried snapshot=%+v", snapshot)
			}
		})
	}
}

func TestGenerationChangePublishRecoversManifestCreatedBeforeStageMarker(t *testing.T) {
	testSetup(t)
	candidate := makePublishCandidate(t, "550e8400-e29b-41d4-a716-446655440000", "payload")
	remoteRoot := t.TempDir()
	checksum := generationCandidateChecksum(t)
	fromToken := seedExactChangeRemote(t, remoteRoot, candidate, checksum)
	attachExactEmptyChange(t, candidate, fromToken, checksum)
	originalFingerprint := candidate.SourceFingerprint
	withLocalCommandRemote(t, remoteRoot)
	publishCommitStageHook = func(stage string) error {
		if stage == "after-manifest" {
			return errors.New("injected after immutable create")
		}
		return nil
	}
	t.Cleanup(func() { publishCommitStageHook = nil })

	err := publishCandidate("alice", candidate.Change.LibraryUUID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: libraryflow.DefaultMaxDeletes})
	if err == nil || !strings.Contains(err.Error(), "injected after immutable create") {
		t.Fatalf("first publish error=%v", err)
	}
	var recovery publishRecoveryRecord
	if err := readJSONFile(publishRecoveryPath("alice"), &recovery); err != nil {
		t.Fatal(err)
	}
	if recovery.Stage != "payload-complete" {
		t.Fatalf("recovery stage=%q, want payload-complete", recovery.Stage)
	}
	manifestBefore, err := os.ReadFile(filepath.Join(remoteRoot, filepath.FromSlash(recovery.ManifestPath)))
	if err != nil || !bytes.Equal(manifestBefore, recovery.Manifest) {
		t.Fatalf("immutable manifest before recovery=%q err=%v", manifestBefore, err)
	}

	// A fresh command may observe new local source after the crash. Recovery
	// must finish the durable old publication instead of discarding its record
	// and reusing the generation now occupied by the immutable manifest.
	if err := os.WriteFile(filepath.Join(candidate.Root, "metadata.db"), []byte("new local source"), 0o644); err != nil {
		t.Fatal(err)
	}
	fresh, err := captureExistingCandidate(candidate.Root, candidate.Excludes)
	if err != nil {
		t.Fatal(err)
	}
	if fresh.SourceFingerprint == originalFingerprint {
		t.Fatal("test mutation did not change source fingerprint")
	}
	publishCommitStageHook = nil
	if err := publishCandidate("alice", candidate.Change.LibraryUUID, GroupS3Credentials{}, fresh, publishOptions{MaxDeletes: libraryflow.DefaultMaxDeletes}); err != nil {
		t.Fatal(err)
	}
	snapshot := (&libraryRemote{fsPath: remoteRoot}).commitState()
	if snapshot.Err != nil || !snapshot.Committed || snapshot.Generation != 2 || snapshot.SourceFingerprint != originalFingerprint {
		t.Fatalf("recovered snapshot=%+v, want original generation-2 publication", snapshot)
	}
	manifestAfter, err := os.ReadFile(filepath.Join(remoteRoot, filepath.FromSlash(recovery.ManifestPath)))
	if err != nil || !bytes.Equal(manifestAfter, manifestBefore) {
		t.Fatalf("immutable manifest changed during recovery=%q err=%v", manifestAfter, err)
	}
}

func TestGenerationChangeRecoveryRevalidatesWriterBeforeManifestReplay(t *testing.T) {
	testSetup(t)
	candidate := makePublishCandidate(t, "550e8400-e29b-41d4-a716-446655440000", "payload")
	remoteRoot := t.TempDir()
	checksum := generationCandidateChecksum(t)
	fromToken := seedExactChangeRemote(t, remoteRoot, candidate, checksum)
	attachExactEmptyChange(t, candidate, fromToken, checksum)
	withLocalCommandRemote(t, remoteRoot)
	publishCommitStageHook = func(stage string) error {
		if stage == "before-manifest" {
			return errors.New("injected before immutable create")
		}
		return nil
	}
	t.Cleanup(func() { publishCommitStageHook = nil })

	err := publishCandidate("alice", candidate.Change.LibraryUUID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: libraryflow.DefaultMaxDeletes})
	if err == nil || !strings.Contains(err.Error(), "injected before immutable create") {
		t.Fatalf("first publish error=%v", err)
	}
	var recovery publishRecoveryRecord
	if err := readJSONFile(publishRecoveryPath("alice"), &recovery); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(filepath.Join(remoteRoot, filepath.FromSlash(recovery.ManifestPath))); !os.IsNotExist(err) {
		t.Fatalf("manifest exists before recovery replay: %v", err)
	}

	publishCommitStageHook = func(stage string) error {
		if stage != "recovery-before-manifest" {
			return nil
		}
		marker := libraryflow.ClaimWriter("other-seat", "Other seat", time.Now(), nil)
		raw, err := marker.Marshal()
		if err != nil {
			return err
		}
		return os.WriteFile(filepath.Join(remoteRoot, libraryflow.WriterPath), raw, 0o600)
	}
	err = publishCandidate("alice", candidate.Change.LibraryUUID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: libraryflow.DefaultMaxDeletes})
	if err == nil || !strings.Contains(err.Error(), "publishing access changed") {
		t.Fatalf("recovery error=%v, want writer revalidation failure", err)
	}
	if _, err := os.Stat(filepath.Join(remoteRoot, filepath.FromSlash(recovery.ManifestPath))); !os.IsNotExist(err) {
		t.Fatalf("stale writer created immutable manifest: %v", err)
	}
	remoteToken, err := os.ReadFile(filepath.Join(remoteRoot, libraryflow.GenerationPath))
	if err != nil || !bytes.Equal(remoteToken, fromToken) {
		t.Fatalf("sentinel after writer race=%x err=%v, want predecessor %x", remoteToken, err, fromToken)
	}
}

func TestCaptureRejectsStaleSameSizeContentLedger(t *testing.T) {
	testSetup(t)
	candidate := makePublishCandidate(t, "550e8400-e29b-41d4-a716-446655440000", "payload")
	checksum := generationCandidateChecksum(t)
	fromToken := generationChangeMemberToken(1)
	attachExactEmptyChange(t, candidate, fromToken, checksum)
	originalFingerprint := candidate.SourceFingerprint

	payloadPath := filepath.Join(candidate.Root, "Author", "Book (1)", "book.epub")
	if err := os.WriteFile(payloadPath, []byte("changed"), 0o644); err != nil {
		t.Fatal(err)
	}
	fresh, err := captureExistingCandidate(candidate.Root, candidate.Excludes)
	if err != nil {
		t.Fatal(err)
	}
	if fresh.SourceFingerprint != originalFingerprint {
		t.Fatalf("same-size rewrite changed portable source fingerprint: %s != %s", fresh.SourceFingerprint, originalFingerprint)
	}
	if fresh.Change != nil {
		t.Fatal("stale generation change candidate remained attached after payload bytes changed")
	}
}

func TestGenerationChangePublishRecoversPointerAheadOfSentinel(t *testing.T) {
	testSetup(t)
	candidate := makePublishCandidate(t, "550e8400-e29b-41d4-a716-446655440000", "payload")
	remoteRoot := t.TempDir()
	checksum := generationCandidateChecksum(t)
	fromToken := seedExactChangeRemote(t, remoteRoot, candidate, checksum)
	attachExactEmptyChange(t, candidate, fromToken, checksum)
	withLocalCommandRemote(t, remoteRoot)
	publishCommitStageHook = func(stage string) error {
		if stage == "after-pointer" {
			return errors.New("injected pointer boundary")
		}
		return nil
	}
	t.Cleanup(func() { publishCommitStageHook = nil })

	err := publishCandidate("alice", candidate.Change.LibraryUUID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: libraryflow.DefaultMaxDeletes})
	if err == nil || !strings.Contains(err.Error(), "injected pointer boundary") {
		t.Fatalf("first publish error=%v", err)
	}
	broken := (&libraryRemote{fsPath: remoteRoot}).commitState()
	if broken.Err == nil || broken.Committed {
		t.Fatalf("pointer-ahead remote unexpectedly committed: %+v", broken)
	}
	if err := os.WriteFile(filepath.Join(candidate.Root, "metadata.db"), []byte("next local edit"), 0o644); err != nil {
		t.Fatal(err)
	}
	publishCommitStageHook = nil
	if err := publishCandidate("alice", candidate.Change.LibraryUUID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: libraryflow.DefaultMaxDeletes}); err != nil {
		t.Fatal(err)
	}
	recovered := (&libraryRemote{fsPath: remoteRoot}).commitState()
	if recovered.Err != nil || !recovered.Committed || recovered.Generation != 2 {
		t.Fatalf("recovered snapshot=%+v", recovered)
	}
	if _, err := os.Stat(publishRecoveryPath("alice")); !os.IsNotExist(err) {
		t.Fatalf("recovery record remains: %v", err)
	}
}

func TestGenerationChangePublishRecoversSentinelAheadOfBookkeeping(t *testing.T) {
	testSetup(t)
	candidate := makePublishCandidate(t, "550e8400-e29b-41d4-a716-446655440000", "payload")
	remoteRoot := t.TempDir()
	checksum := generationCandidateChecksum(t)
	fromToken := seedExactChangeRemote(t, remoteRoot, candidate, checksum)
	attachExactEmptyChange(t, candidate, fromToken, checksum)
	withLocalCommandRemote(t, remoteRoot)
	publishCommitStageHook = func(stage string) error {
		if stage == "after-sentinel" {
			return errors.New("injected sentinel bookkeeping boundary")
		}
		return nil
	}
	t.Cleanup(func() { publishCommitStageHook = nil })

	err := publishCandidate("alice", candidate.Change.LibraryUUID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: libraryflow.DefaultMaxDeletes})
	if err == nil || !strings.Contains(err.Error(), "injected sentinel bookkeeping boundary") {
		t.Fatalf("first publish error=%v", err)
	}
	committed := (&libraryRemote{fsPath: remoteRoot}).commitState()
	if committed.Err != nil || !committed.Committed || committed.Generation != 2 {
		t.Fatalf("remote was not committed before bookkeeping recovery: %+v", committed)
	}
	publishCommitStageHook = nil
	if err := publishCandidate("alice", candidate.Change.LibraryUUID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: libraryflow.DefaultMaxDeletes}); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(publishRecoveryPath("alice")); !os.IsNotExist(err) {
		t.Fatalf("recovery record remains: %v", err)
	}
}

func TestGenerationChangePublishRecoversAfterBaselineWrite(t *testing.T) {
	testSetup(t)
	candidate := makePublishCandidate(t, "550e8400-e29b-41d4-a716-446655440000", "payload")
	remoteRoot := t.TempDir()
	checksum := generationCandidateChecksum(t)
	fromToken := seedExactChangeRemote(t, remoteRoot, candidate, checksum)
	attachExactEmptyChange(t, candidate, fromToken, checksum)
	withLocalCommandRemote(t, remoteRoot)
	publishCommitStageHook = func(stage string) error {
		if stage == "after-baseline" {
			return errors.New("injected baseline bookkeeping boundary")
		}
		return nil
	}
	t.Cleanup(func() { publishCommitStageHook = nil })

	err := publishCandidate("alice", candidate.Change.LibraryUUID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: libraryflow.DefaultMaxDeletes})
	if err == nil || !strings.Contains(err.Error(), "injected baseline bookkeeping boundary") {
		t.Fatalf("first publish error=%v", err)
	}
	publishCommitStageHook = nil
	if err := publishCandidate("alice", candidate.Change.LibraryUUID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: libraryflow.DefaultMaxDeletes}); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(publishRecoveryPath("alice")); !os.IsNotExist(err) {
		t.Fatalf("recovery record remains: %v", err)
	}
}

func TestGenerationChangePublishRecoversLegacyPointerAheadOfSentinel(t *testing.T) {
	testSetup(t)
	candidate := makePublishCandidate(t, "550e8400-e29b-41d4-a716-446655440000", "payload")
	pointerPath := filepath.Join(candidate.Root, filepath.FromSlash(memberPointerPath))
	pointer, err := calibre.ReadPointerFile(pointerPath)
	if err != nil {
		t.Fatal(err)
	}
	pointer.CatalogChecksum = strings.Repeat("a", 64)
	if err := calibre.WritePointerDocument(pointerPath, pointer); err != nil {
		t.Fatal(err)
	}
	remoteRoot := t.TempDir()
	withLocalCommandRemote(t, remoteRoot)
	publishCommitStageHook = func(stage string) error {
		if stage == "after-pointer" {
			return errors.New("injected legacy pointer boundary")
		}
		return nil
	}
	t.Cleanup(func() { publishCommitStageHook = nil })

	err = publishCandidate("alice", "550e8400-e29b-41d4-a716-446655440000", GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: libraryflow.DefaultMaxDeletes})
	if err == nil || !strings.Contains(err.Error(), "injected legacy pointer boundary") {
		t.Fatalf("first publish error=%v", err)
	}
	publishCommitStageHook = nil
	if err := publishCandidate("alice", "550e8400-e29b-41d4-a716-446655440000", GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: libraryflow.DefaultMaxDeletes}); err != nil {
		t.Fatal(err)
	}
	if snapshot := (&libraryRemote{fsPath: remoteRoot}).commitState(); snapshot.Err != nil || !snapshot.Committed || snapshot.Pointer.CatalogChecksum != pointer.CatalogChecksum {
		t.Fatalf("recovered snapshot=%+v", snapshot)
	}
	baseline, err := loadBaseline("alice")
	if err != nil || baseline == nil || baseline.ContentLedgerVersion != 0 {
		t.Fatalf("compatibility baseline=%+v err=%v", baseline, err)
	}
}

func TestGenerationChangePublishReplansManifestAgainstLegacyPredecessor(t *testing.T) {
	testSetup(t)
	candidate := makePublishCandidate(t, "550e8400-e29b-41d4-a716-446655440000", "payload")
	remoteRoot := t.TempDir()
	writeTestFile(t, remoteRoot, "metadata.db", "metadata")
	writeTestFile(t, remoteRoot, "Author/Book (1)/book.epub", "payload")
	writeTestFile(t, remoteRoot, "static/library_index.zst", "index")
	for _, path := range []string{memberPointerPath, libraryflow.GenerationPath} {
		data, err := os.ReadFile(filepath.Join(candidate.Root, filepath.FromSlash(path)))
		if err != nil {
			t.Fatal(err)
		}
		full := filepath.Join(remoteRoot, filepath.FromSlash(path))
		if err := os.MkdirAll(filepath.Dir(full), 0o755); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(full, data, 0o644); err != nil {
			t.Fatal(err)
		}
	}
	withLocalCommandRemote(t, remoteRoot)
	publishCommitStageHook = func(stage string) error {
		if stage == "before-pointer" {
			return errors.New("injected legacy predecessor boundary")
		}
		return nil
	}
	t.Cleanup(func() { publishCommitStageHook = nil })

	options := publishOptions{MaxDeletes: libraryflow.DefaultMaxDeletes, AllowCompleteOverwrite: true}
	err := publishCandidate("alice", "550e8400-e29b-41d4-a716-446655440000", GroupS3Credentials{}, candidate, options)
	if err == nil || !strings.Contains(err.Error(), "injected legacy predecessor boundary") {
		t.Fatalf("first publish error=%v", err)
	}
	publishCommitStageHook = nil
	if err := publishCandidate("alice", "550e8400-e29b-41d4-a716-446655440000", GroupS3Credentials{}, candidate, options); err != nil {
		t.Fatal(err)
	}
	if snapshot := (&libraryRemote{fsPath: remoteRoot}).commitState(); snapshot.Err != nil || !snapshot.Committed || snapshot.Generation != 2 {
		t.Fatalf("replanned snapshot=%+v", snapshot)
	}
}

func TestGenerationChangePublishStopsWhenWriterChangesBeforeSentinel(t *testing.T) {
	testSetup(t)
	candidate := makePublishCandidate(t, "550e8400-e29b-41d4-a716-446655440000", "payload")
	remoteRoot := t.TempDir()
	withLocalCommandRemote(t, remoteRoot)
	publishCommitStageHook = func(stage string) error {
		if stage != "before-sentinel" {
			return nil
		}
		marker := libraryflow.ClaimWriter("other-seat", "Other seat", time.Now(), nil)
		raw, err := marker.Marshal()
		if err != nil {
			return err
		}
		return os.WriteFile(filepath.Join(remoteRoot, libraryflow.WriterPath), raw, 0o600)
	}
	t.Cleanup(func() { publishCommitStageHook = nil })

	err := publishCandidate("alice", "550e8400-e29b-41d4-a716-446655440000", GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: libraryflow.DefaultMaxDeletes})
	if err == nil || !strings.Contains(err.Error(), "publishing access changed") {
		t.Fatalf("publish error=%v", err)
	}
	if _, err := os.Stat(filepath.Join(remoteRoot, libraryflow.GenerationPath)); !os.IsNotExist(err) {
		t.Fatalf("sentinel exists after writer race: %v", err)
	}
}

func TestGenerationChangePublishStopsWhenLocalChangesBeforeSentinel(t *testing.T) {
	testSetup(t)
	candidate := makePublishCandidate(t, "550e8400-e29b-41d4-a716-446655440000", "payload")
	remoteRoot := t.TempDir()
	checksum := generationCandidateChecksum(t)
	fromToken := seedExactChangeRemote(t, remoteRoot, candidate, checksum)
	attachExactEmptyChange(t, candidate, fromToken, checksum)
	withLocalCommandRemote(t, remoteRoot)
	publishCommitStageHook = func(stage string) error {
		if stage == "before-sentinel" {
			return os.WriteFile(filepath.Join(candidate.Root, "Author", "Book (1)", "book.epub"), []byte("changed"), 0o644)
		}
		return nil
	}
	t.Cleanup(func() { publishCommitStageHook = nil })

	err := publishCandidate("alice", "550e8400-e29b-41d4-a716-446655440000", GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: libraryflow.DefaultMaxDeletes})
	if err == nil || !strings.Contains(err.Error(), "library files changed while publishing") {
		t.Fatalf("publish error=%v", err)
	}
	remoteToken, readErr := os.ReadFile(filepath.Join(remoteRoot, libraryflow.GenerationPath))
	if readErr != nil || !bytes.Equal(remoteToken, fromToken) {
		t.Fatalf("sentinel after local mutation = %x, err=%v; want predecessor %x", remoteToken, readErr, fromToken)
	}
}

func TestGenerationChangePublishStopsWhenBuiltIndexChangesBeforeSentinel(t *testing.T) {
	testSetup(t)
	candidate := makePublishCandidate(t, "550e8400-e29b-41d4-a716-446655440000", "payload")
	remoteRoot := t.TempDir()
	checksum := generationCandidateChecksum(t)
	fromToken := seedExactChangeRemote(t, remoteRoot, candidate, checksum)
	attachExactEmptyChange(t, candidate, fromToken, checksum)
	withLocalCommandRemote(t, remoteRoot)
	publishCommitStageHook = func(stage string) error {
		if stage == "before-sentinel" {
			return os.WriteFile(
				filepath.Join(candidate.Root, filepath.FromSlash(candidate.Change.IndexArtifact.Path)),
				[]byte("replaced after the manifest and pointer were prepared"), 0o644,
			)
		}
		return nil
	}
	t.Cleanup(func() { publishCommitStageHook = nil })

	err := publishCandidate("alice", candidate.Change.LibraryUUID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: libraryflow.DefaultMaxDeletes})
	if err == nil || !strings.Contains(err.Error(), "generated library index changed while publishing") {
		t.Fatalf("publish error=%v", err)
	}
	remoteToken, readErr := os.ReadFile(filepath.Join(remoteRoot, libraryflow.GenerationPath))
	if readErr != nil || !bytes.Equal(remoteToken, fromToken) {
		t.Fatalf("sentinel after index mutation = %x, err=%v; want predecessor %x", remoteToken, readErr, fromToken)
	}
}

func TestGenerationChangeManifestRejectsConflictingExistingBytes(t *testing.T) {
	remoteRoot := t.TempDir()
	remote := &libraryRemote{fsPath: remoteRoot}
	bound := boundGenerationPublication{
		ManifestPath:  ".accorder/changes/target.manifest.json",
		ManifestBytes: []byte("expected\n"),
	}
	writeTestFile(t, remoteRoot, bound.ManifestPath, "different\n")
	if err := createGenerationChangeManifest(remote, bound); err == nil || !strings.Contains(err.Error(), "different changed-book record") {
		t.Fatalf("conflicting create error=%v", err)
	}
	data, err := os.ReadFile(filepath.Join(remoteRoot, filepath.FromSlash(bound.ManifestPath)))
	if err != nil {
		t.Fatal(err)
	}
	if string(data) != "different\n" {
		t.Fatalf("existing immutable bytes changed to %q", data)
	}
}

func attachExactEmptyChange(t *testing.T, candidate *libraryCandidate, fromToken []byte, checksum string) {
	t.Helper()
	book := generationCandidateBook()
	book.LibraryUUID = "550e8400-e29b-41d4-a716-446655440000"
	jsonlPath := filepath.Join(candidate.Root, "candidate-books.jsonl")
	jsonl, err := os.Create(jsonlPath)
	if err != nil {
		t.Fatal(err)
	}
	if err := json.NewEncoder(jsonl).Encode(book); err != nil {
		_ = jsonl.Close()
		t.Fatal(err)
	}
	if err := jsonl.Close(); err != nil {
		t.Fatal(err)
	}
	base, generation, err := torshare.DecodeGeneration(fromToken)
	if err != nil {
		t.Fatal(err)
	}
	indexPath := filepath.Join(candidate.Root, "static", "library_index")
	search := &calibre.MotwSearch{JsonlPath: jsonlPath, IndexPath: indexPath, BaseGeneration: &base, StartGeneration: generation}
	index, err := search.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := search.CompressToFile(index); err != nil {
		t.Fatal(err)
	}
	if err := compressFileZstd(jsonlPath, indexPath+".jsonl.zst"); err != nil {
		t.Fatal(err)
	}
	manifest, err := calibre.ReadExistingManifest(indexPath)
	if err != nil {
		t.Fatal(err)
	}
	if err := calibre.WritePointerFile(indexPath, manifest, calibre.PointerFileLibrary{UUID: book.LibraryUUID, Librarian: "Alice"}, true); err != nil {
		t.Fatal(err)
	}
	pointer, err := calibre.ReadPointerFile(indexPath + ".manifest.json")
	if err != nil {
		t.Fatal(err)
	}
	pointer.CatalogChecksum = checksum
	if err := calibre.WritePointerDocument(indexPath+".manifest.json", pointer); err != nil {
		t.Fatal(err)
	}
	objects, err := listLocalObjects(candidate.Root)
	if err != nil {
		t.Fatal(err)
	}
	ledger, _, _, err := buildContentLedger(candidate.Root, objects, candidate.Excludes, nil)
	if err != nil {
		t.Fatal(err)
	}
	fromCount := uint32(1)
	change := localChangeCandidate{
		Version: localChangeCandidateVersion, LibraryUUID: "550e8400-e29b-41d4-a716-446655440000",
		Scope: calibre.GenerationChangeScopeExact, FromGeneration: hex.EncodeToString(fromToken),
		FromLiveCount: &fromCount, FromCatalogChecksum: checksum,
		TargetSourceFingerprint: candidate.SourceFingerprint, ToLiveCount: 1, ToCatalogChecksum: checksum,
		Changes: []calibre.GenerationChange{}, ContentLedgerVersion: 1, ContentLedger: ledger,
	}
	indexZstPath := filepath.Join(candidate.Root, "static", "library_index.zst")
	indexInfo, err := os.Stat(indexZstPath)
	if err != nil {
		t.Fatal(err)
	}
	change.IndexArtifact = libraryflow.NewLocalObject("static/library_index.zst", indexInfo)
	change.IndexArtifact.Hash, err = hashLocalFile(indexZstPath)
	if err != nil {
		t.Fatal(err)
	}
	if err := saveLocalChangeCandidate(candidate.Root, change); err != nil {
		t.Fatal(err)
	}
	candidate.Change = &change
}

func generationCandidateChecksum(t *testing.T) string {
	t.Helper()
	book := generationCandidateBook()
	book.LibraryUUID = "550e8400-e29b-41d4-a716-446655440000"
	checksum, err := calibre.CatalogChecksum([]*calibre.Book{book})
	if err != nil {
		t.Fatal(err)
	}
	return hex.EncodeToString(checksum[:])
}

func seedExactChangeRemote(t *testing.T, root string, candidate *libraryCandidate, checksum string) []byte {
	t.Helper()
	writeTestFile(t, root, "metadata.db", "metadata")
	writeTestFile(t, root, "Author/Book (1)/book.epub", "payload")
	previousFingerprint := strings.Repeat("e", 64)
	pointer, err := calibre.BindPointerCommit(calibre.PointerFile{
		Version: 1,
		Library: calibre.PointerFileLibrary{UUID: "550e8400-e29b-41d4-a716-446655440000", Librarian: "Alice"},
		Index:   calibre.PointerFileIndex{URL: "library_index.zst", NumBooks: 1, PointerGeneration: 1},
	}, previousFingerprint, 1)
	if err != nil {
		t.Fatal(err)
	}
	pointer.CatalogChecksum = checksum
	if err := os.MkdirAll(filepath.Join(root, "static"), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := calibre.WritePointerDocument(filepath.Join(root, filepath.FromSlash(memberPointerPath)), pointer); err != nil {
		t.Fatal(err)
	}
	var base [16]byte
	base[0] = 3
	token := torshare.EncodeGeneration(base, 1)
	if err := os.WriteFile(filepath.Join(root, libraryflow.GenerationPath), token, 0o644); err != nil {
		t.Fatal(err)
	}
	if err := saveBaseline("alice", libraryBaseline{
		LibraryID: pointer.Library.UUID, RemoteSourceFingerprint: previousFingerprint,
		LocalSourceFingerprint: previousFingerprint, Generation: 1,
	}); err != nil {
		t.Fatal(err)
	}
	return token
}
