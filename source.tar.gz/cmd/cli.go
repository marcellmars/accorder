package cmd

import (
	"encoding/json"
	"fmt"
	"log"
	"reflect"
	"strings"

	"github.com/alecthomas/kong"
	"github.com/tidwall/gjson"
	"github.com/tidwall/sjson"
)

type Globals struct {
	Version VersionFlag       `short:"v" name:"version" help:"Print version information and quit"`
	On      onFlagInterceptor `name:"on" help:"Run this command on a remote server over SSH (value is an ssh host or alias, e.g. from ~/.ssh/config)." default:""`
}

type VersionFlag bool

func (v VersionFlag) BeforeApply(app *kong.Kong, vars kong.Vars) error {
	fmt.Println(vars["version"])
	app.Exit(0)
	return nil
}

type fieldTags struct {
	JSONName         string
	SharedGroup      string
	ExcludeFromAlias bool
	NoPropagate      bool
	Required         bool
}

func getFieldTags(t reflect.Type, fieldName string) (fieldTags, bool) {
	if t.Kind() == reflect.Ptr {
		t = t.Elem()
	}
	for i := 0; i < t.NumField(); i++ {
		field := t.Field(i)
		jsonTag := field.Tag.Get("json")
		jsonName := strings.Split(jsonTag, ",")[0]
		if field.Name == fieldName || jsonName == fieldName {
			return fieldTags{
				JSONName:         jsonName,
				SharedGroup:      field.Tag.Get("sharedgroup"),
				ExcludeFromAlias: field.Tag.Get("alias") == "-",
				NoPropagate:      field.Tag.Get("propagate") == "-",
				Required:         strings.Contains(field.Tag.Get("validate"), "required"),
			}, true
		}
		if field.Anonymous && field.Type.Kind() == reflect.Struct {
			if tags, ok := getFieldTags(field.Type, fieldName); ok {
				return tags, true
			}
		}
	}
	return fieldTags{}, false
}

func getProvidedFlagNames(ctx *kong.Context) map[string]struct{} {
	provided := make(map[string]struct{})
	for _, path := range ctx.Path {
		if path.Flag != nil && path.Flag.Value != nil {
			flagName := path.Flag.Value.Name
			if flagName != "" {
				provided[flagName] = struct{}{}
			}
		}
	}
	return provided
}

var sharedGroupCache = make(map[reflect.Type]map[string]struct{})

func getSharedGroups(t reflect.Type) map[string]struct{} {
	if t.Kind() == reflect.Ptr {
		t = t.Elem()
	}
	if cached, ok := sharedGroupCache[t]; ok {
		return cached
	}
	groups := make(map[string]struct{})
	collectSharedGroups(t, groups)
	sharedGroupCache[t] = groups
	return groups
}

func collectSharedGroups(t reflect.Type, groups map[string]struct{}) {
	if t.Kind() == reflect.Ptr {
		t = t.Elem()
	}
	for i := 0; i < t.NumField(); i++ {
		field := t.Field(i)
		if sg := field.Tag.Get("sharedgroup"); sg != "" {
			groups[sg] = struct{}{}
		}
		if field.Anonymous && field.Type.Kind() == reflect.Struct {
			collectSharedGroups(field.Type, groups)
		}
	}
}

func hasSharedGroup(t reflect.Type, groupName string) bool {
	groups := getSharedGroups(t)
	_, ok := groups[groupName]
	return ok
}

func copyFromCLIToTarget(cli *CLI, targetValue reflect.Value, actionPath string) {
	pathParts := strings.Split(actionPath, ".")
	sourceValue, err := navigateByJSONPath(reflect.ValueOf(cli), pathParts)
	if err != nil {
		log.Printf("Warning: %v", err)
		return
	}
	target := targetValue
	if target.Kind() == reflect.Ptr {
		if target.IsNil() {
			target.Set(reflect.New(target.Type().Elem()))
		}
		target = target.Elem()
	}
	if !target.CanSet() || !sourceValue.IsValid() {
		log.Printf("Warning: Unable to set target for action path %s", actionPath)
		return
	}
	if sourceValue.Kind() == reflect.Ptr {
		if sourceValue.IsNil() {
			return
		}
		sourceValue = sourceValue.Elem()
	}
	target.Set(sourceValue)
}

func navigateByJSONPath(value reflect.Value, path []string) (reflect.Value, error) {
	current := value
	for _, segment := range path {
		if !current.IsValid() {
			return reflect.Value{}, fmt.Errorf("invalid path segment %q", segment)
		}
		if current.Kind() == reflect.Ptr {
			if current.IsNil() {
				current.Set(reflect.New(current.Type().Elem()))
			}
			current = current.Elem()
		}
		field := fieldByJSONName(current, segment)
		if !field.IsValid() {
			return reflect.Value{}, fmt.Errorf("field with json tag %q not found while navigating path %s",
				segment, strings.Join(path, "."))
		}
		current = field
	}
	return current, nil
}

func fieldByJSONName(v reflect.Value, jsonName string) reflect.Value {
	t := v.Type()
	for i := 0; i < t.NumField(); i++ {
		field := t.Field(i)
		tag := field.Tag.Get("json")
		if tag == "" {
			continue
		}
		name := strings.Split(tag, ",")[0]
		if name == jsonName {
			fv := v.Field(i)
			if fv.Kind() == reflect.Ptr && fv.IsNil() {
				fv.Set(reflect.New(fv.Type().Elem()))
			}
			return fv
		}
	}
	return reflect.Value{}
}

func (c *CLI) AfterApply(ctx *kong.Context) error {
	providedAction := ctx.Selected()
	if providedAction == nil {
		return nil
	}

	cliRoot := providedAction
	for cliRoot.Parent != nil {
		cliRoot = cliRoot.Parent
	}

	selectedActionJSON, _ := json.Marshal(providedAction.Target.Interface())
	var selectedAction map[string]interface{}
	_ = json.Unmarshal(selectedActionJSON, &selectedAction)

	actionAlias, ok := selectedAction["action_alias"].(string)
	if !ok || actionAlias == "" {

		if cf := commonFieldsOf(providedAction.Target); cf != nil && cf.showConfigRequested() {
			return nil
		}
		return validateSelectedNode(providedAction, "")
	}

	providedFlags := getProvidedFlagNames(ctx)

	common := commonFieldsOf(providedAction.Target)
	showConfig := common != nil && common.showConfigRequested()
	prov := newProvenanceTable()

	if common != nil {
		common.setShowConfigContext(&showConfigContext{
			provenance:   prov,
			selectedNode: providedAction,
			rootNode:     cliRoot,
			readOnly:     showConfig,
		})
	}

	var liveServe *FedlibShareLiveCmd
	if providedAction.Target.CanAddr() {
		liveServe, _ = providedAction.Target.Addr().Interface().(*FedlibShareLiveCmd)
	}
	if liveServe != nil && !showConfig {
		if err := blockingIssueError("fedlib share live", liveServe.descriptorPreflight()); err != nil {
			return err
		}
	}

	if !showConfig {
		unlockAliasCfg := lockAliasConfigOrDie()
		defer unlockAliasCfg()
	}
	configFileBytes := loadActionAliases()
	if !showConfig {
		migrateAliasCredentials(&configFileBytes)
	}

	actionPath := strings.Join(strings.Split(providedAction.Path(), " "), ".")
	actionAliasPath := actionAlias + "." + actionPath

	targetType := providedAction.Target.Type()

	savedCount := 0
	for key, value := range selectedAction {
		tags, found := getFieldTags(targetType, key)
		if !found {
			continue
		}
		if tags.JSONName == "-" || tags.JSONName == "" || tags.ExcludeFromAlias || key == "action_alias" {
			continue
		}
		if _, wasProvided := providedFlags[tags.JSONName]; !wasProvided {
			continue
		}
		if value == nil {
			continue
		}

		configFileBytes, _ = sjson.SetBytes(configFileBytes, actionAliasPath+"."+key, value)
		savedCount++

		if tags.NoPropagate {
			continue
		}

		if tags.SharedGroup != "" {
			propagateSharedField(cliRoot, providedAction, actionAlias, key, value, tags.SharedGroup, &configFileBytes)
		}

		if providedAction.Group != nil && providedAction.Group.Key != "" && tags.SharedGroup == "" {
			propagateGroupField(cliRoot, providedAction, actionAlias, key, value, &configFileBytes)
		}
	}

	aliasData := gjson.GetBytes(configFileBytes, actionAlias).Raw
	if aliasData != "" {
		if err := json.Unmarshal([]byte(aliasData), c); err != nil {
			log.Fatalln(err)
		}
	}

	copyFromCLIToTarget(c, providedAction.Target, actionPath)

	recordFlagOrigins(prov, ctx, gjson.ParseBytes(configFileBytes).Get(actionAlias), actionPath, actionAlias)

	rc := &resolveCtx{prov: prov, readOnly: showConfig}

	if liveServe != nil && !showConfig {
		if err := blockingIssueError("fedlib share live", liveServe.completeAggregatePath()); err != nil {
			return err
		}
	}

	switch actionPath {
	case "lib.publish", "lib.upload", "lib.download", "lib.status", "lib.sync",
		"lib.seat.show", "lib.seat.claim", "lib.seat.release":
		_, keysFileExplicit := providedFlags["keys-file"]
		if keysFileExplicit || mergedKeysFile(providedAction.Target) != "" {
			resolveOperatorS3Creds(providedAction.Target, actionAlias, providedFlags, rc)
		} else {
			_, bucketExplicit := providedFlags["bucket"]
			resolveS3CredsFromSecretsStore(providedAction.Target, actionAlias, bucketExplicit, rc)
		}
	case "fedlib.share.live":

		if liveServe != nil && !showConfig {
			rc.credentialOnly = true
			resolveOperatorS3Creds(providedAction.Target, actionAlias, providedFlags, rc)
			liveServe.prepared = true
		}
	case "fedlib.build", "fedlib.share.funnel", "lib.build":
		resolveOperatorS3Creds(providedAction.Target, actionAlias, providedFlags, rc)
	}

	loadedCount := len(selectedAction) - 1
	if savedCount == 0 && loadedCount > 0 && !showConfig {
		log.Printf("[CFG] Using alias '%s' (%d %s loaded)",
			actionAlias, loadedCount, plural(loadedCount, "flag", "flags"))
	}

	if !showConfig {
		if err := validateSelectedNode(providedAction, actionAlias); err != nil {
			return err
		}
	}

	if showConfig {

		stampPendingMint(prov, providedAction.Target)
		return nil
	}

	mintSetupDefaults(providedAction, cliRoot, actionAlias, actionAliasPath, &configFileBytes)
	aliases := cacheAliasSetFromBytes(configFileBytes)
	if err := validateAssetsCacheRemoteCollisions(aliases, actionAlias); err != nil {
		const hint = "rename one of the colliding aliases with 'accorder config rename'"
		if cacheRemoteMutatingAction(actionPath) {
			return fmt.Errorf("%w — %s", err, hint)
		}
		// A pre-existing alias pair like "x" and "x-assets" must not lock
		// unrelated workflows (lib build, lib search, ...) out after an
		// upgrade: only commands that create or migrate VFS cache trees
		// refuse outright; everything else proceeds with a warning.
		log.Printf("[WARN] %v — serve commands will refuse this alias until repaired; %s", err, hint)
	}

	saveActionAliases(configFileBytes)

	if savedCount > 0 {
		log.Printf("Saved %d %s to alias '%s' for '%s'",
			savedCount, plural(savedCount, "field", "fields"), actionAlias, providedAction.Path())
	}

	return nil
}

// cacheRemoteMutatingAction reports whether the command at actionPath can
// create or migrate VFS cache trees and must therefore refuse a colliding
// alias set outright. Serve setup, rename, and recovery re-validate on their
// own paths; this gate only decides whether AfterApply hard-fails or warns.
func cacheRemoteMutatingAction(actionPath string) bool {
	switch actionPath {
	case "fedlib.share.live", "fedlib.share.funnel", "lib.share.live", "fedlib.service.install":
		return true
	default:
		return false
	}
}

func commonFieldsOf(target reflect.Value) *CommonCommandFields {
	if target.Kind() == reflect.Ptr {
		if target.IsNil() {
			return nil
		}
		target = target.Elem()
	}
	if target.Kind() != reflect.Struct {
		return nil
	}
	f := target.FieldByName("CommonCommandFields")
	if !f.IsValid() || !f.CanAddr() {
		return nil
	}
	cf, _ := f.Addr().Interface().(*CommonCommandFields)
	return cf
}

func stampPendingMint(prov *ProvenanceTable, target reflect.Value) {
	if target.Kind() == reflect.Ptr {
		target = target.Elem()
	}
	if target.Kind() != reflect.Struct {
		return
	}
	for _, f := range []struct{ name, kind string }{
		{"LibraryID", "uuid"},
		{"Librarian", "librarian"},
	} {
		if hasGenTag(target.Type(), f.name, f.kind) && fieldStringValue(target, f.name) == "" {
			prov.Stamp(fieldAddr(target, f.name), OriginMinted, "generated at run time")
		}
	}
}

// adoptSharedField returns the value `key` already holds under any sibling
// subcommand of this alias, or "" if none carries one.
//
// Identity fields are alias-wide by construction: propagateSharedField writes
// them to every peer that accepts them. A caller about to generate one must
// therefore ask whether the alias already has an answer, because "this
// subcommand's field is empty" is not the same question as "this library has
// no identity". Running a `lib` subcommand for the first time leaves the first
// true and the second false, and minting on the strength of it re-identifies
// the whole alias.
func adoptSharedField(cliRoot, current *kong.Node, alias, key, groupName string, configBytes []byte) string {
	found := ""
	var traverse func(*kong.Node)
	traverse = func(node *kong.Node) {
		if node == nil || found != "" {
			return
		}
		if node != current && node.Target.IsValid() && node.Target.Type().Kind() == reflect.Struct {
			if hasSharedGroup(node.Target.Type(), groupName) && typeHasAliasField(node.Target.Type(), key) {
				peerPath := strings.Join(strings.Split(node.Path(), " "), ".")
				if value := gjson.GetBytes(configBytes, alias+"."+peerPath+"."+key).String(); value != "" {
					found = value
					return
				}
			}
		}
		for _, child := range node.Children {
			traverse(child)
		}
	}
	traverse(cliRoot)
	return found
}

// adoptSharedUint is adoptSharedField for a numeric field. Zero means no
// sibling carries one — which for dictID is also the legitimate value for a
// library that is not a federation member.
func adoptSharedUint(cliRoot, current *kong.Node, alias, key, groupName string, configBytes []byte) uint64 {
	var found uint64
	var traverse func(*kong.Node)
	traverse = func(node *kong.Node) {
		if node == nil || found != 0 {
			return
		}
		if node != current && node.Target.IsValid() && node.Target.Type().Kind() == reflect.Struct {
			if hasSharedGroup(node.Target.Type(), groupName) && typeHasAliasField(node.Target.Type(), key) {
				peerPath := strings.Join(strings.Split(node.Path(), " "), ".")
				if value := gjson.GetBytes(configBytes, alias+"."+peerPath+"."+key); value.Exists() {
					if n := value.Uint(); n != 0 {
						found = n
						return
					}
				}
			}
		}
		for _, child := range node.Children {
			traverse(child)
		}
	}
	traverse(cliRoot)
	return found
}

func propagateSharedField(cliRoot, current *kong.Node, alias, key string, value interface{}, groupName string, configBytes *[]byte) {
	var traverse func(*kong.Node)
	traverse = func(node *kong.Node) {
		if node == nil {
			return
		}
		if node != current && node.Target.IsValid() && node.Target.Type().Kind() == reflect.Struct {
			if hasSharedGroup(node.Target.Type(), groupName) &&
				typeHasAliasField(node.Target.Type(), key) {
				peerPath := strings.Join(strings.Split(node.Path(), " "), ".")
				peerAliasPath := alias + "." + peerPath
				*configBytes, _ = sjson.SetBytes(*configBytes, peerAliasPath+"."+key, value)
			}
		}
		for _, child := range node.Children {
			traverse(child)
		}
	}
	traverse(cliRoot)
}

func propagateGroupField(cliRoot, current *kong.Node, alias, key string, value interface{}, configBytes *[]byte) {
	var traverse func(*kong.Node)
	traverse = func(node *kong.Node) {
		if node == nil {
			return
		}
		if node.Group != nil && current.Group.Key == node.Group.Key && node != current &&
			node.Target.IsValid() && node.Target.Type().Kind() == reflect.Struct &&
			typeHasAliasField(node.Target.Type(), key) {
			peerPath := strings.Join(strings.Split(node.Path(), " "), ".")
			peerAliasPath := alias + "." + peerPath
			*configBytes, _ = sjson.SetBytes(*configBytes, peerAliasPath+"."+key, value)
		}
		for _, child := range node.Children {
			traverse(child)
		}
	}
	traverse(cliRoot)
}

func plural(n int, singular, pluralForm string) string {
	if n == 1 {
		return singular
	}
	return pluralForm
}

var cmdVersion = "dev"

func Execute(version string) {
	if f := strings.Fields(version); len(f) >= 2 {
		cmdVersion = f[1]
	}

	cli := CLI{
		Globals: Globals{},
	}

	ctx := kong.Parse(&cli,
		kong.Name("accorder"),
		kong.Description("Accord actions. The 'action alias' feature stores the latest flag values, enabling future runs with just the 'action alias' argument present, thus eliminating the need to re-specify flags."),
		kong.ShortUsageOnError(),
		kong.ConfigureHelp(kong.HelpOptions{
			Compact: true,
			Tree:    true,
		}),
		kong.Vars{
			"version": version,
		},
		kong.Bind(&cli.Globals, &cli))
	err := ctx.Run()
	ctx.FatalIfErrorf(err)
}
