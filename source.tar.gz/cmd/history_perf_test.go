//go:build linux && !tailscale

package cmd

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"path/filepath"
	"sync"
	"syscall"
	"testing"
	"time"
)

// Copied unchanged into detached historical worktrees. Only the upload adapter
// changes where the production preparation entry point was renamed.
func TestHistoricalCommandPerformance(t *testing.T) {
	mode, root := os.Getenv("ACCORDER_HISTORY_MODE"), os.Getenv("ACCORDER_HISTORY_ROOT")
	if mode == "" {
		t.Skip("opt-in disposable historical command comparison")
	}
	if !filepath.IsAbs(root) || filepath.Base(root) != "library" {
		t.Fatal("explicit scratch/library root required")
	}
	if _, err := os.Stat(filepath.Join(filepath.Dir(root), "fixture.json")); err != nil {
		t.Fatal("missing disposable fixture marker")
	}
	accorderConfigDir = filepath.Join(filepath.Dir(root), "config")
	if err := os.MkdirAll(accorderConfigDir, 0o700); err != nil {
		t.Fatal(err)
	}
	build := &LibBuildCmd{GroupLib: GroupLib{GroupLibDir: GroupLibDir{CalibreDirectory: root},
		LibraryID: "550e8400-e29b-41d4-a716-446655440000", Librarian: "Alice",
		JsonLPath: filepath.Join(root, "static/catalog.jsonl"), IndexPath: filepath.Join(root, "static/library_index")}}
	build.ActionAlias = "alice"
	type workStat struct {
		Calls   int     `json:"calls"`
		Items   int     `json:"items"`
		Seconds float64 `json:"seconds"`
	}
	work := map[string]workStat{}
	if os.Getenv("ACCORDER_HISTORY_ACCOUNTING") == "1" {
		var mu sync.Mutex
		libraryWorkObserver = func(stage string, duration time.Duration, items int) {
			mu.Lock()
			defer mu.Unlock()
			stat := work[stage]
			stat.Calls++
			stat.Items += items
			stat.Seconds += duration.Seconds()
			work[stage] = stat
		}
		t.Cleanup(func() { libraryWorkObserver = nil })
	}
	// Reading the index for identity would warm cold measurements; hash it only
	// after the command. The runner compares hashes of steady-state invocations.
	var before, after syscall.Rusage
	if err := syscall.Getrusage(syscall.RUSAGE_SELF, &before); err != nil {
		t.Fatal(err)
	}
	start := time.Now()
	var err error
	switch mode {
	case "build":
		err = build.Run(nil)
	case "upload-preparation":
		err = historicalPrepareUpload(build)
	default:
		t.Fatalf("unknown mode %q", mode)
	}
	elapsed := time.Since(start)
	if err != nil {
		t.Fatal(err)
	}
	if err := syscall.Getrusage(syscall.RUSAGE_SELF, &after); err != nil {
		t.Fatal(err)
	}
	index, err := os.ReadFile(build.IndexPath + ".zst")
	if err != nil {
		t.Fatal(err)
	}
	digest := sha256.Sum256(index)
	row := map[string]any{"mode": mode, "wall_seconds": elapsed.Seconds(),
		"cpu_seconds":          float64(after.Utime.Nano()+after.Stime.Nano()-before.Utime.Nano()-before.Stime.Nano()) / 1e9,
		"process_peak_rss_kib": after.Maxrss, "index_sha256": hex.EncodeToString(digest[:]),
		"fixture_root": root, "revision": os.Getenv("ACCORDER_HISTORY_REVISION"), "upload_adapter": historicalUploadAdapter}
	row["work"] = work
	raw, err := json.Marshal(row)
	if err != nil {
		t.Fatal(err)
	}
	t.Log(string(raw))
}
