package cmd

import (
	"bytes"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"

	uuid "github.com/satori/go.uuid"
)

const memberChangeRequestVersion = 1

const memberChangeRequestMaxBytes = 1 << 20

var errBoundedFileTooLarge = errors.New("file exceeds byte limit")

type observedMemberTransition struct {
	LibraryUUID        string `json:"library_uuid"`
	PreviousGeneration string `json:"previous_generation"`
	ObservedGeneration string `json:"observed_generation"`
}

type memberChangeRequest struct {
	Version int                        `json:"version"`
	Members []observedMemberTransition `json:"members"`
}

func encodeMemberChangeRequest(transitions []observedMemberTransition) ([]byte, error) {
	request := memberChangeRequest{Version: memberChangeRequestVersion, Members: append([]observedMemberTransition(nil), transitions...)}
	if err := request.validate(); err != nil {
		return nil, err
	}
	data, err := json.Marshal(request)
	if err != nil {
		return nil, err
	}
	return append(data, '\n'), nil
}

func decodeMemberChangeRequest(data []byte) ([]observedMemberTransition, error) {
	if len(data) < 2 || data[len(data)-1] != '\n' || data[len(data)-2] == '\n' {
		return nil, errors.New("member change request: exactly one trailing LF is required")
	}
	if len(bytes.TrimSpace(data[:len(data)-1])) != len(data)-1 {
		return nil, errors.New("member change request: non-canonical whitespace")
	}
	var request memberChangeRequest
	dec := json.NewDecoder(bytes.NewReader(data[:len(data)-1]))
	dec.DisallowUnknownFields()
	if err := dec.Decode(&request); err != nil {
		return nil, fmt.Errorf("member change request: %w", err)
	}
	var trailing any
	if err := dec.Decode(&trailing); err != io.EOF {
		return nil, errors.New("member change request: trailing JSON")
	}
	if err := request.validate(); err != nil {
		return nil, err
	}
	canonical, err := encodeMemberChangeRequest(request.Members)
	if err != nil {
		return nil, err
	}
	if !bytes.Equal(canonical, data) {
		return nil, errors.New("member change request: non-canonical encoding")
	}
	return request.Members, nil
}

func (request memberChangeRequest) validate() error {
	if request.Version != memberChangeRequestVersion {
		return fmt.Errorf("member change request: unsupported version %d", request.Version)
	}
	if request.Members == nil {
		return errors.New("member change request: members is required")
	}
	previousUUID := ""
	for i, transition := range request.Members {
		parsed, err := uuid.FromString(transition.LibraryUUID)
		if err != nil || parsed.String() != transition.LibraryUUID || strings.ToLower(transition.LibraryUUID) != transition.LibraryUUID {
			return fmt.Errorf("member change request: members[%d].library_uuid is not canonical", i)
		}
		if previousUUID != "" && transition.LibraryUUID <= previousUUID {
			return errors.New("member change request: members must be strictly UUID-sorted and unique")
		}
		previousUUID = transition.LibraryUUID
		previous, err := decodeGenerationHex(transition.PreviousGeneration)
		if err != nil {
			return fmt.Errorf("member change request: members[%d].previous_generation: %w", i, err)
		}
		observed, err := decodeGenerationHex(transition.ObservedGeneration)
		if err != nil {
			return fmt.Errorf("member change request: members[%d].observed_generation: %w", i, err)
		}
		if previous == observed {
			return fmt.Errorf("member change request: members[%d] generations are equal", i)
		}
	}
	return nil
}

func decodeGenerationHex(value string) (aggregateGenerationToken, error) {
	if len(value) != 48 || strings.ToLower(value) != value {
		return aggregateGenerationToken{}, errors.New("generation must be 48 lowercase hexadecimal characters")
	}
	raw, err := hex.DecodeString(value)
	if err != nil {
		return aggregateGenerationToken{}, err
	}
	return decodeAggregateGenerationToken(raw)
}

func transitionGenerationHex(token [24]byte) string { return hex.EncodeToString(token[:]) }

func (mpc *memberPollContext) observedTransitions(changedUUIDs []string) []observedMemberTransition {
	transitions := make([]observedMemberTransition, 0, len(changedUUIDs))
	for _, memberUUID := range changedUUIDs {
		if entry, ok := mpc.pollSet[memberUUID]; !ok || entry.Kind == "peer" {
			continue
		}
		prefix := mpc.registryPrefixes[memberUUID]
		change, ok := mpc.lastTickChanges[prefix]
		current, currentOK := mpc.lastKnownGen[prefix]
		if !ok || !change.hadPrev || !currentOK {
			continue
		}
		transitions = append(transitions, observedMemberTransition{
			LibraryUUID: memberUUID, PreviousGeneration: transitionGenerationHex(change.prev),
			ObservedGeneration: transitionGenerationHex(current),
		})
	}
	sort.Slice(transitions, func(i, j int) bool { return transitions[i].LibraryUUID < transitions[j].LibraryUUID })
	return transitions
}

func residualPublicationScope(changes map[string]genChange, registryPrefixes map[string]string, transitions []observedMemberTransition) aggregateInvalidationScope {
	covered := make(map[string]struct{}, len(transitions))
	for _, transition := range transitions {
		if prefix := registryPrefixes[transition.LibraryUUID]; prefix != "" {
			covered[prefix] = struct{}{}
		}
	}
	residual := make([]string, 0, len(changes))
	for prefix := range changes {
		if _, ok := covered[prefix]; !ok {
			residual = append(residual, prefix)
		}
	}
	return memberAggregateInvalidation(residual...)
}

func writeMemberChangeRequest(dir string, transitions []observedMemberTransition) (string, error) {
	data, err := encodeMemberChangeRequest(transitions)
	if err != nil {
		return "", err
	}
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return "", err
	}
	f, err := os.CreateTemp(dir, ".member-change-request-*.json")
	if err != nil {
		return "", err
	}
	path := f.Name()
	cleanup := func() {
		_ = f.Close()
		_ = os.Remove(path)
	}
	if err := f.Chmod(0o600); err != nil {
		cleanup()
		return "", err
	}
	if _, err := f.Write(data); err != nil {
		cleanup()
		return "", err
	}
	if err := f.Sync(); err != nil {
		cleanup()
		return "", err
	}
	if err := f.Close(); err != nil {
		_ = os.Remove(path)
		return "", err
	}
	return filepath.Clean(path), nil
}

func readFileBounded(path string, maxBytes int64) ([]byte, error) {
	info, err := os.Stat(path)
	if err != nil {
		return nil, err
	}
	if info.Size() > maxBytes {
		return nil, fmt.Errorf("%w: %s is %d bytes, limit %d", errBoundedFileTooLarge, filepath.Base(path), info.Size(), maxBytes)
	}
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	if int64(len(data)) > maxBytes {
		return nil, fmt.Errorf("%w: %s grew past limit %d", errBoundedFileTooLarge, filepath.Base(path), maxBytes)
	}
	return data, nil
}
