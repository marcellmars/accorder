package cmd

import (
	"fmt"
	"reflect"
	"sort"
	"strings"

	"github.com/alecthomas/kong"
	"github.com/go-playground/validator/v10"
)

type validationItem struct {
	display string
	hint    string
	tag     string
	order   int
}

func validateSelectedNode(node *kong.Node, actionAlias string) error {
	if node == nil || !node.Target.IsValid() || !node.Target.CanAddr() {
		return nil
	}
	return validateSelectedTarget(node, node.Target.Addr().Interface(), node.Path(), actionAlias)
}

func validateSelectedTarget(node *kong.Node, target any, cmdPath, actionAlias string) error {
	err := validate.Struct(target)
	if err == nil {
		return nil
	}
	verrs, ok := err.(validator.ValidationErrors)
	if !ok {

		return fmt.Errorf("validation setup error on %s: %w", cmdPath, err)
	}

	items := make([]validationItem, 0, len(verrs))
	for i, fe := range verrs {
		items = append(items, resolveValidationItem(node, target, fe, i))
	}
	sort.SliceStable(items, func(i, j int) bool { return items[i].order < items[j].order })

	var missing, hints, invalid []string
	for _, it := range items {
		if strings.HasPrefix(it.tag, "required") {
			missing = append(missing, it.display)
			hints = append(hints, it.hint)
		} else {
			invalid = append(invalid, fmt.Sprintf("%s (%s)", it.display, it.tag))
		}
	}

	if len(missing) > 0 {
		if actionAlias != "" {

			return fmt.Errorf("missing required flags: %s\n  tip: run with explicit flags to save them, e.g.:\n  accorder %s %s %s",
				strings.Join(missing, ", "), cmdPath, actionAlias, strings.Join(hints, " "))
		}
		return fmt.Errorf("missing required values: %s\n  tip: accorder %s %s",
			strings.Join(missing, ", "), cmdPath, strings.Join(hints, " "))
	}
	return fmt.Errorf("validation errors: %s", strings.Join(invalid, ", "))
}

func resolveValidationItem(node *kong.Node, target any, fe validator.FieldError, seq int) validationItem {
	const (
		flagBase       = 1_000
		unresolvedBase = 2_000
	)
	if node != nil {
		if fv, ok := fieldByStructNamespace(reflect.ValueOf(target), fe.StructNamespace()); ok && fv.CanAddr() {
			addr := fv.Addr().Pointer()
			for i, p := range node.Positional {
				if p != nil && p.Target.IsValid() && p.Target.CanAddr() && p.Target.Addr().Pointer() == addr {
					return validationItem{
						display: "<" + p.Name + ">",
						hint:    "<" + p.Name + ">",
						tag:     fe.ActualTag(),
						order:   i,
					}
				}
			}
			for i, f := range node.Flags {
				if f != nil && f.Value != nil && f.Value.Target.IsValid() && f.Value.Target.CanAddr() &&
					f.Value.Target.Addr().Pointer() == addr {
					return validationItem{
						display: "--" + f.Name,
						hint:    "--" + f.Name + "=<value>",
						tag:     fe.ActualTag(),
						order:   flagBase + i,
					}
				}
			}
		}
	}

	name, isArg := fieldSpellingByGoName(reflect.TypeOf(target), fe.StructField())
	if isArg {
		return validationItem{
			display: "<" + name + ">",
			hint:    "<" + name + ">",
			tag:     fe.ActualTag(),
			order:   unresolvedBase + seq,
		}
	}
	return validationItem{
		display: "--" + name,
		hint:    "--" + name + "=<value>",
		tag:     fe.ActualTag(),
		order:   unresolvedBase + seq,
	}
}

func fieldByStructNamespace(v reflect.Value, ns string) (reflect.Value, bool) {
	parts := strings.Split(ns, ".")
	if len(parts) < 2 {
		return reflect.Value{}, false
	}
	if v.Kind() == reflect.Ptr {
		v = v.Elem()
	}
	for _, name := range parts[1:] {
		if v.Kind() != reflect.Struct {
			return reflect.Value{}, false
		}
		v = v.FieldByName(name)
		if !v.IsValid() {
			return reflect.Value{}, false
		}
	}
	return v, true
}

func fieldSpellingByGoName(t reflect.Type, goName string) (string, bool) {
	if t == nil {
		return strings.ToLower(goName), false
	}
	if t.Kind() == reflect.Ptr {
		t = t.Elem()
	}
	if t.Kind() != reflect.Struct {
		return strings.ToLower(goName), false
	}
	f, ok := t.FieldByName(goName)
	if !ok {
		return strings.ToLower(goName), false
	}
	_, isArg := f.Tag.Lookup("arg")
	name := f.Tag.Get("name")
	if name == "" {
		name = strings.Split(f.Tag.Get("json"), ",")[0]
	}
	if name == "" || name == "-" {
		name = strings.ToLower(goName)
	}
	return name, isArg
}
