package cmd

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/tidwall/gjson"
)

func aliasExists(name string) bool {
	data, err := os.ReadFile(savedActionAliases)
	if err != nil {
		return false
	}
	return gjson.GetBytes(data, name).Exists()
}

func TestRename_MigratesPairAndJSONL(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "old")
	seedTreePair(t, "accorder-serve-old")
	seedTreePair(t, "accorder-serve-old-assets")
	seedTreePair(t, "accorder-funnel-old")
	seedTreePair(t, "accorder-funnel-old-assets")
	for _, remote := range []string{
		"accorder-serve-old", "accorder-serve-old-assets",
		"accorder-funnel-old", "accorder-funnel-old-assets",
	} {
		ledgerServeStart(t, remote, "bucket")
	}
	activateReclaim(t)
	if err := os.WriteFile(filepath.Join(accorderCacheDir(), "old.jsonl"), []byte("{}"), 0o644); err != nil {
		t.Fatal(err)
	}

	cmd := &AliasRenameCmd{OldName: "old", NewName: "new"}
	if err := cmd.Run(); err != nil {
		t.Fatal(err)
	}

	if !aliasExists("new") || aliasExists("old") {
		t.Fatal("config rename did not commit")
	}
	if !treeExists("vfs", "accorder-serve-new") || !treeExists("vfsMeta", "accorder-serve-new") {
		t.Fatal("tree pair not migrated to new name")
	}
	if treeExists("vfs", "accorder-serve-old") || treeExists("vfsMeta", "accorder-serve-old") {
		t.Fatal("old tree pair still present")
	}
	if !treeExists("vfs", "accorder-serve-new-assets") || !treeExists("vfsMeta", "accorder-serve-new-assets") {
		t.Fatal("assets tree pair not migrated to new name")
	}
	if treeExists("vfs", "accorder-serve-old-assets") || treeExists("vfsMeta", "accorder-serve-old-assets") {
		t.Fatal("old assets tree pair still present")
	}
	for _, remote := range []string{"accorder-funnel-new", "accorder-funnel-new-assets"} {
		if !treeExists("vfs", remote) || !treeExists("vfsMeta", remote) {
			t.Fatalf("funnel tree pair not migrated to %s", remote)
		}
	}
	for _, remote := range []string{"accorder-funnel-old", "accorder-funnel-old-assets"} {
		if treeExists("vfs", remote) || treeExists("vfsMeta", remote) {
			t.Fatalf("old funnel tree pair still present at %s", remote)
		}
	}
	if _, err := os.Stat(filepath.Join(accorderCacheDir(), "new.jsonl")); err != nil {
		t.Fatal("jsonl not migrated")
	}
	if _, err := os.Stat(renameIntentPath()); !os.IsNotExist(err) {
		t.Fatal("intent marker not removed after successful rename")
	}

	// Ledger: source tombstoned, destination active — migrated tree is
	// ledgered without waiting for the next serve start.
	records, malformed, _ := readLedger()
	if malformed {
		t.Fatal("ledger malformed")
	}
	view := replayLedger(records)
	if len(view.activeRoots["accorder-serve-old"]) != 0 || !view.activeRoots["accorder-serve-new"]["bucket"] ||
		len(view.activeRoots["accorder-serve-old-assets"]) != 0 || !view.activeRoots["accorder-serve-new-assets"]["bucket"] ||
		len(view.activeRoots["accorder-funnel-old"]) != 0 || !view.activeRoots["accorder-funnel-new"]["bucket"] ||
		len(view.activeRoots["accorder-funnel-old-assets"]) != 0 || !view.activeRoots["accorder-funnel-new-assets"]["bucket"] {
		t.Fatalf("ledger rename record wrong: old=%v new=%v",
			view.activeRoots["accorder-serve-old"], view.activeRoots["accorder-serve-new"])
	}
}

func TestRename_LegacyTreeSkippedConfigStillRenamed(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "old")
	seedTreePair(t, "accorder-serve-old") // no ledger record: legacy
	activateReclaim(t)

	if err := (&AliasRenameCmd{OldName: "old", NewName: "new"}).Run(); err != nil {
		t.Fatal(err)
	}
	if !aliasExists("new") || aliasExists("old") {
		t.Fatal("config rename did not commit")
	}
	if !treeExists("vfs", "accorder-serve-old") {
		t.Fatal("legacy tree was moved — must be report-only")
	}
	if treeExists("vfs", "accorder-serve-new") {
		t.Fatal("legacy tree migrated under new name")
	}
}

func TestRename_RevalidatesCollisionInsideConfigLock(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "old")
	seedTreePair(t, "accorder-serve-old")
	ledgerServeStart(t, "accorder-serve-old", "bucket")
	activateReclaim(t)

	// Hold the config lock while rename takes its optimistic snapshot and its
	// mutation locks. Adding the conflicting alias here models a second process
	// committing after the optimistic read but before rename's locked commit.
	releaseConfig, err := lockAliasConfig()
	if err != nil {
		t.Fatal(err)
	}
	renameErr := make(chan error, 1)
	go func() {
		renameErr <- migrateRenamedAliasCache("old", "new")
	}()

	deadline := time.Now().Add(2 * time.Second)
	passedOptimisticRead := false
	for time.Now().Before(deadline) {
		releaseProbe, ok, probeErr := acquireMutationLock("accorder-serve-old", "")
		if probeErr != nil {
			releaseConfig()
			t.Fatal(probeErr)
		}
		if !ok {
			passedOptimisticRead = true
			break
		}
		releaseProbe()
		time.Sleep(time.Millisecond)
	}
	if !passedOptimisticRead {
		releaseConfig()
		t.Fatal("rename did not reach the locked commit")
	}

	seedAliasNames(t, "old", "new-assets")
	releaseConfig()

	select {
	case err := <-renameErr:
		if err == nil || !strings.Contains(err.Error(), "collides") {
			t.Fatalf("rename error = %v, want locked collision refusal", err)
		}
	case <-time.After(2 * time.Second):
		t.Fatal("rename did not return after the config lock was released")
	}
	if !aliasExists("old") || !aliasExists("new-assets") || aliasExists("new") {
		t.Fatal("collision refusal mutated the alias set")
	}
	if !treeExists("vfs", "accorder-serve-old") || treeExists("vfs", "accorder-serve-new") {
		t.Fatal("collision refusal moved the cache tree")
	}
}

func TestRename_PreActivationSkipsMigration(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "old")
	seedTreePair(t, "accorder-serve-old")
	ledgerServeStart(t, "accorder-serve-old", "bucket")

	// no activation

	if err := (&AliasRenameCmd{OldName: "old", NewName: "new"}).Run(); err != nil {
		t.Fatal(err)
	}
	if !aliasExists("new") || aliasExists("old") {
		t.Fatal("config rename did not commit pre-activation")
	}
	if !treeExists("vfs", "accorder-serve-old") || treeExists("vfs", "accorder-serve-new") {
		t.Fatal("tree moved pre-activation — destructive machinery must be off")
	}
}

func TestRename_DestinationCollisionSkipsNeverMerges(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "old")
	seedTreePair(t, "accorder-serve-old")
	seedTreePair(t, "accorder-serve-new") // destination already exists
	ledgerServeStart(t, "accorder-serve-old", "bucket")
	activateReclaim(t)

	if err := (&AliasRenameCmd{OldName: "old", NewName: "new"}).Run(); err != nil {
		t.Fatal(err)
	}
	if !aliasExists("new") || aliasExists("old") {
		t.Fatal("config rename did not commit")
	}
	if !treeExists("vfs", "accorder-serve-old") || !treeExists("vfs", "accorder-serve-new") {
		t.Fatal("collision handling moved or merged a tree")
	}
}

func TestRename_ContendedLockSkipsIdentity(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "old")
	seedTreePair(t, "accorder-serve-old")
	ledgerServeStart(t, "accorder-serve-old", "bucket")
	activateReclaim(t)

	rel, ok, err := acquireMutationLock("accorder-serve-old", "bucket")
	if err != nil || !ok {
		t.Fatalf("test lock: %v", err)
	}
	defer rel()

	if err := (&AliasRenameCmd{OldName: "old", NewName: "new"}).Run(); err != nil {
		t.Fatal(err)
	}
	if !aliasExists("new") || aliasExists("old") {
		t.Fatal("config rename did not commit despite contended identity")
	}
	if !treeExists("vfs", "accorder-serve-old") || treeExists("vfs", "accorder-serve-new") {
		t.Fatal("contended identity was migrated")
	}
}

func TestRename_AmbiguousIdentitySkipped(t *testing.T) {
	testSetup(t)

	// accorder-serve-old reverse-parses to "old" AND "serve-old"; the
	// latter existing makes the tree possibly shared — never moved.
	seedAliasNames(t, "old", "serve-old")
	seedTreePair(t, "accorder-serve-old")
	ledgerServeStart(t, "accorder-serve-old", "bucket")
	activateReclaim(t)

	if err := (&AliasRenameCmd{OldName: "old", NewName: "new"}).Run(); err != nil {
		t.Fatal(err)
	}
	if !aliasExists("new") || aliasExists("old") {
		t.Fatal("config rename did not commit")
	}
	if !treeExists("vfs", "accorder-serve-old") || treeExists("vfs", "accorder-serve-new") {
		t.Fatal("possibly-shared tree was migrated")
	}
}

func TestDelete_ReclaimsTreesRetainsJSONL(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "gone")
	seedTreePair(t, "accorder-serve-gone")
	seedTreePair(t, "accorder-serve-gone-assets")
	seedTreePair(t, "accorder-funnel-gone")
	seedTreePair(t, "accorder-funnel-gone-assets")
	for _, remote := range []string{
		"accorder-serve-gone", "accorder-serve-gone-assets",
		"accorder-funnel-gone", "accorder-funnel-gone-assets",
	} {
		ledgerServeStart(t, remote, "bucket")
	}
	activateReclaim(t)
	if err := os.WriteFile(filepath.Join(accorderCacheDir(), "gone.jsonl"), []byte("{}"), 0o644); err != nil {
		t.Fatal(err)
	}

	if err := (&AliasDeleteCmd{Name: "gone", Force: true}).Run(); err != nil {
		t.Fatal(err)
	}
	if aliasExists("gone") {
		t.Fatal("config delete did not commit")
	}
	for _, remote := range []string{
		"accorder-serve-gone", "accorder-serve-gone-assets",
		"accorder-funnel-gone", "accorder-funnel-gone-assets",
	} {
		if treeExists("vfs", remote) || treeExists("vfsMeta", remote) {
			t.Fatalf("tree pair %s not reclaimed", remote)
		}
	}
	if _, err := os.Stat(filepath.Join(accorderCacheDir(), "gone.jsonl")); err != nil {
		t.Fatal("jsonl deleted — it is retained data")
	}
	records, malformed, _ := readLedger()
	if malformed {
		t.Fatal("ledger malformed")
	}
	view := replayLedger(records)
	for _, remote := range []string{
		"accorder-serve-gone", "accorder-serve-gone-assets",
		"accorder-funnel-gone", "accorder-funnel-gone-assets",
	} {
		if len(view.activeRoots[remote]) != 0 {
			t.Fatalf("identity %s not tombstoned after delete", remote)
		}
	}
}

func TestDelete_PreActivationKeepsTrees(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "gone")
	seedTreePair(t, "accorder-serve-gone")
	ledgerServeStart(t, "accorder-serve-gone", "bucket")

	if err := (&AliasDeleteCmd{Name: "gone", Force: true}).Run(); err != nil {
		t.Fatal(err)
	}
	if aliasExists("gone") {
		t.Fatal("config delete did not commit")
	}
	if !treeExists("vfs", "accorder-serve-gone") {
		t.Fatal("tree reclaimed pre-activation")
	}
}

func TestRecovery_CompletesInterruptedMigrationForward(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "old")
	activateReclaim(t)

	// Crash state: vfs half moved, vfsMeta half not, config not yet saved.
	seedTreePair(t, "accorder-serve-old", "vfsMeta")
	seedTreePair(t, "accorder-serve-new", "vfs")
	intent := renameIntent{
		V: 1, OldAlias: "old", NewAlias: "new",
		Identities: []renameIdentity{{
			FromRemote: "accorder-serve-old", ToRemote: "accorder-serve-new",
			HasVFS: true, HasMeta: true, Roots: []string{"bucket"},
		}},
		TS: "2026-08-17T00:00:00Z",
	}
	data, _ := json.Marshal(intent)
	if err := writeFileDurable(renameIntentPath(), data, 0o600); err != nil {
		t.Fatal(err)
	}

	handled, err := reconcileRenameIntent()
	if err != nil || !handled {
		t.Fatalf("handled=%v err=%v", handled, err)
	}
	if !treeExists("vfs", "accorder-serve-new") || !treeExists("vfsMeta", "accorder-serve-new") {
		t.Fatal("migration not completed forward")
	}
	if treeExists("vfsMeta", "accorder-serve-old") {
		t.Fatal("old vfsMeta half left behind")
	}
	if !aliasExists("new") || aliasExists("old") {
		t.Fatal("config not reconciled to the new alias")
	}
	if _, err := os.Stat(renameIntentPath()); !os.IsNotExist(err) {
		t.Fatal("intent marker not removed")
	}
}

func TestRecovery_AmbiguousStateAborts(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "old")
	activateReclaim(t)

	// Both sides exist for the vfs half: matches no single journal step.
	seedTreePair(t, "accorder-serve-old")
	seedTreePair(t, "accorder-serve-new", "vfs")
	intent := renameIntent{
		V: 1, OldAlias: "old", NewAlias: "new",
		Identities: []renameIdentity{{
			FromRemote: "accorder-serve-old", ToRemote: "accorder-serve-new",
			HasVFS: true, HasMeta: true,
		}},
		TS: "2026-08-17T00:00:00Z",
	}
	data, _ := json.Marshal(intent)
	if err := writeFileDurable(renameIntentPath(), data, 0o600); err != nil {
		t.Fatal(err)
	}

	if _, err := reconcileRenameIntent(); err == nil {
		t.Fatal("ambiguous directory state did not abort recovery")
	}

	// Nothing moved, marker retained for manual resolution.
	if !treeExists("vfs", "accorder-serve-old") || !treeExists("vfs", "accorder-serve-new") {
		t.Fatal("recovery mutated an ambiguous state")
	}
	if _, err := os.Stat(renameIntentPath()); err != nil {
		t.Fatal("intent marker removed despite abort")
	}
}

func TestRecovery_CollisionAbortsBeforeTreeMutation(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "old", "new-assets")
	activateReclaim(t)

	// Crash state: the vfs half moved before the alias commit. Completing the
	// rename would make new's assets identity collide with new-assets' books
	// identity, so recovery must leave the remaining half and journal intact.
	seedTreePair(t, "accorder-serve-old", "vfsMeta")
	seedTreePair(t, "accorder-serve-new", "vfs")
	intent := renameIntent{
		V: 1, OldAlias: "old", NewAlias: "new",
		Identities: []renameIdentity{{
			FromRemote: "accorder-serve-old", ToRemote: "accorder-serve-new",
			HasVFS: true, HasMeta: true, Roots: []string{"bucket"},
		}},
		TS: "2026-08-31T00:00:00Z",
	}
	data, _ := json.Marshal(intent)
	if err := writeFileDurable(renameIntentPath(), data, 0o600); err != nil {
		t.Fatal(err)
	}

	if _, err := reconcileRenameIntent(); err == nil || !strings.Contains(err.Error(), "collides") {
		t.Fatalf("recovery error = %v, want collision refusal", err)
	}
	if !treeExists("vfsMeta", "accorder-serve-old") || treeExists("vfsMeta", "accorder-serve-new") {
		t.Fatal("recovery moved the remaining cache half before collision admission")
	}
	if !aliasExists("old") || !aliasExists("new-assets") || aliasExists("new") {
		t.Fatal("recovery collision refusal mutated the alias set")
	}
	if _, err := os.Stat(renameIntentPath()); err != nil {
		t.Fatal("recovery removed the intent marker despite collision refusal")
	}
}

func TestRecovery_MaliciousJournalRejected(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "old")
	activateReclaim(t)
	intent := renameIntent{
		V: 1, OldAlias: "old", NewAlias: "new",
		Identities: []renameIdentity{{
			FromRemote: "accorder-../../../etc", ToRemote: "accorder-serve-new",
			HasVFS: true, HasMeta: true,
		}},
		TS: "2026-08-17T00:00:00Z",
	}
	data, _ := json.Marshal(intent)
	if err := writeFileDurable(renameIntentPath(), data, 0o600); err != nil {
		t.Fatal(err)
	}
	if _, err := reconcileRenameIntent(); err == nil {
		t.Fatal("journal with path-escaping remote name accepted")
	}
}

// ── review-fix regression tests ──────────────────────────────────────

func TestRename_DestinationLockContendedSkips(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "old")
	seedTreePair(t, "accorder-serve-old")
	ledgerServeStart(t, "accorder-serve-old", "bucket")
	activateReclaim(t)

	// A live serve can hold the DESTINATION remote name before rclone
	// materializes its tree; the rename must not move a tree under it.
	rel, ok, err := acquireMutationLock("accorder-serve-new", "otherbucket")
	if err != nil || !ok {
		t.Fatalf("test lock: %v", err)
	}
	defer rel()

	if err := (&AliasRenameCmd{OldName: "old", NewName: "new"}).Run(); err != nil {
		t.Fatal(err)
	}
	if !aliasExists("new") || aliasExists("old") {
		t.Fatal("config rename did not commit")
	}
	if !treeExists("vfs", "accorder-serve-old") || treeExists("vfs", "accorder-serve-new") {
		t.Fatal("tree moved onto a remote name whose mutation lock a serve holds")
	}
}

func TestRenameDelete_TraversalNamesRejected(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "myalias")
	if err := os.MkdirAll(accorderCacheDir(), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(accorderCacheDir(), "myalias.jsonl"), []byte("{}"), 0o644); err != nil {
		t.Fatal(err)
	}
	before, _ := os.ReadFile(savedActionAliases)

	if err := (&AliasRenameCmd{OldName: "myalias", NewName: "../../../outside/evil"}).Run(); err == nil {
		t.Fatal("traversal rename accepted")
	}
	if err := (&AliasRenameCmd{OldName: "../../etc", NewName: "x"}).Run(); err == nil {
		t.Fatal("traversal source name accepted")
	}
	if _, err := reclaimDeletedAliasCache("../../etc"); err == nil {
		t.Fatal("traversal delete accepted")
	}
	after, _ := os.ReadFile(savedActionAliases)
	if string(before) != string(after) {
		t.Fatal("config mutated by rejected traversal name")
	}
	if _, err := os.Stat(filepath.Join(accorderCacheDir(), "myalias.jsonl")); err != nil {
		t.Fatal("jsonl moved by rejected traversal name")
	}
}

func TestRename_PendingMarkerBlocksMigration(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "old")
	seedTreePair(t, "accorder-serve-old")
	ledgerServeStart(t, "accorder-serve-old", "bucket")
	activateReclaim(t)
	// A crashed migration's journal is present: a new rename must not
	// overwrite it. Marker content is another rename's journal.
	if err := writeFileDurable(renameIntentPath(), []byte(`{"v":1,"oldAlias":"a","newAlias":"b","identities":[],"ts":"2026-01-01T00:00:00Z"}`), 0o600); err != nil {
		t.Fatal(err)
	}
	markerBefore, _ := os.ReadFile(renameIntentPath())

	if err := (&AliasRenameCmd{OldName: "old", NewName: "new"}).Run(); err != nil {
		t.Fatal(err)
	}
	if !aliasExists("new") || aliasExists("old") {
		t.Fatal("config rename did not commit")
	}
	if !treeExists("vfs", "accorder-serve-old") || treeExists("vfs", "accorder-serve-new") {
		t.Fatal("tree migrated while an unreconciled marker exists")
	}
	markerAfter, err := os.ReadFile(renameIntentPath())
	if err != nil || string(markerBefore) != string(markerAfter) {
		t.Fatal("pending marker overwritten or removed by a new rename")
	}
}

func TestRename_PreActivationLeavesJSONLAndNoMarker(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "old")
	if err := os.MkdirAll(accorderCacheDir(), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(accorderCacheDir(), "old.jsonl"), []byte("{}"), 0o644); err != nil {
		t.Fatal(err)
	}
	// no activation: NOTHING but the config may be mutated
	if err := (&AliasRenameCmd{OldName: "old", NewName: "new"}).Run(); err != nil {
		t.Fatal(err)
	}
	if !aliasExists("new") || aliasExists("old") {
		t.Fatal("config rename did not commit")
	}
	if _, err := os.Stat(filepath.Join(accorderCacheDir(), "old.jsonl")); err != nil {
		t.Fatal("jsonl moved pre-activation")
	}
	if _, err := os.Stat(renameIntentPath()); !os.IsNotExist(err) {
		t.Fatal("intent marker written pre-activation — only a post-activation prune could ever reconcile it")
	}
}

func TestRecovery_CompletesJSONLMove(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "old")
	activateReclaim(t)
	seedTreePair(t, "accorder-serve-old", "vfsMeta")
	seedTreePair(t, "accorder-serve-new", "vfs")
	if err := os.WriteFile(filepath.Join(accorderCacheDir(), "old.jsonl"), []byte("{}"), 0o644); err != nil {
		t.Fatal(err)
	}
	intent := renameIntent{
		V: 1, OldAlias: "old", NewAlias: "new",
		Identities: []renameIdentity{{
			FromRemote: "accorder-serve-old", ToRemote: "accorder-serve-new",
			HasVFS: true, HasMeta: true, Roots: []string{"bucket"},
		}},
		JSONLFrom: filepath.Join(accorderCacheDir(), "old.jsonl"),
		JSONLTo:   filepath.Join(accorderCacheDir(), "new.jsonl"),
		TS:        "2026-08-17T00:00:00Z",
	}
	data, _ := json.Marshal(intent)
	if err := writeFileDurable(renameIntentPath(), data, 0o600); err != nil {
		t.Fatal(err)
	}
	handled, err := reconcileRenameIntent()
	if err != nil || !handled {
		t.Fatalf("handled=%v err=%v", handled, err)
	}
	if _, err := os.Stat(filepath.Join(accorderCacheDir(), "new.jsonl")); err != nil {
		t.Fatal("journaled jsonl move not completed by recovery")
	}
	if _, err := os.Stat(filepath.Join(accorderCacheDir(), "old.jsonl")); !os.IsNotExist(err) {
		t.Fatal("old jsonl still present after recovery")
	}
}
