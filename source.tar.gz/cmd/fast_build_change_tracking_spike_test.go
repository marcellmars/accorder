package cmd

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"reflect"
	"runtime"
	"sort"
	"strings"
	"testing"
	"time"

	"accorder/pkg/calibre"
	"accorder/pkg/libraryflow"
	"accorder/pkg/rclonexfer"
)

func TestSpikeConservativePayloadSupersetThroughCurrentConsumer(t *testing.T) {
	libraryUUID := "00000000-0000-4000-8000-000000000902"
	unchanged := spikeBook("00000000-0000-4000-8000-000000000911", libraryUUID, "Untouched/Control (1)", "untouched")
	timestampOnly := spikeBook("00000000-0000-4000-8000-000000000912", libraryUUID, "Timestamp/Only (2)", "timestamp")
	sameSize := spikeBook("00000000-0000-4000-8000-000000000913", libraryUUID, "Rewrite/Same Size (3)", "rewrite")
	movedOld := spikeBook("00000000-0000-4000-8000-000000000914", libraryUUID, "Old Parent/Moved (4)", "moved")
	deleted := spikeBook("00000000-0000-4000-8000-000000000915", libraryUUID, "Deleted/Book (5)", "deleted")
	oldBooks := []*calibre.Book{unchanged, timestampOnly, sameSize, movedOld, deleted}

	movedNew := spikeCloneBook(movedOld)
	movedNew.Formats[0].DirectoryPath = "New Parent/Moved (4)"
	movedNew.CoverUrl = "New Parent/Moved (4)/cover.jpg"
	added := spikeBook("00000000-0000-4000-8000-000000000916", libraryUUID, "Added/Book (6)", "added")
	newBooks := []*calibre.Book{
		spikeCloneBook(unchanged), spikeCloneBook(timestampOnly), spikeCloneBook(sameSize), movedNew, added,
	}

	previous := make(map[string]calibre.CatalogRecordInfo, len(oldBooks))
	for _, book := range oldBooks {
		info, err := calibre.CatalogRecordInfoForBook(book)
		if err != nil {
			t.Fatal(err)
		}
		previous[book.Id] = info
	}
	diff, err := calibre.CompileCatalogDiffFromRecordInfos(newBooks, previous)
	if err != nil {
		t.Fatal(err)
	}
	oldToken := generationChangeMemberToken(40)
	newToken := generationChangeMemberToken(41)
	oldGeneration := hex.EncodeToString(oldToken)
	ledger := spikeCatalogLedger(newBooks)
	changedCurrent := []string{
		timestampOnly.Formats[0].DirectoryPath + "/" + timestampOnly.Formats[0].Name,
		sameSize.Formats[0].DirectoryPath + "/" + sameSize.Formats[0].Name,
		movedNew.Formats[0].DirectoryPath + "/" + movedNew.Formats[0].Name,
		added.Formats[0].DirectoryPath + "/" + added.Formats[0].Name,
	}
	removed := []string{
		movedOld.Formats[0].DirectoryPath + "/" + movedOld.Formats[0].Name,
		deleted.Formats[0].DirectoryPath + "/" + deleted.Formats[0].Name,
	}
	baseline := &libraryBaseline{
		GenerationToken: oldGeneration, CatalogChecksum: diff.FromChecksum,
		ContentLedgerVersion: 1,
	}
	candidateChange := compileLocalChangeCandidate(
		libraryUUID, oldGeneration, strings.Repeat("a", 64), diff, ledger,
		changedCurrent, removed, baseline,
	)
	if candidateChange.Scope != calibre.GenerationChangeScopeExact {
		t.Fatalf("compiler downgraded conservative selection: scope=%s reason=%s", candidateChange.Scope, candidateChange.Reason)
	}

	wantKinds := map[string]string{
		timestampOnly.Id: "edited",
		sameSize.Id:      "edited",
		movedOld.Id:      "edited",
		deleted.Id:       "deleted",
		added.Id:         "added",
	}
	if len(candidateChange.Changes) != len(wantKinds) {
		t.Fatalf("changes=%+v, want exactly %d touched IDs", candidateChange.Changes, len(wantKinds))
	}
	for _, change := range candidateChange.Changes {
		if wantKinds[change.ID] != change.Kind {
			t.Errorf("change %s kind=%q, want %q", change.ID, change.Kind, wantKinds[change.ID])
		}
		if change.ID == unchanged.Id {
			t.Fatal("untouched control entered changed-ID superset")
		}
		if change.ID == timestampOnly.Id || change.ID == sameSize.Id {
			if change.OldRecordDigest != change.NewRecordDigest || !change.PayloadChanged {
				t.Errorf("payload-only change is not represented conservatively: %+v", change)
			}
		}
	}

	oldDir := t.TempDir()
	oldEndpointToken, oldPointer := spikeWriteEndpoint(t, oldDir, oldBooks, 40)
	if !bytes.Equal(oldEndpointToken, oldToken) {
		t.Fatal("old endpoint token mismatch")
	}
	writeCachedMemberCommit(t, oldDir, oldToken, oldPointer)
	newDir := t.TempDir()
	newEndpointToken, newPointer := spikeWriteEndpoint(t, newDir, newBooks, 41)
	if !bytes.Equal(newEndpointToken, newToken) {
		t.Fatal("new endpoint token mismatch")
	}

	local := &libraryCandidate{
		SourceFingerprint: strings.Repeat("a", 64),
		Change:            &candidateChange,
	}
	initial := remoteLibrarySnapshot{
		Pointer: oldPointer, PointerRaw: []byte("non-empty"), GenerationRaw: oldToken,
		Generation: 40, SourceFingerprint: strings.Repeat("a", 64), Committed: true,
	}
	bound, err := bindGenerationPublication(initial, newPointer, local, newToken, strings.Repeat("a", 64))
	if err != nil {
		t.Fatal(err)
	}
	if bound.Scope != calibre.GenerationChangeScopeExact {
		t.Fatalf("binding scope=%s reason=%s", bound.Scope, bound.Reason)
	}
	manifest, err := calibre.DecodeGenerationChangeManifest(bound.ManifestBytes, calibre.GenerationChangeLimits{})
	if err != nil {
		t.Fatalf("decode bound manifest: %v", err)
	}
	if len(manifest.Changes) != len(wantKinds) {
		t.Fatalf("bound manifest lost selected IDs: %+v", manifest.Changes)
	}

	bucket := t.TempDir()
	prefix := "member"
	manifestPath := filepath.Join(bucket, prefix, filepath.FromSlash(bound.ManifestPath))
	if err := os.MkdirAll(filepath.Dir(manifestPath), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(manifestPath, bound.ManifestBytes, 0o644); err != nil {
		t.Fatal(err)
	}
	rclonexfer.Initialize()
	defer rclonexfer.Finalize()
	target, err := decodeAggregateGenerationToken(newToken)
	if err != nil {
		t.Fatal(err)
	}
	result := deriveMemberChangeResult(bucket, oldDir, newDir, prefix, libraryUUID, observedMemberTransition{
		LibraryUUID: libraryUUID, PreviousGeneration: oldGeneration,
		ObservedGeneration: hex.EncodeToString(newToken),
	}, target, newPointer)
	if result.Scope != calibre.GenerationChangeScopeExact || result.Reason != "" {
		t.Fatalf("consumer rejected conservative manifest: %+v", result)
	}
	wantDirectories := []string{
		"member/Added", "member/Added/Book (6)",
		"member/Deleted", "member/Deleted/Book (5)",
		"member/New Parent", "member/New Parent/Moved (4)",
		"member/Old Parent", "member/Old Parent/Moved (4)",
		"member/Rewrite", "member/Rewrite/Same Size (3)",
		"member/Timestamp", "member/Timestamp/Only (2)",
	}
	if !reflect.DeepEqual(result.BooksDirectories, wantDirectories) {
		t.Errorf("book directories=%v, want endpoint and parent scopes %v", result.BooksDirectories, wantDirectories)
	}
	wantAssets := append(append([]string(nil), wantDirectories...), "member/static")
	sort.Strings(wantAssets)
	if !reflect.DeepEqual(result.AssetsDirectories, wantAssets) {
		t.Errorf("asset directories=%v, want %v", result.AssetsDirectories, wantAssets)
	}
	for _, directory := range append(result.BooksDirectories, result.AssetsDirectories...) {
		if strings.Contains(directory, "Untouched") {
			t.Errorf("untouched book leaked into cache scope: %s", directory)
		}
	}
	t.Logf("exact manifest accepted %d conservative IDs and derived %d book/%d asset directories without the untouched scope", len(manifest.Changes), len(result.BooksDirectories), len(result.AssetsDirectories))
}

func TestSpikeStatInventoryAgainstByteOracle(t *testing.T) {
	root := t.TempDir()
	path := filepath.Join(root, "Author", "Book (1)", "book.epub")
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		t.Fatal(err)
	}
	stamp := time.Unix(1_700_000_000, 123_000_000)
	write := func(data string) {
		t.Helper()
		if err := os.WriteFile(path, []byte(data), 0o644); err != nil {
			t.Fatal(err)
		}
		if err := os.Chtimes(path, stamp, stamp); err != nil {
			t.Fatal(err)
		}
	}
	capture := func() (libraryflow.Object, [sha256.Size]byte, os.FileInfo) {
		t.Helper()
		info, err := os.Stat(path)
		if err != nil {
			t.Fatal(err)
		}
		data, err := os.ReadFile(path)
		if err != nil {
			t.Fatal(err)
		}
		object := libraryflow.NewLocalObjectAt("Author/Book (1)/book.epub", path, info)
		digest := sha256.Sum256(data)
		object.Hash = hex.EncodeToString(digest[:])
		return object, digest, info
	}

	write("old!")
	before, beforeDigest, beforeInfo := capture()
	if before.ChangeTime <= 0 {
		t.Fatalf("%s filesystem exposes no nonzero change timestamp", runtime.GOOS)
	}
	unchanged, unchangedDigest, _ := capture()
	if !canReuseContentDigest(unchanged, before) || unchangedDigest != beforeDigest {
		t.Fatal("unchanged control was not reusable")
	}

	t.Run("same-size restored-mtime rewrite", func(t *testing.T) {
		time.Sleep(5 * time.Millisecond)
		write("new!")
		after, digest, _ := capture()
		if digest == beforeDigest {
			t.Fatal("byte oracle did not observe rewrite")
		}
		if after.Size != before.Size || !after.ModTime.Equal(before.ModTime) {
			t.Fatalf("fixture failed to preserve size/mtime: before=%+v after=%+v", before, after)
		}
		if after.ChangeTime == before.ChangeTime || canReuseContentDigest(after, before) {
			t.Fatalf("metadata detector missed ordinary rewrite: before=%+v after=%+v", before, after)
		}
	})

	write("base")
	atomicBefore, atomicDigest, atomicBeforeInfo := capture()
	t.Run("atomic replacement", func(t *testing.T) {
		replacement := filepath.Join(root, "replacement.epub")
		if err := os.WriteFile(replacement, []byte("swap"), 0o644); err != nil {
			t.Fatal(err)
		}
		if err := os.Chtimes(replacement, stamp, stamp); err != nil {
			t.Fatal(err)
		}
		time.Sleep(5 * time.Millisecond)
		if err := os.Rename(replacement, path); err != nil {
			t.Fatal(err)
		}
		after, digest, afterInfo := capture()
		if digest == atomicDigest || canReuseContentDigest(after, atomicBefore) {
			t.Fatalf("metadata detector missed atomic replacement: before=%+v after=%+v", atomicBefore, after)
		}
		beforeIdentity, afterIdentity := spikeNativeFileIdentity(atomicBeforeInfo), spikeNativeFileIdentity(afterInfo)
		if beforeIdentity != "" && afterIdentity != "" && beforeIdentity == afterIdentity {
			t.Fatalf("atomic replacement retained native file identity %q", beforeIdentity)
		}
		t.Logf("atomic replacement native identity: %q -> %q", beforeIdentity, afterIdentity)
	})

	write("time")
	timestampBefore, timestampDigest, _ := capture()
	t.Run("timestamp-only edit is conservative", func(t *testing.T) {
		later := stamp.Add(time.Hour)
		if err := os.Chtimes(path, later, later); err != nil {
			t.Fatal(err)
		}
		after, digest, _ := capture()
		if digest != timestampDigest {
			t.Fatal("timestamp-only fixture unexpectedly changed bytes")
		}
		if canReuseContentDigest(after, timestampBefore) {
			t.Fatal("metadata detector failed to conservatively select timestamp-only edit")
		}
	})

	write("zero")
	zeroBefore, zeroDigest, _ := capture()
	t.Run("missing and zero indicators fail closed", func(t *testing.T) {
		zero := zeroBefore
		zero.Hash = ""
		zero.ChangeTime = 0
		if canReuseContentDigest(zero, zeroBefore) {
			t.Fatal("zero change indicator was trusted")
		}
		ledger, changed, removed, err := buildContentLedger(root, nil, nil, []libraryflow.Object{zeroBefore})
		if err != nil {
			t.Fatal(err)
		}
		if len(ledger) != 0 || len(changed) != 0 || len(removed) != 1 || removed[0] != zeroBefore.Path {
			t.Fatalf("missing file result ledger=%v changed=%v removed=%v", ledger, changed, removed)
		}
		if zeroDigest == ([sha256.Size]byte{}) {
			t.Fatal("invalid byte-oracle control")
		}
	})

	write("copy")
	copyBefore, copyDigest, _ := capture()
	t.Run("copied state and root invalidate reuse", func(t *testing.T) {
		copiedRoot := t.TempDir()
		copiedPath := filepath.Join(copiedRoot, "Author", "Book (1)", "book.epub")
		if err := os.MkdirAll(filepath.Dir(copiedPath), 0o755); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(copiedPath, []byte("copy"), 0o644); err != nil {
			t.Fatal(err)
		}
		if err := os.Chtimes(copiedPath, copyBefore.ModTime, copyBefore.ModTime); err != nil {
			t.Fatal(err)
		}
		info, err := os.Stat(copiedPath)
		if err != nil {
			t.Fatal(err)
		}
		copied := libraryflow.NewLocalObjectAt(copyBefore.Path, copiedPath, info)
		data, err := os.ReadFile(copiedPath)
		if err != nil {
			t.Fatal(err)
		}
		if sha256.Sum256(data) != copyDigest {
			t.Fatal("copied-root oracle differs")
		}
		if copied.ChangeTime == copyBefore.ChangeTime {
			t.Fatalf("copied root collided on change timestamp %d; provenance must reject copied state independently", copied.ChangeTime)
		}
		if canReuseContentDigest(copied, copyBefore) {
			t.Fatal("copied state/root was treated as same-root reusable evidence")
		}
	})

	write("left")
	collisionBefore, collisionDigest, collisionInfo := capture()
	t.Run("simulated timestamp collision exposes boundary", func(t *testing.T) {
		if err := os.WriteFile(path, []byte("rite"), 0o644); err != nil {
			t.Fatal(err)
		}
		actual, err := os.ReadFile(path)
		if err != nil {
			t.Fatal(err)
		}
		if sha256.Sum256(actual) == collisionDigest {
			t.Fatal("byte oracle did not observe collision fixture rewrite")
		}
		forgedCurrent := collisionBefore
		forgedCurrent.Hash = ""
		if !canReuseContentDigest(forgedCurrent, collisionBefore) {
			t.Fatal("simulated equal size/mtime/change-time tuple did not exercise collision")
		}
		actualInfo, err := os.Stat(path)
		if err != nil {
			t.Fatal(err)
		}
		if spikeNativeFileIdentity(collisionInfo) != spikeNativeFileIdentity(actualInfo) {
			t.Fatal("in-place rewrite unexpectedly changed native file identity")
		}
		t.Log("byte oracle catches a forged all-timestamp collision that metadata-only reuse cannot; file identity does not distinguish an in-place rewrite")
	})

	_ = beforeInfo
}

func TestSpikeV1MigrationAdapterRetainsTransferCoverage(t *testing.T) {
	root := t.TempDir()
	payloadRel := "Author/Book (1)/book.epub"
	payloadPath := filepath.Join(root, filepath.FromSlash(payloadRel))
	if err := os.MkdirAll(filepath.Dir(payloadPath), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(payloadPath, []byte("same"), 0o644); err != nil {
		t.Fatal(err)
	}
	info, err := os.Stat(payloadPath)
	if err != nil {
		t.Fatal(err)
	}
	legacyObject := libraryflow.NewLocalObjectAt(payloadRel, payloadPath, info)
	legacyObject.Hash = spikeSHA256("same")
	if legacyObject.ChangeTime == 0 {
		t.Fatalf("v1 migration fixture has no change timestamp on %s", runtime.GOOS)
	}

	t.Run("completed v1 baseline imports without unchanged byte reads", func(t *testing.T) {
		fixture := libraryBaseline{
			Version: machineStateVersion, LibraryID: "00000000-0000-4000-8000-000000000902",
			RemoteSourceFingerprint: strings.Repeat("a", 64), LocalSourceFingerprint: strings.Repeat("a", 64),
			Generation: 7, GenerationToken: hex.EncodeToString(generationChangeMemberToken(7)),
			CatalogChecksum: strings.Repeat("b", 64), ContentLedgerVersion: 1,
			ContentLedger: []libraryflow.Object{legacyObject}, UpdatedAt: time.Now().UTC(),
		}
		raw, err := json.Marshal(fixture)
		if err != nil {
			t.Fatal(err)
		}
		migrated, err := spikeImportBaselineV1(raw)
		if err != nil {
			t.Fatal(err)
		}
		if migrated.Kind != "completed-v1" || migrated.GenerationToken != fixture.GenerationToken || len(migrated.Inventory) != 1 {
			t.Fatalf("migrated baseline=%+v", migrated)
		}

		originalHasher := contentLedgerHashFile
		t.Cleanup(func() { contentLedgerHashFile = originalHasher })
		contentLedgerHashFile = func(path string, _ func(int64)) (string, error) {
			return "", fmt.Errorf("unchanged format was read: %s", path)
		}
		current := libraryflow.NewLocalObjectAt(payloadRel, payloadPath, info)
		ledger, changed, removed, err := buildContentLedger(root, []libraryflow.Object{current}, nil, migrated.Inventory)
		if err != nil {
			t.Fatal(err)
		}
		if len(changed) != 0 || len(removed) != 0 || ledger[0].Hash != legacyObject.Hash {
			t.Fatalf("unchanged v1 import ledger=%+v changed=%v removed=%v", ledger, changed, removed)
		}
	})

	libraryUUID := "00000000-0000-4000-8000-000000000902"
	bookA := spikeBook("00000000-0000-4000-8000-000000000921", libraryUUID, "Author/Book (1)", "A")
	bookB := spikeCloneBook(bookA)
	bookB.Title, bookB.TitleSort = "B", "B"
	bookC := spikeCloneBook(bookB)
	bookC.Title, bookC.TitleSort = "C", "C"
	infoA, err := calibre.CatalogRecordInfoForBook(bookA)
	if err != nil {
		t.Fatal(err)
	}
	diffAB, err := calibre.CompileCatalogDiffFromRecordInfos([]*calibre.Book{bookB}, map[string]calibre.CatalogRecordInfo{bookA.Id: infoA})
	if err != nil {
		t.Fatal(err)
	}
	infoB, err := calibre.CatalogRecordInfoForBook(bookB)
	if err != nil {
		t.Fatal(err)
	}
	diffBC, err := calibre.CompileCatalogDiffFromRecordInfos([]*calibre.Book{bookC}, map[string]calibre.CatalogRecordInfo{bookB.Id: infoB})
	if err != nil {
		t.Fatal(err)
	}
	genA := hex.EncodeToString(generationChangeMemberToken(10))
	prior := spikeCandidateFromDiff(diffAB, libraryUUID, genA, legacyObject)
	prior.ForcePaths = []string{payloadRel}
	delta := spikeCandidateFromDiff(diffBC, libraryUUID, genA, legacyObject)
	delta.FromGeneration = genA
	delta.ForcePaths = []string{payloadRel}
	composed, err := composeLocalBuildCandidate(prior, delta)
	if err != nil {
		t.Fatal(err)
	}

	t.Run("unpublished A-B-C v1 candidate preserves remote-relative binding", func(t *testing.T) {
		raw, err := json.Marshal(composed)
		if err != nil {
			t.Fatal(err)
		}
		migrated, err := spikeImportCandidateV1(raw)
		if err != nil {
			t.Fatal(err)
		}
		if migrated.Kind != "unpublished-v1" || migrated.FromGeneration != genA || !reflect.DeepEqual(migrated.ForcePaths, []string{payloadRel}) {
			t.Fatalf("migrated pending candidate=%+v", migrated)
		}
		if len(composed.Changes) != 1 || composed.Changes[0].OldRecordDigest != diffAB.Changes[0].OldRecordDigest || composed.Changes[0].NewRecordDigest != diffBC.Changes[0].NewRecordDigest {
			t.Fatalf("A-B-C transition was not retained: %+v", composed.Changes)
		}

		oldPointer := calibre.PointerFile{
			Library:         calibre.PointerFileLibrary{UUID: libraryUUID},
			Index:           calibre.PointerFileIndex{NumBooks: diffAB.FromCount},
			CatalogChecksum: diffAB.FromChecksum, SourceFingerprint: strings.Repeat("a", 64),
		}
		newPointer := calibre.PointerFile{
			Library:         calibre.PointerFileLibrary{UUID: libraryUUID},
			Index:           calibre.PointerFileIndex{NumBooks: diffBC.ToCount},
			CatalogChecksum: diffBC.ToChecksum, SourceFingerprint: strings.Repeat("c", 64),
		}
		local := &libraryCandidate{SourceFingerprint: strings.Repeat("c", 64), Change: &composed}
		initial := remoteLibrarySnapshot{
			Pointer: oldPointer, PointerRaw: []byte("non-empty"), GenerationRaw: generationChangeMemberToken(10),
			Generation: 10, SourceFingerprint: strings.Repeat("a", 64), Committed: true,
		}
		bound, err := bindGenerationPublication(initial, newPointer, local, generationChangeMemberToken(12), strings.Repeat("a", 64))
		if err != nil {
			t.Fatal(err)
		}
		if bound.Scope != calibre.GenerationChangeScopeExact || bound.CompleteOverwrite || !reflect.DeepEqual(bound.ForcePaths, []string{payloadRel}) {
			t.Fatalf("bound migrated A-C publication=%+v", bound)
		}
		decoded, err := calibre.DecodeGenerationChangeManifest(bound.ManifestBytes, calibre.GenerationChangeLimits{})
		if err != nil {
			t.Fatal(err)
		}
		if decoded.FromGeneration != genA || len(decoded.Changes) != 1 {
			t.Fatalf("bound manifest=%+v", decoded)
		}
	})

	t.Run("legacy cutoff selects only post-cutoff paths", func(t *testing.T) {
		cutoff := time.Now().UTC().Add(-time.Hour)
		legacy := &libraryBaseline{
			Version: machineStateVersion, LibraryID: libraryUUID,
			RemoteSourceFingerprint: strings.Repeat("a", 64), LocalSourceFingerprint: strings.Repeat("a", 64),
			Generation: 10, ContentLedgerVersion: 0, UpdatedAt: cutoff,
		}
		inventory := []libraryflow.Object{
			{Path: "Old/Book (1)/old.epub", Size: 4, ModTime: cutoff.Add(-time.Minute), ChangeTime: cutoff.Add(-time.Minute).UnixNano(), Hash: spikeSHA256("old!")},
			{Path: "New/Book (2)/new.epub", Size: 4, ModTime: cutoff.Add(time.Minute), ChangeTime: cutoff.Add(time.Minute).UnixNano(), Hash: spikeSHA256("new!")},
		}
		forced, ok := legacyBaselineUpgradeChanges(legacy, genA, inventory)
		if !ok || !reflect.DeepEqual(forced, []string{"New/Book (2)/new.epub"}) {
			t.Fatalf("legacy cutoff forced=%v ok=%t", forced, ok)
		}
		inventory[0].ChangeTime = 0
		if _, ok := legacyBaselineUpgradeChanges(legacy, genA, inventory); ok {
			t.Fatal("legacy cutoff accepted an inventory with unknown change evidence")
		}
	})

	t.Run("interrupted v1 recovery remains an explicit resume", func(t *testing.T) {
		record := publishRecoveryRecord{
			Version: machineStateVersion, Alias: "alice", LibraryID: libraryUUID,
			SourceFingerprint: strings.Repeat("c", 64), Generation: 12,
			GenerationToken: hex.EncodeToString(generationChangeMemberToken(12)),
			CatalogChecksum: diffBC.ToChecksum, Stage: "payload-complete",
			ManifestPath: ".accorder/changes/resume.manifest.json", Manifest: []byte("manifest"), Pointer: []byte("pointer"),
			PreviousGenerationToken: genA, ContentLedgerVersion: 1, ContentLedger: []libraryflow.Object{legacyObject},
		}
		raw, err := json.Marshal(record)
		if err != nil {
			t.Fatal(err)
		}
		migrated, err := spikeImportRecoveryV1(raw)
		if err != nil {
			t.Fatal(err)
		}
		if migrated.Kind != "interrupted-v1" || migrated.ResumeStage != "payload-complete" || migrated.UnknownEquivalence || migrated.GenerationToken != record.GenerationToken {
			t.Fatalf("migrated recovery=%+v", migrated)
		}
	})

	t.Run("unknown non-empty remote never becomes no-op", func(t *testing.T) {
		unknown := spikeMigrationState{Kind: "unknown-non-empty", UnknownEquivalence: true, CompleteOverwrite: true}
		if !unknown.UnknownEquivalence || !unknown.CompleteOverwrite {
			t.Fatalf("unknown state was silently blessed: %+v", unknown)
		}
		bound, err := bindGenerationPublication(
			remoteLibrarySnapshot{PointerRaw: []byte("non-empty"), Committed: true},
			calibre.PointerFile{CatalogChecksum: diffBC.ToChecksum},
			&libraryCandidate{SourceFingerprint: strings.Repeat("c", 64)},
			generationChangeMemberToken(12), "",
		)
		if err != nil {
			t.Fatal(err)
		}
		if bound.Scope != calibre.GenerationChangeScopeCoarse || !bound.CompleteOverwrite || bound.Reason != "missing-build-candidate" {
			t.Fatalf("unknown non-empty binding=%+v", bound)
		}
	})

	t.Run("remote advance invalidates exact binding", func(t *testing.T) {
		advanced := remoteLibrarySnapshot{
			Pointer:    calibre.PointerFile{Index: calibre.PointerFileIndex{NumBooks: diffAB.ToCount}, CatalogChecksum: diffAB.ToChecksum},
			PointerRaw: []byte("non-empty"), GenerationRaw: generationChangeMemberToken(11), Generation: 11,
			SourceFingerprint: strings.Repeat("d", 64), Committed: true,
		}
		pointer := calibre.PointerFile{
			Library: calibre.PointerFileLibrary{UUID: libraryUUID}, Index: calibre.PointerFileIndex{NumBooks: diffBC.ToCount},
			CatalogChecksum: diffBC.ToChecksum,
		}
		bound, err := bindGenerationPublication(advanced, pointer, &libraryCandidate{SourceFingerprint: strings.Repeat("c", 64), Change: &composed}, generationChangeMemberToken(12), strings.Repeat("a", 64))
		if err != nil {
			t.Fatal(err)
		}
		if bound.Scope != calibre.GenerationChangeScopeCoarse || !bound.CompleteOverwrite || bound.Reason != "remote-predecessor-mismatch" {
			t.Fatalf("remote advance binding=%+v", bound)
		}
	})

	t.Run("forced copy replaces same-size remote bytes with readback", func(t *testing.T) {
		localRoot := t.TempDir()
		remoteRoot := t.TempDir()
		localPayload := filepath.Join(localRoot, filepath.FromSlash(payloadRel))
		remotePayload := filepath.Join(remoteRoot, filepath.FromSlash(payloadRel))
		for _, name := range []string{localPayload, remotePayload, filepath.Join(localRoot, "static", "library_index.zst")} {
			if err := os.MkdirAll(filepath.Dir(name), 0o755); err != nil {
				t.Fatal(err)
			}
		}
		if err := os.WriteFile(localPayload, []byte("NEW!"), 0o644); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(remotePayload, []byte("OLD!"), 0o644); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(filepath.Join(localRoot, "static", "library_index.zst"), []byte("index"), 0o644); err != nil {
			t.Fatal(err)
		}
		candidate := &libraryCandidate{Root: localRoot, Change: &localChangeCandidate{
			ForcePaths: []string{payloadRel}, IndexArtifact: libraryflow.Object{Path: "static/library_index.zst"},
		}}
		rclonexfer.Initialize()
		defer rclonexfer.Finalize()
		remote := &libraryRemote{fsPath: remoteRoot}
		if err := executeTransferCorrectness(candidate, remote, boundGenerationPublication{ForcePaths: []string{payloadRel}}, nil); err != nil {
			t.Fatal(err)
		}
		got, err := os.ReadFile(remotePayload)
		if err != nil {
			t.Fatal(err)
		}
		if string(got) != "NEW!" {
			t.Fatalf("same-size remote replacement readback=%q", got)
		}
	})
}

type spikeMigrationState struct {
	Kind               string
	GenerationToken    string
	FromGeneration     string
	Inventory          []libraryflow.Object
	ForcePaths         []string
	ResumeStage        string
	UnknownEquivalence bool
	CompleteOverwrite  bool
}

func spikeImportBaselineV1(raw []byte) (spikeMigrationState, error) {
	var baseline libraryBaseline
	if err := spikeDecodeStrict(raw, &baseline); err != nil {
		return spikeMigrationState{}, err
	}
	if baseline.Version != machineStateVersion || baseline.ContentLedgerVersion != 1 || len(baseline.ContentLedger) == 0 {
		return spikeMigrationState{}, errors.New("not a completed v1 baseline")
	}
	if err := validateSourceContentLedger(baseline.ContentLedger); err != nil {
		return spikeMigrationState{}, err
	}
	return spikeMigrationState{Kind: "completed-v1", GenerationToken: baseline.GenerationToken, Inventory: append([]libraryflow.Object(nil), baseline.ContentLedger...)}, nil
}

func spikeImportCandidateV1(raw []byte) (spikeMigrationState, error) {
	var candidate localChangeCandidate
	if err := spikeDecodeStrict(raw, &candidate); err != nil {
		return spikeMigrationState{}, err
	}
	if err := candidate.validate(); err != nil {
		return spikeMigrationState{}, err
	}
	return spikeMigrationState{
		Kind: "unpublished-v1", FromGeneration: candidate.FromGeneration,
		Inventory:  append([]libraryflow.Object(nil), candidate.ContentLedger...),
		ForcePaths: append([]string(nil), candidate.ForcePaths...),
	}, nil
}

func spikeImportRecoveryV1(raw []byte) (spikeMigrationState, error) {
	var recovery publishRecoveryRecord
	if err := spikeDecodeStrict(raw, &recovery); err != nil {
		return spikeMigrationState{}, err
	}
	if recovery.Version != machineStateVersion || recovery.ContentLedgerVersion != 1 || recovery.Stage == "" {
		return spikeMigrationState{}, errors.New("not an interrupted v1 recovery")
	}
	if err := validateSourceContentLedger(recovery.ContentLedger); err != nil {
		return spikeMigrationState{}, err
	}
	return spikeMigrationState{
		Kind: "interrupted-v1", GenerationToken: recovery.GenerationToken,
		Inventory: append([]libraryflow.Object(nil), recovery.ContentLedger...), ResumeStage: recovery.Stage,
	}, nil
}

func spikeDecodeStrict(raw []byte, target any) error {
	decoder := json.NewDecoder(bytes.NewReader(raw))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(target); err != nil {
		return err
	}
	var trailing any
	if err := decoder.Decode(&trailing); !errors.Is(err, io.EOF) {
		if err == nil {
			return errors.New("multiple JSON values")
		}
		return err
	}
	return nil
}

func spikeCandidateFromDiff(diff calibre.CatalogDiff, libraryUUID, fromGeneration string, object libraryflow.Object) localChangeCandidate {
	return localChangeCandidate{
		Version: localChangeCandidateVersion, LibraryUUID: libraryUUID, Scope: calibre.GenerationChangeScopeExact,
		FromGeneration: fromGeneration, FromLiveCount: uint32ptr(diff.FromCount), FromCatalogChecksum: diff.FromChecksum,
		TargetSourceFingerprint: strings.Repeat("c", 64), ToLiveCount: diff.ToCount, ToCatalogChecksum: diff.ToChecksum,
		Changes:              append([]calibre.GenerationChange(nil), diff.Changes...),
		ContentLedgerVersion: 1, ContentLedger: []libraryflow.Object{object},
		IndexArtifact: libraryflow.Object{Path: "static/library_index.zst", Size: 5, Hash: spikeSHA256("index")},
	}
}

func spikeBook(id, libraryUUID, directory, title string) *calibre.Book {
	return &calibre.Book{
		Abstract: "", Authors: []string{"Author"}, LibraryUrl: "library",
		CoverUrl: filepath.ToSlash(filepath.Join(directory, "cover.jpg")),
		Formats:  []*calibre.File{{Format: "epub", DirectoryPath: directory, Name: "book.epub", Size: 4}},
		Id:       id, Identifiers: []*calibre.Identifier{}, Languages: []string{}, LastModified: "2026-09-03T00:00:00Z",
		Librarian: "member", LibraryUUID: libraryUUID, Pubdate: "", Publisher: "", Series: "", Tags: []string{},
		Title: title, TitleSort: title, CoverFingerprint: "fingerprint",
	}
}

func spikeCloneBook(book *calibre.Book) *calibre.Book {
	clone := *book
	clone.Authors = append([]string(nil), book.Authors...)
	clone.Identifiers = append([]*calibre.Identifier(nil), book.Identifiers...)
	clone.Languages = append([]string(nil), book.Languages...)
	clone.Tags = append([]string(nil), book.Tags...)
	clone.Formats = make([]*calibre.File, len(book.Formats))
	for i, format := range book.Formats {
		copy := *format
		clone.Formats[i] = &copy
	}
	return &clone
}

func spikeCatalogLedger(books []*calibre.Book) []libraryflow.Object {
	objects := []libraryflow.Object{{Path: "metadata.db", Size: 8, Hash: spikeSHA256("metadata")}}
	for _, book := range books {
		objects = append(objects,
			libraryflow.Object{Path: book.CoverUrl, Size: 4, Hash: spikeSHA256(book.Id + "cover")},
			libraryflow.Object{Path: filepath.ToSlash(filepath.Join(book.Formats[0].DirectoryPath, book.Formats[0].Name)), Size: 4, Hash: spikeSHA256(book.Id + "format")},
		)
	}
	sort.Slice(objects, func(i, j int) bool { return objects[i].Path < objects[j].Path })
	return objects
}

func spikeWriteEndpoint(t *testing.T, dir string, books []*calibre.Book, generation uint64) ([]byte, calibre.PointerFile) {
	t.Helper()
	jsonl := filepath.Join(dir, "books.jsonl")
	f, err := os.Create(jsonl)
	if err != nil {
		t.Fatal(err)
	}
	encoder := json.NewEncoder(f)
	for _, book := range books {
		if err := encoder.Encode(book); err != nil {
			_ = f.Close()
			t.Fatal(err)
		}
	}
	if err := f.Close(); err != nil {
		t.Fatal(err)
	}
	base := generationChangeBase()
	indexPath := filepath.Join(dir, "library_index")
	search := &calibre.MotwSearch{JsonlPath: jsonl, IndexPath: indexPath, BaseGeneration: &base, StartGeneration: generation}
	index, err := search.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := search.CompressToFile(index); err != nil {
		t.Fatal(err)
	}
	manifest, err := calibre.ReadExistingManifest(indexPath)
	if err != nil {
		t.Fatal(err)
	}
	if err := calibre.WritePointerFile(indexPath, manifest, calibre.PointerFileLibrary{UUID: books[0].LibraryUUID, Librarian: "member"}, true); err != nil {
		t.Fatal(err)
	}
	pointer, err := calibre.ReadPointerFile(indexPath + ".manifest.json")
	if err != nil {
		t.Fatal(err)
	}
	pointer, err = calibre.BindPointerCommit(pointer, strings.Repeat("a", 64), generation)
	if err != nil {
		t.Fatal(err)
	}
	checksum, err := calibre.CatalogChecksum(books)
	if err != nil {
		t.Fatal(err)
	}
	pointer.CatalogChecksum = hex.EncodeToString(checksum[:])
	return generationChangeMemberToken(generation), pointer
}

func spikeNativeFileIdentity(info os.FileInfo) string {
	value := reflect.ValueOf(info.Sys())
	if !value.IsValid() {
		return ""
	}
	if value.Kind() == reflect.Pointer {
		if value.IsNil() {
			return ""
		}
		value = value.Elem()
	}
	if value.Kind() != reflect.Struct {
		return ""
	}
	readUint := func(name string) (uint64, bool) {
		field := value.FieldByName(name)
		if !field.IsValid() {
			return 0, false
		}
		switch field.Kind() {
		case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
			return field.Uint(), true
		case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
			return uint64(field.Int()), true
		default:
			return 0, false
		}
	}
	if dev, ok := readUint("Dev"); ok {
		if ino, ok := readUint("Ino"); ok {
			return fmt.Sprintf("dev:%d:ino:%d", dev, ino)
		}
	}
	if volume, ok := readUint("VolumeSerialNumber"); ok {
		high, highOK := readUint("FileIndexHigh")
		low, lowOK := readUint("FileIndexLow")
		if highOK && lowOK {
			return fmt.Sprintf("volume:%d:file:%d", volume, high<<32|low)
		}
	}
	return ""
}

func spikeSHA256(value string) string {
	digest := sha256.Sum256([]byte(value))
	return hex.EncodeToString(digest[:])
}
