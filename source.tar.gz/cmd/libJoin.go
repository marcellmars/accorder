package cmd

import (
	"accorder/pkg/fedlibinvite"
	"accorder/pkg/secrets"
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/alecthomas/kong"
	"github.com/tidwall/gjson"
	"github.com/tidwall/sjson"
	"golang.org/x/term"
	"gopkg.in/ini.v1"
)

type LibJoinCmd struct {
	CommonCommandFields
	Invite         string `name:"invite" short:"I" help:"Invite blob from 'fedlib members invite' (or a share grant), or @<file> to read it from a file." json:"-" secret:"redact"`
	Passphrase     string `name:"passphrase" help:"Passphrase for the local secrets store (or set ACCORDER_SECRETS_PASSPHRASE)." env:"ACCORDER_SECRETS_PASSPHRASE" json:"-" secret:"redact"`
	CalibrePath    string `name:"calibrepath" short:"c" json:"calibrepath" sharedgroup:"lib" help:"Calibre library destination or existing source. Recovery creates it when absent." validate:"omitempty"`
	Endpoint       string `name:"endpoint" help:"(peer join) Public https URL where your library is served via 'lib share live'." validate:"omitempty,url" json:"-"`
	LibraryID      string `name:"libraryID" aliases:"library-id" help:"(peer join) Your library UUID; defaults to the alias's stored libraryID." json:"-"`
	Insecure       bool   `name:"insecure" help:"Accept http:// offer/invite URLs (no TLS). For trusted/test networks only — the claim and any grant token cross the wire in cleartext." json:"-"`
	DiscardPending bool   `name:"discard-pending" help:"Discard this alias's encrypted pending join after confirmation." json:"-"`
	Yes            bool   `name:"yes" help:"Confirm --discard-pending non-interactively." json:"-"`
}

// isOfferURL reports whether arg is an offer/invite URL lib join should claim over HTTP.
// https is always accepted; http only with --insecure (trusted/test networks).
func isOfferURL(arg string, insecure bool) bool {
	if strings.HasPrefix(arg, "https://") {
		return true
	}
	return insecure && strings.HasPrefix(arg, "http://")
}

func resolveInviteArg(arg string, insecure bool) (string, error) {
	if strings.HasPrefix(arg, "https://") {
		return claimInviteURL(arg)
	}
	if strings.HasPrefix(arg, "http://") {
		if insecure {
			return claimInviteURL(arg)
		}
		return "", fmt.Errorf("plain-HTTP claim refused — invite URLs must be https:// (pass --insecure to allow http on a trusted network) (got %q)", arg)
	}
	path, isFile := strings.CutPrefix(arg, "@")
	if !isFile {
		return arg, nil
	}
	data, err := os.ReadFile(path)
	if err != nil {
		return "", fmt.Errorf("read invite file: %w", err)
	}
	if blob, ok := scanForInviteBlob(string(data)); ok {
		return blob, nil
	}
	return "", fmt.Errorf("no invite blob found in %s (expected a line starting with %q)", path, fedlibinvite.WriteInvitePrefix)
}

func scanForInviteBlob(body string) (string, bool) {
	for _, line := range strings.Split(body, "\n") {
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, fedlibinvite.WriteInvitePrefix) {
			return line, true
		}
	}
	return "", false
}

// joinHTTPClient bounds offer-info GETs and claim POSTs with a timeout so an
// unresponsive or black-hole offer host can't hang `lib join` indefinitely.
var joinHTTPClient = &http.Client{Timeout: 30 * time.Second}

func claimInviteURL(rawURL string) (string, error) {
	claimURL := strings.TrimRight(rawURL, "/") + "/claim"
	resp, err := joinHTTPClient.Post(claimURL, "application/json", nil)
	if err != nil {
		return "", fmt.Errorf("claim invite: %w", err)
	}
	defer resp.Body.Close()
	body, err := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if err != nil {
		return "", fmt.Errorf("claim invite: read response: %w", err)
	}
	switch resp.StatusCode {
	case http.StatusOK:
	case http.StatusNotFound:
		return "", fmt.Errorf("claim invite: offer not found, already claimed, or expired — ask the operator to re-issue (%s)", rawURL)
	case http.StatusTooManyRequests:
		return "", fmt.Errorf("claim invite: rate limited by the serve — retry in a few seconds")
	default:
		return "", fmt.Errorf("claim invite: unexpected status %s from %s", resp.Status, claimURL)
	}

	var envelope struct {
		Version int    `json:"version"`
		Invite  string `json:"invite"`
	}
	if err := json.Unmarshal(body, &envelope); err == nil &&
		strings.HasPrefix(envelope.Invite, fedlibinvite.WriteInvitePrefix) {
		return envelope.Invite, nil
	}
	if blob, ok := scanForInviteBlob(string(body)); ok {
		return blob, nil
	}
	return "", fmt.Errorf("claim invite: response carries no invite blob (expected JSON envelope or a %q line)", fedlibinvite.WriteInvitePrefix)
}

// offerInfo is the machine-readable membership-offer descriptor returned by the
// serve daemon's /invite/<token> endpoint when queried with Accept: application/json.
type offerInfo struct {
	Kind        string `json:"kind"` // "peer" or "operator"
	Prefix      string `json:"prefix"`
	DisplayName string `json:"display_name"`
	FedlibID    string `json:"fedlib_id"` // peer offers only; keys the per-federation read-grant
}

// fetchOfferInfo does a non-burning GET of an offer URL to discover its kind, so
// lib join can branch to the peer flow without consuming a single-use operator offer.
func fetchOfferInfo(offerURL string) (*offerInfo, error) {
	req, err := http.NewRequest(http.MethodGet, offerURL, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Accept", "application/json")
	resp, err := joinHTTPClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("offer info: status %s", resp.Status)
	}
	body, err := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if err != nil {
		return nil, err
	}
	var info offerInfo
	if err := json.Unmarshal(body, &info); err != nil {
		return nil, err
	}
	return &info, nil
}

// runPeerJoin completes the librarian half of the peer handshake: mint a read-grant
// for the operator and POST {library_uuid, endpoint, grant_token} to the claim-callback.
// The grant is minted in the same registry the librarian's 'lib share live' for this
// alias serves from, so the operator's later authenticated fetch validates against it.
func (c *LibJoinCmd) runPeerJoin(offerURL string, info *offerInfo) error {
	if c.Endpoint == "" {
		return fmt.Errorf("lib join: peer membership offer requires --endpoint <your public https URL> (where your library is served via 'lib share live')")
	}

	libraryID := c.LibraryID
	if libraryID == "" {
		libraryID = gjson.GetBytes(loadActionAliases(), c.ActionAlias+".lib.build.libraryID").String()
	}
	if libraryID == "" {
		return fmt.Errorf("lib join: cannot determine your library UUID — pass --libraryID or set it on alias %q first", c.ActionAlias)
	}

	stateDir := filepath.Join(accorderConfigDir, "clearnet-lib", c.ActionAlias)
	reg, err := newGrantRegistry(stateDir)
	if err != nil {
		return fmt.Errorf("lib join: open grant registry: %w", err)
	}
	// Key the grant by federation so one library can belong to several federations at
	// once: each federation gets its own revocable grantee, and re-joining one rotates
	// only that federation's grant instead of clobbering every other membership. Older
	// operators that don't advertise a fedlib_id fall back to the legacy shared slot.
	grantee := "federation-operator"
	if info.FedlibID != "" {
		grantee = "fedop:" + info.FedlibID
	}
	// Rotate rather than accumulate: drop any prior grant for THIS federation before
	// minting a fresh one, so re-running lib join can't leave orphaned live tokens.
	_ = reg.revoke(grantee)
	token, err := reg.issue(grantee, nil)
	if err != nil {
		return fmt.Errorf("lib join: issue grant: %w", err)
	}

	payload, err := json.Marshal(peerClaimRequest{
		LibraryUUID: libraryID,
		Endpoint:    strings.TrimRight(c.Endpoint, "/"),
		GrantToken:  token,
	})
	if err != nil {
		return fmt.Errorf("lib join: encode claim: %w", err)
	}

	claimURL := strings.TrimRight(offerURL, "/") + "/claim"
	resp, err := joinHTTPClient.Post(claimURL, "application/json", bytes.NewReader(payload))
	if err != nil {
		return fmt.Errorf("lib join: claim peer offer: %w", err)
	}
	defer resp.Body.Close()
	respBody, _ := io.ReadAll(io.LimitReader(resp.Body, 1<<20))

	switch resp.StatusCode {
	case http.StatusCreated:
	case http.StatusConflict:
		return fmt.Errorf("lib join: already registered with this federation: %s", strings.TrimSpace(string(respBody)))
	case http.StatusNotFound:
		return fmt.Errorf("lib join: peer offer not found, already claimed, or expired — ask the operator to re-issue")
	case http.StatusTooManyRequests:
		return fmt.Errorf("lib join: rate limited by the serve — retry in a few seconds")
	default:
		return fmt.Errorf("lib join: claim peer offer: unexpected status %s: %s", resp.Status, strings.TrimSpace(string(respBody)))
	}

	fmt.Fprintf(os.Stderr, "lib join: joined federation as peer member (prefix: %s)\n", info.Prefix)
	fmt.Fprintf(os.Stderr, "  endpoint: %s\n", strings.TrimRight(c.Endpoint, "/"))
	fmt.Fprintf(os.Stderr, "  a read-grant was issued to the operator (friend %q)\n", grantee)
	fmt.Fprintf(os.Stderr, "  revoke it any time with 'lib share revoke-grant' to leave the federation\n")
	return nil
}

func (c *LibJoinCmd) Run(ctx *kong.Context) error {
	// LibJoinCmd embeds CommonCommandFields, so -s was already accepted and
	// advertised in --help; without this gate it was silently inert and the
	// join proceeded, consuming a single-use invite.
	if c.HandleShowConfig(c) {
		return nil
	}

	if c.DiscardPending {
		store, err := resolveJoinSecretsStore(c.Passphrase)
		if err != nil {
			return fmt.Errorf("lib join: %w", err)
		}
		if !c.Yes && !promptYesNo(fmt.Sprintf("Discard the pending join for alias %q?", c.ActionAlias)) {
			fmt.Fprintln(os.Stderr, "Cancelled.")
			return nil
		}
		release, err := acquireLibraryExecutionLock(c.ActionAlias)
		if err != nil {
			return fmt.Errorf("lib join: %w", err)
		}
		defer release()
		if err := store.Delete(pendingJoinKey(c.ActionAlias)); err != nil && !errors.Is(err, secrets.ErrKeyNotFound) {
			return fmt.Errorf("lib join: discard pending: %w", err)
		}
		fmt.Fprintf(os.Stderr, "lib join: discarded pending identity for alias %q\n", c.ActionAlias)
		return nil
	}
	if c.Invite == "" {
		return fmt.Errorf("lib join: invite blob is required — usage: accorder lib join <alias> '<blob>' (or @<file>)")
	}
	// Peer membership offer: detect (non-burning GET) before the operator-hosted
	// flow, which opens the secrets store and claims write-creds a peer join never needs.
	var offerPrefix string
	var offerPrefixKnown bool
	if isOfferURL(c.Invite, c.Insecure) {
		info, infoErr := fetchOfferInfo(c.Invite)
		if infoErr == nil && info.Kind == "peer" {
			return c.runPeerJoin(c.Invite, info)
		}
		// The burn-free GET also carries the offer's prefix — the only
		// identity-adjacent fact available before the claim, since the
		// informational payload deliberately omits the library UUID.
		if infoErr == nil {
			offerPrefix, offerPrefixKnown = info.Prefix, true
		}
		// If the user supplied peer-only flags, this is a peer join: do NOT silently
		// fall through to the offer-burning operator claim on a transient info-fetch
		// failure (the non-burning GET exists precisely to avoid wasting the offer).
		if infoErr != nil && (c.Endpoint != "" || c.LibraryID != "") {
			return fmt.Errorf("lib join: could not read membership offer at %s: %w\n  (not falling through to the operator claim, which would burn a single-use peer offer — retry)", c.Invite, infoErr)
		}
	}

	// Fall back to the alias's own saved calibrepath before anything burns.
	// The generic sibling backfill (mintSetupDefaults) sets the field by its Go
	// name "CalibreDirectory", which LibJoinCmd does not have — its field is
	// CalibrePath — so a legacy alias holding only lib.build.calibrepath (no
	// lib.join node; written before 2695dc0 put calibrepath in the shared
	// group) arrives here empty, classifies NoSource, and would burn the offer
	// before an unfollowable refusal. Reading the alias directly closes that
	// gap and is exactly the recall `-s` provenance already advertises.
	if c.CalibrePath == "" {
		if p := adoptedAliasCalibrePath(loadActionAliases(), c.ActionAlias); p != "" {
			fmt.Fprintf(os.Stderr, "lib join: using calibrepath %s (from alias %q)\n", p, c.ActionAlias)
			c.CalibrePath = p
		}
	}
	if c.CalibrePath != "" {
		if err := validateJoinDestination(c.CalibrePath); err != nil {
			return err
		}
	}

	// Open AND validate the secrets store BEFORE claiming the invite. A URL invite
	// is a single-use offer that claimInviteURL burns on receipt, so anything that
	// can fail — most often an unopenable passphrase-protected store — must fail
	// here, not after the offer is already spent (which would force a re-issue).
	storePath := secretsStorePath()
	store, err := resolveJoinSecretsStore(c.Passphrase)
	if err != nil {
		return fmt.Errorf("lib join: %w", err)
	}
	// Pre-claim preflight. Classify what this alias already holds BEFORE the
	// single-use offer is spent: a refusal here costs the operator nothing,
	// while the same refusal after the claim forces them to re-mint. Listing
	// the store also verifies it is openable — List and Verify both fully
	// decrypt, so one call serves both and skips a second KDF run.
	keyNames, verr := store.List()
	if verr != nil {
		return fmt.Errorf("lib join: secrets store %s is not usable: %w\n"+
			"  supply its passphrase via --passphrase or ACCORDER_SECRETS_PASSPHRASE,\n"+
			"  or convert it to passphrase-free (key-file) mode with 'accorder secrets rekey'\n"+
			"  refusing before the invite is claimed — a burned offer cannot be reclaimed", storePath, verr)
	}
	calibreDBExists := c.CalibrePath != "" && joinFileExists(filepath.Join(c.CalibrePath, "metadata.db"))
	decision := classifyJoinAlias(loadActionAliases(), keyNames, c.ActionAlias, calibreDBExists)

	// A raw blob or @file resolves locally, so its prefix is known before any
	// claim; only an offer URL has to be POSTed to be read, and its prefix came
	// from the burn-free GET above.
	claimBurns := isOfferURL(c.Invite, c.Insecure)
	var blobArg string
	var inv *fedlibinvite.WriteInvite
	if !claimBurns {
		blobArg, err = resolveInviteArg(c.Invite, c.Insecure)
		if err != nil {
			return fmt.Errorf("lib join: %w", err)
		}
		inv, err = fedlibinvite.DecodeWriteInvite(blobArg)
		if err != nil {
			return fmt.Errorf("lib join: %w", err)
		}
		offerPrefix, offerPrefixKnown = inv.Prefix, true
	}

	if err := preflightJoinDecision(c.ActionAlias, decision, offerPrefix, offerPrefixKnown, c.Invite); err != nil {
		return err
	}

	if claimBurns {
		blobArg, err = resolveInviteArg(c.Invite, c.Insecure)
		if err != nil {
			return fmt.Errorf("lib join: %w", err)
		}
		inv, err = fedlibinvite.DecodeWriteInvite(blobArg)
		if err != nil {
			return fmt.Errorf("lib join: %w", err)
		}
	}
	// Post-claim reconcile of the prefix. The pre-claim gate necessarily ran on
	// the offer host's advertised prefix, which is cleartext and not bound to
	// the sealed blob — the claimed payload is the authenticated value, so the
	// structural checks repeat against it before anything is written. A
	// mismatch here spends the offer (unavoidable) but mutates nothing.
	if offerPrefixKnown && claimBurns && inv.Prefix != offerPrefix {
		return fmt.Errorf("lib join: the offer advertised prefix %q but the claimed invite carries %q — refusing\n"+
			"  nothing was stored; the offer host may be misconfigured or hostile", offerPrefix, inv.Prefix)
	}
	if decision.HasPrefix && decision.PriorPrefix != inv.Prefix {
		return fmt.Errorf("lib join: alias %q already belongs to prefix %q; the claimed invite is for %q — refusing\n"+
			"  nothing was stored; to join under the new prefix, use a new alias", c.ActionAlias, decision.PriorPrefix, inv.Prefix)
	}
	secretEntries := []struct{ name, value string }{
		{c.ActionAlias + "/write/access-key", inv.AccessKey},
		{c.ActionAlias + "/write/secret-key", inv.SecretKey},
	}
	if inv.RemoteConfig != nil {
		secretEntries = append(secretEntries,
			struct{ name, value string }{c.ActionAlias + "/write/provider", inv.RemoteConfig["provider"]},
			struct{ name, value string }{c.ActionAlias + "/write/endpoint", inv.RemoteConfig["endpoint"]},
			struct{ name, value string }{c.ActionAlias + "/write/bucket", inv.RemoteConfig["bucket"]},
		)
	}
	if inv.Prefix != "" {
		secretEntries = append(secretEntries,
			struct{ name, value string }{c.ActionAlias + "/write/prefix", inv.Prefix},
		)
	}
	if inv.FedlibID != "" {
		secretEntries = append(secretEntries,
			struct{ name, value string }{c.ActionAlias + "/write/fedlib-id", inv.FedlibID},
		)
	}

	pendingValue, err := encodePendingJoin(inv)
	if err != nil {
		return fmt.Errorf("lib join: encode pending identity: %w", err)
	}
	bundle := map[string]string{pendingJoinKey(c.ActionAlias): pendingValue}
	var storedNames []string
	for _, entry := range secretEntries {
		if entry.value == "" {
			continue
		}
		bundle[entry.name] = entry.value
		storedNames = append(storedNames, entry.name)
	}
	if err := store.SetMany(bundle); err != nil {
		return fmt.Errorf("lib join: atomically store credentials and pending identity: %w", err)
	}

	fmt.Fprintf(os.Stderr, "lib join: configured alias %q\n", c.ActionAlias)
	fmt.Fprintf(os.Stderr, "  fedlib:   %s\n", inv.FedlibID)
	fmt.Fprintf(os.Stderr, "  prefix:   %s\n", inv.Prefix)
	fmt.Fprintf(os.Stderr, "  backend:  %s\n", inv.Backend)
	if inv.RemoteConfig != nil {
		fmt.Fprintf(os.Stderr, "  provider: %s\n", inv.RemoteConfig["provider"])
		fmt.Fprintf(os.Stderr, "  endpoint: %s\n", inv.RemoteConfig["endpoint"])
		fmt.Fprintf(os.Stderr, "  bucket:   %s\n", inv.RemoteConfig["bucket"])
	}
	fmt.Fprintf(os.Stderr, "  secrets:  %s\n", strings.Join(storedNames, ", "))
	fmt.Fprintf(os.Stderr, "\nWrite credentials stored in %s (encrypted).\n", storePath)
	fmt.Fprintf(os.Stderr, "Raw keys are NOT stored in any config file.\n")

	if c.CalibrePath == "" && inv.LibraryID != "" {
		iniMap, err := parseAccorderIni()
		if err != nil {
			fmt.Fprintf(os.Stderr, "lib join: warning: failed to parse accorder.ini: %v\n", err)
		} else if localDir, ok := iniMap[inv.LibraryID]; ok {
			metadataPath := filepath.Join(localDir, "metadata.db")
			if _, err := os.Stat(metadataPath); err == nil {
				log.Printf("[JOIN] Auto-adopted calibrepath from accorder.ini: %s", localDir)
				c.CalibrePath = localDir
			} else {
				fmt.Fprintf(os.Stderr, "lib join: warning: accorder.ini lists %s for this library, but metadata.db not found; proceeding with credentials-only join\n", localDir)
			}
		}
	}

	// Deliberately NO NoSource→LocalBuild refresh here. The only way a Calibre
	// source becomes reachable between classification and this point is the
	// accorder.ini block above — and ini resolves a directory by the INVITE's
	// UUID, not the alias's. For a NoSource alias (which by definition holds a
	// different UUID), that directory belongs to another library; treating it
	// as the alias's own source would authorize an adoption that strands the
	// old cached catalog — the exact harm NoSource exists to prevent. An alias
	// whose real source is reachable classifies LocalBuild up front (via -c,
	// alias recall, or the lib.build fallback), and a matching-identity
	// re-invite passes the guard below regardless of source.

	// Now that the invite's UUID is known, the adoption-only guards can run.
	if err := noSourceAdoptionRefusal(c.ActionAlias, decision, inv.LibraryID, c.Invite); err != nil {
		return err
	}
	if err := checkInviteAliasIdentity(c.ActionAlias, inv.LibraryID, decision); err != nil {
		return fmt.Errorf("lib join: %w\n  credentials and pending identity were saved; retry with a different alias", err)
	}
	if inv.RemoteConfig == nil || inv.RemoteConfig["bucket"] == "" {
		if err := activateInviteIdentity(ctx, c.ActionAlias, inv, decision); err != nil {
			return err
		}
		if c.CalibrePath != "" && joinFileExists(filepath.Join(c.CalibrePath, "metadata.db")) {
			// Preserve the historical friendly failure for old/hand-authored
			// blobs: identity is usable, but publishing is impossible without
			// a scoped remote. Current operator invites always carry it.
			return c.runJoinPublish(ctx, inv)
		}
		clearPendingJoin(store, c.ActionAlias)
		fmt.Fprintf(os.Stderr, "lib join: invite has no remote configuration; identity activated, published-content inspection skipped\n")
		return nil
	}
	creds := inviteCredentials(inv)
	remote, err := openLibraryRemoteForCommand(c.ActionAlias, creds)
	if err != nil {
		return fmt.Errorf("lib join: inspect published library: %w\n  retry: accorder lib sync %s -c <path>", err, c.ActionAlias)
	}
	snapshot := remote.commitState()
	remote.Close()
	if snapshot.Err != nil {
		if snapshot.Legacy {
			return fmt.Errorf("lib join: published library is legacy/unverified; ask its current writer to publish once with a current client before recovery\n  credentials and pending identity remain saved")
		}
		return fmt.Errorf("lib join: remote publish is interrupted/uncommitted: %w\n  credentials and pending identity remain saved", snapshot.Err)
	}
	if snapshot.Committed {
		if inv.LibraryID != "" && snapshot.Pointer.Library.UUID != inv.LibraryID {
			return fmt.Errorf("lib join: remote pointer UUID %s does not match invite UUID %s; no alias was activated", snapshot.Pointer.Library.UUID, inv.LibraryID)
		}
		if c.CalibrePath == "" {
			home, homeErr := os.UserHomeDir()
			if homeErr != nil {
				return fmt.Errorf("lib join: choose a destination and resume with `accorder lib sync %s -c <path>`", c.ActionAlias)
			}
			c.CalibrePath = filepath.Join(home, "Calibre Libraries", c.ActionAlias)
		}
		fmt.Fprintf(os.Stderr, "Published library found: %d books, generation %d\n", snapshot.Pointer.Index.NumBooks, snapshot.Generation)
		if term.IsTerminal(int(os.Stdin.Fd())) && !promptYesNoDefaultYes(fmt.Sprintf("Pull into %s?", c.CalibrePath)) {
			fmt.Fprintf(os.Stderr, "Join saved for later. Resume with: accorder lib sync %s -c %q\n", c.ActionAlias, c.CalibrePath)
			return nil
		}
		syncCmd := &LibSyncCmd{
			GroupLib:           GroupLib{GroupLibDir: GroupLibDir{CalibreDirectory: c.CalibrePath}, LibraryID: inv.LibraryID, Librarian: inv.Label, DictID: inv.DictID, FedlibPrefix: inv.Prefix},
			GroupS3Credentials: creds, ExpectedLibraryID: inv.LibraryID,
		}
		syncCmd.ActionAlias = c.ActionAlias
		// Activation runs AFTER a successful sync, as it always has on this
		// branch of the join. An earlier revision adopted first, to shrink the
		// window in which a concurrent `lib build` could abort the CAS after
		// content had moved — but the sync's own preconditions can refuse
		// deterministically (most commonly "destination is non-empty with no
		// sync baseline", which is exactly what a local build's directory looks
		// like), and adopting first turned that ordinary refusal into a
		// half-adopted alias: federation UUID in the config, local index and
		// cache still keyed to the old one, offer spent, no rollback. A rare
		// race was being paid for with a deterministic failure. Adoption after
		// sync keeps every refusal on this path non-mutating; the CAS inside
		// storeInviteLibraryID still guards the write itself.
		if err := syncCmd.Run(ctx); err != nil {
			return fmt.Errorf("lib join: %w\n  credentials and pending identity remain saved; retry: accorder lib sync %s -c %q", err, c.ActionAlias, c.CalibrePath)
		}
		if err := activateInviteIdentity(ctx, c.ActionAlias, inv, decision); err != nil {
			return fmt.Errorf("lib join: activate recovered identity: %w", err)
		}
		clearPendingJoin(store, c.ActionAlias)
		return nil
	}

	localLibrary := c.CalibrePath != "" && joinFileExists(filepath.Join(c.CalibrePath, "metadata.db"))
	if localLibrary {
		// Defaults to yes, like the pull prompt in the committed branch above.
		// Publishing is what `lib join` was asked to do, and this same branch
		// publishes unprompted when stdin is not a terminal — a [y/N] here made
		// the supervised path more timid than the automated one, and turned a
		// reflexive Enter into a credentials-only join nobody asked for.
		if term.IsTerminal(int(os.Stdin.Fd())) && !promptYesNoDefaultYes(fmt.Sprintf("No published library exists. Build and publish %s?", c.CalibrePath)) {
			fmt.Fprintf(os.Stderr, "Credentials-only join saved; publish later with: accorder lib publish %s\n", c.ActionAlias)
			return activateInviteIdentity(ctx, c.ActionAlias, inv, decision)
		}
		if err := activateInviteIdentity(ctx, c.ActionAlias, inv, decision); err != nil {
			return err
		}
		if err := c.runJoinPublish(ctx, inv); err != nil {
			return err
		}
		clearPendingJoin(store, c.ActionAlias)
		return nil
	}
	if err := activateInviteIdentity(ctx, c.ActionAlias, inv, decision); err != nil {
		return err
	}
	clearPendingJoin(store, c.ActionAlias)
	// The invite is spent, credentials and identity are stored — but nothing was
	// published, so this member stays `invited` in the operator's registry and
	// their books never appear. Returning nil here made that outcome look like
	// success, which is the failure mode worth the non-zero exit: the librarian
	// walks away believing they have joined.
	//
	// Two sibling paths deliberately keep exit 0: a librarian who explicitly
	// declined a prompt above chose their state, and the no-remote-config
	// branch earlier is a complete outcome for its invite type — a
	// legacy/hand-authored blob without a scoped remote cannot end in a
	// publish, so "identity activated" is all a join can mean there.
	return fmt.Errorf("lib join: joined %q but %w\n"+
		"  credentials and identity are saved, and the invite has been claimed\n"+
		"  finish the join by naming the library: accorder lib publish %s -c /path/to/calibre/library",
		c.ActionAlias, errJoinPublishedNothing, c.ActionAlias)
}

// errJoinPublishedNothing marks a join that stored credentials and activated
// identity but published no content. In-process callers test it with
// errors.Is; the e2e suites, which see only a child process's output, match
// the literal token "published nothing" — keep that phrase stable, it is the
// cross-process half of this contract.
var errJoinPublishedNothing = errors.New("published nothing — no Calibre library was given or found")

func promptYesNoDefaultYes(prompt string) bool {
	if !term.IsTerminal(int(os.Stdin.Fd())) {
		return false
	}
	fmt.Fprintf(os.Stderr, "%s [Y/n] ", prompt)
	var answer string
	_, _ = fmt.Scanln(&answer)
	answer = strings.ToLower(strings.TrimSpace(answer))
	return answer == "" || answer == "y" || answer == "yes"
}

type pendingJoinIdentity struct {
	Version   int    `json:"version"`
	LibraryID string `json:"library_id"`
	DictID    uint32 `json:"dict_id"`
	Prefix    string `json:"prefix"`
	Label     string `json:"label"`
}

func pendingJoinKey(alias string) string { return alias + "/pending/join" }

func encodePendingJoin(invite *fedlibinvite.WriteInvite) (string, error) {
	data, err := json.Marshal(pendingJoinIdentity{
		Version: 1, LibraryID: invite.LibraryID, DictID: invite.DictID,
		Prefix: invite.Prefix, Label: invite.Label,
	})
	if err != nil {
		return "", err
	}
	return string(data), nil
}

func clearPendingJoin(store *secrets.Store, alias string) {
	if err := store.Delete(pendingJoinKey(alias)); err != nil && !errors.Is(err, secrets.ErrKeyNotFound) {
		fmt.Fprintf(os.Stderr, "lib join: warning: clear pending identity: %v\n", err)
	}
}

func loadPendingJoin(passphrase, alias string) (*pendingJoinIdentity, *secrets.Store, error) {
	store, err := resolveJoinSecretsStore(passphrase)
	if err != nil {
		return nil, nil, err
	}
	raw, err := store.Get(pendingJoinKey(alias))
	if err != nil {
		return nil, store, err
	}
	var pending pendingJoinIdentity
	if err := json.Unmarshal([]byte(raw), &pending); err != nil {
		return nil, store, fmt.Errorf("decode encrypted pending identity: %w", err)
	}
	if pending.Version != 1 || pending.LibraryID == "" {
		return nil, store, fmt.Errorf("invalid encrypted pending identity for alias %q", alias)
	}
	return &pending, store, nil
}

func validateJoinDestination(path string) error {
	info, err := os.Stat(path)
	if os.IsNotExist(err) {
		return nil
	}
	if err != nil {
		return fmt.Errorf("lib join: inspect --calibrepath %q: %w", path, err)
	}
	if !info.IsDir() {
		return fmt.Errorf("lib join: --calibrepath %q is not a directory", path)
	}
	if joinFileExists(filepath.Join(path, "metadata.db")) {
		return nil
	}
	empty, err := directoryHasEntries(path)
	if err != nil {
		return fmt.Errorf("lib join: inspect --calibrepath %q: %w", path, err)
	}
	if empty {
		return fmt.Errorf("lib join: --calibrepath %q is non-empty but metadata.db is missing", path)
	}
	return nil
}

func joinFileExists(path string) bool {
	info, err := os.Stat(path)
	return err == nil && !info.IsDir()
}

func checkInviteAliasIdentity(alias, inviteID string, d joinAliasDecision) error {
	if inviteID == "" {
		return nil
	}
	configBytes := loadActionAliases()
	stored := gjson.GetBytes(configBytes, alias+".lib.build.libraryID").String()
	if stored == "" || stored == inviteID {
		return nil
	}
	// One adoption rule, one implementation: the early gate delegates to the
	// same authorizeAdoption the under-lock CAS uses, so the two sites cannot
	// drift apart — a divergence here would admit pre-claim what the CAS later
	// refuses, moving the refusal past the burn. authorizeAdoption allows only
	// a LocalBuild whose re-read state still matches the classification, and
	// phrases every refusal itself.
	return authorizeAdoption(configBytes, alias, d, stored, inviteID)
}

func inviteCredentials(invite *fedlibinvite.WriteInvite) GroupS3Credentials {
	bucket := strings.TrimRight(invite.RemoteConfig["bucket"], "/")
	if invite.Prefix != "" {
		bucket += "/" + strings.Trim(invite.Prefix, "/")
	}
	return GroupS3Credentials{
		Bucket: bucket, S3AccessKey: invite.AccessKey, S3SecretKey: invite.SecretKey,
		S3Provider: invite.RemoteConfig["provider"], S3Endpoint: invite.RemoteConfig["endpoint"],
	}
}

func activateInviteIdentity(ctx *kong.Context, alias string, invite *fedlibinvite.WriteInvite, d joinAliasDecision) error {
	if invite.LibraryID != "" {
		if err := storeInviteLibraryID(ctx, alias, invite.LibraryID, d); err != nil {
			return err
		}
	}
	if invite.Label != "" {
		storeInviteLabelAsLibrarian(ctx, alias, invite.Label)
	}
	if invite.DictID != 0 {
		storeInviteDictID(ctx, alias, invite.DictID)
	}
	if invite.Prefix != "" {
		storeInvitePrefix(ctx, alias, invite.Prefix)
	}
	return nil
}

func (c *LibJoinCmd) runJoinPublish(ctx *kong.Context, inv *fedlibinvite.WriteInvite) error {
	root := joinRootNode(ctx)
	libraryID, librarian, _ := ensureAliasSetup(root, c.ActionAlias, c.CalibrePath, inv.Label)

	if inv.RemoteConfig == nil || inv.RemoteConfig["bucket"] == "" {
		return fmt.Errorf("lib join: invite carries no bucket/remote config — cannot publish (re-issue the invite with full remote config)")
	}

	build := &LibBuildCmd{}
	build.ActionAlias = c.ActionAlias
	build.CalibreDirectory = c.CalibrePath
	build.Librarian = librarian
	build.LibraryID = libraryID
	build.InPipeline = true
	// This struct is constructed directly (not via kong parse), so AfterApply
	// does not hydrate it from the action-alias config that storeInviteDictID/
	// storeInvitePrefix just wrote. Carry the invite's DictID + prefix straight
	// onto the build, otherwise the join-time publish ships a DictID=1 container
	// with no baked BaseURL — defeating WF3 composition on the primary join path.
	build.DictID = inv.DictID
	build.FedlibPrefix = inv.Prefix
	if err := build.Run(ctx); err != nil {
		return fmt.Errorf("lib join: build: %w", err)
	}

	bucket := strings.TrimRight(inv.RemoteConfig["bucket"], "/")
	if inv.Prefix != "" {
		bucket = bucket + "/" + inv.Prefix
	}
	upload := &LibUploadCmd{
		GroupLib: build.GroupLib,
		GroupS3Credentials: GroupS3Credentials{
			Bucket:      bucket,
			S3AccessKey: inv.AccessKey,
			S3SecretKey: inv.SecretKey,
			S3Provider:  inv.RemoteConfig["provider"],
			S3Endpoint:  inv.RemoteConfig["endpoint"],
		},
		ExcludeGlobs: build.PrivateExcludes,
	}
	upload.ActionAlias = c.ActionAlias
	upload.InPipeline = true
	if err := upload.Run(ctx); err != nil {
		return fmt.Errorf("lib join: publish: %w", err)
	}

	fmt.Fprintf(os.Stderr, "lib join: built and published %q to %s\n", c.ActionAlias, bucket)
	return nil
}

func storeInviteDictID(ctx *kong.Context, alias string, dictID uint32) {
	root := joinRootNode(ctx)
	unlockAliasCfg := lockAliasConfigOrDie()
	defer unlockAliasCfg()
	configBytes := loadActionAliases()
	var err error
	configBytes, err = sjson.SetBytes(configBytes, alias+".lib.build.dictID", dictID)
	if err != nil {
		fmt.Fprintf(os.Stderr, "lib join: store invite dictID: %v\n", err)
		return
	}
	if buildNode := findNodeByPath(root, "lib.build"); buildNode != nil {
		// Propagate the numeric dictID (not a stringified one): the GroupLib.dictID
		// field is uint32, so writing "4" to sibling lib.* paths (lib.upload, etc.)
		// makes the next `lib publish`/`lib upload` fail to unmarshal the alias.
		propagateSharedField(root, buildNode, alias, "dictID", dictID, "lib", &configBytes)
	}
	saveActionAliases(configBytes)
	fmt.Fprintf(os.Stderr, "lib join: stored DictID %d for alias %q\n", dictID, alias)
}

func storeInvitePrefix(ctx *kong.Context, alias, prefix string) {
	root := joinRootNode(ctx)
	unlockAliasCfg := lockAliasConfigOrDie()
	defer unlockAliasCfg()
	configBytes := loadActionAliases()
	var err error
	configBytes, err = sjson.SetBytes(configBytes, alias+".lib.build.fedlibPrefix", prefix)
	if err != nil {
		fmt.Fprintf(os.Stderr, "lib join: store invite prefix: %v\n", err)
		return
	}
	if buildNode := findNodeByPath(root, "lib.build"); buildNode != nil {
		// Propagate to every sharedgroup:"lib" sibling (lib.publish, lib.upload, …)
		// so a later `lib publish <alias>` re-bakes /files/<prefix> instead of an
		// empty BaseURL. storeInviteDictID does the same; without it, republishing a
		// joined member silently drops every book's file base.
		propagateSharedField(root, buildNode, alias, "fedlibPrefix", prefix, "lib", &configBytes)
	}
	saveActionAliases(configBytes)
	fmt.Fprintf(os.Stderr, "lib join: stored fedlib prefix %q for alias %q\n", prefix, alias)
}

func storeInviteLabelAsLibrarian(ctx *kong.Context, alias, label string) {
	root := joinRootNode(ctx)
	unlockAliasCfg := lockAliasConfigOrDie()
	defer unlockAliasCfg()
	configBytes := loadActionAliases()
	// Don't clobber a librarian the user already chose for this alias (e.g. set in
	// browse settings or a prior --librarian): the invite label only seeds a name
	// when none is set yet.
	if existing := gjson.GetBytes(configBytes, alias+".lib.build.librarian").String(); existing != "" {
		return
	}
	var err error
	configBytes, err = sjson.SetBytes(configBytes, alias+".lib.build.librarian", label)
	if err != nil {
		fmt.Fprintf(os.Stderr, "lib join: store invite label: %v\n", err)
		return
	}
	if buildNode := findNodeByPath(root, "lib.build"); buildNode != nil {
		propagateSharedField(root, buildNode, alias, "librarian", label, "lib", &configBytes)
	}
	saveActionAliases(configBytes)
	fmt.Fprintf(os.Stderr, "lib join: stored invite label %q as librarian for alias %q\n", label, alias)
}

func storeInviteLibraryID(ctx *kong.Context, alias, inviteID string, d joinAliasDecision) error {
	root := joinRootNode(ctx)
	unlockAliasCfg := lockAliasConfigOrDie()
	defer unlockAliasCfg()
	configBytes := loadActionAliases()
	stored := gjson.GetBytes(configBytes, alias+".lib.build.libraryID").String()
	if stored == inviteID {
		// Already ours — a re-invite carrying the identity this alias holds.
		return nil
	}
	if stored != "" {
		if err := authorizeAdoption(configBytes, alias, d, stored, inviteID); err != nil {
			return err
		}
		fmt.Fprintf(os.Stderr, "lib join: adopting federation identity for alias %q\n"+
			"  local library %s had no membership or publish record; replaced by %s\n",
			alias, stored, inviteID)
	}
	var err error
	configBytes, err = sjson.SetBytes(configBytes, alias+".lib.build.libraryID", inviteID)
	if err != nil {
		return fmt.Errorf("adopt invite libraryID: %w", err)
	}
	if buildNode := findNodeByPath(root, "lib.build"); buildNode != nil {
		propagateSharedField(root, buildNode, alias, "libraryID", inviteID, "lib", &configBytes)
	}
	saveActionAliases(configBytes)
	fmt.Fprintf(os.Stderr, "lib join: adopted federation libraryID %s for alias %q\n", inviteID, alias)
	return nil
}

func joinRootNode(ctx *kong.Context) *kong.Node {
	if ctx == nil {
		return nil
	}
	root := ctx.Selected()
	for root != nil && root.Parent != nil {
		root = root.Parent
	}
	return root
}

func findNodeByPath(root *kong.Node, dottedPath string) *kong.Node {
	var found *kong.Node
	var traverse func(*kong.Node)
	traverse = func(n *kong.Node) {
		if n == nil || found != nil {
			return
		}
		if strings.Join(strings.Split(n.Path(), " "), ".") == dottedPath {
			found = n
			return
		}
		for _, child := range n.Children {
			traverse(child)
		}
	}
	traverse(root)
	return found
}

func promptSecretsPassphrase(provided string) (string, error) {
	if provided != "" {
		return provided, nil
	}
	fd := int(os.Stdin.Fd())
	if !term.IsTerminal(fd) {
		return "", fmt.Errorf("--passphrase or ACCORDER_SECRETS_PASSPHRASE is required (no terminal to prompt on)")
	}
	fmt.Fprint(os.Stderr, "Secrets-store passphrase: ")
	pw, err := term.ReadPassword(fd)
	fmt.Fprintln(os.Stderr)
	if err != nil {
		return "", fmt.Errorf("read passphrase: %w", err)
	}
	p := strings.TrimSpace(string(pw))
	if p == "" {
		return "", fmt.Errorf("empty passphrase")
	}
	return p, nil
}

func parseAccorderIni() (map[string]string, error) {
	iniPath := filepath.Join(accorderConfigDir, "accorder.ini")

	if _, err := os.Stat(iniPath); os.IsNotExist(err) {
		return nil, nil
	}

	cfg, err := ini.Load(iniPath)
	if err != nil {
		return nil, fmt.Errorf("load accorder.ini: %w", err)
	}

	result := make(map[string]string)
	for _, section := range cfg.Sections() {
		name := section.Name()
		if name == "DEFAULT" || !strings.HasSuffix(name, "_calibre") {
			continue
		}

		uuid := section.Key("library_uuid").String()
		localDir := section.Key("local_directory").String()

		if uuid != "" && localDir != "" {
			result[uuid] = localDir
		}
	}

	return result, nil
}
