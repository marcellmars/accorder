package cmd

import (
	"os"
	"path/filepath"
	"testing"

	"accorder/pkg/calibre"
)

// TestRangeFetchGate covers the gate browse applies on a SyncRangeFetch: a plain
// cached index may take the incremental tail range-fetch, but a locally-compiled
// index (JSONL-compiled, or recompiled with descriptions via `lib index
// recompile`) must fall back to a full re-fetch — its byte layout no longer
// matches the server's, so delta offsets would be wrong. After the full re-fetch
// the M2 hook re-applies descriptions. This is the recompiled-index update path.
func TestRangeFetchGate(t *testing.T) {
	dir := t.TempDir()
	localPath := filepath.Join(dir, "library_index.zst")
	if err := os.WriteFile(localPath, []byte("zstbytes"), 0o644); err != nil {
		t.Fatal(err)
	}

	// Plain cached index: a source append can be applied as a range-fetch delta.
	if !rangeFetchAllowed(localPath) {
		t.Fatal("plain cached index should permit range-fetch of the delta")
	}

	// Recompiled / locally-compiled index: range-fetch is refused, forcing a full
	// re-download on every source change.
	markCompiled(localPath)
	if !isLocallyCompiled(localPath) {
		t.Fatal("markCompiled did not set the .compiled marker")
	}
	if rangeFetchAllowed(localPath) {
		t.Fatal("locally-compiled index must refuse range-fetch (forces full re-download)")
	}

	// Clearing the marker restores the incremental path.
	clearCompiledMark(localPath)
	if !rangeFetchAllowed(localPath) {
		t.Fatal("clearing .compiled should restore range-fetch")
	}
}

// TestSyncDecisionDrivesGate ties the two halves together: DetermineSyncAction
// decides append-vs-compaction, and only a SyncRangeFetch outcome is then
// subject to the .compiled gate. A compaction already forces a full download
// regardless of the marker. (DetermineSyncAction's full matrix lives in
// pkg/calibre/sync_test.go; this asserts the browse-side contract.)
func TestSyncDecisionDrivesGate(t *testing.T) {
	cached := &calibre.CachedSyncState{
		BaseGeneration:    "base-1",
		PointerGeneration: 5,
		LastCompactGen:    0,
	}

	// Source appended (same lineage, higher generation, no new compaction) → range-fetch.
	appended := calibre.PointerFile{}
	appended.Index.BaseGeneration = "base-1"
	appended.Index.PointerGeneration = 6
	if got := calibre.DetermineSyncAction(cached, appended, "append", false); got.Kind != calibre.SyncRangeFetch {
		t.Fatalf("append: expected SyncRangeFetch, got %v (%s)", got.Kind, got.Reason)
	}

	// Source compacted (new BaseGeneration) → full download, no range-fetch to gate.
	compacted := calibre.PointerFile{}
	compacted.Index.BaseGeneration = "base-2"
	compacted.Index.PointerGeneration = 6
	if got := calibre.DetermineSyncAction(cached, compacted, "append", false); got.Kind != calibre.SyncFullDownload {
		t.Fatalf("compaction: expected SyncFullDownload, got %v (%s)", got.Kind, got.Reason)
	}
}
