//go:build !tailscale && !tor

package cmd

import (
	"strings"
	"testing"

	"github.com/alecthomas/kong"
)

func driftFindings(t *testing.T, cfg string, alias string) []rotFinding {
	t.Helper()
	app, err := kong.New(&CLI{}, kong.Name("accorder"), kong.Exit(func(int) {}))
	if err != nil {
		t.Fatalf("kong.New: %v", err)
	}
	var out []rotFinding
	for _, f := range scanAliasRot(app.Model.Node, []byte(cfg), alias) {
		if f.Kind == rotDriftedKey {
			out = append(out, f)
		}
	}
	return out
}

// TRUE POSITIVE: a sharedgroup field holding different values on two commands
// that propagation keeps in sync. calibrepath carries sharedgroup:"lib", so
// AfterApply copies it between lib commands — a disagreement is a real fault.
func TestDrift_ReportsSharedGroupDisagreement(t *testing.T) {
	testSetup(t)
	cfg := `{"a":{"lib":{
		"build":{"calibrepath":"/srv/library"},
		"upload":{"calibrepath":"/mnt/OLD-library"}}}}`

	got := driftFindings(t, cfg, "a")
	if len(got) != 1 {
		t.Fatalf("want exactly 1 drift finding, got %d: %+v", len(got), got)
	}
	if got[0].Path != "calibrepath" {
		t.Errorf("finding names %q, want calibrepath", got[0].Path)
	}
	for _, want := range []string{"/srv/library", "/mnt/OLD-library", "lib.build", "lib.upload"} {
		if !strings.Contains(got[0].Reason, want) {
			t.Errorf("reason must name both values and both paths; missing %q in %q", want, got[0].Reason)
		}
	}
	if got[0].Kind.deletable() {
		t.Error("drift must be report-only — the tool cannot know which value is correct")
	}
}

// FALSE POSITIVE GUARD 1: `listen` is intentionally different between
// lib share live (:8724) and fedlib share live (:8723). Neither tags it
// sharedgroup and their kong groups differ (lib vs fedlib), so propagation
// can never link them. Naive leaf-name grouping — what the shell detector
// does — would flag this.
func TestDrift_IgnoresIntentionallyDifferentListen(t *testing.T) {
	testSetup(t)
	cfg := `{"a":{
		"lib":{"share":{"live":{"listen":"127.0.0.1:8724"}}},
		"fedlib":{"share":{"live":{"listen":"127.0.0.1:8723"}}}}}`

	if got := driftFindings(t, cfg, "a"); len(got) != 0 {
		t.Errorf("listen across lib/fedlib is not drift, got %+v", got)
	}
}

// FALSE POSITIVE GUARD 2: the production shape. Fossil subtrees from an older
// naming scheme hold stale copies of a setting the live command also has.
// They match no command in this build, so they are rotDeadSubtree, not a
// competing value. Reporting drift here would be strictly worse than the
// unknown-subtree finding the operator already gets.
func TestDrift_IgnoresFossilSubtrees(t *testing.T) {
	testSetup(t)
	cfg := `{"a":{
		"calibre":{"build":{"aggregate-path":"/root/.config/accorder-kong/aggregate"}},
		"motw":{"serve":{"aggregate-path":"/root/.config/accorder-kong/aggregate"}},
		"fedlib":{"share":{"live":{"aggregate-path":"/root/.config/accorder/aggregate"}}}}}`

	if got := driftFindings(t, cfg, "a"); len(got) != 0 {
		t.Errorf("fossil subtrees are not drift candidates, got %+v", got)
	}

	app, _ := kong.New(&CLI{}, kong.Name("accorder"), kong.Exit(func(int) {}))
	var dead int
	for _, f := range scanAliasRot(app.Model.Node, []byte(cfg), "a") {
		if f.Kind == rotDeadSubtree {
			dead++
		}
	}
	if dead == 0 {
		t.Error("the fossils must still be reported as unknown subtrees")
	}
}

// Paths differing only by a trailing slash are the same directory. Raw
// string comparison reported these as conflicting, which on a real config
// would be common noise — operators type ~/lib and ~/lib/ interchangeably.
func TestDrift_NormalizesPathSpelling(t *testing.T) {
	testSetup(t)
	cfg := `{"a":{"lib":{
		"build":{"calibrepath":"/srv/library/"},
		"upload":{"calibrepath":"/srv/library"}}}}`
	if got := driftFindings(t, cfg, "a"); len(got) != 0 {
		t.Errorf("trailing-slash difference is not drift, got %+v", got)
	}
}

// A single value across many commands is agreement, not drift.
func TestDrift_SilentWhenValuesAgree(t *testing.T) {
	testSetup(t)
	cfg := `{"a":{"lib":{
		"build":{"calibrepath":"/srv/library"},
		"upload":{"calibrepath":"/srv/library"}}}}`
	if got := driftFindings(t, cfg, "a"); len(got) != 0 {
		t.Errorf("identical values are not drift, got %+v", got)
	}
}
