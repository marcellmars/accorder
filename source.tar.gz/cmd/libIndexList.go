package cmd

import (
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"text/tabwriter"
)

type LibIndexListCmd struct{}

func (c *LibIndexListCmd) Run() error {
	entries := registryList()
	if len(entries) == 0 {
		fmt.Fprintln(os.Stderr, "No sources registered. Use 'lib browse' with --invite or --endpoint to auto-register.")
		return nil
	}
	cacheBase := filepath.Join(accorderConfigDir, "tor", "cache")
	names := make([]string, 0, len(entries))
	for name := range entries {
		names = append(names, name)
	}
	sort.Strings(names)
	tw := tabwriter.NewWriter(os.Stdout, 0, 4, 2, ' ', 0)
	fmt.Fprintf(tw, "NAME\tUUID\tENDPOINT\tINDEX SIZE\tLAST SYNCED\n")
	for _, name := range names {
		e := entries[name]
		size, synced := "-", "-"
		if e.UUID != "" {
			idxPath := filepath.Join(cacheBase, e.UUID, "static", "library_index.zst")
			if fi, err := os.Stat(idxPath); err == nil {
				size = formatSize(fi.Size())
				synced = fi.ModTime().Format("2006-01-02 15:04")
			}
		}
		ep := e.Endpoint
		if ep == "" && e.Invite != "" {
			ep = "(onion)"
		}
		fmt.Fprintf(tw, "%s\t%s\t%s\t%s\t%s\n", name, shortUUID(e.UUID), ep, size, synced)
	}
	tw.Flush()
	return nil
}

func formatSize(bytes int64) string {
	const (
		kib = 1024
		mib = 1024 * kib
		gib = 1024 * mib
	)
	switch {
	case bytes >= gib:
		return fmt.Sprintf("%.1f GiB", float64(bytes)/float64(gib))
	case bytes >= mib:
		return fmt.Sprintf("%.1f MiB", float64(bytes)/float64(mib))
	case bytes >= kib:
		return fmt.Sprintf("%.0f KiB", float64(bytes)/float64(kib))
	default:
		return fmt.Sprintf("%d B", bytes)
	}
}

func shortUUID(uuid string) string {
	if len(uuid) <= 8 {
		return uuid
	}
	return uuid[:8] + "..."
}
