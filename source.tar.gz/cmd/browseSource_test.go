//go:build !tailscale

package cmd

import (
	"os"
	"path/filepath"
	"testing"

	"github.com/tidwall/gjson"
)

func TestPersistAndLoadBrowseSource_Invite(t *testing.T) {
	testSetup(t)

	persistBrowseSource("mylib", "abc123.onion", "", "per_library", "Alice's Library")

	onion, endpoint, pt, label := loadBrowseSource("mylib")
	if onion != "abc123.onion" {
		t.Errorf("onion = %q, want abc123.onion", onion)
	}
	if endpoint != "" {
		t.Errorf("endpoint = %q, want empty", endpoint)
	}
	if pt != "per_library" {
		t.Errorf("publisher-type = %q, want per_library", pt)
	}
	if label != "Alice's Library" {
		t.Errorf("source-label = %q, want Alice's Library", label)
	}

	// Verify stored under the correct JSON path.
	data, err := os.ReadFile(savedActionAliases)
	if err != nil {
		t.Fatal(err)
	}
	if got := gjson.GetBytes(data, "mylib.lib.browse.onion").String(); got != "abc123.onion" {
		t.Errorf("stored onion = %q", got)
	}
}

func TestPersistAndLoadBrowseSource_BareEndpoint(t *testing.T) {
	testSetup(t)

	// Public clearnet case: no invite, no auth, no onion, no source-label.
	persistBrowseSource("motw", "", "https://library.memoryoftheworld.org/", "aggregator", "")

	onion, endpoint, pt, label := loadBrowseSource("motw")
	if onion != "" {
		t.Errorf("onion = %q, want empty", onion)
	}
	if endpoint != "https://library.memoryoftheworld.org/" {
		t.Errorf("endpoint = %q, want https://library.memoryoftheworld.org/", endpoint)
	}
	if pt != "aggregator" {
		t.Errorf("publisher-type = %q, want aggregator", pt)
	}
	if label != "" {
		t.Errorf("source-label = %q, want empty", label)
	}
}

func TestPersistAndLoadBrowseSource_OverwriteOnRerun(t *testing.T) {
	testSetup(t)

	// First run with one source.
	persistBrowseSource("mylib", "abc123.onion", "", "per_library", "First")

	// Second run overwrites with a different source (e.g. user re-invites).
	persistBrowseSource("mylib", "xyz456.onion", "", "per_library", "Second")

	onion, _, _, label := loadBrowseSource("mylib")
	if onion != "xyz456.onion" {
		t.Errorf("onion = %q, want xyz456.onion (not overwritten?)", onion)
	}
	if label != "Second" {
		t.Errorf("source-label = %q, want Second", label)
	}
}

func TestOfflineCacheDir_NoUUID_Error(t *testing.T) {
	testSetup(t)

	_, err := offlineCacheDir("unknown-alias", "/tmp/cache")
	if err == nil {
		t.Fatal("expected error when no UUID is saved, got nil")
	}
}

func TestOfflineCacheDir_WithUUID(t *testing.T) {
	testSetup(t)

	// Simulate a prior online sync that persisted the UUID.
	persistBrowseSourceUUID("mylib", "550e8400-e29b-41d4-a716-446655440000")

	dir, err := offlineCacheDir("mylib", "/tmp/cache")
	if err != nil {
		t.Fatalf("offlineCacheDir: %v", err)
	}
	want := filepath.Join("/tmp/cache", "550e8400-e29b-41d4-a716-446655440000")
	if dir != want {
		t.Errorf("dir = %q, want %q", dir, want)
	}
}

func TestPersistBrowseSourceUUID_WritesUnderAlias(t *testing.T) {
	testSetup(t)

	persistBrowseSourceUUID("mylib", "test-uuid-123")

	data, err := os.ReadFile(savedActionAliases)
	if err != nil {
		t.Fatal(err)
	}
	got := gjson.GetBytes(data, "mylib.lib.browse.source-uuid").String()
	if got != "test-uuid-123" {
		t.Errorf("source-uuid = %q, want test-uuid-123", got)
	}
}

func TestCalibrePathSharedGroupPropagation(t *testing.T) {
	libDir := testSetup(t)

	// Parse a lib browse command with calibrepath set.
	// The sharedgroup:"lib" tag should propagate to sibling commands.
	parseCLI(t, []string{
		"lib", "browse", "shared-browse-test",
		"--calibrepath=" + libDir,
		"--http-endpoint=http://example.com/",
	})

	alias := readAlias(t, "shared-browse-test")

	// calibrepath should be propagated to lib.build (sharedgroup:"lib" sibling).
	buildCalibre := alias.Get("lib.build.calibrepath").String()
	if buildCalibre != libDir {
		t.Errorf("lib.build.calibrepath = %q, want %q (sharedgroup propagation)", buildCalibre, libDir)
	}

	// calibrepath should also appear under lib.share.live.
	shareCalibre := alias.Get("lib.share.live.calibrepath").String()
	if shareCalibre != libDir {
		t.Errorf("lib.share.live.calibrepath = %q, want %q", shareCalibre, libDir)
	}

	// calibrepath should propagate to lib.join too (sharedgroup:"lib" sibling) — so a
	// later `lib join <alias>` inherits it and can build+publish without -c.
	joinCalibre := alias.Get("lib.join.calibrepath").String()
	if joinCalibre != libDir {
		t.Errorf("lib.join.calibrepath = %q, want %q (sharedgroup propagation)", joinCalibre, libDir)
	}
}

// The --librarian flag on lib browse carries sharedgroup:"lib", so a librarian
// given at browse time reaches the alias's other lib actions (build, share,
// join) — the same recall that lets a later bare command reuse it.
func TestBrowseLibrarianSharedGroupPropagation(t *testing.T) {
	libDir := testSetup(t)

	parseCLI(t, []string{
		"lib", "browse", "shared-librarian-test",
		"--calibrepath=" + libDir,
		"--librarian=Ada Lovelace",
		"--http-endpoint=http://example.com/",
	})

	alias := readAlias(t, "shared-librarian-test")

	// Reaches the lib actions that declare a librarian in the group.
	for _, path := range []string{
		"lib.browse.librarian",
		"lib.build.librarian",
		"lib.share.live.librarian",
	} {
		if got := alias.Get(path).String(); got != "Ada Lovelace" {
			t.Errorf("%s = %q, want %q (sharedgroup propagation)", path, got, "Ada Lovelace")
		}
	}

	// Not lib.join: it has no librarian flag (the librarian comes from the
	// invite), so there is no field for the group to populate. Unlike
	// calibrepath, which lib join does declare and does receive.
	if got := alias.Get("lib.join.librarian").String(); got != "" {
		t.Errorf("lib.join.librarian = %q, want empty (join has no librarian field)", got)
	}
}

// Regression (ca-117 §4): the bare re-run of a bookmarked PUBLIC clearnet source
// resolves auth via loadBrowseAuth. A public source stores no bearer token, so
// the secrets store either has no file or no such key — both must resolve to
// "no auth, browse public", NOT a fatal error. Before the fix, a present-but-
// keyless store returned secrets.ErrKeyNotFound and `lib browse <alias>` died
// with "read bearer token: ... not found" — breaking the exact command the
// share-line teaching message tells the friend to run next time.
func TestLoadBrowseAuth_PublicSourceMissingTokenIsNotFatal(t *testing.T) {
	testSetup(t)

	// No token was ever stored for this alias (public source).
	scheme, token, keyPriv, err := loadBrowseAuth("from-alice", "")
	if err != nil {
		t.Fatalf("public bearer path must not error on a missing token, got: %v", err)
	}
	if scheme != "" || token != "" || keyPriv != "" {
		t.Errorf("expected empty auth for a public source, got scheme=%q token=%q keyPriv=%q", scheme, token, keyPriv)
	}

	// Same for the onion client-auth path.
	scheme, _, keyPriv, err = loadBrowseAuth("from-alice", "abc123.onion")
	if err != nil {
		t.Fatalf("public onion path must not error on a missing client-auth key, got: %v", err)
	}
	if scheme != "" || keyPriv != "" {
		t.Errorf("expected empty onion auth for a public source, got scheme=%q keyPriv=%q", scheme, keyPriv)
	}
}
