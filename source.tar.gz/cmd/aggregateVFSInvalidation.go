package cmd

import (
	"fmt"
	"log"
	"os"
	"path"
	"path/filepath"
	"sort"
	"strings"

	"accorder/pkg/libraryflow"
	"accorder/pkg/rclonexfer"
	"accorder/pkg/torshare"
)

type aggregateInvalidationScope struct {
	full     bool
	prefixes []string
	books    []string
	assets   []string
}

func fullAggregateInvalidation() aggregateInvalidationScope {
	return aggregateInvalidationScope{full: true}
}

func memberAggregateInvalidation(prefixes ...string) aggregateInvalidationScope {
	return aggregateInvalidationScope{prefixes: normalizedInvalidationDirs(prefixes)}
}

func exactAggregateInvalidation(books, assets []string) aggregateInvalidationScope {
	return aggregateInvalidationScope{
		books: normalizedInvalidationDirs(books), assets: normalizedInvalidationDirs(assets),
	}
}

func normalizedInvalidationDirs(dirs []string) []string {
	seen := make(map[string]struct{}, len(dirs))
	cleaned := make([]string, 0, len(dirs))
	for _, prefix := range dirs {
		prefix = strings.Trim(path.Clean("/"+strings.TrimSpace(prefix)), "/")
		if prefix == "" || prefix == "." {
			continue
		}
		if _, ok := seen[prefix]; ok {
			continue
		}
		seen[prefix] = struct{}{}
		cleaned = append(cleaned, prefix)
	}
	sort.Strings(cleaned)
	return cleaned
}

// publicationScope classifies one aggregate publication. A topology change
// needs the full tree (the spike showed a selective forget cannot reach an
// uncached ancestor); otherwise only the member prefixes whose generation
// moved this tick, falling back to full when no prefix can be named.
func publicationScope(membershipChanged bool, changes map[string]genChange) aggregateInvalidationScope {
	if membershipChanged {
		return fullAggregateInvalidation()
	}
	prefixes := make([]string, 0, len(changes))
	for prefix := range changes {
		prefixes = append(prefixes, prefix)
	}
	scope := memberAggregateInvalidation(prefixes...)
	if len(scope.prefixes) == 0 {
		return fullAggregateInvalidation()
	}
	return scope
}

func (s aggregateInvalidationScope) merge(other aggregateInvalidationScope) aggregateInvalidationScope {
	if s.full || other.full {
		return fullAggregateInvalidation()
	}
	all := append(append([]string(nil), s.prefixes...), other.prefixes...)
	return aggregateInvalidationScope{
		prefixes: normalizedInvalidationDirs(all),
		books:    normalizedInvalidationDirs(append(append([]string(nil), s.books...), other.books...)),
		assets:   normalizedInvalidationDirs(append(append([]string(nil), s.assets...), other.assets...)),
	}
}

func (s aggregateInvalidationScope) description() string {
	if s.full {
		return "whole cache"
	}
	return fmt.Sprintf("targeted: %d whole-library %s, %d book %s, %d asset %s",
		len(s.prefixes), plural(len(s.prefixes), "prefix", "prefixes"),
		len(s.books), plural(len(s.books), "directory", "directories"),
		len(s.assets), plural(len(s.assets), "directory", "directories"))
}

func (s aggregateInvalidationScope) directories(role string) []string {
	if s.full {
		return nil
	}
	dirs := append([]string(nil), s.prefixes...)
	if role == "books" {
		dirs = append(dirs, s.books...)
	} else {
		dirs = append(dirs, s.assets...)
	}
	return normalizedInvalidationDirs(dirs)
}

type aggregateVFSTarget struct {
	role string
	fs   string
}

type aggregateVFSInvalidator struct {
	targets []aggregateVFSTarget
	pending map[string]aggregateInvalidationScope
	forget  func(string, ...string) error
}

func newAggregateVFSInvalidator(vfs aggregateVFSResources) *aggregateVFSInvalidator {
	targets := make([]aggregateVFSTarget, 0, 2)
	if vfs.BooksFS != "" {
		targets = append(targets, aggregateVFSTarget{role: "books", fs: vfs.BooksFS})
	}
	if vfs.AssetsFS != "" {
		targets = append(targets, aggregateVFSTarget{role: "assets", fs: vfs.AssetsFS})
	}
	return &aggregateVFSInvalidator{
		targets: targets,
		pending: make(map[string]aggregateInvalidationScope),
		forget:  rclonexfer.ForgetVFSDirectories,
	}
}

func (i *aggregateVFSInvalidator) invalidate(scope aggregateInvalidationScope) {
	for _, target := range i.targets {
		next := scope
		if pending, ok := i.pending[target.role]; ok {
			next = pending.merge(next)
		}
		i.pending[target.role] = next
	}
	i.retry()
}

func (i *aggregateVFSInvalidator) retry() {
	for _, target := range i.targets {
		scope, ok := i.pending[target.role]
		if !ok {
			continue
		}
		dirs := scope.directories(target.role)
		if !scope.full && len(dirs) == 0 {
			// Nothing named on this plane is not the same request as "forget
			// everything": ForgetVFSDirectories treats a zero-length dirs as
			// the latter. An exact scope that only ever touched the other
			// plane (e.g. a catalog-only edit with no cover/format changes)
			// must resolve as a no-op here, not a full forget.
			delete(i.pending, target.role)
			continue
		}
		if err := i.forget(target.fs, dirs...); err != nil {
			log.Printf("fedlib share live: %s cache refresh (%s) failed; will retry: %v",
				target.role, scope.description(), err)
			continue
		}
		delete(i.pending, target.role)
		log.Printf("fedlib share live: %s cache refresh complete (%s)",
			target.role, scope.description())
	}
}

// aggregateGenerationToken is the exact 24-byte _GENERATION frame; equality is
// the publication identity the invalidation scope is bound to.
type aggregateGenerationToken [24]byte

func decodeAggregateGenerationToken(data []byte) (aggregateGenerationToken, error) {
	var token aggregateGenerationToken
	if _, _, err := torshare.DecodeGeneration(data); err != nil {
		return token, err
	}
	copy(token[:], data)
	return token, nil
}

// parts splits a decoded token; it cannot fail because the token was validated
// when it was decoded.
func (t aggregateGenerationToken) parts() (base [16]byte, gen uint64) {
	base, gen, _ = torshare.DecodeGeneration(t[:])
	return base, gen
}

func readAggregateGenerationToken(dir string) (aggregateGenerationToken, error) {
	data, err := os.ReadFile(filepath.Join(dir, libraryflow.GenerationPath))
	if err != nil {
		return aggregateGenerationToken{}, err
	}
	return decodeAggregateGenerationToken(data)
}

// aggregatePublicationIntent remembers the scope of the publication this
// poller produced so the matching remote generation can be invalidated
// selectively; any other generation degrades to a full forget.
type aggregatePublicationIntent struct {
	present bool
	token   aggregateGenerationToken
	scope   aggregateInvalidationScope
}

// record binds scope to the generation token the rebuild wrote. Scopes of
// publications not yet observed accumulate (full dominates), so a superseded
// generation still carries every changed prefix. A bind failure records the
// zero token with full scope, which no real generation can match.
func (i *aggregatePublicationIntent) record(token aggregateGenerationToken, scope aggregateInvalidationScope) {
	i.present = true
	i.token = token
	i.scope = i.scope.merge(scope)
}

func (i *aggregatePublicationIntent) consume(remote aggregateGenerationToken) aggregateInvalidationScope {
	scope := fullAggregateInvalidation()
	if i.present && i.token == remote {
		scope = i.scope
	}
	*i = aggregatePublicationIntent{}
	return scope
}
