package cmd

import "context"

var startTorFn func(ctx context.Context, localAddr, alias, configDir string) (
	onionHostname string, stopFn func() error, err error,
)

var startDualTorFn func(ctx context.Context, browserAddr, indexAddr, alias, configDir string, dualCfg DualOnionConfig) (
	DualOnionResult, error,
)
