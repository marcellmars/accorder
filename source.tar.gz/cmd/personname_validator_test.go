package cmd

import "testing"

// TestPersonnameValidator locks in the UX win: a librarian/friend name may now
// contain spaces and mixed case (e.g. "Marcell Mars"), preserved verbatim,
// while genuinely dangerous input (path separators, control chars) is rejected.
func TestPersonnameValidator(t *testing.T) {
	initValidator()

	valid := []string{
		"marcellmars",        // old alphanumunicode value still valid (back-compat)
		"Marcell Mars",       // the motivating case: space + mixed case
		"José N'Diaye-Smith", // unicode + apostrophe + hyphen
		"Иван Петров",        // non-latin unicode
		"X",                  // single char
		"a.b",                // dot
	}
	for _, s := range valid {
		if err := validate.Var(s, "required,personname"); err != nil {
			t.Errorf("personname(%q) should be valid, got: %v", s, err)
		}
	}

	invalid := []string{
		"",      // empty (required)
		"   ",   // whitespace only
		"a/b",   // forward slash
		"a\\b",  // backslash
		"a\nb",  // newline
		"a\tb",  // tab (control char)
		"a\x00", // NUL
	}
	for _, s := range invalid {
		if err := validate.Var(s, "required,personname"); err == nil {
			t.Errorf("personname(%q) should be invalid", s)
		}
	}

	// Friend uses omitempty,personname: empty is allowed, bad chars are not.
	if err := validate.Var("", "omitempty,personname"); err != nil {
		t.Errorf("omitempty,personname empty should pass, got: %v", err)
	}
	if err := validate.Var("Friend Name", "omitempty,personname"); err != nil {
		t.Errorf("omitempty,personname spaced should pass, got: %v", err)
	}
	if err := validate.Var("bad/name", "omitempty,personname"); err == nil {
		t.Errorf("omitempty,personname with slash should fail")
	}
}
