package cmd

import (
	"context"
	"errors"
	"fmt"
	"log"
	"net"
	"net/http"
	"os"
	"os/signal"
	"path/filepath"
	"strings"
	"sync"
	"syscall"
	"time"
)

const defaultHTTPShutdownGrace = 10 * time.Second
const forcedHTTPHandlerWait = time.Second

type DualOnionConfig struct {
	BrowserPublic bool
	IndexPublic   bool
}

type DualOnionResult struct {
	BrowserOnion string
	IndexOnion   string
	StopFn       func() error
}

type ServeOptions struct {
	CommandName    string
	ServiceName    string
	OnlyTor        bool
	OnlyHTTP       bool
	TorAlias       string
	StartTorFn     func(ctx context.Context, localAddr, alias, configDir string) (string, func() error, error)
	StartDualTorFn func(ctx context.Context, browserAddr, indexAddr, alias, configDir string, dualCfg DualOnionConfig) (DualOnionResult, error)
	DualOnionCfg   *DualOnionConfig
	BrowserMux     *http.ServeMux

	WarmUp            func(ctx context.Context) (mux, browserMux *http.ServeMux, err error)
	PreServe          func(ctx context.Context)
	SuppressListenLog bool
	OnShutdown        func()
	FriendHintFn      func(OnionAddrs, net.Addr) []string
	ShutdownGrace     time.Duration
}

type OnionAddrs struct {
	Single  string
	Browser string
	Index   string
}

func reconcileTorPublicAuthState(stateDir, mode string) error {
	sentinel := filepath.Join(stateDir, ".public")
	if mode != "public" {
		_ = os.Remove(sentinel)
		return nil
	}
	if err := os.MkdirAll(stateDir, 0o700); err != nil {
		return fmt.Errorf("mkdir tor state dir: %w", err)
	}
	if err := os.WriteFile(sentinel, []byte("public\n"), 0o644); err != nil {
		return fmt.Errorf("write .public sentinel: %w", err)
	}
	entries, _ := filepath.Glob(filepath.Join(stateDir, "authorized_clients", "*.auth"))
	for _, e := range entries {
		log.Printf("share live: --mode public: removing stale auth file %s", filepath.Base(e))
		if err := os.Remove(e); err != nil {
			return fmt.Errorf("--mode public: remove auth file %s: %w (public would be silently auth-gated)", filepath.Base(e), err)
		}
	}
	return nil
}

func printOnionBanner(lines ...string) {
	width := 0
	for _, l := range lines {
		if n := len([]rune(l)); n > width {
			width = n
		}
	}
	fmt.Fprintf(os.Stderr, "\n  ┌%s┐\n", strings.Repeat("─", width+4))
	for _, l := range lines {
		fmt.Fprintf(os.Stderr, "  │  %s%s  │\n", l, strings.Repeat(" ", width-len([]rune(l))))
	}
	fmt.Fprintf(os.Stderr, "  └%s┘\n\n", strings.Repeat("─", width+4))
}

func runShutdownPhase(commandName, phase string, fn func() error) error {
	started := time.Now()
	log.Printf("%s: shutdown phase %s started", commandName, phase)
	err := fn()
	elapsed := time.Since(started).Round(time.Millisecond)
	if err != nil {
		log.Printf("%s: shutdown phase %s failed after %s: %v", commandName, phase, elapsed, err)
		return err
	}
	log.Printf("%s: shutdown phase %s completed in %s", commandName, phase, elapsed)
	return nil
}

func runShutdownStep(commandName, phase string, fn func()) {
	_ = runShutdownPhase(commandName, phase, func() error {
		fn()
		return nil
	})
}

type trackedHTTPHandler struct {
	next   http.Handler
	mu     sync.Mutex
	active int
	idle   chan struct{}
}

func newTrackedHTTPHandler(next http.Handler) *trackedHTTPHandler {
	idle := make(chan struct{})
	close(idle)
	return &trackedHTTPHandler{next: next, idle: idle}
}

func (h *trackedHTTPHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	h.mu.Lock()
	if h.active == 0 {
		h.idle = make(chan struct{})
	}
	h.active++
	h.mu.Unlock()
	defer func() {
		h.mu.Lock()
		h.active--
		if h.active == 0 {
			close(h.idle)
		}
		h.mu.Unlock()
	}()
	if h.next == nil {
		http.DefaultServeMux.ServeHTTP(w, r)
		return
	}
	h.next.ServeHTTP(w, r)
}

func (h *trackedHTTPHandler) wait(timeout time.Duration) error {
	h.mu.Lock()
	idle := h.idle
	h.mu.Unlock()
	select {
	case <-idle:
		return nil
	case <-time.After(timeout):
		return fmt.Errorf("active HTTP handlers did not stop within %s after forced close", timeout)
	}
}

func serveHTTPWithTransport(ln net.Listener, mux *http.ServeMux, opts ServeOptions) error {

	var gate *readinessGate
	var handler http.Handler = mux
	if opts.WarmUp != nil {
		gate = &readinessGate{}
		handler = gate
	}
	trackedHandler := newTrackedHTTPHandler(handler)
	srv := &http.Server{Handler: trackedHandler}

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)
	defer signal.Stop(sigCh)
	serveLifetimeDone := make(chan struct{})
	defer close(serveLifetimeDone)
	signalShutdownStarted := make(chan struct{})
	signalShutdownDone := make(chan struct{})
	var signalShutdownErr error
	shutdownGrace := opts.ShutdownGrace
	if shutdownGrace <= 0 {
		shutdownGrace = defaultHTTPShutdownGrace
	}
	go func() {
		select {
		case <-sigCh:
			close(signalShutdownStarted)
			log.Printf("%s: shutting down...", opts.CommandName)
			cancel()
			signalShutdownErr = runShutdownPhase(opts.CommandName, "public-http-drain", func() error {
				shutdownCtx, shutdownCancel := context.WithTimeout(context.Background(), shutdownGrace)
				err := srv.Shutdown(shutdownCtx)
				shutdownCancel()
				if err == nil {
					return nil
				}
				if errors.Is(err, context.DeadlineExceeded) {
					log.Printf("%s: shutdown phase public-http-drain grace expired after %s; closing active connections", opts.CommandName, shutdownGrace)
					if closeErr := srv.Close(); closeErr != nil {
						return closeErr
					}
					return trackedHandler.wait(forcedHTTPHandlerWait)
				}
				closeErr := srv.Close()
				if closeErr != nil {
					return errors.Join(err, closeErr)
				}
				return err
			})
			close(signalShutdownDone)
		case <-serveLifetimeDone:
		}
	}()
	waitForSignalShutdown := func() error {
		select {
		case <-signalShutdownStarted:
			<-signalShutdownDone
			return signalShutdownErr
		default:
			return nil
		}
	}

	var serveErrCh chan error
	stopServing := func() {
		if serveErrCh != nil {
			_ = srv.Shutdown(context.Background())
			<-serveErrCh
			return
		}
		ln.Close()
	}

	if opts.WarmUp != nil {
		if !opts.OnlyTor && !opts.SuppressListenLog {
			log.Printf("%s: HTTP bound on %s (warming up)", opts.CommandName, ln.Addr())
		}
		serveErrCh = make(chan error, 1)
		go func() { serveErrCh <- srv.Serve(ln) }()

		warmMux, warmBrowserMux, werr := opts.WarmUp(ctx)
		if werr != nil {

			userAborted := ctx.Err() != nil
			cancel()
			shutdownErr := waitForSignalShutdown()
			if opts.OnShutdown != nil {
				runShutdownStep(opts.CommandName, "caller-background", opts.OnShutdown)
			}
			stopServing()
			if userAborted {
				return shutdownErr
			}

			return werr
		}
		if warmMux == nil {

			cancel()
			waitForSignalShutdown()
			if opts.OnShutdown != nil {
				runShutdownStep(opts.CommandName, "caller-background", opts.OnShutdown)
			}
			stopServing()
			return fmt.Errorf("%s: warm-up returned no mux", opts.CommandName)
		}
		mux = warmMux
		if warmBrowserMux != nil {
			opts.BrowserMux = warmBrowserMux
		}
		gate.setReady(mux)
	}

	var planeHandler http.Handler = mux
	if gate != nil {
		planeHandler = gate
	}

	if opts.PreServe != nil {
		opts.PreServe(ctx)
	}

	var torStopFn func() error
	var onionAddrs OnionAddrs
	wantTor := !opts.OnlyHTTP
	if wantTor {
		if opts.OnlyTor && opts.StartTorFn == nil {
			cancel()
			waitForSignalShutdown()
			if opts.OnShutdown != nil {
				runShutdownStep(opts.CommandName, "caller-background", opts.OnShutdown)
			}
			stopServing()
			return fmt.Errorf("%s: --only-tor requires building with -tags tor", opts.CommandName)
		}

		svcName := opts.ServiceName
		if svcName == "" {
			svcName = "the service"
		}

		dualSentinel := filepath.Join(accorderConfigDir, "tor", opts.TorAlias, ".serve-dual")
		if opts.DualOnionCfg != nil {
			_ = os.MkdirAll(filepath.Dir(dualSentinel), 0o700)
			_ = os.WriteFile(dualSentinel, []byte("1\n"), 0o644)
		} else {
			_ = os.Remove(dualSentinel)
		}

		if opts.DualOnionCfg != nil && opts.StartDualTorFn != nil {
			if !isLoopback(ln.Addr().String()) {
				log.Printf("%s: WARNING: listen address %s is not loopback; %s may be reachable without Tor",
					opts.CommandName, ln.Addr(), svcName)
			}
			indexTarget, indexSrv, ierr := startOnionPlane(planeHandler)
			if ierr != nil {
				cancel()
				waitForSignalShutdown()
				if opts.OnShutdown != nil {
					runShutdownStep(opts.CommandName, "caller-background", opts.OnShutdown)
				}
				stopServing()
				return fmt.Errorf("%s: index-plane listen: %w", opts.CommandName, ierr)
			}
			browserTarget := indexTarget
			var browserSrv *http.Server
			if opts.BrowserMux != nil {
				var berr error
				browserTarget, browserSrv, berr = startOnionPlane(opts.BrowserMux)
				if berr != nil {
					_ = indexSrv.Close()
					cancel()
					waitForSignalShutdown()
					if opts.OnShutdown != nil {
						runShutdownStep(opts.CommandName, "caller-background", opts.OnShutdown)
					}
					stopServing()
					return fmt.Errorf("%s: browser-plane listen: %w", opts.CommandName, berr)
				}
			}
			log.Printf("%s: starting tor dual-onion (may take up to 60s)...", opts.CommandName)
			result, err := opts.StartDualTorFn(ctx, browserTarget, indexTarget, opts.TorAlias, accorderConfigDir, *opts.DualOnionCfg)
			if err != nil {
				userAborted := ctx.Err() != nil
				if browserSrv != nil {
					_ = browserSrv.Close()
				}
				cancel()
				shutdownErr := waitForSignalShutdown()
				if opts.OnShutdown != nil {
					runShutdownStep(opts.CommandName, "caller-background", opts.OnShutdown)
				}
				stopServing()
				if userAborted {
					return shutdownErr
				}
				return fmt.Errorf("%s: start dual tor: %w", opts.CommandName, err)
			}
			torStopFn = func() error {
				_ = indexSrv.Close()
				if browserSrv != nil {
					_ = browserSrv.Close()
				}
				return result.StopFn()
			}
			log.Printf("%s: browser onion (public, browse only): http://%s/", opts.CommandName, result.BrowserOnion)
			log.Printf("%s: index onion (invite, full access):   http://%s/", opts.CommandName, result.IndexOnion)
			onionAddrs.Browser = result.BrowserOnion
			onionAddrs.Index = result.IndexOnion
			printOnionBanner(
				fmt.Sprintf("sharing %q via Tor (dual onion)", opts.TorAlias),
				"browser (public):  http://"+result.BrowserOnion+"/",
				"index (invite):    http://"+result.IndexOnion+"/",
			)
		} else if opts.StartTorFn != nil {
			if !isLoopback(ln.Addr().String()) {
				log.Printf("%s: WARNING: listen address %s is not loopback; %s may be reachable without Tor",
					opts.CommandName, ln.Addr(), svcName)
			}
			onionTarget, onionSrv, oerr := startOnionPlane(planeHandler)
			if oerr != nil {
				cancel()
				waitForSignalShutdown()
				if opts.OnShutdown != nil {
					runShutdownStep(opts.CommandName, "caller-background", opts.OnShutdown)
				}
				stopServing()
				return fmt.Errorf("%s: onion-plane listen: %w", opts.CommandName, oerr)
			}
			log.Printf("%s: starting tor (may take up to 60s)...", opts.CommandName)
			onion, stopFn, err := opts.StartTorFn(ctx, onionTarget, opts.TorAlias, accorderConfigDir)
			if err != nil {
				userAborted := ctx.Err() != nil
				_ = onionSrv.Close()
				cancel()
				shutdownErr := waitForSignalShutdown()
				if opts.OnShutdown != nil {
					runShutdownStep(opts.CommandName, "caller-background", opts.OnShutdown)
				}
				stopServing()
				if userAborted {
					return shutdownErr
				}
				return fmt.Errorf("%s: start tor: %w", opts.CommandName, err)
			}
			torStopFn = func() error {
				_ = onionSrv.Close()
				return stopFn()
			}
			onionAddrs.Single = onion
			log.Printf("%s: onion: http://%s/", opts.CommandName, onion)
			printOnionBanner(fmt.Sprintf("sharing %q at  http://%s/", opts.TorAlias, onion))
		}
	}

	if err := ctx.Err(); err != nil {
		cancel()
		shutdownErr := waitForSignalShutdown()
		if opts.OnShutdown != nil {
			runShutdownStep(opts.CommandName, "caller-background", opts.OnShutdown)
		}
		if torStopFn != nil {
			_ = runShutdownPhase(opts.CommandName, "tor-stop", torStopFn)
		}
		stopServing()
		return shutdownErr
	}

	if opts.WarmUp == nil && !opts.OnlyTor && !opts.SuppressListenLog {
		log.Printf("%s: HTTP bound on %s", opts.CommandName, ln.Addr())
	}
	if opts.FriendHintFn != nil {
		if hint := opts.FriendHintFn(onionAddrs, ln.Addr()); len(hint) > 0 {
			fmt.Fprintln(os.Stderr)
			for _, l := range hint {
				fmt.Fprintf(os.Stderr, "  %s\n", l)
			}
			fmt.Fprintln(os.Stderr)
		}
	}
	var serveErr error
	if serveErrCh != nil {
		serveErr = <-serveErrCh
	} else {
		serveErr = srv.Serve(ln)
	}

	cancel()
	shutdownErr := waitForSignalShutdown()
	if opts.OnShutdown != nil {
		runShutdownStep(opts.CommandName, "caller-background", opts.OnShutdown)
	}
	if torStopFn != nil {
		_ = runShutdownPhase(opts.CommandName, "tor-stop", torStopFn)
	}
	if serveErr != nil && !errors.Is(serveErr, http.ErrServerClosed) {
		return serveErr
	}
	return shutdownErr
}
