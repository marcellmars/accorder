package cmd

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"accorder/pkg/calibre"
	"accorder/pkg/libraryflow"
)

// This is a database change contract, not native filesystem evidence. Keeping
// Files empty in sourceEvidence makes older v2 readers refuse this record rather
// than misinterpret catalog stamps as native IDs. Existing v1/v2 history is
// imported; no librarian is asked to discard it or rehash unchanged formats.
type catalogSourceEvidence struct {
	Contract string                      `json:"contract"`
	Database libraryflow.Object          `json:"database"`
	Files    []calibre.SourceCatalogFile `json:"files"`
	// Selection binds a reusable build inventory to its exclusion policy.
	// Empty means a historical checkpoint; recovery still accepts it unchanged.
	Selection string `json:"selection,omitempty"`
}

func isCatalogEvidence(evidence *sourceEvidence) bool {
	return evidence != nil && evidence.Catalog != nil
}

func catalogDatabaseFingerprint(digest string) string {
	sum := sha256.Sum256([]byte(calibre.CatalogSourceContract + "\x00" + digest))
	return hex.EncodeToString(sum[:])
}

func sourceFingerprintForEvidence(ledger []libraryflow.Object, evidence *sourceEvidence) (string, error) {
	if isCatalogEvidence(evidence) {
		if err := validateCatalogEvidence(ledger, evidence); err != nil {
			return "", err
		}
		return catalogDatabaseFingerprint(evidence.Catalog.Database.Hash), nil
	}
	return sourceFingerprintFromContentLedger(ledger)
}

func readCatalogInventory(root string, database *buildDatabaseObservation) (*sourceInventory, error) {
	finish := beginLibraryWork("database-inventory")
	defer finish(1)
	if err := requireClosedCalibre(root); err != nil {
		return nil, err
	}
	files, err := calibre.ReadSourceCatalog(root)
	if err != nil {
		return nil, err
	}
	digest, err := hashLocalFile(filepath.Join(root, "metadata.db"))
	if err != nil {
		return nil, err
	}
	if err := verifyBuildDatabase(root, database); err != nil {
		return nil, err
	}
	object := database.Object
	object.Hash = digest
	result := &sourceInventory{Root: filepath.Clean(root), Catalog: &catalogSourceEvidence{Contract: calibre.CatalogSourceContract, Database: object, Files: files}}
	result.Objects = append(result.Objects, object)
	for _, file := range files {
		result.Objects = append(result.Objects, libraryflow.Object{Path: file.Path, Size: file.Size})
	}
	sort.Slice(result.Objects, func(i, j int) bool { return result.Objects[i].Path < result.Objects[j].Path })
	return result, nil
}

// At an independent validation boundary only the database must be re-observed.
// The saved catalog is usable iff that database still matches. A changed database
// is parsed afresh for build/attachment, never treated as the old snapshot.
func inventoryForEvidence(root string, evidence *sourceEvidence, ledger []libraryflow.Object) (*sourceInventory, error) {
	if isCatalogEvidence(evidence) {
		if err := verifyCatalogDatabase(root, evidence); err == nil {
			return &sourceInventory{Root: filepath.Clean(root), Objects: ledger, Catalog: evidence.Catalog}, nil
		}
		database, err := observeBuildDatabase(root)
		if err != nil {
			return nil, err
		}
		if database == nil {
			return nil, errors.New("Calibre database is missing or invalid; publication is stopped")
		}
		return readCatalogInventory(root, database)
	}
	if evidence != nil && !isCatalogEvidence(evidence) {
		// Only a retained native-evidence recovery may require its original
		// contract. New Calibre builds do not create this evidence.
		return parallelInventory(root, 16, true)
	}
	return scanSourceObjects(root)
}

func catalogSelection(excludes []string) string {
	raw, _ := json.Marshal(excludes)
	digest := sha256.Sum256(append([]byte("database-only-no-opf-v1\x00"), raw...))
	return hex.EncodeToString(digest[:])
}

// Build may reuse a filtered catalog only for the same exclusions. In
// particular, making a private book public must not reuse a catalog that
// omitted it. Historical checkpoints take one database-only migration pass;
// recovery uses inventoryForEvidence instead and retains its original paths.
func catalogInventoryForBuild(root string, evidence *sourceEvidence, ledger []libraryflow.Object, excludes []string) (*sourceInventory, error) {
	if isCatalogEvidence(evidence) {
		if evidence.Catalog.Selection == catalogSelection(excludes) {
			if err := requireSourceCoherence(root, ledger, evidence); err == nil {
				return inventoryForEvidence(root, evidence, ledger)
			}
		}
		database, err := observeBuildDatabase(root)
		if err != nil {
			return nil, err
		}
		if database == nil || !database.SQLite {
			return nil, errors.New("Calibre database is missing or invalid; rebuild is stopped")
		}
		return readCatalogInventory(root, database)
	}
	return scanSourceObjects(root)
}

func verifyCatalogDatabase(root string, evidence *sourceEvidence) error {
	if !isCatalogEvidence(evidence) || evidence.Catalog.Contract != calibre.CatalogSourceContract {
		return errors.New("unsupported Calibre change record")
	}
	if err := requireClosedCalibre(root); err != nil {
		return err
	}
	// No payload native signals are required. Hashing this one database also
	// works on filesystems without trustworthy native ChangeTime support.
	digest, err := hashLocalFile(filepath.Join(root, "metadata.db"))
	if err != nil {
		return err
	}
	if digest != evidence.Catalog.Database.Hash {
		return errors.New("Calibre database changed since the build; rebuild before publishing")
	}
	return nil
}

func buildCatalogEvidence(root string, inventory *sourceInventory, excludes []string, previous []libraryflow.Object, prior *sourceEvidence, seat string) ([]libraryflow.Object, *sourceEvidence, []string, []string, error) {
	if inventory == nil || inventory.Root != filepath.Clean(root) || inventory.Catalog == nil {
		return nil, nil, nil, nil, errors.New("Calibre catalog belongs to another source")
	}
	abs, err := filepath.Abs(root)
	if err != nil {
		return nil, nil, nil, nil, err
	}
	selection := catalogSelection(excludes)
	// inventoryForEvidence already rechecked the database at this boundary.
	// Reuse the immutable, validated selection rather than reconstructing the
	// same file tables. The caller still checks the current index and commit.
	if isCatalogEvidence(prior) && inventory.Catalog == prior.Catalog &&
		prior.Catalog.Selection == selection && prior.Provenance.Root == abs && prior.Provenance.Seat == seat {
		if err := validateCatalogEvidence(previous, prior); err != nil {
			return nil, nil, nil, nil, err
		}
		return previous, prior, nil, nil, nil
	}
	ledger, err := libraryflow.FilterSortedInventory(inventory.Objects, excludes, false)
	if err != nil {
		return nil, nil, nil, nil, err
	}
	catalog := *inventory.Catalog
	catalog.Files = nil
	catalog.Selection = selection
	for _, file := range inventory.Catalog.Files {
		if strings.HasSuffix(file.Path, "/metadata.opf") && file.Optional {
			// Attachment/recovery may still use historical OPF evidence. Do
			// not label it as a new OPF-free selection and reuse it in build.
			catalog.Selection = ""
			break
		}
	}
	rootID, _ := sourceLocalFileEvidence(root)
	evidence := &sourceEvidence{Provenance: sourceProvenance{Root: abs, Seat: seat, RootID: rootID}, Catalog: &catalog}
	var oldFiles []calibre.SourceCatalogFile
	if isCatalogEvidence(prior) {
		oldFiles = prior.Catalog.Files
	}
	oldDatabase := ""
	for _, object := range previous {
		if object.Path == "metadata.db" {
			oldDatabase = object.Hash
		}
	}
	var changed, removed []string
	currentIndex, oldFileIndex, oldObjectIndex := 0, 0, 0
	// All three inputs are sorted. Walk them together, retaining hashes and
	// deriving changes/removals without allocating full-library path maps.
	recordRemoval := func(object libraryflow.Object) {
		if !isCatalogEvidence(prior) {
			return
		}
		// Synthetic optional OPFs in the preceding database contract are
		// bookkeeping retirement, not payload deletions or cache changes.
		if strings.HasSuffix(object.Path, "/metadata.opf") {
			index := sort.Search(len(oldFiles), func(i int) bool { return oldFiles[i].Path >= object.Path })
			if index < len(oldFiles) && oldFiles[index].Path == object.Path && oldFiles[index].Optional {
				return
			}
		}
		removed = append(removed, object.Path)
	}
	for i := range ledger {
		object := &ledger[i]
		for oldObjectIndex < len(previous) && previous[oldObjectIndex].Path < object.Path {
			recordRemoval(previous[oldObjectIndex])
			oldObjectIndex++
		}
		var previousObject libraryflow.Object
		if oldObjectIndex < len(previous) && previous[oldObjectIndex].Path == object.Path {
			previousObject = previous[oldObjectIndex]
			oldObjectIndex++
		}
		if object.Path == "metadata.db" {
			object.Hash = catalog.Database.Hash
			if object.Hash != oldDatabase {
				changed = append(changed, object.Path)
			}
		} else {
			for currentIndex < len(inventory.Catalog.Files) && inventory.Catalog.Files[currentIndex].Path < object.Path {
				currentIndex++
			}
			if currentIndex == len(inventory.Catalog.Files) || inventory.Catalog.Files[currentIndex].Path != object.Path {
				return nil, nil, nil, nil, fmt.Errorf("file %s is not in the Calibre catalog", object.Path)
			}
			file := inventory.Catalog.Files[currentIndex]
			catalog.Files = append(catalog.Files, file)
			for oldFileIndex < len(oldFiles) && oldFiles[oldFileIndex].Path < file.Path {
				oldFileIndex++
			}
			found := oldFileIndex < len(oldFiles) && oldFiles[oldFileIndex].Path == file.Path
			var priorFile calibre.SourceCatalogFile
			if found {
				priorFile = oldFiles[oldFileIndex]
			}
			if isCatalogEvidence(prior) && (!found || priorFile != file) {
				changed = append(changed, file.Path)
			}
			// A legacy checkpoint has no database book stamps. Its old/new
			// index diff and retained pending paths supply the transition; do
			// not turn a schema upgrade into an all-payload overwrite.
			if previousObject.Path == file.Path && (priorFile == file || oldDatabase == catalog.Database.Hash) {
				object.Hash = previousObject.Hash
			}
		}
	}
	for ; oldObjectIndex < len(previous); oldObjectIndex++ {
		recordRemoval(previous[oldObjectIndex])
	}
	return ledger, evidence, changed, removed, validateCatalogEvidence(ledger, evidence)
}

func validateCatalogEvidence(ledger []libraryflow.Object, evidence *sourceEvidence) error {
	if evidence == nil {
		return errors.New("invalid Calibre change record")
	}
	c := evidence.Catalog
	if c == nil || c.Contract != calibre.CatalogSourceContract || len(evidence.Files) != 0 || evidence.Provenance.Root == "" || !filepath.IsAbs(evidence.Provenance.Root) || c.Database.Path != "metadata.db" {
		return errors.New("invalid Calibre change record")
	}
	if err := validateContentLedger([]libraryflow.Object{c.Database}); err != nil {
		return err
	}
	for i, file := range c.Files {
		if (i > 0 && c.Files[i-1].Path >= file.Path) || len(file.Stamp) != 64 || file.Size < 0 {
			return errors.New("invalid Calibre file record")
		}
		for _, digit := range file.Stamp {
			if !strings.ContainsRune("0123456789abcdefABCDEF", digit) {
				return errors.New("invalid Calibre file stamp")
			}
		}
	}
	metadata, previous := false, ""
	fileIndex := 0
	for _, object := range ledger {
		path, err := libraryflow.NormalizePath(object.Path)
		if err != nil || path != object.Path || path <= previous || !libraryflow.IsSourcePath(path) || object.Size < 0 {
			return errors.New("invalid Calibre publication path")
		}
		previous = path
		if path == "metadata.db" {
			metadata = object.Hash == c.Database.Hash && object.Size == c.Database.Size
		} else {
			if fileIndex == len(c.Files) || c.Files[fileIndex].Path != path || c.Files[fileIndex].Size != object.Size {
				return errors.New("Calibre catalog and publication paths disagree")
			}
			fileIndex++
		}
	}
	if !metadata || fileIndex != len(c.Files) {
		return errors.New("incomplete Calibre change record")
	}
	return nil
}

func localSourceFingerprintForContract(root string, excludes []string, contract string) (string, error) {
	switch contract {
	case "":
		fp, _, err := libraryflow.SourceFingerprint(root, excludes)
		return fp, err
	case calibre.CatalogSourceContract:
		digest, err := hashLocalFile(filepath.Join(root, "metadata.db"))
		if err != nil {
			return "", err
		}
		return catalogDatabaseFingerprint(digest), nil
	default:
		return "", errors.New("this publication uses an unsupported source-change contract; update Accorder")
	}
}

func catalogOptionalPath(evidence *sourceEvidence, path string) bool {
	if !isCatalogEvidence(evidence) {
		return false
	}
	files := evidence.Catalog.Files
	i := sort.Search(len(files), func(i int) bool { return files[i].Path >= path })
	return i < len(files) && files[i].Path == path && files[i].Optional
}

// A forced transfer is bounded to changed books. Validate each component so a
// catalog path cannot escape through a symlink after removal of the global walk.
func checkCatalogTransferPath(root, path string, optional bool) (bool, error) {
	normal, err := libraryflow.NormalizePath(path)
	if err != nil || normal != path {
		return false, fmt.Errorf("unsafe changed-book path %q", path)
	}
	current := root
	for _, component := range strings.Split(path, "/") {
		current = filepath.Join(current, component)
		info, err := os.Lstat(current)
		if os.IsNotExist(err) && optional {
			return false, nil
		}
		if err != nil {
			return false, err
		}
		if info.Mode()&os.ModeSymlink != 0 {
			return false, fmt.Errorf("refusing symlink in changed-book path %s", path)
		}
	}
	return true, nil
}
