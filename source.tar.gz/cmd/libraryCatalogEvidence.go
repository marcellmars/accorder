package cmd

import (
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"accorder/pkg/calibre"
	"accorder/pkg/libraryflow"
)

// This is a database change contract, not native filesystem evidence. Keeping
// Files empty in sourceEvidence makes older v2 readers refuse this record rather
// than misinterpret catalog stamps as native IDs. Existing v1/v2 history is
// imported; no librarian is asked to discard it or rehash unchanged formats.
type catalogSourceEvidence struct {
	Contract string                      `json:"contract"`
	Database libraryflow.Object          `json:"database"`
	Files    []calibre.SourceCatalogFile `json:"files"`
}

func isCatalogEvidence(evidence *sourceEvidence) bool {
	return evidence != nil && evidence.Catalog != nil
}

func catalogDatabaseFingerprint(digest string) string {
	sum := sha256.Sum256([]byte(calibre.CatalogSourceContract + "\x00" + digest))
	return hex.EncodeToString(sum[:])
}

func sourceFingerprintForEvidence(ledger []libraryflow.Object, evidence *sourceEvidence) (string, error) {
	if isCatalogEvidence(evidence) {
		if err := validateCatalogEvidence(ledger, evidence); err != nil {
			return "", err
		}
		return catalogDatabaseFingerprint(evidence.Catalog.Database.Hash), nil
	}
	return sourceFingerprintFromContentLedger(ledger)
}

func readCatalogInventory(root string, database *buildDatabaseObservation) (*sourceInventory, error) {
	finish := beginLibraryWork("database-inventory")
	defer finish(1)
	if err := requireClosedCalibre(root); err != nil {
		return nil, err
	}
	files, err := calibre.ReadSourceCatalog(root)
	if err != nil {
		return nil, err
	}
	digest, err := hashLocalFile(filepath.Join(root, "metadata.db"))
	if err != nil {
		return nil, err
	}
	if err := verifyBuildDatabase(root, database); err != nil {
		return nil, err
	}
	object := database.Object
	object.Hash = digest
	result := &sourceInventory{Root: filepath.Clean(root), Catalog: &catalogSourceEvidence{Contract: calibre.CatalogSourceContract, Database: object, Files: files}}
	result.Objects = append(result.Objects, object)
	for _, file := range files {
		result.Objects = append(result.Objects, libraryflow.Object{Path: file.Path, Size: file.Size})
	}
	sort.Slice(result.Objects, func(i, j int) bool { return result.Objects[i].Path < result.Objects[j].Path })
	return result, nil
}

// At an independent validation boundary only the database must be re-observed.
// The saved catalog is usable iff that database still matches. A changed database
// is parsed afresh for build/attachment, never treated as the old snapshot.
func inventoryForEvidence(root string, evidence *sourceEvidence, ledger []libraryflow.Object) (*sourceInventory, error) {
	if isCatalogEvidence(evidence) {
		if err := verifyCatalogDatabase(root, evidence); err == nil {
			return &sourceInventory{Root: filepath.Clean(root), Objects: ledger, Catalog: evidence.Catalog}, nil
		}
		database, err := observeBuildDatabase(root)
		if err != nil {
			return nil, err
		}
		if database == nil {
			return nil, errors.New("Calibre database is missing or invalid; publication is stopped")
		}
		return readCatalogInventory(root, database)
	}
	if evidence != nil && !isCatalogEvidence(evidence) {
		// Only a retained native-evidence recovery may require its original
		// contract. New Calibre builds do not create this evidence.
		return parallelInventory(root, 16, true)
	}
	return scanSourceObjects(root)
}

func verifyCatalogDatabase(root string, evidence *sourceEvidence) error {
	if !isCatalogEvidence(evidence) || evidence.Catalog.Contract != calibre.CatalogSourceContract {
		return errors.New("unsupported Calibre change record")
	}
	if err := requireClosedCalibre(root); err != nil {
		return err
	}
	// No payload native signals are required. Hashing this one database also
	// works on filesystems without trustworthy native ChangeTime support.
	digest, err := hashLocalFile(filepath.Join(root, "metadata.db"))
	if err != nil {
		return err
	}
	if digest != evidence.Catalog.Database.Hash {
		return errors.New("Calibre database changed since the build; rebuild before publishing")
	}
	return nil
}

func buildCatalogEvidence(root string, inventory *sourceInventory, excludes []string, previous []libraryflow.Object, prior *sourceEvidence, seat string) ([]libraryflow.Object, *sourceEvidence, []string, []string, error) {
	if inventory.Root != filepath.Clean(root) || inventory.Catalog == nil {
		return nil, nil, nil, nil, errors.New("Calibre catalog belongs to another source")
	}
	ledger, err := libraryflow.FilterInventory(inventory.Objects, excludes, false)
	if err != nil {
		return nil, nil, nil, nil, err
	}
	abs, err := filepath.Abs(root)
	if err != nil {
		return nil, nil, nil, nil, err
	}
	catalog := *inventory.Catalog
	catalog.Files = nil
	rootID, _ := sourceLocalFileEvidence(root)
	evidence := &sourceEvidence{Provenance: sourceProvenance{Root: abs, Seat: seat, RootID: rootID}, Catalog: &catalog}
	currentFiles := make(map[string]calibre.SourceCatalogFile, len(inventory.Catalog.Files))
	for _, file := range inventory.Catalog.Files {
		currentFiles[file.Path] = file
	}
	oldFiles := make(map[string]calibre.SourceCatalogFile)
	if isCatalogEvidence(prior) {
		for _, file := range prior.Catalog.Files {
			oldFiles[file.Path] = file
		}
	}
	old := make(map[string]libraryflow.Object, len(previous))
	oldDatabase := ""
	for _, object := range previous {
		old[object.Path] = object
		if object.Path == "metadata.db" {
			oldDatabase = object.Hash
		}
	}
	var changed, removed []string
	for i := range ledger {
		object := &ledger[i]
		if object.Path == "metadata.db" {
			object.Hash = catalog.Database.Hash
			if object.Hash != oldDatabase {
				changed = append(changed, object.Path)
			}
		} else {
			file, ok := currentFiles[object.Path]
			if !ok {
				return nil, nil, nil, nil, fmt.Errorf("file %s is not in the Calibre catalog", object.Path)
			}
			catalog.Files = append(catalog.Files, file)
			priorFile, found := oldFiles[file.Path]
			if isCatalogEvidence(prior) && (!found || priorFile != file) {
				changed = append(changed, file.Path)
			}
			// A legacy checkpoint has no database book stamps. Its old/new
			// index diff and retained pending paths supply the transition; do
			// not turn a schema upgrade into an all-payload overwrite.
			if previousObject, exists := old[file.Path]; exists && (priorFile == file || oldDatabase == catalog.Database.Hash) {
				object.Hash = previousObject.Hash
			}
		}
		delete(old, object.Path)
	}
	if isCatalogEvidence(prior) {
		for path := range old {
			removed = append(removed, path)
		}
	}
	sort.Strings(removed)
	return ledger, evidence, changed, removed, validateCatalogEvidence(ledger, evidence)
}

func validateCatalogEvidence(ledger []libraryflow.Object, evidence *sourceEvidence) error {
	c := evidence.Catalog
	if c == nil || c.Contract != calibre.CatalogSourceContract || len(evidence.Files) != 0 || evidence.Provenance.Root == "" || !filepath.IsAbs(evidence.Provenance.Root) || c.Database.Path != "metadata.db" {
		return errors.New("invalid Calibre change record")
	}
	if err := validateContentLedger([]libraryflow.Object{c.Database}); err != nil {
		return err
	}
	files := make(map[string]calibre.SourceCatalogFile, len(c.Files))
	for _, file := range c.Files {
		if _, exists := files[file.Path]; exists || len(file.Stamp) != 64 || file.Size < 0 {
			return errors.New("invalid Calibre file record")
		}
		if _, err := hex.DecodeString(file.Stamp); err != nil {
			return err
		}
		files[file.Path] = file
	}
	metadata, previous := false, ""
	for _, object := range ledger {
		path, err := libraryflow.NormalizePath(object.Path)
		if err != nil || path != object.Path || path <= previous || !libraryflow.IsSourcePath(path) || object.Size < 0 {
			return errors.New("invalid Calibre publication path")
		}
		previous = path
		if path == "metadata.db" {
			metadata = object.Hash == c.Database.Hash && object.Size == c.Database.Size
		} else {
			file, ok := files[path]
			if !ok || file.Size != object.Size {
				return errors.New("Calibre catalog and publication paths disagree")
			}
			delete(files, path)
		}
	}
	if !metadata || len(files) != 0 {
		return errors.New("incomplete Calibre change record")
	}
	return nil
}

func localSourceFingerprintForContract(root string, excludes []string, contract string) (string, error) {
	switch contract {
	case "":
		fp, _, err := libraryflow.SourceFingerprint(root, excludes)
		return fp, err
	case calibre.CatalogSourceContract:
		digest, err := hashLocalFile(filepath.Join(root, "metadata.db"))
		if err != nil {
			return "", err
		}
		return catalogDatabaseFingerprint(digest), nil
	default:
		return "", errors.New("this publication uses an unsupported source-change contract; update Accorder")
	}
}

func catalogOptionalPath(evidence *sourceEvidence, path string) bool {
	if !isCatalogEvidence(evidence) {
		return false
	}
	files := evidence.Catalog.Files
	i := sort.Search(len(files), func(i int) bool { return files[i].Path >= path })
	return i < len(files) && files[i].Path == path && files[i].Optional
}

// A forced transfer is bounded to changed books. Validate each component so a
// catalog path cannot escape through a symlink after removal of the global walk.
func checkCatalogTransferPath(root, path string, optional bool) (bool, error) {
	normal, err := libraryflow.NormalizePath(path)
	if err != nil || normal != path {
		return false, fmt.Errorf("unsafe changed-book path %q", path)
	}
	current := root
	for _, component := range strings.Split(path, "/") {
		current = filepath.Join(current, component)
		info, err := os.Lstat(current)
		if os.IsNotExist(err) && optional {
			return false, nil
		}
		if err != nil {
			return false, err
		}
		if info.Mode()&os.ModeSymlink != 0 {
			return false, fmt.Errorf("refusing symlink in changed-book path %s", path)
		}
	}
	return true, nil
}
