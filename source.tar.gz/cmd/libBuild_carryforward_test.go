//go:build !tailscale

package cmd

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"

	"accorder/pkg/calibre"
)

// seedCmdJSONLWithFingerprints writes a JSONL fixture with cover fingerprints pre-populated.
func seedCmdJSONLWithFingerprints(t *testing.T, path, libraryID, librarian string, n int) {
	t.Helper()
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		t.Fatal(err)
	}
	f, err := os.Create(path)
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()
	w := bufio.NewWriter(f)
	defer w.Flush()
	for i := 0; i < n; i++ {

		// Create a non-zero fingerprint for each book.
		var fp [calibre.FingerprintSize]byte
		fp[0] = byte(i + 1)
		fp[1] = byte(i + 2)
		fp[2] = byte(i + 3)
		fp[3] = byte(i + 4)
		fp[4] = byte(i + 5)
		fp[5] = byte(i + 6)

		book := calibre.Book{
			Title:            fmt.Sprintf("Book %d", i),
			Authors:          []string{"Author"},
			LastModified:     fmt.Sprintf("2024-01-%02dT00:00:00+00:00", (i%28)+1),
			LibraryUUID:      libraryID,
			Librarian:        librarian,
			UUID:             fmt.Sprintf("book-uuid-%d", i),
			CoverFingerprint: calibre.EncodeFingerprintBase64(fp),
		}
		data, err := json.Marshal(book)
		if err != nil {
			t.Fatal(err)
		}
		_, _ = w.Write(data)
		_ = w.WriteByte('\n')
	}
}

func TestCarryForward_Hit(t *testing.T) {
	libDir := testSetup(t)

	// Step 1: Build an index with fingerprints pre-populated in the JSONL.
	jsonlPath := filepath.Join(accorderConfigDir, "cache", "cfhit.jsonl")
	seedCmdJSONLWithFingerprints(t, jsonlPath, mintTestUUID, "Alice", 5)

	build := &LibBuildCmd{}
	build.ActionAlias = "cfhit"
	build.CalibreDirectory = libDir
	build.Librarian = "Alice"
	build.LibraryID = mintTestUUID
	build.Index = new(bool)
	if err := build.Run(nil); err != nil {
		t.Fatalf("initial build: %v", err)
	}

	// Verify the index was created.
	indexZst := filepath.Join(libDir, "static", "library_index.zst")
	if _, err := os.Stat(indexZst); err != nil {
		t.Fatalf("expected index at %s: %v", indexZst, err)
	}

	// Read the prior index to verify fingerprints are stored.
	priorBooks, err := calibre.AllBooksFromIndex(filepath.Join(libDir, "static", "library_index"))
	if err != nil {
		t.Fatalf("read prior index: %v", err)
	}
	if len(priorBooks) != 5 {
		t.Fatalf("prior index has %d books, want 5", len(priorBooks))
	}
	priorFPs := make(map[string]string)
	for _, b := range priorBooks {
		if b.CoverFingerprint != "" {
			priorFPs[b.Id] = b.CoverFingerprint
		}
	}
	if len(priorFPs) != 5 {
		t.Fatalf("prior index has %d fingerprints, want 5", len(priorFPs))
	}

	// Step 2: Rebuild from JSONL *without* fingerprints. No cover files exist.
	// Without carry-forward, books would have no fingerprints.
	// With carry-forward, they should get the fingerprints from the prior index.
	jsonlPath2 := filepath.Join(accorderConfigDir, "cache", "cfhit.jsonl")
	seedCmdJSONL(t, jsonlPath2, mintTestUUID, "Alice", 5)

	build2 := &LibBuildCmd{}
	build2.ActionAlias = "cfhit"
	build2.CalibreDirectory = libDir
	build2.Librarian = "Alice"
	build2.LibraryID = mintTestUUID
	build2.Index = new(bool)
	if err := build2.Run(nil); err != nil {
		t.Fatalf("rebuild: %v", err)
	}

	// Read the rebuilt index and verify fingerprints were carried forward.
	rebuiltBooks, err := calibre.AllBooksFromIndex(filepath.Join(libDir, "static", "library_index"))
	if err != nil {
		t.Fatalf("read rebuilt index: %v", err)
	}
	for _, b := range rebuiltBooks {
		want, ok := priorFPs[b.Id]
		if !ok {
			t.Errorf("book %q not found in prior fingerprints", b.Id)
			continue
		}
		if b.CoverFingerprint != want {
			t.Errorf("book %q: fingerprint = %q, want %q (carry-forward failed)", b.Id, b.CoverFingerprint, want)
		}
	}
}

func TestCarryForward_Miss(t *testing.T) {
	libDir := testSetup(t)

	// Step 1: Build an index with 3 books that have fingerprints.
	jsonlPath := filepath.Join(accorderConfigDir, "cache", "cfmiss.jsonl")
	seedCmdJSONLWithFingerprints(t, jsonlPath, mintTestUUID, "Alice", 3)

	build := &LibBuildCmd{}
	build.ActionAlias = "cfmiss"
	build.CalibreDirectory = libDir
	build.Librarian = "Alice"
	build.LibraryID = mintTestUUID
	build.Index = new(bool)
	if err := build.Run(nil); err != nil {
		t.Fatalf("initial build: %v", err)
	}

	// Capture fingerprints from the prior index.
	priorBooks, err := calibre.AllBooksFromIndex(filepath.Join(libDir, "static", "library_index"))
	if err != nil {
		t.Fatalf("read prior index: %v", err)
	}
	priorFPs := make(map[string]string)
	for _, b := range priorBooks {
		if b.CoverFingerprint != "" {
			priorFPs[b.Id] = b.CoverFingerprint
		}
	}

	// Step 2: Rebuild with 5 books (3 original + 2 new), no fingerprints in JSONL.
	seedCmdJSONL(t, jsonlPath, mintTestUUID, "Alice", 5)

	build2 := &LibBuildCmd{}
	build2.ActionAlias = "cfmiss"
	build2.CalibreDirectory = libDir
	build2.Librarian = "Alice"
	build2.LibraryID = mintTestUUID
	build2.Index = new(bool)
	if err := build2.Run(nil); err != nil {
		t.Fatalf("rebuild: %v", err)
	}

	// Read rebuilt index.
	rebuiltBooks, err := calibre.AllBooksFromIndex(filepath.Join(libDir, "static", "library_index"))
	if err != nil {
		t.Fatalf("read rebuilt index: %v", err)
	}

	var hits, misses int
	for _, b := range rebuiltBooks {
		if want, ok := priorFPs[b.Id]; ok {

			// Original book: should carry forward.
			if b.CoverFingerprint != want {
				t.Errorf("original book %q: fingerprint = %q, want %q", b.Id, b.CoverFingerprint, want)
			}
			hits++
		} else {

			// New book: no cover file, so fingerprint should be empty.
			if b.CoverFingerprint != "" {
				t.Errorf("new book %q: fingerprint = %q, want empty", b.Id, b.CoverFingerprint)
			}
			misses++
		}
	}
	if hits != 3 {
		t.Errorf("carry-forward hits = %d, want 3", hits)
	}
	if misses != 2 {
		t.Errorf("carry-forward misses = %d, want 2", misses)
	}
}

func TestCarryForward_CompactBypass(t *testing.T) {
	libDir := testSetup(t)

	// Step 1: Build an index with fingerprints.
	jsonlPath := filepath.Join(accorderConfigDir, "cache", "cfcompact.jsonl")
	seedCmdJSONLWithFingerprints(t, jsonlPath, mintTestUUID, "Alice", 5)

	build := &LibBuildCmd{}
	build.ActionAlias = "cfcompact"
	build.CalibreDirectory = libDir
	build.Librarian = "Alice"
	build.LibraryID = mintTestUUID
	build.Index = new(bool)
	if err := build.Run(nil); err != nil {
		t.Fatalf("initial build: %v", err)
	}

	// Step 2: Rebuild with --compact from JSONL *without* fingerprints.
	// Carry-forward should be skipped (c.Compact != nil).
	// No cover files exist, so all fingerprints should be empty after rebuild.
	seedCmdJSONL(t, jsonlPath, mintTestUUID, "Alice", 5)

	build2 := &LibBuildCmd{}
	build2.ActionAlias = "cfcompact"
	build2.CalibreDirectory = libDir
	build2.Librarian = "Alice"
	build2.LibraryID = mintTestUUID
	build2.Index = new(bool)
	build2.Compact = new(bool)
	if err := build2.Run(nil); err != nil {
		t.Fatalf("compact rebuild: %v", err)
	}

	// Read rebuilt index: all fingerprints should be empty (carry-forward was skipped).
	rebuiltBooks, err := calibre.AllBooksFromIndex(filepath.Join(libDir, "static", "library_index"))
	if err != nil {
		t.Fatalf("read rebuilt index: %v", err)
	}
	for _, b := range rebuiltBooks {
		if b.CoverFingerprint != "" {
			t.Errorf("compact rebuild: book %q has fingerprint %q, want empty (carry-forward should be skipped)", b.Id, b.CoverFingerprint)
		}
	}
}
