package cmd

import (
	"os"
	"path/filepath"
	"testing"
)

// setTestConfigHome sets XDG_CONFIG_HOME so os.UserConfigDir() returns tmpDir.
func setTestConfigHome(t *testing.T, tmpDir string) {
	t.Helper()
	t.Setenv("XDG_CONFIG_HOME", tmpDir)
}

// ═══════════════════════════════════════════════════════════════════
// parseAccorderIni — the legacy accorder.ini calibrepath "help"
// ═══════════════════════════════════════════════════════════════════

func TestParseAccorderIni_CalibreSections(t *testing.T) {
	tmpDir := t.TempDir()
	setTestConfigHome(t, tmpDir)

	iniDir := filepath.Join(tmpDir, AppName)
	_ = os.MkdirAll(iniDir, 0755)
	// parseAccorderIni reads accorder.ini from the active config dir.
	accorderConfigDir = iniDir

	iniContent := `[biopolitics_calibre]
library_uuid = uuid-bio-123
local_directory = /home/user/Calibre Library
librarian = Alice
library_secret = secret123

[poetry_calibre]
library_uuid = uuid-poetry-456
local_directory = /home/user/Poetry
librarian = Bob
library_secret = secret456

[not_calibre_section]
library_uuid = should-be-ignored
local_directory = /ignored
`
	_ = os.WriteFile(filepath.Join(iniDir, "accorder.ini"), []byte(iniContent), 0644)

	result, err := parseAccorderIni()
	if err != nil {
		t.Fatalf("parseAccorderIni: %v", err)
	}

	if len(result) != 2 {
		t.Fatalf("expected 2 entries, got %d", len(result))
	}

	if result["uuid-bio-123"] != "/home/user/Calibre Library" {
		t.Errorf("biopolitics entry: got %q", result["uuid-bio-123"])
	}
	if result["uuid-poetry-456"] != "/home/user/Poetry" {
		t.Errorf("poetry entry: got %q", result["uuid-poetry-456"])
	}
	if _, ok := result["should-be-ignored"]; ok {
		t.Errorf("non-calibre section should be ignored")
	}
}

func TestParseAccorderIni_MissingFileReturnsNil(t *testing.T) {
	tmpDir := t.TempDir()
	setTestConfigHome(t, tmpDir)

	iniDir := filepath.Join(tmpDir, AppName)
	_ = os.MkdirAll(iniDir, 0755)
	accorderConfigDir = iniDir
	// No accorder.ini written.

	result, err := parseAccorderIni()
	if err != nil {
		t.Fatalf("parseAccorderIni: %v", err)
	}
	if result != nil {
		t.Errorf("expected nil result for missing file, got %v", result)
	}
}

// ═══════════════════════════════════════════════════════════════════
// findCalibreLibraries — the config find-calibre scanner
// ═══════════════════════════════════════════════════════════════════

func TestFindCalibreLibraries_FindsMetadataDB(t *testing.T) {
	tmpDir := t.TempDir()

	// Create a fake Calibre library with the SQLite magic header.
	libDir := filepath.Join(tmpDir, "MyLibrary")
	_ = os.MkdirAll(libDir, 0755)
	sqliteMagic := []byte("SQLite format 3\x00")
	_ = os.WriteFile(filepath.Join(libDir, "metadata.db"), sqliteMagic, 0644)

	results, err := findCalibreLibraries(tmpDir)
	if err != nil {
		t.Fatalf("findCalibreLibraries: %v", err)
	}
	if len(results) != 1 {
		t.Fatalf("expected 1 result, got %d", len(results))
	}
	if results[0] != libDir {
		t.Errorf("expected %q, got %q", libDir, results[0])
	}
}

func TestFindCalibreLibraries_SkipsNonSQLite(t *testing.T) {
	tmpDir := t.TempDir()

	// metadata.db without the SQLite magic header.
	libDir := filepath.Join(tmpDir, "FakeLib")
	_ = os.MkdirAll(libDir, 0755)
	_ = os.WriteFile(filepath.Join(libDir, "metadata.db"), []byte("not sqlite data"), 0644)

	results, err := findCalibreLibraries(tmpDir)
	if err != nil {
		t.Fatalf("findCalibreLibraries: %v", err)
	}
	if len(results) != 0 {
		t.Errorf("expected 0 results for non-SQLite metadata.db, got %d", len(results))
	}
}

func TestFindCalibreLibraries_SkipsHiddenAndSkipList(t *testing.T) {
	tmpDir := t.TempDir()

	// Libraries buried under hidden / skip-list dirs must be ignored.
	for _, dir := range []string{".hidden", "node_modules", "Trash"} {
		libDir := filepath.Join(tmpDir, dir, "SomeLib")
		_ = os.MkdirAll(libDir, 0755)
		_ = os.WriteFile(filepath.Join(libDir, "metadata.db"), []byte("SQLite format 3\x00"), 0644)
	}

	// A valid library that should be found.
	goodDir := filepath.Join(tmpDir, "GoodLib")
	_ = os.MkdirAll(goodDir, 0755)
	_ = os.WriteFile(filepath.Join(goodDir, "metadata.db"), []byte("SQLite format 3\x00"), 0644)

	results, err := findCalibreLibraries(tmpDir)
	if err != nil {
		t.Fatalf("findCalibreLibraries: %v", err)
	}
	if len(results) != 1 {
		t.Errorf("expected 1 result (only GoodLib), got %d: %v", len(results), results)
	}
}

func TestFindCalibreLibraries_DoesNotDescendIntoMatchedLib(t *testing.T) {
	tmpDir := t.TempDir()

	// A Calibre lib nested inside another: only the outer should match.
	outerLib := filepath.Join(tmpDir, "OuterLib")
	innerLib := filepath.Join(outerLib, "subdir", "InnerLib")
	_ = os.MkdirAll(innerLib, 0755)
	sqliteMagic := []byte("SQLite format 3\x00")
	_ = os.WriteFile(filepath.Join(outerLib, "metadata.db"), sqliteMagic, 0644)
	_ = os.WriteFile(filepath.Join(innerLib, "metadata.db"), sqliteMagic, 0644)

	results, err := findCalibreLibraries(tmpDir)
	if err != nil {
		t.Fatalf("findCalibreLibraries: %v", err)
	}
	// SkipDir stops descent once the outer match is found.
	if len(results) != 1 {
		t.Errorf("expected 1 result (outer only), got %d: %v", len(results), results)
	}
}
