package cmd

import (
	"accorder/pkg/calibre"
	"os"
	"path/filepath"
	"testing"

	"github.com/goccy/go-json"
)

// ---------------------------------------------------------------------------
// Phase 1 tests: LibraryMeta extensions, HasRcloneMembers, local dispatch,
// RequireS3Creds, fedlib members add --local-path.
// ---------------------------------------------------------------------------

func TestLibraryMeta_IsLocal(t *testing.T) {
	tests := []struct {
		name string
		meta calibre.LibraryMeta
		want bool
	}{
		{"local", calibre.LibraryMeta{Kind: "local"}, true},
		{"rclone", calibre.LibraryMeta{Kind: "rclone"}, false},
		{"empty (backward compat)", calibre.LibraryMeta{}, false},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := tt.meta.IsLocal(); got != tt.want {
				t.Errorf("IsLocal() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestHasRcloneMembers(t *testing.T) {
	tests := []struct {
		name     string
		registry map[string]calibre.LibraryMeta
		want     bool
	}{
		{
			"all local",
			map[string]calibre.LibraryMeta{
				"a": {Kind: "local"},
				"b": {Kind: "local"},
			},
			false,
		},
		{
			"all rclone",
			map[string]calibre.LibraryMeta{
				"a": {Kind: "rclone"},
				"b": {},
			},
			true,
		},
		{
			"mixed",
			map[string]calibre.LibraryMeta{
				"a": {Kind: "local"},
				"b": {Kind: "rclone"},
			},
			true,
		},
		{
			// An invited S3 member must trigger rclone setup + poller so its
			// first publish can be detected and reconciled (G2/G4).
			// The invited:<prefix> keys below are a deliberate LEGACY fixture
			// (registries written by pre-mint binaries) — the check is
			// state-based and key-agnostic, so both key shapes must work
			// (operator-minted-member-uuid).
			"invited-only rclone",
			map[string]calibre.LibraryMeta{
				"invited:alice": {Prefix: "alice", State: "invited"},
			},
			true,
		},
		{
			"local plus invited rclone",
			map[string]calibre.LibraryMeta{
				"a":             {Kind: "local"},
				"invited:alice": {Prefix: "alice", State: "invited"},
			},
			true,
		},
		{
			"disabled rclone only",
			map[string]calibre.LibraryMeta{
				"a": {Prefix: "z", State: "disabled"},
			},
			false,
		},
		{
			"empty backward compat",
			map[string]calibre.LibraryMeta{
				"a": {}, // empty kind => rclone
			},
			true,
		},
		{
			"empty registry",
			map[string]calibre.LibraryMeta{},
			false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := calibre.HasRcloneMembers(tt.registry); got != tt.want {
				t.Errorf("HasRcloneMembers() = %v, want %v", got, tt.want)
			}
		})
	}
}

func TestRequireS3Creds_Build(t *testing.T) {
	t.Run("all set", func(t *testing.T) {
		cmd := &FedlibBuildCmd{
			Bucket:      "b",
			S3AccessKey: "ak",
			S3SecretKey: "sk",
			S3Provider:  "p",
			S3Endpoint:  "e",
		}
		if err := cmd.RequireS3Creds(); err != nil {
			t.Errorf("expected no error, got %v", err)
		}
	})

	t.Run("missing bucket", func(t *testing.T) {
		cmd := &FedlibBuildCmd{
			S3AccessKey: "ak",
			S3SecretKey: "sk",
			S3Provider:  "p",
			S3Endpoint:  "e",
		}
		if err := cmd.RequireS3Creds(); err == nil {
			t.Error("expected error for missing bucket")
		}
	})

	t.Run("missing access key", func(t *testing.T) {
		cmd := &FedlibBuildCmd{
			Bucket:      "b",
			S3SecretKey: "sk",
			S3Provider:  "p",
			S3Endpoint:  "e",
		}
		if err := cmd.RequireS3Creds(); err == nil {
			t.Error("expected error for missing access key")
		}
	})
}

func TestRequireS3Creds_ShareLive(t *testing.T) {
	t.Run("all set", func(t *testing.T) {
		cmd := &FedlibShareLiveCmd{
			Bucket:      "b",
			S3AccessKey: "ak",
			S3SecretKey: "sk",
			S3Provider:  "p",
			S3Endpoint:  "e",
		}
		if err := cmd.RequireS3Creds(); err != nil {
			t.Errorf("expected no error, got %v", err)
		}
	})

	t.Run("missing endpoint", func(t *testing.T) {
		cmd := &FedlibShareLiveCmd{
			Bucket:      "b",
			S3AccessKey: "ak",
			S3SecretKey: "sk",
			S3Provider:  "p",
		}
		if err := cmd.RequireS3Creds(); err == nil {
			t.Error("expected error for missing endpoint")
		}
	})
}

func TestFedlibMembersAdd_LocalPath(t *testing.T) {
	root := t.TempDir()
	registryDir := filepath.Join(root, "config")
	if err := os.MkdirAll(registryDir, 0o755); err != nil {
		t.Fatal(err)
	}

	// Create a valid local library directory with the expected index file.
	libDir := filepath.Join(root, "mylib")
	seedLocalLibrary(t, filepath.Join(libDir, "static"), 3, "TestLib", "uuid-test-1111", "mylib")

	// seedLocalLibrary creates library_index.zst inside the given dir,
	// so the index is at libDir/static/library_index.zst.

	// Write an empty registry.
	registryPath := filepath.Join(registryDir, "aggregate_libraries.json")
	if err := os.WriteFile(registryPath, []byte("{}"), 0o644); err != nil {
		t.Fatal(err)
	}

	// Save and restore accorderConfigDir.
	origConfigDir := accorderConfigDir
	accorderConfigDir = registryDir
	defer func() { accorderConfigDir = origConfigDir }()

	t.Run("add local member", func(t *testing.T) {
		cmd := &FedlibMembersAddCmd{
			UUID:      "uuid-test-1111",
			Librarian: "TestLib",
			LocalPath: libDir,
		}
		if err := cmd.Run(); err != nil {
			t.Fatalf("Run() error: %v", err)
		}

		// Read back and verify.
		data, err := os.ReadFile(registryPath)
		if err != nil {
			t.Fatal(err)
		}
		var reg map[string]calibre.LibraryMeta
		if err := json.Unmarshal(data, &reg); err != nil {
			t.Fatal(err)
		}
		meta, ok := reg["uuid-test-1111"]
		if !ok {
			t.Fatal("member not found in registry")
		}
		if meta.Kind != "local" {
			t.Errorf("Kind = %q, want %q", meta.Kind, "local")
		}
		if meta.LocalPath != libDir {
			t.Errorf("LocalPath = %q, want %q", meta.LocalPath, libDir)
		}
		if meta.Prefix != "mylib" {
			t.Errorf("Prefix = %q, want %q (basename of local-path)", meta.Prefix, "mylib")
		}
	})

	t.Run("reject duplicate prefix", func(t *testing.T) {
		cmd := &FedlibMembersAddCmd{
			UUID:      "uuid-dupe-2222",
			Librarian: "Dupe",
			LocalPath: libDir,
		}
		if err := cmd.Run(); err == nil {
			t.Error("expected error for duplicate prefix")
		}
	})

	t.Run("add local with explicit prefix", func(t *testing.T) {
		cmd := &FedlibMembersAddCmd{
			UUID:      "uuid-custom-3333",
			Librarian: "Custom",
			Prefix:    "custom-prefix",
			LocalPath: libDir,
		}
		if err := cmd.Run(); err != nil {
			t.Fatalf("Run() error: %v", err)
		}

		data, err := os.ReadFile(registryPath)
		if err != nil {
			t.Fatal(err)
		}
		var reg map[string]calibre.LibraryMeta
		if err := json.Unmarshal(data, &reg); err != nil {
			t.Fatal(err)
		}
		meta := reg["uuid-custom-3333"]
		if meta.Prefix != "custom-prefix" {
			t.Errorf("Prefix = %q, want %q", meta.Prefix, "custom-prefix")
		}
	})

	t.Run("reject relative local path", func(t *testing.T) {
		cmd := &FedlibMembersAddCmd{
			UUID:      "uuid-rel-4444",
			Librarian: "Rel",
			LocalPath: "relative/path",
		}
		if err := cmd.Run(); err == nil {
			t.Error("expected error for relative path")
		}
	})

	t.Run("reject missing index", func(t *testing.T) {
		emptyDir := t.TempDir()
		cmd := &FedlibMembersAddCmd{
			UUID:      "uuid-noindex-5555",
			Librarian: "NoIndex",
			LocalPath: emptyDir,
		}
		if err := cmd.Run(); err == nil {
			t.Error("expected error for missing static/library_index.zst")
		}
	})

	t.Run("rclone member requires prefix", func(t *testing.T) {
		cmd := &FedlibMembersAddCmd{
			UUID:      "uuid-rclone-6666",
			Librarian: "RcloneNoPrefix",
		}
		if err := cmd.Run(); err == nil {
			t.Error("expected error for rclone member without --prefix")
		}
	})
}

func TestLibraryMeta_JSONRoundtrip(t *testing.T) {

	// Verify new fields serialize/deserialize correctly with omitempty.
	meta := calibre.LibraryMeta{
		Librarian: "Alice",
		Prefix:    "alice",
		Kind:      "local",
		LocalPath: "/data/alice",
	}
	data, err := json.Marshal(meta)
	if err != nil {
		t.Fatal(err)
	}

	var got calibre.LibraryMeta
	if err := json.Unmarshal(data, &got); err != nil {
		t.Fatal(err)
	}
	if got.Kind != "local" {
		t.Errorf("Kind = %q, want %q", got.Kind, "local")
	}
	if got.LocalPath != "/data/alice" {
		t.Errorf("LocalPath = %q, want %q", got.LocalPath, "/data/alice")
	}

	// Verify omitempty: rclone member without Kind/LocalPath should not have those keys.
	rcloneMeta := calibre.LibraryMeta{
		Librarian: "Bob",
		Prefix:    "bob",
	}
	rcloneData, err := json.Marshal(rcloneMeta)
	if err != nil {
		t.Fatal(err)
	}
	rcloneStr := string(rcloneData)
	if contains(rcloneStr, "kind") {
		t.Errorf("rclone meta should not contain 'kind' key, got: %s", rcloneStr)
	}
	if contains(rcloneStr, "local_path") {
		t.Errorf("rclone meta should not contain 'local_path' key, got: %s", rcloneStr)
	}
}

func contains(s, substr string) bool {
	return len(s) >= len(substr) && searchString(s, substr)
}

func searchString(s, substr string) bool {
	for i := 0; i <= len(s)-len(substr); i++ {
		if s[i:i+len(substr)] == substr {
			return true
		}
	}
	return false
}

// ---------------------------------------------------------------------------
// Phase 2 tests: per-fedlib registry, state machine.
// ---------------------------------------------------------------------------

func TestMemberState_BackwardCompat(t *testing.T) {

	// Verify that the state machine handles legacy values.
	tests := []struct {
		state    string
		isActive bool
	}{
		{"", true},      // legacy enabled
		{"ready", true}, // new enabled
		{"off", false},  // legacy disabled
		{"disabled", false},
		{"invited", false},
		{"retired", false},
	}
	for _, tt := range tests {
		tt := tt
		t.Run("state="+tt.state, func(t *testing.T) {
			got := isMemberActive(tt.state)
			if got != tt.isActive {
				t.Errorf("isMemberActive(%q) = %v, want %v", tt.state, got, tt.isActive)
			}
		})
	}
}

func TestLoadMembersRegistryFromPath(t *testing.T) {
	root := t.TempDir()
	registryPath := filepath.Join(root, "members.json")

	// Non-existent file returns empty registry.
	reg, path, err := loadMembersRegistryFromPath(registryPath)
	if err != nil {
		t.Fatal(err)
	}
	if len(reg) != 0 {
		t.Errorf("empty registry: got %d entries, want 0", len(reg))
	}
	if path != registryPath {
		t.Errorf("path = %q, want %q", path, registryPath)
	}

	// Write and read back.
	testReg := map[string]calibre.LibraryMeta{
		"uuid-1": {Librarian: "Alice", Prefix: "alice", Kind: "local", LocalPath: "/data/alice"},
	}
	data, _ := json.MarshalIndent(testReg, "", "  ")
	if err := os.WriteFile(registryPath, data, 0o644); err != nil {
		t.Fatal(err)
	}

	reg, _, err = loadMembersRegistryFromPath(registryPath)
	if err != nil {
		t.Fatal(err)
	}
	if reg["uuid-1"].Kind != "local" {
		t.Errorf("Kind = %q, want %q", reg["uuid-1"].Kind, "local")
	}
}
