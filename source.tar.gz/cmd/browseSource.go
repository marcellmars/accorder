package cmd

import (
	"accorder/pkg/calibre"
	"accorder/pkg/secrets"
	"errors"
	"fmt"
	"log"
	"os"
	"path/filepath"

	"github.com/tidwall/gjson"
	"github.com/tidwall/sjson"
)

var browseSourceKeys = []string{"onion", "endpoint", "publisher-type", "source-label", "source-uuid"}

func browseBearerKey(alias string) string     { return alias + "/browse/bearer-token" }
func browseClientAuthKey(alias string) string { return alias + "/browse/client-auth-key" }

func persistBrowseSource(alias, onion, endpoint, publisherType, sourceLabel string) {
	unlockAliasCfg := lockAliasConfigOrDie()
	defer unlockAliasCfg()
	configBytes := loadActionAliases()
	for _, k := range browseSourceKeys {
		configBytes, _ = sjson.DeleteBytes(configBytes, alias+".lib.browse."+k)
	}
	set := func(key, value string) {
		if value != "" {
			configBytes, _ = sjson.SetBytes(configBytes, alias+".lib.browse."+key, value)
		}
	}
	set("onion", onion)
	set("endpoint", endpoint)
	set("publisher-type", publisherType)
	set("source-label", sourceLabel)
	saveActionAliases(configBytes)
}

func loadBrowseSource(alias string) (onion, endpoint, publisherType, sourceLabel string) {
	configBytes := loadActionAliases()
	get := func(key string) string {
		return gjson.GetBytes(configBytes, alias+".lib.browse."+key).String()
	}
	return get("onion"), get("endpoint"), get("publisher-type"), get("source-label")
}

func persistBrowseAuth(alias, scheme, token, keyPrivB32 string) error {
	store, err := resolveBrowseSecretsStore()
	if err != nil {
		return fmt.Errorf("browse: secrets store: %w", err)
	}
	if verr := store.Verify(); verr != nil {
		return browseSecretsUnusableErr(verr)
	}

	type entry struct{ name, value string }
	var entries []entry
	switch scheme {
	case "bearer":
		if token != "" {
			entries = append(entries, entry{browseBearerKey(alias), token})
		}
	case "x25519":
		if keyPrivB32 != "" {
			entries = append(entries, entry{browseClientAuthKey(alias), keyPrivB32})
		}
	}
	for _, e := range entries {
		if err := store.Set(e.name, e.value); err != nil {
			return fmt.Errorf("browse: store %s: %w", e.name, err)
		}
	}
	if len(entries) > 0 {
		fmt.Fprintf(os.Stderr, "browse: auth credential stored in %s (encrypted)\n", secretsStorePath())
	}
	return nil
}

func loadBrowseAuth(alias, onion string) (scheme, token, keyPrivB32 string, err error) {
	store, err := resolveBrowseSecretsStore()
	if err != nil {
		return "", "", "", fmt.Errorf("browse: secrets store: %w", err)
	}

	if verr := store.Verify(); verr != nil {
		return "", "", "", browseSecretsUnusableErr(verr)
	}

	if onion != "" {
		key, gerr := store.Get(browseClientAuthKey(alias))
		if gerr != nil {
			// No stored auth = a public source. The store file may be absent
			// (os.IsNotExist) or present-but-without-this-key (ErrKeyNotFound);
			// both mean "browse it unauthenticated", not a fatal error.
			if os.IsNotExist(gerr) || errors.Is(gerr, secrets.ErrKeyNotFound) {
				return "", "", "", nil
			}
			return "", "", "", fmt.Errorf("browse: read client-auth key: %w", gerr)
		}
		return "x25519", "", key, nil
	}

	tok, gerr := store.Get(browseBearerKey(alias))
	if gerr != nil {
		// A public clearnet source stores no bearer token. As with the onion
		// branch, a missing key (file absent OR key absent) means "public",
		// not failure — this is the bare-re-run path a friend takes after
		// pasting a public share line.
		if os.IsNotExist(gerr) || errors.Is(gerr, secrets.ErrKeyNotFound) {
			return "", "", "", nil
		}
		return "", "", "", fmt.Errorf("browse: read bearer token: %w", gerr)
	}
	return "bearer", tok, "", nil
}

func browseSecretsUnusableErr(verr error) error {
	return fmt.Errorf("browse: secrets store %s is not usable: %w\n"+
		"  supply its passphrase via ACCORDER_SECRETS_PASSPHRASE,\n"+
		"  or convert it to passphrase-free (key-file) mode with 'accorder secrets rekey'",
		secretsStorePath(), verr)
}

func resolveBrowseSecretsStore() (*secrets.Store, error) {
	return resolveJoinSecretsStore("")
}

func persistBrowseSourceUUID(alias, uuid string) {
	if uuid == "" {
		return
	}
	unlockAliasCfg := lockAliasConfigOrDie()
	defer unlockAliasCfg()
	configBytes := loadActionAliases()
	configBytes, _ = sjson.SetBytes(configBytes, alias+".lib.browse.source-uuid", uuid)
	saveActionAliases(configBytes)
	log.Printf("[CFG] browse source UUID %s saved for alias %q", uuid, alias)
}

func offlineCacheDir(alias, cacheBase string) (string, error) {
	uuid := gjson.GetBytes(loadActionAliases(), alias+".lib.browse.source-uuid").String()
	if uuid != "" {
		return filepath.Join(cacheBase, uuid), nil
	}
	_, endpoint, _, _ := loadBrowseSource(alias)
	if endpoint != "" {
		if _, entry, ok := registryFindByEndpoint(endpoint); ok && entry.UUID != "" {
			log.Printf("[CFG] offline: resolved uuid %s from registry for endpoint %s", entry.UUID, endpoint)
			return filepath.Join(cacheBase, entry.UUID), nil
		}
	}
	// A never-browsed alias may name a registered source directly (e.g. after
	// `lib index add <name>` pre-fetched the index): resolve its cached UUID.
	if entry, ok := registryGet(calibre.SlugifySourceName(alias)); ok && entry.UUID != "" {
		log.Printf("[CFG] offline: resolved uuid %s from registry source %q", entry.UUID, alias)
		return filepath.Join(cacheBase, entry.UUID), nil
	}
	aliasDir := filepath.Join(cacheBase, alias)
	if _, err := os.Stat(filepath.Join(aliasDir, "static")); err == nil {
		return aliasDir, nil
	}
	return "", fmt.Errorf("browse --offline: no cached library for alias %q "+
		"(run online at least once first)", alias)
}
