//go:build !tailscale && !tor

package cmd

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"

	"github.com/tidwall/gjson"
	"github.com/tidwall/sjson"
)

// ═══════════════════════════════════════════════════════════════════
// Spike: fedlib-serve-descriptor — Phase 0 validation
//
// Hypothesis 1: Removing storage flags from FedlibShareLiveCmd doesn't
// break action-alias persistence for existing aliases.
//
// Hypothesis 2: The invite's offer dir path resolves identically whether
// serve_alias comes from a flag or the descriptor.
// ═══════════════════════════════════════════════════════════════════

// TestSpike_AliasLoadIgnoresUnknownFields validates that an alias persisted
// with fields that no longer exist on the struct (e.g. s3-access-key,
// s3-secret-key) loads without error via json.Unmarshal.
//
// Background: AfterApply (cli.go:253) does json.Unmarshal(aliasData, c).
// Go's json.Unmarshal silently drops unknown keys by default. If this ever
// changes (e.g. someone adds DisallowUnknownFields), this test will catch it.
func TestSpike_AliasLoadIgnoresUnknownFields(t *testing.T) {
	testSetup(t)

	// Simulate an alias with fields that no longer exist on the struct
	// (e.g. bucket, upload-prefix — now populated from the descriptor, not CLI).
	// We use synthetic unknown fields to avoid triggering migrateAliasCredentials.
	aliasJSON := `{
		"fedlib": {
			"share": {
				"live": {
					"aggregate-path": "/tmp/agg",
					"fedlib-id": "motw",
					"listen": "127.0.0.1:8723",
					"removed-storage-flag": "some-value",
					"another-removed-flag": "another-value"
				}
			}
		}
	}`

	// Write it as a saved alias.
	configBytes, _ := sjson.SetRawBytes([]byte("{}"), "motw", []byte(aliasJSON))
	if err := os.WriteFile(savedActionAliases, configBytes, 0o644); err != nil {
		t.Fatal(err)
	}

	// ca-125: live serve validates descriptor existence at parse time.
	if err := saveFedlibDescriptor("motw", fedlibDescriptor{Version: fedlibDescriptorVersion}); err != nil {
		t.Fatal(err)
	}

	// Parse via Kong, which triggers AfterApply → json.Unmarshal.
	cli, _ := parseCLI(t, []string{"fedlib", "share", "live", "motw",
		"--aggregate-path", "/tmp/agg"})

	// The critical assertion: the serve loaded the known fields correctly
	// despite the alias containing unknown fields.
	live := cli.Fedlib.Share.Live
	if live.AggregatePath != "/tmp/agg" {
		t.Errorf("AggregatePath: got %q, want /tmp/agg", live.AggregatePath)
	}
	if live.Listen != "127.0.0.1:8723" {
		t.Errorf("Listen: got %q, want 127.0.0.1:8723", live.Listen)
	}
}

// TestSpike_AliasLoadIgnoresUnknownFields_DirectUnmarshal does a lower-level
// check: unmarshal JSON with extra fields directly into FedlibShareLiveCmd.
// This isolates the Go json behavior from the Kong machinery.
func TestSpike_AliasLoadIgnoresUnknownFields_DirectUnmarshal(t *testing.T) {
	// JSON with fields that exist on the struct plus fields that don't.
	// Storage-identity fields (bucket, s3-provider, etc.) are now kong:"-"
	// without json tags, so they won't unmarshal from alias JSON — that's
	// the desired behavior (they come from the descriptor now).
	data := []byte(`{
		"aggregate-path": "/tmp/agg",
		"fedlib-id": "motw",
		"bucket": "mybucket",
		"s3-access-key": "AKIAIOSFODNN7EXAMPLE",
		"s3-secret-key": "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
		"s3-provider": "Wasabi",
		"s3-endpoint": "https://s3.wasabisys.com",
		"keys-file": "/keys/motw.s3.keys",
		"listen": "127.0.0.1:8723",
		"mode": "public",
		"unknown-future-field": "whatever"
	}`)

	var cmd FedlibShareLiveCmd
	err := json.Unmarshal(data, &cmd)
	if err != nil {
		t.Fatalf("json.Unmarshal must not fail on unknown fields: %v", err)
	}
	if cmd.AggregatePath != "/tmp/agg" {
		t.Errorf("AggregatePath: got %q, want /tmp/agg", cmd.AggregatePath)
	}
	if cmd.Listen != "127.0.0.1:8723" {
		t.Errorf("Listen: got %q, want 127.0.0.1:8723", cmd.Listen)
	}
}

// TestSpike_AliasUnknownFieldsPreservedInConfig verifies that loading an alias
// with truly unknown fields does NOT strip those fields from the persisted JSON.
// AfterApply only writes *provided* flags (not the full struct), so keys that
// don't map to any struct field survive in the JSON untouched.
//
// Note: S3 credential fields (s3-access-key, s3-secret-key) are NOT good test
// subjects here because migrateAliasCredentials deliberately strips them from
// the alias file and moves them to a .keys file. We use synthetic unknown
// fields instead.
func TestSpike_AliasUnknownFieldsPreservedInConfig(t *testing.T) {
	testSetup(t)

	aliasJSON := `{
		"fedlib": {
			"share": {
				"live": {
					"aggregate-path": "/tmp/agg",
					"fedlib-id": "motw",
					"listen": "127.0.0.1:8723",
					"removed-future-field": "should-survive",
					"another-unknown": 42
				}
			}
		}
	}`

	configBytes, _ := sjson.SetRawBytes([]byte("{}"), "motw", []byte(aliasJSON))
	if err := os.WriteFile(savedActionAliases, configBytes, 0o644); err != nil {
		t.Fatal(err)
	}

	// ca-125: live serve validates descriptor existence at parse time.
	if err := saveFedlibDescriptor("motw", fedlibDescriptor{Version: fedlibDescriptorVersion}); err != nil {
		t.Fatal(err)
	}

	// Parse without providing any new flags (beyond the required ones).
	// The alias's stale "fedlib-id" key is itself an unknown field now and
	// must survive the round-trip like the synthetic ones.
	parseCLI(t, []string{"fedlib", "share", "live", "motw",
		"--aggregate-path", "/tmp/agg"})

	// Re-read the alias file — the unknown keys must still be present.
	after, err := os.ReadFile(savedActionAliases)
	if err != nil {
		t.Fatal(err)
	}
	futureField := gjson.GetBytes(after, `motw.fedlib.share.live.removed-future-field`).String()
	if futureField != "should-survive" {
		t.Errorf("removed-future-field lost after parse: got %q", futureField)
	}
	anotherUnknown := gjson.GetBytes(after, `motw.fedlib.share.live.another-unknown`).Int()
	if anotherUnknown != 42 {
		t.Errorf("another-unknown lost after parse: got %d", anotherUnknown)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Hypothesis 2: Offer-dir path derivation
// ═══════════════════════════════════════════════════════════════════

// TestSpike_OfferDirPathEquivalence verifies that the invite's offer-dir
// path (using c.ServeAlias from the descriptor) matches the serve's
// InviteOffersDir (using c.ActionAlias).
//
// The invite writes to:
//
//	filepath.Join(accorderConfigDir, "clearnet", c.ServeAlias, "invites")
//	[fedlibMembersInvite.go:337]
//
// The serve reads from:
//
//	filepath.Join(accorderConfigDir, "clearnet", c.ActionAlias, "invites")
//	[fedlibShareLive.go:176]
//
// For offers to work, the invite's --serve-alias must equal the serve's
// action alias. When serve_alias is recalled from the descriptor, it must
// have been persisted as the serve's action alias name.
func TestSpike_OfferDirPathEquivalence(t *testing.T) {
	testSetup(t)

	serveAlias := "motw" // the action alias used by `fedlib share live motw`

	// Path the invite would use (serve_alias comes from descriptor).
	invitePath := filepath.Join(accorderConfigDir, "clearnet", serveAlias, "invites")

	// Path the serve uses (ActionAlias from CommonCommandFields).
	servePath := filepath.Join(accorderConfigDir, "clearnet", serveAlias, "invites")

	if invitePath != servePath {
		t.Errorf("path mismatch:\n  invite: %s\n  serve:  %s", invitePath, servePath)
	}

	// Also verify against inviteOffersDir helper.
	helperPath := inviteOffersDir(serveAlias)
	if helperPath != servePath {
		t.Errorf("inviteOffersDir mismatch:\n  helper: %s\n  serve:  %s", helperPath, servePath)
	}
}

// TestSpike_DescriptorServeAliasRecalledForOfferDir verifies the full flow:
// 1. Save a descriptor with serve_alias = "motw"
// 2. Create an invite that recalls serve_alias from the descriptor
// 3. The offer lands in the directory the serve would read from
func TestSpike_DescriptorServeAliasRecalledForOfferDir(t *testing.T) {
	testSetup(t)

	// Seed descriptor with serve_alias.
	keysPath := filepath.Join(accorderConfigDir, "test_root.keys")
	if err := os.WriteFile(keysPath, []byte("access-key=AK\nsecret-key=SK\n"), 0o600); err != nil {
		t.Fatal(err)
	}
	desc := fedlibDescriptor{
		Version:      fedlibDescriptorVersion,
		Bucket:       "testbucket",
		S3Provider:   "Wasabi",
		S3Endpoint:   "https://s3.wasabisys.com",
		Endpoint:     "https://motw.example.com",
		RootKeysFile: keysPath,
	}
	if err := saveFedlibDescriptor("testfed", desc); err != nil {
		t.Fatal(err)
	}

	// One name: BOTH the invite and the serve derive the offers dir from the
	// federation id itself — the serve_alias indirection is gone.
	inviteDir := inviteOffersDir("testfed")

	// The serve's ActionAlias IS the federation id.
	serveDir := filepath.Join(accorderConfigDir, "clearnet", "testfed", "invites")

	if inviteDir != serveDir {
		t.Errorf("offer dir mismatch when using descriptor serve_alias:\n  invite: %s\n  serve:  %s",
			inviteDir, serveDir)
	}
}

// TestSpike_OfferDirMismatchDetected is a negative test: if someone stores a
// different serve_alias in the descriptor than the actual serve's action alias,
// offers would be written to the wrong directory. This test documents that
// footgun — there is no runtime guard against it.
func TestSpike_OfferDirMismatchDetected(t *testing.T) {
	testSetup(t)

	// Descriptor says serve_alias = "wrong-alias" but serve runs as "motw".
	wrongAlias := "wrong-alias"
	serveAlias := "motw"

	inviteDir := filepath.Join(accorderConfigDir, "clearnet", wrongAlias, "invites")
	serveDir := filepath.Join(accorderConfigDir, "clearnet", serveAlias, "invites")

	if inviteDir == serveDir {
		t.Error("expected mismatch when serve_alias != action alias, but paths match")
	}
	// This documents the risk: no runtime validation prevents a stale/wrong
	// serve_alias in the descriptor from causing offers to be invisible to the serve.
}
