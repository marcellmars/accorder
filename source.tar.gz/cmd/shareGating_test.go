package cmd

// Route-gating matrix tests for `lib share live` and `fedlib share live`.
//
// These assert the mode × plane access table from
// .sit/docs/accorder/SHARE_ACCESS_MODES.md: in `private` mode the browser plane
// (SPA shell, embedded static assets, catalog metadata, /static/data*.js) is
// capability-gated exactly like the index plane, while /redeem stays open in
// every mode so a friend can bootstrap. `public` keeps the browser plane
// anonymous.
//
// Following .sit/howto/route_table_zero_value_testing.md, the fedlib mux is
// built over a zero-value serveState: the denied direction (401 without a
// capability) is answered by withAuth before any state-backed handler body
// runs, so no MWSC fixture is needed. The "opens with a capability" direction
// is asserted on state-free routes (the SPA shell and an embedded asset) plus,
// for lib, a real file-backed /static/data1.js.

import (
	"accorder/pkg/calibre"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func gatingTestReg(t *testing.T) *grantRegistry {
	t.Helper()
	reg, err := newGrantRegistry(t.TempDir())
	if err != nil {
		t.Fatalf("newGrantRegistry: %v", err)
	}
	return reg
}

// redeemCookie mints a token, redeems it through the real /redeem handler, and
// returns the resulting signed cookie — the exact bootstrap a browser friend
// performs.
func redeemCookie(t *testing.T, reg *grantRegistry, token string) *http.Cookie {
	t.Helper()
	rec := httptest.NewRecorder()
	makeRedeemHandler(reg).ServeHTTP(rec, httptest.NewRequest("GET", "/redeem?token="+token, nil))
	if rec.Code != http.StatusOK {
		t.Fatalf("redeem: got %d, want 200", rec.Code)
	}
	cookies := rec.Result().Cookies()
	if len(cookies) == 0 {
		t.Fatal("redeem: no Set-Cookie")
	}
	return cookies[0]
}

func codeFor(mux *http.ServeMux, path string, cookie *http.Cookie) int {
	req := httptest.NewRequest("GET", path, nil)
	if cookie != nil {
		req.AddCookie(cookie)
	}
	rec := httptest.NewRecorder()
	mux.ServeHTTP(rec, req)
	return rec.Code
}

func buildFedlibTestMux(t *testing.T, mode string, reg *grantRegistry) *http.ServeMux {
	t.Helper()
	meter := &sessionMeter{window: time.Hour, granularity: time.Minute, maxSessions: 100, maxDistinct: 50}
	breaker, err := newEgressBreaker(egressBreakerConfig{})
	if err != nil {
		t.Fatalf("newEgressBreaker: %v", err)
	}
	mux := http.NewServeMux()
	// Mirrors setupAggregateServe's mux wiring (frontend + aggregate routes).
	calibre.RegisterFrontendRoutesGated(mux, nil, browserPlaneWrap(reg, mode))
	registerAggregateRoutes(mux, &serveState{}, aggregateVFSAddresses{}, meter, breaker, reg, mode, "", nil, false)
	return mux
}

func TestFedlibShareGating_Private(t *testing.T) {
	reg := gatingTestReg(t)
	token, err := reg.issue("alice", nil)
	if err != nil {
		t.Fatal(err)
	}
	mux := buildFedlibTestMux(t, "private", reg)

	// Every browser- and index-plane route is denied without a capability.
	// (withAuth answers 401 before the state-backed handler body runs.)
	gated := []string{
		"/",                         // SPA shell
		"/static/js/bundle.js",      // embedded static asset
		"/search",                   // catalog metadata
		"/books",                    // catalog metadata
		"/static/data1.js",          // synthesized catalog
		"/static/library_index.zst", // index plane
		"/static/library_index.jsonl.zst",
	}
	for _, p := range gated {
		if code := codeFor(mux, p, nil); code != http.StatusUnauthorized {
			t.Errorf("private %s without capability: got %d, want 401", p, code)
		}
	}

	// /redeem is open in private.
	if code := codeFor(mux, "/redeem?token="+token, nil); code != http.StatusOK {
		t.Errorf("/redeem in private: got %d, want 200", code)
	}

	// A redeemed capability opens the browser plane. Asserted on the
	// state-free routes; state-backed catalog routes need an index fixture and
	// are covered for the "opens" direction by the lib data1.js test below.
	cookie := redeemCookie(t, reg, token)
	for _, p := range []string{"/", "/static/js/bundle.js"} {
		if code := codeFor(mux, p, cookie); code != http.StatusOK {
			t.Errorf("private %s with capability: got %d, want 200", p, code)
		}
	}
}

func TestFedlibShareGating_Public(t *testing.T) {
	reg := gatingTestReg(t)
	token, err := reg.issue("alice", nil)
	if err != nil {
		t.Fatal(err)
	}
	mux := buildFedlibTestMux(t, "public", reg)

	// Browser plane is anonymous in public (state-free routes).
	for _, p := range []string{"/", "/static/js/bundle.js"} {
		if code := codeFor(mux, p, nil); code != http.StatusOK {
			t.Errorf("public %s: got %d, want 200 anonymous", p, code)
		}
	}
	// /redeem still open (mints the classing cookie for metered public shares).
	if code := codeFor(mux, "/redeem?token="+token, nil); code != http.StatusOK {
		t.Errorf("/redeem in public: got %d, want 200", code)
	}
}

func TestFedlibShareGating_OfflinePrivate(t *testing.T) {
	reg := gatingTestReg(t)
	if _, err := reg.issue("alice", nil); err != nil {
		t.Fatal(err)
	}
	mux := buildFedlibTestMux(t, "offline-private", reg)

	// Browser plane open, index plane gated.
	for _, p := range []string{"/", "/static/js/bundle.js"} {
		if code := codeFor(mux, p, nil); code != http.StatusOK {
			t.Errorf("offline-private %s: got %d, want 200 anonymous", p, code)
		}
	}
	for _, p := range []string{"/static/library_index.zst", "/static/library_index.jsonl.zst"} {
		if code := codeFor(mux, p, nil); code != http.StatusUnauthorized {
			t.Errorf("offline-private %s without capability: got %d, want 401", p, code)
		}
	}
}

// TestLibShareGating_BrowserPlane exercises the lib share live browser-plane
// wiring (RegisterFrontendRoutesGated + applyWrap over a real file server), so
// the "opens with a capability" direction is asserted on a genuine 200 for both
// the SPA shell and /static/data1.js.
func TestLibShareGating_BrowserPlane(t *testing.T) {
	dir := t.TempDir()
	if err := os.MkdirAll(filepath.Join(dir, "static"), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(dir, "static", "data1.js"), []byte("CALIBRE_BOOKS1=[]"), 0o644); err != nil {
		t.Fatal(err)
	}
	fileServer := http.FileServer(http.Dir(dir))

	reg := gatingTestReg(t)
	token, err := reg.issue("alice", nil)
	if err != nil {
		t.Fatal(err)
	}
	cookie := redeemCookie(t, reg, token)

	buildLibMux := func(mode string) *http.ServeMux {
		mux := http.NewServeMux()
		browserWrap := browserPlaneWrap(reg, mode)
		calibre.RegisterFrontendRoutesGated(mux, guardedFileHandler(fileServer), browserWrap)
		mux.Handle("/static/data1.js", applyWrap(browserWrap, fileServer))
		mux.HandleFunc("/redeem", makeRedeemHandler(reg))
		return mux
	}

	// Private: shell + data*.js gated; open with a capability; /redeem open.
	priv := buildLibMux("private")
	for _, p := range []string{"/", "/static/data1.js"} {
		if code := codeFor(priv, p, nil); code != http.StatusUnauthorized {
			t.Errorf("lib private %s without capability: got %d, want 401", p, code)
		}
		if code := codeFor(priv, p, cookie); code != http.StatusOK {
			t.Errorf("lib private %s with capability: got %d, want 200", p, code)
		}
	}
	if code := codeFor(priv, "/redeem?token="+token, nil); code != http.StatusOK {
		t.Errorf("lib /redeem in private: got %d, want 200", code)
	}

	// Public: shell + data*.js anonymous.
	pub := buildLibMux("public")
	for _, p := range []string{"/", "/static/data1.js"} {
		if code := codeFor(pub, p, nil); code != http.StatusOK {
			t.Errorf("lib public %s: got %d, want 200 anonymous", p, code)
		}
	}
}
