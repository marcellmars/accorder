package cmd

import (
	"context"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"fmt"
	"log"
	"net"
	"net/http"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/goccy/go-json"
	"github.com/rclone/rclone/librclone/librclone"
)

func parseByteSize(s string) (int64, error) {
	s = strings.TrimSpace(s)
	if s == "" {
		return 0, fmt.Errorf("empty byte size string")
	}

	multiplier := int64(1)
	numStr := s
	// Egress flags historically accept K/KB and Ki/KiB as equivalent binary
	// units, and bare integers are bytes. VFS cache caps use rclone's different
	// SizeSuffix grammar and are parsed separately by parseVFSCacheSize.
	if strings.HasSuffix(numStr, "B") {
		numStr = strings.TrimSuffix(numStr, "B")
	}

	if len(numStr) >= 2 {
		suffix2 := numStr[len(numStr)-2:]
		switch suffix2 {
		case "Ki":
			multiplier = 1 << 10
			numStr = numStr[:len(numStr)-2]
		case "Mi":
			multiplier = 1 << 20
			numStr = numStr[:len(numStr)-2]
		case "Gi":
			multiplier = 1 << 30
			numStr = numStr[:len(numStr)-2]
		case "Ti":
			multiplier = 1 << 40
			numStr = numStr[:len(numStr)-2]
		}
	}
	if multiplier == 1 && len(numStr) >= 1 {
		suffix1 := numStr[len(numStr)-1]
		switch suffix1 {
		case 'K':
			multiplier = 1 << 10
			numStr = numStr[:len(numStr)-1]
		case 'M':
			multiplier = 1 << 20
			numStr = numStr[:len(numStr)-1]
		case 'G':
			multiplier = 1 << 30
			numStr = numStr[:len(numStr)-1]
		case 'T':
			multiplier = 1 << 40
			numStr = numStr[:len(numStr)-1]
		}
	}

	n, err := strconv.ParseInt(strings.TrimSpace(numStr), 10, 64)
	if err != nil {
		return 0, fmt.Errorf("invalid byte size %q: %w", s, err)
	}
	if n < 0 {
		return 0, fmt.Errorf("negative byte size %q", s)
	}
	if multiplier > 1 && n > (1<<63-1)/multiplier {
		return 0, fmt.Errorf("byte size %q overflows int64", s)
	}
	return n * multiplier, nil
}

const cookieName = "ep_sid"

const accorderClientHeader = "X-Accorder-Client"

var bookExts = map[string]bool{
	"pdf": true, "epub": true, "mobi": true, "azw3": true, "djvu": true,
	"fb2": true, "txt": true, "cbz": true, "cbr": true, "azw": true,
	"lit": true, "rtf": true, "doc": true, "docx": true, "zip": true, "rar": true,
}

var coverExts = map[string]bool{
	"jpg": true, "jpeg": true, "png": true, "webp": true, "gif": true,
	"avif": true, "bmp": true, "svg": true,
}

func fileKind(path string) string {
	base := path[strings.LastIndexByte(path, '/')+1:]
	i := strings.LastIndexByte(base, '.')
	if i < 0 {
		return "other"
	}
	ext := strings.ToLower(base[i+1:])
	if len(ext) < 1 || len(ext) > 5 {
		return "other"
	}
	switch {
	case bookExts[ext]:
		return "book"
	case coverExts[ext]:
		return "cover"
	default:
		return "other"
	}
}

type sessionData struct {
	mu                 sync.Mutex
	lastActive         atomic.Int64
	window             time.Duration
	granularitySeconds int64
	maxDistinct        int
	bookHashes         map[uint64]int64
	coverHashes        map[uint64]int64
}

func hashPath(path string) uint64 {
	h := sha256.Sum256([]byte(path))
	return binary.LittleEndian.Uint64(h[:8])
}

func (s *sessionData) record(path, kind string, now time.Time) (books, covers int) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.lastActive.Store(now.Unix())
	bucket := now.Unix() / s.granularitySeconds
	cutoff := now.Add(-s.window).Unix() / s.granularitySeconds
	for _, m := range []map[uint64]int64{s.bookHashes, s.coverHashes} {
		for h, b := range m {
			if b < cutoff {
				delete(m, h)
			}
		}
	}
	var target map[uint64]int64
	switch kind {
	case "book":
		target = s.bookHashes
	case "cover":
		target = s.coverHashes
	}
	if target != nil {
		ph := hashPath(path)
		if _, exists := target[ph]; exists {
			target[ph] = bucket
		} else if len(target) < s.maxDistinct {
			target[ph] = bucket
		}
	}
	return len(s.bookHashes), len(s.coverHashes)
}

type sessionMeter struct {
	sessions     sync.Map
	sessionCount atomic.Int64
	window       time.Duration
	granularity  time.Duration
	maxSessions  int
	maxDistinct  int
}

// NOTE: clientIP trusts forwarded headers only from a loopback peer — the Caddy
// reverse proxy on the clearnet plane, which appends the real client IP as the
// rightmost X-Forwarded-For entry. On the onion plane the peer is tor's
// synthetic per-circuit address (fc00:dead:beef:4dad::/64, non-loopback), so
// this branch is skipped and the circuit address is the session key; onion
// forwarded headers are stripped upstream (startOnionPlane) regardless.
func clientIP(r *http.Request) string {
	host, _, _ := net.SplitHostPort(r.RemoteAddr)
	if ip := net.ParseIP(host); ip != nil && ip.IsLoopback() {
		if xff := r.Header.Get("X-Forwarded-For"); xff != "" {
			if i := strings.LastIndexByte(xff, ','); i >= 0 {
				return strings.TrimSpace(xff[i+1:])
			}
			return strings.TrimSpace(xff)
		}
		if xri := r.Header.Get("X-Real-IP"); xri != "" {
			return strings.TrimSpace(xri)
		}
	}
	return host
}

func (m *sessionMeter) fallbackSessionID(r *http.Request) string {
	h := sha256.Sum256([]byte(clientIP(r) + r.UserAgent()))
	return hex.EncodeToString(h[:8])
}

func (m *sessionMeter) resolveSession(w http.ResponseWriter, r *http.Request) string {
	if grantID, ok := r.Context().Value(grantIDKey).(string); ok && grantID != "" {
		sid := "grant:" + grantID
		m.getOrCreateSession(sid)
		return sid
	}
	if ann := r.Header.Get(accorderClientHeader); ann != "" {
		h := sha256.Sum256([]byte(clientIP(r) + r.UserAgent() + ann))
		sid := "accorder:" + hex.EncodeToString(h[:8])
		m.getOrCreateSession(sid)
		return sid
	}
	if c, err := r.Cookie(cookieName); err == nil && c.Value != "" {
		m.getOrCreateSession(c.Value)
		return c.Value
	}
	sid := m.fallbackSessionID(r)
	http.SetCookie(w, &http.Cookie{
		Name:     cookieName,
		Value:    sid,
		Path:     "/files/",
		HttpOnly: true,
		SameSite: http.SameSiteLaxMode,
		MaxAge:   3600,
	})
	m.getOrCreateSession(sid)
	return sid
}

func (m *sessionMeter) getOrCreateSession(sid string) *sessionData {
	if v, ok := m.sessions.Load(sid); ok {
		return v.(*sessionData)
	}
	gsec := int64(m.granularity.Seconds())
	if gsec < 1 {
		gsec = 1
	}
	sd := &sessionData{
		window:             m.window,
		granularitySeconds: gsec,
		maxDistinct:        m.maxDistinct,
		bookHashes:         make(map[uint64]int64),
		coverHashes:        make(map[uint64]int64),
	}
	sd.lastActive.Store(time.Now().Unix())
	if actual, loaded := m.sessions.LoadOrStore(sid, sd); loaded {
		return actual.(*sessionData)
	}
	m.sessionCount.Add(1)
	if int(m.sessionCount.Load()) > m.maxSessions {
		m.evictSessions(m.maxSessions)
	}
	return sd
}

func (m *sessionMeter) evictSessions(maxSessions int) {
	count := int(m.sessionCount.Load())
	if count <= maxSessions {
		return
	}
	type entry struct {
		id         string
		lastActive int64
	}
	entries := make([]entry, 0, count)
	m.sessions.Range(func(key, val any) bool {
		sd := val.(*sessionData)
		entries = append(entries, entry{id: key.(string), lastActive: sd.lastActive.Load()})
		return true
	})
	sort.Slice(entries, func(i, j int) bool {
		return entries[i].lastActive < entries[j].lastActive
	})
	toEvict := count - maxSessions
	for i := 0; i < toEvict && i < len(entries); i++ {
		if _, loaded := m.sessions.LoadAndDelete(entries[i].id); loaded {
			m.sessionCount.Add(-1)
		}
	}
}

func (m *sessionMeter) sweepStale() {
	cutoff := time.Now().Add(-2 * m.window).Unix()
	m.sessions.Range(func(key, val any) bool {
		sd := val.(*sessionData)
		if sd.lastActive.Load() < cutoff {
			if _, loaded := m.sessions.LoadAndDelete(key); loaded {
				m.sessionCount.Add(-1)
			}
		}
		return true
	})
	m.evictSessions(m.maxSessions)
}

func (m *sessionMeter) startSweep(ctx context.Context) {
	ticker := time.NewTicker(10 * time.Minute)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			m.sweepStale()
		}
	}
}

func validateMeterFlags(window, granularity time.Duration, maxSessions, maxDistinct int) error {
	if window <= 0 {
		return fmt.Errorf("--meter-window must be > 0 (got %v)", window)
	}
	if granularity < time.Second {
		return fmt.Errorf("--meter-bucket-granularity must be >= 1s (got %v)", granularity)
	}
	if maxSessions <= 0 {
		return fmt.Errorf("--meter-max-sessions must be > 0 (got %d)", maxSessions)
	}
	if maxDistinct <= 0 {
		return fmt.Errorf("--meter-max-distinct must be > 0 (got %d)", maxDistinct)
	}
	return nil
}

type egressBreakerConfig struct {
	MonthlyAllowanceBytes int64
	MonthlyAllowanceIsSet bool
	BudgetUSD             float64
	BudgetUSDIsSet        bool
	PricePerGB            float64
	RawLimitBytes         int64
	RawLimitIsSet         bool
	BurstBytes            int64
	BurstIsSet            bool
}

type egressBreaker struct {
	tripped        atomic.Bool
	mu             sync.Mutex
	tokens         float64
	bucketCapacity float64
	sustainedRate  float64
	lastPoll       time.Time
	lastBytes      int64
}

func newEgressBreaker(cfg egressBreakerConfig) (*egressBreaker, error) {
	if !cfg.RawLimitIsSet && !cfg.BudgetUSDIsSet && !cfg.MonthlyAllowanceIsSet {
		return nil, nil
	}
	var sustainedRate float64
	switch {
	case cfg.RawLimitIsSet:
		sustainedRate = float64(cfg.RawLimitBytes) / 86400.0
	case cfg.BudgetUSDIsSet:
		if cfg.PricePerGB <= 0 {
			return nil, fmt.Errorf("--egress-price-per-gb must be > 0 when --egress-budget-usd is set")
		}
		budgetBytesPerDay := (cfg.BudgetUSD / cfg.PricePerGB) * 1e9
		sustainedRate = budgetBytesPerDay / 86400.0
	default:
		sustainedRate = float64(cfg.MonthlyAllowanceBytes) / (30.0 * 86400.0)
	}
	if sustainedRate <= 0 {
		return nil, fmt.Errorf("egress budget resolves to zero rate; breaker would trip permanently")
	}
	var capacity float64
	if cfg.BurstIsSet {
		if cfg.BurstBytes <= 0 {
			return nil, fmt.Errorf("--egress-burst must be > 0 when set")
		}
		capacity = float64(cfg.BurstBytes)
	} else {
		capacity = sustainedRate * 3600
	}
	return &egressBreaker{
		tokens:         capacity,
		bucketCapacity: capacity,
		sustainedRate:  sustainedRate,
		lastPoll:       time.Now(),
	}, nil
}

func (b *egressBreaker) pollOnce(bytesNow int64, now time.Time) {
	delta := bytesNow - b.lastBytes
	if delta < 0 {
		delta = 0
	}
	b.lastBytes = bytesNow

	b.mu.Lock()
	elapsed := now.Sub(b.lastPoll).Seconds()
	b.lastPoll = now
	b.tokens += b.sustainedRate * elapsed
	if b.tokens > b.bucketCapacity {
		b.tokens = b.bucketCapacity
	}
	b.tokens -= float64(delta)
	if b.tokens <= 0 {
		b.tripped.Store(true)
	} else if b.tokens > b.bucketCapacity*0.2 {
		b.tripped.Store(false)
	}
	b.mu.Unlock()
}

func (b *egressBreaker) pollLoop(ctx context.Context, interval time.Duration) {
	ticker := time.NewTicker(interval)
	defer ticker.Stop()
	if out, status := librclone.RPC("core/stats", "{}"); status == 200 {
		var stats struct {
			Bytes int64 `json:"bytes"`
		}
		if json.Unmarshal([]byte(out), &stats) == nil {
			b.lastBytes = stats.Bytes
			b.lastPoll = time.Now()
		}
	}
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			out, status := librclone.RPC("core/stats", "{}")
			if status != 200 {
				continue
			}
			var stats struct {
				Bytes int64 `json:"bytes"`
			}
			if json.Unmarshal([]byte(out), &stats) != nil {
				continue
			}
			b.pollOnce(stats.Bytes, time.Now())
		}
	}
}

func meterPathKey(urlPath string) string {
	return filepath.Clean(strings.TrimPrefix(urlPath, "/files/"))
}

func sessionClass(sid string) string {
	switch {
	case strings.HasPrefix(sid, "grant:"):
		return "grant"
	case strings.HasPrefix(sid, "accorder:"):
		return "accorder"
	default:
		return "anon"
	}
}

func withEndpointProtection(next http.Handler, meter *sessionMeter, breaker *egressBreaker) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if breaker != nil && breaker.tripped.Load() {
			w.Header().Set("Retry-After", "60")
			http.Error(w, "Service temporarily unavailable", http.StatusServiceUnavailable)
			log.Printf("endpoint_protection: BREAKER path=%s", r.URL.Path)
			return
		}
		sid := meter.resolveSession(w, r)
		sdVal, ok := meter.sessions.Load(sid)
		if !ok {
			sdVal = meter.getOrCreateSession(sid)
		}
		key := meterPathKey(r.URL.Path)
		kind := fileKind(key)
		books, covers := sdVal.(*sessionData).record(key, kind, time.Now())
		log.Printf("endpoint_protection: session=%s class=%s kind=%s path=%s distinct_books=%d distinct_covers=%d ts=%d",
			sid, sessionClass(sid), kind, r.URL.Path, books, covers, time.Now().Unix())
		next.ServeHTTP(w, r)
	})
}
