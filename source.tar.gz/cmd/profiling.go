package cmd

import (
	"fmt"
	"log"
	"net"
	"net/http"
	httppprof "net/http/pprof"
	"os"
	"runtime/pprof"
)

func startPprofListener(addr string) error {
	host, _, err := net.SplitHostPort(addr)
	if err != nil {
		return fmt.Errorf("pprof listen %s: %w", addr, err)
	}
	if ip := net.ParseIP(host); ip == nil || !ip.IsLoopback() {
		return fmt.Errorf("pprof listen %s: refusing non-loopback bind (the endpoint exposes process flags including credentials)", addr)
	}

	mux := http.NewServeMux()
	mux.HandleFunc("/debug/pprof/", httppprof.Index)
	mux.HandleFunc("/debug/pprof/cmdline", httppprof.Cmdline)
	mux.HandleFunc("/debug/pprof/profile", httppprof.Profile)
	mux.HandleFunc("/debug/pprof/symbol", httppprof.Symbol)
	mux.HandleFunc("/debug/pprof/trace", httppprof.Trace)

	ln, err := net.Listen("tcp", addr)
	if err != nil {
		return fmt.Errorf("pprof listen %s: %w", addr, err)
	}
	go func() {
		log.Printf("pprof debug endpoint on http://%s/debug/pprof/ (heap: /debug/pprof/heap)", addr)
		if serveErr := http.Serve(ln, mux); serveErr != nil {
			log.Printf("pprof listener stopped: %v", serveErr)
		}
	}()
	return nil
}

//nolint:unused // retained for ad-hoc profiling per CLAUDE.md
func startCPUProfile() {
	f, err := os.Create("cpu.prof")
	if err != nil {
		log.Fatal("could not create CPU profile: ", err)
	}
	if err := pprof.StartCPUProfile(f); err != nil {
		log.Fatal("could not start CPU profile: ", err)
	}
}

//nolint:unused // retained for ad-hoc profiling per CLAUDE.md
func stopCPUProfile() {
	pprof.StopCPUProfile()
}

//nolint:unused // retained for ad-hoc profiling per CLAUDE.md
func writeHeapProfile() {
	f, err := os.Create("mem.prof")
	if err != nil {
		log.Fatal("could not create memory profile: ", err)
	}
	defer f.Close()
	if err := pprof.WriteHeapProfile(f); err != nil {
		log.Fatal("could not write memory profile: ", err)
	}
}
