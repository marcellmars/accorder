package cmd

//

// Phase 4.3: claim client against the *real* invite handler
// (spike_validation_coverage rule 6 — production primitives, httptest tier).

import (
	"accorder/pkg/fedlibinvite"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

// startInviteServer serves the production invite handler over httptest TLS
// (the claim client requires https) and returns the server plus a claim URL
// for a freshly sealed offer.
func startInviteServer(t *testing.T) (srv *httptest.Server, claimURL, blob string, client *http.Client) {
	t.Helper()
	dir := t.TempDir()
	token, blobOut := writeTestOffer(t, dir, time.Now().Add(time.Hour))
	srv = httptest.NewTLSServer(makeInviteHandler(dir, newIPRateLimiter(1000, time.Millisecond)))
	t.Cleanup(srv.Close)
	return srv, srv.URL + "/invite/" + token, blobOut, srv.Client()
}

func TestJoinClaim_URLResolvesToSameBlob(t *testing.T) {
	_, claimURL, blob, client := startInviteServer(t)

	// The claim client uses http.Post (default client); swap in the test
	// server's TLS-trusting transport for the duration.
	oldTransport := http.DefaultTransport
	http.DefaultTransport = client.Transport
	defer func() { http.DefaultTransport = oldTransport }()

	got, err := resolveInviteArg(claimURL, false)
	if err != nil {
		t.Fatalf("resolveInviteArg(url, false): %v", err)
	}
	if got != blob {
		t.Fatalf("claimed blob differs from sealed blob\ngot:  %q\nwant: %q", got, blob)
	}
	if _, err := fedlibinvite.DecodeWriteInvite(got); err != nil {
		t.Fatalf("claimed blob does not decode: %v", err)
	}

	// Single-use: the same URL claims only once.
	if _, err := resolveInviteArg(claimURL, false); err == nil {
		t.Fatal("second claim succeeded; want not-found error")
	} else if !strings.Contains(err.Error(), "re-issue") {
		t.Errorf("second-claim error not actionable: %v", err)
	}
}

func TestJoinClaim_PlainHTTPRefused(t *testing.T) {
	_, err := resolveInviteArg("http://lib.example.org/invite/abcdefghijklmnopqrstuvwxyz", false)
	if err == nil {
		t.Fatal("plain-http URL accepted")
	}
	if !strings.Contains(err.Error(), "https://") {
		t.Errorf("refusal message does not name the https requirement: %v", err)
	}
}

func TestJoinClaim_LiteralAndFileBranchesUntouched(t *testing.T) {
	blob := fedlibinvite.EncodeWriteInvite(&fedlibinvite.WriteInvite{
		FedlibID: "f", Prefix: "p", AccessKey: "a", SecretKey: "s",
	})
	got, err := resolveInviteArg(blob, false)
	if err != nil || got != blob {
		t.Fatalf("literal branch: got %q err %v", got, err)
	}
}

func TestJoinClaim_LineScanFallback(t *testing.T) {
	blob := fedlibinvite.EncodeWriteInvite(&fedlibinvite.WriteInvite{
		FedlibID: "f", Prefix: "p", AccessKey: "a", SecretKey: "s",
	})
	srv := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {

		// Non-envelope body: prose around a blob line (future non-Go serves).
		_, _ = w.Write([]byte("here is your invite\n" + blob + "\nenjoy\n"))
	}))
	defer srv.Close()

	oldTransport := http.DefaultTransport
	http.DefaultTransport = srv.Client().Transport
	defer func() { http.DefaultTransport = oldTransport }()

	got, err := claimInviteURL(srv.URL + "/invite/whatever")
	if err != nil {
		t.Fatalf("claimInviteURL with line-scan body: %v", err)
	}
	if got != blob {
		t.Fatalf("line-scan fallback: got %q want %q", got, blob)
	}
}

// Regression: a bad --calibrepath must fail BEFORE the single-use offer is
// claimed, leaving the invite claimable for a corrected retry.
func TestJoinClaim_CalibrePreflightBeforeClaim(t *testing.T) {
	testSetup(t)
	_, claimURL, _, client := startInviteServer(t)

	oldTransport := http.DefaultTransport
	http.DefaultTransport = client.Transport
	defer func() { http.DefaultTransport = oldTransport }()

	notALibrary := t.TempDir() // non-empty and no metadata.db; empty is a valid recovery target
	if err := os.WriteFile(filepath.Join(notALibrary, "unrelated.txt"), []byte("keep"), 0o644); err != nil {
		t.Fatal(err)
	}
	cmd := &LibJoinCmd{Invite: claimURL, CommonCommandFields: CommonCommandFields{ActionAlias: "preflight"}, CalibrePath: notALibrary}
	err := cmd.Run(nil)
	if err == nil {
		t.Fatal("join with bad calibrepath succeeded; want metadata.db error")
	}
	if !strings.Contains(err.Error(), "metadata.db") {
		t.Fatalf("error does not name the failed preflight: %v", err)
	}

	// The offer must still be claimable — the preflight ran before the POST.
	if _, err := resolveInviteArg(claimURL, false); err != nil {
		t.Fatalf("offer was consumed by the failed preflight join: %v", err)
	}
}
