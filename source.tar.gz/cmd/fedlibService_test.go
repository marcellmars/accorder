package cmd

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// ═══════════════════════════════════════════════════════════════════
// renderUnit — pure, so these are golden tests with no host involved.
// ═══════════════════════════════════════════════════════════════════

func TestRenderUnit_Golden(t *testing.T) {
	got, err := renderUnit(unitSpec{
		ExecPath:     "/usr/local/bin/accorder",
		Alias:        "motw",
		User:         "root",
		Home:         "/root",
		ConfigHome:   "/root/.config",
		TimeoutStart: 90,
	})
	if err != nil {
		t.Fatalf("renderUnit: %v", err)
	}

	want := `[Unit]
Description=accorder fedlib serve (motw)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
Environment=HOME=/root
WorkingDirectory=/root
Environment=XDG_CONFIG_HOME=/root/.config
ExecStart=/usr/local/bin/accorder fedlib share live motw
Restart=on-failure
RestartSec=10
TimeoutStartSec=90

[Install]
WantedBy=multi-user.target
`
	if got != want {
		t.Errorf("unit mismatch\n--- got ---\n%s\n--- want ---\n%s", got, want)
	}
}

func TestRenderUnit_GoldenWithMemoryLimitAndPprof(t *testing.T) {
	got, err := renderUnit(unitSpec{
		ExecPath:     "/usr/local/bin/accorder",
		Alias:        "motw",
		User:         "root",
		Home:         "/root",
		MemoryLimit:  "500MiB",
		ExtraArgs:    []string{"--pprof-listen", "127.0.0.1:8724"},
		TimeoutStart: 90,
	})
	if err != nil {
		t.Fatalf("renderUnit: %v", err)
	}
	for _, want := range []string{
		"Environment=GOMEMLIMIT=500MiB",
		"ExecStart=/usr/local/bin/accorder fedlib share live motw --pprof-listen 127.0.0.1:8724",
	} {
		if !strings.Contains(got, want) {
			t.Errorf("unit missing %q\n%s", want, got)
		}
	}
}

// TestRenderUnit_ExecStartCarriesNoTuningFlags pins the central design decision:
// the seven settings the old wrapper pinned are replayed from the alias, so the
// unit must not restate them. If they reappear here, the drift the wrapper had
// has been reintroduced.
func TestRenderUnit_ExecStartCarriesNoTuningFlags(t *testing.T) {
	got, err := renderUnit(unitSpec{
		ExecPath: "/usr/local/bin/accorder", Alias: "motw", TimeoutStart: 90,
	})
	if err != nil {
		t.Fatalf("renderUnit: %v", err)
	}
	for _, forbidden := range []string{
		"--listen", "--cache-size", "--cache-size-assets", "--cache-max-age",
		"--cache-min-free", "--poll-interval", "--aggregate-path",
	} {
		if strings.Contains(got, forbidden) {
			t.Errorf("unit pins %s; it must come from the alias instead\n%s", forbidden, got)
		}
	}
}

// The unit this replaces carried TimeoutStartSec=0. systemd reads 0 as "no
// limit", which is what let a failed start hang indefinitely; refuse to emit it.
func TestRenderUnit_RefusesZeroTimeout(t *testing.T) {
	if _, err := renderUnit(unitSpec{ExecPath: "/x", Alias: "a", TimeoutStart: 0}); err == nil {
		t.Error("expected refusal for TimeoutStartSec=0")
	}
}

func TestRenderUnit_RequiresExecPathAndAlias(t *testing.T) {
	if _, err := renderUnit(unitSpec{Alias: "a", TimeoutStart: 90}); err == nil {
		t.Error("expected error without exec path")
	}
	if _, err := renderUnit(unitSpec{ExecPath: "/x", TimeoutStart: 90}); err == nil {
		t.Error("expected error without alias")
	}
}

// ═══════════════════════════════════════════════════════════════════
// The install guard
// ═══════════════════════════════════════════════════════════════════

// seedServeAlias writes an alias holding the operator's serve settings plus the
// descriptor `fedlib share live` requires at parse time.
func seedServeAlias(t *testing.T, withTuning bool) {
	t.Helper()
	tuning := ""
	if withTuning {
		tuning = `"listen": "0.0.0.0:8723",
						"cache-size": "20Gi",
						"cache-size-assets": "7Gi",
						"cache-max-age": "8760h",
						"cache-min-free": "5Gi",
						"poll-interval": 120,`
	}
	aliasJSON := `{
		"motw": {
			"fedlib": {
				"share": {
					"live": {
						` + tuning + `
						"aggregate-path": "/srv/fedlib/motw"
					}
				}
			}
		}
	}`
	if err := os.WriteFile(savedActionAliases, []byte(aliasJSON), 0o600); err != nil {
		t.Fatal(err)
	}
	if err := saveFedlibDescriptor("motw", fedlibDescriptor{
		Version:    fedlibDescriptorVersion,
		Bucket:     "test-bucket/prefix",
		S3Provider: "Wasabi",
		S3Endpoint: "https://s3.wasabisys.com",
		FedlibPath: "/srv/fedlib/motw",
	}); err != nil {
		t.Fatal(err)
	}
}

func installCmdFor(alias string) *FedlibServiceInstallCmd {
	c := &FedlibServiceInstallCmd{TimeoutStart: 90, UnitDir: "/etc/systemd/system", ExecPath: "/usr/local/bin/accorder"}
	c.ActionAlias = alias
	return c
}

// TestServiceInstall_GuardRefusesStockDefaults is the reason this command is
// not a template renderer. The unit omits the tuning flags on the strength of
// alias replay; if the alias does not hold them the serve starts *successfully*
// on stock values, which is worse than failing.
func TestServiceInstall_GuardRefusesStockDefaults(t *testing.T) {
	testSetup(t)
	seedServeAlias(t, false) // aggregate-path only — no tuning

	_, err := installCmdFor("motw").spec()
	if err == nil {
		t.Fatal("expected refusal when serve settings would come from defaults")
	}
	for _, flag := range []string{"--listen", "--cache-size", "--cache-size-assets", "--cache-max-age", "--cache-min-free", "--poll-interval"} {
		if !strings.Contains(err.Error(), flag) {
			t.Errorf("refusal does not name %s: %v", flag, err)
		}
	}
	// --aggregate-path must NOT be guarded: it falls back to the descriptor and
	// already returns a Blocking issue when unresolvable.
	if strings.Contains(err.Error(), "--aggregate-path") {
		t.Error("refusal names --aggregate-path, which resolves from the descriptor and fails loudly on its own")
	}
}

func TestServiceInstall_GuardPassesWithConfiguredAlias(t *testing.T) {
	testSetup(t)
	seedServeAlias(t, true)

	spec, err := installCmdFor("motw").spec()
	if err != nil {
		t.Fatalf("spec: %v", err)
	}
	if spec.Alias != "motw" {
		t.Errorf("alias = %q", spec.Alias)
	}
	unit, err := renderUnit(spec)
	if err != nil {
		t.Fatalf("renderUnit: %v", err)
	}
	if !strings.Contains(unit, "ExecStart=/usr/local/bin/accorder fedlib share live motw") {
		t.Errorf("unexpected ExecStart:\n%s", unit)
	}
}

func TestServiceInstall_AcceptDefaultsBypassesGuard(t *testing.T) {
	testSetup(t)
	seedServeAlias(t, false)

	c := installCmdFor("motw")
	c.AcceptDefaults = boolPtr(true)
	if _, err := c.spec(); err != nil {
		t.Fatalf("--accept-defaults should bypass the guard: %v", err)
	}
}

// Pointing the service at another config dir moves the aliases, keys and
// secrets.age it reads. That is a migration, so it must not happen by flag.
func TestServiceInstall_RefusesConfigHomeMove(t *testing.T) {
	testSetup(t)
	seedServeAlias(t, true)

	c := installCmdFor("motw")
	c.ConfigHome = "/var/lib/somewhere-else"
	_, err := c.spec()
	if err == nil {
		t.Fatal("expected refusal for a config-home that is not the one in use")
	}
	if !strings.Contains(err.Error(), "migration") {
		t.Errorf("refusal should explain it is a migration: %v", err)
	}

	c.Force = boolPtr(true)
	if _, err := c.spec(); err != nil {
		t.Errorf("--force should allow the move: %v", err)
	}
}

// TestServiceInstall_PinsConfigHomeInUse is the regression guard for the
// derivation bug: the unit must NAME the config dir the operator is using,
// never infer it from HOME. os.UserConfigDir() prefers XDG_CONFIG_HOME over
// $HOME/.config, so HOME does not determine it.
func TestServiceInstall_PinsConfigHomeInUse(t *testing.T) {
	testSetup(t)
	seedServeAlias(t, true)

	spec, err := installCmdFor("motw").spec()
	if err != nil {
		t.Fatalf("spec: %v", err)
	}
	// The contract: the unit pins the parent of the config dir in use, so the
	// service's os.UserConfigDir() lands back on it. (In production
	// accorderConfigDir is always Join(configDir, AppName) — configuration.go:32
	// — so Join(pin, AppName) round-trips exactly; testSetup uses a bare temp
	// dir, so assert the pin itself rather than the round-trip.)
	if got, want := spec.ConfigHome, filepath.Dir(accorderConfigDir); got != want {
		t.Errorf("pinned XDG_CONFIG_HOME = %q, want %q", got, want)
	}
	unit, err := renderUnit(spec)
	if err != nil {
		t.Fatalf("renderUnit: %v", err)
	}
	if !strings.Contains(unit, "Environment=XDG_CONFIG_HOME="+spec.ConfigHome) {
		t.Errorf("unit does not pin the config dir:\n%s", unit)
	}
}

// ═══════════════════════════════════════════════════════════════════
// atomic write
// ═══════════════════════════════════════════════════════════════════

func TestWriteFileAtomically(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "sub", "accorder-motw.service")

	if err := writeFileAtomically(path, []byte("first"), 0o644); err != nil {
		t.Fatalf("write: %v", err)
	}
	if err := writeFileAtomically(path, []byte("second"), 0o644); err != nil {
		t.Fatalf("overwrite: %v", err)
	}
	got, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("read: %v", err)
	}
	if string(got) != "second" {
		t.Errorf("content = %q, want %q", got, "second")
	}
	// No temp files left behind.
	entries, _ := os.ReadDir(filepath.Dir(path))
	if len(entries) != 1 {
		names := []string{}
		for _, e := range entries {
			names = append(names, e.Name())
		}
		t.Errorf("expected only the unit file, got %v", names)
	}
}

// ═══════════════════════════════════════════════════════════════════
// service show — the drift comparison
//
// Added after a code review found two defects here that no test covered:
// the comparison was rebuilt by hand (dropping every persisted install flag,
// so any unit installed with --user/--home/--memory-limit reported DRIFT
// forever against a unit the tool would never generate), and it ran through
// the config-home migration refusal (so a --force-installed unit could not be
// compared at all). Both are reporting-path bugs: they make the tool lie about
// state rather than corrupt it, which is exactly the class unit tests catch
// and manual smoke-testing does not.
// ═══════════════════════════════════════════════════════════════════

// seedInstallFlags persists install-time flags under the alias, the way a real
// `fedlib service install motw --user root ...` would.
func seedInstallFlags(t *testing.T) {
	t.Helper()
	data, err := os.ReadFile(savedActionAliases)
	if err != nil {
		t.Fatal(err)
	}
	merged := strings.Replace(string(data), `"motw": {`, `"motw": {
		"fedlib": {
			"service": {
				"install": {
					"user": "root",
					"home": "/root",
					"memory-limit": "500MiB",
					"timeout-start": 120,
					"exec-path": "/usr/local/bin/accorder"
				}
			}
		},`, 1)
	if err := os.WriteFile(savedActionAliases, []byte(merged), 0o600); err != nil {
		t.Fatal(err)
	}
}

// TestServiceShow_RegenerationReplaysPersistedInstallFlags is the regression
// guard for the first finding. Rebuilding the install command by hand loses
// these, and every subsequent `show` then reports drift against a phantom.
func TestServiceShow_RegenerationReplaysPersistedInstallFlags(t *testing.T) {
	testSetup(t)
	seedServeAlias(t, true)
	seedInstallFlags(t)

	install, err := resolveInstallForAlias("motw")
	if err != nil {
		t.Fatalf("resolveInstallForAlias: %v", err)
	}
	for _, tc := range []struct{ name, got, want string }{
		{"user", install.User, "root"},
		{"home", install.Home, "/root"},
		{"memory-limit", install.MemoryLimit, "500MiB"},
		{"exec-path", install.ExecPath, "/usr/local/bin/accorder"},
	} {
		if tc.got != tc.want {
			t.Errorf("%s = %q, want %q — persisted install flags must be replayed for the drift comparison", tc.name, tc.got, tc.want)
		}
	}
	if install.TimeoutStart != 120 {
		t.Errorf("timeout-start = %d, want 120", install.TimeoutStart)
	}
}

// TestServiceShow_RegeneratedUnitMatchesInstalled closes the loop: what
// install would write is what show regenerates, byte for byte.
func TestServiceShow_RegeneratedUnitMatchesInstalled(t *testing.T) {
	testSetup(t)
	seedServeAlias(t, true)
	seedInstallFlags(t)

	install, err := resolveInstallForAlias("motw")
	if err != nil {
		t.Fatalf("resolveInstallForAlias: %v", err)
	}
	install.AcceptDefaults = boolPtr(true)
	install.Force = boolPtr(true)
	spec, err := install.spec()
	if err != nil {
		t.Fatalf("spec: %v", err)
	}
	unit, err := renderUnit(spec)
	if err != nil {
		t.Fatalf("renderUnit: %v", err)
	}
	// The persisted flags must actually reach the rendered unit.
	for _, want := range []string{
		"User=root",
		"Environment=HOME=/root",
		"Environment=GOMEMLIMIT=500MiB",
		"TimeoutStartSec=120",
		"ExecStart=/usr/local/bin/accorder fedlib share live motw",
	} {
		if !strings.Contains(unit, want) {
			t.Errorf("regenerated unit missing %q\n%s", want, unit)
		}
	}
}

// TestServiceShow_ForceLetsAMovedConfigHomeBeCompared is the regression guard
// for the second finding. An operator who installed with --force --config-home
// still needs `show` to compare, not to refuse.
func TestServiceShow_ForceLetsAMovedConfigHomeBeCompared(t *testing.T) {
	testSetup(t)
	seedServeAlias(t, true)

	install, err := resolveInstallForAlias("motw")
	if err != nil {
		t.Fatalf("resolveInstallForAlias: %v", err)
	}
	install.ConfigHome = "/var/lib/elsewhere"
	install.ExecPath = "/usr/local/bin/accorder"

	// Without Force this is the migration refusal — correct when installing.
	install.AcceptDefaults = boolPtr(true)
	if _, err := install.spec(); err == nil {
		t.Fatal("expected the migration refusal when not forcing")
	}

	// Reporting must not be gated by it.
	install.Force = boolPtr(true)
	spec, err := install.spec()
	if err != nil {
		t.Fatalf("reporting path must not be blocked by the migration refusal: %v", err)
	}
	if spec.ConfigHome != "/var/lib/elsewhere" {
		t.Errorf("ConfigHome = %q, want the forced value", spec.ConfigHome)
	}
}

// TestServiceShow_RunReportsMatchForFreshlyGeneratedUnit is the guard that the
// two above are not.
//
// They exercise resolveInstallForAlias; the defects lived in Run(), which had
// hand-built the install command instead of calling it. Reverting Run() left
// those tests green — a regression guard that does not cover the call site is
// not a regression guard. This drives Run() end to end and reads its output.
func TestServiceShow_RunReportsMatchForFreshlyGeneratedUnit(t *testing.T) {
	testSetup(t)
	seedServeAlias(t, true)
	seedInstallFlags(t)

	// Generate exactly what `install` would write, and put it on disk.
	install, err := resolveInstallForAlias("motw")
	if err != nil {
		t.Fatalf("resolveInstallForAlias: %v", err)
	}
	install.AcceptDefaults = boolPtr(true)
	install.Force = boolPtr(true)
	spec, err := install.spec()
	if err != nil {
		t.Fatalf("spec: %v", err)
	}
	unit, err := renderUnit(spec)
	if err != nil {
		t.Fatalf("renderUnit: %v", err)
	}
	unitDir := t.TempDir()
	if err := os.WriteFile(filepath.Join(unitDir, "accorder-motw.service"), []byte(unit), 0o644); err != nil {
		t.Fatal(err)
	}

	show := &FedlibServiceShowCmd{UnitDir: unitDir}
	show.ActionAlias = "motw"

	out := captureStdout(t, func() {
		if err := show.Run(nil); err != nil {
			t.Errorf("Run: %v", err)
		}
	})

	if strings.Contains(out, "DRIFT") {
		t.Errorf("show reported drift against a unit install would generate right now:\n%s", out)
	}
	if !strings.Contains(out, "matches what would be generated now") {
		t.Errorf("show did not report a match:\n%s", out)
	}
}

// And the converse: a unit that genuinely differs must be reported.
func TestServiceShow_RunReportsRealDrift(t *testing.T) {
	testSetup(t)
	seedServeAlias(t, true)
	seedInstallFlags(t)

	unitDir := t.TempDir()
	stale := "[Unit]\nDescription=something else entirely\n"
	if err := os.WriteFile(filepath.Join(unitDir, "accorder-motw.service"), []byte(stale), 0o644); err != nil {
		t.Fatal(err)
	}

	show := &FedlibServiceShowCmd{UnitDir: unitDir}
	show.ActionAlias = "motw"

	out := captureStdout(t, func() {
		if err := show.Run(nil); err != nil {
			t.Errorf("Run: %v", err)
		}
	})
	if !strings.Contains(out, "DRIFT") {
		t.Errorf("show did not report drift for a stale unit:\n%s", out)
	}
}

// TestServiceInstall_ServeArgsPassThroughSplitOnWhitespace covers the three
// json:"-" flags the alias refuses to hold — the only things that belong in
// ExecStart besides the alias name.
func TestServiceInstall_ServeArgsPassThroughSplitOnWhitespace(t *testing.T) {
	testSetup(t)
	seedServeAlias(t, true)

	c := installCmdFor("motw")
	c.ServeArgs = []string{"--pprof-listen 127.0.0.1:8724", "--only-http"}
	spec, err := c.spec()
	if err != nil {
		t.Fatalf("spec: %v", err)
	}
	unit, err := renderUnit(spec)
	if err != nil {
		t.Fatalf("renderUnit: %v", err)
	}
	want := "ExecStart=/usr/local/bin/accorder fedlib share live motw --pprof-listen 127.0.0.1:8724 --only-http"
	if !strings.Contains(unit, want) {
		t.Errorf("ExecStart missing passthroughs\nwant: %s\ngot:\n%s", want, unit)
	}
}
