package cmd

import (
	"archive/tar"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"testing"

	"github.com/klauspost/compress/zstd"
)

// seedIdentityFiles creates a realistic set of identity files under configDir
// for testing backup enumeration and round-trip restore.
func seedIdentityFiles(t *testing.T, configDir string) map[string]string {
	t.Helper()
	files := map[string]string{
		"tor/lib/hs_ed25519_secret_key":          "fake-tor-secret-key-32-bytes!!!!",
		"tor/lib/hs_ed25519_public_key":          "fake-tor-public-key-32-bytes!!!!",
		"tor/lib/hostname":                       "exampleonion.onion\n",
		"tor/lib/authorized_clients/friend.auth": "descriptor:x25519:FAKEKEY",
		"tor/lib/browser/hs_ed25519_secret_key":  "fake-dual-onion-browser-key!!!!!",
		"clearnet/lib/signing.key":               "fake-signing-key-32-bytes!!!!!!!",
		"clearnet/lib/grants.json":               `{"tok1":{"friend":"alice","token":"tok1"},"tok2":{"friend":"bob","token":"tok2"}}`,
		"clearnet-lib/mylib/signing.key":         "fake-lib-signing-key-32-bytes!!!",
		"fedlibs.json":                           `{"lib":{"version":1,"bucket":"motw"}}`,
		"aggregate_libraries.json":               `{"uuid1":{"prefix":"alice"}}`,
		"motw_libraries.json":                    `{"uuid1":{"librarian":"alice"}}`,
		"indices.json":                           `{"srcA":{"endpoint":"https://example.org"}}`,
		"keys/lib.s3.keys":                       "access-key=AKIA\nsecret-key=secret\n",
		"keys/operator.s3.keys":                  "access-key=AKIA2\nsecret-key=secret2\n",
		"keys/extra.keys":                        "access-key=AKIA3\nsecret-key=secret3\n",
		"wasabi_root.keys":                       "access-key=ROOT\nsecret-key=rootsecret\n",
		"secrets.age":                            "age-encrypted-blob",
		"secrets.key":                            "# age identity\nAGE-SECRET-KEY-1FAKE\n",
		"action_aliases.json":                    `{"mylib":{"lib":{"build":{}}}}`,
		"tailscale_state/tailscaled.state":       `{}`,
	}
	for rel, content := range files {
		abs := filepath.Join(configDir, rel)
		if err := os.MkdirAll(filepath.Dir(abs), 0o700); err != nil {
			t.Fatalf("mkdir %s: %v", filepath.Dir(abs), err)
		}
		if err := os.WriteFile(abs, []byte(content), 0o600); err != nil {
			t.Fatalf("write %s: %v", abs, err)
		}
	}
	return files
}

// seedExcludedFiles creates regenerable cache/scratch files that
// enumerateBackupFiles must skip.
func seedExcludedFiles(t *testing.T, configDir string) []string {
	t.Helper()
	rels := []string{
		"cache/vfs/accorder-serve-lib/book.epub",
		"cache/mylib.jsonl",
		"backups/action_aliases.json.bak-prune-20260101-000000",
		"indexes/legacy.idx",
		"aggregate/library_index.zst",
		"tor/cache/consensus",
		"tor/lib/cached-microdescs",
		"tor/lib/tor.log",
		"tor/lib/tor.pid",
		"tor/lib/control_port",
		"tor/lib/control_auth_cookie",
		"tor/lib/lock",
		"tailscale_state/tailscaled.log1.txt",
		"action_aliases.json.lock",
	}
	for _, rel := range rels {
		abs := filepath.Join(configDir, rel)
		if err := os.MkdirAll(filepath.Dir(abs), 0o700); err != nil {
			t.Fatalf("mkdir %s: %v", filepath.Dir(abs), err)
		}
		if err := os.WriteFile(abs, []byte("scratch"), 0o600); err != nil {
			t.Fatalf("write %s: %v", abs, err)
		}
	}
	return rels
}

func TestFedlibBackup_EnumeratesAllIdentityFiles(t *testing.T) {
	configDir := t.TempDir()
	seeded := seedIdentityFiles(t, configDir)
	// Exact-match against the seeded set below doubles as the exclusion
	// assertion: any scratch file leaking in fails the length check.
	seedExcludedFiles(t, configDir)

	got := enumerateBackupFiles(configDir)

	// Convert to relative paths for comparison.
	gotRel := make([]string, len(got))
	for i, abs := range got {
		rel, err := filepath.Rel(configDir, abs)
		if err != nil {
			t.Fatalf("rel: %v", err)
		}
		gotRel[i] = rel
	}
	sort.Strings(gotRel)

	// Build expected list from seeded files.
	expected := make([]string, 0, len(seeded))
	for k := range seeded {
		expected = append(expected, k)
	}
	sort.Strings(expected)

	if len(gotRel) != len(expected) {
		t.Fatalf("enumerate returned %d files, want %d\ngot:  %v\nwant: %v", len(gotRel), len(expected), gotRel, expected)
	}
	for i := range expected {
		if gotRel[i] != expected[i] {
			t.Errorf("file %d: got %q, want %q", i, gotRel[i], expected[i])
		}
	}
}

func TestFedlibBackup_EmptyConfigDir(t *testing.T) {
	configDir := t.TempDir()
	got := enumerateBackupFiles(configDir)
	if len(got) != 0 {
		t.Fatalf("expected 0 files from empty config dir, got %d: %v", len(got), got)
	}
}

func TestFedlibBackup_Restore_RoundTrip(t *testing.T) {

	// Set up source config dir with identity files.
	srcDir := t.TempDir()
	seeded := seedIdentityFiles(t, srcDir)

	// Run backup.
	tarball := filepath.Join(t.TempDir(), "test-backup.tar.zst")
	origConfigDir := accorderConfigDir
	accorderConfigDir = srcDir
	defer func() { accorderConfigDir = origConfigDir }()

	backupCmd := &FedlibBackupCmd{Output: tarball}
	if err := backupCmd.Run(); err != nil {
		t.Fatalf("backup: %v", err)
	}

	// Verify tarball exists.
	info, err := os.Stat(tarball)
	if err != nil {
		t.Fatalf("tarball missing: %v", err)
	}
	if info.Size() == 0 {
		t.Fatal("tarball is empty")
	}

	// Run restore to a fresh directory.
	dstDir := t.TempDir()
	restoreCmd := &FedlibRestoreCmd{Input: tarball, ConfigDir: dstDir}
	if err := restoreCmd.Run(); err != nil {
		t.Fatalf("restore: %v", err)
	}

	// Verify all files were restored with correct content.
	for rel, wantContent := range seeded {
		abs := filepath.Join(dstDir, rel)
		got, err := os.ReadFile(abs)
		if err != nil {
			t.Errorf("restored file %s: %v", rel, err)
			continue
		}
		if string(got) != wantContent {
			t.Errorf("restored file %s: content mismatch\ngot:  %q\nwant: %q", rel, string(got), wantContent)
		}

		// Verify permissions are restrictive (0600 or tighter).
		finfo, err := os.Stat(abs)
		if err != nil {
			t.Errorf("stat %s: %v", rel, err)
			continue
		}
		perm := finfo.Mode().Perm()
		if perm&0o077 != 0 {
			t.Errorf("restored file %s has too-open permissions: %o (want group/other bits clear)", rel, perm)
		}
	}
}

func TestFedlibRestore_OnionAddressPreserved(t *testing.T) {
	srcDir := t.TempDir()
	seedIdentityFiles(t, srcDir)

	tarball := filepath.Join(t.TempDir(), "test-backup.tar.zst")
	origConfigDir := accorderConfigDir
	accorderConfigDir = srcDir
	defer func() { accorderConfigDir = origConfigDir }()

	backupCmd := &FedlibBackupCmd{Output: tarball}
	if err := backupCmd.Run(); err != nil {
		t.Fatalf("backup: %v", err)
	}

	dstDir := t.TempDir()
	restoreCmd := &FedlibRestoreCmd{Input: tarball, ConfigDir: dstDir}
	if err := restoreCmd.Run(); err != nil {
		t.Fatalf("restore: %v", err)
	}

	// Verify .onion address is preserved.
	hostname, err := os.ReadFile(filepath.Join(dstDir, "tor", "lib", "hostname"))
	if err != nil {
		t.Fatalf("read hostname: %v", err)
	}
	if strings.TrimSpace(string(hostname)) != "exampleonion.onion" {
		t.Errorf("onion address not preserved: got %q", string(hostname))
	}

	// Verify signing key is preserved (non-regenerable).
	sigKey, err := os.ReadFile(filepath.Join(dstDir, "clearnet", "lib", "signing.key"))
	if err != nil {
		t.Fatalf("read signing key: %v", err)
	}
	if string(sigKey) != "fake-signing-key-32-bytes!!!!!!!" {
		t.Errorf("signing key not preserved: got %q", string(sigKey))
	}
}

func TestFedlibRestore_RejectsPathTraversal(t *testing.T) {

	// Create a malicious tarball with a path traversal entry.
	tarball := filepath.Join(t.TempDir(), "evil.tar.zst")
	f, err := os.Create(tarball)
	if err != nil {
		t.Fatal(err)
	}
	zw, _ := zstd.NewWriter(f)
	tw := tar.NewWriter(zw)

	_ = tw.WriteHeader(&tar.Header{
		Name: "../../../etc/evil",
		Mode: 0o600,
		Size: 4,
	})
	_, _ = tw.Write([]byte("evil"))
	tw.Close()
	zw.Close()
	f.Close()

	dstDir := t.TempDir()
	restoreCmd := &FedlibRestoreCmd{Input: tarball, ConfigDir: dstDir}
	err = restoreCmd.Run()
	if err == nil {
		t.Fatal("expected error for path traversal, got nil")
	}
	if !strings.Contains(err.Error(), "unsafe path") {
		t.Errorf("expected 'unsafe path' error, got: %v", err)
	}
}

func TestFedlibBackup_CategorizeFiles(t *testing.T) {
	configDir := t.TempDir()
	seedIdentityFiles(t, configDir)

	files := enumerateBackupFiles(configDir)
	summary := categorizeBackupFiles(configDir, files)

	for _, want := range []string{"tor file", "signing key", "grant", "registry", "secrets-store", "credential key", "tailscale state", "other config"} {
		if !strings.Contains(summary, want) {
			t.Errorf("summary %q missing expected category %q", summary, want)
		}
	}
}

func TestFedlibBackup_TarballContents(t *testing.T) {
	srcDir := t.TempDir()
	seeded := seedIdentityFiles(t, srcDir)
	seedExcludedFiles(t, srcDir)

	tarball := filepath.Join(t.TempDir(), "test-backup.tar.zst")
	origConfigDir := accorderConfigDir
	accorderConfigDir = srcDir
	defer func() { accorderConfigDir = origConfigDir }()

	backupCmd := &FedlibBackupCmd{Output: tarball}
	if err := backupCmd.Run(); err != nil {
		t.Fatalf("backup: %v", err)
	}

	// Open and list tarball contents.
	f, _ := os.Open(tarball)
	defer f.Close()
	zr, _ := zstd.NewReader(f)
	defer zr.Close()
	tr := tar.NewReader(zr)

	var names []string
	for {
		hdr, err := tr.Next()
		if err == io.EOF {
			break
		}
		if err != nil {
			t.Fatalf("read tar: %v", err)
		}
		names = append(names, hdr.Name)
	}
	sort.Strings(names)

	// All identity files and nothing else — excluded scratch must not leak in.
	if len(names) != len(seeded) {
		t.Errorf("expected %d entries in tarball, got %d: %v", len(seeded), len(names), names)
	}
}
