package cmd

import (
	"bytes"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"reflect"
	"sort"
	"strings"
	"time"

	"github.com/alecthomas/kong"
	"github.com/tidwall/gjson"
	"github.com/tidwall/sjson"
)

func typeHasAliasField(t reflect.Type, jsonKey string) bool {
	tags, ok := getFieldTags(t, jsonKey)
	return ok && tags.JSONName != "" && tags.JSONName != "-" &&
		!tags.ExcludeFromAlias
}

type rotKind int

const (
	rotDeadKey rotKind = iota
	rotDeadSubtree
	rotDefaultShadow
	rotDanglingPath
	rotExcludedKey
	rotEmptyNode
	rotForeignKey
	rotCorruptEntry

	rotStaleCacheTree
	rotRetainedAliasJSONL

	rotDriftedKey

	rotKindCount
)

func (k rotKind) deletable() bool {
	switch k {
	case rotDeadKey, rotDefaultShadow, rotExcludedKey, rotEmptyNode:
		return true
	}

	return false
}

type rotFinding struct {
	File    string
	Alias   string
	Path    string
	EscPath string
	Kind    rotKind
	Value   string
	Reason  string
}

func escapeGJSONKey(k string) string {
	var b strings.Builder
	for _, r := range k {
		switch r {
		case '.', '*', '?', '\\', '|', '#', '@':
			b.WriteByte('\\')
		}
		b.WriteRune(r)
	}
	return b.String()
}

func isEmptyObject(v gjson.Result) bool {
	if !v.IsObject() {
		return false
	}
	empty := true
	v.ForEach(func(_, _ gjson.Result) bool { empty = false; return false })
	return empty
}

var aliasSideChannelKeys = map[string]map[string]bool{
	"":           sideChannelSet(nil, "taught"),
	"lib.browse": sideChannelSet(browseSourceKeys, browseIndexDescriptionsKey),
}

func sideChannelSet(keys []string, extra ...string) map[string]bool {
	set := make(map[string]bool, len(keys)+len(extra))
	for _, k := range append(extra, keys...) {
		set[k] = true
	}
	return set
}

var danglingPathKeys = map[string]bool{
	"calibrepath": true,
	"index-path":  true,
	"jsonl-path":  true,
	"keys-file":   true,
}

func shadowsDefault(stored, computed string) bool {
	return stored != "" && computed != "" &&
		filepath.Clean(stored) == filepath.Clean(computed)
}

type rotScanner struct {
	root          *kong.Node
	alias         string
	computedIndex string
	computedJsonl string
	findings      []rotFinding
	liveLeaves    []liveLeaf
}

type liveLeaf struct {
	path  string
	key   string
	value string
	group string
}

func scanAliasRot(root *kong.Node, cfg []byte, alias string) []rotFinding {
	if !isValidAliasName(alias) {
		return nil
	}
	node := gjson.GetBytes(cfg, alias)
	if !node.Exists() || !node.IsObject() {
		return nil
	}
	s := &rotScanner{root: root, alias: alias}
	if cp := gjson.GetBytes(cfg, alias+".lib.build.calibrepath").String(); cp != "" {
		s.computedIndex = filepath.Join(cp, "static", "library_index")
	}
	s.computedJsonl = filepath.Join(accorderCacheDir(), alias+".jsonl")

	if isEmptyObject(node) {
		s.add(rotFinding{Kind: rotEmptyNode, Reason: "empty profile"})
		return s.findings
	}
	s.walk(node, "", "")
	s.detectDrift()
	return s.findings
}

func (s *rotScanner) propagationGroup(dotted, key string, tags fieldTags) string {
	if tags.SharedGroup != "" {
		return "shared:" + tags.SharedGroup + ":" + key
	}
	node := findNodeByPath(s.root, dotted)
	if node == nil || node.Group == nil || node.Group.Key == "" {
		return ""
	}
	return "group:" + node.Group.Key + ":" + key
}

func (s *rotScanner) detectDrift() {
	byGroup := map[string][]liveLeaf{}
	order := []string{}
	for _, l := range s.liveLeaves {
		if _, seen := byGroup[l.group]; !seen {
			order = append(order, l.group)
		}
		byGroup[l.group] = append(byGroup[l.group], l)
	}
	for _, g := range order {
		leaves := byGroup[g]
		if len(leaves) < 2 {
			continue
		}
		distinct := map[string][]string{}
		values := []string{}
		for _, l := range leaves {
			v := l.value
			if danglingPathKeys[l.key] && v != "" {
				v = filepath.Clean(v)
			}
			if _, seen := distinct[v]; !seen {
				values = append(values, v)
			}
			distinct[v] = append(distinct[v], l.path)
		}
		if len(values) < 2 {
			continue
		}
		var parts []string
		for _, v := range values {
			parts = append(parts, fmt.Sprintf("%q at %s", v, strings.Join(distinct[v], ", ")))
		}
		s.add(rotFinding{
			Path:   leaves[0].key,
			Kind:   rotDriftedKey,
			Value:  leaves[0].value,
			Reason: "conflicting values across commands that share this setting: " + strings.Join(parts, " vs "),
		})
	}
}

func (s *rotScanner) add(f rotFinding) {
	f.Alias = s.alias
	s.findings = append(s.findings, f)
}

func (s *rotScanner) walk(node gjson.Result, dotted, escDotted string) {
	kongNode := s.root
	if dotted != "" {
		kongNode = findNodeByPath(s.root, dotted)
	}
	var kongType reflect.Type
	if kongNode != nil && kongNode.Target.IsValid() && kongNode.Target.Type().Kind() == reflect.Struct {
		kongType = kongNode.Target.Type()
	}
	node.ForEach(func(k, v gjson.Result) bool {
		key := k.String()
		childPath := key
		escChild := escapeGJSONKey(key)
		if dotted != "" {
			childPath = dotted + "." + key
			escChild = escDotted + "." + escChild
		}
		if isEmptyObject(v) {
			s.add(rotFinding{Path: childPath, EscPath: escChild, Kind: rotEmptyNode, Reason: "empty node"})
			return true
		}
		if v.IsObject() && findNodeByPath(s.root, childPath) != nil {
			s.walk(v, childPath, escChild)
			return true
		}
		if kongType != nil && !v.IsObject() {
			if typeHasAliasField(kongType, key) {
				s.inspectLiveLeaf(childPath, escChild, dotted, kongType, key, v)
				return true
			}
			if tags, ok := getFieldTags(kongType, key); ok && tags.ExcludeFromAlias {
				s.add(rotFinding{Path: childPath, EscPath: escChild, Kind: rotExcludedKey,
					Reason: "secret-bearing field persisted (--apply migrates S3 credentials to the keys file, then removes leftovers)"})
				return true
			}
		}
		if aliasSideChannelKeys[dotted][key] {
			return true
		}
		if v.IsObject() {
			s.add(rotFinding{Path: childPath, EscPath: escChild, Kind: rotDeadSubtree,
				Reason: "unknown command path on this build (another build variant?)"})
			return true
		}

		if v.Type == gjson.String && isAliasCredKey(key) {
			s.add(rotFinding{Path: childPath, EscPath: escChild, Kind: rotExcludedKey,
				Reason: "secret-bearing field persisted (--apply migrates S3 credentials to the keys file, then removes leftovers)"})
			return true
		}
		at := "profile root"
		if dotted != "" {
			at = strings.ReplaceAll(dotted, ".", " ")
		}
		reason := fmt.Sprintf("no such flag on %s", at)

		if kongNode != nil {
			for _, fl := range kongNode.Flags {
				if fl.Name == key {
					reason = fmt.Sprintf("never-persisted flag --%s (json:\"-\"); stored copy is ignored on recall and deletable", key)
					break
				}
			}
		}
		s.add(rotFinding{Path: childPath, EscPath: escChild, Kind: rotDeadKey, Value: v.String(),
			Reason: reason})
		return true
	})
}

var shadowEligibleNodes = map[string]bool{
	"lib.build":   true,
	"lib.publish": true,
	"lib.upload":  true,
}

func (s *rotScanner) inspectLiveLeaf(childPath, escPath, dotted string, kongType reflect.Type, key string, v gjson.Result) {
	stored := v.String()
	required := false
	if tags, ok := getFieldTags(kongType, key); ok {
		required = tags.Required
		if g := s.propagationGroup(dotted, key, tags); g != "" {
			s.liveLeaves = append(s.liveLeaves, liveLeaf{path: childPath, key: key, value: stored, group: g})
		}
	}
	if !required && shadowEligibleNodes[dotted] {
		switch key {
		case "index-path":
			if shadowsDefault(stored, s.computedIndex) {
				s.add(rotFinding{Path: childPath, EscPath: escPath, Kind: rotDefaultShadow, Value: stored,
					Reason: "equals computed default <calibrepath>/static/library_index"})
				return
			}
		case "jsonl-path":
			if shadowsDefault(stored, s.computedJsonl) {
				s.add(rotFinding{Path: childPath, EscPath: escPath, Kind: rotDefaultShadow, Value: stored,
					Reason: "equals computed default cache/<alias>.jsonl"})
				return
			}
		}
	}
	if danglingPathKeys[key] && stored != "" {
		probe := stored
		if key == "index-path" {
			probe = stored + ".zst"
		}
		if _, err := os.Stat(probe); err != nil {
			if _, err := os.Stat(stored); err != nil {
				s.add(rotFinding{Path: childPath, EscPath: escPath, Kind: rotDanglingPath, Value: stored,
					Reason: "path does not exist (report-only)"})
			}
		}
	}
}

func lastDottedSegment(path string) string {
	if i := strings.LastIndex(path, "."); i >= 0 {
		return path[i+1:]
	}
	return path
}

func applyRotDeletions(cfg []byte, findings []rotFinding, aliases []string) ([]byte, map[rotKind]int, int) {
	deleted := make(map[rotKind]int)
	for _, f := range findings {
		if !f.Kind.deletable() || f.Kind == rotEmptyNode {
			continue
		}
		path := f.Alias
		if f.EscPath != "" {
			path += "." + f.EscPath
		}
		if f.Kind == rotExcludedKey && isAliasCredKey(lastDottedSegment(f.Path)) &&
			gjson.GetBytes(cfg, path).Exists() {

			log.Printf("[B1] prune: %s not deleted — credential migration could not preserve it (see migration warnings above)", path)
			continue
		}
		out, err := sjson.DeleteBytes(cfg, path)
		if err != nil || bytes.Equal(out, cfg) {
			continue
		}
		cfg = out
		deleted[f.Kind]++
	}
	cfg, removedNodes := cleanupEmptyNodes(cfg, aliases)
	return cfg, deleted, removedNodes
}

func cleanupEmptyNodes(cfg []byte, aliases []string) ([]byte, int) {
	removed := 0
	for changed := true; changed; {
		changed = false
		var empties []string
		var walk func(prefix string, v gjson.Result)
		walk = func(prefix string, v gjson.Result) {
			v.ForEach(func(k, cv gjson.Result) bool {
				p := prefix + "." + escapeGJSONKey(k.String())
				if cv.IsObject() {
					if isEmptyObject(cv) {
						empties = append(empties, p)
					} else {
						walk(p, cv)
					}
				}
				return true
			})
		}
		for _, alias := range aliases {
			node := gjson.GetBytes(cfg, alias)
			if !node.Exists() || !node.IsObject() {
				continue
			}
			if isEmptyObject(node) {
				empties = append(empties, alias)
				continue
			}
			walk(alias, node)
		}
		for _, p := range empties {
			out, err := sjson.DeleteBytes(cfg, p)
			if err != nil || bytes.Equal(out, cfg) {
				continue
			}
			cfg = out
			removed++
			changed = true
		}
	}
	return cfg, removed
}

func backupActionAliases(label string) (string, error) {
	dir := filepath.Join(accorderConfigDir, "backups")
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return "", err
	}
	dst := filepath.Join(dir, fmt.Sprintf("action_aliases.json.bak-%s-%s",
		label, time.Now().Format("20060102-150405")))
	return dst, os.WriteFile(dst, loadActionAliases(), 0o600)
}

func kongRootNode(ctx *kong.Context) *kong.Node {
	root := ctx.Selected()
	for root != nil && root.Parent != nil {
		root = root.Parent
	}
	return root
}

type AliasPruneCmd struct {
	Name  string `arg:"" optional:"" help:"Limit pruning to one action alias." validate:"omitempty,alias"`
	Apply bool   `help:"Delete dead keys, default shadows, leaked secret keys, and empty nodes (a timestamped backup is written first). Default is a dry-run report."`

	ApplyCacheTrees bool `name:"apply-cache-trees" help:"Delete stranded VFS cache trees (lock-gated; runs interrupted-migration recovery first). Legacy pre-ledger trees additionally require --attest-no-serves. Independent of --apply."`
	AttestNoServes  bool `name:"attest-no-serves" help:"Operator attestation that no accorder serve — including pre-protocol binaries, now or later — runs against this cache dir. Activates the reclaim protocol and licenses legacy-tree deletion. Only meaningful with --apply-cache-trees."`
}

func (c *AliasPruneCmd) Run(ctx *kong.Context) error {
	root := kongRootNode(ctx)
	if c.Name != "" && !isValidAliasName(c.Name) {
		return fmt.Errorf("invalid profile name %q (must be alphanumeric + hyphens)", c.Name)
	}
	if c.AttestNoServes && !c.ApplyCacheTrees {
		return fmt.Errorf("--attest-no-serves requires --apply-cache-trees (attestation never activates or deletes on its own)")
	}
	if c.ApplyCacheTrees && c.Name != "" {
		return fmt.Errorf("--apply-cache-trees is only valid on an unscoped run (cache trees are not per-alias findings)")
	}

	cfg := loadActionAliases()

	aliases := GetAllAliases()
	if c.Name != "" {
		if !gjson.GetBytes(cfg, c.Name).Exists() {
			return fmt.Errorf("alias %q not found", c.Name)
		}
		aliases = []string{c.Name}
	}

	var companionFindings []rotFinding
	var cacheScan *cacheScanResult
	var cacheFindings []rotFinding
	if c.Name == "" {
		var cerr error
		companionFindings, cerr = scanAllCompanionRot(accorderConfigDir)
		if cerr != nil {
			return cerr
		}

		cacheScan, cerr = scanCacheTrees(defaultSizeBudget)
		if cerr != nil {
			return cerr
		}
		cacheFindings = cacheRotFindings(cacheScan)
	}

	if len(aliases) == 0 && len(companionFindings) == 0 && len(cacheFindings) == 0 {

		if c.ApplyCacheTrees {
			if err := c.applyCacheTrees(cacheScan); err != nil {
				return err
			}
		}
		fmt.Println("No saved profiles.")
		return nil
	}
	sort.Strings(aliases)

	if len(aliases) > 0 {
		fmt.Printf("Scanning %d %s against this binary's command tree...\n\n",
			len(aliases), plural(len(aliases), "profile", "profiles"))
	}

	var findings []rotFinding
	for _, alias := range aliases {
		findings = append(findings, scanAliasRot(root, cfg, alias)...)
	}
	findings = append(findings, companionFindings...)
	findings = append(findings, cacheFindings...)
	if len(findings) == 0 {

		if c.ApplyCacheTrees {
			if err := c.applyCacheTrees(cacheScan); err != nil {
				return err
			}
		}
		fmt.Println("No rot found.")
		return nil
	}

	renderRotFindings(findings)
	if cacheScan != nil {
		reportCacheScanNotes(cacheScan)
	}
	fmt.Println()
	fmt.Println(rotSummaryLine(findings))

	if c.ApplyCacheTrees {
		if err := c.applyCacheTrees(cacheScan); err != nil {
			return err
		}
	}

	deletableCount := 0
	for _, f := range findings {
		if f.Kind.deletable() {
			deletableCount++
		}
	}
	if !c.Apply {
		if deletableCount > 0 {
			fmt.Println("Run again with --apply to delete dead keys, shadows, leaked secret keys, and empty nodes (backup written first).")
		}
		if !c.ApplyCacheTrees {
			for _, f := range findings {
				if f.Kind == rotStaleCacheTree {
					fmt.Println("Run again with --apply-cache-trees to delete stranded cache trees (legacy trees additionally need --attest-no-serves).")
					break
				}
			}
		}
		return nil
	}
	if deletableCount == 0 {
		fmt.Println("Nothing deletable — only report-only findings remain.")
		return nil
	}

	unlockAliasCfg := lockAliasConfigOrDie()
	defer unlockAliasCfg()
	backupPath, err := backupActionAliases("prune")
	if err != nil {
		return fmt.Errorf("backup before prune: %w", err)
	}
	fmt.Printf("Backup: %s\n", backupPath)

	cfg = loadActionAliases()
	if migrateAliasCredentials(&cfg) {
		fmt.Println("Migrated persisted S3 credentials to keys files (lossless).")
	}
	cfg, deleted, removedNodes := applyRotDeletions(cfg, findings, aliases)
	saveActionAliases(cfg)
	fmt.Printf("Deleted %d dead %s, %d leaked secret %s, %d default %s; removed %d empty %s.\n",
		deleted[rotDeadKey], plural(deleted[rotDeadKey], "key", "keys"),
		deleted[rotExcludedKey], plural(deleted[rotExcludedKey], "key", "keys"),
		deleted[rotDefaultShadow], plural(deleted[rotDefaultShadow], "shadow", "shadows"),
		removedNodes, plural(removedNodes, "node", "nodes"))
	return nil
}

func renderRotFindings(findings []rotFinding) {

	var aliasFindings, companionFindings []rotFinding
	for _, f := range findings {
		if f.File == "" {
			aliasFindings = append(aliasFindings, f)
			continue
		}
		companionFindings = append(companionFindings, f)
	}

	byAlias := make(map[string][]rotFinding)
	var aliases []string
	for _, f := range aliasFindings {
		if _, seen := byAlias[f.Alias]; !seen {
			aliases = append(aliases, f.Alias)
		}
		byAlias[f.Alias] = append(byAlias[f.Alias], f)
	}
	sort.Strings(aliases)
	for _, alias := range aliases {
		fmt.Printf("  %s:\n", alias)
		for _, f := range byAlias[alias] {
			fmt.Printf("    %s\n", formatRotFinding(f))
		}
	}

	renderCompanionFindings(companionFindings)
}

func renderCompanionFindings(findings []rotFinding) {
	if len(findings) == 0 {
		return
	}
	byFile := make(map[string]map[string][]rotFinding)
	var files []string
	for _, f := range findings {
		if _, seen := byFile[f.File]; !seen {
			files = append(files, f.File)
			byFile[f.File] = make(map[string][]rotFinding)
		}
		byFile[f.File][f.Alias] = append(byFile[f.File][f.Alias], f)
	}
	sort.Strings(files)
	for _, file := range files {
		fmt.Printf("  %s:\n", file)
		entries := make([]string, 0, len(byFile[file]))
		for entry := range byFile[file] {
			entries = append(entries, entry)
		}
		sort.Strings(entries)
		for _, entry := range entries {
			fmt.Printf("    %s:\n", entry)
			for _, f := range byFile[file][entry] {
				fmt.Printf("      %s\n", formatRotFinding(f))
			}
		}
	}
}

func formatRotFinding(f rotFinding) string {
	path := f.Path
	if path == "" {
		path = "(profile)"
	}
	switch f.Kind {
	case rotDeadKey:
		return fmt.Sprintf("✗ dead    %s = %q  (%s)", path, f.Value, f.Reason)
	case rotExcludedKey:
		return fmt.Sprintf("✗ secret  %s  (%s)", path, f.Reason)
	case rotDefaultShadow:
		return fmt.Sprintf("~ shadow  %s = %q  (%s)", path, f.Value, f.Reason)
	case rotDanglingPath:
		return fmt.Sprintf("! path    %s = %q  (%s)", path, f.Value, f.Reason)
	case rotDriftedKey:
		return fmt.Sprintf("≠ drift   %s  (%s)", path, f.Reason)
	case rotDeadSubtree:
		return fmt.Sprintf("? subtree %s  (%s)", path, f.Reason)
	case rotEmptyNode:
		return fmt.Sprintf("∅ empty   %s  (%s)", path, f.Reason)
	case rotForeignKey:
		return fmt.Sprintf("⚑ foreign %s  (%s)  = %s", path, f.Reason, f.Value)
	case rotCorruptEntry:
		return fmt.Sprintf("⚠ corrupt entry  (%s)", f.Reason)
	case rotStaleCacheTree:
		return fmt.Sprintf("✗ stranded cache tree  %s  (%s)", f.Value, f.Reason)
	case rotRetainedAliasJSONL:
		return fmt.Sprintf("⚑ retained %s  (%s)", f.Value, f.Reason)
	}
	return fmt.Sprintf("? %s (%s)", path, f.Reason)
}

func rotSummaryLine(findings []rotFinding) string {
	counts := make(map[rotKind]int)
	for _, f := range findings {
		counts[f.Kind]++
	}
	var parts []string
	addPart := func(k rotKind, singular, pluralForm string) {
		if n := counts[k]; n > 0 {
			parts = append(parts, fmt.Sprintf("%d %s", n, plural(n, singular, pluralForm)))
		}
	}
	addPart(rotDeadKey, "dead key", "dead keys")
	addPart(rotExcludedKey, "leaked secret key", "leaked secret keys")
	addPart(rotDefaultShadow, "default shadow", "default shadows")
	addPart(rotDanglingPath, "dangling path", "dangling paths")
	addPart(rotDeadSubtree, "unknown subtree", "unknown subtrees")
	addPart(rotDriftedKey, "drifted setting", "drifted settings")
	addPart(rotEmptyNode, "empty node", "empty nodes")
	addPart(rotForeignKey, "foreign key", "foreign keys")
	addPart(rotCorruptEntry, "corrupt entry", "corrupt entries")
	addPart(rotStaleCacheTree, "stranded cache tree", "stranded cache trees")
	addPart(rotRetainedAliasJSONL, "retained build snapshot", "retained build snapshots")
	return strings.Join(parts, ", ") + "."
}
