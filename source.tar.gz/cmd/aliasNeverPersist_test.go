//go:build !tailscale

package cmd

import (
	"os"
	"testing"
)

// ca-122 regression: diagnostic-class flags carry json:"-" and must never
// enter the alias store, while tuning flags in the same struct keep
// persisting.
func TestAliasNeverPersist_RcloneLogLevelNotSaved(t *testing.T) {
	testSetup(t)
	// ca-125: live serve validates descriptor existence at parse time.
	if err := saveFedlibDescriptor("npdemo", fedlibDescriptor{Version: fedlibDescriptorVersion}); err != nil {
		t.Fatal(err)
	}
	parseCLI(t, []string{"fedlib", "share", "live", "npdemo",
		"--aggregate-path", "/tmp/agg",
		"--rclone-log-level", "INFO",
		"--cache-size", "1Gi"})
	alias := readAlias(t, "npdemo")
	live := alias.Get("fedlib.share.live")
	if live.Get("rclone-log-level").Exists() {
		t.Error("--rclone-log-level should not be persisted to alias (json:\"-\")")
	}
	if live.Get("cache-size").String() != "1Gi" {
		t.Errorf("control --cache-size not persisted: got %q", live.Get("cache-size").String())
	}
}

// ca-122 regression: a legacy rclone-log-level key already in the store (the
// incident left one behind, value INFO) must be inert on recall — the
// json:"-" field stays empty so rclone keeps its default — while tuning keys
// in the same subtree still recall.
func TestAliasNeverPersist_LegacyRcloneLogLevelNotRecalled(t *testing.T) {
	testSetup(t)
	seed := `{"npdemo":{"fedlib":{"share":{"live":{"rclone-log-level":"INFO","cache-size":"2Gi"}}}}}`
	if err := os.WriteFile(savedActionAliases, []byte(seed), 0o600); err != nil {
		t.Fatal(err)
	}
	// ca-125: live serve validates descriptor existence at parse time.
	if err := saveFedlibDescriptor("npdemo", fedlibDescriptor{Version: fedlibDescriptorVersion}); err != nil {
		t.Fatal(err)
	}
	cli, _ := parseCLI(t, []string{"fedlib", "share", "live", "npdemo",
		"--aggregate-path", "/tmp/agg"})
	live := cli.Fedlib.Share.Live
	if live.RcloneLogLevel != "" {
		t.Errorf("legacy rclone-log-level recalled: got %q, want empty (rclone default NOTICE)", live.RcloneLogLevel)
	}
	if live.CacheSize != "2Gi" {
		t.Errorf("control cache-size not recalled: got %q, want 2Gi", live.CacheSize)
	}
}

// ca-122: once the field is json:"-", a legacy stored key no longer matches
// any alias field, so config prune reports it as a deletable dead key; the
// tuning key next to it stays a live leaf with no finding.
func TestAliasNeverPersist_LegacyKeyIsPruneDeadKey(t *testing.T) {
	testSetup(t)
	seed := `{"npdemo":{"fedlib":{"share":{"live":{"rclone-log-level":"NOTICE","cache-size":"2Gi"}}}}}`
	if err := os.WriteFile(savedActionAliases, []byte(seed), 0o600); err != nil {
		t.Fatal(err)
	}
	_, ctx := parseCLI(t, []string{"config", "prune"})
	root := kongRootNode(ctx)
	cfg := loadActionAliases()
	findings := scanAliasRot(root, cfg, "npdemo")

	found := false
	for _, f := range findings {
		switch f.Path {
		case "fedlib.share.live.rclone-log-level":
			found = true
			if f.Kind != rotDeadKey {
				t.Errorf("legacy key kind = %d, want rotDeadKey (%d)", f.Kind, rotDeadKey)
			}
		case "fedlib.share.live.cache-size":
			t.Errorf("live tuning key wrongly flagged: kind %d", f.Kind)
		}
	}
	if !found {
		t.Errorf("legacy rclone-log-level not reported by prune; findings: %+v", findings)
	}
}

// ca-122: a stored key under a command path that is NOT registered on this
// build (fedlib share funnel only exists under -tags tailscale) must classify
// as a report-only dead subtree, never as a deletable dead key — prune must
// not offer to delete state that another build variant may still own.
func TestAliasNeverPersist_FunnelSubtreeIsDeadSubtreeOnNonTailscale(t *testing.T) {
	testSetup(t)
	seed := `{"npdemo":{"fedlib":{"share":{"funnel":{"rclone-log-level":"INFO"}}}}}`
	if err := os.WriteFile(savedActionAliases, []byte(seed), 0o600); err != nil {
		t.Fatal(err)
	}
	_, ctx := parseCLI(t, []string{"config", "prune"})
	root := kongRootNode(ctx)
	cfg := loadActionAliases()
	findings := scanAliasRot(root, cfg, "npdemo")

	found := false
	for _, f := range findings {
		if f.Path == "fedlib.share.funnel" {
			found = true
			if f.Kind != rotDeadSubtree {
				t.Errorf("funnel subtree kind = %d, want rotDeadSubtree (%d)", f.Kind, rotDeadSubtree)
			}
		}
		if f.Path == "fedlib.share.funnel.rclone-log-level" && f.Kind == rotDeadKey {
			t.Errorf("funnel leaf wrongly classified as deletable dead key")
		}
	}
	if !found {
		t.Errorf("funnel dead subtree not reported by prune; findings: %+v", findings)
	}
}

// A `lib` subcommand the alias has never run must adopt the library identity
// its siblings already carry, not mint a fresh one.
//
// The incident: an alias published for months under one UUID had never run
// `lib status`. One `lib status` found that subcommand's --libraryID empty,
// minted a new UUID and a generated librarian name, and propagateSharedField
// wrote both across all seven `lib` subcommands that accept them — replacing
// the published identity everywhere. The next publish would have been refused
// by its own remote for a UUID mismatch. "This subcommand's field is empty" is
// not "this library has no identity".
func TestAliasAdoptsSiblingIdentityInsteadOfMinting(t *testing.T) {
	testSetup(t)
	const (
		uuid      = "fac314b6-cfa9-4d2b-99d6-e40a37599cdd"
		librarian = "marcell mars"
	)
	library := t.TempDir()
	seed := `{"lib1":{"lib":{"publish":{"libraryID":"` + uuid + `","librarian":"` + librarian + `","calibrepath":"` + library + `"},` +
		`"build":{"dictID":55,"fedlibPrefix":"marcell"}}}}`
	if err := os.WriteFile(savedActionAliases, []byte(seed), 0o600); err != nil {
		t.Fatal(err)
	}

	// lib status has no saved subtree at all: the pre-incident state.
	parseCLI(t, []string{"lib", "status", "lib1",
		"--bucket", "b/p", "--s3-access-key", "k", "--s3-secret-key", "s",
		"--s3-provider", "Wasabi", "--s3-endpoint", "https://example.invalid"})

	alias := readAlias(t, "lib1")
	for _, path := range []string{"lib.publish", "lib.build", "lib.upload", "lib.status"} {
		if got := alias.Get(path + ".libraryID").String(); got != "" && got != uuid {
			t.Errorf("%s.libraryID = %q, want the alias's published %q", path, got, uuid)
		}
		if got := alias.Get(path + ".librarian").String(); got != "" && got != librarian {
			t.Errorf("%s.librarian = %q, want the alias's published %q", path, got, librarian)
		}
	}
	if got := alias.Get("lib.publish.libraryID").String(); got != uuid {
		t.Fatalf("the published subcommand lost its identity: %q", got)
	}

	// The alias knows where the library is; a subcommand that has never run
	// must not report it missing.
	if got := alias.Get("lib.status.calibrepath").String(); got != library {
		t.Errorf("lib.status.calibrepath = %q, want the alias's %q", got, library)
	}
}

// The federation fields must travel with the alias like every other shared
// field, in both directions: adopted by a subcommand that has never run, and
// propagated when an operator passes the flag.
//
// Losing them is silent. libBuild refuses a reserved DictID only when
// FedlibPrefix is set, so a build that inherited neither produces a member
// index with DictID 0, no aggregate fields and no /files/<prefix> in any book
// URL, with no error. dictID and fedlibPrefix were the only two fields in
// GroupLib that `lib join` propagated (group name hardcoded) while the
// flag-save path did not (per-field tag missing).
func TestFederationFieldsTravelWithTheAlias(t *testing.T) {
	testSetup(t)
	library := t.TempDir()

	t.Run("adopted by a subcommand that has never run", func(t *testing.T) {
		testSetup(t)
		seed := `{"fed":{"lib":{"build":{"dictID":55,"fedlibPrefix":"marcell","calibrepath":"` + library + `"}}}}`
		if err := os.WriteFile(savedActionAliases, []byte(seed), 0o600); err != nil {
			t.Fatal(err)
		}
		cli, _ := parseCLI(t, []string{"lib", "publish", "fed",
			"--bucket", "b/p", "--s3-access-key", "k", "--s3-secret-key", "s",
			"--s3-provider", "Wasabi", "--s3-endpoint", "https://example.invalid"})
		if got := cli.Lib.Publish.DictID; got != 55 {
			t.Errorf("publish DictID = %d, want the alias's 55 (0 builds a reserved member index)", got)
		}
		if got := cli.Lib.Publish.FedlibPrefix; got != "marcell" {
			t.Errorf("publish FedlibPrefix = %q, want the alias's \"marcell\" (empty drops /files/<prefix> from every book URL)", got)
		}
	})

	t.Run("propagated when the operator passes the flag", func(t *testing.T) {
		testSetup(t)
		seed := `{"fed":{"lib":{"build":{"calibrepath":"` + library + `"},"publish":{"calibrepath":"` + library + `"}}}}`
		if err := os.WriteFile(savedActionAliases, []byte(seed), 0o600); err != nil {
			t.Fatal(err)
		}
		// The server-side recompile the --dictID help text describes.
		parseCLI(t, []string{"lib", "build", "fed", "--dictID", "55", "--fedlibPrefix", "marcell"})
		alias := readAlias(t, "fed")
		if got := alias.Get("lib.publish.dictID").Uint(); got != 55 {
			t.Errorf("lib.publish.dictID = %d, want 55 propagated from the build that set it", got)
		}
		if got := alias.Get("lib.publish.fedlibPrefix").String(); got != "marcell" {
			t.Errorf("lib.publish.fedlibPrefix = %q, want \"marcell\"", got)
		}
	})
}
