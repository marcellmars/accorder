//go:build !tailscale

package cmd

// ca-125 matrix: `fedlib share live` storage identity, keys path and access
// mode are owned by one descriptor snapshot loaded before the alias
// transaction; credential resolution fills only the access/secret pair; a
// mode disagreement fails closed before any write; Run consumes the
// retained snapshot without rereading fedlibs.json.

import (
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	"github.com/tidwall/gjson"
)

func seedLiveAlias(t *testing.T, alias, liveJSON string) {
	t.Helper()
	seed := `{"` + alias + `":{"fedlib":{"share":{"live":` + liveJSON + `}}}}`
	if err := os.WriteFile(savedActionAliases, []byte(seed), 0o600); err != nil {
		t.Fatal(err)
	}
}

func writeMembersJSON(t *testing.T, dir, registryJSON string) {
	t.Helper()
	if err := os.WriteFile(filepath.Join(dir, "members.json"), []byte(registryJSON), 0o600); err != nil {
		t.Fatal(err)
	}
}

func TestFedlibShareLive_ModeAssertionMatrix(t *testing.T) {
	for _, tc := range []struct {
		name     string
		descMode string
		flagMode string
		wantErr  string
		wantMode string
	}{
		{"descriptor-set_absent", "private", "", "", "private"},
		{"descriptor-set_equal", "private", "private", "", "private"},
		{"descriptor-set_different", "private", "public",
			`--mode=public conflicts with descriptor mode "private"`, ""},
		{"descriptor-empty_explicit", "", "offline-private", "", "offline-private"},
		{"descriptor-empty_absent", "", "", "", "public"},
		{"descriptor-invalid", "bogus", "", `has invalid mode "bogus"`, ""},
	} {
		t.Run(tc.name, func(t *testing.T) {
			testSetup(t)
			dir := t.TempDir()
			seedDescriptor(t, "fed", fedlibDescriptor{Mode: tc.descMode, FedlibPath: dir})

			args := []string{"fedlib", "share", "live", "fed"}
			if tc.flagMode != "" {
				args = append(args, "--mode", tc.flagMode)
			}
			cli, _, err := parseCLIErr(t, args)

			if tc.wantErr != "" {
				if err == nil || !strings.Contains(err.Error(), tc.wantErr) {
					t.Fatalf("want error containing %q, got %v", tc.wantErr, err)
				}
				return
			}
			if err != nil {
				t.Fatalf("parse: %v", err)
			}
			if got := cli.Fedlib.Share.Live.Mode; got != tc.wantMode {
				t.Errorf("Mode = %q, want %q", got, tc.wantMode)
			}
			// The mode assertion is one-run only: never persisted.
			if readAlias(t, "fed").Get("fedlib.share.live.mode").Exists() {
				t.Error("--mode leaked into the action-alias store")
			}
		})
	}
}

// A normal-run mode conflict must fail before the alias lock, credential
// migration, and any config write: the whole config tree stays
// byte-identical and the migration destination is never created.
func TestFedlibShareLive_ModeConflictWritesNothing(t *testing.T) {
	testSetup(t)
	dir := t.TempDir()
	seedDescriptor(t, "fed", fedlibDescriptor{Mode: "private", FedlibPath: dir})
	seedLiveAlias(t, "fed", `{"s3-access-key":"LEGACY_RAW_SECRET","cache-size":"2Gi"}`)

	before := snapshotDir(t, accorderConfigDir)
	_, _, err := parseCLIErr(t, []string{"fedlib", "share", "live", "fed", "--mode", "public"})
	if err == nil || !strings.Contains(err.Error(), `--mode=public conflicts with descriptor mode "private"`) {
		t.Fatalf("want mode-conflict parse error, got %v", err)
	}
	after := snapshotDir(t, accorderConfigDir)

	if len(before) != len(after) {
		t.Errorf("file count changed: %d -> %d", len(before), len(after))
	}
	for p, b := range before {
		if after[p] != b {
			t.Errorf("file %s changed on a failed run", p)
		}
	}
	for p := range after {
		if _, ok := before[p]; !ok {
			t.Errorf("file %s created on a failed run", p)
		}
	}
	if _, err := os.Stat(defaultKeysFilePath("fed")); !os.IsNotExist(err) {
		t.Error("credential-migration destination was created on a failed run")
	}
	if !strings.Contains(readAlias(t, "fed").Raw, "LEGACY_RAW_SECRET") {
		t.Error("raw alias credential was migrated or removed on a failed run")
	}
}

// An aggregate path supplied only by action-alias recall stays valid: the
// descriptor preflight must not demand it before the alias merge.
func TestFedlibShareLive_AggregatePathFromAliasRecallOnly(t *testing.T) {
	testSetup(t)
	dir := t.TempDir()
	seedDescriptor(t, "fed", fedlibDescriptor{}) // no FedlibPath
	seedLiveAlias(t, "fed", `{"aggregate-path":"`+dir+`"}`)

	cli, _ := parseCLI(t, []string{"fedlib", "share", "live", "fed"})
	if got := cli.Fedlib.Share.Live.AggregatePath; got != dir {
		t.Errorf("AggregatePath = %q, want alias-recalled %q", got, dir)
	}
}

// Explicit flags keep beating stored alias values through the retained
// locked load → migrate → overlay → unmarshal sequence.
func TestFedlibShareLive_ExplicitAggregatePathBeatsStored(t *testing.T) {
	testSetup(t)
	stored := t.TempDir()
	explicit := t.TempDir()
	seedDescriptor(t, "fed", fedlibDescriptor{})
	seedLiveAlias(t, "fed", `{"aggregate-path":"`+stored+`"}`)

	cli, _ := parseCLI(t, []string{"fedlib", "share", "live", "fed", "--aggregate-path", explicit})
	if got := cli.Fedlib.Share.Live.AggregatePath; got != explicit {
		t.Errorf("AggregatePath = %q, want explicit %q", got, explicit)
	}
	if got := readAlias(t, "fed").Get("fedlib.share.live.aggregate-path").String(); got != explicit {
		t.Errorf("stored aggregate-path = %q, want updated to %q", got, explicit)
	}
}

// An all-local registry with an S3-less descriptor stays valid: preflight
// slots empty identity without complaint and RequireS3Creds remains gated
// on the member scan.
func TestFedlibShareLive_AllLocalRegistryNeedsNoS3(t *testing.T) {
	testSetup(t)
	dir := t.TempDir()
	seedDescriptor(t, "fed", fedlibDescriptor{FedlibPath: dir})
	writeMembersJSON(t, dir, `{"11111111-1111-1111-1111-111111111111":{"librarian":"A","prefix":"a","kind":"local","local_path":"`+dir+`"}}`)

	cli, _ := parseCLI(t, []string{"fedlib", "share", "live", "fed"})
	live := &cli.Fedlib.Share.Live
	if live.Bucket != "" || live.S3AccessKey != "" {
		t.Errorf("empty descriptor identity was filled from somewhere: bucket=%q access=%q", live.Bucket, live.S3AccessKey)
	}
	hasRclone, locals, err := scanMembersForServe(dir, filepath.Join(dir, "members.json"))
	if err != nil {
		t.Fatal(err)
	}
	if hasRclone {
		t.Error("all-local registry reported rclone members — RequireS3Creds would fire")
	}
	if len(locals) != 1 {
		t.Errorf("local members = %d, want 1", len(locals))
	}
}

// Keys file and secrets store may fill only the credential pair: the
// descriptor's storage identity is immutable during credential resolution.
func TestFedlibShareLive_DescriptorIdentityImmuneToCredentialSources(t *testing.T) {
	testSetup(t)
	dir := t.TempDir()
	seedDescriptor(t, "fed", fedlibDescriptor{Bucket: "desc-bucket", FedlibPath: dir})
	if err := writeKeysFile(defaultKeysFilePath("fed"), s3KeysFile{
		AccessKey: "FILE_AK", SecretKey: "FILE_SK",
		Provider: "FileProv", Endpoint: "https://file.example.com", Bucket: "file-bucket",
	}); err != nil {
		t.Fatal(err)
	}

	cli, _ := parseCLI(t, []string{"fedlib", "share", "live", "fed"})
	live := &cli.Fedlib.Share.Live
	if live.S3AccessKey != "FILE_AK" || live.S3SecretKey != "FILE_SK" {
		t.Errorf("credential pair not filled from keys file: %q/%q", live.S3AccessKey, live.S3SecretKey)
	}
	if live.Bucket != "desc-bucket" {
		t.Errorf("Bucket = %q, want descriptor's %q (keys file must not write identity)", live.Bucket, "desc-bucket")
	}
	if live.S3Provider != "" || live.S3Endpoint != "" {
		t.Errorf("identity written by keys file: provider=%q endpoint=%q", live.S3Provider, live.S3Endpoint)
	}
}

// A descriptor-selected keys path is the only keys path live serve reads;
// relative paths resolve against the config dir, and the default migration
// path is not consulted.
func TestFedlibShareLive_DescriptorKeysPathWins(t *testing.T) {
	for _, tc := range []struct {
		name    string
		keysRef func(custom string) string
	}{
		{"absolute", func(custom string) string { return custom }},
		{"config-dir-relative", func(string) string { return filepath.Join("keys", "custom.s3.keys") }},
	} {
		t.Run(tc.name, func(t *testing.T) {
			testSetup(t)
			dir := t.TempDir()
			custom := filepath.Join(accorderConfigDir, "keys", "custom.s3.keys")
			if err := writeKeysFile(custom, s3KeysFile{AccessKey: "CUSTOM_AK", SecretKey: "CUSTOM_SK"}); err != nil {
				t.Fatal(err)
			}
			if err := writeKeysFile(defaultKeysFilePath("fed"), s3KeysFile{AccessKey: "DEFAULT_AK", SecretKey: "DEFAULT_SK"}); err != nil {
				t.Fatal(err)
			}
			seedDescriptor(t, "fed", fedlibDescriptor{FedlibPath: dir, KeysFile: tc.keysRef(custom)})

			cli, _ := parseCLI(t, []string{"fedlib", "share", "live", "fed"})
			if got := cli.Fedlib.Share.Live.S3AccessKey; got != "CUSTOM_AK" {
				t.Errorf("S3AccessKey = %q, want CUSTOM_AK from the descriptor-selected keys file", got)
			}
		})
	}
}

// Explicit credentials survive the alias transaction (json:"-" fields are
// invisible to the merge), never persist to the alias store, and keep the
// deliberate keys-file persistence path.
func TestFedlibShareLive_ExplicitCredentialsSurviveAndNeverPersistToAlias(t *testing.T) {
	testSetup(t)
	dir := t.TempDir()
	seedDescriptor(t, "fed", fedlibDescriptor{FedlibPath: dir})
	// Pre-seed the default keys file with provider/endpoint that only the
	// file holds (identity is descriptor-owned and empty here): the
	// explicit-cred rewrite must round-trip them, not silently strip them
	// from a file fedlib build also reads.
	if err := writeKeysFile(defaultKeysFilePath("fed"), s3KeysFile{
		AccessKey: "OLD_AK", SecretKey: "OLD_SK",
		Provider: "Wasabi", Endpoint: "https://s3.example.com",
	}); err != nil {
		t.Fatal(err)
	}

	cli, _ := parseCLI(t, []string{"fedlib", "share", "live", "fed",
		"--s3-access-key", "EXPLICIT_AK", "--s3-secret-key", "EXPLICIT_SK"})
	live := &cli.Fedlib.Share.Live
	if live.S3AccessKey != "EXPLICIT_AK" || live.S3SecretKey != "EXPLICIT_SK" {
		t.Errorf("explicit credentials lost in alias processing: %q/%q", live.S3AccessKey, live.S3SecretKey)
	}
	raw := readAlias(t, "fed").Raw
	for _, secret := range []string{"EXPLICIT_AK", "EXPLICIT_SK", "s3-access-key", "s3-secret-key"} {
		if strings.Contains(raw, secret) {
			t.Errorf("alias store contains %q — live credentials must never persist there", secret)
		}
	}
	// Deliberate keys-file persistence stays: explicit creds are saved to
	// the resolved keys path so the next run finds them.
	kf, err := parseKeysFile(defaultKeysFilePath("fed"))
	if err != nil {
		t.Fatalf("keys-file persistence gone: %v", err)
	}
	if kf.AccessKey != "EXPLICIT_AK" {
		t.Errorf("persisted access key = %q, want EXPLICIT_AK", kf.AccessKey)
	}
	if kf.Provider != "Wasabi" || kf.Endpoint != "https://s3.example.com" {
		t.Errorf("keys-file rewrite dropped file-held identity: provider=%q endpoint=%q", kf.Provider, kf.Endpoint)
	}
}

// When credential migration fail-closes (unwritable keys dir), prune
// --apply must not delete the raw alias credential either — the alias
// store holds the only live copy.
func TestPrune_ApplyKeepsCredWhenMigrationFailsClosed(t *testing.T) {
	testSetup(t)
	seedLiveAlias(t, "fed", `{"s3-access-key":"ONLY_COPY"}`)
	keysDir := filepath.Join(accorderConfigDir, "keys")
	if err := os.MkdirAll(keysDir, 0o500); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = os.Chmod(keysDir, 0o700) })

	_, ctx := parseCLI(t, []string{"config", "prune"})
	findings := scanAliasRot(kongRootNode(ctx), loadActionAliases(), "fed")

	cfg := loadActionAliases()
	migrateAliasCredentials(&cfg)
	cfg, deleted, _ := applyRotDeletions(cfg, findings, []string{"fed"})
	if deleted[rotExcludedKey] != 0 {
		t.Errorf("excluded-key deletions = %d, want 0 when migration fail-closed", deleted[rotExcludedKey])
	}
	if got := gjson.GetBytes(cfg, "fed.fedlib.share.live.s3-access-key").String(); got != "ONLY_COPY" {
		t.Errorf("raw credential = %q, want the preserved ONLY_COPY", got)
	}
}

// A descriptor-selected keys file is operator-managed and may hold the
// federation's write credentials (fedlib build reads the same path).
// Explicit serve credentials apply to the invocation only — the file must
// stay byte-identical, unlike the per-alias default path where explicit
// creds deliberately persist.
func TestFedlibShareLive_ExplicitCredsNeverRewriteDescriptorKeysFile(t *testing.T) {
	testSetup(t)
	dir := t.TempDir()
	custom := filepath.Join(accorderConfigDir, "keys", "operator-root.s3.keys")
	if err := writeKeysFile(custom, s3KeysFile{
		AccessKey: "ROOT_AK", SecretKey: "ROOT_SK",
		Provider: "Wasabi", Endpoint: "https://s3.example.com",
		Bucket: "fed-bucket", Prefix: "agg",
	}); err != nil {
		t.Fatal(err)
	}
	before, err := os.ReadFile(custom)
	if err != nil {
		t.Fatal(err)
	}
	seedDescriptor(t, "fed", fedlibDescriptor{FedlibPath: dir, KeysFile: custom})

	cli, _ := parseCLI(t, []string{"fedlib", "share", "live", "fed",
		"--s3-access-key", "RO_AK", "--s3-secret-key", "RO_SK"})
	live := &cli.Fedlib.Share.Live
	if live.S3AccessKey != "RO_AK" || live.S3SecretKey != "RO_SK" {
		t.Errorf("explicit credentials lost: %q/%q", live.S3AccessKey, live.S3SecretKey)
	}

	after, err := os.ReadFile(custom)
	if err != nil {
		t.Fatal(err)
	}
	if string(before) != string(after) {
		t.Errorf("descriptor-selected keys file rewritten by explicit serve creds:\nbefore:\n%s\nafter:\n%s", before, after)
	}
}

// Stale alias copies of mode and storage identity are inert: they neither
// assert a mode (no conflict) nor write identity, and provenance reports
// the descriptor, not the ignored alias key.
func TestFedlibShareLive_LegacyAliasStorageAndModeInert(t *testing.T) {
	testSetup(t)
	dir := t.TempDir()
	seedDescriptor(t, "fed", fedlibDescriptor{
		Bucket: "desc-bucket", UploadPrefix: "DP", Mode: "private", FedlibPath: dir,
	})
	// A legacy store carrying mode "public" plus identity keys. Since the
	// fields are json:"-", none of this reaches the command — and the
	// stored mode is NOT an assertion, so no conflict fires.
	seedLiveAlias(t, "fed", `{"mode":"public","bucket":"ALIAS_BUCKET","upload-prefix":"ALIAS_PREFIX","cache-size":"3Gi"}`)

	cli, _ := parseCLI(t, []string{"fedlib", "share", "live", "fed"})
	live := &cli.Fedlib.Share.Live
	if live.Mode != "private" {
		t.Errorf("Mode = %q, want descriptor's private", live.Mode)
	}
	if live.Bucket != "desc-bucket" || live.UploadPrefix != "DP" {
		t.Errorf("identity recalled from alias: bucket=%q prefix=%q", live.Bucket, live.UploadPrefix)
	}
	if live.CacheSize != "3Gi" {
		t.Errorf("tuning key not recalled: cache-size=%q, want 3Gi", live.CacheSize)
	}

	prov := live.showConfigContext().provenance
	self := reflect.ValueOf(live).Elem()
	entry, ok := prov.lookup(fieldAddr(self, "Mode"))
	if !ok {
		t.Fatal("Mode has no provenance entry")
	}
	if entry.Origin != OriginDescriptor {
		t.Errorf("Mode origin = %q, want %q (ignored legacy key must not claim alias origin)", entry.Origin, OriginDescriptor)
	}
}

// Raw alias credentials: migration moves them to the keys file (success),
// leaves the store untouched when it cannot write (failure), and never runs
// under -s (skip) — and in no case does the raw value reach the command
// through recall.
func TestFedlibShareLive_RawCredMigrationSuccessFailureSkip(t *testing.T) {
	t.Run("success", func(t *testing.T) {
		testSetup(t)
		dir := t.TempDir()
		seedDescriptor(t, "fed", fedlibDescriptor{FedlibPath: dir})
		seedLiveAlias(t, "fed", `{"s3-access-key":"LEGACY_AK","cache-size":"2Gi"}`)

		cli, _ := parseCLI(t, []string{"fedlib", "share", "live", "fed"})
		if readAlias(t, "fed").Get("fedlib.share.live.s3-access-key").Exists() {
			t.Error("raw credential still in alias store after migration")
		}
		kf, err := parseKeysFile(defaultKeysFilePath("fed"))
		if err != nil || kf.AccessKey != "LEGACY_AK" {
			t.Errorf("migrated keys file: %v / %q, want LEGACY_AK", err, kf.AccessKey)
		}
		// The value the serve sees came through the keys file, not recall.
		if cli.Fedlib.Share.Live.S3AccessKey != "LEGACY_AK" {
			t.Errorf("S3AccessKey = %q, want LEGACY_AK via migrated keys file", cli.Fedlib.Share.Live.S3AccessKey)
		}
	})

	t.Run("failure_leaves_raw_untouched_and_unrecalled", func(t *testing.T) {
		testSetup(t)
		dir := t.TempDir()
		seedDescriptor(t, "fed", fedlibDescriptor{FedlibPath: dir})
		seedLiveAlias(t, "fed", `{"s3-access-key":"LEGACY_AK"}`)
		keysDir := filepath.Join(accorderConfigDir, "keys")
		if err := os.MkdirAll(keysDir, 0o500); err != nil {
			t.Fatal(err)
		}
		t.Cleanup(func() { _ = os.Chmod(keysDir, 0o700) })

		cli, _ := parseCLI(t, []string{"fedlib", "share", "live", "fed"})
		if !readAlias(t, "fed").Get("fedlib.share.live.s3-access-key").Exists() {
			t.Error("raw credential removed although migration could not write")
		}
		if cli.Fedlib.Share.Live.S3AccessKey != "" {
			t.Errorf("S3AccessKey = %q, want empty — an unmigrated raw value must not be recalled", cli.Fedlib.Share.Live.S3AccessKey)
		}
	})

	t.Run("stat_failure_leaves_raw_untouched", func(t *testing.T) {
		// [REFINEMENT] ca-125 contract: when the migration destination
		// cannot even be stat'ed (here: the keys dir path is a file), the
		// raw alias credential is the only copy — it must survive.
		testSetup(t)
		dir := t.TempDir()
		seedDescriptor(t, "fed", fedlibDescriptor{FedlibPath: dir})
		seedLiveAlias(t, "fed", `{"s3-access-key":"LEGACY_AK"}`)
		if err := os.WriteFile(filepath.Join(accorderConfigDir, "keys"), []byte("not a dir"), 0o600); err != nil {
			t.Fatal(err)
		}

		parseCLI(t, []string{"fedlib", "share", "live", "fed"})
		if !readAlias(t, "fed").Get("fedlib.share.live.s3-access-key").Exists() {
			t.Error("raw credential deleted although the migration destination was unstatable")
		}
	})

	t.Run("skip_under_show_config", func(t *testing.T) {
		testSetup(t)
		dir := t.TempDir()
		seedDescriptor(t, "fed", fedlibDescriptor{FedlibPath: dir})
		seedLiveAlias(t, "fed", `{"s3-access-key":"LEGACY_AK"}`)
		beforeAlias, err := os.ReadFile(savedActionAliases)
		if err != nil {
			t.Fatal(err)
		}

		out := captureShowConfig(t, []string{"fedlib", "share", "live", "fed", "-s"})
		afterAlias, err := os.ReadFile(savedActionAliases)
		if err != nil {
			t.Fatal(err)
		}
		if string(beforeAlias) != string(afterAlias) {
			t.Error("-s modified the alias store")
		}
		if strings.Contains(out, "LEGACY_AK") {
			t.Error("-s printed a raw stored credential")
		}
	})
}

// config prune classifies the now-inert stale keys: mode as a deletable
// never-persisted dead key, raw credentials as excluded keys that --apply
// migrates before removal.
func TestFedlibShareLive_PruneClassifiesStaleModeAndCreds(t *testing.T) {
	testSetup(t)
	seedLiveAlias(t, "fed", `{"mode":"public","s3-access-key":"XX","cache-size":"2Gi"}`)

	_, ctx := parseCLI(t, []string{"config", "prune"})
	findings := scanAliasRot(kongRootNode(ctx), loadActionAliases(), "fed")

	var sawMode, sawCred bool
	for _, f := range findings {
		switch f.Path {
		case "fedlib.share.live.mode":
			sawMode = true
			if f.Kind != rotDeadKey {
				t.Errorf("stale mode kind = %d, want rotDeadKey (%d)", f.Kind, rotDeadKey)
			}
			if !strings.Contains(f.Reason, "never-persisted") {
				t.Errorf("stale mode reason = %q, want never-persisted explanation", f.Reason)
			}
		case "fedlib.share.live.s3-access-key":
			sawCred = true
			if f.Kind != rotExcludedKey {
				t.Errorf("stale credential kind = %d, want rotExcludedKey (%d) so --apply migrates first", f.Kind, rotExcludedKey)
			}
		case "fedlib.share.live.cache-size":
			t.Errorf("live tuning key wrongly flagged: kind %d", f.Kind)
		}
	}
	if !sawMode || !sawCred {
		t.Errorf("missing findings (mode=%v cred=%v): %+v", sawMode, sawCred, findings)
	}
}

// The seam test: fedlibs.json is rewritten between AfterApply and Run. Run
// must keep serving the invocation's snapshot — identity, mode and
// credentials — and never reread the descriptor.
func TestFedlibShareLive_RunUsesRetainedSnapshotAfterDescriptorRewrite(t *testing.T) {
	testSetup(t)
	dir := t.TempDir()
	seedDescriptor(t, "fed", fedlibDescriptor{Bucket: "orig-bucket", Mode: "private", FedlibPath: dir})
	// One rclone member so Run stops deterministically at RequireS3Creds,
	// after every identity/mode decision and before any listener.
	writeMembersJSON(t, dir, `{"22222222-2222-2222-2222-222222222222":{"librarian":"B","prefix":"b"}}`)

	cli, _ := parseCLI(t, []string{"fedlib", "share", "live", "fed"})
	live := &cli.Fedlib.Share.Live

	seedDescriptor(t, "fed", fedlibDescriptor{Bucket: "evil-bucket", Mode: "public", FedlibPath: dir})

	err := live.Run()
	if err == nil || !strings.Contains(err.Error(), "required when the registry contains rclone members") {
		t.Fatalf("want RequireS3Creds error, got %v", err)
	}
	if live.Bucket != "orig-bucket" {
		t.Errorf("Bucket = %q, want the retained snapshot's orig-bucket", live.Bucket)
	}
	if live.Mode != "private" {
		t.Errorf("Mode = %q, want the retained snapshot's private", live.Mode)
	}
	if live.descriptor == nil || live.descriptor.Bucket != "orig-bucket" {
		t.Errorf("retained descriptor = %+v, want the original snapshot", live.descriptor)
	}
}
