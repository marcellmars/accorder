package cmd

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"
	"regexp"
	"strings"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/credentials"
	"github.com/aws/aws-sdk-go-v2/service/iam"
	iamtypes "github.com/aws/aws-sdk-go-v2/service/iam/types"
	"github.com/goccy/go-json"
)

var safeScopedName = regexp.MustCompile(`^[A-Za-z0-9._-]+$`)

type iamMintResult struct {
	Username  string
	AccessKey string
	SecretKey string
}

func mintScopedCredentials(ctx context.Context, rootKey, rootSecret, iamEndpoint, prefix, bucket string) (*iamMintResult, error) {
	if !safeScopedName.MatchString(prefix) {
		return nil, fmt.Errorf("mint scoped credentials: unsafe prefix %q (allowed: letters, digits, '.', '_', '-')", prefix)
	}
	username := "fedlib-" + prefix

	client := iam.New(iam.Options{
		Region:       "us-east-1",
		Credentials:  credentials.NewStaticCredentialsProvider(rootKey, rootSecret, ""),
		BaseEndpoint: &iamEndpoint,
	})

	created := true
	_, err := client.CreateUser(ctx, &iam.CreateUserInput{
		UserName: &username,
	})
	if err != nil {
		if !isAlreadyExistsErr(err) {
			return nil, fmt.Errorf("CreateUser %s: %w", username, err)
		}
		created = false
		log.Printf("fedlib members invite: IAM user %s already exists; proceeding", username)
	}

	policyDoc := buildScopedPolicy(bucket, prefix)
	policyJSON, err := json.Marshal(policyDoc)
	if err != nil {
		if created {
			cleanupUser(ctx, client, username)
		}
		return nil, fmt.Errorf("marshal policy: %w", err)
	}
	policyName := "fedlib-scope-" + prefix
	policyStr := string(policyJSON)
	_, err = client.PutUserPolicy(ctx, &iam.PutUserPolicyInput{
		UserName:       &username,
		PolicyName:     &policyName,
		PolicyDocument: &policyStr,
	})
	if err != nil {
		if created {
			cleanupUser(ctx, client, username)
		}
		return nil, fmt.Errorf("PutUserPolicy %s: %w", username, err)
	}

	createKeyOut, err := client.CreateAccessKey(ctx, &iam.CreateAccessKeyInput{
		UserName: &username,
	})
	if err != nil {
		if isLimitExceededErr(err) {
			if rotateErr := rotateOldestKey(ctx, client, username); rotateErr != nil {
				if created {
					cleanupUser(ctx, client, username)
				}
				return nil, fmt.Errorf("rotate oldest key for %s: %w (original: %v)", username, rotateErr, err)
			}
			createKeyOut, err = client.CreateAccessKey(ctx, &iam.CreateAccessKeyInput{
				UserName: &username,
			})
			if err != nil {
				if created {
					cleanupUser(ctx, client, username)
				}
				return nil, fmt.Errorf("CreateAccessKey %s (after rotate): %w", username, err)
			}
		} else {
			if created {
				cleanupUser(ctx, client, username)
			}
			return nil, fmt.Errorf("CreateAccessKey %s: %w", username, err)
		}
	}

	return &iamMintResult{
		Username:  username,
		AccessKey: aws.ToString(createKeyOut.AccessKey.AccessKeyId),
		SecretKey: aws.ToString(createKeyOut.AccessKey.SecretAccessKey),
	}, nil
}

type iamPolicyDocument struct {
	Version   string               `json:"Version"`
	Statement []iamPolicyStatement `json:"Statement"`
}

type iamPolicyStatement struct {
	Sid       string                            `json:"Sid,omitempty"`
	Effect    string                            `json:"Effect"`
	Action    []string                          `json:"Action"`
	Resource  interface{}                       `json:"Resource"`
	Condition map[string]map[string]interface{} `json:"Condition,omitempty"`
}

func buildScopedPolicy(bucket, prefix string) iamPolicyDocument {
	bucketARN := "arn:aws:s3:::" + bucket
	bareARN := bucketARN + "/" + prefix
	prefixARN := bareARN + "/*"

	return iamPolicyDocument{
		Version: "2012-10-17",
		Statement: []iamPolicyStatement{
			{
				Sid:    "AllowObjectOps",
				Effect: "Allow",
				Action: []string{
					"s3:PutObject",
					"s3:GetObject",
					"s3:DeleteObject",
				},
				Resource: []string{bareARN, prefixARN},
			},
			{
				Sid:    "AllowListBucket",
				Effect: "Allow",
				Action: []string{
					"s3:ListBucket",
				},
				Resource: bucketARN,
				Condition: map[string]map[string]interface{}{
					"StringLike": {
						"s3:prefix": []string{prefix, prefix + "/*"},
					},
				},
			},
		},
	}
}

func printMintCommands(prefix, bucket, iamEndpoint string) {
	username := "fedlib-" + prefix
	policyName := "fedlib-scope-" + prefix
	policy := buildScopedPolicy(bucket, prefix)
	policyJSON, _ := json.MarshalIndent(policy, "", "  ")

	fmt.Fprintf(os.Stderr, "\n--- Scoped IAM commands for prefix %q ---\n\n", prefix)
	fmt.Fprintf(os.Stderr, "# 1. Create IAM sub-user\n")
	fmt.Fprintf(os.Stderr, "aws iam create-user --user-name %s --endpoint-url %s\n\n", username, iamEndpoint)
	fmt.Fprintf(os.Stderr, "# 2. Attach scoped policy\n")
	fmt.Fprintf(os.Stderr, "aws iam put-user-policy --user-name %s --policy-name %s --endpoint-url %s --policy-document '%s'\n\n",
		username, policyName, iamEndpoint, string(policyJSON))
	fmt.Fprintf(os.Stderr, "# 3. Create access key\n")
	fmt.Fprintf(os.Stderr, "aws iam create-access-key --user-name %s --endpoint-url %s\n\n", username, iamEndpoint)
	fmt.Fprintf(os.Stderr, "# Then run: accorder fedlib members invite ... --s3-access-key=<key> --s3-secret-key=<secret>\n")
	fmt.Fprintf(os.Stderr, "--- End ---\n\n")
}

func rotateOldestKey(ctx context.Context, client *iam.Client, username string) error {
	listOut, err := client.ListAccessKeys(ctx, &iam.ListAccessKeysInput{
		UserName: &username,
	})
	if err != nil {
		return fmt.Errorf("list access keys: %w", err)
	}
	if len(listOut.AccessKeyMetadata) == 0 {
		return fmt.Errorf("no access keys to rotate")
	}

	oldest := listOut.AccessKeyMetadata[0]
	for _, k := range listOut.AccessKeyMetadata[1:] {
		if oldest.CreateDate == nil ||
			(k.CreateDate != nil && k.CreateDate.Before(*oldest.CreateDate)) {
			oldest = k
		}
	}

	_, err = client.DeleteAccessKey(ctx, &iam.DeleteAccessKeyInput{
		UserName:    &username,
		AccessKeyId: oldest.AccessKeyId,
	})
	if err != nil {
		return fmt.Errorf("delete oldest key %s: %w", aws.ToString(oldest.AccessKeyId), err)
	}
	log.Printf("fedlib members invite: rotated oldest key %s for user %s", aws.ToString(oldest.AccessKeyId), username)
	return nil
}

func cleanupUser(ctx context.Context, client *iam.Client, username string) {
	listOut, err := client.ListAccessKeys(ctx, &iam.ListAccessKeysInput{UserName: &username})
	if err == nil {
		for _, k := range listOut.AccessKeyMetadata {
			_, _ = client.DeleteAccessKey(ctx, &iam.DeleteAccessKeyInput{
				UserName:    &username,
				AccessKeyId: k.AccessKeyId,
			})
		}
	}
	polOut, err := client.ListUserPolicies(ctx, &iam.ListUserPoliciesInput{UserName: &username})
	if err == nil {
		for _, pn := range polOut.PolicyNames {
			_, _ = client.DeleteUserPolicy(ctx, &iam.DeleteUserPolicyInput{
				UserName:   &username,
				PolicyName: &pn,
			})
		}
	}
	_, _ = client.DeleteUser(ctx, &iam.DeleteUserInput{UserName: &username})
}

func isAlreadyExistsErr(err error) bool {
	var entityExists *iamtypes.EntityAlreadyExistsException
	if ok := errors.As(err, &entityExists); ok {
		return true
	}
	return strings.Contains(err.Error(), "EntityAlreadyExists")
}

func isLimitExceededErr(err error) bool {
	var limitExceeded *iamtypes.LimitExceededException
	if ok := errors.As(err, &limitExceeded); ok {
		return true
	}
	return strings.Contains(err.Error(), "LimitExceeded")
}
