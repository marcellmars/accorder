//go:build !tailscale

package cmd

import (
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"accorder/pkg/calibre"
	"accorder/pkg/rclonexfer"
	"github.com/rclone/rclone/fs/config"
	"github.com/rclone/rclone/librclone/librclone"
)

// Actual command publications feed the unchanged consumer and real VFS RPCs.
// Local storage is intentional: this checks directory-cache behavior, not S3
// conditional-write compatibility. No production credentials or trees are used.
func TestFastBuildScratchServePublication(t *testing.T) {
	scenario := os.Getenv("ACCORDER_SCRATCH_SERVE_SCENARIO")
	if scenario == "" {
		t.Skip("opt-in whole-command HTTP acceptance; set ACCORDER_SCRATCH_SERVE_SCENARIO=edit, edit-after-grace, new-author, add-format, move, delete, or private")
	}
	switch scenario {
	case "edit", "edit-after-grace", "new-author", "add-format", "move", "delete", "private":
	default:
		t.Fatal("unknown scratch-serve scenario")
	}
	root := testSetup(t)
	seedPublishCalibreLibrary(t, root)
	writeTestFile(t, root, "Author/Book (1)/cover.jpg", "cover-old")
	fastBuildSQL(t, root, `INSERT INTO books(id,title,sort,uuid,path) VALUES(2,'Control','Control','control-uuid','Untouched/Control (2)');
INSERT INTO data(id,book,format,uncompressed_size,name) VALUES(2,2,'EPUB',7,'Control');
INSERT INTO books_authors_link(book,author) VALUES(2,1);
UPDATE books SET pubdate='2020-01-01T00:00:00+00:00',last_modified='2026-09-07T00:00:00+00:00' WHERE id=2;`)
	writeTestFile(t, root, "Untouched/Control (2)/Control.epub", "control")
	writeTestFile(t, root, "Untouched/Control (2)/cover.jpg", "control-cover")
	bucket := t.TempDir()
	remoteRoot := filepath.Join(bucket, "alice")
	if err := os.MkdirAll(remoteRoot, 0o755); err != nil {
		t.Fatal(err)
	}
	previousConfig := config.GetConfigPath()
	if err := config.SetConfigPath(filepath.Join(t.TempDir(), "rclone.conf")); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = config.SetConfigPath(previousConfig) })
	withLocalCommandRemote(t, remoteRoot)
	build := fastBuildCommand(root)
	build.FedlibPrefix, build.DictID = "alice", 2
	publish := func() remoteLibrarySnapshot {
		t.Helper()
		command := &LibPublishCmd{GroupLib: build.GroupLib, MaxDeletes: 25}
		command.ActionAlias = "alice"
		if err := command.Run(nil); err != nil {
			t.Fatal(err)
		}
		snapshot := (&libraryRemote{fsPath: remoteRoot}).commitState()
		if snapshot.Err != nil || !snapshot.Committed {
			t.Fatalf("commit: %+v", snapshot)
		}
		return snapshot
	}
	previous := publish()
	cached := t.TempDir()
	cacheEndpoint := func(snapshot remoteLibrarySnapshot, dest string) {
		t.Helper()
		if err := rclonexfer.CopyFile(remoteRoot, "static/library_index.zst", dest, "library_index.zst"); err != nil {
			t.Fatal(err)
		}
		writeCachedMemberCommit(t, dest, snapshot.GenerationRaw, snapshot.Pointer)
	}
	cacheEndpoint(previous, cached)
	type plane struct{ fs, base string }
	start := func(role string) plane {
		t.Helper()
		name := fmt.Sprintf("scratch-change-%s-%d", role, time.Now().UnixNano())
		data, _ := json.Marshal(map[string]any{"name": name, "type": "local", "parameters": map[string]string{}})
		out, status := librclone.RPC("config/create", string(data))
		if status != http.StatusOK {
			t.Fatalf("create remote: %d %s", status, out)
		}
		t.Cleanup(func() { _ = rclonexfer.DeleteRemote(name) })
		fs := name + ":" + filepath.ToSlash(bucket)
		id, address, err := rclonexfer.ServeHTTPWithVFS(fs, "127.0.0.1:0", rclonexfer.VFSOptions{
			CacheMode: "full", CacheMaxSize: "16Mi", CacheMaxAge: "1h", CachePollInterval: "1h", DirCacheTime: "1h", ReadOnly: true,
		})
		if err != nil {
			t.Fatal(err)
		}
		t.Cleanup(func() {
			if err := rclonexfer.StopServe(id); err != nil {
				t.Error(err)
			}
		})
		return plane{fs, "http://" + address}
	}
	books, assets := start("books"), start("assets")
	invalidator := newAggregateVFSInvalidator(aggregateVFSResources{BooksFS: books.fs, AssetsFS: assets.fs})
	get := func(p plane, path string, wantStatus int, wantBody string) {
		t.Helper()
		u := p.base + (&url.URL{Path: "/alice/" + path}).EscapedPath()
		response, err := (&http.Client{Timeout: 5 * time.Second}).Get(u)
		if err != nil {
			t.Fatal(err)
		}
		body, err := io.ReadAll(response.Body)
		_ = response.Body.Close()
		if err != nil || response.StatusCode != wantStatus || (wantBody != "" && string(body) != wantBody) {
			t.Fatalf("GET %s: status=%d body=%q err=%v, want %d %q", path, response.StatusCode, body, err, wantStatus, wantBody)
		}
	}
	get(books, fastBuildPayload, 200, "payload")
	get(assets, "Author/Book (1)/cover.jpg", 200, "cover-old")
	get(books, "Untouched/Control (2)/Control.epub", 200, "control")
	get(assets, "Untouched/Control (2)/cover.jpg", 200, "control-cover")
	// A hidden remote addition is a negative control: targeted invalidation
	// must leave the unrelated cached directory listing untouched.
	writeTestFile(t, remoteRoot, "Untouched/Control (2)/probe.epub", "probe")
	get(books, "Untouched/Control (2)/probe.epub", 404, "")
	if err := os.Remove(filepath.Join(remoteRoot, "Untouched/Control (2)/probe.epub")); err != nil {
		t.Fatal(err)
	}
	advance := func() {
		t.Helper()
		next := publish()
		stage := t.TempDir()
		cacheEndpoint(next, stage)
		token, err := decodeAggregateGenerationToken(next.GenerationRaw)
		if err != nil {
			t.Fatal(err)
		}
		transition := observedMemberTransition{LibraryUUID: fastBuildLibraryID, PreviousGeneration: hex.EncodeToString(previous.GenerationRaw), ObservedGeneration: hex.EncodeToString(next.GenerationRaw)}
		result := deriveMemberChangeResult(bucket, cached, stage, "alice", fastBuildLibraryID, transition, token, next.Pointer)
		wantScope := calibre.GenerationChangeScopeExact
		if scenario == "private" {
			wantScope = calibre.GenerationChangeScopeCoarse // Old leaked paths require member cleanup.
		}
		if result.Scope != wantScope {
			t.Fatalf("consumer: %+v", result)
		}
		for _, dir := range append(append([]string(nil), result.BooksDirectories...), result.AssetsDirectories...) {
			if dir == "alice" || strings.Contains(dir, "Untouched") {
				t.Fatalf("unrelated invalidation: %+v", result)
			}
		}
		writeTestFile(t, remoteRoot, "Untouched/Control (2)/probe.epub", "probe")
		scope := exactAggregateInvalidation(result.BooksDirectories, result.AssetsDirectories)
		if scenario == "private" {
			scope = memberAggregateInvalidation("alice")
		}
		invalidator.invalidate(scope)
		if len(invalidator.pending) != 0 {
			t.Fatalf("failed invalidation: %+v", invalidator.pending)
		}
		if scenario == "private" {
			get(books, "Untouched/Control (2)/probe.epub", 200, "probe")
		} else {
			get(books, "Untouched/Control (2)/probe.epub", 404, "")
		}
		if err := os.Remove(filepath.Join(remoteRoot, "Untouched/Control (2)/probe.epub")); err != nil {
			t.Fatal(err)
		}
		get(books, "Untouched/Control (2)/Control.epub", 200, "control")
		get(assets, "Untouched/Control (2)/cover.jpg", 200, "control-cover")
		previous, cached = next, stage
		t.Logf("generation %d: books=%v assets=%v", next.Generation, result.BooksDirectories, result.AssetsDirectories)
	}
	if scenario == "edit" || scenario == "edit-after-grace" {
		if scenario == "edit-after-grace" {
			// Diagnostic control, not an acceptance workaround: immediate reads
			// must work too. rclone's default read-handle grace period is 5s.
			time.Sleep(6 * time.Second)
		}
		for rel, replacement := range map[string]string{fastBuildPayload: "changed", "Author/Book (1)/cover.jpg": "cover-new"} {
			path := filepath.Join(root, filepath.FromSlash(rel))
			info, err := os.Stat(path)
			if err != nil {
				t.Fatal(err)
			}
			writeTestFile(t, root, rel, replacement)
			if err := os.Chtimes(path, info.ModTime(), info.ModTime()); err != nil {
				t.Fatal(err)
			}
		}
		fastBuildCalibreEdit(t, root, 1)
		advance()
		get(books, fastBuildPayload, 200, "changed")
		get(assets, "Author/Book (1)/cover.jpg", 200, "cover-new")
	} else if scenario == "new-author" {
		get(books, "NewAuthor/New (3)/New.epub", 404, "")
		get(assets, "NewAuthor/New (3)/cover.jpg", 404, "")
		fastBuildSQL(t, root, `INSERT INTO books(id,title,sort,uuid,path) VALUES(3,'New','New','new-uuid','NewAuthor/New (3)');
INSERT INTO data(id,book,format,uncompressed_size,name) VALUES(3,3,'EPUB',3,'New');
INSERT INTO books_authors_link(book,author) VALUES(3,1);
UPDATE books SET pubdate='2020-01-01T00:00:00+00:00',last_modified='2026-09-07T00:00:00+00:00' WHERE id=3;`)
		writeTestFile(t, root, "NewAuthor/New (3)/New.epub", "new")
		writeTestFile(t, root, "NewAuthor/New (3)/cover.jpg", "new-cover")
		advance()
		get(books, "NewAuthor/New (3)/New.epub", 200, "new")
		get(assets, "NewAuthor/New (3)/cover.jpg", 200, "new-cover")
	} else if scenario == "add-format" {
		get(books, "Author/Book (1)/Book - Author.pdf", 404, "")
		fastBuildSQL(t, root, `INSERT INTO data(id,book,format,uncompressed_size,name) VALUES(3,1,'PDF',3,'Book - Author')`)
		writeTestFile(t, root, "Author/Book (1)/Book - Author.pdf", "pdf")
		advance()
		get(books, "Author/Book (1)/Book - Author.pdf", 200, "pdf")
		get(books, fastBuildPayload, 200, "payload")
		get(assets, "Author/Book (1)/cover.jpg", 200, "cover-old")
	} else if scenario == "delete" || scenario == "private" {
		if scenario == "private" {
			fastBuildSQL(t, root, `INSERT INTO tags(id,name) VALUES(1,'private'); INSERT INTO books_tags_link(book,tag) VALUES(1,1)`)
			fastBuildCalibreEdit(t, root, 1)
		} else {
			fastBuildSQL(t, root, `DELETE FROM data WHERE book=1; DELETE FROM books WHERE id=1`)
			// Model Calibre's trash move, not deletion of any operator files.
			trash := filepath.Join(root, ".caltrash", "b")
			if err := os.MkdirAll(trash, 0700); err != nil {
				t.Fatal(err)
			}
			if err := os.Rename(filepath.Join(root, "Author/Book (1)"), filepath.Join(trash, "1")); err != nil {
				t.Fatal(err)
			}
		}
		advance()
		get(books, fastBuildPayload, 404, "")
		get(assets, "Author/Book (1)/cover.jpg", 404, "")
	} else if scenario == "move" {
		fastBuildSQL(t, root, `UPDATE books SET path='Moved/Book (1)' WHERE id=1`)
		if err := os.MkdirAll(filepath.Join(root, "Moved"), 0o755); err != nil {
			t.Fatal(err)
		}
		if err := os.Rename(filepath.Join(root, "Author/Book (1)"), filepath.Join(root, "Moved/Book (1)")); err != nil {
			t.Fatal(err)
		}
		advance()
		get(books, fastBuildPayload, 404, "")
		get(assets, "Author/Book (1)/cover.jpg", 404, "")
		get(books, "Moved/Book (1)/Book - Author.epub", 200, "payload")
		get(assets, "Moved/Book (1)/cover.jpg", 200, "cover-old")
	}
}
