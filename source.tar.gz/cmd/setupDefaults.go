package cmd

import (
	"accorder/pkg/librarianname"
	"log"
	"reflect"

	"github.com/alecthomas/kong"
	uuid "github.com/satori/go.uuid"
	"github.com/tidwall/sjson"
)

func hasGenTag(t reflect.Type, fieldName, genKind string) bool {
	if t.Kind() == reflect.Ptr {
		t = t.Elem()
	}
	if t.Kind() != reflect.Struct {
		return false
	}
	for i := 0; i < t.NumField(); i++ {
		field := t.Field(i)
		if field.Name == fieldName {
			return field.Tag.Get("gen") == genKind
		}
		if field.Anonymous && field.Type.Kind() == reflect.Struct {
			if hasGenTag(field.Type, fieldName, genKind) {
				return true
			}
		}
	}
	return false
}

func mintSetupDefaults(action, cliRoot *kong.Node, alias, aliasPath string, configBytes *[]byte) {
	target := action.Target
	if !target.IsValid() {
		return
	}
	if target.Kind() == reflect.Ptr {
		target = target.Elem()
	}
	if target.Kind() != reflect.Struct {
		return
	}

	// A subcommand this alias has never run has no calibrepath of its own, but
	// the alias plainly knows where the library is — every sibling carries it.
	// Without this, `lib status` reports "local library missing" for a library
	// sitting exactly where `lib publish` has been reading it all along. Same
	// confusion as the mint below, milder consequence: it misreports rather
	// than overwrites.
	if typeHasAliasField(target.Type(), "calibrepath") && fieldStringValue(target, "CalibreDirectory") == "" {
		if path := adoptSharedField(cliRoot, action, alias, "calibrepath", "lib", *configBytes); path != "" {
			setFieldString(target, "CalibreDirectory", path)
			*configBytes, _ = sjson.SetBytes(*configBytes, aliasPath+".calibrepath", path)
		}
	}

	// The federation fields travel with the alias too, and losing them is
	// silent: libBuild refuses a reserved DictID only when FedlibPrefix is set
	// (libBuild.go), so a subcommand that inherited neither builds a member
	// index with DictID 0, no aggregate fields, and no /files/<prefix> in any
	// book URL — and says nothing.
	if typeHasAliasField(target.Type(), "fedlibPrefix") && fieldStringValue(target, "FedlibPrefix") == "" {
		if prefix := adoptSharedField(cliRoot, action, alias, "fedlibPrefix", "lib", *configBytes); prefix != "" {
			setFieldString(target, "FedlibPrefix", prefix)
			*configBytes, _ = sjson.SetBytes(*configBytes, aliasPath+".fedlibPrefix", prefix)
		}
	}
	if typeHasAliasField(target.Type(), "dictID") && fieldUintValue(target, "DictID") == 0 {
		if dictID := adoptSharedUint(cliRoot, action, alias, "dictID", "lib", *configBytes); dictID != 0 {
			setFieldUint(target, "DictID", dictID)
			*configBytes, _ = sjson.SetBytes(*configBytes, aliasPath+".dictID", dictID)
		}
	}

	// Adopt before minting. An empty field on THIS subcommand means only that
	// this subcommand has never run; the alias may already have an identity
	// saved under a sibling. Minting on the strength of an empty field and
	// then propagating the new value overwrites that identity everywhere —
	// one `lib status` on an alias that had never run it replaced a published
	// library's UUID and librarian across seven subcommands, and the next
	// publish would have been refused by its own remote.
	if hasGenTag(target.Type(), "LibraryID", "uuid") && fieldStringValue(target, "LibraryID") == "" {
		id := adoptSharedField(cliRoot, action, alias, "libraryID", "lib", *configBytes)
		minted := id == ""
		if minted {
			id = uuid.NewV4().String()
		}
		setFieldString(target, "LibraryID", id)
		*configBytes, _ = sjson.SetBytes(*configBytes, aliasPath+".libraryID", id)
		propagateSharedField(cliRoot, action, alias, "libraryID", id, "lib", configBytes)
		if minted {
			log.Printf("[CFG] minted libraryID %s for alias %q (saved)", id, alias)
		} else {
			log.Printf("[CFG] libraryID %s adopted from alias %q", id, alias)
		}
	}

	if hasGenTag(target.Type(), "Librarian", "librarian") && fieldStringValue(target, "Librarian") == "" {
		name := adoptSharedField(cliRoot, action, alias, "librarian", "lib", *configBytes)
		generated := name == ""
		if generated {
			name = librarianname.Generate(fieldStringValue(target, "LibraryID"), 0)
		}
		setFieldString(target, "Librarian", name)
		*configBytes, _ = sjson.SetBytes(*configBytes, aliasPath+".librarian", name)
		propagateSharedField(cliRoot, action, alias, "librarian", name, "lib", configBytes)
		if generated {
			log.Printf("[CFG] librarian %q (generated; set --librarian to choose)", name)
		} else {
			log.Printf("[CFG] librarian %q adopted from alias %q", name, alias)
		}
	}
}
