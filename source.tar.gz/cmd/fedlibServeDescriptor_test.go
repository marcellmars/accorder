package cmd

import (
	"strings"
	"testing"
)

// The serve requires its positional to name a descriptor (one name).
// This test exercises the descriptor-missing error path.
func TestServeRequiresFedlibID_MissingDescriptor(t *testing.T) {
	testSetup(t)
	cmd := &FedlibShareLiveCmd{}
	cmd.ActionAlias = "nonexistent"
	cmd.AggregatePath = t.TempDir()
	err := cmd.Run()
	if err == nil {
		t.Fatal("expected error for missing descriptor")
	}
	if !strings.Contains(err.Error(), "names no federation descriptor") {
		t.Errorf("unexpected error: %v", err)
	}
}

// Descriptor slots storage-identity fields into the serve command struct.
func TestServeDescriptorLoad(t *testing.T) {
	testSetup(t)
	if err := saveFedlibDescriptor("srv", fedlibDescriptor{
		Version:      fedlibDescriptorVersion,
		Bucket:       "mybucket",
		UploadPrefix: "aggregate",
		S3Provider:   "Wasabi",
		S3Endpoint:   "s3.wasabisys.com",
		KeysFile:     "keys/lib.s3.keys",
		Mode:         "offline-private",
	}); err != nil {
		t.Fatal(err)
	}
	cmd := &FedlibShareLiveCmd{}
	cmd.ActionAlias = "srv"
	cmd.AggregatePath = t.TempDir()

	// Run() will fail at RequireS3Creds (no real creds), but we can
	// check that the descriptor fields were slotted before that point.
	err := cmd.Run()
	if err == nil {
		t.Fatal("expected cred-validation error (no real S3 creds)")
	}
	// The error should come from RequireS3Creds, not from descriptor load.
	if strings.Contains(err.Error(), "names no federation descriptor") {
		t.Fatalf("descriptor load failed unexpectedly: %v", err)
	}

	// Verify fields were slotted from descriptor.
	for _, tc := range []struct{ name, got, want string }{
		{"Bucket", cmd.Bucket, "mybucket"},
		{"UploadPrefix", cmd.UploadPrefix, "aggregate"},
		{"S3Provider", cmd.S3Provider, "Wasabi"},
		{"S3Endpoint", cmd.S3Endpoint, "s3.wasabisys.com"},
		{"KeysFile", cmd.KeysFile, "keys/lib.s3.keys"},
		{"Mode", cmd.Mode, "offline-private"},
	} {
		if tc.got != tc.want {
			t.Errorf("%s = %q, want %q", tc.name, tc.got, tc.want)
		}
	}
}

// Mode from descriptor is authoritative; empty descriptor mode falls back to "public".
func TestServeModeFromDescriptor(t *testing.T) {
	testSetup(t)
	// Case 1: descriptor with explicit mode.
	if err := saveFedlibDescriptor("mode-explicit", fedlibDescriptor{
		Version: fedlibDescriptorVersion,
		Bucket:  "b",
		Mode:    "private",
	}); err != nil {
		t.Fatal(err)
	}
	cmd := &FedlibShareLiveCmd{}
	cmd.ActionAlias = "mode-explicit"
	cmd.AggregatePath = t.TempDir()
	_ = cmd.Run() // will fail at cred validation
	if cmd.Mode != "private" {
		t.Errorf("mode = %q, want private", cmd.Mode)
	}

	// Case 2: descriptor with empty mode → code fallback "public".
	if err := saveFedlibDescriptor("mode-empty", fedlibDescriptor{
		Version: fedlibDescriptorVersion,
		Bucket:  "b",
	}); err != nil {
		t.Fatal(err)
	}
	cmd2 := &FedlibShareLiveCmd{}
	cmd2.ActionAlias = "mode-empty"
	cmd2.AggregatePath = t.TempDir()
	_ = cmd2.Run()
	if cmd2.Mode != "public" {
		t.Errorf("mode = %q, want public (fallback)", cmd2.Mode)
	}
}
