package cmd

import (
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	"accorder/pkg/calibre"
)

func motwType() reflect.Type { return reflect.TypeOf(calibre.MotwLibrary{}) }
func metaType() reflect.Type { return reflect.TypeOf(calibre.LibraryMeta{}) }

// TestCompanionKindsNeverDeletable is the regression guard for the design's
// load-bearing guarantee: companion findings are non-deletable by omission from
// deletable(), which is the single gate applyRotDeletions consults. If someone
// adds these kinds to that switch, deletion silently becomes possible.
func TestCompanionKindsNeverDeletable(t *testing.T) {
	for _, k := range []rotKind{rotForeignKey, rotCorruptEntry} {
		if k.deletable() {
			t.Fatalf("rotKind %d must never be deletable — applyRotDeletions would delete companion registry data", k)
		}
	}
}

// TestApplyRotDeletionsSkipsCompanionFindings proves the guarantee end-to-end
// rather than by inspecting deletable() alone.
func TestApplyRotDeletionsSkipsCompanionFindings(t *testing.T) {
	cfg := []byte(`{"alias":{"lib":{"build":{"gone":"x"}}}}`)
	findings := []rotFinding{
		{File: motwLibrariesFile, Alias: "uuid-1", Path: "secret", Kind: rotForeignKey},
		{File: motwLibrariesFile, Alias: "uuid-2", Kind: rotCorruptEntry},
	}
	out, deleted, _ := applyRotDeletions(cfg, findings, []string{"alias"})
	if len(deleted) != 0 {
		t.Fatalf("companion findings caused deletions: %v", deleted)
	}
	if string(out) != string(cfg) {
		t.Fatalf("config mutated by companion findings:\n got %s\nwant %s", out, cfg)
	}
}

func TestLiveJSONTags(t *testing.T) {
	motw := liveJSONTags(motwType())
	for _, want := range []string{"state", "url", "librarian"} {
		if !motw[want] {
			t.Errorf("MotwLibrary: missing live tag %q (got %v)", want, motw)
		}
	}
	if len(motw) != 3 {
		t.Errorf("MotwLibrary: expected 3 tags, got %d (%v)", len(motw), motw)
	}

	meta := liveJSONTags(metaType())

	// omitempty must be stripped from the tag name.
	for _, want := range []string{"librarian", "prefix", "state", "kind", "local_path", "dict_id", "endpoint", "grant_token"} {
		if !meta[want] {
			t.Errorf("LibraryMeta: missing live tag %q (got %v)", want, meta)
		}
	}
}

// TestCompanionStructsFullyTagged pins the assumption the oracle rests on: an
// untagged field would be invisible to liveJSONTags and its on-disk key would
// be reported as foreign — a false positive.
func TestCompanionStructsFullyTagged(t *testing.T) {
	for _, tt := range []reflect.Type{motwType(), metaType()} {
		for i := 0; i < tt.NumField(); i++ {
			f := tt.Field(i)
			if f.Tag.Get("json") == "" {
				t.Errorf("%s.%s has no json tag — the companion oracle would report its key as foreign", tt.Name(), f.Name)
			}
		}
	}
}

func TestLoadCompanionRegistry(t *testing.T) {
	dir := t.TempDir()

	t.Run("missing file is not an error", func(t *testing.T) {
		data, err := loadCompanionRegistry(filepath.Join(dir, "absent.json"))
		if err != nil || data != nil {
			t.Fatalf("got (%v, %v), want (nil, nil)", data, err)
		}
	})

	t.Run("invalid JSON syntax", func(t *testing.T) {
		p := filepath.Join(dir, "bad.json")
		os.WriteFile(p, []byte(`{"a":`), 0o600)
		_, err := loadCompanionRegistry(p)
		if err == nil || !strings.Contains(err.Error(), "invalid JSON syntax") {
			t.Fatalf("err=%v, want invalid JSON syntax", err)
		}
	})

	t.Run("top-level array rejected", func(t *testing.T) {
		p := filepath.Join(dir, "arr.json")
		os.WriteFile(p, []byte(`[1,2]`), 0o600)
		_, err := loadCompanionRegistry(p)
		if err == nil || !strings.Contains(err.Error(), "not a JSON object") {
			t.Fatalf("err=%v, want not-a-JSON-object", err)
		}
	})

	t.Run("valid object", func(t *testing.T) {
		p := filepath.Join(dir, "ok.json")
		os.WriteFile(p, []byte(`{"u":{"state":"ready"}}`), 0o600)
		data, err := loadCompanionRegistry(p)
		if err != nil || len(data) == 0 {
			t.Fatalf("got (%q, %v), want data and nil error", data, err)
		}
	})
}

func TestScanCompanionRot(t *testing.T) {
	t.Run("all-live keys produce no findings", func(t *testing.T) {
		data := []byte(`{"u1":{"state":"ready","url":"//x/","librarian":"K"}}`)
		if f := scanCompanionRot(motwLibrariesFile, data, motwType()); len(f) != 0 {
			t.Fatalf("expected no findings, got %+v", f)
		}
	})

	t.Run("secret is foreign, secret-labelled and redacted", func(t *testing.T) {
		data := []byte(`{"u1":{"secret":"44095b24a16e40cbbbd6312b65a21f1f","state":"on"}}`)
		f := scanCompanionRot(motwLibrariesFile, data, motwType())
		if len(f) != 1 {
			t.Fatalf("expected 1 finding, got %d: %+v", len(f), f)
		}
		if f[0].Kind != rotForeignKey || f[0].Path != "secret" || f[0].File != motwLibrariesFile {
			t.Fatalf("unexpected finding: %+v", f[0])
		}
		if f[0].Alias != "u1" {
			t.Errorf("finding must carry its registry entry key, got %q", f[0].Alias)
		}
		if !strings.Contains(f[0].Reason, "secret-bearing") {
			t.Errorf("reason should mark it secret-bearing, got %q", f[0].Reason)
		}
		if strings.Contains(f[0].Value, "44095b24") {
			t.Fatalf("SECRET LEAKED into finding value: %q", f[0].Value)
		}
		if f[0].Value != "<redacted secret, 32 bytes>" {
			t.Errorf("value=%q, want redacted-secret label", f[0].Value)
		}
	})

	t.Run("unknown non-secret keys are redacted too", func(t *testing.T) {
		data := []byte(`{"u1":{"api_key":"super-secret-value"}}`)
		f := scanCompanionRot(motwLibrariesFile, data, motwType())
		if len(f) != 1 {
			t.Fatalf("expected 1 finding, got %+v", f)
		}
		if strings.Contains(f[0].Value, "super-secret-value") {
			t.Fatalf("unknown foreign value leaked: %q — foreign fields may hold credentials", f[0].Value)
		}
	})

	t.Run("non-object entry yields rotCorruptEntry", func(t *testing.T) {
		data := []byte(`{"u1":"i-should-be-an-object"}`)
		f := scanCompanionRot(motwLibrariesFile, data, motwType())
		if len(f) != 1 || f[0].Kind != rotCorruptEntry {
			t.Fatalf("expected one rotCorruptEntry, got %+v", f)
		}
		if f[0].Alias != "u1" {
			t.Errorf("corrupt finding must name its entry, got %q", f[0].Alias)
		}
	})

	t.Run("aggregate registry with only live keys is clean", func(t *testing.T) {
		data := []byte(`{"u1":{"librarian":"K","prefix":"p","state":"ready","dict_id":55}}`)
		if f := scanCompanionRot(aggregateLibrariesFile, data, metaType()); len(f) != 0 {
			t.Fatalf("expected no findings, got %+v", f)
		}
	})

	t.Run("empty data is a no-op", func(t *testing.T) {
		if f := scanCompanionRot(motwLibrariesFile, nil, motwType()); f != nil {
			t.Fatalf("expected nil, got %+v", f)
		}
	})
}

// TestFormatRotFindingRedactsSecrets asserts the rendered line never carries
// raw credential material even if a caller builds a finding by hand.
func TestFormatRotFindingRedactsSecrets(t *testing.T) {
	data := []byte(`{"u1":{"secret":"deadbeefdeadbeefdeadbeefdeadbeef"}}`)
	f := scanCompanionRot(motwLibrariesFile, data, motwType())[0]
	line := formatRotFinding(f)
	if strings.Contains(line, "deadbeef") {
		t.Fatalf("formatted line leaked the secret: %q", line)
	}
	if !strings.Contains(line, "foreign") {
		t.Errorf("formatted line should mark the finding foreign, got %q", line)
	}
}

// TestRotSummaryCountsCompanionKinds guards the gap the proposal's
// invariant-falsification pass found: an unhandled kind is silently absent
// from the summary line.
func TestRotSummaryCountsCompanionKinds(t *testing.T) {
	line := rotSummaryLine([]rotFinding{
		{File: motwLibrariesFile, Kind: rotForeignKey},
		{File: motwLibrariesFile, Kind: rotForeignKey},
		{File: motwLibrariesFile, Kind: rotCorruptEntry},
	})
	if !strings.Contains(line, "2 foreign keys") {
		t.Errorf("summary missing foreign-key count: %q", line)
	}
	if !strings.Contains(line, "1 corrupt entry") {
		t.Errorf("summary missing corrupt-entry count: %q", line)
	}
}

func TestScanAllCompanionRot(t *testing.T) {
	dir := t.TempDir()
	os.WriteFile(filepath.Join(dir, motwLibrariesFile),
		[]byte(`{"u1":{"state":"on","secret":"abc"}}`), 0o600)
	os.WriteFile(filepath.Join(dir, aggregateLibrariesFile),
		[]byte(`{"u2":{"librarian":"K","prefix":"p"}}`), 0o600)

	findings, err := scanAllCompanionRot(dir)
	if err != nil {
		t.Fatal(err)
	}
	if len(findings) != 1 || findings[0].File != motwLibrariesFile {
		t.Fatalf("expected one motw finding, got %+v", findings)
	}

	t.Run("file-level corruption aborts", func(t *testing.T) {
		bad := t.TempDir()
		os.WriteFile(filepath.Join(bad, motwLibrariesFile), []byte(`{`), 0o600)
		if _, err := scanAllCompanionRot(bad); err == nil {
			t.Fatal("expected an error so --apply cannot proceed on a corrupt registry")
		}
	})

	t.Run("empty dir is clean", func(t *testing.T) {
		f, err := scanAllCompanionRot(t.TempDir())
		if err != nil || len(f) != 0 {
			t.Fatalf("got (%+v, %v), want (empty, nil)", f, err)
		}
	})
}

// TestAliasOnlyRenderUnchanged is the golden test the propose review
// prescribed: with a PURE-ALIAS findings slice (no companion findings), both
// the rendered lines and the summary must be byte-identical to the
// pre-companion behaviour — one level of grouping, no file heading, and no
// companion counts. A mixed slice would be the wrong fixture, because the
// summary legitimately gains companion counts when companion rot exists.
func TestAliasOnlyRenderUnchanged(t *testing.T) {
	aliasOnly := []rotFinding{
		{Alias: "zeta", Path: "lib.build.gone", Kind: rotDeadKey, Value: "x", Reason: "no such flag on lib build"},
		{Alias: "alpha", Path: "lib.upload.old", Kind: rotDefaultShadow, Value: "y", Reason: "shadows default"},
	}

	out := captureStdout(t, func() { renderRotFindings(aliasOnly) })
	want := "  alpha:\n" +
		"    ~ shadow  lib.upload.old = \"y\"  (shadows default)\n" +
		"  zeta:\n" +
		"    ✗ dead    lib.build.gone = \"x\"  (no such flag on lib build)\n"
	if out != want {
		t.Fatalf("alias-only render drifted:\n got %q\nwant %q", out, want)
	}

	if got := rotSummaryLine(aliasOnly); got != "1 dead key, 1 default shadow." {
		t.Fatalf("alias-only summary drifted: %q", got)
	}
}
