package cmd

import (
	"fmt"
	"log"
	"os"
	"reflect"
	"strings"

	"github.com/alecthomas/kong"
	"github.com/tidwall/gjson"
)

type Origin string

const (
	OriginFlag       Origin = "flag"
	OriginEnv        Origin = "env"
	OriginAlias      Origin = "alias"
	OriginAliasProp  Origin = "alias (propagated)"
	OriginKeysFile   Origin = "keys-file"
	OriginSecrets    Origin = "secrets-store"
	OriginDescriptor Origin = "descriptor"
	OriginDerived    Origin = "derived"
	OriginMinted     Origin = "minted"
	OriginDefault    Origin = "default"
)

type FieldIssue struct {
	FieldPtr uintptr
	Message  string
	Blocking bool
}

type provEntry struct {
	Origin Origin
	Detail string
}

type ProvenanceTable struct {
	entries map[uintptr]provEntry
}

func newProvenanceTable() *ProvenanceTable {
	return &ProvenanceTable{entries: make(map[uintptr]provEntry)}
}

func (p *ProvenanceTable) Stamp(addr uintptr, origin Origin, detail string) {
	if p == nil || addr == 0 {
		return
	}
	p.entries[addr] = provEntry{Origin: origin, Detail: detail}
}

func (p *ProvenanceTable) StampField(target reflect.Value, name string, origin Origin, detail string) {
	if p == nil {
		return
	}
	p.Stamp(fieldAddr(target, name), origin, detail)
}

func (p *ProvenanceTable) lookup(addr uintptr) (provEntry, bool) {
	if p == nil {
		return provEntry{}, false
	}
	e, ok := p.entries[addr]
	return e, ok
}

func fieldAddr(v reflect.Value, name string) uintptr {
	if v.Kind() == reflect.Ptr {
		if v.IsNil() {
			return 0
		}
		v = v.Elem()
	}
	if v.Kind() != reflect.Struct {
		return 0
	}
	f := v.FieldByName(name)
	if !f.IsValid() || !f.CanAddr() {
		return 0
	}
	return f.Addr().Pointer()
}

type showConfigContext struct {
	provenance   *ProvenanceTable
	selectedNode *kong.Node
	rootNode     *kong.Node
	issues       []FieldIssue
	readOnly     bool
}

func (c *showConfigContext) addIssues(issues ...FieldIssue) {
	if c == nil {
		return
	}
	c.issues = append(c.issues, issues...)
}

type EffectiveResolver interface {
	ResolveEffective() []FieldIssue
}

func recordFlagOrigins(p *ProvenanceTable, ctx *kong.Context, aliasData gjson.Result, actionPath, alias string) {
	if p == nil || ctx == nil {
		return
	}
	provided := getProvidedFlagNames(ctx)
	sel := ctx.Selected()
	if sel == nil {
		return
	}
	for _, f := range sel.Flags {
		if f.Value == nil || !f.Value.Target.IsValid() || !f.Value.Target.CanAddr() {
			continue
		}
		addr := f.Value.Target.Addr().Pointer()
		name := f.Name

		if _, ok := provided[name]; ok {
			p.Stamp(addr, OriginFlag, "--"+name)
			continue
		}

		if _, seen := p.lookup(addr); seen {
			continue
		}

		if aliasData.Exists() && aliasRecallableFlag(sel.Target.Type(), name) {
			if r := aliasData.Get(actionPath + "." + name); r.Exists() {
				p.Stamp(addr, OriginAlias, alias+"."+actionPath+"."+name)
				continue
			}
			if path, ok := findPropagated(aliasData, name, actionPath); ok {
				p.Stamp(addr, OriginAliasProp, alias+"."+path)
				continue
			}
		}

		if env, ok := envSource(f); ok {
			p.Stamp(addr, OriginEnv, env)
			continue
		}

		p.Stamp(addr, OriginDefault, "")
	}
}

func aliasRecallableFlag(t reflect.Type, flagName string) bool {
	tags, ok := getFieldTags(t, flagName)
	return ok && tags.JSONName == flagName
}

func envSource(f *kong.Flag) (string, bool) {
	for _, e := range f.Envs {
		if _, ok := os.LookupEnv(e); ok {
			return e, true
		}
	}
	return "", false
}

func findPropagated(aliasData gjson.Result, key, selfPath string) (string, bool) {
	var found string
	var walk func(node gjson.Result, path string)
	walk = func(node gjson.Result, path string) {
		if found != "" || !node.IsObject() {
			return
		}
		node.ForEach(func(k, v gjson.Result) bool {
			if found != "" {
				return false
			}
			child := k.String()
			next := child
			if path != "" {
				next = path + "." + child
			}
			if child == key && !v.IsObject() {
				if next != selfPath+"."+key {
					found = next
				}
				return found == ""
			}
			if v.IsObject() {
				walk(v, next)
			}
			return true
		})
	}
	walk(aliasData, "")
	if found == "" {
		return "", false
	}
	return strings.TrimSuffix(found, ""), true
}

type resolveCtx struct {
	prov     *ProvenanceTable
	readOnly bool

	credentialOnly bool
}

func resolveCtxOf(rcs []*resolveCtx) *resolveCtx {
	if len(rcs) > 0 && rcs[0] != nil {
		return rcs[0]
	}
	return &resolveCtx{}
}

func (c *CommonCommandFields) provenanceTable() *ProvenanceTable {
	if c.showConfigCtx == nil {
		c.showConfigCtx = &showConfigContext{provenance: newProvenanceTable()}
	}
	if c.showConfigCtx.provenance == nil {
		c.showConfigCtx.provenance = newProvenanceTable()
	}
	return c.showConfigCtx.provenance
}

func blockingIssueError(cmdName string, issues []FieldIssue) error {
	var blocking []string
	for _, is := range issues {
		if is.Blocking {
			blocking = append(blocking, is.Message)
			continue
		}
		log.Printf("%s: %s", cmdName, is.Message)
	}
	if len(blocking) == 0 {
		return nil
	}
	return fmt.Errorf("%s: %s", cmdName, strings.Join(blocking, "; "))
}
