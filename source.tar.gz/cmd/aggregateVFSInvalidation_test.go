package cmd

import (
	"errors"
	"reflect"
	"testing"
	"time"

	"accorder/pkg/torshare"
)

func testAggregateGenerationToken(t *testing.T, generation uint64) aggregateGenerationToken {
	t.Helper()
	var base [16]byte
	base[0] = byte(generation)
	token, err := decodeAggregateGenerationToken(torshare.EncodeGeneration(base, generation))
	if err != nil {
		t.Fatalf("decode token: %v", err)
	}
	return token
}

func TestAggregateInvalidationScopeMerge(t *testing.T) {
	a := memberAggregateInvalidation("z/member", "/a/member/", "z/member")
	if a.full || !reflect.DeepEqual(a.prefixes, []string{"a/member", "z/member"}) {
		t.Fatalf("canonical member scope = %+v", a)
	}
	b := memberAggregateInvalidation("b/member")
	if got := a.merge(b); got.full || !reflect.DeepEqual(got.prefixes, []string{"a/member", "b/member", "z/member"}) {
		t.Fatalf("merged member scope = %+v", got)
	}
	if got := a.merge(fullAggregateInvalidation()); !got.full || len(got.prefixes) != 0 {
		t.Fatalf("full must dominate merge: %+v", got)
	}
}

type forgetCall struct {
	fs   string
	dirs []string
}

// stubForget records every forget the invalidator issues and fails those
// for which fail returns true.
func stubForget(invalidator *aggregateVFSInvalidator, fail func(fs string) bool) *[]forgetCall {
	calls := &[]forgetCall{}
	invalidator.forget = func(fs string, dirs ...string) error {
		*calls = append(*calls, forgetCall{fs: fs, dirs: append([]string(nil), dirs...)})
		if fail(fs) {
			return errors.New("injected failure for " + fs)
		}
		return nil
	}
	return calls
}

func TestPublicationScopeClassifiesTopologyAndEmptyAsFull(t *testing.T) {
	changes := map[string]genChange{"z/member": {}, "a/member": {}}
	if got := publicationScope(false, changes); got.full || !reflect.DeepEqual(got.prefixes, []string{"a/member", "z/member"}) {
		t.Fatalf("member publication scope = %+v", got)
	}
	if got := publicationScope(true, changes); !got.full {
		t.Fatalf("topology change must use full scope: %+v", got)
	}
	if got := publicationScope(false, nil); !got.full {
		t.Fatalf("publication without nameable prefixes must use full scope: %+v", got)
	}
}

func TestObservedTransitionsPreservePeerAsResidualPrefix(t *testing.T) {
	const (
		rcloneUUID = "00000000-0000-4000-8000-000000000301"
		peerUUID   = "00000000-0000-4000-8000-000000000302"
	)
	previous := testAggregateGenerationToken(t, 1)
	current := testAggregateGenerationToken(t, 2)
	mpc := &memberPollContext{
		pollSet: map[string]memberPollEntry{
			rcloneUUID: {Prefix: "rclone-member", Kind: "rclone"},
			peerUUID:   {Prefix: "peer-member", Kind: "peer"},
		},
		registryPrefixes: map[string]string{rcloneUUID: "rclone-member", peerUUID: "peer-member"},
		lastKnownGen:     map[string][24]byte{"rclone-member": current, "peer-member": current},
		lastTickChanges: map[string]genChange{
			"rclone-member": {prev: previous, hadPrev: true},
			"peer-member":   {prev: previous, hadPrev: true},
		},
	}
	transitions := mpc.observedTransitions([]string{rcloneUUID, peerUUID})
	if len(transitions) != 1 || transitions[0].LibraryUUID != rcloneUUID {
		t.Fatalf("rclone manifest transitions=%+v", transitions)
	}
	residual := residualPublicationScope(mpc.lastTickChanges, mpc.registryPrefixes, transitions)
	if residual.full || !reflect.DeepEqual(residual.prefixes, []string{"peer-member"}) {
		t.Fatalf("peer residual scope=%+v", residual)
	}
	derived := exactAggregateInvalidation([]string{"rclone-member/book"}, []string{"rclone-member/static"})
	merged := derived.merge(residual)
	if !reflect.DeepEqual(merged.prefixes, []string{"peer-member"}) || !reflect.DeepEqual(merged.books, []string{"rclone-member/book"}) {
		t.Fatalf("mixed transport scope=%+v", merged)
	}
}

func TestAggregateVFSInvalidatorRetriesOnlyFailedPlane(t *testing.T) {
	invalidator := newAggregateVFSInvalidator(aggregateVFSResources{
		BooksFS:  "books:bucket",
		AssetsFS: "assets:bucket",
	})
	assetsFailures := 1
	callsPtr := stubForget(invalidator, func(fs string) bool {
		if fs == "assets:bucket" && assetsFailures > 0 {
			assetsFailures--
			return true
		}
		return false
	})
	calls := func() []forgetCall { return *callsPtr }

	invalidator.invalidate(memberAggregateInvalidation("z", "a"))
	if len(calls()) != 2 {
		t.Fatalf("initial calls = %d, want books + assets", len(calls()))
	}
	for _, got := range calls() {
		if !reflect.DeepEqual(got.dirs, []string{"a", "z"}) {
			t.Fatalf("%s dirs = %v", got.fs, got.dirs)
		}
	}
	if _, ok := invalidator.pending["books"]; ok {
		t.Fatal("successful books invalidation remained pending")
	}
	if _, ok := invalidator.pending["assets"]; !ok {
		t.Fatal("failed assets invalidation was not retained")
	}

	invalidator.retry()
	if len(calls()) != 3 || calls()[2].fs != "assets:bucket" {
		t.Fatalf("retry calls = %+v, want assets only", calls())
	}
	if len(invalidator.pending) != 0 {
		t.Fatalf("pending after successful retry = %+v", invalidator.pending)
	}
}

func TestAggregateVFSInvalidatorUsesPlaneSpecificExactDirectories(t *testing.T) {
	invalidator := newAggregateVFSInvalidator(aggregateVFSResources{
		BooksFS:  "books:bucket",
		AssetsFS: "assets:bucket",
	})
	calls := stubForget(invalidator, func(string) bool { return false })

	invalidator.invalidate(exactAggregateInvalidation(
		[]string{"member/Author/Book"},
		[]string{"member/Author/Cover", "member/static"},
	))
	if len(*calls) != 2 {
		t.Fatalf("calls = %+v, want one call per plane", *calls)
	}
	if got := (*calls)[0]; got.fs != "books:bucket" || !reflect.DeepEqual(got.dirs, []string{"member/Author/Book"}) {
		t.Fatalf("books call = %+v", got)
	}
	if got := (*calls)[1]; got.fs != "assets:bucket" || !reflect.DeepEqual(got.dirs, []string{"member/Author/Cover", "member/static"}) {
		t.Fatalf("assets call = %+v", got)
	}
}

// TestAggregateVFSInvalidatorExactScopeEmptyPlaneIsNoop guards against
// collapsing "nothing named on this plane" into ForgetVFSDirectories' own
// zero-args contract, which means "forget this VFS's complete tree." An
// exact scope whose books side is legitimately empty (for example a member
// change that only touched assets) must not forget the entire books plane.
func TestAggregateVFSInvalidatorExactScopeEmptyPlaneIsNoop(t *testing.T) {
	invalidator := newAggregateVFSInvalidator(aggregateVFSResources{
		BooksFS:  "books:bucket",
		AssetsFS: "assets:bucket",
	})
	calls := stubForget(invalidator, func(string) bool { return false })

	invalidator.invalidate(exactAggregateInvalidation(nil, []string{"member/static"}))
	if len(*calls) != 1 {
		t.Fatalf("calls = %+v, want only the assets plane invoked", *calls)
	}
	if got := (*calls)[0]; got.fs != "assets:bucket" || !reflect.DeepEqual(got.dirs, []string{"member/static"}) {
		t.Fatalf("assets call = %+v", got)
	}
	if len(invalidator.pending) != 0 {
		t.Fatalf("pending after empty-plane no-op = %+v", invalidator.pending)
	}
}

func TestAggregateVFSInvalidatorFullScopeDominatesPendingMembers(t *testing.T) {
	invalidator := newAggregateVFSInvalidator(aggregateVFSResources{
		BooksFS:  "books:bucket",
		AssetsFS: "assets:bucket",
	})
	fail := true
	callsPtr := stubForget(invalidator, func(string) bool { return fail })

	invalidator.invalidate(memberAggregateInvalidation("member"))
	fail = false
	invalidator.invalidate(fullAggregateInvalidation())
	calls := *callsPtr
	if len(calls) != 4 {
		t.Fatalf("calls = %+v, want two failed member calls then two full calls", calls)
	}
	for _, got := range calls[2:] {
		if got.dirs != nil {
			t.Fatalf("%s retry dirs = %v, want full forget", got.fs, got.dirs)
		}
	}
	if len(invalidator.pending) != 0 {
		t.Fatalf("pending after full success = %+v", invalidator.pending)
	}
}

func TestAggregatePublicationIntentUsesExactGeneration(t *testing.T) {
	one := testAggregateGenerationToken(t, 1)
	two := testAggregateGenerationToken(t, 2)

	var intent aggregatePublicationIntent
	if got := intent.consume(aggregateGenerationToken{}); !got.full {
		t.Fatalf("nothing recorded must use full scope even for a zero token: %+v", got)
	}

	intent.record(one, memberAggregateInvalidation("member"))
	if got := intent.consume(one); got.full || !reflect.DeepEqual(got.prefixes, []string{"member"}) {
		t.Fatalf("exact generation scope = %+v", got)
	}
	if got := intent.consume(one); !got.full {
		t.Fatalf("consumed intent must not match a second time: %+v", got)
	}

	intent.record(one, memberAggregateInvalidation("member"))
	if got := intent.consume(two); !got.full {
		t.Fatalf("mismatched generation must use full scope: %+v", got)
	}

	intent.record(aggregateGenerationToken{}, fullAggregateInvalidation())
	intent.record(one, memberAggregateInvalidation("member"))
	if got := intent.consume(one); !got.full {
		t.Fatalf("a failed bind must keep the full scope for the next generation: %+v", got)
	}

	intent.record(one, memberAggregateInvalidation("a"))
	intent.record(two, memberAggregateInvalidation("b"))
	if got := intent.consume(two); got.full || !reflect.DeepEqual(got.prefixes, []string{"a", "b"}) {
		t.Fatalf("superseding generation must carry the union: %+v", got)
	}
}

func TestServeStateHotSwapPublishesBeforeOldReaderDrain(t *testing.T) {
	old := &singleIndex{}
	next := &singleIndex{}
	state := &serveState{current: old}
	_, release := state.snapshot()

	published := make(chan struct{})
	returned := make(chan struct{})
	go func() {
		state.hotSwap(next, func() { close(published) })
		close(returned)
	}()

	select {
	case <-published:
	case <-time.After(time.Second):
		t.Fatal("publication callback did not run while old reader was held")
	}
	select {
	case <-returned:
		t.Fatal("hotSwap returned before old reader drain")
	default:
	}
	current, currentRelease := state.snapshot()
	currentRelease()
	if current != next {
		t.Fatal("publication callback ran before next pointer became visible")
	}
	release()
	select {
	case <-returned:
	case <-time.After(time.Second):
		t.Fatal("hotSwap did not finish after old reader released")
	}
}

func TestMemberPollContextRollbackRestoresTopologyAndGenerations(t *testing.T) {
	var previous [24]byte
	previous[0] = 7
	mpc := &memberPollContext{
		lastKnownGen: map[string][24]byte{"member": {9}},
		lastTickChanges: map[string]genChange{
			"member": {prev: previous, hadPrev: true},
		},
	}
	mpc.rollback(true)
	if !mpc.membershipChanged {
		t.Fatal("failed topology rebuild did not restore membership change")
	}
	if got := mpc.lastKnownGen["member"]; got != previous {
		t.Fatalf("member generation = %v, want restored %v", got, previous)
	}
	if mpc.lastTickChanges != nil {
		t.Fatalf("restored lastTickChanges = %+v, want nil after rollback", mpc.lastTickChanges)
	}
}
