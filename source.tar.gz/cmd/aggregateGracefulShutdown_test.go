//go:build !windows

package cmd

import (
	"bytes"
	"fmt"
	"net"
	"net/http"
	"net/http/httputil"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"syscall"
	"testing"
	"time"

	"accorder/pkg/rclonexfer"
	"github.com/rclone/rclone/fs/config"
)

const (
	gracefulShutdownHelperEnv = "ACCORDER_GRACEFUL_SHUTDOWN_HELPER"
	gracefulShutdownShapeEnv  = "ACCORDER_GRACEFUL_SHUTDOWN_SHAPE"
	gracefulShutdownReadyEnv  = "ACCORDER_GRACEFUL_SHUTDOWN_READY"
	gracefulShutdownDoneEnv   = "ACCORDER_GRACEFUL_SHUTDOWN_DONE"
)

func TestGracefulShutdownEmbeddedRcloneSubprocess(t *testing.T) {
	if os.Getenv(gracefulShutdownHelperEnv) == "1" {
		runPhase0GracefulShutdownHelper(t)
		return
	}

	for _, shape := range []string{"idle", "cover", "book", "range"} {
		t.Run(shape, func(t *testing.T) {
			dir := t.TempDir()
			readyPath := filepath.Join(dir, "ready")
			donePath := filepath.Join(dir, "done")
			var output bytes.Buffer
			child := exec.Command(os.Args[0], "-test.run=^TestGracefulShutdownEmbeddedRcloneSubprocess$")
			child.Env = append(os.Environ(),
				gracefulShutdownHelperEnv+"=1",
				gracefulShutdownShapeEnv+"="+shape,
				gracefulShutdownReadyEnv+"="+readyPath,
				gracefulShutdownDoneEnv+"="+donePath,
			)
			child.Stdout = &output
			child.Stderr = &output
			if err := child.Start(); err != nil {
				t.Fatal(err)
			}

			addr := waitForShutdownHelperFile(t, child, readyPath, 10*time.Second)
			var response *http.Response
			if shape != "idle" {
				requestPath := "/book.epub"
				if shape == "cover" {
					requestPath = "/cover.jpg"
				}
				req, err := http.NewRequest(http.MethodGet, "http://"+addr+requestPath, nil)
				if err != nil {
					t.Fatal(err)
				}
				if shape == "range" {
					req.Header.Set("Range", "bytes=0-33554431")
				}
				response, err = http.DefaultClient.Do(req)
				if err != nil {
					t.Fatalf("start held %s request: %v\n%s", shape, err, output.String())
				}
			}

			started := time.Now()
			if err := child.Process.Signal(syscall.SIGTERM); err != nil {
				t.Fatal(err)
			}
			waitErr := waitForShutdownHelperExit(child, 5*time.Second)
			if response != nil {
				_ = response.Body.Close()
			}
			if waitErr != nil {
				t.Fatalf("%s child exit: %v\n%s", shape, waitErr, output.String())
			}
			if elapsed := time.Since(started); elapsed >= 5*time.Second {
				t.Fatalf("%s shutdown took %s", shape, elapsed)
			}
			if _, err := os.Stat(donePath); err != nil {
				t.Fatalf("%s cleanup marker: %v\n%s", shape, err, output.String())
			}
			for _, forbidden := range []string{
				"Signal received:",
				"context deadline exceeded",
				"Exiting...",
			} {
				if strings.Contains(output.String(), forbidden) {
					t.Fatalf("%s output contains %q:\n%s", shape, forbidden, output.String())
				}
			}
			for _, required := range []string{
				"shutdown phase public-http-drain started",
				"shutdown phase public-http-drain completed",
				"shutdown phase caller-background completed",
				"shutdown phase assets-vfs-stop completed",
				"shutdown phase books-vfs-stop completed",
			} {
				if !strings.Contains(output.String(), required) {
					t.Fatalf("%s output does not contain %q:\n%s", shape, required, output.String())
				}
			}
			if shape != "idle" && !strings.Contains(output.String(), "public-http-drain grace expired") {
				t.Fatalf("%s request drained before the forced-close assertion:\n%s", shape, output.String())
			}
			assertShutdownLogOrder(t, output.String(),
				"shutdown phase public-http-drain completed",
				"shutdown phase caller-background completed",
				"shutdown phase assets-vfs-stop completed",
				"shutdown phase books-vfs-stop completed",
			)
			if count := strings.Count(output.String(), "shutdown phase assets-vfs-stop started"); count != 1 {
				t.Fatalf("%s assets cleanup ran %d times, want once:\n%s", shape, count, output.String())
			}
		})
	}
}

func runPhase0GracefulShutdownHelper(t *testing.T) {
	rclonexfer.UseHostSignalHandler()
	dir := t.TempDir()
	if err := config.SetConfigPath(filepath.Join(dir, "rclone.conf")); err != nil {
		t.Fatal(err)
	}
	if err := rclonexfer.SetCacheDir(filepath.Join(dir, "cache")); err != nil {
		t.Fatal(err)
	}
	rclonexfer.Initialize()
	defer rclonexfer.Finalize()

	backing := filepath.Join(dir, "backing")
	if err := os.MkdirAll(backing, 0o755); err != nil {
		t.Fatal(err)
	}
	for _, name := range []string{"cover.jpg", "book.epub"} {
		f, err := os.Create(filepath.Join(backing, name))
		if err != nil {
			t.Fatal(err)
		}
		if err := f.Truncate(64 << 20); err != nil {
			_ = f.Close()
			t.Fatal(err)
		}
		if err := f.Close(); err != nil {
			t.Fatal(err)
		}
	}

	booksID, booksAddr, err := rclonexfer.ServeHTTPWithVFS(backing, "127.0.0.1:0", rclonexfer.VFSOptions{CacheMode: "full", ReadOnly: true})
	if err != nil {
		t.Fatal(err)
	}
	assetsID, assetsAddr, err := rclonexfer.ServeHTTPWithVFS(backing, "127.0.0.1:0", rclonexfer.VFSOptions{CacheMode: "full", ReadOnly: true})
	if err != nil {
		_ = rclonexfer.StopServe(booksID)
		t.Fatal(err)
	}

	booksURL, _ := url.Parse("http://" + booksAddr)
	assetsURL, _ := url.Parse("http://" + assetsAddr)
	mux := http.NewServeMux()
	mux.Handle("/book.epub", httputil.NewSingleHostReverseProxy(booksURL))
	mux.Handle("/cover.jpg", httputil.NewSingleHostReverseProxy(assetsURL))
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(os.Getenv(gracefulShutdownReadyEnv), []byte(ln.Addr().String()), 0o600); err != nil {
		t.Fatal(err)
	}
	if err := serveHTTPWithTransport(ln, mux, ServeOptions{
		CommandName:   "test graceful shutdown",
		OnlyHTTP:      true,
		ShutdownGrace: 150 * time.Millisecond,
		OnShutdown:    func() {},
	}); err != nil {
		t.Fatal(err)
	}

	var cleanupOnce sync.Once
	cleanup := func() {
		cleanupOnce.Do(func() {
			for _, serve := range []struct {
				name string
				id   string
			}{{"assets", assetsID}, {"books", booksID}} {
				started := time.Now()
				if err := runShutdownPhase("test graceful shutdown", serve.name+"-vfs-stop", func() error {
					return rclonexfer.StopServe(serve.id)
				}); err != nil {
					t.Fatalf("stop %s VFS: %v", serve.name, err)
				}
				if elapsed := time.Since(started); elapsed >= 2*time.Second {
					t.Fatalf("stop %s VFS took %s after outer cancellation", serve.name, elapsed)
				}
			}
		})
	}
	cleanup()
	cleanup()
	if err := os.WriteFile(os.Getenv(gracefulShutdownDoneEnv), []byte("ok\n"), 0o600); err != nil {
		t.Fatal(err)
	}
}

func assertShutdownLogOrder(t *testing.T, output string, markers ...string) {
	t.Helper()
	previous := -1
	for _, marker := range markers {
		index := strings.Index(output, marker)
		if index < 0 {
			t.Fatalf("shutdown output missing %q:\n%s", marker, output)
		}
		if index <= previous {
			t.Fatalf("shutdown marker %q is out of order:\n%s", marker, output)
		}
		previous = index
	}
}

func waitForShutdownHelperFile(t *testing.T, child *exec.Cmd, path string, timeout time.Duration) string {
	t.Helper()
	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) {
		body, err := os.ReadFile(path)
		if err == nil && len(body) > 0 {
			return string(body)
		}
		if child.ProcessState != nil && child.ProcessState.Exited() {
			t.Fatalf("helper exited before readiness")
		}
		time.Sleep(10 * time.Millisecond)
	}
	_ = child.Process.Kill()
	t.Fatalf("helper did not become ready within %s", timeout)
	return ""
}

func waitForShutdownHelperExit(child *exec.Cmd, timeout time.Duration) error {
	done := make(chan error, 1)
	go func() { done <- child.Wait() }()
	select {
	case err := <-done:
		return err
	case <-time.After(timeout):
		_ = child.Process.Kill()
		<-done
		return fmt.Errorf("did not exit within %s", timeout)
	}
}
