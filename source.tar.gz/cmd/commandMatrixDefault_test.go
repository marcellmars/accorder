//go:build !tor && !tailscale

package cmd

import "testing"

// The default build must not leak tag-gated transports (cq-38).
func TestCommandMatrix_VariantExtrasAbsent(t *testing.T) {
	got := collectCommandPaths(t)
	for _, extra := range []string{
		"lib.share.address",
		"lib.share.grant-tor",
		"fedlib.share.grant-tor",
		"lib.share.funnel",
		"fedlib.share.funnel",
	} {
		if got[extra] {
			t.Errorf("tag-gated command %q leaked into the default build", extra)
		}
	}
}
