package cmd

import (
	"encoding/json"
	"fmt"
	"log"
	"os"
	"strings"

	"github.com/tidwall/gjson"
	"github.com/tidwall/sjson"
)

var sourceRegistryPath string

type SourceEntry struct {
	UUID          string `json:"uuid"`
	Endpoint      string `json:"endpoint,omitempty"`
	Invite        string `json:"invite,omitempty"`
	PublisherType string `json:"publisherType,omitempty"`
	SourceLabel   string `json:"sourceLabel,omitempty"`
	LibraryName   string `json:"libraryName,omitempty"`
	Librarian     string `json:"librarian,omitempty"`
}

func loadSourceRegistry() []byte {
	data, err := os.ReadFile(sourceRegistryPath)
	if err != nil {
		if os.IsNotExist(err) {
			return []byte("{}")
		}
		log.Fatalln("load source registry:", err)
	}
	return data
}

func saveSourceRegistry(content []byte) {
	tmp := sourceRegistryPath + ".tmp"
	if err := os.WriteFile(tmp, content, 0644); err != nil {
		log.Fatalln("save source registry:", err)
	}
	if err := os.Rename(tmp, sourceRegistryPath); err != nil {
		log.Fatalln("rename source registry:", err)
	}
}

func registrySet(name string, entry SourceEntry) error {
	data := loadSourceRegistry()
	existing := gjson.GetBytes(data, name)
	if existing.Exists() {
		existingUUID := existing.Get("uuid").String()
		if existingUUID != "" && entry.UUID != "" && existingUUID != entry.UUID {
			return fmt.Errorf("source name %q already registered (uuid %s) — "+
				"pick a different name, or rename the old entry "+
				"('lib index rename %s <new-name>')", name, existingUUID, name)
		}
		if existingUUID == "" && entry.UUID == "" {
			return fmt.Errorf("source name %q already registered — "+
				"use 'lib browse <alias> --from %s' to sync it, or pick a different name", name, name)
		}
	}
	if existing.Exists() {
		data, _ = sjson.DeleteBytes(data, name)
	}
	entryJSON, _ := json.Marshal(entry)
	data, _ = sjson.SetRawBytes(data, name, entryJSON)
	saveSourceRegistry(data)
	return nil
}

func registerOrUpdate(name string, entry SourceEntry) string {
	data := loadSourceRegistry()
	candidate := name

	for i := 2; ; i++ {
		existing := gjson.GetBytes(data, candidate)
		if !existing.Exists() {
			break
		}
		existingUUID := existing.Get("uuid").String()
		if existingUUID == entry.UUID {
			break
		}
		if existingUUID == "" {
			break
		}
		candidate = fmt.Sprintf("%s-%d", name, i)
	}

	if gjson.GetBytes(data, candidate).Exists() {
		data, _ = sjson.DeleteBytes(data, candidate)
	}
	entryJSON, _ := json.Marshal(entry)
	data, _ = sjson.SetRawBytes(data, candidate, entryJSON)
	saveSourceRegistry(data)
	return candidate
}

func registryGet(name string) (SourceEntry, bool) {
	data := loadSourceRegistry()
	r := gjson.GetBytes(data, name)
	if !r.Exists() {
		return SourceEntry{}, false
	}
	return SourceEntry{
		UUID:          r.Get("uuid").String(),
		Endpoint:      r.Get("endpoint").String(),
		Invite:        r.Get("invite").String(),
		PublisherType: r.Get("publisherType").String(),
		SourceLabel:   r.Get("sourceLabel").String(),
		LibraryName:   r.Get("libraryName").String(),
		Librarian:     r.Get("librarian").String(),
	}, true
}

func registryDelete(name string) error {
	data := loadSourceRegistry()
	if !gjson.GetBytes(data, name).Exists() {
		return fmt.Errorf("source %q not found in registry", name)
	}
	data, _ = sjson.DeleteBytes(data, name)
	saveSourceRegistry(data)
	return nil
}

func registryRename(oldName, newName string) error {
	data := loadSourceRegistry()
	old := gjson.GetBytes(data, oldName)
	if !old.Exists() {
		return fmt.Errorf("source %q not found in registry", oldName)
	}
	if gjson.GetBytes(data, newName).Exists() {
		return fmt.Errorf("source name %q already exists", newName)
	}
	data, _ = sjson.SetRawBytes(data, newName, []byte(old.Raw))
	data, _ = sjson.DeleteBytes(data, oldName)
	saveSourceRegistry(data)
	return nil
}

func registryFindByEndpoint(endpoint string) (string, SourceEntry, bool) {
	normalized := strings.TrimRight(endpoint, "/") + "/"
	data := loadSourceRegistry()
	var foundName string
	var foundEntry SourceEntry
	gjson.ParseBytes(data).ForEach(func(key, value gjson.Result) bool {
		ep := value.Get("endpoint").String()
		if ep == "" {
			return true
		}
		epNorm := strings.TrimRight(ep, "/") + "/"
		if epNorm == normalized {
			foundName = key.String()
			foundEntry = SourceEntry{
				UUID:          value.Get("uuid").String(),
				Endpoint:      ep,
				Invite:        value.Get("invite").String(),
				PublisherType: value.Get("publisherType").String(),
				SourceLabel:   value.Get("sourceLabel").String(),
				LibraryName:   value.Get("libraryName").String(),
				Librarian:     value.Get("librarian").String(),
			}
			return false
		}
		return true
	})
	if foundName != "" {
		return foundName, foundEntry, true
	}
	return "", SourceEntry{}, false
}

func registryList() map[string]SourceEntry {
	data := loadSourceRegistry()
	entries := make(map[string]SourceEntry)
	gjson.ParseBytes(data).ForEach(func(key, value gjson.Result) bool {
		entries[key.String()] = SourceEntry{
			UUID:          value.Get("uuid").String(),
			Endpoint:      value.Get("endpoint").String(),
			Invite:        value.Get("invite").String(),
			PublisherType: value.Get("publisherType").String(),
			SourceLabel:   value.Get("sourceLabel").String(),
			LibraryName:   value.Get("libraryName").String(),
			Librarian:     value.Get("librarian").String(),
		}
		return true
	})
	return entries
}
