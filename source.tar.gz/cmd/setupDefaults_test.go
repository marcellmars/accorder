//go:build !tailscale

package cmd

// Production tests for the setup-default mint (narrative-setup-defaults
// item 1), converted from the four TestSpike_H1_* spike tests. The spike
// simulated the mint with production primitives; these run the REAL
// in-hook mint (mintSetupDefaults inside AfterApply).
//

import (
	"accorder/pkg/fedlibinvite"
	"accorder/pkg/librarianname"
	"bytes"
	"os"
	"path/filepath"
	"strings"
	"testing"

	uuid "github.com/satori/go.uuid"
	"github.com/tidwall/gjson"
)

// parseCLIErr is parseCLI without t.Fatal on parse error, so negative
// arms can assert on the validation error.

const mintTestUUID = "550e8400-e29b-41d4-a716-446655440000"

// ═══════════════════════════════════════════════════════════════════
// Cold build with no --libraryID mints a UUID, persists it under the
// current path AND all sharedgroup:"lib" siblings (spike positive arm,
// now with the real in-hook mint).
// ═══════════════════════════════════════════════════════════════════

func TestMint_ColdBuildMintsAndPersistsAcrossSiblings(t *testing.T) {
	libDir := testSetup(t)

	_, ctx := parseCLI(t, []string{
		"lib", "build", "mintalias",
		"--calibrepath=" + libDir,
		"--librarian=Alice",
	})

	target := ctx.Selected().Target.Interface().(LibBuildCmd)
	if target.LibraryID == "" {
		t.Fatal("LibraryID not minted on cold build")
	}
	if _, err := uuid.FromString(target.LibraryID); err != nil {
		t.Fatalf("minted LibraryID %q is not a valid UUID: %v", target.LibraryID, err)
	}

	alias := readAlias(t, "mintalias")
	for _, path := range []string{"lib.build", "lib.share.live", "lib.upload", "lib.publish"} {
		if got := alias.Get(path + ".libraryID").String(); got != target.LibraryID {
			t.Errorf("%s.libraryID = %q, want minted %q", path, got, target.LibraryID)
		}
	}
}

// ═══════════════════════════════════════════════════════════════════
// A sibling command in a fresh parse (fresh process simulation) resolves
// the same minted id — cross-command identity stability.
// ═══════════════════════════════════════════════════════════════════

func TestMint_SiblingResolvesMintedID(t *testing.T) {
	libDir := testSetup(t)

	_, ctx := parseCLI(t, []string{
		"lib", "build", "mintalias",
		"--calibrepath=" + libDir,
		"--librarian=Alice",
	})
	minted := ctx.Selected().Target.Interface().(LibBuildCmd).LibraryID

	_, ctx2, err := parseCLIErr(t, []string{"lib", "share", "live", "mintalias"})
	if err != nil {
		t.Fatalf("sibling parse failed (minted id should satisfy uuid validation): %v", err)
	}
	target := ctx2.Selected().Target.Interface().(LibShareLiveCmd)
	if target.LibraryID != minted {
		t.Errorf("sibling resolved libraryID = %q, want minted %q", target.LibraryID, minted)
	}
	if target.Librarian != "Alice" {
		t.Errorf("sibling resolved librarian = %q, want Alice (first-run propagation)", target.Librarian)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Flagless re-runs after the mint neither clobber nor re-save the minted
// value — providedFlags discipline holds (alias file byte-identical).
// Spike arm c converted.
// ═══════════════════════════════════════════════════════════════════

func TestMint_RerunsDoNotClobberMintedValue(t *testing.T) {
	libDir := testSetup(t)

	_, ctx := parseCLI(t, []string{
		"lib", "build", "mintalias",
		"--calibrepath=" + libDir,
		"--librarian=Alice",
	})
	minted := ctx.Selected().Target.Interface().(LibBuildCmd).LibraryID

	before, err := os.ReadFile(savedActionAliases)
	if err != nil {
		t.Fatalf("read alias file: %v", err)
	}

	// Flagless re-run of the minting command.
	_, ctx2, err := parseCLIErr(t, []string{"lib", "build", "mintalias"})
	if err != nil {
		t.Fatalf("flagless lib build re-run failed: %v", err)
	}
	build := ctx2.Selected().Target.Interface().(LibBuildCmd)
	if build.LibraryID != minted {
		t.Errorf("re-run resolved libraryID = %q, want minted %q", build.LibraryID, minted)
	}

	// Flagless sibling run.
	if _, _, err := parseCLIErr(t, []string{"lib", "share", "live", "mintalias"}); err != nil {
		t.Fatalf("flagless lib share live run failed: %v", err)
	}

	after, err := os.ReadFile(savedActionAliases)
	if err != nil {
		t.Fatalf("read alias file: %v", err)
	}
	if !bytes.Equal(before, after) {
		t.Errorf("alias file changed across flagless re-runs (providedFlags discipline violated)\nbefore: %s\nafter:  %s", before, after)
	}
}

// ═══════════════════════════════════════════════════════════════════
// A provided --libraryID wins: no mint happens, the provided value is
// stored and resolved.
// ═══════════════════════════════════════════════════════════════════

func TestMint_ProvidedLibraryIDWins(t *testing.T) {
	libDir := testSetup(t)

	_, ctx := parseCLI(t, []string{
		"lib", "build", "providedalias",
		"--calibrepath=" + libDir,
		"--librarian=Alice",
		"--libraryID=" + mintTestUUID,
	})
	target := ctx.Selected().Target.Interface().(LibBuildCmd)
	if target.LibraryID != mintTestUUID {
		t.Errorf("LibraryID = %q, want provided %q (mint should not override)", target.LibraryID, mintTestUUID)
	}
	alias := readAlias(t, "providedalias")
	if got := alias.Get("lib.build.libraryID").String(); got != mintTestUUID {
		t.Errorf("persisted libraryID = %q, want provided %q", got, mintTestUUID)
	}
}

// ═══════════════════════════════════════════════════════════════════
// A provided INVALID UUID still fails validation — omitempty relaxation
// does not let bad values through.
// ═══════════════════════════════════════════════════════════════════

func TestMint_ProvidedInvalidUUIDStillErrors(t *testing.T) {
	libDir := testSetup(t)

	_, _, err := parseCLIErr(t, []string{
		"lib", "build", "badalias",
		"--calibrepath=" + libDir,
		"--librarian=Alice",
		"--libraryID=not-a-uuid",
	})
	if err == nil {
		t.Fatal("expected validation error for invalid --libraryID, got nil")
	}
	if !strings.Contains(err.Error(), "uuid") {
		t.Errorf("expected uuid validation error, got: %v", err)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Phase 2: librarian generation. Cold build with no --librarian
// generates a deterministic name seeded from the minted libraryID,
// persists + propagates it.
// ═══════════════════════════════════════════════════════════════════

func TestMint_GeneratesLibrarianFromMintedID(t *testing.T) {
	libDir := testSetup(t)

	_, ctx := parseCLI(t, []string{
		"lib", "build", "genalias",
		"--calibrepath=" + libDir,
	})
	target := ctx.Selected().Target.Interface().(LibBuildCmd)
	if target.LibraryID == "" {
		t.Fatal("LibraryID not minted")
	}
	want := librarianname.Generate(target.LibraryID, 0)
	if target.Librarian != want {
		t.Errorf("Librarian = %q, want generated %q", target.Librarian, want)
	}

	alias := readAlias(t, "genalias")
	for _, path := range []string{"lib.build", "lib.share.live", "lib.upload", "lib.publish"} {
		if got := alias.Get(path + ".librarian").String(); got != want {
			t.Errorf("%s.librarian = %q, want generated %q", path, got, want)
		}
	}

	// Fresh sibling parse resolves the same generated name (stored wins,
	// no regeneration).
	_, ctx2, err := parseCLIErr(t, []string{"lib", "share", "live", "genalias"})
	if err != nil {
		t.Fatalf("sibling parse failed: %v", err)
	}
	sibling := ctx2.Selected().Target.Interface().(LibShareLiveCmd)
	if sibling.Librarian != want {
		t.Errorf("sibling librarian = %q, want %q", sibling.Librarian, want)
	}
}

func TestMint_ProvidedLibrarianWins(t *testing.T) {
	libDir := testSetup(t)

	_, ctx := parseCLI(t, []string{
		"lib", "build", "namedalias",
		"--calibrepath=" + libDir,
		"--librarian=Ada Lovelace",
	})
	target := ctx.Selected().Target.Interface().(LibBuildCmd)
	if target.Librarian != "Ada Lovelace" {
		t.Errorf("Librarian = %q, want provided 'Ada Lovelace'", target.Librarian)
	}
	if _, generated := librarianname.IsGenerated(target.Librarian, target.LibraryID); generated {
		t.Error("provided librarian detected as generated")
	}
}

// ═══════════════════════════════════════════════════════════════════
// Phase 2: invite Label plumbing. lib join with a Label stores it as
// the alias's librarian; a subsequent lib build uses the Label, not a
// generated name.
// ═══════════════════════════════════════════════════════════════════

func TestJoin_LabelBecomesLibrarian(t *testing.T) {
	libDir := testSetup(t)

	inv := &fedlibinvite.WriteInvite{
		FedlibID:  "fedlib-x",
		Backend:   "s3",
		Prefix:    "alice",
		AccessKey: "AK",
		SecretKey: "SK",
		Label:     "Alice's Library",
	}
	blob := fedlibinvite.EncodeWriteInvite(inv)

	_, ctx := parseCLI(t, []string{"lib", "join", "joined", "--invite", blob, "--passphrase=pw"})
	join := &LibJoinCmd{Invite: blob, CommonCommandFields: CommonCommandFields{ActionAlias: "joined"}}
	if err := join.Run(ctx); err != nil {
		t.Fatalf("lib join: %v", err)
	}

	alias := readAlias(t, "joined")
	for _, path := range []string{"lib.build", "lib.share.live", "lib.upload", "lib.publish"} {
		if got := alias.Get(path + ".librarian").String(); got != "Alice's Library" {
			t.Errorf("%s.librarian = %q, want invite label", path, got)
		}
	}

	// Subsequent build uses the Label (stored value wins — no generation).
	_, ctx2, err := parseCLIErr(t, []string{"lib", "build", "joined", "--calibrepath=" + libDir})
	if err != nil {
		t.Fatalf("lib build after join failed: %v", err)
	}
	build := ctx2.Selected().Target.Interface().(LibBuildCmd)
	if build.Librarian != "Alice's Library" {
		t.Errorf("build librarian = %q, want invite label (no generation)", build.Librarian)
	}
}

func TestJoin_EmptyLabelTolerated(t *testing.T) {
	libDir := testSetup(t)

	inv := &fedlibinvite.WriteInvite{
		FedlibID:  "fedlib-x",
		Backend:   "s3",
		Prefix:    "bob",
		AccessKey: "AK",
		SecretKey: "SK",
	}
	blob := fedlibinvite.EncodeWriteInvite(inv)

	_, ctx := parseCLI(t, []string{"lib", "join", "nolabel", "--invite", blob, "--passphrase=pw"})
	join := &LibJoinCmd{Invite: blob, CommonCommandFields: CommonCommandFields{ActionAlias: "nolabel"}}
	if err := join.Run(ctx); err != nil {
		t.Fatalf("lib join: %v", err)
	}
	alias := readAlias(t, "nolabel")
	if alias.Get("lib.build.librarian").Exists() {
		t.Error("empty Label should not write a librarian")
	}

	// Build then generates (no stored librarian).
	_, ctx2, err := parseCLIErr(t, []string{"lib", "build", "nolabel", "--calibrepath=" + libDir})
	if err != nil {
		t.Fatalf("lib build after label-less join failed: %v", err)
	}
	build := ctx2.Selected().Target.Interface().(LibBuildCmd)
	if _, generated := librarianname.IsGenerated(build.Librarian, build.LibraryID); !generated {
		t.Errorf("librarian %q should be generated after label-less join", build.Librarian)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Phase 8 (pq-20): lib join --calibrepath chains build + publish. The
// live-Wasabi smoke rides the e2e harness; here we assert the chain
// fires, identity is minted + persisted, and the pre-checks produce
// friendly errors.
// ═══════════════════════════════════════════════════════════════════

func TestJoinPublish_MintsIdentityAndPrechecksLibrary(t *testing.T) {
	libDir := testSetup(t)
	// Empty is now a supported recovery destination. A non-empty unrelated
	// directory still fails before a claim or local identity mutation.
	if err := os.WriteFile(filepath.Join(libDir, "unrelated.txt"), []byte("keep"), 0o644); err != nil {
		t.Fatal(err)
	}

	inv := &fedlibinvite.WriteInvite{
		FedlibID: "fedlib-x",
		Backend:  "s3",
		RemoteConfig: map[string]string{
			"provider": "Wasabi", "endpoint": "ep", "bucket": "motw",
		},
		Prefix:    "alice",
		AccessKey: "AK",
		SecretKey: "SK",
		Label:     "Alice's Library",
	}
	blob := fedlibinvite.EncodeWriteInvite(inv)

	args := []string{"lib", "join", "jp", "--invite", blob, "--passphrase=pw", "--calibrepath=" + libDir}
	_, ctx := parseCLI(t, args)
	join := &LibJoinCmd{Invite: blob, CommonCommandFields: CommonCommandFields{ActionAlias: "jp"}, CalibrePath: libDir}
	err := join.Run(ctx)
	if err == nil {
		t.Fatal("expected metadata.db pre-check error, got nil")
	}
	if !strings.Contains(err.Error(), "metadata.db") {
		t.Errorf("expected friendly metadata.db pre-check, got: %v", err)
	}

	// Preflight runs before any side effect: nothing is stored on the
	// alias when the calibrepath check fails (the invite — single-use
	// when claimed via URL — stays redeemable for a corrected retry).
	if data, err := os.ReadFile(savedActionAliases); err == nil {
		if got := gjson.GetBytes(data, "jp.lib.build.librarian").String(); got != "" {
			t.Errorf("librarian stored despite failed preflight: %q", got)
		}
	}
}

func TestJoinPublish_RequiresRemoteConfig(t *testing.T) {
	libDir := testSetup(t)

	// Give the dir a metadata.db stub so the pre-check passes and the
	// remote-config check is reached first... order: metadata.db check
	// runs first, so put the stub in place.
	if err := os.WriteFile(libDir+"/metadata.db", []byte("stub"), 0o644); err != nil {
		t.Fatal(err)
	}

	inv := &fedlibinvite.WriteInvite{
		FedlibID:  "fedlib-x",
		Backend:   "s3",
		Prefix:    "bob",
		AccessKey: "AK",
		SecretKey: "SK",
	}
	blob := fedlibinvite.EncodeWriteInvite(inv)
	_, ctx := parseCLI(t, []string{"lib", "join", "norc", "--invite", blob, "--passphrase=pw", "--calibrepath=" + libDir})
	join := &LibJoinCmd{Invite: blob, CommonCommandFields: CommonCommandFields{ActionAlias: "norc"}, CalibrePath: libDir}
	err := join.Run(ctx)
	if err == nil {
		t.Fatal("expected remote-config error, got nil")
	}
	if !strings.Contains(err.Error(), "bucket") {
		t.Errorf("expected bucket/remote-config error, got: %v", err)
	}

	// Identity minted + persisted before the publish chain bailed.
	alias := readAlias(t, "norc")
	id := alias.Get("lib.build.libraryID").String()
	if id == "" {
		t.Fatal("libraryID not minted/persisted by join+publish path")
	}
	want := librarianname.Generate(id, 0)
	if got := alias.Get("lib.build.librarian").String(); got != want {
		t.Errorf("librarian = %q, want generated %q", got, want)
	}

	// Calibrepath persisted for future flagless builds.
	if got := alias.Get("lib.build.calibrepath").String(); got != libDir {
		t.Errorf("calibrepath = %q, want %q", got, libDir)
	}

	// Propagated to siblings.
	if got := alias.Get("lib.share.live.libraryID").String(); got != id {
		t.Errorf("sibling libraryID = %q, want %q", got, id)
	}
}
