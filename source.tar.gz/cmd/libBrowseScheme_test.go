package cmd

import (
	"strings"
	"testing"
)

// A malformed --http-endpoint scheme (e.g. the "htpps://" typo, a missing
// scheme, or a non-http scheme) must fail fast with a clear error — before any
// rclone call, which would otherwise retry 4× on "unsupported protocol scheme".
func TestLibBrowse_BadEndpointScheme_FailsFast(t *testing.T) {
	cases := []string{
		"htpps://library.memoryoftheworld.org", // scheme typo
		"library.memoryoftheworld.org",         // no scheme
		"ftp://library.memoryoftheworld.org",   // wrong scheme
	}
	for _, ep := range cases {
		c := &LibBrowseCmd{HTTPEndpoint: ep}
		c.ActionAlias = "motw"
		err := c.Run(nil)
		if err == nil {
			t.Errorf("%q: want a validation error, got nil", ep)
			continue
		}
		if !strings.Contains(err.Error(), "not a valid http(s)") {
			t.Errorf("%q: want a scheme error, got: %v", ep, err)
		}
	}
}
