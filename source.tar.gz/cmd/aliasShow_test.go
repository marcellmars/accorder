//go:build !tailscale

package cmd

// ca-126: `config show` is deny-by-default. Only canonical command labels
// and recognized field names are emitted; safe scalar values print raw;
// credentials, compound values under fields, and unknown raw key bytes are
// redacted; malformed trees fail with a sanitized error and empty stdout.

import (
	"os"
	"strings"
	"testing"
)

// runAliasShow parses and dispatches `config show <name>` the way
// production does, capturing stdout/stderr.
func runAliasShow(t *testing.T, name string) (stdout, stderr string, err error) {
	t.Helper()
	_, ctx := parseCLI(t, []string{"config", "show", name})
	return captureInviteOutput(t, func() error { return ctx.Run() })
}

func seedRawAliases(t *testing.T, raw string) {
	t.Helper()
	if err := os.WriteFile(savedActionAliases, []byte(raw), 0o600); err != nil {
		t.Fatal(err)
	}
}

func TestAliasShow_SafeScalarsKeepFormatting(t *testing.T) {
	testSetup(t)
	seedRawAliases(t, `{"demo":{"fedlib":{"share":{"live":{"cache-size":"2Gi","poll-interval":30,"allow-full-rebuild":true,"listen":""}}}}}`)

	stdout, _, err := runAliasShow(t, "demo")
	if err != nil {
		t.Fatalf("run: %v", err)
	}
	want := "Alias: demo\n" +
		"  fedlib:\n" +
		"    share:\n" +
		"      live:\n" +
		"        allow-full-rebuild: true\n" +
		"        cache-size: \"2Gi\"\n" +
		"        listen: \"\"\n" +
		"        poll-interval: 30\n"
	if stdout != want {
		t.Errorf("output mismatch:\ngot:\n%s\nwant:\n%s", stdout, want)
	}
}

// The flagship example: a safe bucket renders, a credential field keeps its
// canonical label but hides its value, an unknown key hides both.
func TestAliasShow_CredentialAndUnknownKeyRedaction(t *testing.T) {
	testSetup(t)
	seedRawAliases(t, `{"leak":{"lib":{"upload":{"bucket":"books/alice","s3-secret-key":"TOPSECRET","zz-unknown-key":"HIDDENVALUE"}}}}`)

	stdout, stderr, err := runAliasShow(t, "leak")
	if err != nil {
		t.Fatalf("run: %v", err)
	}
	want := "Alias: leak\n" +
		"  lib:\n" +
		"    upload:\n" +
		"      bucket: \"books/alice\"\n" +
		"      s3-secret-key: <redacted>\n" +
		"      <redacted-key>: <redacted>\n"
	if stdout != want {
		t.Errorf("output mismatch:\ngot:\n%s\nwant:\n%s", stdout, want)
	}
	for _, forbidden := range []string{"TOPSECRET", "HIDDENVALUE", "zz-unknown-key"} {
		if strings.Contains(stdout, forbidden) || strings.Contains(stderr, forbidden) {
			t.Errorf("output leaked %q", forbidden)
		}
	}
}

// An object below a credential field is one redacted compound leaf: the
// allow-listed child name inside it must not be reclassified and exposed.
func TestAliasShow_NestedSecretCounterexample(t *testing.T) {
	testSetup(t)
	seedRawAliases(t, `{"leak":{"lib":{"upload":{"s3-secret-key":{"bucket":"SECRET_BYTES"}}}}}`)

	stdout, stderr, err := runAliasShow(t, "leak")
	if err != nil {
		t.Fatalf("run: %v", err)
	}
	if !strings.Contains(stdout, "s3-secret-key: <redacted>") {
		t.Errorf("compound credential not redacted atomically:\n%s", stdout)
	}
	for _, forbidden := range []string{"SECRET_BYTES", "bucket"} {
		if strings.Contains(stdout, forbidden) || strings.Contains(stderr, forbidden) {
			t.Errorf("nested compound leaked %q:\n%s", forbidden, stdout)
		}
	}
}

// Arrays and compounds under safe names redact atomically too.
func TestAliasShow_CompoundUnderSafeNameRedacts(t *testing.T) {
	testSetup(t)
	seedRawAliases(t, `{"demo":{"lib":{"upload":{"bucket":["SECRET_IN_ARRAY"],"keys-file":{"deep":"SECRET_IN_OBJ"}}}}}`)

	stdout, _, err := runAliasShow(t, "demo")
	if err != nil {
		t.Fatalf("run: %v", err)
	}
	if !strings.Contains(stdout, "bucket: <redacted>") || !strings.Contains(stdout, "keys-file: <redacted>") {
		t.Errorf("compound values under safe names not redacted:\n%s", stdout)
	}
	for _, forbidden := range []string{"SECRET_IN_ARRAY", "SECRET_IN_OBJ", "deep"} {
		if strings.Contains(stdout, forbidden) {
			t.Errorf("compound leaked %q:\n%s", forbidden, stdout)
		}
	}
}

// Raw keys are untrusted bytes: secrets, newlines, and terminal-control
// sequences in a key must not reach the terminal, and a newline in a key
// must not inject an extra output line.
func TestAliasShow_MaliciousKeyBytesNeverEcho(t *testing.T) {
	testSetup(t)
	seedRawAliases(t, `{"demo":{"lib":{"upload":{"AKIA_LEAKED_KEY_ID":"v1","evil\n[injected]": "v2","ansi\u001b[31mred":"v3"}}}}`)

	stdout, stderr, err := runAliasShow(t, "demo")
	if err != nil {
		t.Fatalf("run: %v", err)
	}
	want := "Alias: demo\n" +
		"  lib:\n" +
		"    upload:\n" +
		"      <redacted-key>: <redacted>\n" +
		"      <redacted-key>: <redacted>\n" +
		"      <redacted-key>: <redacted>\n"
	if stdout != want {
		t.Errorf("output mismatch (injected line?):\ngot:\n%q\nwant:\n%q", stdout, want)
	}
	for _, forbidden := range []string{"AKIA_LEAKED_KEY_ID", "[injected]", "\x1b", "ansi"} {
		if strings.Contains(stdout, forbidden) || strings.Contains(stderr, forbidden) {
			t.Errorf("malicious key bytes leaked (%q)", forbidden)
		}
	}
}

// Structural failures: scalar, array, and null roots, plus wrong-shaped
// recognized structural nodes, return a sanitized error naming only the
// alias and canonical path — with empty stdout and no raw bytes anywhere.
func TestAliasShow_StructuralFailuresAreSanitized(t *testing.T) {
	for _, tc := range []struct {
		name    string
		raw     string
		wantErr string
	}{
		{"scalar_root", `{"leak":"SECRET_BYTES"}`, `alias "leak" has invalid structure`},
		{"array_root", `{"leak":["SECRET_BYTES"]}`, `alias "leak" has invalid structure`},
		{"null_root", `{"leak":null}`, `alias "leak" has invalid structure`},
		{"scalar_at_command", `{"leak":{"lib":"SECRET_BYTES"}}`, "invalid structure at lib"},
		{"null_at_nested_command", `{"leak":{"lib":{"upload":null}}}`, "invalid structure at lib.upload"},
		{"array_at_command", `{"leak":{"lib":{"upload":["SECRET_BYTES"]}}}`, "invalid structure at lib.upload"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			testSetup(t)
			seedRawAliases(t, tc.raw)

			stdout, stderr, err := runAliasShow(t, "leak")
			if err == nil || !strings.Contains(err.Error(), tc.wantErr) {
				t.Fatalf("want error containing %q, got %v", tc.wantErr, err)
			}
			if stdout != "" {
				t.Errorf("partial output on structural failure:\n%q", stdout)
			}
			for _, ch := range []struct{ name, text string }{
				{"stdout", stdout}, {"stderr", stderr}, {"error", err.Error()},
			} {
				if strings.Contains(ch.text, "SECRET_BYTES") {
					t.Errorf("%s leaked raw value", ch.name)
				}
			}
		})
	}
}

// {} is a valid, empty alias tree — and unknown structure at the profile
// root (e.g. state from another build variant) hides its key bytes.
func TestAliasShow_EmptyAndForeignRoots(t *testing.T) {
	testSetup(t)
	seedRawAliases(t, `{"empty":{},"foreign":{"unknown-subtree":{"deep":"SECRET"}}}`)

	stdout, _, err := runAliasShow(t, "empty")
	if err != nil {
		t.Fatalf("empty object root must be valid: %v", err)
	}
	if stdout != "Alias: empty\n" {
		t.Errorf("empty alias output = %q, want header only", stdout)
	}

	stdout, _, err = runAliasShow(t, "foreign")
	if err != nil {
		t.Fatalf("foreign subtree must render redacted, not fail: %v", err)
	}
	if !strings.Contains(stdout, "<redacted-key>: <redacted>") {
		t.Errorf("foreign subtree not redacted:\n%s", stdout)
	}
	for _, forbidden := range []string{"unknown-subtree", "deep", "SECRET"} {
		if strings.Contains(stdout, forbidden) {
			t.Errorf("foreign subtree leaked %q:\n%s", forbidden, stdout)
		}
	}
}

func TestAliasShow_MissingAliasStillErrors(t *testing.T) {
	testSetup(t)
	seedRawAliases(t, `{}`)
	stdout, _, err := runAliasShow(t, "nope")
	if err == nil || !strings.Contains(err.Error(), `alias "nope" not found`) {
		t.Fatalf("want not-found error, got %v", err)
	}
	if stdout != "" {
		t.Errorf("output on missing alias: %q", stdout)
	}
}
