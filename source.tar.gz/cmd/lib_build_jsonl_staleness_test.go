package cmd

import (
	"os"
	"path/filepath"
	"testing"
	"time"
)

// TestJsonlNeedsExport locks in the cache-staleness fix: an --index build must
// re-export the cached books JSONL from Calibre whenever metadata.db has changed
// since the JSONL was last written. Before the fix, the build reused the JSONL
// whenever it merely existed, so a rebuild after adding/editing/removing books
// silently served the pre-change book set (and federation member republishes
// never propagated their changes).
func TestJsonlNeedsExport(t *testing.T) {
	dir := t.TempDir()
	jsonl := filepath.Join(dir, "books.jsonl")
	calDir := filepath.Join(dir, "lib")
	if err := os.MkdirAll(calDir, 0o755); err != nil {
		t.Fatal(err)
	}
	db := filepath.Join(calDir, "metadata.db")
	base := time.Now()

	// 1. Missing JSONL -> must export.
	if !jsonlNeedsExport(jsonl, calDir) {
		t.Error("missing JSONL should need export")
	}

	// 2. JSONL newer than metadata.db (fresh, just-built state) -> no export.
	writeAt(t, db, base.Add(-time.Minute))
	writeAt(t, jsonl, base)
	if jsonlNeedsExport(jsonl, calDir) {
		t.Error("JSONL newer than metadata.db should NOT need export")
	}

	// 3. metadata.db modified after the JSONL (library changed) -> must export.
	if err := os.Chtimes(db, base.Add(time.Minute), base.Add(time.Minute)); err != nil {
		t.Fatal(err)
	}
	if !jsonlNeedsExport(jsonl, calDir) {
		t.Error("metadata.db newer than JSONL should need export")
	}

	// 4. Equal mtime (coarse FS / same-second add→build→edit cycle) -> must export.
	if err := os.Chtimes(db, base, base); err != nil {
		t.Fatal(err)
	}
	if err := os.Chtimes(jsonl, base, base); err != nil {
		t.Fatal(err)
	}
	if !jsonlNeedsExport(jsonl, calDir) {
		t.Error("equal mtime should be treated as stale and re-export")
	}

	// 5. No metadata.db (externally-supplied JSONL, no Calibre dir) -> keep it.
	if jsonlNeedsExport(jsonl, filepath.Join(dir, "no-such-dir")) {
		t.Error("absent metadata.db should keep the existing JSONL")
	}
}

func writeAt(t *testing.T, path string, mod time.Time) {
	t.Helper()
	if err := os.WriteFile(path, []byte("x"), 0o644); err != nil {
		t.Fatal(err)
	}
	if err := os.Chtimes(path, mod, mod); err != nil {
		t.Fatal(err)
	}
}
