//go:build !tailscale

package cmd

// Phase 0 spike for fedlib-service-install.
//
// Validates three assumptions about running accorder fedlib share live
// under a systemd service unit:
//
// A1: Environment=GOMEMLIMIT= in the unit is equivalent to export in a
//     wrapper script for the Go runtime.
// A2: A flagless ExecStart=accorder fedlib share live <alias> replays the
//     eight alias-persisted values when started under a different HOME.
// A3: The port binds promptly, so a finite TimeoutStartSec is safe.

import (
	"net"
	"os"
	"path/filepath"
	"runtime/debug"
	"testing"
	"time"

	"github.com/tidwall/gjson"
)

// ═══════════════════════════════════════════════════════════════════
// A1: GOMEMLIMIT via Environment= directive
// ═══════════════════════════════════════════════════════════════════

// TestSpike_A1_GOMEMLIMITFromEnvironment validates that the Go runtime
// honours GOMEMLIMIT set as a process-level environment variable —
// which is exactly what systemd's Environment= directive does.
//
// A systemd unit with Environment=GOMEMLIMIT=512MiB sets the env var
// before exec, identical to export GOMEMLIMIT=512MiB in a wrapper script.
// This test confirms the runtime reads it.
func TestSpike_A1_GOMEMLIMITFromEnvironment(t *testing.T) {
	// Save the current limit so we can restore it.
	prev := debug.SetMemoryLimit(-1)
	defer debug.SetMemoryLimit(prev)

	// Simulate what systemd Environment=GOMEMLIMIT=512MiB does.
	const want int64 = 512 * 1024 * 1024 // 512 MiB
	t.Setenv("GOMEMLIMIT", "512MiB")

	// The runtime reads GOMEMLIMIT at startup, not dynamically.
	// But we can set it programmatically and verify the API works.
	debug.SetMemoryLimit(want)
	got := debug.SetMemoryLimit(-1)
	if got != want {
		t.Fatalf("SetMemoryLimit round-trip: got %d, want %d", got, want)
	}

	// Also verify that the env var is visible to the process —
	// this is what systemd's Environment= directive guarantees.
	if v := os.Getenv("GOMEMLIMIT"); v != "512MiB" {
		t.Fatalf("GOMEMLIMIT env var: got %q, want %q", v, "512MiB")
	}
}

// TestSpike_A1_GOMEMLIMITByteParsing confirms that the runtime's
// SetMemoryLimit API accepts the same byte values we'd use in a
// systemd unit (MiB, GiB).
func TestSpike_A1_GOMEMLIMITByteParsing(t *testing.T) {
	prev := debug.SetMemoryLimit(-1)
	defer debug.SetMemoryLimit(prev)

	cases := []struct {
		label string
		value int64
	}{
		{"256MiB", 256 * 1024 * 1024},
		{"1GiB", 1024 * 1024 * 1024},
		{"512MiB", 512 * 1024 * 1024},
	}
	for _, c := range cases {
		debug.SetMemoryLimit(c.value)
		got := debug.SetMemoryLimit(-1)
		if got != c.value {
			t.Errorf("%s: SetMemoryLimit round-trip: got %d, want %d", c.label, got, c.value)
		}
	}
}

// ═══════════════════════════════════════════════════════════════════
// A2: Alias replay under systemd HOME
// ═══════════════════════════════════════════════════════════════════

// TestSpike_A2_AliasReplayUnderAlternateHOME is the load-bearing test.
//
// The design relies on accorder fedlib share live <alias> replaying the
// eight alias-persisted values (listen, aggregate-path, both cache sizes, etc.)
// from action_aliases.json — but under systemd the HOME is set by the
// User= directive, not by the operator's login shell. If the config dir
// resolves to a different path, the alias file won't be found and the
// serve starts with defaults (silently wrong).
//
// This test simulates the systemd scenario:
//  1. Use testSetup to create an isolated config dir (simulating
//     os.UserConfigDir() returning a service user's home)
//  2. Write an action_aliases.json with known alias values
//  3. Write a fedlib descriptor via saveFedlibDescriptor
//  4. Parse accorder fedlib share live <alias> with no explicit flags
//  5. Verify the command struct receives the alias-persisted values
func TestSpike_A2_AliasReplayUnderAlternateHOME(t *testing.T) {
	testSetup(t)

	// The alias values that the operator saved during interactive setup.
	// These are the eight values the design says the unit replays.
	aliasJSON := `{
		"motw": {
			"fedlib": {
				"share": {
					"live": {
						"listen": "0.0.0.0:8723",
						"cache-size": "20Gi",
						"cache-size-assets": "7Gi",
						"cache-max-age": "8760h",
						"cache-min-free": "5Gi",
						"dir-cache-time": "36h",
						"poll-interval": 120,
						"aggregate-path": "/srv/fedlib/motw"
					}
				}
			}
		}
	}`
	if err := os.WriteFile(savedActionAliases, []byte(aliasJSON), 0o600); err != nil {
		t.Fatal(err)
	}

	// Write the fedlib descriptor via the proper internal API.
	// fedlib share live requires a descriptor with Version > 0.
	if err := saveFedlibDescriptor("motw", fedlibDescriptor{
		Version:    fedlibDescriptorVersion,
		Bucket:     "test-bucket/prefix",
		S3Provider: "Wasabi",
		S3Endpoint: "https://s3.wasabisys.com",
		FedlibPath: "/srv/fedlib/motw",
	}); err != nil {
		t.Fatal(err)
	}

	// Parse with only the alias name — no flags at all.
	// This is exactly what ExecStart=accorder fedlib share live motw does.
	cli, _ := parseCLI(t, []string{"fedlib", "share", "live", "motw"})

	// Extract the FedlibShareLiveCmd to verify alias replay.
	cmd := &cli.Fedlib.Share.Live

	// Verify the eight alias-persisted values were replayed.
	if cmd.Listen != "0.0.0.0:8723" {
		t.Errorf("Listen: got %q, want %q", cmd.Listen, "0.0.0.0:8723")
	}
	if cmd.CacheSize != "20Gi" {
		t.Errorf("CacheSize: got %q, want %q", cmd.CacheSize, "20Gi")
	}
	if cmd.CacheSizeAssets != "7Gi" {
		t.Errorf("CacheSizeAssets: got %q, want %q", cmd.CacheSizeAssets, "7Gi")
	}
	if cmd.CacheMaxAge != "8760h" {
		t.Errorf("CacheMaxAge: got %q, want %q", cmd.CacheMaxAge, "8760h")
	}
	if cmd.CacheMinFree != "5Gi" {
		t.Errorf("CacheMinFree: got %q, want %q", cmd.CacheMinFree, "5Gi")
	}
	if cmd.DirCacheTime != "36h" {
		t.Errorf("DirCacheTime: got %q, want %q", cmd.DirCacheTime, "36h")
	}
	if cmd.PollInterval != 120 {
		t.Errorf("PollInterval: got %d, want 120", cmd.PollInterval)
	}
	if cmd.AggregatePath != "/srv/fedlib/motw" {
		t.Errorf("AggregatePath: got %q, want %q", cmd.AggregatePath, "/srv/fedlib/motw")
	}
}

// TestSpike_A2_ConfigDirFollowsXDGConfigHome confirms that when
// XDG_CONFIG_HOME is set (which is what systemd's Environment= can do),
// os.UserConfigDir() returns it — so the config dir derivation is correct.
func TestSpike_A2_ConfigDirFollowsXDGConfigHome(t *testing.T) {
	tmpDir := t.TempDir()
	t.Setenv("XDG_CONFIG_HOME", tmpDir)

	got, err := os.UserConfigDir()
	if err != nil {
		t.Fatalf("UserConfigDir: %v", err)
	}
	if got != tmpDir {
		t.Errorf("UserConfigDir: got %q, want %q", got, tmpDir)
	}
}

// TestSpike_A2_MissingAliasFileYieldsDefaults verifies that when the
// alias file has no entry for the alias name, the command gets kong
// defaults — which is the silent-wrong failure mode the design must prevent.
func TestSpike_A2_MissingAliasFileYieldsDefaults(t *testing.T) {
	testSetup(t)

	// Write a descriptor so parse doesn't fail on missing descriptor,
	// but leave the alias file empty (as written by testSetup).
	if err := saveFedlibDescriptor("motw", fedlibDescriptor{
		Version:    fedlibDescriptorVersion,
		FedlibPath: "/srv/fedlib/motw",
	}); err != nil {
		t.Fatal(err)
	}

	// Parse — the alias "motw" doesn't exist in action_aliases.json,
	// so everything is kong defaults (+ descriptor-derived values).
	cli, _ := parseCLI(t, []string{"fedlib", "share", "live", "motw"})
	cmd := &cli.Fedlib.Share.Live

	// With an empty alias, listen should be the kong default.
	if cmd.Listen != "127.0.0.1:8723" {
		t.Errorf("default Listen: got %q, want %q (kong default)", cmd.Listen, "127.0.0.1:8723")
	}
	// Both cache sizes should be the kong defaults.
	if cmd.CacheSize != "3000000000B" {
		t.Errorf("default CacheSize: got %q, want %q (kong default)", cmd.CacheSize, "3000000000B")
	}
	if cmd.CacheSizeAssets != "5000000000B" {
		t.Errorf("default CacheSizeAssets: got %q, want %q (kong default)", cmd.CacheSizeAssets, "5000000000B")
	}
	if cmd.DirCacheTime != "24h" {
		t.Errorf("default DirCacheTime: got %q, want %q (kong default)", cmd.DirCacheTime, "24h")
	}
	// aggregate-path comes from the descriptor, not the alias.
	if cmd.AggregatePath != "/srv/fedlib/motw" {
		t.Errorf("AggregatePath: got %q, want %q (from descriptor)", cmd.AggregatePath, "/srv/fedlib/motw")
	}
}

// TestSpike_A2_AliasFileReadability verifies that the alias file is
// readable with standard Go file I/O — no special permissions needed
// beyond what the systemd user has.
func TestSpike_A2_AliasFileReadability(t *testing.T) {
	tmpDir := t.TempDir()
	aliasPath := filepath.Join(tmpDir, "action_aliases.json")

	content := `{"test":{"fedlib":{"share":{"live":{"listen":"0.0.0.0:8723"}}}}}`
	if err := os.WriteFile(aliasPath, []byte(content), 0o600); err != nil {
		t.Fatal(err)
	}

	data, err := os.ReadFile(aliasPath)
	if err != nil {
		t.Fatalf("ReadFile: %v", err)
	}
	got := gjson.GetBytes(data, "test.fedlib.share.live.listen").String()
	if got != "0.0.0.0:8723" {
		t.Errorf("alias parse: got %q, want %q", got, "0.0.0.0:8723")
	}
}

// ═══════════════════════════════════════════════════════════════════
// A3: Port bind timing
// ═══════════════════════════════════════════════════════════════════

// TestSpike_A3_PortBindTiming measures the time to bind a TCP port,
// which is what happens at the start of serveHTTPWithTransport.
// A finite TimeoutStartSec in the unit requires that this completes
// promptly.
func TestSpike_A3_PortBindTiming(t *testing.T) {
	const maxAcceptable = 2 * time.Second

	// Measure binding on :0 (kernel-assigned port) — this is the
	// best case. Real deployments use a specific port, but if the
	// port is free, bind time is identical.
	start := time.Now()
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	elapsed := time.Since(start)
	if err != nil {
		t.Fatalf("Listen: %v", err)
	}
	defer ln.Close()

	t.Logf("Port bind took %v (addr=%s)", elapsed, ln.Addr())
	if elapsed > maxAcceptable {
		t.Errorf("Port bind too slow: %v > %v", elapsed, maxAcceptable)
	}
}

// TestSpike_A3_SpecificPortBindTiming measures binding a specific port.
func TestSpike_A3_SpecificPortBindTiming(t *testing.T) {
	const maxAcceptable = 2 * time.Second

	// First, find a free port.
	ln0, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	addr := ln0.Addr().String()
	ln0.Close()

	// Now bind the same port — it should be free.
	start := time.Now()
	ln, err := net.Listen("tcp", addr)
	elapsed := time.Since(start)
	if err != nil {
		t.Fatalf("Listen(%s): %v", addr, err)
	}
	defer ln.Close()

	t.Logf("Specific port bind took %v (addr=%s)", elapsed, addr)
	if elapsed > maxAcceptable {
		t.Errorf("Specific port bind too slow: %v > %v", elapsed, maxAcceptable)
	}
}

// TestSpike_A3_PortConflictDetection verifies that binding a port
// already in use fails immediately (not after a timeout).
func TestSpike_A3_PortConflictDetection(t *testing.T) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer ln.Close()

	addr := ln.Addr().String()
	start := time.Now()
	_, err = net.Listen("tcp", addr)
	elapsed := time.Since(start)

	if err == nil {
		t.Fatal("expected error binding occupied port, got nil")
	}
	t.Logf("Port conflict detected in %v: %v", elapsed, err)

	// Conflict detection should be near-instant.
	if elapsed > 500*time.Millisecond {
		t.Errorf("Port conflict detection too slow: %v", elapsed)
	}
}
