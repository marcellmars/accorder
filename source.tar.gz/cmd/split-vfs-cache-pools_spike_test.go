package cmd

import (
	"accorder/pkg/calibre"
	"accorder/pkg/rclonexfer"
	"crypto/sha256"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"net/http/httputil"
	"os"
	"path/filepath"
	"slices"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/rclone/rclone/fs/config"
	"github.com/rclone/rclone/librclone/librclone"
)

// TestAssetsTreeIsOwnedAndApplyPruneRetainsIt promotes the destructive Phase 0
// counterexample into the post-feature filesystem-state invariant.
func TestAssetsTreeIsOwnedAndApplyPruneRetainsIt(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "motw")

	const booksRemote = "accorder-serve-motw"
	const assetsRemote = "accorder-serve-motw-assets"
	seedTreePair(t, booksRemote)
	seedTreePair(t, assetsRemote)
	ledgerServeStart(t, booksRemote, "scratch-bucket")
	ledgerServeStart(t, assetsRemote, "scratch-bucket")
	activateReclaim(t)

	scan, err := scanCacheTrees(defaultSizeBudget)
	if err != nil {
		t.Fatal(err)
	}
	if got := findTree(t, scan, booksRemote).Class; got != treeOwned {
		t.Fatalf("books class=%s, want owned", got)
	}
	assets := findTree(t, scan, assetsRemote)
	if assets.Class != treeOwned {
		t.Fatalf("assets class=%s candidates=%v, want owned", assets.Class, assets.Candidates)
	}
	if !slices.Contains(assets.Candidates, "motw") {
		t.Fatalf("assets candidates=%v, want base alias motw", assets.Candidates)
	}

	_, ctx := parseCLI(t, []string{"config", "prune", "--apply-cache-trees"})
	var runErr error
	out := captureStdout(t, func() { runErr = ctx.Run() })
	if runErr != nil {
		t.Fatalf("config prune: %v\n%s", runErr, out)
	}
	if !treeExists("vfs", booksRemote) || !treeExists("vfsMeta", booksRemote) {
		t.Fatalf("owned books tree was changed by prune:\n%s", out)
	}
	if !treeExists("vfs", assetsRemote) || !treeExists("vfsMeta", assetsRemote) {
		t.Fatalf("owned assets tree was changed by prune:\n%s", out)
	}
	if strings.Contains(out, "Reclaimed vfs/"+assetsRemote) {
		t.Fatalf("prune reported assets-tree reclamation:\n%s", out)
	}

	t.Logf("apply prune retained books=%s and assets=%s", booksRemote, assetsRemote)
}

func TestScratchPruneRetainsBothRealVFSTreesLiveAndStopped(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "scratch")
	activateReclaim(t)
	backingParent := t.TempDir()
	const remoteRoot = "scratch-bucket"
	backing := filepath.Join(backingParent, remoteRoot)
	for rel, body := range map[string]string{
		"member/Author/Title/book.epub": "BOOK-SCRATCH-PAYLOAD",
		"member/Author/Title/cover.jpg": "COVER-SCRATCH-PAYLOAD",
	} {
		path := filepath.Join(backing, filepath.FromSlash(rel))
		if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(path, []byte(body), 0o644); err != nil {
			t.Fatal(err)
		}
	}
	t.Chdir(backingParent)

	names := liveCacheRemoteNames("scratch")
	remotes := []string{names.Books, names.Assets}
	previousCacheDir := config.GetCacheDir()
	previousConfigPath := config.GetConfigPath()
	if err := config.SetConfigPath(filepath.Join(t.TempDir(), "rclone.conf")); err != nil {
		t.Fatal(err)
	}
	if err := rclonexfer.SetCacheDir(accorderCacheDir()); err != nil {
		t.Fatal(err)
	}
	rclonexfer.Initialize()
	var serveIDs []string
	mutationRelease, err := serveCacheStartupMany("scratch prune", []cacheTreeIdentity{
		{RemoteName: names.Books, RemoteRoot: remoteRoot},
		{RemoteName: names.Assets, RemoteRoot: remoteRoot},
	})
	if err != nil {
		rclonexfer.Finalize()
		t.Fatal(err)
	}
	locksReleased := false
	stopServes := func() {
		for i := len(serveIDs) - 1; i >= 0; i-- {
			if err := rclonexfer.StopServe(serveIDs[i]); err != nil {
				t.Logf("StopServe(%s): %v", serveIDs[i], err)
			}
		}
		serveIDs = nil
		if !locksReleased {
			mutationRelease()
			locksReleased = true
		}
	}
	t.Cleanup(func() {
		stopServes()
		for i := len(remotes) - 1; i >= 0; i-- {
			_ = rclonexfer.DeleteRemote(remotes[i])
		}
		rclonexfer.Finalize()
		_ = rclonexfer.SetCacheDir(previousCacheDir)
		_ = config.SetConfigPath(previousConfigPath)
	})

	for _, remote := range remotes {
		payload, _ := json.Marshal(map[string]any{
			"name": remote, "type": "local", "parameters": map[string]string{},
		})
		out, status := librclone.RPC("config/create", string(payload))
		if status != http.StatusOK {
			t.Fatalf("config/create %s: status=%d out=%s", remote, status, out)
		}
	}
	start := func(remote string) string {
		t.Helper()
		id, addr, err := rclonexfer.ServeHTTPWithVFS(remote+":"+remoteRoot, "127.0.0.1:0", rclonexfer.VFSOptions{
			CacheMode: "full", CacheMaxSize: "1Mi", CacheMaxAge: "1h",
			CacheMinFreeSpace: "2Gi", ReadOnly: true,
		})
		if err != nil {
			t.Fatal(err)
		}
		serveIDs = append(serveIDs, id)
		return "http://" + addr
	}
	booksURL := start(names.Books)
	assetsURL := start(names.Assets)
	fetch := func(baseURL, rel, want string) {
		t.Helper()
		resp, err := (&http.Client{Timeout: 10 * time.Second}).Get(baseURL + "/" + rel)
		if err != nil {
			t.Fatal(err)
		}
		body, readErr := io.ReadAll(resp.Body)
		_ = resp.Body.Close()
		if readErr != nil || resp.StatusCode != http.StatusOK || string(body) != want {
			t.Fatalf("GET %s: status=%d body=%q read=%v", rel, resp.StatusCode, body, readErr)
		}
	}
	fetch(booksURL, "member/Author/Title/book.epub", "BOOK-SCRATCH-PAYLOAD")
	fetch(assetsURL, "member/Author/Title/cover.jpg", "COVER-SCRATCH-PAYLOAD")
	waitForTreeFile(t, filepath.Join(accorderCacheDir(), "vfs", names.Books), "book.epub")
	waitForTreeFile(t, filepath.Join(accorderCacheDir(), "vfs", names.Assets), "cover.jpg")

	runPrune := func(stage string) {
		t.Helper()
		_, ctx := parseCLI(t, []string{"config", "prune", "--apply-cache-trees"})
		var runErr error
		out := captureStdout(t, func() { runErr = ctx.Run() })
		if runErr != nil {
			t.Fatalf("%s prune: %v\n%s", stage, runErr, out)
		}
		if strings.Contains(out, "Reclaimed vfs/"+names.Books) || strings.Contains(out, "Reclaimed vfs/"+names.Assets) {
			t.Fatalf("%s prune offered or reclaimed a live identity:\n%s", stage, out)
		}
	}
	liveData := splitCacheDataDigests(t, names)
	runPrune("live")
	if after := splitCacheDataDigests(t, names); !equalSplitDigests(liveData, after) {
		t.Fatalf("live prune changed cached payloads: before=%v after=%v", liveData, after)
	}

	stopServes()
	stoppedTrees := splitCacheTreeDigests(t, names)
	runPrune("stopped")
	if after := splitCacheTreeDigests(t, names); !equalSplitDigests(stoppedTrees, after) {
		t.Fatalf("stopped prune changed cache trees: before=%v after=%v", stoppedTrees, after)
	}
	t.Log("unscoped apply retained both real VFS tree pairs while live and after shutdown")
}

func waitForTreeFile(t *testing.T, root, base string) {
	t.Helper()
	deadline := time.Now().Add(5 * time.Second)
	for {
		found := false
		_ = filepath.WalkDir(root, func(_ string, entry os.DirEntry, err error) error {
			if err == nil && !entry.IsDir() && entry.Name() == base {
				found = true
				return filepath.SkipAll
			}
			return nil
		})
		if found {
			return
		}
		if time.Now().After(deadline) {
			t.Fatalf("%s did not appear below %s", base, root)
		}
		time.Sleep(25 * time.Millisecond)
	}
}

type splitDigests map[string]map[string][32]byte

func splitCacheDataDigests(t *testing.T, names aggregateCacheRemoteNames) splitDigests {
	t.Helper()
	return splitCacheDigests(t, names, []string{"vfs"})
}

func splitCacheTreeDigests(t *testing.T, names aggregateCacheRemoteNames) splitDigests {
	t.Helper()
	return splitCacheDigests(t, names, []string{"vfs", "vfsMeta"})
}

func splitCacheDigests(t *testing.T, names aggregateCacheRemoteNames, halves []string) splitDigests {
	t.Helper()
	out := splitDigests{}
	for _, remote := range []string{names.Books, names.Assets} {
		out[remote] = map[string][32]byte{}
		for _, half := range halves {
			root := filepath.Join(accorderCacheDir(), half, remote)
			err := filepath.WalkDir(root, func(path string, entry os.DirEntry, err error) error {
				if err != nil {
					return err
				}
				if !entry.Type().IsRegular() {
					return nil
				}
				data, err := os.ReadFile(path)
				if err != nil {
					return err
				}
				rel, err := filepath.Rel(root, path)
				if err != nil {
					return err
				}
				out[remote][half+"/"+filepath.ToSlash(rel)] = sha256.Sum256(data)
				return nil
			})
			if err != nil {
				t.Fatal(err)
			}
		}
	}
	return out
}

func equalSplitDigests(left, right splitDigests) bool {
	if len(left) != len(right) {
		return false
	}
	for remote, leftFiles := range left {
		rightFiles, ok := right[remote]
		if !ok || len(leftFiles) != len(rightFiles) {
			return false
		}
		for path, digest := range leftFiles {
			if rightFiles[path] != digest {
				return false
			}
		}
	}
	return true
}

// TestAggregateRouteSplitsAssetsAndBooks instruments both VFS backends around
// the production aggregate router.
func TestAggregateRouteSplitsAssetsAndBooks(t *testing.T) {
	type recorder struct {
		mu    sync.Mutex
		paths []string
	}
	newBackend := func(rec *recorder) *httptest.Server {
		return httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			rec.mu.Lock()
			rec.paths = append(rec.paths, r.URL.Path)
			rec.mu.Unlock()
			w.WriteHeader(http.StatusOK)
		}))
	}
	var books, assets recorder
	booksBackend := newBackend(&books)
	defer booksBackend.Close()
	assetsBackend := newBackend(&assets)
	defer assetsBackend.Close()

	state := &serveState{current: &singleIndex{libraries: map[string]calibre.LibraryMeta{
		"member-id": {Prefix: "member"},
	}}}
	meter := &sessionMeter{
		window:      time.Hour,
		granularity: time.Minute,
		maxSessions: 100,
		maxDistinct: 100,
	}
	mux := http.NewServeMux()
	registerAggregateRoutes(
		mux,
		state,
		aggregateVFSAddresses{
			Books:  strings.TrimPrefix(booksBackend.URL, "http://"),
			Assets: strings.TrimPrefix(assetsBackend.URL, "http://"),
		},
		meter,
		nil,
		nil,
		"public",
		"",
		nil,
		false,
	)

	paths := []string{
		"/files/member/cover.jpg",
		"/files/member/Author/Title/cover.jpg",
		"/files/member/static",
		"/files/member/static/",
		"/files/member/static/app.js",
		"/files/member/Author/Title/book.epub",
		"/files/member/Author/Title/image.jpg",
		"/files/member/Author/Title/not-cover.jpg",
	}
	for _, path := range paths {
		rec := httptest.NewRecorder()
		mux.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, path, nil))
		if rec.Code != http.StatusOK {
			t.Fatalf("GET %s: status=%d body=%s", path, rec.Code, rec.Body.String())
		}
	}

	books.mu.Lock()
	booksPaths := append([]string(nil), books.paths...)
	books.mu.Unlock()
	assets.mu.Lock()
	assetsPaths := append([]string(nil), assets.paths...)
	assets.mu.Unlock()
	if want := []string{
		"/member/Author/Title/book.epub",
		"/member/Author/Title/image.jpg",
		"/member/Author/Title/not-cover.jpg",
	}; !slices.Equal(booksPaths, want) {
		t.Fatalf("books backend paths=%v, want %v", booksPaths, want)
	}
	if want := []string{
		"/member/cover.jpg",
		"/member/Author/Title/cover.jpg",
		"/member/static",
		"/member/static",
		"/member/static/app.js",
	}; !slices.Equal(assetsPaths, want) {
		t.Fatalf("assets backend paths=%v, want %v", assetsPaths, want)
	}
	beforeBooks, beforeAssets := len(booksPaths), len(assetsPaths)
	for _, invalid := range []string{
		"/files/member/../other/cover.jpg",
		"/files/member/%2e%2e/other/cover.jpg",
	} {
		rec := httptest.NewRecorder()
		mux.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, invalid, nil))
		if rec.Code == http.StatusOK {
			t.Errorf("traversal path %s reached a backend", invalid)
		}
	}
	books.mu.Lock()
	if len(books.paths) != beforeBooks {
		t.Errorf("traversal reached books backend: %v", books.paths[beforeBooks:])
	}
	books.mu.Unlock()
	assets.mu.Lock()
	if len(assets.paths) != beforeAssets {
		t.Errorf("traversal reached assets backend: %v", assets.paths[beforeAssets:])
	}
	assets.mu.Unlock()

	t.Logf("router split books=%v assets=%v", booksPaths, assetsPaths)
}

func TestAggregateMemberPrefixPrefersLongestBoundaryMatch(t *testing.T) {
	libraries := map[string]calibre.LibraryMeta{
		"outer": {Prefix: "org"},
		"inner": {Prefix: "org/member"},
	}
	for _, path := range []string{
		"org/member/static/app.js",
		"org/member/Author/Title/book.epub",
		"org/member",
	} {
		if got := aggregateMemberPrefix(libraries, path); got != "org/member" {
			t.Fatalf("aggregateMemberPrefix(%q)=%q, want longest match org/member", path, got)
		}
	}
	if got := aggregateMemberPrefix(libraries, "organization/book.epub"); got != "" {
		t.Fatalf("boundary-unsafe prefix match = %q, want none", got)
	}
}

func TestAggregateRouteOverlappingPrefixStaticAlwaysUsesAssets(t *testing.T) {
	var booksRequests, assetsRequests int
	books := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		booksRequests++
		w.WriteHeader(http.StatusOK)
	}))
	defer books.Close()
	assets := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		assetsRequests++
		w.WriteHeader(http.StatusOK)
	}))
	defer assets.Close()

	state := &serveState{current: &singleIndex{libraries: map[string]calibre.LibraryMeta{
		"outer": {Prefix: "org"},
		"inner": {Prefix: "org/member"},
	}}}
	mux := http.NewServeMux()
	registerAggregateRoutes(mux, state, aggregateVFSAddresses{
		Books:  strings.TrimPrefix(books.URL, "http://"),
		Assets: strings.TrimPrefix(assets.URL, "http://"),
	}, &sessionMeter{
		window: time.Hour, granularity: time.Minute, maxSessions: 100, maxDistinct: 100,
	}, nil, nil, "public", "", nil, false)

	for range 32 {
		rec := httptest.NewRecorder()
		mux.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/files/org/member/static/app.js", nil))
		if rec.Code != http.StatusOK {
			t.Fatalf("status=%d, want 200", rec.Code)
		}
	}
	if booksRequests != 0 || assetsRequests != 32 {
		t.Fatalf("overlapping-prefix requests: books=%d assets=%d, want assets only", booksRequests, assetsRequests)
	}
}

func TestAggregateRouteMissingSelectedBackendFailsClosed(t *testing.T) {
	backend := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
	}))
	defer backend.Close()
	addr := strings.TrimPrefix(backend.URL, "http://")
	state := &serveState{current: &singleIndex{libraries: map[string]calibre.LibraryMeta{
		"member-id": {Prefix: "member"},
	}}}
	newMux := func(addrs aggregateVFSAddresses) *http.ServeMux {
		mux := http.NewServeMux()
		registerAggregateRoutes(mux, state, addrs, &sessionMeter{
			window: time.Hour, granularity: time.Minute, maxSessions: 10, maxDistinct: 10,
		}, nil, nil, "public", "", nil, false)
		return mux
	}
	for _, tc := range []struct {
		name string
		mux  *http.ServeMux
		path string
	}{
		{name: "assets missing", mux: newMux(aggregateVFSAddresses{Books: addr}), path: "/files/member/cover.jpg"},
		{name: "books missing", mux: newMux(aggregateVFSAddresses{Assets: addr}), path: "/files/member/book.epub"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			rec := httptest.NewRecorder()
			tc.mux.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, tc.path, nil))
			if rec.Code != http.StatusNotFound {
				t.Fatalf("status=%d, want 404", rec.Code)
			}
		})
	}
}

func TestAggregateRoutePeerPrecedesLocalPoolSelection(t *testing.T) {
	var peerRequests, localRequests int
	peer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		peerRequests++
		w.WriteHeader(http.StatusOK)
	}))
	defer peer.Close()
	local := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		localRequests++
		w.WriteHeader(http.StatusOK)
	}))
	defer local.Close()
	table := &peerEndpointTable{
		registryPath: filepath.Join(t.TempDir(), "absent-members.json"),
		loaded:       true,
		proxies: map[string]*httputil.ReverseProxy{
			"member": newPeerReverseProxy("member", peer.URL, "grant"),
		},
	}
	state := &serveState{current: &singleIndex{libraries: map[string]calibre.LibraryMeta{
		"member-id": {Prefix: "member"},
	}}}
	mux := http.NewServeMux()
	localAddr := strings.TrimPrefix(local.URL, "http://")
	registerAggregateRoutes(mux, state, aggregateVFSAddresses{Books: localAddr, Assets: localAddr}, &sessionMeter{
		window: time.Hour, granularity: time.Minute, maxSessions: 10, maxDistinct: 10,
	}, nil, nil, "public", "", table, false)

	rec := httptest.NewRecorder()
	mux.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/files/member/cover.jpg", nil))
	if rec.Code != http.StatusOK || peerRequests != 1 || localRequests != 0 {
		t.Fatalf("status=%d peer=%d local=%d, want peer-only dispatch", rec.Code, peerRequests, localRequests)
	}
}

func TestAggregateRouteMultiSegmentPeerUsesFullPrefix(t *testing.T) {
	var peerRequests, localRequests int
	peer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		peerRequests++
		w.WriteHeader(http.StatusOK)
	}))
	defer peer.Close()
	local := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		localRequests++
		w.WriteHeader(http.StatusOK)
	}))
	defer local.Close()
	table := &peerEndpointTable{
		registryPath: filepath.Join(t.TempDir(), "absent-members.json"),
		loaded:       true,
		proxies: map[string]*httputil.ReverseProxy{
			"org/member": newPeerReverseProxy("org/member", peer.URL, "grant"),
		},
	}
	state := &serveState{current: &singleIndex{libraries: map[string]calibre.LibraryMeta{
		"member-id": {Prefix: "org/member"},
	}}}
	mux := http.NewServeMux()
	localAddr := strings.TrimPrefix(local.URL, "http://")
	registerAggregateRoutes(mux, state, aggregateVFSAddresses{Books: localAddr, Assets: localAddr}, &sessionMeter{
		window: time.Hour, granularity: time.Minute, maxSessions: 10, maxDistinct: 10,
	}, nil, nil, "public", "", table, false)

	rec := httptest.NewRecorder()
	mux.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/files/org/member/cover.jpg", nil))
	if rec.Code != http.StatusOK || peerRequests != 1 || localRequests != 0 {
		t.Fatalf("status=%d peer=%d local=%d, want full-prefix peer dispatch", rec.Code, peerRequests, localRequests)
	}
}

// TestRcloneSetupOwnsCleanupBeforeSetLogLevelFailure pins the partial-start
// lifecycle ordering that the pre-feature spike found missing.
func TestRcloneSetupOwnsCleanupBeforeSetLogLevelFailure(t *testing.T) {
	source, err := os.ReadFile("aggregateServeSetup.go")
	if err != nil {
		t.Fatal(err)
	}
	body := string(source)
	start := strings.Index(body, "func setupAggregateServeRclone(")
	if start < 0 {
		t.Fatal("setupAggregateServeRclone not found")
	}
	body = body[start:]
	initialize := strings.Index(body, "rclonexfer.Initialize()")
	setLogLevel := strings.Index(body, "if err := rclonexfer.SetLogLevel(p.RcloneLogLevel); err != nil {")
	cleanupInstalled := strings.Index(body, "cleanupAll := func()")
	if initialize < 0 || setLogLevel < 0 || cleanupInstalled < 0 {
		t.Fatalf("could not locate lifecycle landmarks: initialize=%d setLog=%d cleanup=%d",
			initialize, setLogLevel, cleanupInstalled)
	}
	returnAfterLogFailure := strings.Index(body[setLogLevel:], "return nil, fmt.Errorf")
	if returnAfterLogFailure < 0 {
		t.Fatal("SetLogLevel failure return not found")
	}
	returnAfterLogFailure += setLogLevel
	if !(initialize < cleanupInstalled && cleanupInstalled < setLogLevel && setLogLevel < returnAfterLogFailure) {
		t.Fatalf("unexpected lifecycle order: initialize=%d setLog=%d return=%d cleanup=%d",
			initialize, setLogLevel, returnAfterLogFailure, cleanupInstalled)
	}
	branchEnd := strings.Index(body[setLogLevel:], "return nil, fmt.Errorf")
	branch := body[setLogLevel : setLogLevel+branchEnd]
	if !strings.Contains(branch, "cleanupAll()") {
		t.Fatal("SetLogLevel failure branch does not call the installed cleanup owner")
	}

	t.Log("invalid SetLogLevel is owned by cleanup installed immediately after Initialize")
}

func TestRcloneSetupRejectsCacheIdentityCollisionBeforeSideEffects(t *testing.T) {
	testSetup(t)
	seedAliasNames(t, "motw", "motw-assets")
	names := liveCacheRemoteNames("motw")
	resources, err := setupAggregateServeRclone(AggregateServeParams{
		CommandName: "collision test", ActionAlias: "motw",
		RemoteName: names.Books, AssetsRemoteName: names.Assets,
	})
	if err == nil || !strings.Contains(err.Error(), "collides") {
		if resources != nil && resources.Cleanup != nil {
			resources.Cleanup()
		}
		t.Fatalf("setup error=%v, want collision refusal", err)
	}
	if resources != nil {
		t.Fatal("collision returned owned resources")
	}
	if _, statErr := os.Stat(accorderCacheDir()); !os.IsNotExist(statErr) {
		t.Fatalf("collision created cache state before admission: %v", statErr)
	}
	if _, statErr := os.Stat(identityLedgerPath()); !os.IsNotExist(statErr) {
		t.Fatalf("collision wrote the identity ledger before admission: %v", statErr)
	}
}
