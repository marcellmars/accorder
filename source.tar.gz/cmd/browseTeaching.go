package cmd

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"strings"

	"github.com/tidwall/gjson"
	"github.com/tidwall/sjson"
)

func teachingKey(sourceUUID, endpoint string) string {
	if sourceUUID != "" {
		return "uuid:" + sourceUUID
	}
	if endpoint == "" {
		return ""
	}
	sum := sha256.Sum256([]byte(endpoint))
	return "ep:" + hex.EncodeToString(sum[:])[:16]
}

func alreadyTaught(cfg []byte, alias, sourceUUID, endpoint string) (taught bool, staleKey string) {
	base := alias + ".taught."
	if k := teachingKey(sourceUUID, ""); k != "" {
		if gjson.GetBytes(cfg, base+k).Bool() {
			return true, ""
		}

		if fk := teachingKey("", endpoint); fk != "" && gjson.GetBytes(cfg, base+fk).Bool() {
			return true, fk
		}
		return false, ""
	}
	if k := teachingKey("", endpoint); k != "" {
		return gjson.GetBytes(cfg, base+k).Bool(), ""
	}
	return false, ""
}

func writeTaughtMarker(alias, sourceUUID, endpoint, staleKey string) error {
	key := teachingKey(sourceUUID, endpoint)
	if key == "" {
		return nil
	}
	// ca-111: this RMW bypassed the writer survey because it calls the
	// try* variants directly — every action_aliases.json read-modify-write
	// takes the alias-config lock (review finding).
	release, err := lockAliasConfig()
	if err != nil {
		return err
	}
	defer release()
	cfg, err := tryLoadActionAliases()
	if err != nil {
		return fmt.Errorf("load action aliases: %w", err)
	}
	base := alias + ".taught."
	cfg, err = sjson.SetBytes(cfg, base+key, true)
	if err != nil {
		return fmt.Errorf("set teaching marker: %w", err)
	}
	if staleKey != "" && staleKey != key {

		if migrated, derr := sjson.DeleteBytes(cfg, base+staleKey); derr == nil {
			cfg = migrated
		}
	}

	if err := trySaveActionAliases(cfg); err != nil {
		return fmt.Errorf("write teaching marker: %w", err)
	}
	return nil
}

func emitBrowseTeaching(alias, sourceUUID, endpoint, savedSource string, out io.Writer) (emitted bool, err error) {
	cfg, err := tryLoadActionAliases()
	if err != nil {

		return false, fmt.Errorf("load action aliases: %w", err)
	}
	taught, staleKey := alreadyTaught(cfg, alias, sourceUUID, endpoint)
	if taught {
		if staleKey != "" {

			return false, writeTaughtMarker(alias, sourceUUID, endpoint, staleKey)
		}
		return false, nil
	}

	fmt.Fprintln(out)
	fmt.Fprintln(out, "Their library is saved on your side:")
	if savedSource != "" {
		fmt.Fprintf(out, "  --from %s   your name for their library — change it any time,\n", savedSource)
		fmt.Fprintf(out, "  %s   omit it once saved (see 'lib index list')\n", strings.Repeat(" ", len("--from "+savedSource)))
	}
	fmt.Fprintf(out, "  %s   your action alias — any name works; if omitted,\n", alias)
	fmt.Fprintf(out, "  %s   the run uses 'default'\n", strings.Repeat(" ", len(alias)))
	fmt.Fprintln(out)
	fmt.Fprintf(out, "Next time:  accorder lib browse %s\n", alias)
	fmt.Fprintln(out)

	return true, writeTaughtMarker(alias, sourceUUID, endpoint, staleKey)
}
