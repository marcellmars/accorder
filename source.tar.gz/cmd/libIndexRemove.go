package cmd

type LibIndexRemoveCmd struct {
	Name string `arg:"" help:"Source name to remove."`
}

func (c *LibIndexRemoveCmd) Run() error {
	return registryDelete(c.Name)
}
