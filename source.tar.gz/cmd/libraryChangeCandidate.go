package cmd

import (
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"

	"accorder/pkg/calibre"
	"accorder/pkg/libraryflow"
	"accorder/pkg/torshare"
)

const (
	localChangeCandidateVersion = 1
	localChangeCandidatePath    = ".accorder/change-candidate.json"
)

// localChangeCandidate is private evidence produced by lib build and consumed
// by lib publish. Paths and stat facts deliberately never enter the remote
// generation-change manifest.
type localChangeCandidate struct {
	Evidence                *sourceEvidence            `json:"source_evidence,omitempty"`
	LegacyDigest            string                     `json:"legacy_digest,omitempty"`
	Version                 int                        `json:"version"`
	LibraryUUID             string                     `json:"library_uuid"`
	Scope                   string                     `json:"scope"`
	Reason                  string                     `json:"reason,omitempty"`
	FromGeneration          string                     `json:"from_generation,omitempty"`
	FromLiveCount           *uint32                    `json:"from_live_count,omitempty"`
	FromCatalogChecksum     string                     `json:"from_catalog_checksum,omitempty"`
	TargetSourceFingerprint string                     `json:"target_source_fingerprint"`
	ToLiveCount             uint32                     `json:"to_live_count"`
	ToCatalogChecksum       string                     `json:"to_catalog_checksum"`
	Changes                 []calibre.GenerationChange `json:"changes,omitempty"`
	ForcePaths              []string                   `json:"force_paths,omitempty"`
	CompleteOverwrite       bool                       `json:"complete_overwrite"`
	ContentLedgerVersion    int                        `json:"content_ledger_version"`
	ContentLedger           []libraryflow.Object       `json:"content_ledger"`
	IndexArtifact           libraryflow.Object         `json:"index_artifact"`
}

func localChangeCandidateFile(root string) string {
	return existingEvidencePath(legacyChangeCandidateFile(root))
}

func legacyChangeCandidateFile(root string) string {
	return filepath.Join(root, filepath.FromSlash(localChangeCandidatePath))
}

func readLocalGenerationHex(root string) (string, error) {
	raw, err := os.ReadFile(filepath.Join(root, libraryflow.GenerationPath))
	if err != nil {
		return "", err
	}
	if _, _, err := torshare.DecodeGeneration(raw); err != nil {
		return "", err
	}
	return hex.EncodeToString(raw), nil
}

func loadLocalChangeCandidate(root string) (*localChangeCandidate, error) {
	var candidate localChangeCandidate
	if err := readJSONFile(localChangeCandidateFile(root), &candidate); err != nil {
		return nil, err
	}
	if localChangeCandidateFile(root) == evidenceStatePath(legacyChangeCandidateFile(root)) && candidate.Version != sourceEvidenceVersion {
		return nil, errors.New("new build checkpoint contains an incompatible version; retained for inspection")
	}
	if err := candidate.validate(); err != nil {
		return nil, err
	}
	if candidate.Version == sourceEvidenceVersion {
		if err := checkLegacyEvidence(legacyChangeCandidateFile(root), candidate.LegacyDigest); err != nil {
			return nil, err
		}
	}
	return &candidate, nil
}

func saveLocalChangeCandidate(root string, candidate localChangeCandidate) error {
	path := legacyChangeCandidateFile(root)
	if candidate.ContentLedgerVersion == sourceEvidenceVersion {
		candidate.Version = sourceEvidenceVersion
		var err error
		candidate.LegacyDigest, err = legacyEvidenceDigest(path)
		if err != nil {
			return err
		}
		path = evidenceStatePath(path)
	} else {
		candidate.Version = localChangeCandidateVersion
	}
	if err := candidate.validate(); err != nil {
		return err
	}
	return writeJSONAtomic(path, candidate)
}

// loadReusableBuildCandidate returns a candidate only when it belongs to this
// library and still names the exact index artifact on disk. The candidate is
// never publication authority here: it is a local checkpoint that lets a
// repeated build reuse content hashes and retain its cumulative transition.
func loadReusableBuildCandidate(root, libraryUUID, indexPath string) *localChangeCandidate {
	candidate, err := loadLocalChangeCandidate(root)
	if err != nil || candidate.LibraryUUID != libraryUUID {
		return nil
	}
	indexRel := indexSiblingRel(root, indexPath, ".zst")
	if indexRel == "" || candidate.IndexArtifact.Path != indexRel {
		return nil
	}
	if localIndexArtifactMatches(root, candidate.IndexArtifact) {
		return candidate
	}
	return nil
}

func localIndexArtifactMatches(root string, artifact libraryflow.Object) bool {
	path := filepath.Join(root, filepath.FromSlash(artifact.Path))
	info, err := os.Stat(path)
	if err != nil || info.IsDir() || info.Size() != artifact.Size {
		return false
	}
	current := libraryflow.NewLocalObjectAt(artifact.Path, path, info)
	if canReuseContentDigest(current, artifact) {
		return true
	}
	digest, err := hashLocalFile(path)
	return err == nil && digest == artifact.Hash
}

func (candidate localChangeCandidate) validate() error {
	if candidate.Version != localChangeCandidateVersion && candidate.Version != sourceEvidenceVersion {
		return fmt.Errorf("saved build information has unsupported version %d", candidate.Version)
	}
	if candidate.LibraryUUID == "" || candidate.TargetSourceFingerprint == "" || candidate.ToCatalogChecksum == "" {
		return errors.New("saved build information is missing required library details")
	}
	if candidate.Scope != calibre.GenerationChangeScopeExact && candidate.Scope != calibre.GenerationChangeScopeCoarse {
		return fmt.Errorf("saved build information has unsupported cache-refresh mode %q", candidate.Scope)
	}
	if candidate.Scope == calibre.GenerationChangeScopeExact && (candidate.FromGeneration == "" || candidate.FromLiveCount == nil || candidate.FromCatalogChecksum == "") {
		return errors.New("saved build information for a targeted cache refresh is missing details about the previous publication")
	}
	if candidate.Scope == calibre.GenerationChangeScopeCoarse && candidate.Reason == "" {
		return errors.New("saved build information for a whole-library cache refresh is missing its diagnostic reason")
	}
	if candidate.Scope == calibre.GenerationChangeScopeCoarse && len(candidate.Changes) != 0 {
		return errors.New("saved build information for a whole-library cache refresh must not contain changed-book details")
	}
	if candidate.ContentLedgerVersion != candidate.Version {
		return fmt.Errorf("saved build information has unsupported file-checksum format %d", candidate.ContentLedgerVersion)
	}
	if candidate.Version == sourceEvidenceVersion {
		if err := validateSourceEvidence(candidate.ContentLedger, candidate.Evidence); err != nil {
			return err
		}
	} else {
		if err := validateSourceContentLedger(candidate.ContentLedger); err != nil {
			return err
		}
	}
	ledgerPaths := make(map[string]struct{}, len(candidate.ContentLedger))
	for _, object := range candidate.ContentLedger {
		ledgerPaths[object.Path] = struct{}{}
	}
	if err := validateCandidatePaths(candidate.ForcePaths, ledgerPaths); err != nil {
		return err
	}
	if !libraryflow.IsDerivedPath(candidate.IndexArtifact.Path) || !strings.HasSuffix(candidate.IndexArtifact.Path, ".zst") {
		return errors.New("saved build information does not name a compressed library index")
	}
	if err := validateContentLedger([]libraryflow.Object{candidate.IndexArtifact}); err != nil {
		return fmt.Errorf("saved build information has an invalid compressed library index: %w", err)
	}
	return nil
}

func validateCandidatePaths(paths []string, ledgerPaths map[string]struct{}) error {
	previous := ""
	for _, raw := range paths {
		path, err := libraryflow.NormalizePath(raw)
		if err != nil || path != raw {
			return fmt.Errorf("saved build information has an invalid file marked for re-upload: %q", raw)
		}
		if previous != "" && path <= previous {
			return errors.New("files marked for re-upload in saved build information must be sorted and unique")
		}
		if _, ok := ledgerPaths[path]; !ok {
			return fmt.Errorf("file %q is marked for re-upload but is absent from the saved file-checksum list", path)
		}
		previous = path
	}
	return nil
}

func validateContentLedger(ledger []libraryflow.Object) error {
	previous := ""
	for _, object := range ledger {
		path, err := libraryflow.NormalizePath(object.Path)
		if err != nil || path != object.Path || (previous != "" && path <= previous) {
			return errors.New("saved file-checksum paths must be normalized, sorted, and unique")
		}
		if len(object.Hash) != sha256.Size*2 || strings.ToLower(object.Hash) != object.Hash {
			return fmt.Errorf("saved file checksum is invalid for %q", path)
		}
		if _, err := hex.DecodeString(object.Hash); err != nil {
			return fmt.Errorf("saved file checksum is invalid for %q: %w", path, err)
		}
		previous = path
	}
	return nil
}

func validateSourceContentLedger(ledger []libraryflow.Object) error {
	if err := validateContentLedger(ledger); err != nil {
		return err
	}
	for _, object := range ledger {
		if !libraryflow.IsSourcePath(object.Path) {
			return fmt.Errorf("saved file-checksum path %q is not a publishable library file", object.Path)
		}
	}
	return nil
}

func sourceFingerprintFromContentLedger(ledger []libraryflow.Object) (string, error) {
	metadataHash := ""
	for _, object := range ledger {
		if object.Path == "metadata.db" {
			metadataHash = object.Hash
			break
		}
	}
	fingerprint, _, err := libraryflow.SourceFingerprintFromObjects(ledger, metadataHash, nil)
	return fingerprint, err
}

func sameContentLedgerInventory(objects []libraryflow.Object, excludes []string, ledger []libraryflow.Object) bool {
	current, err := libraryflow.FilterInventory(objects, excludes, false)
	if err != nil || len(current) != len(ledger) {
		return false
	}
	for index := range current {
		if current[index].Path != ledger[index].Path || current[index].Size != ledger[index].Size {
			return false
		}
	}
	return true
}

// contentLedgerHashFile is a narrow test seam for proving that an unchanged
// repeated build performs no source-byte reads. Index-artifact verification
// intentionally continues to call hashLocalFile directly.
var contentLedgerHashFile = hashLocalFileWithProgress

var contentHashBufferPool = sync.Pool{
	New: func() any { return make([]byte, 1<<20) },
}

// buildContentLedger returns a complete source-content ledger plus the paths
// whose bytes were added/changed and removed. Stat identity is only an
// accelerator: without a trustworthy change timestamp the file is rehashed.
func buildContentLedger(root string, objects []libraryflow.Object, excludes []string, previous []libraryflow.Object) ([]libraryflow.Object, []string, []string, error) {
	return buildContentLedgerWithProgress(root, objects, excludes, previous, nil)
}

type contentLedgerProgress struct {
	TotalFiles  int
	TotalBytes  int64
	HashFiles   int
	HashBytes   int64
	HashedFiles int
	HashedBytes int64
	ReusedFiles int
}

func buildContentLedgerWithProgress(
	root string,
	objects []libraryflow.Object,
	excludes []string,
	previous []libraryflow.Object,
	progress func(contentLedgerProgress),
) ([]libraryflow.Object, []string, []string, error) {
	current, err := libraryflow.FilterInventory(objects, excludes, false)
	if err != nil {
		return nil, nil, nil, err
	}
	previousByPath := make(map[string]libraryflow.Object, len(previous))
	for _, object := range previous {
		previousByPath[object.Path] = object
	}
	state := contentLedgerProgress{TotalFiles: len(current)}
	for _, object := range current {
		state.TotalBytes += object.Size
		if canReuseContentDigest(object, previousByPath[object.Path]) {
			state.ReusedFiles++
		} else {
			state.HashFiles++
			state.HashBytes += object.Size
		}
	}
	if progress != nil {
		progress(state)
	}
	ledger := make([]libraryflow.Object, 0, len(current))
	changed := make([]string, 0)
	seen := make(map[string]struct{}, len(current))
	for _, object := range current {
		seen[object.Path] = struct{}{}
		prior, existed := previousByPath[object.Path]
		if canReuseContentDigest(object, prior) {
			object.Hash = prior.Hash
		} else {
			digest, err := contentLedgerHashFile(filepath.Join(root, filepath.FromSlash(object.Path)), func(bytesRead int64) {
				state.HashedBytes += bytesRead
				if progress != nil {
					progress(state)
				}
			})
			if err != nil {
				return nil, nil, nil, fmt.Errorf("checksum library file %s: %w", object.Path, err)
			}
			object.Hash = digest
			state.HashedFiles++
			if progress != nil {
				progress(state)
			}
		}
		if !existed || object.Hash != prior.Hash {
			changed = append(changed, object.Path)
		}
		ledger = append(ledger, object)
	}
	removed := make([]string, 0)
	for _, object := range previous {
		if _, ok := seen[object.Path]; !ok {
			removed = append(removed, object.Path)
		}
	}
	sort.Strings(changed)
	sort.Strings(removed)
	return ledger, changed, removed, nil
}

func canChainLocalBuildCandidate(candidate *localChangeCandidate, priorGeneration string, diff calibre.CatalogDiff) bool {
	return candidate != nil && candidate.FromGeneration == priorGeneration &&
		candidate.ToLiveCount == diff.FromCount && candidate.ToCatalogChecksum == diff.FromChecksum
}

// composeLocalBuildCandidate carries an unpublished A->B transition across a
// later local B->C build. This keeps build retries and the build phase inside
// `lib publish` from silently replacing remote-relative evidence with a diff
// against their own output.
func composeLocalBuildCandidate(prior, delta localChangeCandidate) (localChangeCandidate, error) {
	if prior.LibraryUUID != delta.LibraryUUID || prior.ToLiveCount != valueOrZero(delta.FromLiveCount) ||
		prior.ToCatalogChecksum != delta.FromCatalogChecksum {
		return localChangeCandidate{}, errors.New("saved build history is not continuous")
	}

	combined := delta
	combined.FromGeneration = prior.FromGeneration
	combined.FromLiveCount = cloneUint32(prior.FromLiveCount)
	combined.FromCatalogChecksum = prior.FromCatalogChecksum
	combined.CompleteOverwrite = prior.CompleteOverwrite || delta.CompleteOverwrite
	combined.ForcePaths = mergeCandidateForcePaths(prior.ForcePaths, delta.ForcePaths, delta.ContentLedger)

	switch {
	case prior.Scope == calibre.GenerationChangeScopeCoarse:
		reason := prior.Reason
		if delta.Scope == calibre.GenerationChangeScopeCoarse && delta.CompleteOverwrite && !prior.CompleteOverwrite {
			reason = delta.Reason
		}
		combined.makeCoarse(reason, combined.CompleteOverwrite)
	case delta.Scope == calibre.GenerationChangeScopeCoarse:
		combined.makeCoarse(delta.Reason, combined.CompleteOverwrite)
	default:
		changes, err := composeGenerationChanges(prior.Changes, delta.Changes)
		if err != nil {
			return localChangeCandidate{}, err
		}
		combined.Scope = calibre.GenerationChangeScopeExact
		combined.Reason = ""
		combined.Changes = changes
		if len(changes) > calibre.DefaultGenerationChangeMaxItems {
			combined.makeCoarse("change-limit", true)
		}
	}
	if combined.Scope == calibre.GenerationChangeScopeExact {
		if combined.FromLiveCount == nil {
			return localChangeCandidate{}, errors.New("saved build history is missing the previous publication's book count")
		}
		if err := calibre.ValidateCatalogTransition(
			combined.FromCatalogChecksum, combined.ToCatalogChecksum,
			*combined.FromLiveCount, combined.ToLiveCount, combined.Changes,
		); err != nil {
			return localChangeCandidate{}, fmt.Errorf("combine changed-book lists from consecutive builds: %w", err)
		}
	}
	return combined, nil
}

func cloneUint32(value *uint32) *uint32 {
	if value == nil {
		return nil
	}
	copy := *value
	return &copy
}

func valueOrZero(value *uint32) uint32 {
	if value == nil {
		return 0
	}
	return *value
}

func mergeCandidateForcePaths(first, second []string, ledger []libraryflow.Object) []string {
	current := make(map[string]struct{}, len(ledger))
	for _, object := range ledger {
		current[object.Path] = struct{}{}
	}
	merged := make(map[string]struct{}, len(first)+len(second))
	for _, paths := range [][]string{first, second} {
		for _, path := range paths {
			if _, exists := current[path]; exists {
				merged[path] = struct{}{}
			}
		}
	}
	result := make([]string, 0, len(merged))
	for path := range merged {
		result = append(result, path)
	}
	sort.Strings(result)
	return result
}

type generationChangeEndpoints struct {
	beforeExists bool
	before       string
	afterExists  bool
	after        string
	payload      bool
}

func changeEndpoints(change calibre.GenerationChange) (generationChangeEndpoints, error) {
	validDigest := func(value string) bool {
		if len(value) != sha256.Size*2 || strings.ToLower(value) != value {
			return false
		}
		_, err := hex.DecodeString(value)
		return err == nil
	}
	switch change.Kind {
	case "added":
		if change.OldRecordDigest != "" || !validDigest(change.NewRecordDigest) {
			return generationChangeEndpoints{}, fmt.Errorf("invalid added change %s", change.ID)
		}
		return generationChangeEndpoints{afterExists: true, after: change.NewRecordDigest, payload: change.PayloadChanged}, nil
	case "edited":
		if !validDigest(change.OldRecordDigest) || !validDigest(change.NewRecordDigest) {
			return generationChangeEndpoints{}, fmt.Errorf("invalid edited change %s", change.ID)
		}
		return generationChangeEndpoints{beforeExists: true, before: change.OldRecordDigest, afterExists: true, after: change.NewRecordDigest, payload: change.PayloadChanged}, nil
	case "deleted":
		if !validDigest(change.OldRecordDigest) || change.NewRecordDigest != "" || change.PayloadChanged {
			return generationChangeEndpoints{}, fmt.Errorf("invalid deleted change %s", change.ID)
		}
		return generationChangeEndpoints{beforeExists: true, before: change.OldRecordDigest}, nil
	default:
		return generationChangeEndpoints{}, fmt.Errorf("unsupported change kind %q", change.Kind)
	}
}

func composeGenerationChanges(first, second []calibre.GenerationChange) ([]calibre.GenerationChange, error) {
	byID := make(map[string]calibre.GenerationChange, len(first)+len(second))
	for _, change := range first {
		if _, err := changeEndpoints(change); err != nil {
			return nil, err
		}
		if _, exists := byID[change.ID]; exists {
			return nil, fmt.Errorf("first changed-book list repeats book ID %s", change.ID)
		}
		byID[change.ID] = change
	}
	seenSecond := make(map[string]struct{}, len(second))
	for _, next := range second {
		if _, repeated := seenSecond[next.ID]; repeated {
			return nil, fmt.Errorf("second changed-book list repeats book ID %s", next.ID)
		}
		seenSecond[next.ID] = struct{}{}
		right, err := changeEndpoints(next)
		if err != nil {
			return nil, err
		}
		previous, exists := byID[next.ID]
		if !exists {
			byID[next.ID] = next
			continue
		}
		left, err := changeEndpoints(previous)
		if err != nil {
			return nil, err
		}
		if left.afterExists != right.beforeExists || (left.afterExists && left.after != right.before) {
			return nil, fmt.Errorf("changed-book history for %s is not continuous", next.ID)
		}
		payload := left.payload || right.payload
		switch {
		case !left.beforeExists && !right.afterExists:
			delete(byID, next.ID)
		case !left.beforeExists:
			byID[next.ID] = calibre.GenerationChange{Kind: "added", ID: next.ID, NewRecordDigest: right.after, PayloadChanged: payload}
		case !right.afterExists:
			byID[next.ID] = calibre.GenerationChange{Kind: "deleted", ID: next.ID, OldRecordDigest: left.before}
		case left.before == right.after && !payload:
			delete(byID, next.ID)
		default:
			byID[next.ID] = calibre.GenerationChange{
				Kind: "edited", ID: next.ID, OldRecordDigest: left.before,
				NewRecordDigest: right.after, PayloadChanged: payload,
			}
		}
	}
	result := make([]calibre.GenerationChange, 0, len(byID))
	for _, change := range byID {
		result = append(result, change)
	}
	sort.Slice(result, func(i, j int) bool { return result[i].ID < result[j].ID })
	return result, nil
}

// legacyBaselineUpgradeChanges upgrades a baseline written before content
// ledgers existed without retransmitting the whole library. The old baseline
// proves that this seat's local and remote source inventories agreed when its
// generation committed. A Unix change time after that commit is therefore a
// conservative changed-path signal: unlike mtime it also advances when bytes
// are rewritten and the old mtime is restored. Filesystems without that signal
// remain ineligible and keep the fail-closed complete-overwrite policy.
func legacyBaselineUpgradeChanges(baseline *libraryBaseline, priorGeneration string, ledger []libraryflow.Object) ([]string, bool) {
	if baseline == nil || baseline.ContentLedgerVersion != 0 || baseline.UpdatedAt.IsZero() ||
		baseline.LocalSourceFingerprint == "" || baseline.LocalSourceFingerprint != baseline.RemoteSourceFingerprint {
		return nil, false
	}
	token, err := decodeGenerationHex(priorGeneration)
	if err != nil {
		return nil, false
	}
	_, generation := token.parts()
	if generation != baseline.Generation {
		return nil, false
	}
	cutoff := baseline.UpdatedAt.UTC()
	if cutoff.After(time.Now().UTC()) {
		return nil, false
	}
	changed := make([]string, 0)
	for _, object := range ledger {
		if object.ChangeTime <= 0 {
			return nil, false
		}
		if object.ChangeTime > cutoff.UnixNano() || object.ModTime.After(cutoff) {
			changed = append(changed, object.Path)
		}
	}
	sort.Strings(changed)
	return changed, true
}

func canReuseContentDigest(current, previous libraryflow.Object) bool {
	if current.ChangeTime == 0 || previous.ChangeTime == 0 || current.ChangeTime != previous.ChangeTime || current.Size != previous.Size || !current.ModTime.Equal(previous.ModTime) {
		return false
	}
	if len(previous.Hash) != sha256.Size*2 || strings.ToLower(previous.Hash) != previous.Hash {
		return false
	}
	_, err := hex.DecodeString(previous.Hash)
	return err == nil
}

func hashLocalFile(path string) (string, error) {
	return hashLocalFileWithProgress(path, nil)
}

func hashLocalFileWithProgress(path string, progress func(int64)) (string, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close()
	h := sha256.New()
	buffer := contentHashBufferPool.Get().([]byte)
	defer contentHashBufferPool.Put(buffer)
	for {
		n, readErr := f.Read(buffer)
		if n > 0 {
			if _, err := h.Write(buffer[:n]); err != nil {
				return "", err
			}
			if progress != nil {
				progress(int64(n))
			}
		}
		if errors.Is(readErr, io.EOF) {
			break
		}
		if readErr != nil {
			return "", readErr
		}
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

func compileLocalChangeCandidate(libraryUUID, priorGeneration, targetSourceFingerprint string, diff calibre.CatalogDiff, ledger []libraryflow.Object, changedCurrent, removed []string, baseline *libraryBaseline) localChangeCandidate {
	candidate := localChangeCandidate{
		Version: localChangeCandidateVersion, LibraryUUID: libraryUUID,
		Scope: calibre.GenerationChangeScopeExact, FromGeneration: priorGeneration,
		TargetSourceFingerprint: targetSourceFingerprint,
		FromLiveCount:           uint32ptr(diff.FromCount), ToLiveCount: diff.ToCount,
		FromCatalogChecksum: diff.FromChecksum, ToCatalogChecksum: diff.ToChecksum,
		Changes:              append([]calibre.GenerationChange(nil), diff.Changes...),
		ContentLedgerVersion: 1, ContentLedger: append([]libraryflow.Object(nil), ledger...),
	}

	payloadIDs, ambiguous := payloadChangedIDs(changedCurrent, removed, diff.CurrentRecords, diff.PreviousRecords)
	changesByID := make(map[string]int, len(candidate.Changes))
	for index := range candidate.Changes {
		changesByID[candidate.Changes[index].ID] = index
	}
	for id := range payloadIDs {
		if index, ok := changesByID[id]; ok {
			if candidate.Changes[index].Kind != "deleted" {
				candidate.Changes[index].PayloadChanged = true
			}
			continue
		}
		oldInfo, oldOK := diff.PreviousRecords[id]
		newInfo, newOK := diff.CurrentRecords[id]
		if oldOK && newOK {
			candidate.Changes = append(candidate.Changes, calibre.GenerationChange{
				Kind: "edited", ID: id, OldRecordDigest: oldInfo.RecordDigest,
				NewRecordDigest: newInfo.RecordDigest, PayloadChanged: true,
			})
		}
	}
	sort.Slice(candidate.Changes, func(i, j int) bool { return candidate.Changes[i].ID < candidate.Changes[j].ID })

	ledgerPaths := make(map[string]struct{}, len(ledger))
	for _, object := range ledger {
		ledgerPaths[object.Path] = struct{}{}
	}
	force := make(map[string]struct{})
	for _, path := range changedCurrent {
		if _, ok := ledgerPaths[path]; ok {
			force[path] = struct{}{}
		}
	}
	for _, change := range candidate.Changes {
		if change.Kind == "deleted" {
			continue
		}
		if info, ok := diff.CurrentRecords[change.ID]; ok {
			for _, path := range append([]string{info.CoverURL}, info.FormatPaths...) {
				path, err := libraryflow.NormalizePath(path)
				if err == nil {
					if _, exists := ledgerPaths[path]; exists {
						force[path] = struct{}{}
					}
				}
			}
		}
	}
	for path := range force {
		candidate.ForcePaths = append(candidate.ForcePaths, path)
	}
	sort.Strings(candidate.ForcePaths)

	switch {
	case priorGeneration == "":
		candidate.makeCoarse("no-local-predecessor", true)
	case baseline == nil || (baseline.ContentLedgerVersion != 1 && baseline.ContentLedgerVersion != sourceEvidenceVersion):
		candidate.makeCoarse("missing-content-baseline", true)
	case baseline.GenerationToken != priorGeneration || baseline.CatalogChecksum != diff.FromChecksum:
		candidate.makeCoarse("stale-content-baseline", true)
	case ambiguous:
		candidate.makeCoarse("unmapped-payload-change", true)
	case len(candidate.Changes) > calibre.DefaultGenerationChangeMaxItems:
		candidate.makeCoarse("change-limit", true)
	}
	return candidate
}

func (candidate *localChangeCandidate) makeCoarse(reason string, completeOverwrite bool) {
	candidate.Scope = calibre.GenerationChangeScopeCoarse
	candidate.Reason = reason
	candidate.Changes = nil
	candidate.CompleteOverwrite = completeOverwrite
}

// generationChangeReasonExplanation turns persisted diagnostic reason codes
// into text suitable for normal command output. Keep the stable code alongside
// this explanation when troubleshooting value matters.
func generationChangeReasonExplanation(reason string) string {
	switch reason {
	case "invalid-content-baseline":
		return "the saved file-change history is unreadable"
	case "content-baseline-library-mismatch":
		return "the saved file-change history belongs to another library"
	case "invalid-local-generation":
		return "the local publication marker is unreadable"
	case "invalid-local-predecessor":
		return "the previous library index cannot be compared"
	case "invalid-local-candidate-chain":
		return "the previous unpublished build cannot be continued"
	case "legacy-content-baseline-upgrade":
		return "change tracking is being upgraded from an older Accorder version"
	case "source-provenance-changed":
		return "this library's device or location differs from its saved file-change history"
	case "source-coherence-unavailable":
		return "this filesystem does not provide the file-change information needed for safe publication"
	case "derived-repair-rebase":
		return "the library index was repaired separately; pending book-file updates were retained"
	case "no-local-predecessor":
		return "there is no previous local publication to compare"
	case "missing-content-baseline":
		return "there is no saved file-change history to compare"
	case "stale-content-baseline":
		return "the saved file-change history does not match the previous build"
	case "unmapped-payload-change":
		return "some changed files could not be matched to books"
	case "change-limit":
		return "too many books changed to track individually"
	case "missing-build-candidate":
		return "the library was not built with the current change tracker"
	case "first-publication":
		return "this is the first publication"
	case "private-file-cleanup":
		return "previously published private files were removed; cached copies also need refreshing"
	case "remote-predecessor-mismatch":
		return "the remote library changed after this update was prepared"
	default:
		return "the changed-book list could not be verified"
	}
}

func generationChangeReasonDetails(reason string) string {
	if reason == "" {
		return ""
	}
	return fmt.Sprintf("%s; diagnostic: %s", generationChangeReasonExplanation(reason), reason)
}

func uint32ptr(value uint32) *uint32 { return &value }

func payloadChangedIDs(changedCurrent, removed []string, current, previous map[string]calibre.CatalogRecordInfo) (map[string]struct{}, bool) {
	currentDirs := catalogDirectories(current)
	previousDirs := catalogDirectories(previous)
	ids := make(map[string]struct{})
	ambiguous := false
	classify := func(objectPath string) {
		// Root coordination/source files such as metadata.db are transferred but
		// have no VFS book directory to invalidate.
		if !strings.Contains(objectPath, "/") {
			return
		}
		directory := filepath.ToSlash(filepath.Dir(objectPath))
		matches := make(map[string]struct{})
		for _, byDirectory := range []map[string]map[string]struct{}{currentDirs, previousDirs} {
			for probe := directory; probe != "." && probe != ""; probe = filepath.ToSlash(filepath.Dir(probe)) {
				for id := range byDirectory[probe] {
					matches[id] = struct{}{}
				}
				if len(byDirectory[probe]) > 0 {
					break
				}
			}
		}
		if len(matches) != 1 {
			ambiguous = true
			return
		}
		for id := range matches {
			ids[id] = struct{}{}
		}
	}
	for _, path := range changedCurrent {
		classify(path)
	}
	for _, path := range removed {
		classify(path)
	}
	return ids, ambiguous
}

func catalogDirectories(records map[string]calibre.CatalogRecordInfo) map[string]map[string]struct{} {
	result := make(map[string]map[string]struct{})
	for id, record := range records {
		for _, raw := range record.BookDirectories {
			directory := strings.Trim(filepath.ToSlash(filepath.Clean(raw)), "/")
			if directory == "" || directory == "." {
				continue
			}
			if result[directory] == nil {
				result[directory] = make(map[string]struct{})
			}
			result[directory][id] = struct{}{}
		}
	}
	return result
}

func candidateCarryForward(previous, current map[string]calibre.CatalogRecordInfo, payloadChanged map[string]struct{}) map[string]string {
	result := make(map[string]string)
	for id, info := range current {
		prior, ok := previous[id]
		if !ok || prior.CoverFingerprint == "" {
			continue
		}
		if _, changed := payloadChanged[id]; changed {
			continue
		}
		if info.MetadataDigest == prior.MetadataDigest {
			result[id] = prior.CoverFingerprint
		}
	}
	return result
}
