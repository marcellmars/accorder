//go:build !tailscale && !tor

package cmd

// ===========================================================================
// Phase 0 spike: accorder-doctor (ca-121)
// (.sit/workflows/2026-08-18_accorder-doctor/propose.md, Phase 0)
//
// Resolves the two assumptions the proposal left open, before the checks are
// designed around them.
// ===========================================================================

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// Assumption 1: walkSize, pointed at a LIVE VFS cache root (not a reclaim
// candidate), returns a total comparable to the --cache-size cap.
//
// The falsifying question is not "does walkSize work" but "does doctor look
// where the serve actually writes". Producers, all three verified present in
// the tree: fedlibShareLive.go:120 "accorder-serve-"+alias,
// fedlibShareFunnel.go:53 "accorder-funnel-"+alias, libShareLive.go:227
// "accorder-"+alias.
func TestSpike_WalkSizeOverLiveCacheRoot(t *testing.T) {
	testSetup(t)
	const alias = "motw"
	remote := "accorder-serve-" + alias
	tree := cacheTreeInfo{RemoteName: remote}

	// Materialise what a serve would leave behind: vfs/ + vfsMeta/ halves.
	vfs, meta := tree.vfsPath(), tree.metaPath()
	for _, d := range []string{vfs, meta} {
		if err := os.MkdirAll(filepath.Join(d, "books"), 0o700); err != nil {
			t.Fatal(err)
		}
	}
	payload := make([]byte, 4096)
	if err := os.WriteFile(filepath.Join(vfs, "books", "a.epub"), payload, 0o600); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(meta, "books", "a.epub"), payload[:512], 0o600); err != nil {
		t.Fatal(err)
	}

	total, lower := walkSize([]string{vfs, meta}, defaultSizeBudget, nil)
	if lower {
		t.Errorf("walkSize truncated on a 2-file tree; budget wiring is wrong")
	}
	if want := int64(4096 + 512); total != want {
		t.Errorf("walkSize = %d bytes, want %d (both halves must count)", total, want)
	}

	// The cap side of the comparison: --cache-size is passed to rclone as an
	// unparsed string, so doctor must parse it itself.
	cap, err := parseByteSize("10Gi")
	if err != nil {
		t.Fatalf("parseByteSize(10Gi): %v", err)
	}
	if cap <= total {
		t.Errorf("sanity: 10Gi (%d) should exceed a 4.5KB tree (%d)", cap, total)
	}
	if formatByteSize(total) == "" {
		t.Error("formatByteSize returned empty for a non-zero total")
	}
}

func TestDoctorReportsBooksAndAssetsCachePlanesIndependently(t *testing.T) {
	testSetup(t)
	const alias = "motw"
	if err := os.WriteFile(savedActionAliases, []byte(`{
		"motw":{"fedlib":{"share":{"live":{
			"cache-size":"100B",
			"cache-size-assets":"5B"
		}}}}
	}`), 0o600); err != nil {
		t.Fatal(err)
	}

	names := liveCacheRemoteNames(alias)
	for remote, rangeBytes := range map[string]int64{
		names.Books:  4,
		names.Assets: 15,
	} {
		seedDoctorCacheItem(t, remote, "bucket", "object", 32, rangeBytes)
	}

	doctor := &DoctorCmd{ActionAlias: alias}
	ctx := doctorCacheContext{currentRoot: "bucket"}
	books := doctor.checkCachePlane(doctorCachePlane{name: "cache books", remoteName: names.Books, capField: "cache-size"}, ctx)
	assets := doctor.checkCachePlane(doctorCachePlane{name: "cache assets", remoteName: names.Assets, capField: "cache-size-assets"}, ctx)
	if books.name != "cache books" || books.verdict != vOK {
		t.Errorf("books result = %#v, want independent healthy books row", books)
	}
	if assets.name != "cache assets" || assets.verdict != vWarn || !strings.Contains(assets.detail, "eviction is not keeping up") {
		t.Errorf("assets result = %#v, want independent over-cap assets warning", assets)
	}
}

func TestParseVFSCacheSizeUsesRcloneGrammar(t *testing.T) {
	tests := []struct {
		value   string
		want    int64
		wantErr bool
	}{
		{value: "3000000000B", want: 3000000000},
		{value: "1.5Gi", want: 3 * (1 << 29)},
		{value: "2", want: 2 << 10},
		{value: "1kib", want: 1 << 10},
		{value: "3GB", wantErr: true},
	}
	for _, test := range tests {
		t.Run(test.value, func(t *testing.T) {
			got, err := parseVFSCacheSize(test.value)
			if (err != nil) != test.wantErr {
				t.Fatalf("parseVFSCacheSize(%q) error=%v, wantErr=%v", test.value, err, test.wantErr)
			}
			if !test.wantErr && got != test.want {
				t.Fatalf("parseVFSCacheSize(%q)=%d, want %d", test.value, got, test.want)
			}
		})
	}
}

func TestDoctorExistingCachePlaneWarnsWhenSavedCapIsMissing(t *testing.T) {
	testSetup(t)
	const alias = "motw"
	if err := os.WriteFile(savedActionAliases, []byte(`{
		"motw":{"fedlib":{"share":{"live":{"cache-size":"20B"}}}}
	}`), 0o600); err != nil {
		t.Fatal(err)
	}
	names := liveCacheRemoteNames(alias)
	seedDoctorCacheItem(t, names.Assets, "bucket", "cover.jpg", 32, 5)

	got := (&DoctorCmd{ActionAlias: alias}).checkCachePlane(
		doctorCachePlane{name: "cache assets", remoteName: names.Assets, capField: "cache-size-assets"},
		doctorCacheContext{currentRoot: "bucket"},
	)
	if got.verdict != vWarn || !strings.Contains(got.detail, "no saved --cache-size-assets cap") {
		t.Fatalf("assets result = %#v, want missing-cap warning for an existing plane", got)
	}
}

func TestDoctorFunnelPlanesResolveTheirOwnSavedBucket(t *testing.T) {
	testSetup(t)
	const alias = "motw"
	if err := os.WriteFile(savedActionAliases, []byte(`{
		"motw":{"fedlib":{"share":{"funnel":{
			"bucket":"funnel-bucket",
			"cache-size":"20B",
			"cache-size-assets":"30B"
		}}}}
	}`), 0o600); err != nil {
		t.Fatal(err)
	}
	names := funnelCacheRemoteNames(alias)
	seedDoctorCacheItem(t, names.Books, "funnel-bucket", "book.epub", 32, 10)
	seedDoctorCacheItem(t, names.Assets, "funnel-bucket", "cover.jpg", 32, 12)

	results := (&DoctorCmd{ActionAlias: alias}).checkCachePlanes()
	for _, index := range []int{2, 3} {
		got := results[index]
		if got.verdict != vOK || !strings.Contains(got.detail, `current "funnel-bucket"`) {
			t.Fatalf("funnel result = %#v, want current root from funnel alias", got)
		}
		if strings.Contains(got.detail, "stale") || strings.Contains(got.detail, "current root unresolved") {
			t.Fatalf("funnel result reused live descriptor context: %#v", got)
		}
	}
	if results[0].verdict != vSkipped || results[1].verdict != vSkipped {
		t.Fatalf("funnel-only host live rows = %#v / %#v, want skipped", results[0], results[1])
	}
}

func TestDoctorAssetsCachePlaneWarnsOnMalformedCap(t *testing.T) {
	testSetup(t)
	const alias = "motw"
	if err := os.WriteFile(savedActionAliases, []byte(`{
		"motw":{"fedlib":{"share":{"live":{"cache-size-assets":"not-bytes"}}}}
	}`), 0o600); err != nil {
		t.Fatal(err)
	}
	names := liveCacheRemoteNames(alias)
	seedDoctorCacheItem(t, names.Assets, "bucket", "cover.jpg", 32, 5)

	got := (&DoctorCmd{ActionAlias: alias}).checkCachePlane(
		doctorCachePlane{name: "cache assets", remoteName: names.Assets, capField: "cache-size-assets"},
		doctorCacheContext{currentRoot: "bucket"},
	)
	if got.verdict != vWarn || !strings.Contains(got.detail, "invalid") {
		t.Errorf("assets result = %#v, want malformed-cap warning", got)
	}
}

func TestDoctorUsesDescriptorRootCleanerRangesAndSeparatesStaleFootprint(t *testing.T) {
	testSetup(t)
	const alias = "motw"
	if err := os.WriteFile(savedActionAliases, []byte(`{
		"motw":{"fedlib":{"share":{"live":{
			"cache-size":"20B",
			"cache-size-assets":"20B"
		}}}}
	}`), 0o600); err != nil {
		t.Fatal(err)
	}
	if err := saveFedlibDescriptor(alias, fedlibDescriptor{Version: fedlibDescriptorVersion, Bucket: "current"}); err != nil {
		t.Fatal(err)
	}

	names := liveCacheRemoteNames(alias)
	// The current file is logically 1 MiB but only a 10-byte range is cached;
	// doctor must compare 10 bytes with the cap. The stale root is larger than
	// the cap but is footprint-only and must not trigger an eviction warning.
	seedDoctorCacheItem(t, names.Books, "current", "book.epub", 1<<20, 10)
	seedDoctorCacheItem(t, names.Books, "old-bucket", "old.epub", 1<<20, 1000)

	results := (&DoctorCmd{ActionAlias: alias}).checkCachePlanes()
	books := results[0]
	if !strings.Contains(books.detail, `cleaner 10B of 20B cap`) {
		t.Fatalf("books detail does not use rclone ranges for the descriptor root: %s", books.detail)
	}
	if !strings.Contains(books.detail, `current "current"`) || !strings.Contains(books.detail, `stale "old-bucket"`) {
		t.Fatalf("books detail does not separate current and stale roots: %s", books.detail)
	}
	if strings.Contains(books.detail, "eviction is not keeping up") {
		t.Fatalf("stale/logical bytes were charged to the current cleaner cap: %s", books.detail)
	}
	if books.verdict != vWarn || !strings.Contains(books.detail, "outside the current cap") {
		t.Fatalf("stale root was not surfaced as a warning: %#v", books)
	}
}

func TestDoctorWarnsOnMalformedMetadataAndOmitsMalformedLedgerRoots(t *testing.T) {
	testSetup(t)
	const alias = "motw"
	if err := os.WriteFile(savedActionAliases, []byte(`{
		"motw":{"fedlib":{"share":{"live":{
			"cache-size":"20B",
			"cache-size-assets":"20B"
		}}}}
	}`), 0o600); err != nil {
		t.Fatal(err)
	}
	if err := saveFedlibDescriptor(alias, fedlibDescriptor{Version: fedlibDescriptorVersion, Bucket: "current"}); err != nil {
		t.Fatal(err)
	}

	names := liveCacheRemoteNames(alias)
	seedDoctorCacheItem(t, names.Books, "current", "book.epub", 32, 10)
	metaPath := filepath.Join(accorderCacheDir(), "vfsMeta", names.Books, "current", "book.epub")
	if err := os.WriteFile(metaPath, []byte(`{"Size":32,"Rs":[{"Pos":0,"Size":20},{"Pos":10,"Size":10}]}`), 0o600); err != nil {
		t.Fatal(err)
	}
	ledgerPath := identityLedgerPath()
	if err := os.MkdirAll(filepath.Dir(ledgerPath), 0o700); err != nil {
		t.Fatal(err)
	}
	ledger := `{"v":1,"type":"serve-start","remote":"` + names.Books + `","root":"ledger-only","ts":"2026-08-31T00:00:00Z"}` + "\n" + "not-json\n"
	if err := os.WriteFile(ledgerPath, []byte(ledger), 0o600); err != nil {
		t.Fatal(err)
	}

	books := (&DoctorCmd{ActionAlias: alias}).checkCachePlanes()[0]
	if books.verdict != vWarn || !strings.Contains(books.detail, "overlapping or unsorted ranges") {
		t.Fatalf("malformed metadata was not a warned accounting failure: %#v", books)
	}
	if !strings.Contains(books.detail, "identity ledger malformed") {
		t.Fatalf("malformed ledger was not reported: %s", books.detail)
	}
	if strings.Contains(books.detail, "ledger-only") {
		t.Fatalf("doctor trusted the valid prefix of a malformed ledger: %s", books.detail)
	}
}

func seedDoctorCacheItem(t *testing.T, remote, root, rel string, logicalSize, rangeBytes int64) {
	t.Helper()
	dataPath := filepath.Join(accorderCacheDir(), "vfs", remote, filepath.FromSlash(root), filepath.FromSlash(rel))
	metaPath := filepath.Join(accorderCacheDir(), "vfsMeta", remote, filepath.FromSlash(root), filepath.FromSlash(rel))
	for _, path := range []string{dataPath, metaPath} {
		if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
			t.Fatal(err)
		}
	}
	data, err := os.OpenFile(dataPath, os.O_CREATE|os.O_WRONLY, 0o600)
	if err != nil {
		t.Fatal(err)
	}
	if err := data.Truncate(logicalSize); err != nil {
		_ = data.Close()
		t.Fatal(err)
	}
	if err := data.Close(); err != nil {
		t.Fatal(err)
	}
	metadata := fmt.Sprintf(`{"Size":%d,"Rs":[{"Pos":0,"Size":%d}]}`, logicalSize, rangeBytes)
	if err := os.WriteFile(metaPath, []byte(metadata), 0o600); err != nil {
		t.Fatal(err)
	}
}

// Assumption 1b: the prefix list is longest-first, so a serve cache is never
// attributed to a `lib share live` alias of the same name. This ordering is
// load-bearing and easy to break by sorting the slice.
func TestSpike_RemoteNamePrefixOrderingIsLongestFirst(t *testing.T) {
	got := remoteNameCandidates("accorder-serve-motw")
	if len(got) == 0 {
		t.Fatal("no candidates for a serve remote name")
	}
	if got[0] != "motw" {
		t.Errorf("first candidate = %q, want \"motw\" — `accorder-` matched before "+
			"`accorder-serve-`, which would attribute a fedlib serve cache to a lib alias", got[0])
	}
}

// Assumption 2: adding a report-only rotKind must not change what
// `config prune --apply` deletes. This pins the CURRENT deletable set so the
// Phase 1 change is provably additive.
func TestSpike_DeletableSetIsClosedOverReportOnlyKinds(t *testing.T) {
	deletable := map[rotKind]bool{}
	for k := rotDeadKey; k < rotKindCount; k++ {
		deletable[k] = k.deletable()
	}
	for _, tc := range []struct {
		kind rotKind
		want bool
		why  string
	}{
		{rotDeadKey, true, "dead keys are the primary prune target"},
		{rotDefaultShadow, true, "default shadows are safe to drop"},
		{rotExcludedKey, true, "excluded keys never belonged"},
		{rotEmptyNode, true, "empty nodes are structural litter"},
		{rotDeadSubtree, false, "may be live config for another build variant (ca-128)"},
		{rotDanglingPath, false, "the path may return; report only"},
		{rotStaleCacheTree, false, "gated behind --apply-cache-trees + attestation"},
		{rotDriftedKey, false, "two values, no way to know which is correct"},
	} {
		if got := deletable[tc.kind]; got != tc.want {
			t.Errorf("rotKind(%d).deletable() = %v, want %v — %s", tc.kind, got, tc.want, tc.why)
		}
	}

	// The bound must cover every kind, including ones added after this test
	// was written — that is the failure this loop previously had.
	if len(deletable) != int(rotKindCount) {
		t.Errorf("iterated %d kinds but rotKindCount is %d; the bound has drifted from the enum",
			len(deletable), rotKindCount)
	}
}
