package cmd

// cq-38: every build variant must register the canonical base command
// set. The three CLI structs (cmd/cliMainStruct.go, cmd/cliTorStruct.go,
// cmd/cliTailscaleStruct.go) are hand-maintained and mutually exclusive
// per build tag, so this file is deliberately unconstrained: it walks
// whichever CLI is active, and each tagged test run (default, -tags tor,
// -tags tailscale) pins its own variant. Variant-only extras are asserted
// by the tagged companion files (commandMatrix*_test.go).

import (
	"strings"
	"testing"

	"github.com/alecthomas/kong"
)

// baseCommandPaths is the canonical command tree every build variant must
// register, spelled as dotted kong paths. Adding a command to
// cliMainStruct.go requires adding it here AND to the other two variant
// structs — a variant that misses it fails its tagged test run.
var baseCommandPaths = []string{
	"config.(aliases)",
	"config.(aliases).copy",
	"config.(aliases).delete",
	"config.(aliases).find-calibre",
	"config.(aliases).list",
	"config.(aliases).prune",
	"config.(aliases).rename",
	"config.(aliases).show",
	"config.(aliases).validate",
	"doctor",
	"fedlib",
	"fedlib.backup",
	"fedlib.build",
	"fedlib.config",
	"fedlib.config.list",
	"fedlib.config.set",
	"fedlib.config.show",
	"fedlib.invites",
	"fedlib.invites.list",
	"fedlib.invites.revoke",
	"fedlib.members",
	"fedlib.members.add",
	"fedlib.members.disable",
	"fedlib.members.enable",
	"fedlib.members.invite",
	"fedlib.members.list",
	"fedlib.members.offer",
	"fedlib.members.reindex",
	"fedlib.members.remove",
	"fedlib.members.status",
	"fedlib.restore",
	"fedlib.share",
	"fedlib.share.grant",
	"fedlib.share.list-grants",
	"fedlib.share.live",
	"fedlib.share.reset-grants",
	"fedlib.share.revoke-grant",
	"lib",
	"lib.browse",
	"lib.build",
	"lib.download",
	"lib.import",
	"lib.index",
	"lib.index.add",
	"lib.index.download",
	"lib.index.info",
	"lib.index.list",
	"lib.index.recompile",
	"lib.index.remove",
	"lib.index.rename",
	"lib.join",
	"lib.publish",
	"lib.search",
	"lib.seat",
	"lib.seat.claim",
	"lib.seat.release",
	"lib.seat.show",
	"lib.share",
	"lib.share.grant",
	"lib.share.list-grants",
	"lib.share.live",
	"lib.share.reset-grants",
	"lib.share.revoke-grant",
	"lib.status",
	"lib.sync",
	"lib.upload",
	"secrets",
	"secrets.rekey",
}

func collectCommandPaths(t *testing.T) map[string]bool {
	t.Helper()
	cli := &CLI{}
	app, err := kong.New(cli, kong.Name("accorder"), kong.Exit(func(int) {}), kong.Bind(cli))
	if err != nil {
		t.Fatalf("kong.New: %v", err)
	}
	paths := map[string]bool{}
	var walk func(n *kong.Node)
	walk = func(n *kong.Node) {
		for _, ch := range n.Children {
			if ch == nil {
				continue
			}
			paths[strings.Join(strings.Split(ch.Path(), " "), ".")] = true
			walk(ch)
		}
	}
	walk(app.Model.Node)
	return paths
}

func TestCommandMatrix_BaseCommandsPresent(t *testing.T) {
	got := collectCommandPaths(t)
	for _, want := range baseCommandPaths {
		if !got[want] {
			t.Errorf("base command %q is not registered in this build variant's CLI struct", want)
		}
	}
}
