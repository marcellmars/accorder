package cmd

import (
	"encoding/json"
	"fmt"
	"io/fs"
	"log"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"
)

type cacheTreeClass int

const (
	treeUnclassified cacheTreeClass = iota
	treeForeign
	treeOwned
	treeStrandedLedgered
	treeStrandedLegacy
)

func (c cacheTreeClass) String() string {
	switch c {
	case treeOwned:
		return "owned"
	case treeStrandedLedgered:
		return "stranded (ledgered)"
	case treeStrandedLegacy:
		return "stranded (legacy)"
	case treeForeign:
		return "foreign"
	default:
		return "unclassified"
	}
}

type cacheTreeInfo struct {
	RemoteName       string
	Class            cacheTreeClass
	Candidates       []string
	HasVFS, HasMeta  bool
	SizeBytes        int64
	SizeIsLowerBound bool
	DriftRoots       []string
}

func (t cacheTreeInfo) vfsPath() string {
	return filepath.Join(accorderCacheDir(), "vfs", t.RemoteName)
}
func (t cacheTreeInfo) metaPath() string {
	return filepath.Join(accorderCacheDir(), "vfsMeta", t.RemoteName)
}

type cacheRemoteRole string

const (
	cacheRoleLiveBooks    cacheRemoteRole = "live books"
	cacheRoleLiveAssets   cacheRemoteRole = "live assets"
	cacheRoleFunnelBooks  cacheRemoteRole = "funnel books"
	cacheRoleFunnelAssets cacheRemoteRole = "funnel assets"
	cacheRoleLibrary      cacheRemoteRole = "per-library"
)

type cacheRemoteVariant struct {
	Role   cacheRemoteRole
	Prefix string
	Suffix string
}

var reclaimRemoteVariants = []cacheRemoteVariant{
	{Role: cacheRoleLiveBooks, Prefix: "accorder-serve-"},
	{Role: cacheRoleLiveAssets, Prefix: "accorder-serve-", Suffix: "-assets"},
	{Role: cacheRoleFunnelBooks, Prefix: "accorder-funnel-"},
	{Role: cacheRoleFunnelAssets, Prefix: "accorder-funnel-", Suffix: "-assets"},
	{Role: cacheRoleLibrary, Prefix: "accorder-"},
}

type aggregateCacheRemoteNames struct {
	Books  string
	Assets string
}

func cacheRemoteName(role cacheRemoteRole, alias string) string {
	for _, variant := range reclaimRemoteVariants {
		if variant.Role == role {
			return variant.Prefix + alias + variant.Suffix
		}
	}
	return ""
}

func liveCacheRemoteNames(alias string) aggregateCacheRemoteNames {
	return aggregateCacheRemoteNames{
		Books:  cacheRemoteName(cacheRoleLiveBooks, alias),
		Assets: cacheRemoteName(cacheRoleLiveAssets, alias),
	}
}

func funnelCacheRemoteNames(alias string) aggregateCacheRemoteNames {
	return aggregateCacheRemoteNames{
		Books:  cacheRemoteName(cacheRoleFunnelBooks, alias),
		Assets: cacheRemoteName(cacheRoleFunnelAssets, alias),
	}
}

type cacheRemoteIdentity struct {
	Alias  string
	Role   cacheRemoteRole
	Remote string
}

type cacheRemoteCollision struct {
	Remote string
	Left   cacheRemoteIdentity
	Right  cacheRemoteIdentity
}

func cacheAliasSetFromBytes(data []byte) map[string]bool {
	aliases := make(map[string]bool)
	var root map[string]json.RawMessage
	if json.Unmarshal(data, &root) != nil {
		return aliases
	}
	for alias, raw := range root {
		var value map[string]json.RawMessage
		if json.Unmarshal(raw, &value) == nil {
			aliases[alias] = true
		}
	}
	return aliases
}

func cacheRemoteIdentities(alias string) []cacheRemoteIdentity {
	out := make([]cacheRemoteIdentity, 0, len(reclaimRemoteVariants))
	for _, variant := range reclaimRemoteVariants {
		out = append(out, cacheRemoteIdentity{
			Alias:  alias,
			Role:   variant.Role,
			Remote: variant.Prefix + alias + variant.Suffix,
		})
	}
	return out
}

func isAssetsRole(role cacheRemoteRole) bool {
	return role == cacheRoleLiveAssets || role == cacheRoleFunnelAssets
}

func assetsCacheRemoteCollisions(aliases map[string]bool) []cacheRemoteCollision {
	var names []string
	for alias := range aliases {
		names = append(names, alias)
	}
	sort.Strings(names)

	seen := make(map[string][]cacheRemoteIdentity)
	var out []cacheRemoteCollision
	for _, alias := range names {
		for _, identity := range cacheRemoteIdentities(alias) {
			for _, prior := range seen[identity.Remote] {
				if !isAssetsRole(prior.Role) && !isAssetsRole(identity.Role) {
					continue
				}
				out = append(out, cacheRemoteCollision{Remote: identity.Remote, Left: prior, Right: identity})
			}
			seen[identity.Remote] = append(seen[identity.Remote], identity)
		}
	}
	sort.Slice(out, func(i, j int) bool {
		if out[i].Remote != out[j].Remote {
			return out[i].Remote < out[j].Remote
		}
		if out[i].Left.Alias != out[j].Left.Alias {
			return out[i].Left.Alias < out[j].Left.Alias
		}
		return out[i].Right.Alias < out[j].Right.Alias
	})
	return out
}

func validateAssetsCacheRemoteCollisions(aliases map[string]bool, targetAlias string) error {
	for _, collision := range assetsCacheRemoteCollisions(aliases) {
		if collision.Left.Alias != targetAlias && collision.Right.Alias != targetAlias {
			continue
		}
		return fmt.Errorf("alias %q cannot use cache remote %q: %s for alias %q collides with %s for alias %q",
			targetAlias, collision.Remote,
			collision.Left.Role, collision.Left.Alias,
			collision.Right.Role, collision.Right.Alias)
	}
	return nil
}

func validateSavedAssetsCacheRemoteCollisions(targetAlias string) error {
	aliases := cacheAliasSetFromBytes(loadActionAliases())
	if targetAlias != "" {
		aliases[targetAlias] = true
	}
	return validateAssetsCacheRemoteCollisions(aliases, targetAlias)
}

func remoteNameCandidates(remoteName string) []string {
	var out []string
	seen := make(map[string]bool)
	for _, variant := range reclaimRemoteVariants {
		rest, ok := strings.CutPrefix(remoteName, variant.Prefix)
		if !ok || rest == "" {
			continue
		}
		if variant.Suffix != "" {
			if !strings.HasSuffix(rest, variant.Suffix) {
				continue
			}
			rest = strings.TrimSuffix(rest, variant.Suffix)
		}
		if rest != "" && !seen[rest] {
			seen[rest] = true
			out = append(out, rest)
		}
	}
	return out
}

// aliasLoadFailureReason describes WHY the alias set could not be loaded,
// so the operator is told the truth about which situation they are in.
//
// Deletion fails closed either way and that is deliberate: an absent alias
// store makes every cache tree look unowned, which is exactly the state in
// which deleting them would be most destructive and least justified. The
// distinction here is reporting only — never a licence to delete.
func aliasLoadFailureReason() string {
	if _, err := os.Stat(savedActionAliases); os.IsNotExist(err) {
		return "no alias store on this machine yet (nothing has been saved)"
	}
	return "action_aliases.json unreadable"
}

func strictLoadAliasSet() (map[string]bool, error) {
	data, err := tryLoadActionAliases()
	if err != nil {
		return nil, err
	}
	var all map[string]json.RawMessage
	if err := json.Unmarshal(data, &all); err != nil {
		return nil, err
	}
	set := make(map[string]bool, len(all))
	for name := range all {
		set[name] = true
	}
	return set, nil
}

type sizeBudget struct {
	MaxEntries int
	MaxTime    time.Duration
}

var defaultSizeBudget = sizeBudget{MaxEntries: 500_000, MaxTime: 10 * time.Second}

type walkBudgetState struct {
	deadline time.Time
	entries  int
}

func (b sizeBudget) newState() *walkBudgetState {
	return &walkBudgetState{deadline: time.Now().Add(b.MaxTime)}
}

func walkSize(roots []string, budget sizeBudget, state *walkBudgetState) (total int64, lower bool) {
	if state == nil {
		state = budget.newState()
	}
	deadline := state.deadline
	for _, root := range roots {
		if root == "" {
			continue
		}
		_ = filepath.WalkDir(root, func(path string, d fs.DirEntry, err error) error {
			if err != nil {
				return nil
			}
			state.entries++
			if state.entries > budget.MaxEntries || time.Now().After(deadline) {
				lower = true
				return fs.SkipAll
			}
			if d.Type().IsRegular() {
				if info, ierr := d.Info(); ierr == nil {
					total += info.Size()
				}
			}
			return nil
		})
		if lower {
			return total, true
		}
	}
	return total, false
}

type cacheScanResult struct {
	Trees               []cacheTreeInfo
	AliasesOK           bool
	LedgerOK            bool
	RenameIntentPresent bool
	RetainedJSONL       []string
}

func scanCacheTrees(budget sizeBudget) (*cacheScanResult, error) {
	res := &cacheScanResult{}

	aliases, aerr := strictLoadAliasSet()
	res.AliasesOK = aerr == nil
	if aliases == nil {
		aliases = map[string]bool{}
	}

	records, malformed, lerr := readLedger()
	if lerr != nil {
		return nil, fmt.Errorf("cache reclaim: read ledger: %w", lerr)
	}
	res.LedgerOK = !malformed
	view := replayLedger(records)

	if _, err := os.Stat(renameIntentPath()); err == nil {
		res.RenameIntentPresent = true
	}

	cacheDir := accorderCacheDir()
	names := make(map[string]*cacheTreeInfo)
	scanHalf := func(sub string, markVFS bool) error {
		entries, err := os.ReadDir(filepath.Join(cacheDir, sub))
		if err != nil {
			if os.IsNotExist(err) {
				return nil
			}
			return err
		}
		for _, e := range entries {
			name := e.Name()
			t := names[name]
			if t == nil {
				t = &cacheTreeInfo{RemoteName: name}
				names[name] = t
			}

			if !e.IsDir() || e.Type()&fs.ModeSymlink != 0 || !strings.HasPrefix(name, "accorder-") {
				t.Class = treeForeign
			}
			if markVFS {
				t.HasVFS = true
			} else {
				t.HasMeta = true
			}
		}
		return nil
	}
	if err := scanHalf("vfs", true); err != nil {
		return nil, err
	}
	if err := scanHalf("vfsMeta", false); err != nil {
		return nil, err
	}

	walkState := budget.newState()

	for _, t := range names {
		if t.Class == treeForeign {
			res.Trees = append(res.Trees, *t)
			continue
		}
		for _, cand := range remoteNameCandidates(t.RemoteName) {
			if aliases[cand] {
				t.Candidates = append(t.Candidates, cand)
			}
		}
		if len(t.Candidates) > 0 {
			t.Class = treeOwned

			if res.LedgerOK && len(view.activeRoots[t.RemoteName]) > 1 {
				for root := range view.activeRoots[t.RemoteName] {
					t.DriftRoots = append(t.DriftRoots, root)
				}
				sort.Strings(t.DriftRoots)
			}
		} else if res.LedgerOK && view.knownRemotes[t.RemoteName] {
			t.Class = treeStrandedLedgered
		} else {

			t.Class = treeStrandedLegacy
		}
		if t.Class == treeStrandedLedgered || t.Class == treeStrandedLegacy {
			var roots []string
			if t.HasVFS {
				roots = append(roots, t.vfsPath())
			}
			if t.HasMeta {
				roots = append(roots, t.metaPath())
			}
			t.SizeBytes, t.SizeIsLowerBound = walkSize(roots, budget, walkState)
		}
		res.Trees = append(res.Trees, *t)
	}
	sort.Slice(res.Trees, func(i, j int) bool { return res.Trees[i].RemoteName < res.Trees[j].RemoteName })

	entries, err := os.ReadDir(cacheDir)
	if err == nil {
		for _, e := range entries {
			name := e.Name()
			if e.IsDir() || !strings.HasSuffix(name, ".jsonl") {
				continue
			}
			alias := strings.TrimSuffix(name, ".jsonl")
			if !aliases[alias] {
				res.RetainedJSONL = append(res.RetainedJSONL, filepath.Join(cacheDir, name))
			}
		}
		sort.Strings(res.RetainedJSONL)
	}
	return res, nil
}

func formatByteSize(n int64) string {
	const unit = 1024
	if n < unit {
		return fmt.Sprintf("%dB", n)
	}
	div, exp := int64(unit), 0
	for m := n / unit; m >= unit; m /= unit {
		div *= unit
		exp++
	}
	return fmt.Sprintf("%.1f%ci", float64(n)/float64(div), "KMGTPE"[exp])
}

func (t cacheTreeInfo) sizeString() string {
	s := formatByteSize(t.SizeBytes)
	if t.SizeIsLowerBound {
		return "≥" + s
	}
	return s
}

func logCacheInventory(commandName string) {
	scan, err := scanCacheTrees(defaultSizeBudget)
	if err != nil {
		log.Printf("%s: cache inventory unavailable: %v", commandName, err)
		return
	}
	var stranded []cacheTreeInfo
	for _, t := range scan.Trees {
		if t.Class == treeStrandedLedgered || t.Class == treeStrandedLegacy {
			stranded = append(stranded, t)
		}
		if len(t.DriftRoots) > 1 {
			log.Printf("%s: cache inventory: remote %s has %d ledgered roots (%s) — a bucket/prefix change left a stale subtree; report-only",
				commandName, t.RemoteName, len(t.DriftRoots), strings.Join(t.DriftRoots, ", "))
		}
	}
	if len(stranded) == 0 && !scan.RenameIntentPresent {
		return
	}
	for _, t := range stranded {
		log.Printf("%s: cache inventory: stranded tree vfs/%s (%s, %s) — run 'accorder config prune' for details",
			commandName, t.RemoteName, t.sizeString(), t.Class)
	}
	if scan.RenameIntentPresent {
		log.Printf("%s: cache inventory: an interrupted cache-tree migration left an intent marker — run 'accorder config prune --apply-cache-trees' to reconcile", commandName)
	}
}

func serveCacheStartup(commandName, remoteName, remoteRoot string) (release func(), err error) {
	return serveCacheStartupMany(commandName, []cacheTreeIdentity{{RemoteName: remoteName, RemoteRoot: remoteRoot}})
}

type cacheTreeIdentity struct {
	RemoteName string
	RemoteRoot string
}

func serveCacheStartupMany(commandName string, identities []cacheTreeIdentity) (release func(), err error) {
	logCacheInventory(commandName)
	if !reclaimActivated() {
		log.Printf("%s: cache reclaim protocol not activated — stranded-tree deletion and dict reaping stay report-only (activate with 'accorder config prune --apply-cache-trees --attest-no-serves' once no pre-protocol accorder serve is running)", commandName)
	}
	ordered := append([]cacheTreeIdentity(nil), identities...)
	sort.Slice(ordered, func(i, j int) bool { return ordered[i].RemoteName < ordered[j].RemoteName })
	for i := 1; i < len(ordered); i++ {
		if ordered[i-1].RemoteName == ordered[i].RemoteName {
			return nil, fmt.Errorf("%s: duplicate cache remote name %s", commandName, ordered[i].RemoteName)
		}
	}
	var releases []func()
	releaseAll := func() {
		for i := len(releases) - 1; i >= 0; i-- {
			releases[i]()
		}
	}
	for _, identity := range ordered {
		rel, ok, lockErr := acquireMutationLock(identity.RemoteName, identity.RemoteRoot)
		switch {
		case lockErr != nil && errFlockUnsupportedErr(lockErr):
			log.Printf("%s: file locks unsupported on this platform; running without serve exclusivity proof (destructive reclaim is disabled here)", commandName)
			rel = func() {}
		case lockErr != nil:
			releaseAll()
			return nil, fmt.Errorf("%s: mutation lock for %s: %w", commandName, identity.RemoteName, lockErr)
		case !ok:
			releaseAll()
			return nil, fmt.Errorf("%s: another serve is already running with remote name %s (same alias twice would share one VFS cache tree)", commandName, identity.RemoteName)
		}
		releases = append(releases, rel)
	}
	if err := withGCLock(func() error {
		records := make([]ledgerRecord, 0, len(ordered))
		for _, identity := range ordered {
			records = append(records, ledgerRecord{Type: "serve-start", Remote: identity.RemoteName, Root: identity.RemoteRoot, Cmd: commandName})
		}
		return appendLedgerRecords(records)
	}); err != nil {
		releaseAll()
		return nil, fmt.Errorf("%s: identity ledger: %w", commandName, err)
	}
	return releaseAll, nil
}

func errFlockUnsupportedErr(err error) bool {
	return err != nil && strings.Contains(err.Error(), errFlockUnsupported.Error())
}

func destructiveReclaimAllowed() (bool, string) {
	if !platformLocksWork() {
		return false, "file locks unsupported on this platform — destructive reclaim is permanently report-only here"
	}
	if !reclaimActivated() {
		return false, "reclaim protocol not activated — run once with --apply-cache-trees --attest-no-serves after stopping every pre-protocol serve"
	}
	return true, ""
}

func deleteStrandedTree(t cacheTreeInfo, attested bool) (bool, string, error) {
	if ok, why := destructiveReclaimAllowed(); !ok {
		return false, why, nil
	}
	if t.Class == treeStrandedLegacy && !attested {
		return false, "legacy (pre-ledger) tree — deletion additionally requires --attest-no-serves", nil
	}
	if !validRemoteName(t.RemoteName) {
		return false, "remote name failed validation", nil
	}
	rel, ok, err := acquireMutationLock(t.RemoteName, "")
	if err != nil {
		return false, "", fmt.Errorf("mutation lock %s: %w", t.RemoteName, err)
	}
	if !ok {
		return false, "mutation lock contended — a serve appears to be running on this remote name", nil
	}
	defer rel()

	deleted := false
	var reason string
	err = withAliasConfigLock(func() error {

		aliases, aerr := strictLoadAliasSet()
		if aerr != nil {
			reason = aliasLoadFailureReason() + " — all deletion fails closed"
			return nil
		}
		for _, cand := range remoteNameCandidates(t.RemoteName) {
			if aliases[cand] {
				reason = fmt.Sprintf("alias %q now exists — tree became owned since the scan", cand)
				return nil
			}
		}
		vfsGone, metaGone := true, true
		if t.HasVFS {
			if rerr := os.RemoveAll(t.vfsPath()); rerr != nil {
				vfsGone = false
				reason = fmt.Sprintf("vfs half not fully removed: %v", rerr)
			}
		}
		if t.HasMeta {
			if rerr := os.RemoveAll(t.metaPath()); rerr != nil {
				metaGone = false
				if reason == "" {
					reason = fmt.Sprintf("vfsMeta half not fully removed: %v", rerr)
				}
			}
		}

		if vfsGone && metaGone {
			deleted = true
			records, malformed, lerr := readLedger()
			if lerr == nil && !malformed {
				view := replayLedger(records)
				for root := range view.activeRoots[t.RemoteName] {
					if gerr := withGCLock(func() error {
						return appendLedgerRecord(ledgerRecord{Type: "delete", Remote: t.RemoteName, Root: root, Cmd: "config prune"})
					}); gerr != nil {
						return fmt.Errorf("tombstone %s:%s: %w", t.RemoteName, root, gerr)
					}
				}
			}
		}
		return nil
	})
	return deleted, reason, err
}

func cacheRotFindings(scan *cacheScanResult) []rotFinding {
	if scan == nil {
		return nil
	}
	var out []rotFinding
	for _, t := range scan.Trees {
		if t.Class != treeStrandedLedgered && t.Class != treeStrandedLegacy {
			continue
		}
		halves := "vfs + vfsMeta"
		switch {
		case t.HasVFS && !t.HasMeta:
			halves = "vfs only — half pair"
		case !t.HasVFS && t.HasMeta:
			halves = "vfsMeta only — half pair"
		}
		reason := fmt.Sprintf("%s, %s; no configured alias owns this remote name", t.Class, halves)
		if !scan.AliasesOK {
			reason += "; " + aliasLoadFailureReason() + " — deletion fails closed"
		}
		out = append(out, rotFinding{
			File:   "cache",
			Alias:  "vfs/" + t.RemoteName,
			Kind:   rotStaleCacheTree,
			Value:  t.sizeString(),
			Reason: reason,
		})
	}
	for _, path := range scan.RetainedJSONL {
		out = append(out, rotFinding{
			File:   "cache",
			Alias:  filepath.Base(path),
			Kind:   rotRetainedAliasJSONL,
			Value:  path,
			Reason: "build snapshot for a deleted alias — may be the only catalog source; never auto-deleted",
		})
	}
	return out
}

func reportCacheScanNotes(scan *cacheScanResult) {
	for _, t := range scan.Trees {
		if len(t.DriftRoots) > 1 {
			fmt.Printf("  note: remote %s has %d ledgered roots (%s) — a bucket/prefix change left a stale subtree; report-only, reclaimable once the whole remote name is orphaned\n",
				t.RemoteName, len(t.DriftRoots), strings.Join(t.DriftRoots, ", "))
		}
	}
	if scan.RenameIntentPresent {
		fmt.Println("  note: an interrupted cache-tree migration left an intent marker — --apply-cache-trees reconciles it first")
	}
}

func (c *AliasPruneCmd) applyCacheTrees(scan *cacheScanResult) error {
	if scan == nil {
		return nil
	}
	if ok, why := destructiveReclaimAllowed(); !ok && !c.AttestNoServes {
		fmt.Printf("Cache trees: nothing deleted — %s\n", why)
		return nil
	}

	if c.AttestNoServes {
		if err := withGCLock(writeActivationMarker); err != nil {
			return fmt.Errorf("config prune: activation marker: %w", err)
		}
	}
	if ok, why := destructiveReclaimAllowed(); !ok {
		fmt.Printf("Cache trees: nothing deleted — %s\n", why)
		return nil
	}

	if handled, err := reconcileRenameIntent(); err != nil {
		return fmt.Errorf("config prune: %v — filesystem apply branch aborted", err)
	} else if handled {
		fmt.Println("Reconciled an interrupted cache-tree migration.")
		rescanned, rerr := scanCacheTrees(defaultSizeBudget)
		if rerr != nil {
			return rerr
		}
		scan = rescanned
	}
	if !scan.AliasesOK {
		fmt.Printf("Cache trees: nothing deleted — %s, all deletion fails closed.\n", aliasLoadFailureReason())
		return nil
	}
	var reclaimed int64
	deleted, kept := 0, 0
	for _, t := range scan.Trees {
		if t.Class != treeStrandedLedgered && t.Class != treeStrandedLegacy {
			continue
		}
		ok, why, err := deleteStrandedTree(t, c.AttestNoServes)
		if err != nil {
			return fmt.Errorf("config prune: %w — filesystem apply branch aborted", err)
		}
		if ok {
			deleted++
			reclaimed += t.SizeBytes
			fmt.Printf("Reclaimed vfs/%s + vfsMeta/%s (%s).\n", t.RemoteName, t.RemoteName, t.sizeString())
		} else {
			kept++
			fmt.Printf("Kept %s: %s\n", t.RemoteName, why)
		}
	}
	if c.AttestNoServes {
		if bytes, n := reapLegacyDictsAttested(accorderCacheDir()); n > 0 {
			reclaimed += bytes
			fmt.Printf("Reclaimed %d legacy typeahead dict(s) (%s).\n", n, formatByteSize(bytes))
		}
	}
	fmt.Printf("Cache trees: %d deleted, %d kept, %s reclaimed.\n", deleted, kept, formatByteSize(reclaimed))
	return nil
}
