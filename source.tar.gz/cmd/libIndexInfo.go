package cmd

import (
	"accorder/pkg/calibre"
	"encoding/hex"
	"fmt"
	"os"
	"strings"
)

type LibIndexInfoCmd struct {
	CommonCommandFields
	IndexPath string `name:"index-path" json:"index-path" help:"Path to the search index (without .zst extension)." validate:"required,filepath" sharedgroup:"lib"`
	TeaOutputs
}

func (c *LibIndexInfoCmd) Run() error {
	c.Header = ".◟◜calibre index-info◝◞."
	if c.HandleShowConfig(c) {
		return nil
	}

	indexPath := strings.TrimSuffix(c.IndexPath, ".zst")
	zstPath := indexPath + ".zst"

	fi, err := os.Stat(zstPath)
	if err != nil {
		return fmt.Errorf("stat %s: %w", zstPath, err)
	}
	mf, err := calibre.ReadExistingManifest(indexPath)
	if err != nil {
		return fmt.Errorf("read manifest: %w", err)
	}

	liveBooks := int64(mf.NumBooks) - int64(len(mf.Tombstones))
	if liveBooks < 0 {
		liveBooks = 0
	}

	fmt.Printf("Index:           %s\n", zstPath)
	fmt.Printf("File size:       %d bytes (%.1f KiB)\n", fi.Size(), float64(fi.Size())/1024)
	fmt.Printf("BaseGeneration:  %s\n", hex.EncodeToString(mf.BaseGeneration[:]))
	fmt.Printf("Generation:      %d\n", mf.Generation)
	fmt.Printf("Regions:         %d\n", len(mf.Regions))
	fmt.Printf("Books (total):   %d\n", mf.NumBooks)
	fmt.Printf("Books (live):    %d  (after tombstones)\n", liveBooks)
	fmt.Printf("Segments:        %d\n", mf.NumSegments)
	fmt.Printf("Tombstones:      %d\n", len(mf.Tombstones))
	fmt.Printf("ChunkSize:       %d\n", mf.ChunkSize)

	if shouldHintCompact(mf) {
		fmt.Printf("\nhint: %d regions, %d tombstones — `accorder lib build %s --index --compact` would GC dead bytes.\n",
			len(mf.Regions), len(mf.Tombstones), c.ActionAlias)
	}
	return nil
}
