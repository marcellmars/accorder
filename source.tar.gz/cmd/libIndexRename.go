package cmd

import (
	"accorder/pkg/calibre"
	"fmt"
)

type LibIndexRenameCmd struct {
	OldName string `arg:"" help:"Current source name."`
	NewName string `arg:"" help:"New source name."`
}

func (c *LibIndexRenameCmd) Run() error {
	newSlug := calibre.SlugifySourceName(c.NewName)
	if newSlug == "" {
		return fmt.Errorf("new name %q normalizes to empty", c.NewName)
	}
	return registryRename(c.OldName, newSlug)
}
