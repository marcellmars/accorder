package cmd

import "accorder/pkg/torinvite"

var browseTorDialFn func(inv *torinvite.InviteV2, alias, configDir string) (
	socksAddr string, cleanup func(), err error,
)
