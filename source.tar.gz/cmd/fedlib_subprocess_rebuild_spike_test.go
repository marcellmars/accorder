//go:build !tailscale

package cmd

import (
	"bytes"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/tidwall/gjson"
)

// ===========================================================================
// Phase 0 spike: subprocess-aggregate-rebuild
// (.sit/workflows/2026-06-12_subprocess-aggregate-rebuild/study.md, Phase 7)
//

// Assumption 1: a child-shaped `fedlib build` invocation with secrets via
// env (S3_ACCESS_KEY/S3_SECRET_KEY) and provider/endpoint/bucket via argv
// fully resolves creds through resolveOperatorS3Creds (cmd/keysFile.go:85,
// wired for route fedlib.build in cmd/cli.go:264-265) and passes validation.
//

// Assumption 2: a child-shaped invocation with NO alias positional (the
// scripts/deploy-motw-fedlib.sh:62-65 shape) has no action-alias config
// load/merge/persist side effects.
//

// Code-reading hazard for assumption 2: CommonCommandFields.ActionAlias
// (cmd/commonFields.go:8) carries default:"default", so the alias=="" early
// return in CLI.AfterApply (cmd/cli.go:194-196) never fires. These tests
// pin the actual behavior.
//

// No network: only kong parse + AfterApply run; FedlibBuildCmd.Run() is
// never called.
// ===========================================================================

// childArgs returns the deploy-script-shaped argv (no alias positional).
func childArgs(outputPath string, extra ...string) []string {
	args := []string{
		"fedlib", "build",
		"--output-path", outputPath,
		"--upload-prefix", "aggregate",
	}
	return append(args, extra...)
}

// Assumption 1, env variant: secrets via env, non-secrets via argv.
func TestSpike_ChildEnvCredsResolveThroughAfterApply(t *testing.T) {
	_ = testSetup(t)
	t.Setenv("S3_ACCESS_KEY", "AKIAENVSPIKE")
	t.Setenv("S3_SECRET_KEY", "env-secret-spike")

	outputPath := t.TempDir()
	cli, _, err := parseCLIErr(t, childArgs(outputPath,
		"--bucket", "motw",
		"--s3-provider", "Wasabi",
		"--s3-endpoint", "https://s3.wasabisys.com",
	))
	if err != nil {
		t.Fatalf("REFUTED: child-shaped parse with env secrets failed AfterApply/validation: %v", err)
	}

	b := &cli.Fedlib.Build
	if b.ActionAlias != "default" {
		t.Errorf("ActionAlias = %q, expected %q (default:\"default\" tag)", b.ActionAlias, "default")
	}
	if b.S3AccessKey != "AKIAENVSPIKE" || b.S3SecretKey != "env-secret-spike" {
		t.Fatalf("REFUTED: env creds not resolved: access=%q secret=%q", b.S3AccessKey, b.S3SecretKey)
	}
	if err := b.RequireS3Creds(); err != nil {
		t.Fatalf("REFUTED: RequireS3Creds (Run-time gate for rclone members) fails: %v", err)
	}
	t.Logf("CONFIRMED: env-injected secrets + argv non-secrets fully resolve and pass validation (alias %q)", b.ActionAlias)

	// Side-effect probe: provider/endpoint argv flags set credProvided=true in
	// resolveOperatorS3Creds (keysFile.go:106-112), triggering keys-file
	// write-back (keysFile.go:137-149) — which persists the ENV-injected
	// secret to disk.
	keysPath := defaultKeysFilePath("default")
	if data, err := os.ReadFile(keysPath); err == nil {
		if strings.Contains(string(data), "env-secret-spike") {
			t.Logf("FINDING: env-injected secret was written back to %s (argv provider/endpoint => credProvided=true)", keysPath)
		} else {
			t.Logf("keys-file written but without env secret:\n%s", data)
		}
	} else {
		t.Logf("no keys-file write-back at %s: %v", keysPath, err)
	}
}

// Assumption 1, --keys-file variant: all creds from an explicit keys-file.
func TestSpike_ChildKeysFileCredsResolve(t *testing.T) {
	_ = testSetup(t)
	t.Setenv("S3_ACCESS_KEY", "")
	t.Setenv("S3_SECRET_KEY", "")

	kfPath := filepath.Join(t.TempDir(), "child.s3.keys")
	if err := writeKeysFile(kfPath, s3KeysFile{
		AccessKey: "AKIAKEYSFILE",
		SecretKey: "keysfile-secret",
		Provider:  "Wasabi",
		Endpoint:  "https://s3.wasabisys.com",
		Bucket:    "motw/aggregate",
	}); err != nil {
		t.Fatalf("writeKeysFile: %v", err)
	}

	outputPath := t.TempDir()
	cli, _, err := parseCLIErr(t, childArgs(outputPath, "--keys-file", kfPath))
	if err != nil {
		t.Fatalf("REFUTED: child-shaped parse with --keys-file failed: %v", err)
	}

	b := &cli.Fedlib.Build
	if b.S3AccessKey != "AKIAKEYSFILE" || b.S3SecretKey != "keysfile-secret" ||
		b.S3Provider != "Wasabi" || b.S3Endpoint != "https://s3.wasabisys.com" ||
		b.Bucket != "motw/aggregate" {
		t.Fatalf("REFUTED: keys-file fields not fully resolved: %+v", b)
	}
	if err := b.RequireS3Creds(); err != nil {
		t.Fatalf("REFUTED: RequireS3Creds fails after keys-file resolution: %v", err)
	}
	if _, err := os.Stat(defaultKeysFilePath("default")); !os.IsNotExist(err) {
		t.Errorf("unexpected write-back to default keys-file (no argv creds were provided)")
	}
	t.Logf("CONFIRMED: --keys-file resolves all 5 S3 fields (incl. bucket) with no default-keys-file write-back")
}

// Assumption 2, arm A: does the alias-free child shape leave
// action_aliases.json untouched? REFUTED (spike run 2026-06-12): the
// default:"default" tag means the alias machinery runs in full — the
// invocation persists output-path/bucket/upload-prefix under alias
// "default". Secrets do NOT leak (alias:"-" on the cred fields). This test
// pins the observed behavior.
func TestSpike_ChildAliasFreePersistsDefaultAlias(t *testing.T) {
	_ = testSetup(t)
	before, _ := os.ReadFile(savedActionAliases)

	outputPath := t.TempDir()
	_, _, err := parseCLIErr(t, childArgs(outputPath,
		"--bucket", "motw",
		"--s3-access-key", "AKIAARGVSPIKE",
		"--s3-secret-key", "argv-secret-spike",
		"--s3-provider", "Wasabi",
		"--s3-endpoint", "https://s3.wasabisys.com",
	))
	if err != nil {
		t.Fatalf("child-shaped parse failed: %v", err)
	}

	after, _ := os.ReadFile(savedActionAliases)
	if bytes.Equal(before, after) {
		t.Fatalf("behavior changed: action_aliases.json untouched by alias-free invocation (spike observed mutation under alias \"default\")")
	}

	saved := gjson.GetBytes(after, "default.fedlib.build")
	t.Logf("REFUTED (pinned): alias-free invocation mutated action_aliases.json under alias \"default\": %s", saved.Raw)
	for _, key := range []string{"output-path", "bucket", "upload-prefix"} {
		if !saved.Get(key).Exists() {
			t.Errorf("expected %q persisted under default.fedlib.build, got: %s", key, saved.Raw)
		}
	}
	for _, key := range []string{"s3-access-key", "s3-secret-key"} {
		if saved.Get(key).Exists() {
			t.Errorf("SECRET %q leaked into action_aliases.json", key)
		}
	}
}

// Assumption 2, arm B: stale flags saved under alias "default" merge into a
// later alias-free child invocation that did not provide them. REFUTED
// (spike run 2026-06-12): a seeded default.fedlib.build.bucket overrides the
// child's empty --bucket. The serve-spawned child MUST pass every flag it
// cares about explicitly, or hidden "default" alias state alters the build.
func TestSpike_ChildAliasFreeMergesStaleDefaultFlags(t *testing.T) {
	_ = testSetup(t)
	seed := []byte(`{"default":{"fedlib":{"build":{"bucket":"stale-bucket"}}}}`)
	if err := os.WriteFile(savedActionAliases, seed, 0o644); err != nil {
		t.Fatalf("seed aliases: %v", err)
	}

	outputPath := t.TempDir()

	// No --bucket on the child argv; creds via argv to keep validation green.
	cli, _, err := parseCLIErr(t, childArgs(outputPath,
		"--s3-access-key", "AKIAARGVSPIKE",
		"--s3-secret-key", "argv-secret-spike",
		"--s3-provider", "Wasabi",
		"--s3-endpoint", "https://s3.wasabisys.com",
	))
	if err != nil {
		t.Fatalf("child-shaped parse failed: %v", err)
	}

	if got := cli.Fedlib.Build.Bucket; got != "stale-bucket" {
		t.Fatalf("behavior changed: expected stale saved flag to merge into alias-free child invocation, Bucket=%q", got)
	}
	t.Logf("REFUTED (pinned): stale default.fedlib.build.bucket merged into alias-free child (Bucket=%q)", cli.Fedlib.Build.Bucket)
}
