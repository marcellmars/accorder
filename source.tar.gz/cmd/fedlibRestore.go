package cmd

import (
	"archive/tar"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"

	"github.com/klauspost/compress/zstd"
)

type FedlibRestoreCmd struct {
	Input     string `name:"input" help:"Input tarball path (.tar.zst)." validate:"required"`
	ConfigDir string `name:"config-dir" help:"Target config directory (defaults to accorder config dir)." default:""`
}

func (c *FedlibRestoreCmd) Run() error {
	targetDir := c.ConfigDir
	if targetDir == "" {
		targetDir = accorderConfigDir
	}

	f, err := os.Open(c.Input)
	if err != nil {
		return fmt.Errorf("fedlib restore: open %s: %w", c.Input, err)
	}
	defer f.Close()

	zr, err := zstd.NewReader(f)
	if err != nil {
		return fmt.Errorf("fedlib restore: zstd reader: %w", err)
	}
	defer zr.Close()

	tr := tar.NewReader(zr)

	restored := 0
	var onionAddr string
	var grantCount int

	for {
		hdr, err := tr.Next()
		if err == io.EOF {
			break
		}
		if err != nil {
			return fmt.Errorf("fedlib restore: read tar: %w", err)
		}

		clean := filepath.Clean(hdr.Name)
		if strings.HasPrefix(clean, "..") || filepath.IsAbs(clean) {
			return fmt.Errorf("fedlib restore: unsafe path in tarball: %q", hdr.Name)
		}

		dest := filepath.Join(targetDir, clean)

		switch hdr.Typeflag {
		case tar.TypeDir:
			if err := os.MkdirAll(dest, 0o700); err != nil {
				return fmt.Errorf("fedlib restore: mkdir %s: %w", dest, err)
			}
		default:
			return fmt.Errorf("fedlib restore: unexpected tar entry type %d for %s", hdr.Typeflag, clean)
		case tar.TypeReg:
			if err := os.MkdirAll(filepath.Dir(dest), 0o700); err != nil {
				return fmt.Errorf("fedlib restore: mkdir parent %s: %w", dest, err)
			}

			mode := os.FileMode(hdr.Mode) & 0o777
			if mode == 0 {
				mode = 0o600
			}

			data, err := io.ReadAll(tr)
			if err != nil {
				return fmt.Errorf("fedlib restore: read %s: %w", clean, err)
			}

			tmp := dest + ".tmp"
			if err := os.WriteFile(tmp, data, mode); err != nil {
				return fmt.Errorf("fedlib restore: write %s: %w", dest, err)
			}
			if err := os.Rename(tmp, dest); err != nil {
				os.Remove(tmp)
				return fmt.Errorf("fedlib restore: rename %s: %w", dest, err)
			}
			restored++

			base := filepath.Base(clean)
			if base == "hostname" {
				onionAddr = strings.TrimSpace(string(data))
			}
			if base == "grants.json" {
				grantCount += countGrants(data)
			}
		}
	}

	summary := fmt.Sprintf("restored %d files to %s", restored, targetDir)
	if onionAddr != "" {
		summary += fmt.Sprintf("; .onion address: %s", onionAddr)
	}
	if grantCount > 0 {
		summary += fmt.Sprintf("; %d grant(s)", grantCount)
	}
	fmt.Println(summary)
	return nil
}

func countGrants(data []byte) int {
	var grants []struct {
		Revoked bool `json:"revoked"`
	}
	if err := json.Unmarshal(data, &grants); err != nil {
		return 0
	}
	n := 0
	for _, g := range grants {
		if !g.Revoked {
			n++
		}
	}
	return n
}
