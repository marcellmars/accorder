//go:build !tailscale

package cmd

// Tests for the build collapse (narrative-setup-defaults item 5, A1-A4).
// The full cold two-command flow against a real Calibre library rides the
// tag-gated e2e harness (pkg/browselocal); these cover the unit-testable
// pieces: A1 computed defaults, the JSONL-driven index path with defaults,
// A2 wiring, and A4 skip-when-present.

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"net"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"accorder/pkg/calibre"
)

func seedCmdJSONL(t *testing.T, path, libraryID, librarian string, n int) {
	t.Helper()
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		t.Fatal(err)
	}
	f, err := os.Create(path)
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()
	w := bufio.NewWriter(f)
	defer w.Flush()
	for i := 0; i < n; i++ {
		book := calibre.Book{
			Title:        fmt.Sprintf("Book %d", i),
			Authors:      []string{"Author"},
			LastModified: fmt.Sprintf("2024-01-%02dT00:00:00+00:00", (i%28)+1),
			LibraryUUID:  libraryID,
			Librarian:    librarian,
			UUID:         fmt.Sprintf("book-uuid-%d", i),
		}
		data, err := json.Marshal(book)
		if err != nil {
			t.Fatal(err)
		}
		_, _ = w.Write(data)
		_ = w.WriteByte('\n')
	}
}

func TestApplyBuildDefaults(t *testing.T) {
	testSetup(t)

	c := &LibBuildCmd{}
	c.ActionAlias = "myalias"
	c.CalibreDirectory = "/lib/dir"
	c.applyBuildDefaults()
	if want := filepath.Join("/lib/dir", "static", "library_index"); c.IndexPath != want {
		t.Errorf("IndexPath = %q, want %q", c.IndexPath, want)
	}
	if want := filepath.Join(accorderConfigDir, "cache", "myalias.jsonl"); c.JsonLPath != want {
		t.Errorf("JsonLPath = %q, want %q", c.JsonLPath, want)
	}

	// Provided values stay.
	c2 := &LibBuildCmd{}
	c2.CalibreDirectory = "/lib/dir"
	c2.IndexPath = "/explicit/index"
	c2.JsonLPath = "/explicit/books.jsonl"
	c2.applyBuildDefaults()
	if c2.IndexPath != "/explicit/index" || c2.JsonLPath != "/explicit/books.jsonl" {
		t.Errorf("explicit paths clobbered: %q %q", c2.IndexPath, c2.JsonLPath)
	}
}

func TestBuildCollapse_DefaultsNotPersistedToAlias(t *testing.T) {
	libDir := testSetup(t)

	// Parse persists only provided flags; A1 defaults are computed in Run.
	parseCLI(t, []string{"lib", "build", "defaults", "--calibrepath=" + libDir})
	alias := readAlias(t, "defaults")
	if alias.Get("lib.build.index-path").Exists() {
		t.Error("computed index-path leaked into action_aliases.json")
	}
	if alias.Get("lib.build.jsonl-path").Exists() {
		t.Error("computed jsonl-path leaked into action_aliases.json")
	}
}

func TestBuildCollapse_IndexFromJsonlWithDefaultPaths(t *testing.T) {
	libDir := testSetup(t)

	// JSONL fixture sits at the A1 default cache path for this alias.
	jsonlPath := filepath.Join(accorderConfigDir, "cache", "collapse.jsonl")
	seedCmdJSONL(t, jsonlPath, mintTestUUID, "Alice", 10)

	build := &LibBuildCmd{}
	build.ActionAlias = "collapse"
	build.CalibreDirectory = libDir
	build.Librarian = "Alice"
	build.LibraryID = mintTestUUID
	build.Index = new(bool) // index-only run; paths defaulted
	if err := build.Run(nil); err != nil {
		t.Fatalf("lib build --index with defaults: %v", err)
	}

	// Index landed at the A1 default location.
	indexZst := filepath.Join(libDir, "static", "library_index.zst")
	if _, err := os.Stat(indexZst); err != nil {
		t.Errorf("expected index at default path %s: %v", indexZst, err)
	}
}

// The DictID collision guard must fire on BARE federation-member builds too:
// since build collapse A3, a bare build compiles the index, so a member build
// without a unique DictID would land a colliding index at aggregate compose.
func TestBuildCollapse_BareMemberBuildRequiresDictID(t *testing.T) {
	libDir := testSetup(t)

	build := &LibBuildCmd{}
	build.ActionAlias = "collapse-guard"
	build.CalibreDirectory = libDir
	build.Librarian = "Alice"
	build.LibraryID = mintTestUUID
	build.FedlibPrefix = "alice"

	// Index deliberately nil: bare build.
	err := build.Run(nil)
	if err == nil {
		t.Fatal("bare federation-member build without --dictID must be refused")
	}
	if !strings.Contains(err.Error(), "--dictID") {
		t.Fatalf("expected DictID guard error, got: %v", err)
	}
}

func TestBuildCollapse_A2MissingJsonlTriggersExport(t *testing.T) {
	libDir := testSetup(t)

	// No JSONL at the default path and no metadata.db in libDir: the A2
	// export must fire (and fail at book loading) — proving the wiring
	// runs the export before the index build instead of erroring on a
	// missing JSONL file.
	build := &LibBuildCmd{}
	build.ActionAlias = "a2"
	build.CalibreDirectory = libDir
	build.Librarian = "Alice"
	build.LibraryID = mintTestUUID
	build.Index = new(bool)
	err := build.Run(nil)
	if err == nil {
		t.Fatal("expected error (no metadata.db), got nil")
	}
	if !strings.Contains(err.Error(), "load books for JSONL export") {
		t.Errorf("expected A2 export attempt, got: %v", err)
	}
}

func TestShareLive_EnsureLocalIndexSkipsWhenPresent(t *testing.T) {
	libDir := testSetup(t)

	indexPath := filepath.Join(libDir, "static", "library_index")
	if err := os.MkdirAll(filepath.Dir(indexPath), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(indexPath+".zst", []byte("stub"), 0o644); err != nil {
		t.Fatal(err)
	}

	c := &LibShareLiveCmd{}
	c.CalibreDirectory = libDir
	c.IndexPath = indexPath

	// Building would fail (no metadata.db) — success implies skip.
	if err := c.ensureLocalIndex(nil); err != nil {
		t.Errorf("ensureLocalIndex with existing index should skip build: %v", err)
	}
}

func TestBuildCollapse_SelfBuildUnknownToExistingMotwLibraries(t *testing.T) {
	libDir := testSetup(t)

	// A pre-existing motw_libraries.json that does NOT contain this
	// build's libraryID (the live-share regression: a freshly minted
	// browse alias built on a machine with older libraries registered).
	foreign := `{"00000000-0000-0000-0000-00000000beef":{"librarian":"Else","state":"ready"}}`
	if err := os.WriteFile(filepath.Join(accorderConfigDir, "motw_libraries.json"), []byte(foreign), 0644); err != nil {
		t.Fatalf("write motw_libraries.json: %v", err)
	}

	jsonlPath := filepath.Join(accorderConfigDir, "cache", "selfknown.jsonl")
	seedCmdJSONL(t, jsonlPath, mintTestUUID, "Alice", 5)

	build := &LibBuildCmd{}
	build.ActionAlias = "selfknown"
	build.CalibreDirectory = libDir
	build.Librarian = "Alice"
	build.LibraryID = mintTestUUID
	build.Index = new(bool)
	if err := build.Run(nil); err != nil {
		t.Fatalf("self-build with foreign motw_libraries.json: %v", err)
	}
	if _, err := os.Stat(filepath.Join(libDir, "static", "library_index.zst")); err != nil {
		t.Errorf("expected index built: %v", err)
	}
}

// Friend share info: plain sectioned text with ~ ~ ~ ~ separators —
// onion direct link, accorder-to-accorder browse command with offline
// index size, invite-only documentation pointer.

func TestFriendShareInfo_PublicDualTransports(t *testing.T) {
	saved := startTorFn
	startTorFn = func(ctx context.Context, localAddr, alias, configDir string) (string, func() error, error) {
		return "", nil, nil
	}
	defer func() { startTorFn = saved }()

	dir := t.TempDir()
	idx := filepath.Join(dir, "library_index")
	if err := os.WriteFile(idx+".zst", make([]byte, 3*1024*1024), 0644); err != nil {
		t.Fatalf("seed index: %v", err)
	}

	c := &LibShareLiveCmd{}
	c.ActionAlias = "cli-test"

	// A reachable bind, so the pasteable command renders (loopback suppresses it).
	c.Listen = "192.168.1.24:8724"
	c.Mode = "public"
	c.IndexPath = idx
	c.Librarian = "alice"
	c.LibraryName = "Alice's Library"

	got := strings.Join(c.friendBrowseHint(OnionAddrs{Single: "abcdef.onion"}, nil), "\n")
	t.Logf("rendered:\n%s", got)
	for _, want := range []string{
		"Share `cli-test` library via Tor:",
		"http://abcdef.onion/",
		"Anyone with this onion address would be able to access the shared library.",
		"`cli-test` is shared on http://192.168.1.24:8724/",

		// Every name in the pasted command is the recipient's own.
		"accorder lib browse local-librarian --from remote-alice --endpoint http://192.168.1.24:8724/",
		"offline index (3.0 MiB)",
		"`accorder lib share grant --help`",
	} {
		if !strings.Contains(got, want) {
			t.Errorf("public dual-transport info missing %q:\n%s", want, got)
		}
	}
	if n := strings.Count(got, "~ ~ ~ ~"); n != 4 {
		t.Errorf("separator count = %d, want 4:\n%s", n, got)
	}

	// The sharer's own alias must never be handed to the recipient as their
	// browse context — that is the defect this hint shape exists to fix.
	if strings.Contains(got, "lib browse cli-test") {
		t.Errorf("recipient command must not carry the sharer's alias:\n%s", got)
	}
}

func TestFriendShareInfo_HTTPOnlyWithoutTor(t *testing.T) {

	// Default build (or --only-http): no tor section, no onion mention.
	c := &LibShareLiveCmd{}
	c.ActionAlias = "cli-test"
	c.Listen = "192.168.1.24:8724"
	c.Mode = "public"
	c.Librarian = "alice"
	c.LibraryName = "Alice's Library"

	got := strings.Join(c.friendBrowseHint(OnionAddrs{}, nil), "\n")
	if strings.Contains(got, "via Tor") {
		t.Errorf("hint should not mention Tor without a running onion:\n%s", got)
	}
	for _, want := range []string{
		"`cli-test` is shared on http://192.168.1.24:8724/",
		"accorder lib browse local-librarian --from remote-alice",
		"select, queue, download, and render into a library of their own",
		"`accorder lib share grant --help`",
	} {
		if !strings.Contains(got, want) {
			t.Errorf("http-only info missing %q:\n%s", want, got)
		}
	}
}

func TestFriendShareInfo_LoopbackKeepsPasteableCommandWithCaveat(t *testing.T) {

	// A loopback bind is unreachable directly, but it is also the normal shape
	// for a tunnel or reverse-proxy front — the pasteable command must survive,
	// framed with what has to change (re-bind, or front the bind and have the
	// friend substitute the public host).
	c := &LibShareLiveCmd{}
	c.ActionAlias = "cli-test"
	c.Listen = "127.0.0.1:8724"
	c.Mode = "public"
	c.Librarian = "alice"
	c.LibraryName = "Alice's Library"

	got := strings.Join(c.friendBrowseHint(OnionAddrs{}, nil), "\n")
	if !strings.Contains(got, "--endpoint http://127.0.0.1:8724/") {
		t.Errorf("loopback bind must still offer the pasteable browse command:\n%s", got)
	}
	if !strings.Contains(got, "--listen 0.0.0.0:") {
		t.Errorf("loopback bind should advise how to re-serve reachably:\n%s", got)
	}
	if !strings.Contains(got, "tunnel or reverse proxy") {
		t.Errorf("loopback bind should mention the tunnel/reverse-proxy path:\n%s", got)
	}
	if !strings.Contains(got, "Replace the host") {
		t.Errorf("loopback bind should advise substituting a reachable host:\n%s", got)
	}
}

func TestFriendShareInfo_SlotsStayDistinctWithoutLibraryName(t *testing.T) {
	// The local-/remote- prefixes name the two slots by the roles they play on
	// the recipient's machine, so they cannot collapse into each other even
	// when nothing but the librarian name is known. No library name here.
	c := &LibShareLiveCmd{}
	c.ActionAlias = "cli-test"
	c.Listen = "192.168.1.24:8724"
	c.Mode = "public"
	c.Librarian = "alice"

	got := strings.Join(c.friendBrowseHint(OnionAddrs{}, nil), "\n")
	if !strings.Contains(got, "accorder lib browse local-librarian --from remote-alice --endpoint") {
		t.Errorf("both slots should be offered even without a library name:\n%s", got)
	}
	// The whole point of the prefixes: the reader must never see the same word
	// in both slots and conclude they are interchangeable.
	if strings.Contains(got, "--from local-") || strings.Contains(got, "browse remote-") {
		t.Errorf("slot prefixes crossed over:\n%s", got)
	}
}

func TestFriendShareInfo_NoLibrarianStillPastes(t *testing.T) {
	// Librarian normally auto-generates, but the line must stay pasteable even
	// if it is somehow empty — never emit a bare "remote-".
	c := &LibShareLiveCmd{}
	c.ActionAlias = "cli-test"
	c.Listen = "192.168.1.24:8724"
	c.Mode = "public"

	got := strings.Join(c.friendBrowseHint(OnionAddrs{}, nil), "\n")
	if strings.Contains(got, "--from remote- ") || strings.Contains(got, "--from remote---endpoint") {
		t.Errorf("empty librarian produced a dangling remote- name:\n%s", got)
	}
	if !strings.Contains(got, "--from remote-library") {
		t.Errorf("expected the neutral remote-library fallback:\n%s", got)
	}
}

func TestFriendShareInfo_UsesBoundAddressOverRequestedListen(t *testing.T) {

	// With --listen :0 the requested port is meaningless; the bound address is
	// what a friend must dial.
	c := &LibShareLiveCmd{}
	c.ActionAlias = "cli-test"
	c.Listen = "192.168.1.24:0"
	c.Mode = "public"
	c.Librarian = "alice"
	c.LibraryName = "Alice's Library"

	bound := &net.TCPAddr{IP: net.ParseIP("192.168.1.24"), Port: 45123}
	got := strings.Join(c.friendBrowseHint(OnionAddrs{}, bound), "\n")
	if !strings.Contains(got, "http://192.168.1.24:45123/") {
		t.Errorf("hint should advertise the bound port, not the requested one:\n%s", got)
	}
	if strings.Contains(got, ":0/") {
		t.Errorf("hint must not advertise the unbound :0 port:\n%s", got)
	}
}

func TestFriendShareInfo_OnlyTorOmitsBrowseCommand(t *testing.T) {
	saved := startTorFn
	startTorFn = func(ctx context.Context, localAddr, alias, configDir string) (string, func() error, error) {
		return "", nil, nil
	}
	defer func() { startTorFn = saved }()

	c := &LibShareLiveCmd{}
	c.ActionAlias = "cli-test"
	c.Listen = "127.0.0.1:8724"
	c.Mode = "public"
	c.OnlyTor = true

	got := strings.Join(c.friendBrowseHint(OnionAddrs{Single: "abcdef.onion"}, nil), "\n")
	if strings.Contains(got, "--endpoint") {
		t.Errorf("only-tor info should not advertise the HTTP browse command:\n%s", got)
	}
	if !strings.Contains(got, "http://abcdef.onion/") {
		t.Errorf("only-tor info missing the onion link:\n%s", got)
	}
}

func TestFriendShareInfo_GatedModes(t *testing.T) {
	saved := startTorFn
	startTorFn = func(ctx context.Context, localAddr, alias, configDir string) (string, func() error, error) {
		return "", nil, nil
	}
	defer func() { startTorFn = saved }()

	mk := func(mode string) *LibShareLiveCmd {
		c := &LibShareLiveCmd{}
		c.ActionAlias = "cli-test"
		c.Listen = "127.0.0.1:8724"
		c.Mode = mode
		return c
	}

	got := strings.Join(mk("private").friendBrowseHint(OnionAddrs{Single: "abcdef.onion"}, nil), "\n")
	if !strings.Contains(got, "the onion address alone is not enough") {
		t.Errorf("private info missing the invite explanation:\n%s", got)
	}
	if strings.Contains(got, "Anyone with this onion address would be able to access") {
		t.Errorf("private info must not claim open access:\n%s", got)
	}
	if !strings.Contains(got, "`accorder lib share revoke-grant --help`") {
		t.Errorf("gated footer should point at invite management:\n%s", got)
	}

	got = strings.Join(mk("offline-private").friendBrowseHint(OnionAddrs{Browser: "brw.onion", Index: "idx.onion"}, nil), "\n")
	if !strings.Contains(got, "http://brw.onion/") {
		t.Errorf("offline-private should use the public browser onion:\n%s", got)
	}
	if !strings.Contains(got, "invite-only") {
		t.Errorf("offline-private should explain the gated index/files:\n%s", got)
	}
}
