package cmd

import (
	"context"
	"errors"
	"os/exec"
	"reflect"
	"runtime"
	"slices"
	"strings"
	"testing"
	"time"
)

// ===========================================================================
// subprocess-aggregate-rebuild: child-runner unit tests
// (.sit/workflows/2026-06-12_subprocess-aggregate-rebuild/propose.md, Phase 2)
//

// Generation-lineage equivalence between the child build and the in-process
// build is already pinned by TestAggregateBaseGen_ContentSensitive (pure
// over the member set) — no additional equivalence test here.
// ===========================================================================

func testServeParams() AggregateServeParams {
	return AggregateServeParams{
		ActionAlias:   "motw",
		AggregatePath: "/srv/aggregate",
		UploadPrefix:  "aggregate",
		Bucket:        "motw",
		KeysFile:      "/root/.config/accorder/keys/motw.s3.keys",
		S3AccessKey:   "AKIATEST",
		S3SecretKey:   "test-secret",
		S3Provider:    "Wasabi",
		S3Endpoint:    "https://s3.wasabisys.com",
	}
}

// Phase 2.2: the child argv pins every alias-persisted flag and keeps the
// secrets OFF argv (they travel via env — /proc/<pid>/cmdline is world-
// readable for the whole multi-minute build).
func TestChildRebuildArgs_TotalArgv(t *testing.T) {
	p := testServeParams()
	args := buildChildRebuildArgs(p)

	want := []string{
		"fedlib", "build", "motw",
		"--output-path", "/srv/aggregate",
		"--upload-prefix", "aggregate",
		"--bucket", "motw",
		"--keys-file", "/root/.config/accorder/keys/motw.s3.keys",
		"--s3-provider", "Wasabi",
		"--s3-endpoint", "https://s3.wasabisys.com",
		// Daemon-driven builds run on the serving box and by default must never take
		// the monolithic full-rebuild (OOM) path (operators opt out per box via
		// `fedlib share live --allow-full-rebuild`).
		"--no-monolithic-rebuild",
	}
	if !slices.Equal(args, want) {
		t.Fatalf("buildChildRebuildArgs:\n got %q\nwant %q", args, want)
	}
	for _, a := range args {
		if a == p.S3AccessKey || a == p.S3SecretKey {
			t.Fatalf("secret %q on child argv; secrets must travel via env only", a)
		}
	}
}

// The TOTAL-argv invariant, enforced against the struct instead of a
// hand-maintained mirror list: every FedlibBuildCmd field that the alias
// machinery persists (real json name, no alias:"-", no kong:"-") MUST be
// pinned on the child argv — an unpinned field silently merges stale state
// from the serve's saved alias (the spike-refuted hazard). When this fails,
// add the new flag to buildChildRebuildArgs (and AggregateServeParams).
func TestChildRebuildArgs_PinsEveryPersistedFlag(t *testing.T) {
	args := buildChildRebuildArgs(testServeParams())
	argSet := make(map[string]bool, len(args))
	for _, a := range args {
		argSet[a] = true
	}

	var walk func(typ reflect.Type)
	walk = func(typ reflect.Type) {
		for i := 0; i < typ.NumField(); i++ {
			f := typ.Field(i)
			if f.Anonymous && f.Type.Kind() == reflect.Struct {
				walk(f.Type)
				continue
			}
			jsonName := strings.Split(f.Tag.Get("json"), ",")[0]
			if jsonName == "" || jsonName == "-" || jsonName == "action_alias" {
				continue
			}
			if f.Tag.Get("alias") == "-" || f.Tag.Get("kong") == "-" {
				continue
			}
			flagName := f.Tag.Get("name")
			if flagName == "" {
				flagName = jsonName
			}
			if !argSet["--"+flagName] {
				t.Errorf("alias-persisted flag --%s (field %s) is not pinned in buildChildRebuildArgs; stale alias state can merge into the rebuild child", flagName, f.Name)
			}
		}
	}
	walk(reflect.TypeOf(FedlibBuildCmd{}))
}

// Phase 2.3: GOMEMLIMIT is dropped (the serve's 500MiB limit would
// GC-thrash the child's 400-700MB build peak); inherited S3 secrets are
// replaced by the serve's own (getenv returns the FIRST duplicate, so
// stale inherited values must be filtered, not just overridden by append);
// everything else survives.
func TestChildRebuildEnv_DropsGOMEMLIMIT(t *testing.T) {
	p := testServeParams()
	in := []string{
		"PATH=/usr/bin",
		"GOMEMLIMIT=500MiB",
		"S3_ACCESS_KEY=AKIASTALE",
		"S3_SECRET_KEY=stale-secret",
		"HOME=/home/motw",
	}
	got := childRebuildEnv(in, p)
	want := []string{
		"PATH=/usr/bin",
		"HOME=/home/motw",
		"S3_ACCESS_KEY=AKIATEST",
		"S3_SECRET_KEY=test-secret",
	}
	if !slices.Equal(got, want) {
		t.Fatalf("childRebuildEnv:\n got %q\nwant %q", got, want)
	}
}

// Phase 2.4, spawn-class: a nonexistent executable fails at Start, returns
// spawned=false so the caller falls back to the in-process build.
func TestChildRebuild_SpawnFailure(t *testing.T) {
	spawned, err := runChildBuild(context.Background(),
		"/nonexistent/accorder-test-binary", []string{"fedlib", "build"}, nil)
	if spawned {
		t.Fatalf("spawned=true for nonexistent executable; want false (fallback class)")
	}
	if err == nil {
		t.Fatalf("err=nil for nonexistent executable; want spawn error")
	}
}

// Phase 2.4, exit-class: a child that exits non-zero returns spawned=true
// with the exit error — NO fallback (the in-process build would fail
// identically).
func TestChildRebuild_NonZeroExit(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("requires /bin/sh")
	}
	spawned, err := runChildBuild(context.Background(),
		"/bin/sh", []string{"-c", "echo build boom >&2; exit 3"}, nil)
	if !spawned {
		t.Fatalf("spawned=false for a started child; want true (exit class, no fallback)")
	}
	var exitErr *exec.ExitError
	if !errors.As(err, &exitErr) {
		t.Fatalf("err = %v; want *exec.ExitError", err)
	}
	if code := exitErr.ExitCode(); code != 3 {
		t.Fatalf("exit code = %d; want 3", code)
	}
}

// Phase 2.4, overflow-class: a child emitting a single >1MB stderr line
// followed by more output must not deadlock — log forwarding stops with
// bufio.ErrTooLong, the drain branch keeps consuming the pipe, and Wait
// returns the child's (successful) exit.
func TestChildRebuild_StderrOverflowDrains(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("requires /bin/sh")
	}

	// 2MB of 'a' with no newline (overflows the 1MB scanner buffer), then a
	// newline and further output the drain branch must consume.
	script := `head -c 2097152 /dev/zero | tr '\0' a >&2; echo >&2; echo after-overflow >&2`

	done := make(chan struct{})
	var spawned bool
	var err error
	go func() {
		defer close(done)
		spawned, err = runChildBuild(context.Background(), "/bin/sh", []string{"-c", script}, nil)
	}()
	select {
	case <-done:
	case <-time.After(30 * time.Second):
		t.Fatal("runChildBuild deadlocked on scanner overflow (pipe not drained before Wait)")
	}
	if !spawned {
		t.Fatalf("spawned=false; want true")
	}
	if err != nil {
		t.Fatalf("err = %v; want nil (child exited 0 after overflow)", err)
	}
}

// Phase 2.5: the rebuildInFlight guard skips a second call while one is in
// flight and is released after both normal and panicking runs.
func TestRebuildInFlightGuard(t *testing.T) {
	started := make(chan struct{})
	release := make(chan struct{})
	first := make(chan bool)
	go func() {
		first <- runGuardedRebuild(func() {
			close(started)
			<-release
		})
	}()
	<-started

	if runGuardedRebuild(func() { t.Error("second rebuild ran while first in flight") }) {
		t.Fatal("second call returned true while a rebuild was in flight; want skip")
	}

	close(release)
	if !<-first {
		t.Fatal("first call returned false; want it to have run")
	}

	// Released after the success path.
	ran := false
	if !runGuardedRebuild(func() { ran = true }) || !ran {
		t.Fatal("guard not released after a completed rebuild")
	}

	// Released after a failure (panic) path too — defer must restore.
	func() {
		defer func() { _ = recover() }()
		runGuardedRebuild(func() { panic("rebuild failed hard") })
	}()
	ran = false
	if !runGuardedRebuild(func() { ran = true }) || !ran {
		t.Fatal("guard not released after a panicking rebuild")
	}
}

// A failed rebuild must not consume the member's publish: revertLastChanges
// restores lastKnownGen so the next tick re-detects the change and retries.
// Entries that had no previous value (first observation) are deleted, not
// zeroed.
func TestRevertLastChanges_RetriesFailedRebuild(t *testing.T) {
	var oldGen, newGen [24]byte
	copy(oldGen[:], "gen-old")
	copy(newGen[:], "gen-new")

	mpc := &memberPollContext{
		lastKnownGen: map[string][24]byte{
			"alice": newGen, // advanced this tick, had oldGen before
			"bob":   newGen, // advanced this tick, first observation
			"carol": oldGen, // untouched this tick
		},
		lastTickChanges: map[string]genChange{
			"alice": {prev: oldGen, hadPrev: true},
			"bob":   {hadPrev: false},
		},
	}
	mpc.revertLastChanges()

	if got := mpc.lastKnownGen["alice"]; got != oldGen {
		t.Errorf("alice = %q; want previous generation restored", got[:7])
	}
	if _, ok := mpc.lastKnownGen["bob"]; ok {
		t.Error("bob still present; first-observation entries must be deleted on revert")
	}
	if got := mpc.lastKnownGen["carol"]; got != oldGen {
		t.Errorf("carol = %q; untouched entries must survive revert", got[:7])
	}
	if mpc.lastTickChanges != nil {
		t.Error("lastTickChanges not cleared after revert")
	}
}

// Phase 2.7: pin the upload ordering — _GENERATION is the commit marker and
// must be the FINAL upload, after library_index.zst and _IDENTITY, so a
// child killed mid-upload leaves no consumer-visible partial state.
func TestAggregateUploadSequence_GenerationLast(t *testing.T) {
	seq := aggregateUploadSequence("aggregate")
	if len(seq) != 4 {
		t.Fatalf("upload sequence has %d entries; want 4: %+v", len(seq), seq)
	}
	wantLocals := []string{"library_index.zst", "library_index.manifest.json", "_IDENTITY", "_GENERATION"}
	for i, want := range wantLocals {
		if seq[i].local != want {
			t.Errorf("upload[%d].local = %q; want %q", i, seq[i].local, want)
		}
	}
	last := seq[len(seq)-1]
	if last.local != "_GENERATION" || last.remote != "aggregate/_GENERATION" {
		t.Fatalf("final upload = %+v; want _GENERATION -> aggregate/_GENERATION (commit marker last)", last)
	}
	if seq[0].remote != "aggregate/static/library_index.zst" {
		t.Fatalf("seq[0].remote = %q; want aggregate/static/library_index.zst", seq[0].remote)
	}
	if seq[1].remote != "aggregate/static/library_index.manifest.json" {
		t.Fatalf("seq[1].remote = %q; want aggregate/static/library_index.manifest.json", seq[1].remote)
	}
	if seq[2].remote != "aggregate/_IDENTITY" {
		t.Fatalf("seq[2].remote = %q; want aggregate/_IDENTITY", seq[2].remote)
	}
}
