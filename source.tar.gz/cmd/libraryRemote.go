package cmd

import (
	"accorder/pkg/calibre"
	"accorder/pkg/libraryflow"
	"accorder/pkg/rclonexfer"
	"accorder/pkg/torshare"
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/credentials"
	"github.com/aws/aws-sdk-go-v2/service/s3"
	smithyhttp "github.com/aws/smithy-go/transport/http"
)

var errRemoteObjectNotFound = errors.New("remote object not found")

const memberPointerPath = "static/library_index.manifest.json"

type libraryRemote struct {
	name        string
	fsPath      string
	close       func()
	s3Client    *s3.Client
	s3Bucket    string
	s3KeyPrefix string
	// hashMemo caches content digests keyed by the remote object's observed
	// identity. inspect() is called several times per command and each call
	// otherwise re-downloads the whole of metadata.db.
	hashMemo map[string]string
}

// objectIdentityKey is the backend's own answer to "is this the same bytes?":
// size, modification time, and every hash the backend exposes. Any change
// invalidates the memo, so caching a digest against it cannot mask a
// concurrent remote mutation.
func objectIdentityKey(path string, object *rclonexfer.RemoteObject) string {
	keys := make([]string, 0, len(object.Hashes))
	for key := range object.Hashes {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	var b strings.Builder
	fmt.Fprintf(&b, "%s\x00%d\x00%d", path, object.Size, object.ModTime.UTC().UnixNano())
	for _, key := range keys {
		fmt.Fprintf(&b, "\x00%s=%s", key, object.Hashes[key])
	}
	return b.String()
}

var openLibraryRemoteForCommand = openLibraryRemote

func openLibraryRemote(alias string, creds GroupS3Credentials) (*libraryRemote, error) {
	if !isScopedBucket(creds.Bucket) {
		return nil, fmt.Errorf("library remote: refusing bare bucket %q; expected <bucket>/<prefix>", creds.Bucket)
	}
	if err := rclonexfer.SetCacheDir(accorderCacheDir()); err != nil {
		return nil, fmt.Errorf("library remote: set cache dir: %w", err)
	}
	rclonexfer.Initialize()
	name := "accorder-library-flow-" + alias
	_ = rclonexfer.DeleteRemote(name)
	remoteConfig := libraryS3RemoteConfig(creds)
	if err := rclonexfer.ConfigS3Remote(name, remoteConfig); err != nil {
		rclonexfer.Finalize()
		return nil, err
	}
	bucket, prefix, err := splitScopedBucket(creds.Bucket)
	if err != nil {
		_ = rclonexfer.DeleteRemote(name)
		rclonexfer.Finalize()
		return nil, err
	}
	awsConfig := aws.Config{
		Region: "us-east-1",
		Credentials: aws.NewCredentialsCache(credentials.NewStaticCredentialsProvider(
			creds.S3AccessKey, creds.S3SecretKey, "",
		)),
	}
	s3Client := s3.NewFromConfig(awsConfig, func(options *s3.Options) {
		options.UsePathStyle = true
		if remoteConfig.Endpoint != "" {
			options.BaseEndpoint = aws.String(remoteConfig.Endpoint)
		}
	})
	return &libraryRemote{
		name: name, fsPath: name + ":" + creds.Bucket,
		s3Client: s3Client, s3Bucket: bucket, s3KeyPrefix: strings.Trim(prefix, "/"),
		close: func() {
			_ = rclonexfer.DeleteRemote(name)
			rclonexfer.Finalize()
		},
	}, nil
}

func libraryS3RemoteConfig(creds GroupS3Credentials) rclonexfer.S3RemoteConfig {
	return rclonexfer.S3RemoteConfig{
		Provider: creds.S3Provider, AccessKey: creds.S3AccessKey,
		SecretKey: creds.S3SecretKey, Endpoint: normalizeS3Endpoint(creds.S3Endpoint),
	}
}

// normalizeS3Endpoint adapts the scheme-less endpoint form accepted by the
// existing rclone configuration path to the absolute URL required by AWS SDK
// v2's BaseEndpoint field. Explicit schemes remain untouched for local/test
// S3 implementations that intentionally use plain HTTP.
func normalizeS3Endpoint(endpoint string) string {
	endpoint = strings.TrimSpace(endpoint)
	if endpoint == "" || strings.Contains(endpoint, "://") {
		return endpoint
	}
	return "https://" + endpoint
}

// splitScopedBucket separates a "<bucket>/<prefix>" credential value into its
// bucket and key-prefix parts. It trims surrounding slashes first so that a
// value isScopedBucket already accepted (which normalizes the same way)
// cannot be rejected here solely because of a leading or trailing slash.
func splitScopedBucket(scoped string) (bucket, prefix string, err error) {
	bucket, prefix, ok := strings.Cut(strings.Trim(scoped, "/"), "/")
	if !ok || bucket == "" || prefix == "" {
		return "", "", fmt.Errorf("library remote: invalid scoped bucket %q", scoped)
	}
	return bucket, prefix, nil
}

// createImmutable stores path only when no object exists at that key. The S3
// branch uses a backend-enforced conditional write; the local branch exists for
// production-shaped filesystem tests and uses O_EXCL. A false result means an
// object won the race without being replaced; callers must read and compare it.
func (r *libraryRemote) createImmutable(path string, data []byte) (bool, error) {
	path, err := libraryflow.NormalizePath(path)
	if err != nil {
		return false, err
	}
	if r.s3Client != nil {
		key := strings.Trim(r.s3KeyPrefix+"/"+path, "/")
		_, err := r.s3Client.PutObject(context.Background(), &s3.PutObjectInput{
			Bucket: aws.String(r.s3Bucket), Key: aws.String(key),
			Body: bytes.NewReader(data), IfNoneMatch: aws.String("*"),
		})
		if err == nil {
			return true, nil
		}
		var responseError *smithyhttp.ResponseError
		if errors.As(err, &responseError) && responseError.HTTPStatusCode() == 412 {
			return false, nil
		}
		return false, fmt.Errorf("conditional create %s: %w", path, err)
	}
	if r.fsPath == "" || strings.Contains(r.fsPath, ":") {
		return false, errors.New("conditional create is unavailable for this remote backend")
	}
	full := filepath.Join(r.fsPath, filepath.FromSlash(path))
	if err := os.MkdirAll(filepath.Dir(full), 0o755); err != nil {
		return false, err
	}
	f, err := os.OpenFile(full, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0o600)
	if errors.Is(err, os.ErrExist) {
		return false, nil
	}
	if err != nil {
		return false, err
	}
	name := f.Name()
	remove := true
	defer func() {
		_ = f.Close()
		if remove {
			_ = os.Remove(name)
		}
	}()
	if _, err := f.Write(data); err != nil {
		return false, err
	}
	if err := f.Sync(); err != nil {
		return false, err
	}
	if err := f.Close(); err != nil {
		return false, err
	}
	remove = false
	return true, nil
}

func (r *libraryRemote) Close() {
	if r.close != nil {
		r.close()
	}
}

func (r *libraryRemote) list() ([]libraryflow.Object, error) {
	objects, err := rclonexfer.ListObjects(r.fsPath, nil, nil)
	if err != nil {
		return nil, err
	}
	out := make([]libraryflow.Object, 0, len(objects))
	for _, object := range objects {
		hash := ""
		if len(object.Hashes) > 0 {
			keys := make([]string, 0, len(object.Hashes))
			for key := range object.Hashes {
				keys = append(keys, key)
			}
			sort.Strings(keys)
			for _, key := range keys {
				if object.Hashes[key] != "" {
					hash = strings.ToLower(key) + ":" + object.Hashes[key]
					break
				}
			}
		}
		out = append(out, libraryflow.Object{
			Path: object.Path, Size: object.Size, ModTime: object.ModTime, Hash: hash,
		})
	}
	return out, nil
}

func (r *libraryRemote) read(path string, limit int64) ([]byte, error) {
	object, err := rclonexfer.StatObject(r.fsPath, path)
	if err != nil {
		return nil, err
	}
	if object == nil {
		return nil, fmt.Errorf("%w: %s", errRemoteObjectNotFound, path)
	}
	if limit > 0 && object.Size > limit {
		return nil, fmt.Errorf("remote object %s is %d bytes, exceeds limit %d", path, object.Size, limit)
	}
	dir, err := os.MkdirTemp("", "accorder-remote-read-*")
	if err != nil {
		return nil, err
	}
	defer os.RemoveAll(dir)
	name := filepath.Base(filepath.FromSlash(path))
	if err := rclonexfer.CopyFile(r.fsPath, path, dir, name); err != nil {
		return nil, err
	}
	data, err := os.ReadFile(filepath.Join(dir, name))
	if err != nil {
		return nil, err
	}
	if limit > 0 && int64(len(data)) > limit {
		return nil, fmt.Errorf("remote object %s exceeds limit %d", path, limit)
	}
	return data, nil
}

func (r *libraryRemote) write(path string, data []byte) error {
	dir, err := os.MkdirTemp("", "accorder-remote-write-*")
	if err != nil {
		return err
	}
	defer os.RemoveAll(dir)
	name := filepath.Base(filepath.FromSlash(path))
	if err := os.WriteFile(filepath.Join(dir, name), data, 0o600); err != nil {
		return err
	}
	// Coordination objects are explicit writes, not synchronization hints.
	// Their names and sizes are commonly unchanged between generations, so
	// force the transfer instead of allowing rclone's equality heuristic to
	// retain the previous pointer, sentinel, or writer bytes.
	return rclonexfer.CopyFileOverwrite(dir, name, r.fsPath, path)
}

func (r *libraryRemote) hash(path string, limit int64) (string, error) {
	object, err := rclonexfer.StatObject(r.fsPath, path)
	if err != nil {
		return "", err
	}
	if object == nil {
		return "", fmt.Errorf("%w: %s", errRemoteObjectNotFound, path)
	}
	if limit > 0 && object.Size > limit {
		return "", fmt.Errorf("remote object %s is %d bytes, exceeds limit %d", path, object.Size, limit)
	}
	memoKey := objectIdentityKey(path, object)
	if digest, ok := r.hashMemo[memoKey]; ok {
		return digest, nil
	}
	dir, err := os.MkdirTemp("", "accorder-remote-hash-*")
	if err != nil {
		return "", err
	}
	defer os.RemoveAll(dir)
	name := filepath.Base(filepath.FromSlash(path))
	if err := rclonexfer.CopyFile(r.fsPath, path, dir, name); err != nil {
		return "", err
	}
	f, err := os.Open(filepath.Join(dir, name))
	if err != nil {
		return "", err
	}
	defer f.Close()
	h := sha256.New()
	var reader io.Reader = f
	if limit > 0 {
		reader = io.LimitReader(f, limit+1)
	}
	if _, err := io.Copy(h, reader); err != nil {
		return "", err
	}
	digest := hex.EncodeToString(h.Sum(nil))
	if r.hashMemo == nil {
		r.hashMemo = map[string]string{}
	}
	r.hashMemo[memoKey] = digest
	return digest, nil
}

func (r *libraryRemote) uploadFile(localRoot, path string) error {
	return r.uploadFileAs(localRoot, path, path)
}

// uploadFileAs uploads a local artifact to a remote path that need not match
// its local relative path (derived artifacts always land under static/).
func (r *libraryRemote) uploadFileAs(localRoot, localPath, remotePath string) error {
	// This helper is used by the explicit derived-repair command. Repair must
	// replace equal-size bad bytes; the ordinary copy shortcut is not a repair.
	return rclonexfer.CopyFileOverwrite(localRoot, filepath.FromSlash(localPath), r.fsPath, remotePath)
}

type remoteWriterState struct {
	Kind   string // absent, valid, invalid, unreadable
	Marker libraryflow.WriterMarker
	Raw    []byte
	Err    error
}

func (r *libraryRemote) readWriter() remoteWriterState {
	raw, err := r.read(libraryflow.WriterPath, 1<<20)
	if errors.Is(err, errRemoteObjectNotFound) {
		return remoteWriterState{Kind: "absent"}
	}
	if err != nil {
		return remoteWriterState{Kind: "unreadable", Err: err}
	}
	marker, err := libraryflow.ParseWriterMarker(raw)
	if err != nil {
		return remoteWriterState{Kind: "invalid", Raw: raw, Err: err}
	}
	return remoteWriterState{Kind: "valid", Marker: marker, Raw: raw}
}

type remoteLibrarySnapshot struct {
	Pointer           calibre.PointerFile
	PointerRaw        []byte
	GenerationRaw     []byte
	Generation        uint64
	SourceFingerprint string
	Inventory         []libraryflow.Object
	InventoryToken    string
	Writer            remoteWriterState
	Committed         bool
	Legacy            bool
	LastUpdate        time.Time
	Err               error
}

// commitState reads only the objects that record a commit: the writer marker,
// the pointer, and the generation sentinel. Three small reads.
//
// It deliberately does not enumerate the bucket. The pointer already carries
// the source fingerprint and generation of the snapshot it commits, so the
// remote's committed identity is readable from the commit record itself. The
// full inventory walk that inspect() performs to recompute the same value
// costs minutes on a real collection, and publish never needed it: rclone's
// own sync engine works out what to transfer and delete while it transfers.
func (r *libraryRemote) commitState() remoteLibrarySnapshot {
	writer := r.readWriter()
	pointerRaw, pointerErr := r.read(memberPointerPath, 4<<20)
	generationRaw, generationErr := r.read(libraryflow.GenerationPath, 1<<20)
	if errors.Is(pointerErr, errRemoteObjectNotFound) && errors.Is(generationErr, errRemoteObjectNotFound) {
		// Nothing committed here yet; a first publish is free to proceed.
		return remoteLibrarySnapshot{Writer: writer}
	}
	if pointerErr != nil || generationErr != nil {
		return remoteLibrarySnapshot{Writer: writer, Err: fmt.Errorf("read committed snapshot: pointer=%v generation=%v", pointerErr, generationErr)}
	}
	pointer, err := calibre.DecodePointerFile(bytes.NewReader(pointerRaw))
	if err != nil {
		return remoteLibrarySnapshot{Writer: writer, PointerRaw: pointerRaw, Err: err}
	}
	_, generation, err := torshare.DecodeGeneration(generationRaw)
	if err != nil {
		return remoteLibrarySnapshot{Writer: writer, Pointer: pointer, PointerRaw: pointerRaw, GenerationRaw: generationRaw, Err: err}
	}
	snapshot := remoteLibrarySnapshot{
		Writer: writer, Pointer: pointer, PointerRaw: pointerRaw,
		GenerationRaw: generationRaw, Generation: generation,
		SourceFingerprint: pointer.SourceFingerprint,
	}
	if err := calibre.ValidatePointerCommit(pointer, pointer.SourceFingerprint, generation); err != nil {
		snapshot.Legacy = pointer.Version < 2
		snapshot.Err = err
		return snapshot
	}
	snapshot.Committed = true
	return snapshot
}

func (r *libraryRemote) inspect() remoteLibrarySnapshot {
	writer := r.readWriter()
	pointerRaw, pointerErr := r.read(memberPointerPath, 4<<20)
	generationRaw, generationErr := r.read(libraryflow.GenerationPath, 1<<20)
	objects, listErr := r.list()
	if listErr != nil {
		return remoteLibrarySnapshot{Writer: writer, Err: fmt.Errorf("list remote library: %w", listErr)}
	}
	token, tokenErr := libraryflow.StableInventoryToken(objects, nil)
	if tokenErr != nil {
		return remoteLibrarySnapshot{Writer: writer, Inventory: objects, Err: tokenErr}
	}
	metadataHash, metadataErr := r.hash("metadata.db", 2<<30)
	if errors.Is(pointerErr, errRemoteObjectNotFound) {
		if metadataErr == nil && generationErr == nil {
			return remoteLibrarySnapshot{
				Writer: writer, Inventory: objects, InventoryToken: token,
				Legacy: true, Err: errors.New("legacy published library is not bound by a version 2 pointer; publish once with a current client before sync"),
			}
		}
		if errors.Is(metadataErr, errRemoteObjectNotFound) && errors.Is(generationErr, errRemoteObjectNotFound) {
			return remoteLibrarySnapshot{Writer: writer, Inventory: objects, InventoryToken: token}
		}
		return remoteLibrarySnapshot{Writer: writer, Inventory: objects, InventoryToken: token, Err: fmt.Errorf("incomplete remote library: pointer=%v metadata=%v generation=%v", pointerErr, metadataErr, generationErr)}
	}
	if pointerErr != nil || generationErr != nil || metadataErr != nil {
		return remoteLibrarySnapshot{Writer: writer, Inventory: objects, InventoryToken: token, Err: fmt.Errorf("read committed snapshot: pointer=%v metadata=%v generation=%v", pointerErr, metadataErr, generationErr)}
	}
	pointer, err := calibre.DecodePointerFile(bytes.NewReader(pointerRaw))
	if err != nil {
		return remoteLibrarySnapshot{Writer: writer, PointerRaw: pointerRaw, Inventory: objects, InventoryToken: token, Err: err}
	}
	_, generation, err := torshare.DecodeGeneration(generationRaw)
	if err != nil {
		return remoteLibrarySnapshot{Writer: writer, Pointer: pointer, PointerRaw: pointerRaw, GenerationRaw: generationRaw, Inventory: objects, InventoryToken: token, Err: err}
	}
	sourceFingerprint, _, err := libraryflow.SourceFingerprintFromObjects(objects, metadataHash, nil)
	if err != nil {
		return remoteLibrarySnapshot{Writer: writer, Pointer: pointer, PointerRaw: pointerRaw, GenerationRaw: generationRaw, Generation: generation, Inventory: objects, InventoryToken: token, Err: err}
	}
	if err := calibre.ValidatePointerCommit(pointer, sourceFingerprint, generation); err != nil {
		return remoteLibrarySnapshot{Writer: writer, Pointer: pointer, PointerRaw: pointerRaw, GenerationRaw: generationRaw, Generation: generation, SourceFingerprint: sourceFingerprint, Inventory: objects, InventoryToken: token, Legacy: pointer.Version < 2, Err: err}
	}

	// Re-read coordination objects and inventory after the expensive source
	// hash. Only a stable view is eligible for activation or publish approval.
	pointerRaw2, pointerErr2 := r.read(memberPointerPath, 4<<20)
	generationRaw2, generationErr2 := r.read(libraryflow.GenerationPath, 1<<20)
	objects2, listErr2 := r.list()
	if pointerErr2 != nil || generationErr2 != nil || listErr2 != nil {
		return remoteLibrarySnapshot{Writer: writer, Pointer: pointer, Generation: generation, SourceFingerprint: sourceFingerprint, Inventory: objects, InventoryToken: token, Err: errors.New("remote changed or became unreadable during inspection")}
	}
	token2, tokenErr2 := libraryflow.StableInventoryToken(objects2, nil)
	if tokenErr2 != nil || !bytes.Equal(pointerRaw, pointerRaw2) || !bytes.Equal(generationRaw, generationRaw2) || token != token2 {
		return remoteLibrarySnapshot{Writer: writer, Pointer: pointer, Generation: generation, SourceFingerprint: sourceFingerprint, Inventory: objects, InventoryToken: token, Err: errors.New("remote changed during inspection; retry")}
	}
	return remoteLibrarySnapshot{
		Pointer: pointer, PointerRaw: pointerRaw, GenerationRaw: generationRaw,
		Generation: generation, SourceFingerprint: sourceFingerprint,
		Inventory: objects, InventoryToken: token, Writer: writer, Committed: true,
	}
}

func (r *libraryRemote) sourceFingerprint(objects []libraryflow.Object) (string, error) {
	metadataHash, err := r.hash("metadata.db", 2<<30)
	if err != nil {
		return "", err
	}
	fingerprint, _, err := libraryflow.SourceFingerprintFromObjects(objects, metadataHash, nil)
	return fingerprint, err
}
