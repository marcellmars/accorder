package cmd

import (
	"accorder/pkg/secrets"
	"log"
	"os"
	"path/filepath"
	"reflect"
	"strings"
)

func resolveS3CredsFromSecretsStore(target reflect.Value, actionAlias string, bucketExplicit bool, rcs ...*resolveCtx) {
	rc := resolveCtxOf(rcs)
	if target.Kind() == reflect.Ptr {
		target = target.Elem()
	}

	bucket := fieldStringValue(target, "Bucket")
	accessKey := fieldStringValue(target, "S3AccessKey")
	secretKey := fieldStringValue(target, "S3SecretKey")
	provider := fieldStringValue(target, "S3Provider")
	endpoint := fieldStringValue(target, "S3Endpoint")

	bucketSafe := bucketExplicit || isScopedBucket(bucket)
	if bucket != "" && accessKey != "" && secretKey != "" && provider != "" && endpoint != "" && bucketSafe {
		return
	}

	passphrase := fieldStringValue(target, "Passphrase")
	if passphrase == "" {
		passphrase = os.Getenv("ACCORDER_SECRETS_PASSPHRASE")
	}

	storePath := filepath.Join(accorderConfigDir, "secrets.age")
	var store *secrets.Store
	if passphrase != "" {
		store = secrets.NewStore(storePath, passphrase)
	} else if id, err := loadOrGenerateSecretsKey(false); err == nil {
		store = secrets.NewStoreWithIdentity(storePath, id)
	} else {
		return
	}

	fields := []struct {
		fieldName string
		storeKey  string
		current   string
	}{
		{"S3AccessKey", actionAlias + "/write/access-key", accessKey},
		{"S3SecretKey", actionAlias + "/write/secret-key", secretKey},
	}
	if !rc.credentialOnly {
		fields = append(fields, []struct {
			fieldName string
			storeKey  string
			current   string
		}{
			{"S3Provider", actionAlias + "/write/provider", provider},
			{"S3Endpoint", actionAlias + "/write/endpoint", endpoint},
		}...)
	}

	resolved := 0
	for _, f := range fields {
		if f.current != "" {
			continue
		}
		val, err := store.Get(f.storeKey)
		if err != nil {
			log.Printf("[G1] secrets-store: %s not found: %v", f.storeKey, err)
			continue
		}
		if val == "" {
			continue
		}
		setFieldString(target, f.fieldName, val)
		rc.prov.StampField(target, f.fieldName, OriginSecrets, f.storeKey)
		resolved++
	}

	if !bucketExplicit && !rc.credentialOnly {
		effBucket := bucket
		if effBucket == "" {
			if sb, err := store.Get(actionAlias + "/write/bucket"); err == nil {
				effBucket = sb
			} else {
				log.Printf("[G1] secrets-store: %s/write/bucket not found: %v", actionAlias, err)
			}
		}
		if effBucket != "" && !isScopedBucket(effBucket) {
			if sp, _ := store.Get(actionAlias + "/write/prefix"); sp != "" {
				effBucket = strings.TrimRight(effBucket, "/") + "/" + sp
			}
		}
		if effBucket != "" && effBucket != bucket {
			setFieldString(target, "Bucket", effBucket)
			rc.prov.StampField(target, "Bucket", OriginSecrets, actionAlias+"/write/bucket")
			resolved++
		}
	}

	if resolved > 0 {
		log.Printf("[G1] secrets-store: resolved %d S3 credential field(s) for alias %q", resolved, actionAlias)
	}
}

func isScopedBucket(bucket string) bool {
	return strings.Contains(strings.Trim(bucket, "/"), "/")
}

func fieldStringValue(v reflect.Value, name string) string {
	f := v.FieldByName(name)
	if !f.IsValid() || f.Kind() != reflect.String {
		return ""
	}
	return f.String()
}

func fieldUintValue(v reflect.Value, name string) uint64 {
	f := v.FieldByName(name)
	if f.IsValid() && f.CanUint() {
		return f.Uint()
	}
	return 0
}

func setFieldUint(v reflect.Value, name string, val uint64) {
	f := v.FieldByName(name)
	if f.IsValid() && f.CanSet() && f.CanUint() && !f.OverflowUint(val) {
		f.SetUint(val)
	}
}

func setFieldString(v reflect.Value, name, val string) {
	f := v.FieldByName(name)
	if f.IsValid() && f.CanSet() && f.Kind() == reflect.String {
		f.SetString(val)
	}
}
