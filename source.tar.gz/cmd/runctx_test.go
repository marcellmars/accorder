package cmd

import "github.com/alecthomas/kong"

// runNilCtx adapts a command Run method that takes a *kong.Context for
// direct test invocation: unit callers pass nil and the validation helper
// falls back to struct-tag spelling (ca-127).
func runNilCtx(f func(*kong.Context) error) func() error {
	return func() error { return f(nil) }
}
