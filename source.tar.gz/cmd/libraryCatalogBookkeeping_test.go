package cmd

import (
	"bytes"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"sort"
	"strings"
	"sync"
	"testing"
	"time"

	"accorder/pkg/calibre"
	"accorder/pkg/libraryflow"
)

const catalogTestOPF = "Author/Book (1)/metadata.opf"

type catalogWorkCounter struct {
	mu     sync.Mutex
	counts map[string]int
}

func (c *catalogWorkCounter) count(stage string) int {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.counts[stage]
}

func (c *catalogWorkCounter) reset() {
	c.mu.Lock()
	defer c.mu.Unlock()
	clear(c.counts)
}

func (c *catalogWorkCounter) String() string {
	c.mu.Lock()
	defer c.mu.Unlock()
	return fmt.Sprint(c.counts)
}

func catalogWorkCounts(t *testing.T) *catalogWorkCounter {
	t.Helper()
	previous := libraryWorkObserver
	t.Cleanup(func() { libraryWorkObserver = previous })
	counts := &catalogWorkCounter{counts: map[string]int{}}
	libraryWorkObserver = func(stage string, _ time.Duration, _ int) {
		counts.mu.Lock()
		defer counts.mu.Unlock()
		counts.counts[stage]++
	}
	return counts
}

func TestCatalogBookkeepingReusesUnchangedBuildAndAttachment(t *testing.T) {
	root := testSetup(t)
	seedPublishCalibreLibrary(t, root)
	build := fastBuildCommand(root)
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	before, err := loadLocalChangeCandidate(root)
	if err != nil {
		t.Fatal(err)
	}
	counts := catalogWorkCounts(t)
	for _, opf := range []string{"first metadata backup", "different backup"} {
		counts.reset()
		writeTestFile(t, root, catalogTestOPF, opf)
		if err := build.Run(nil); err != nil {
			t.Fatal(err)
		}
		if counts.count("checkpoint-load") != 1 || counts.count("database-inventory") != 0 || counts.count("inventory") != 0 {
			t.Fatalf("unchanged build did redundant work: %v", counts)
		}
		counts.reset()
		candidate, err := captureExistingCandidate(root, resolveUploadExcludes(root, nil))
		if err != nil || candidate.Change == nil {
			t.Fatalf("attachment: %v", err)
		}
		if counts.count("checkpoint-load") != 1 || counts.count("database-inventory") != 0 || counts.count("inventory") != 0 {
			t.Fatalf("attachment did redundant work: %v", counts)
		}
		counts.reset()
		upload := &LibUploadCmd{GroupLib: build.GroupLib}
		prepared, _, err := upload.prepareUploadCandidate(nil, resolveUploadExcludes(root, nil))
		if err != nil || prepared.Change == nil || counts.count("checkpoint-load") != 1 {
			t.Fatalf("upload preparation reread the checkpoint: %v %v", counts, err)
		}
		if !reflect.DeepEqual(before.ForcePaths, candidate.Change.ForcePaths) || before.TargetSourceFingerprint != candidate.SourceFingerprint || before.IndexArtifact.Hash != candidate.Change.IndexArtifact.Hash {
			t.Fatal("OPF-only edit changed pending paths, database identity or index")
		}
		for _, file := range candidate.Change.Evidence.Catalog.Files {
			if strings.HasSuffix(file.Path, "/metadata.opf") {
				t.Fatal("OPF was added to database tracking")
			}
		}
	}
	if err := os.Remove(filepath.Join(root, catalogTestOPF)); err != nil {
		t.Fatal(err)
	}
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	after, err := loadLocalChangeCandidate(root)
	if err != nil || before.TargetSourceFingerprint != after.TargetSourceFingerprint || !reflect.DeepEqual(before.Changes, after.Changes) {
		t.Fatalf("OPF absence changed catalog: %v", err)
	}
}

// Reconstruct a checkpoint emitted before OPF retirement. Do not migrate on
// read: interrupted publication still needs the exact historical evidence.
func addHistoricalCatalogOPF(t *testing.T, root string) *localChangeCandidate {
	t.Helper()
	candidate, err := loadLocalChangeCandidate(root)
	if err != nil {
		t.Fatal(err)
	}
	candidate.Evidence.Catalog.Selection = ""
	candidate.Evidence.Catalog.Files = append(candidate.Evidence.Catalog.Files, calibre.SourceCatalogFile{
		Path: catalogTestOPF, Optional: true, Stamp: candidate.Evidence.Catalog.Files[0].Stamp,
	})
	sort.Slice(candidate.Evidence.Catalog.Files, func(i, j int) bool {
		return candidate.Evidence.Catalog.Files[i].Path < candidate.Evidence.Catalog.Files[j].Path
	})
	candidate.ContentLedger = append(candidate.ContentLedger, libraryflow.Object{Path: catalogTestOPF})
	sort.Slice(candidate.ContentLedger, func(i, j int) bool { return candidate.ContentLedger[i].Path < candidate.ContentLedger[j].Path })
	candidate.ForcePaths = append(candidate.ForcePaths, catalogTestOPF)
	sort.Strings(candidate.ForcePaths)
	if err := saveLocalChangeCandidate(root, *candidate); err != nil {
		t.Fatal(err)
	}
	return candidate
}

func TestCatalogBookkeepingMigratesOPFWithoutLosingPendingEdit(t *testing.T) {
	root := testSetup(t)
	seedPublishCalibreLibrary(t, root)
	remote := t.TempDir()
	withLocalCommandRemote(t, remote)
	build := fastBuildCommand(root)
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	candidate, err := captureExistingCandidate(root, resolveUploadExcludes(root, nil))
	if err != nil {
		t.Fatal(err)
	}
	if err := publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: 25}); err != nil {
		t.Fatal(err)
	}
	writeTestFile(t, root, fastBuildPayload, "changed")
	writeTestFile(t, root, catalogTestOPF, "retained backup")
	fastBuildSQL(t, root, "UPDATE books SET last_modified='2026-09-07T23:00:00+00:00'")
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	old := addHistoricalCatalogOPF(t, root)
	for i := 0; i < 2; i++ {
		if err := build.Run(nil); err != nil {
			t.Fatal(err)
		}
	}
	after, err := loadLocalChangeCandidate(root)
	if err != nil || after.CompleteOverwrite || after.Scope != old.Scope || after.FromGeneration != old.FromGeneration || !reflect.DeepEqual(after.Changes, old.Changes) || !containsString(after.ForcePaths, fastBuildPayload) || containsString(after.ForcePaths, catalogTestOPF) || ledgerContainsPath(after.ContentLedger, catalogTestOPF) {
		t.Fatalf("migration lost pending lineage or retained OPF bookkeeping: %+v %v", after, err)
	}
	upload := &LibUploadCmd{GroupLib: build.GroupLib, MaxDeletes: 25}
	upload.ActionAlias, upload.Bucket = "alice", "bucket/alice"
	if err := upload.Run(nil); err != nil {
		t.Fatal(err)
	}
	for _, path := range []string{fastBuildPayload, catalogTestOPF} {
		local, err := os.ReadFile(filepath.Join(root, path))
		if err != nil {
			t.Fatal(err)
		}
		actual, err := os.ReadFile(filepath.Join(remote, path))
		if err != nil || !bytes.Equal(local, actual) {
			t.Fatalf("ordinary mirror or pending edit broken for %s: %v", path, err)
		}
	}
}

func TestCatalogBookkeepingRecoveryRetainsHistoricalOPF(t *testing.T) {
	root := testSetup(t)
	seedPublishCalibreLibrary(t, root)
	remote := t.TempDir()
	withLocalCommandRemote(t, remote)
	build := fastBuildCommand(root)
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	addHistoricalCatalogOPF(t, root)
	candidate, err := captureExistingCandidate(root, resolveUploadExcludes(root, nil))
	if err != nil || candidate.Change == nil || !ledgerContainsPath(candidate.Change.ContentLedger, catalogTestOPF) {
		t.Fatalf("attachment rewrote historical checkpoint: %v", err)
	}
	stop := errors.New("stop after historical manifest")
	publishCommitStageHook = func(stage string) error {
		if stage == "after-manifest" {
			return stop
		}
		return nil
	}
	t.Cleanup(func() { publishCommitStageHook = nil })
	if err := publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: 25}); !errors.Is(err, stop) {
		t.Fatal(err)
	}
	publishCommitStageHook = nil
	var record publishRecoveryRecord
	if err := readJSONFile(publishRecoveryPath("alice"), &record); err != nil || !ledgerContainsPath(record.ContentLedger, catalogTestOPF) {
		t.Fatalf("recovery lost historical evidence: %v", err)
	}
	publish := &LibPublishCmd{GroupLib: build.GroupLib, MaxDeletes: 25}
	publish.ActionAlias, publish.Bucket = "alice", "bucket/alice"
	if err := publish.Run(nil); err != nil {
		t.Fatalf("historical publication cannot recover: %v", err)
	}
	state := (&libraryRemote{fsPath: remote}).commitState()
	if state.Err != nil || !state.Committed {
		t.Fatalf("recovery did not commit: %+v", state)
	}
}

func TestCatalogBookkeepingSelectionChangeRereadsDatabase(t *testing.T) {
	root := testSetup(t)
	seedPublishCalibreLibrary(t, root)
	installation, err := loadOrCreateInstallation()
	if err != nil {
		t.Fatal(err)
	}
	inventory, err := scanSourceObjects(root)
	if err != nil {
		t.Fatal(err)
	}
	excludes := []string{"Author/Book (1)/**"}
	ledger, evidence, _, _, err := buildCatalogEvidence(root, inventory, excludes, nil, nil, installation.SeatID)
	if err != nil || ledgerContainsPath(ledger, fastBuildPayload) {
		t.Fatalf("excluded payload present: %v", err)
	}
	counts := catalogWorkCounts(t)
	fresh, err := catalogInventoryForBuild(root, evidence, ledger, nil)
	if err != nil || counts.count("database-inventory") != 1 || !ledgerContainsPath(fresh.Objects, fastBuildPayload) {
		t.Fatalf("changed selection reused incomplete inventory: %v %v", counts, err)
	}
	current, _, changed, _, err := buildCatalogEvidence(root, fresh, nil, ledger, evidence, installation.SeatID)
	if err != nil || !ledgerContainsPath(current, fastBuildPayload) || !containsString(changed, fastBuildPayload) {
		t.Fatalf("newly included payload not pending: %v", err)
	}
}
