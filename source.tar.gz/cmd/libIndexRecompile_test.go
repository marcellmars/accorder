package cmd

import (
	"accorder/pkg/calibre"
	"context"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"testing"
)

// buildPlainIndex writes the given books to a JSONL and builds a lean 3-field
// (IndexDescription=false) index at <dir>/library_index, returning the base path.
// The display section still carries each book's abstract (display is independent
// of indexing) — that is what a description recompile re-indexes.
func buildPlainIndex(t *testing.T, dir string, books []calibre.Book) string {
	t.Helper()
	jsonlPath := filepath.Join(dir, "books.jsonl")
	f, err := os.Create(jsonlPath)
	if err != nil {
		t.Fatal(err)
	}
	for _, b := range books {
		line, _ := json.Marshal(b)
		f.Write(line)
		f.Write([]byte("\n"))
	}
	f.Close()

	idxPath := filepath.Join(dir, "library_index")
	ms := &calibre.MotwSearch{JsonlPath: jsonlPath, IndexPath: idxPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex: %v", err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatalf("CompressToFile: %v", err)
	}
	return idxPath
}

// TestRecompileIndexWithDescriptions covers the M2 re-apply core that both the
// `lib index recompile` command and the browse post-sync hook call: a lean
// 3-field index is rebuilt in place as a 4-field index whose abstracts are
// searchable, and an index with no abstracts is refused (errNoDescriptions).
func TestRecompileIndexWithDescriptions(t *testing.T) {
	t.Run("rebuilds a 3-field index to 4-field with searchable descriptions", func(t *testing.T) {
		dir := t.TempDir()
		idxPath := buildPlainIndex(t, dir, []calibre.Book{
			{Title: "Quantum Theory", Authors: []string{"Bohr"}, Tags: []string{"physics"},
				Abstract:     "A study of <b>entanglement</b> and superposition.",
				LastModified: "2024-01-01T00:00:00+00:00", LibraryUUID: "u", UUID: "b1", Id: "1"},
			{Title: "Plain Title", Authors: []string{"Author"}, Tags: []string{"misc"},
				LastModified: "2024-01-02T00:00:00+00:00", LibraryUUID: "u", UUID: "b2", Id: "2"},
		})

		mf0, err := calibre.ReadExistingManifest(idxPath)
		if err != nil {
			t.Fatal(err)
		}
		if mf0.IndexedFieldCount >= 4 {
			t.Fatalf("precondition: index already 4-field (%d)", mf0.IndexedFieldCount)
		}

		n, err := recompileIndexWithDescriptions(idxPath)
		if err != nil {
			t.Fatalf("recompile: %v", err)
		}
		if n != 2 {
			t.Fatalf("book count = %d, want 2", n)
		}

		mf1, err := calibre.ReadExistingManifest(idxPath)
		if err != nil {
			t.Fatal(err)
		}
		if mf1.IndexedFieldCount != 4 {
			t.Fatalf("IndexedFieldCount after recompile = %d, want 4", mf1.IndexedFieldCount)
		}

		// "entanglement" lives only in the abstract — a description search must
		// now find exactly the one book, proving the abstract got indexed.
		searcher := &calibre.MotwSearch{IndexPath: idxPath}
		books, _, err := searcher.Search(context.Background(),
			calibre.SearchQuery{Field: calibre.FieldAbstract, Text: "entanglement"},
			calibre.SearchOptions{})
		if err != nil {
			t.Fatal(err)
		}
		if len(books) != 1 || books[0].Id != "1" {
			t.Fatalf("description:entanglement → %d books, want exactly book 1", len(books))
		}
	})

	t.Run("refuses an index with no descriptions", func(t *testing.T) {
		dir := t.TempDir()
		idxPath := buildPlainIndex(t, dir, []calibre.Book{
			{Title: "No Abstract Here", Authors: []string{"A"}, Tags: []string{"t"},
				LastModified: "2024-01-01T00:00:00+00:00", LibraryUUID: "u", UUID: "b1", Id: "1"},
		})

		_, err := recompileIndexWithDescriptions(idxPath)
		if !errors.Is(err, errNoDescriptions) {
			t.Fatalf("err = %v, want errNoDescriptions", err)
		}

		// The index must stay lean — refusing should not have rewritten it.
		mf, err := calibre.ReadExistingManifest(idxPath)
		if err != nil {
			t.Fatal(err)
		}
		if mf.IndexedFieldCount >= 4 {
			t.Fatalf("index should remain 3-field after refusal, got %d", mf.IndexedFieldCount)
		}
	})
}
