package cmd

import (
	"accorder/pkg/calibre"
	"testing"
)

func TestShouldCompileFromJSONL(t *testing.T) {
	basePF := calibre.PointerFile{
		Version: 1,
		Library: calibre.PointerFileLibrary{UUID: "test", Librarian: "aggregate"},
		Index: calibre.PointerFileIndex{
			URL:               "library_index.zst",
			PointerGeneration: 1,
			NumBooks:          5000,
			JsonlURL:          "library_index.jsonl.zst",
			JsonlBytes:        10_000_000,
			JsonlRawBytes:     45_000_000,
			DictID:            1,
			ChunkSize:         262144,
		},
	}

	t.Run("clearnet_always_false", func(t *testing.T) {
		if shouldCompileFromJSONL(basePF, true) {
			t.Error("clearnet should always return false")
		}
	})

	t.Run("missing_jsonl_url", func(t *testing.T) {
		pf := basePF
		pf.Index.JsonlURL = ""
		if shouldCompileFromJSONL(pf, false) {
			t.Error("missing JsonlURL should return false")
		}
	})

	t.Run("missing_jsonl_bytes", func(t *testing.T) {
		pf := basePF
		pf.Index.JsonlBytes = 0
		if shouldCompileFromJSONL(pf, false) {
			t.Error("missing JsonlBytes should return false")
		}
	})

	t.Run("missing_jsonl_raw_bytes", func(t *testing.T) {
		pf := basePF
		pf.Index.JsonlRawBytes = 0
		if shouldCompileFromJSONL(pf, false) {
			t.Error("missing JsonlRawBytes should return false")
		}
	})

	t.Run("partial_fields_jsonl_bytes_but_no_raw", func(t *testing.T) {

		// Regression: must not compile without the RAM-gate input.
		pf := basePF
		pf.Index.JsonlRawBytes = 0
		if shouldCompileFromJSONL(pf, false) {
			t.Error("JsonlBytes set but JsonlRawBytes missing should return false")
		}
	})

	t.Run("exceeds_size_cap", func(t *testing.T) {
		pf := basePF
		pf.Index.NumBooks = compileGateConstants.SizeCap + 1
		if shouldCompileFromJSONL(pf, false) {
			t.Error("NumBooks exceeding SizeCap should return false")
		}
	})

	t.Run("at_size_cap", func(t *testing.T) {
		pf := basePF
		pf.Index.NumBooks = compileGateConstants.SizeCap

		// At the cap, the gate still passes (uses <=).
		// The RAM gate may refuse if MemAvailable is insufficient.
		got := shouldCompileFromJSONL(pf, false)

		// On a host with sufficient RAM, this should pass. We just
		// verify it doesn't panic.
		_ = got
	})

	t.Run("small_library_tor", func(t *testing.T) {

		// On a machine with sufficient RAM, a small library should pass.
		got := shouldCompileFromJSONL(basePF, false)
		avail := calibre.MemAvailable()
		if avail == 0 {
			if got {
				t.Error("MemAvailable=0 should refuse compile")
			}
			t.Skip("MemAvailable returned 0 — skipping positive test")
		}

		// With 5000 books / 45 MB JSONL, the predicted peak is modest.
		// Any machine with >2 GB available should pass.
		if avail > 2*1024*1024*1024 && !got {
			t.Errorf("shouldCompileFromJSONL = false for small library with %.1f GB available — expected true",
				float64(avail)/1e9)
		}
	})
}

func TestShouldCompileFromJSONL_RAMGateFallback(t *testing.T) {

	// When MemAvailable returns 0, the gate should refuse.
	pf := calibre.PointerFile{
		Index: calibre.PointerFileIndex{
			NumBooks:      1000,
			JsonlURL:      "library_index.jsonl.zst",
			JsonlBytes:    5_000_000,
			JsonlRawBytes: 20_000_000,
			DictID:        1,
			ChunkSize:     262144,
		},
	}
	avail := calibre.MemAvailable()
	if avail == 0 {
		if shouldCompileFromJSONL(pf, false) {
			t.Error("MemAvailable=0 should always refuse compile")
		}
	} else {
		t.Log("MemAvailable is non-zero; this test validates the zero case — skipping on this host")
	}
}
