package cmd

import (
	"accorder/pkg/calibre"
	"accorder/pkg/rclonexfer"
	"fmt"
	"log"
	"net"
	"net/http"
	"net/http/httputil"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

type AggregateServeParams struct {
	CommandName      string
	RemoteName       string
	AssetsRemoteName string
	ActionAlias      string

	AggregatePath   string
	UploadPrefix    string
	Bucket          string
	KeysFile        string
	S3AccessKey     string
	S3SecretKey     string
	S3Provider      string
	S3Endpoint      string
	CacheSize       string
	CacheSizeAssets string
	CacheMaxAge     string
	CacheMinFree    string
	DirCacheTime    string
	RcloneLogLevel  string
	PollInterval    int

	MeterWindow            time.Duration
	MeterMaxSessions       int
	MeterBucketGranularity time.Duration
	MeterMaxDistinct       int

	EgressMonthlyAllowance string
	EgressBudgetUSD        float64
	EgressPricePerGB       float64
	EgressLimit            string
	EgressBurst            string

	HasRcloneMembers bool
	LocalMembers     map[string]string

	Mode            string
	AuthStateDir    string
	InviteOffersDir string
	RegistryPath    string

	AllowFullRebuild bool
}

type AggregateServeResources struct {
	BucketFS         string
	State            *serveState
	Lease            *serveLease
	CacheDir         string
	RegistryPrefixes map[string]string
	RegistryPath     string
	Registry         map[string]calibre.LibraryMeta
	VFS              aggregateVFSResources
	Meter            *sessionMeter
	Breaker          *egressBreaker
	AuthRegistry     *grantRegistry
	Mux              *http.ServeMux
	BrowserMux       *http.ServeMux

	Cleanup func()
}

type aggregateVFSAddresses struct {
	Books  string
	Assets string
}

type aggregateVFSResources struct {
	BooksID   string
	AssetsID  string
	BooksFS   string
	AssetsFS  string
	Addresses aggregateVFSAddresses
}

type aggregateVFSPlane struct {
	Role             string
	RemoteName       string
	BucketFS         string
	CacheSize        string
	RemoteConfigured bool
	ServeID          string
	Addr             string
}

func buildAggregateBrowserMux(p AggregateServeParams, state *serveState, vfsAddrs aggregateVFSAddresses, meter *sessionMeter, breaker *egressBreaker, authReg *grantRegistry) *http.ServeMux {
	if p.Mode != "offline-private" {
		return nil
	}
	bmux := http.NewServeMux()
	calibre.RegisterFrontendRoutes(bmux)
	registerAggregateRoutes(bmux, state, vfsAddrs, meter, breaker, authReg, p.Mode, "", nil, true)
	for prefix, libPath := range p.LocalMembers {
		registerLocalMemberRoute(bmux, prefix, libPath, meter, breaker, authReg, p.Mode)
	}
	return bmux
}

func setupAggregateServe(p AggregateServeParams) (*AggregateServeResources, error) {
	if err := os.MkdirAll(p.AggregatePath, 0o755); err != nil {
		return nil, fmt.Errorf("%s: mkdir %s: %w", p.CommandName, p.AggregatePath, err)
	}

	if !p.HasRcloneMembers {
		return setupAggregateServeLocal(p)
	}
	return setupAggregateServeRclone(p)
}

func setupAggregateServeLocal(p AggregateServeParams) (*AggregateServeResources, error) {
	cacheDir := accorderCacheDir()

	registryPrefixes := make(map[string]string)
	registryPath := filepath.Join(p.AggregatePath, "members.json")
	if _, err := os.Stat(registryPath); os.IsNotExist(err) {
		registryPath = filepath.Join(accorderConfigDir, "aggregate_libraries.json")
	}
	if registry, rerr := readAggregateRegistry(registryPath); rerr == nil {
		for uuid, meta := range registry {
			if meta.Prefix != "" {
				registryPrefixes[uuid] = meta.Prefix
			}
		}
	} else {
		log.Printf("%s: registry unavailable (%v); prefix fallback disabled", p.CommandName, rerr)
	}

	// ca-120: every aggregate serve holds a per-serve lease (local ones
	// included — they open the shared typeahead dict cache) so the dict
	// reaper can see which generations are in use.
	lease, err := acquireServeLease("local-" + p.ActionAlias)
	if err != nil {
		return nil, fmt.Errorf("%s: %w", p.CommandName, err)
	}

	versionDir := p.AggregatePath
	initial, err := openSingleIndex(versionDir, cacheDir, registryPrefixes, lease)
	if err != nil {
		lease.Release()
		return nil, fmt.Errorf("%s: open local aggregate: %w", p.CommandName, err)
	}
	state := &serveState{current: initial}
	mf := initial.search.Manifest()
	log.Printf("%s: loaded local aggregate (%d books, %d segments, %d libraries, gen=%d)",
		p.CommandName, mf.NumBooks, mf.NumSegments, len(initial.libraries), initial.gen)

	if err := validateMeterFlags(p.MeterWindow, p.MeterBucketGranularity, p.MeterMaxSessions, p.MeterMaxDistinct); err != nil {
		state.current.close()
		lease.Release()
		return nil, fmt.Errorf("%s: %w", p.CommandName, err)
	}
	meter := &sessionMeter{
		window:      p.MeterWindow,
		granularity: p.MeterBucketGranularity,
		maxSessions: p.MeterMaxSessions,
		maxDistinct: p.MeterMaxDistinct,
	}

	breakerCfg, err := buildBreakerConfigFromParams(p)
	if err != nil {
		state.current.close()
		lease.Release()
		return nil, fmt.Errorf("%s: %w", p.CommandName, err)
	}
	breaker, err := newEgressBreaker(breakerCfg)
	if err != nil {
		state.current.close()
		lease.Release()
		return nil, fmt.Errorf("%s: %w", p.CommandName, err)
	}

	var authReg *grantRegistry
	if p.AuthStateDir != "" {
		var authErr error
		authReg, authErr = newGrantRegistry(p.AuthStateDir)
		if authErr != nil {
			state.current.close()
			lease.Release()
			return nil, fmt.Errorf("%s: auth registry: %w", p.CommandName, authErr)
		}
	}

	peerTable := newPeerEndpointTable(peerRegistryPath(p, registryPath))
	mux := http.NewServeMux()
	calibre.RegisterFrontendRoutesGated(mux, nil, browserPlaneWrap(authReg, p.Mode))
	registerAggregateRoutes(mux, state, aggregateVFSAddresses{}, meter, breaker, authReg, p.Mode, p.InviteOffersDir, peerTable, false, p.RegistryPath)
	for prefix, libPath := range p.LocalMembers {
		registerLocalMemberRoute(mux, prefix, libPath, meter, breaker, authReg, p.Mode)
	}
	browserMux := buildAggregateBrowserMux(p, state, aggregateVFSAddresses{}, meter, breaker, authReg)

	var cleanupOnce sync.Once
	return &AggregateServeResources{
		State:            state,
		Lease:            lease,
		BrowserMux:       browserMux,
		CacheDir:         cacheDir,
		RegistryPrefixes: registryPrefixes,
		Meter:            meter,
		Breaker:          breaker,
		AuthRegistry:     authReg,
		Mux:              mux,
		Cleanup: func() {
			cleanupOnce.Do(func() {
				started := time.Now()
				log.Printf("%s: shutdown cleanup started", p.CommandName)
				defer func() {
					log.Printf("%s: shutdown cleanup completed in %s", p.CommandName, time.Since(started).Round(time.Millisecond))
				}()
				runShutdownStep(p.CommandName, "index-close", state.current.close)
				runShutdownStep(p.CommandName, "dictionary-lease-release", lease.Release)
			})
		},
	}, nil
}

func setupAggregateServeRclone(p AggregateServeParams) (*AggregateServeResources, error) {
	if p.RemoteName == "" || p.AssetsRemoteName == "" {
		return nil, fmt.Errorf("%s: both books and assets remote names are required", p.CommandName)
	}
	if err := validateSavedAssetsCacheRemoteCollisions(p.ActionAlias); err != nil {
		return nil, fmt.Errorf("%s: %w", p.CommandName, err)
	}
	cacheDir := accorderCacheDir()
	if err := rclonexfer.SetCacheDir(cacheDir); err != nil {
		return nil, fmt.Errorf("%s: set cache dir: %w", p.CommandName, err)
	}
	rclonexfer.UseHostSignalHandler()
	rclonexfer.Initialize()
	rcloneInitialized := true
	var cleanupOnce sync.Once
	var mutationRelease func()
	var lease *serveLease
	var state *serveState
	planes := []*aggregateVFSPlane{
		{Role: "books", RemoteName: p.RemoteName, CacheSize: p.CacheSize},
		{Role: "assets", RemoteName: p.AssetsRemoteName, CacheSize: p.CacheSizeAssets},
	}
	cleanupAll := func() {
		cleanupOnce.Do(func() {
			started := time.Now()
			log.Printf("%s: shutdown cleanup started", p.CommandName)
			defer func() {
				log.Printf("%s: shutdown cleanup completed in %s", p.CommandName, time.Since(started).Round(time.Millisecond))
			}()
			for i := len(planes) - 1; i >= 0; i-- {
				plane := planes[i]
				if plane.ServeID != "" {
					_ = runShutdownPhase(p.CommandName, plane.Role+"-vfs-stop", func() error {
						return rclonexfer.StopServe(plane.ServeID)
					})
				}
			}
			if state != nil {
				runShutdownStep(p.CommandName, "index-close", state.current.close)
			}
			for i := len(planes) - 1; i >= 0; i-- {
				plane := planes[i]
				if plane.RemoteConfigured {
					_ = runShutdownPhase(p.CommandName, plane.Role+"-remote-delete", func() error {
						return rclonexfer.DeleteRemote(plane.RemoteName)
					})
				}
			}
			if lease != nil {
				runShutdownStep(p.CommandName, "dictionary-lease-release", lease.Release)
			}
			if mutationRelease != nil {
				runShutdownStep(p.CommandName, "cache-mutation-locks-release", mutationRelease)
			}
			if rcloneInitialized {
				runShutdownStep(p.CommandName, "librclone-finalize", rclonexfer.Finalize)
				rcloneInitialized = false
			}
		})
	}
	// Must FOLLOW Initialize: it calls fs/log.InitLogging, which resets the
	// handler level to fs.InitialLogLevel() and would discard an earlier set.
	if err := rclonexfer.SetLogLevel(p.RcloneLogLevel); err != nil {
		cleanupAll()
		return nil, fmt.Errorf("%s: %w", p.CommandName, err)
	}

	// ca-120: report-only cache inventory, the per-remote-name mutation
	// locks, and one atomic ledger batch for both VFS identities. These are
	// durably recorded BEFORE either VFS starts.
	var err error
	mutationRelease, err = serveCacheStartupMany(p.CommandName, []cacheTreeIdentity{
		{RemoteName: p.RemoteName, RemoteRoot: p.Bucket},
		{RemoteName: p.AssetsRemoteName, RemoteRoot: p.Bucket},
	})
	if err != nil {
		cleanupAll()
		return nil, err
	}
	lease, err = acquireServeLease(p.RemoteName)
	if err != nil {
		cleanupAll()
		return nil, fmt.Errorf("%s: %w", p.CommandName, err)
	}

	for _, plane := range planes {
		_ = rclonexfer.DeleteRemote(plane.RemoteName)
		plane.RemoteConfigured = true
		if err := rclonexfer.ConfigS3Remote(plane.RemoteName, rclonexfer.S3RemoteConfig{
			Provider:  p.S3Provider,
			AccessKey: p.S3AccessKey,
			SecretKey: p.S3SecretKey,
			Endpoint:  p.S3Endpoint,
		}); err != nil {
			cleanupAll()
			return nil, fmt.Errorf("%s: config %s s3 remote: %w", p.CommandName, plane.Role, err)
		}
		plane.BucketFS = plane.RemoteName + ":" + p.Bucket
	}
	bucketFS := planes[0].BucketFS

	registryPrefixes := make(map[string]string)
	registryPath := filepath.Join(p.AggregatePath, "members.json")
	if _, err := os.Stat(registryPath); os.IsNotExist(err) {
		registryPath = filepath.Join(accorderConfigDir, "aggregate_libraries.json")
	}
	if registry, rerr := readAggregateRegistry(registryPath); rerr == nil {
		for uuid, meta := range registry {
			if meta.Prefix != "" {
				registryPrefixes[uuid] = meta.Prefix
			}
		}
	} else {
		log.Printf("%s: registry unavailable (%v); prefix fallback disabled", p.CommandName, rerr)
	}

	staleVersionDir := currentVersionPath(p.AggregatePath)
	versionDir, err := fetchAggregateVersion(bucketFS, p.UploadPrefix, p.AggregatePath)
	if err != nil {
		local := ""
		if staleVersionDir != "" {
			if _, statErr := os.Stat(staleVersionDir); statErr == nil {
				local = staleVersionDir
			}
		}
		if local == "" {
			cleanupAll()
			return nil, fmt.Errorf("%s: fetch aggregate: %w", p.CommandName, err)
		}
		log.Printf("%s: S3 unreachable (%v); starting offline from last-known local copy", p.CommandName, err)
		versionDir = local
	}
	freshlyFetched := versionDir != staleVersionDir
	initial, err := openSingleIndex(versionDir, cacheDir, registryPrefixes, lease)
	if err != nil {
		if freshlyFetched {
			_ = os.RemoveAll(versionDir)
		}
		cleanupAll()
		return nil, fmt.Errorf("%s: open aggregate: %w", p.CommandName, err)
	}
	state = &serveState{current: initial}
	if freshlyFetched {
		if _, err := commitVersion(p.AggregatePath, versionDir); err != nil {
			// Close the index (via cleanupAll) BEFORE deleting the version
			// dir it holds open files in — RemoveAll over open handles fails
			// silently on Windows and would strand the half-committed dir.
			cleanupAll()
			_ = os.RemoveAll(versionDir)
			return nil, fmt.Errorf("%s: commit aggregate: %w", p.CommandName, err)
		}
		if staleVersionDir != "" {
			pruneVersion(staleVersionDir)
		}
	}
	mf := initial.search.Manifest()
	log.Printf("%s: loaded aggregate (%d books, %d segments, %d libraries, gen=%d)",
		p.CommandName, mf.NumBooks, mf.NumSegments, len(initial.libraries), initial.gen)

	for _, plane := range planes {
		serveID, addr, err := rclonexfer.ServeHTTPWithVFS(plane.BucketFS, "127.0.0.1:0", rclonexfer.VFSOptions{
			CacheMode:         "full",
			CacheMaxSize:      plane.CacheSize,
			CacheMaxAge:       p.CacheMaxAge,
			CacheMinFreeSpace: p.CacheMinFree,
			DirCacheTime:      p.DirCacheTime,
			ReadOnly:          true,
		})
		if err != nil {
			cleanupAll()
			return nil, fmt.Errorf("%s: start %s file plane: %w", p.CommandName, plane.Role, err)
		}
		plane.ServeID = serveID
		plane.Addr = addr
		log.Printf("%s: %s VFS file plane on %s (bucket: %s, cache: %s max-size, %s max-age, %s min-free, %s dir-cache-time)",
			p.CommandName, plane.Role, addr, p.Bucket, plane.CacheSize, p.CacheMaxAge, p.CacheMinFree, p.DirCacheTime)
	}
	if p.PollInterval <= 0 && p.DirCacheTime != "" {
		log.Printf("%s: WARNING: poll-interval is 0, so no generation ever invalidates the VFS directory cache; new or replaced member files become visible only after dir-cache-time (%s)",
			p.CommandName, p.DirCacheTime)
	}
	vfsAddrs := aggregateVFSAddresses{Books: planes[0].Addr, Assets: planes[1].Addr}

	if err := validateMeterFlags(p.MeterWindow, p.MeterBucketGranularity, p.MeterMaxSessions, p.MeterMaxDistinct); err != nil {
		cleanupAll()
		return nil, fmt.Errorf("%s: %w", p.CommandName, err)
	}
	meter := &sessionMeter{
		window:      p.MeterWindow,
		granularity: p.MeterBucketGranularity,
		maxSessions: p.MeterMaxSessions,
		maxDistinct: p.MeterMaxDistinct,
	}

	breakerCfg, err := buildBreakerConfigFromParams(p)
	if err != nil {
		cleanupAll()
		return nil, fmt.Errorf("%s: %w", p.CommandName, err)
	}
	breaker, err := newEgressBreaker(breakerCfg)
	if err != nil {
		cleanupAll()
		return nil, fmt.Errorf("%s: %w", p.CommandName, err)
	}

	var authReg *grantRegistry
	if p.AuthStateDir != "" {
		var authErr error
		authReg, authErr = newGrantRegistry(p.AuthStateDir)
		if authErr != nil {
			cleanupAll()
			return nil, fmt.Errorf("%s: auth registry: %w", p.CommandName, authErr)
		}
	}

	peerTable := newPeerEndpointTable(peerRegistryPath(p, registryPath))
	mux := http.NewServeMux()
	calibre.RegisterFrontendRoutesGated(mux, nil, browserPlaneWrap(authReg, p.Mode))
	registerAggregateRoutes(mux, state, vfsAddrs, meter, breaker, authReg, p.Mode, p.InviteOffersDir, peerTable, false, p.RegistryPath)
	for prefix, libPath := range p.LocalMembers {
		registerLocalMemberRoute(mux, prefix, libPath, meter, breaker, authReg, p.Mode)
	}
	browserMux := buildAggregateBrowserMux(p, state, vfsAddrs, meter, breaker, authReg)

	var fullRegistry map[string]calibre.LibraryMeta
	if reg, rerr := readAggregateRegistry(registryPath); rerr == nil {
		fullRegistry = reg
	}

	return &AggregateServeResources{
		BucketFS:         bucketFS,
		State:            state,
		Lease:            lease,
		BrowserMux:       browserMux,
		CacheDir:         cacheDir,
		RegistryPrefixes: registryPrefixes,
		RegistryPath:     registryPath,
		Registry:         fullRegistry,
		VFS: aggregateVFSResources{
			BooksID:   planes[0].ServeID,
			AssetsID:  planes[1].ServeID,
			BooksFS:   planes[0].BucketFS,
			AssetsFS:  planes[1].BucketFS,
			Addresses: vfsAddrs,
		},
		Meter:        meter,
		Breaker:      breaker,
		AuthRegistry: authReg,
		Mux:          mux,
		Cleanup:      cleanupAll,
	}, nil
}

func scanMembersForServe(aggregatePath, explicitRegistryPath string) (hasRclone bool, localMembers map[string]string, err error) {
	registryPath := explicitRegistryPath
	if registryPath == "" {
		registryPath = filepath.Join(aggregatePath, "members.json")
		if _, statErr := os.Stat(registryPath); os.IsNotExist(statErr) {
			registryPath = filepath.Join(accorderConfigDir, "aggregate_libraries.json")
		}
	}
	registry, err := readAggregateRegistry(registryPath)
	if err != nil {
		return false, nil, err
	}
	localMembers = make(map[string]string)
	for _, meta := range registry {
		if meta.IsActive() && meta.IsLocal() && meta.LocalPath != "" {
			localMembers[meta.Prefix] = meta.LocalPath
		}
	}
	return calibre.HasRcloneMembers(registry), localMembers, nil
}

func requireS3Creds(bucket, accessKey, secretKey, provider, endpoint string) error {
	for _, field := range []struct{ name, val string }{
		{"--bucket", bucket},
		{"--s3-access-key", accessKey},
		{"--s3-secret-key", secretKey},
		{"--s3-provider", provider},
		{"--s3-endpoint", endpoint},
	} {
		if field.val == "" {
			return fmt.Errorf("%s is required when the registry contains rclone members", field.name)
		}
	}
	return nil
}

func registerLocalMemberRoute(mux *http.ServeMux, prefix, libraryPath string, meter *sessionMeter, breaker *egressBreaker, authReg *grantRegistry, mode string) {
	pattern := "/files/" + prefix + "/"
	fs := http.FileServer(http.Dir(libraryPath))
	var handler http.Handler = http.StripPrefix(pattern, fs)
	handler = withEndpointProtection(handler, meter, breaker)
	if authReg != nil {
		if mode == "private" {
			handler = withAuth(handler, authReg)
		} else {
			// Tag-only on non-private shares: classes granted friends for
			// metering without gating access (mode contract: public never 401s).
			handler = withAuthTag(handler, authReg)
		}
	}
	mux.Handle(pattern, handler)
	log.Printf("registered local file route: %s -> %s", pattern, libraryPath)
}

func newPeerReverseProxy(prefix, endpoint, grantToken string) *httputil.ReverseProxy {
	target, err := url.Parse(endpoint)
	if err != nil || target.Host == "" {
		log.Printf("peer file route %s: invalid endpoint %q (%v); skipping", prefix, endpoint, err)
		return nil
	}
	stripPrefix := "/files/" + prefix
	return &httputil.ReverseProxy{
		Director: func(req *http.Request) {
			req.URL.Scheme = target.Scheme
			req.URL.Host = target.Host
			rel := strings.TrimPrefix(req.URL.Path, stripPrefix)
			rel = strings.TrimPrefix(rel, "/")
			req.URL.Path = singleJoiningSlash(target.Path, "/files/"+rel)
			req.URL.RawPath = ""
			req.Host = target.Host
			if grantToken != "" {
				req.Header.Set("Authorization", "Bearer "+grantToken)
			} else {
				req.Header.Del("Authorization")
			}
			req.Header.Del("Cookie")
		},
		ModifyResponse: func(resp *http.Response) error {
			resp.Header.Del("Set-Cookie")
			return nil
		},
		ErrorHandler: func(w http.ResponseWriter, _ *http.Request, err error) {
			log.Printf("peer file proxy %s: %v", prefix, err)
			http.Error(w, "peer member unavailable", http.StatusBadGateway)
		},
	}
}

func isUnsafeProxyHost(host string) bool {
	ip := net.ParseIP(host)
	if ip == nil {
		return false
	}
	return ip.IsLoopback() || ip.IsLinkLocalUnicast() || ip.IsLinkLocalMulticast()
}

func singleJoiningSlash(a, b string) string {
	switch {
	case a == "" || a == "/":
		return b
	case b == "":
		return a
	default:
		return strings.TrimSuffix(a, "/") + "/" + strings.TrimPrefix(b, "/")
	}
}

type peerEndpointTable struct {
	registryPath string
	mu           sync.Mutex
	mtime        time.Time
	loaded       bool
	proxies      map[string]*httputil.ReverseProxy
}

func newPeerEndpointTable(registryPath string) *peerEndpointTable {
	return &peerEndpointTable{registryPath: registryPath, proxies: map[string]*httputil.ReverseProxy{}}
}

func peerRegistryPath(p AggregateServeParams, localRegistryPath string) string {
	if p.RegistryPath != "" {
		return p.RegistryPath
	}
	return localRegistryPath
}

func (t *peerEndpointTable) proxyFor(prefix string) *httputil.ReverseProxy {
	if t == nil || t.registryPath == "" {
		return nil
	}
	t.mu.Lock()
	defer t.mu.Unlock()
	if fi, err := os.Stat(t.registryPath); err == nil && (!t.loaded || !fi.ModTime().Equal(t.mtime)) {
		if registry, rerr := readAggregateRegistry(t.registryPath); rerr == nil {
			next := map[string]*httputil.ReverseProxy{}
			for _, meta := range registry {
				if !(meta.IsActive() && meta.IsPeer() && meta.Endpoint != "" && meta.Prefix != "") {
					continue
				}
				if u, perr := url.Parse(meta.Endpoint); perr != nil || u.Host == "" || isUnsafeProxyHost(u.Hostname()) {
					log.Printf("peer file table: skipping %s — unusable/unsafe endpoint %q", meta.Prefix, meta.Endpoint)
					continue
				}
				if px := newPeerReverseProxy(meta.Prefix, meta.Endpoint, meta.GrantToken); px != nil {
					next[meta.Prefix] = px
				}
			}
			t.proxies = next
			t.mtime = fi.ModTime()
			t.loaded = true
		} else {
			log.Printf("peer file table: registry reload failed (%v); keeping %d cached peer route(s)", rerr, len(t.proxies))
		}
	}
	return t.proxies[prefix]
}

func buildBreakerConfigFromParams(p AggregateServeParams) (egressBreakerConfig, error) {
	var cfg egressBreakerConfig
	cfg.PricePerGB = p.EgressPricePerGB

	if p.EgressLimit != "" {
		v, err := parseByteSize(p.EgressLimit)
		if err != nil {
			return cfg, fmt.Errorf("--egress-limit: %w", err)
		}
		cfg.RawLimitBytes = v
		cfg.RawLimitIsSet = true
	}
	if p.EgressBudgetUSD > 0 {
		cfg.BudgetUSD = p.EgressBudgetUSD
		cfg.BudgetUSDIsSet = true
	}
	if p.EgressMonthlyAllowance != "" {
		v, err := parseByteSize(p.EgressMonthlyAllowance)
		if err != nil {
			return cfg, fmt.Errorf("--egress-monthly-allowance: %w", err)
		}
		cfg.MonthlyAllowanceBytes = v
		cfg.MonthlyAllowanceIsSet = true
	}
	if p.EgressBurst != "" {
		v, err := parseByteSize(p.EgressBurst)
		if err != nil {
			return cfg, fmt.Errorf("--egress-burst: %w", err)
		}
		cfg.BurstBytes = v
		cfg.BurstIsSet = true
	}
	return cfg, nil
}
