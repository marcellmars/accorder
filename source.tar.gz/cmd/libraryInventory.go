package cmd

import (
	"fmt"
	"os"
	"path/filepath"
	"sort"

	"accorder/pkg/libraryflow"
	"golang.org/x/sync/errgroup"
)

type observedSourceFile struct {
	Object   libraryflow.Object
	Evidence sourceFileEvidence
}

// Scoped to one scan/validation boundary; never serialized or saved in Object.
type sourceInventory struct {
	Root    string
	Objects []libraryflow.Object
	Files   map[string]observedSourceFile
	Catalog *catalogSourceEvidence
}

var sourceObserveLocalObject = libraryflow.ObserveLocalObject

func scanSourceObjects(root string) (*sourceInventory, error) {
	database, err := observeBuildDatabase(root)
	if err != nil {
		return nil, err
	}
	if database != nil && database.SQLite {
		return readCatalogInventory(root, database)
	}
	// Retained non-SQLite/import evidence uses the historical contract. It
	// must never be promoted into Calibre database authority.
	return parallelInventory(root, 16, true)
}

func parallelLocalObjects(root string, workers int) ([]libraryflow.Object, error) {
	inventory, err := parallelInventory(root, workers, false)
	if err != nil {
		return nil, err
	}
	return inventory.Objects, nil
}

// Enumerate every directory and stat every file afresh, including excluded
// paths (a hidden symlink is still unsafe). No persisted directory-mtime trust,
// payload reads, or sharing across independent coherence boundaries. Directory
// workers alone did not improve the measured cold HDD latency.
func parallelInventory(root string, workers int, observe bool) (*sourceInventory, error) {
	finish := beginLibraryWork("inventory")
	defer finish(1)
	result := &sourceInventory{Root: filepath.Clean(root)}
	if observe {
		result.Files = make(map[string]observedSourceFile)
	}
	if workers < 1 {
		return nil, fmt.Errorf("inventory needs at least one worker")
	}
	info, err := os.Lstat(root)
	if err != nil {
		return nil, err
	}
	if !info.IsDir() {
		return result, nil
	} // Match WalkDir's non-followed root behavior.
	dirs := []string{root}
	var objects []libraryflow.Object
	for len(dirs) != 0 {
		type batch struct {
			dirs    []string
			objects []libraryflow.Object
			files   []observedSourceFile
		}
		batches := make([]batch, len(dirs))
		var group errgroup.Group
		group.SetLimit(workers)
		for i, dir := range dirs {
			group.Go(func() error {
				finishDirectory := beginLibraryWork("directory-enumeration")
				entries, err := os.ReadDir(dir)
				finishDirectory(1)
				if err != nil {
					return err
				}
				for _, entry := range entries {
					path := filepath.Join(dir, entry.Name())
					if entry.Type()&os.ModeSymlink != 0 {
						return fmt.Errorf("refusing symlink in publish candidate: %s", path)
					}
					if entry.IsDir() {
						batches[i].dirs = append(batches[i].dirs, path)
						continue
					}
					finishMetadata := beginLibraryWork("file-metadata")
					info, err := entry.Info()
					finishMetadata(1)
					if err != nil {
						return err
					}
					rel, err := filepath.Rel(root, path)
					if err != nil {
						return err
					}
					rel = filepath.ToSlash(rel)
					var object libraryflow.Object
					if observe && libraryflow.IsSourcePath(rel) {
						finishNative := beginLibraryWork("native-evidence")
						var id, capability string
						object, id, capability = sourceObserveLocalObject(rel, path, info)
						finishNative(1)
						batches[i].files = append(batches[i].files, observedSourceFile{object, sourceFileEvidence{rel, id, capability}})
					} else {
						object = libraryflow.NewLocalObjectAt(rel, path, info)
					}
					batches[i].objects = append(batches[i].objects, object)
				}
				return nil
			})
		}
		if err := group.Wait(); err != nil {
			return nil, err
		}
		dirs = nil
		for _, batch := range batches {
			dirs = append(dirs, batch.dirs...)
			objects = append(objects, batch.objects...)
			for _, file := range batch.files {
				result.Files[file.Object.Path] = file
			}
		}
	}
	sort.Slice(objects, func(i, j int) bool { return objects[i].Path < objects[j].Path })
	result.Objects = objects
	return result, nil
}
