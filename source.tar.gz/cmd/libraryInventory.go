package cmd

import (
	"fmt"
	"os"
	"path/filepath"
	"sort"

	"accorder/pkg/libraryflow"
	"golang.org/x/sync/errgroup"
)

// Enumerate every directory and stat every file afresh, including excluded
// paths (a hidden symlink is still unsafe). Bounded directory-level concurrency
// overlaps cold filesystem latency without trusting persisted directory mtimes
// or removing either side of a publication's coherence check. Sorted output is
// identical to the former WalkDir inventory. No payload file is opened here.
func parallelLocalObjects(root string, workers int) ([]libraryflow.Object, error) {
	if workers < 1 {
		return nil, fmt.Errorf("inventory needs at least one worker")
	}
	info, err := os.Lstat(root)
	if err != nil {
		return nil, err
	}
	if !info.IsDir() {
		return nil, nil
	} // Match WalkDir's non-followed root behavior.
	dirs := []string{root}
	var objects []libraryflow.Object
	for len(dirs) != 0 {
		type batch struct {
			dirs    []string
			objects []libraryflow.Object
		}
		batches := make([]batch, len(dirs))
		var group errgroup.Group
		group.SetLimit(workers)
		for i, dir := range dirs {
			group.Go(func() error {
				entries, err := os.ReadDir(dir)
				if err != nil {
					return err
				}
				for _, entry := range entries {
					path := filepath.Join(dir, entry.Name())
					if entry.Type()&os.ModeSymlink != 0 {
						return fmt.Errorf("refusing symlink in publish candidate: %s", path)
					}
					if entry.IsDir() {
						batches[i].dirs = append(batches[i].dirs, path)
						continue
					}
					info, err := entry.Info()
					if err != nil {
						return err
					}
					rel, err := filepath.Rel(root, path)
					if err != nil {
						return err
					}
					batches[i].objects = append(batches[i].objects, libraryflow.NewLocalObjectAt(filepath.ToSlash(rel), path, info))
				}
				return nil
			})
		}
		if err := group.Wait(); err != nil {
			return nil, err
		}
		dirs = nil
		for _, batch := range batches {
			dirs = append(dirs, batch.dirs...)
			objects = append(objects, batch.objects...)
		}
	}
	sort.Slice(objects, func(i, j int) bool { return objects[i].Path < objects[j].Path })
	return objects, nil
}
