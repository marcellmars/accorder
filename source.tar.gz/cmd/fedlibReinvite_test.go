//go:build !tailscale

package cmd

// fedlib-reinvite-identity Phase 2 + 4 tests: the re-invite branch of
// `fedlib members invite` (identity-bearing blobs, label defaulting,
// liminal placeholder re-issue, alias-safe prefix validation) and the
// emitted member CLI lines (stdout stays blob-only, hint on stderr).

import (
	"os"
	"path/filepath"
	"strings"
	"testing"

	"accorder/pkg/calibre"
	"accorder/pkg/fedlibinvite"

	uuid "github.com/satori/go.uuid"
)

const readyMemberUUID = "4d1f7c9a-2b3e-4f5a-9c8d-7e6f5a4b3c2d"

// seedRegistry writes the given registry into a fresh fedlib dir and
// returns the dir and the registry file's raw bytes after the write.
func seedRegistry(t *testing.T, registry map[string]calibre.LibraryMeta) (fedlibDir string, raw []byte) {
	t.Helper()
	fedlibDir = t.TempDir()
	registryPath := filepath.Join(fedlibDir, "members.json")
	if err := saveMembersRegistry(registryPath, registry); err != nil {
		t.Fatalf("seed registry: %v", err)
	}
	raw, err := os.ReadFile(registryPath)
	if err != nil {
		t.Fatalf("read seeded registry: %v", err)
	}
	return fedlibDir, raw
}

func decodeStdoutBlob(t *testing.T, stdout string) *fedlibinvite.WriteInvite {
	t.Helper()
	blob := strings.TrimSuffix(stdout, "\n")
	if strings.Contains(blob, "\n") {
		t.Fatalf("stdout is not a single line: %q", stdout)
	}
	inv, err := fedlibinvite.DecodeWriteInvite(blob)
	if err != nil {
		t.Fatalf("decode stdout blob: %v", err)
	}
	return inv
}

// ═══════════════════════════════════════════════════════════════════
// Re-invite of a ready member: blob carries the registry UUID, the
// registry file stays byte-identical, label defaults to the registry
// librarian.
// ═══════════════════════════════════════════════════════════════════

func TestReinvite_ReadyMemberEmbedsUUIDAndLeavesRegistryUntouched(t *testing.T) {
	_ = testSetup(t)
	fedlibDir, before := seedRegistry(t, map[string]calibre.LibraryMeta{
		readyMemberUUID: {Librarian: "Alice's Library", Prefix: "alice", State: "ready", DictID: 2},
	})

	stdout, stderr, err := captureInviteOutput(t, runNilCtx(reinviteCmd("", "alice", fedlibDir).Run))
	if err != nil {
		t.Fatalf("re-invite: %v", err)
	}

	inv := decodeStdoutBlob(t, stdout)
	if inv.LibraryID != readyMemberUUID {
		t.Errorf("blob library_id = %q, want registry key %q", inv.LibraryID, readyMemberUUID)
	}
	if inv.Label != "Alice's Library" {
		t.Errorf("blob label = %q, want defaulted registry librarian", inv.Label)
	}
	if !strings.Contains(stderr, "re-inviting existing member") {
		t.Errorf("stderr missing re-invite log:\n%s", stderr)
	}

	after, err := os.ReadFile(filepath.Join(fedlibDir, "members.json"))
	if err != nil {
		t.Fatalf("read registry after: %v", err)
	}
	if string(before) != string(after) {
		t.Errorf("registry changed by re-invite\nbefore: %s\nafter:  %s", before, after)
	}
}

func TestReinvite_DifferingLabelWarnsAndWinsInBlob(t *testing.T) {
	_ = testSetup(t)
	fedlibDir, before := seedRegistry(t, map[string]calibre.LibraryMeta{
		readyMemberUUID: {Librarian: "Alice's Library", Prefix: "alice", State: "ready", DictID: 2},
	})

	stdout, stderr, err := captureInviteOutput(t, runNilCtx(reinviteCmd("Other Name", "alice", fedlibDir).Run))
	if err != nil {
		t.Fatalf("re-invite: %v", err)
	}
	if !strings.Contains(stderr, "WARNING") || !strings.Contains(stderr, "differs from registry librarian") {
		t.Errorf("stderr missing label-mismatch warning:\n%s", stderr)
	}
	inv := decodeStdoutBlob(t, stdout)
	if inv.Label != "Other Name" {
		t.Errorf("blob label = %q, want provided label", inv.Label)
	}
	if inv.LibraryID != readyMemberUUID {
		t.Errorf("blob library_id = %q, want %q", inv.LibraryID, readyMemberUUID)
	}

	after, _ := os.ReadFile(filepath.Join(fedlibDir, "members.json"))
	if string(before) != string(after) {
		t.Errorf("registry entry must stay untouched on label mismatch")
	}
}

// A member invited before WF3 has DictID=0. Re-inviting it must heal the member
// by allocating a fresh unique DictID (>=2) and persisting it, so the republished
// container no longer ships the default DictID=1 (which collides at compose time).
func TestReinvite_LegacyZeroDictIDHealed(t *testing.T) {
	_ = testSetup(t)
	fedlibDir, _ := seedRegistry(t, map[string]calibre.LibraryMeta{
		readyMemberUUID: {Librarian: "Alice's Library", Prefix: "alice", State: "ready"},
	})

	stdout, _, err := captureInviteOutput(t, runNilCtx(reinviteCmd("", "alice", fedlibDir).Run))
	if err != nil {
		t.Fatalf("re-invite: %v", err)
	}

	inv := decodeStdoutBlob(t, stdout)
	if inv.DictID < 2 {
		t.Errorf("legacy re-invite must allocate a fresh DictID >= 2, got %d", inv.DictID)
	}

	reg, _, err := loadMembersRegistryFromPath(filepath.Join(fedlibDir, "members.json"))
	if err != nil {
		t.Fatalf("load registry: %v", err)
	}
	if got := reg[readyMemberUUID].DictID; got != inv.DictID {
		t.Errorf("registry DictID = %d, want healed value %d persisted", got, inv.DictID)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Legacy placeholder (invited:<prefix>, written by an older binary):
// re-issue migrates it in place — minted identity in the blob, the
// placeholder key deleted, the minted key written.
// (operator-minted-member-uuid: the placeholder-shape assertions that
// lived here were retired; new binaries never write invited:<prefix>.)
// ═══════════════════════════════════════════════════════════════════

func TestReinvite_LegacyPlaceholderMigratesOnReissue(t *testing.T) {
	_ = testSetup(t)
	fedlibDir, _ := seedRegistry(t, map[string]calibre.LibraryMeta{
		"invited:bob": {Librarian: "Bob", Prefix: "bob", State: "invited"},
	})

	stdout, stderr, err := captureInviteOutput(t, runNilCtx(reinviteCmd("Bobby", "bob", fedlibDir).Run))
	if err != nil {
		t.Fatalf("legacy re-issue: %v", err)
	}
	if !strings.Contains(stderr, "re-issuing invite for pending member") || !strings.Contains(stderr, "migrating legacy placeholder") {
		t.Errorf("stderr missing migration log:\n%s", stderr)
	}
	inv := decodeStdoutBlob(t, stdout)
	if _, err := uuid.FromString(inv.LibraryID); err != nil {
		t.Errorf("legacy re-issue blob library_id = %q, want minted UUID: %v", inv.LibraryID, err)
	}

	registry, _, err := loadMembersRegistryFromPath(filepath.Join(fedlibDir, "members.json"))
	if err != nil {
		t.Fatalf("reload registry: %v", err)
	}
	if _, ok := registry["invited:bob"]; ok {
		t.Error("invited:bob placeholder survived the migration")
	}
	if len(registry) != 1 {
		t.Fatalf("registry has %d entries after migration, want exactly 1: %+v", len(registry), registry)
	}
	entry, ok := registry[inv.LibraryID]
	if !ok {
		t.Fatalf("registry not keyed by the minted blob UUID %q: %+v", inv.LibraryID, registry)
	}
	if entry.Librarian != "Bobby" {
		t.Errorf("migrated librarian = %q, want refreshed %q", entry.Librarian, "Bobby")
	}
	if entry.State != "invited" {
		t.Errorf("migrated state = %q, want invited", entry.State)
	}
	if entry.Prefix != "bob" {
		t.Errorf("migrated prefix = %q, want bob", entry.Prefix)
	}
}

func TestReinvite_LiminalEmptyLabelKeepsPlaceholderLibrarian(t *testing.T) {
	_ = testSetup(t)
	fedlibDir, _ := seedRegistry(t, map[string]calibre.LibraryMeta{
		"invited:bob": {Librarian: "Bob", Prefix: "bob", State: "invited"},
	})

	stdout, _, err := captureInviteOutput(t, runNilCtx(reinviteCmd("", "bob", fedlibDir).Run))
	if err != nil {
		t.Fatalf("legacy re-issue with empty label: %v", err)
	}
	if inv := decodeStdoutBlob(t, stdout); inv.Label != "Bob" {
		t.Errorf("blob label = %q, want placeholder librarian %q", inv.Label, "Bob")
	}
}

// ═══════════════════════════════════════════════════════════════════
// New-prefix invites: the operator mints the member identity at invite
// time (operator-minted-member-uuid). Registry keyed by the real UUID
// from day one; blob carries the same UUID; empty label rejected.
// (Replaces TestReinvite_NewPrefixInviteWritesPlaceholder — the
// invited:<prefix> placeholder is never written by new binaries.)
// ═══════════════════════════════════════════════════════════════════

func TestInvite_MintsMemberUUID(t *testing.T) {
	_ = testSetup(t)
	fedlibDir := t.TempDir()

	stdout, stderr, err := captureInviteOutput(t, runNilCtx(reinviteCmd("Carol", "carol", fedlibDir).Run))
	if err != nil {
		t.Fatalf("new invite: %v", err)
	}
	inv := decodeStdoutBlob(t, stdout)
	if _, err := uuid.FromString(inv.LibraryID); err != nil {
		t.Errorf("new invite blob library_id = %q, want parseable UUID: %v", inv.LibraryID, err)
	}
	if !strings.Contains(stderr, "state: invited") || !strings.Contains(stderr, "libraryID: "+inv.LibraryID) {
		t.Errorf("stderr missing minted invited status line:\n%s", stderr)
	}

	registry, _, err := loadMembersRegistryFromPath(filepath.Join(fedlibDir, "members.json"))
	if err != nil {
		t.Fatalf("reload registry: %v", err)
	}
	if _, ok := registry["invited:carol"]; ok {
		t.Error("legacy invited:carol placeholder written by new binary")
	}
	entry, ok := registry[inv.LibraryID]
	if !ok {
		t.Fatalf("registry not keyed by minted blob UUID %q: %+v", inv.LibraryID, registry)
	}
	if entry.Librarian != "Carol" || entry.Prefix != "carol" || entry.State != "invited" {
		t.Errorf("minted entry = %+v, want {Carol carol invited}", entry)
	}
}

// Running the invite twice for the same not-yet-joined prefix re-embeds
// the SAME minted UUID: the second run hits the re-invite branch
// (success criterion 6 — new-invite and re-invite share the embed path).
func TestInvite_ReissueIsIdempotent(t *testing.T) {
	_ = testSetup(t)
	fedlibDir := t.TempDir()

	stdout1, _, err := captureInviteOutput(t, runNilCtx(reinviteCmd("Carol", "carol", fedlibDir).Run))
	if err != nil {
		t.Fatalf("first invite: %v", err)
	}
	first := decodeStdoutBlob(t, stdout1)

	stdout2, stderr2, err := captureInviteOutput(t, runNilCtx(reinviteCmd("", "carol", fedlibDir).Run))
	if err != nil {
		t.Fatalf("second invite: %v", err)
	}
	second := decodeStdoutBlob(t, stdout2)

	if second.LibraryID != first.LibraryID {
		t.Errorf("second invite minted a different UUID: %q vs %q", second.LibraryID, first.LibraryID)
	}
	if !strings.Contains(stderr2, "re-inviting existing member") {
		t.Errorf("second invite did not take the re-invite branch:\n%s", stderr2)
	}

	registry, _, err := loadMembersRegistryFromPath(filepath.Join(fedlibDir, "members.json"))
	if err != nil {
		t.Fatalf("reload registry: %v", err)
	}
	if len(registry) != 1 {
		t.Errorf("registry has %d entries after re-issue, want 1: %+v", len(registry), registry)
	}
	if entry, ok := registry[first.LibraryID]; !ok || entry.State != "invited" {
		t.Errorf("registry entry for %q = %+v, want State invited", first.LibraryID, entry)
	}
}

// Offer round-trip (study C3): the blob is encoded once before sealing,
// so a sealed-then-claimed offer carries the minted LibraryID verbatim
// with zero offer-side code changes.
func TestInvite_OfferCarriesMintedUUID(t *testing.T) {
	_ = testSetup(t)
	fedlibDir := t.TempDir()

	cmd := reinviteCmd("Carol", "carol", fedlibDir)
	cmd.Offer = true
	cmd.Endpoint = "https://lib.example"
	_ = saveFedlibDescriptor(cmd.FedlibID, fedlibDescriptor{
		Version: fedlibDescriptorVersion, Endpoint: "https://lib.example",
	})

	stdout, _, err := captureInviteOutput(t, runNilCtx(cmd.Run))
	if err != nil {
		t.Fatalf("offer invite: %v", err)
	}
	claimURL := strings.TrimSpace(stdout)
	token := claimURL[strings.LastIndex(claimURL, "/")+1:]

	dir := inviteOffersDir(cmd.FedlibID)
	offer, err := fedlibinvite.ClaimOffer(dir, token)
	if err != nil {
		t.Fatalf("claim offer: %v", err)
	}
	blob, err := fedlibinvite.OpenOffer(token, offer)
	if err != nil {
		t.Fatalf("open offer: %v", err)
	}
	inv, err := fedlibinvite.DecodeWriteInvite(blob)
	if err != nil {
		t.Fatalf("decode claimed blob: %v", err)
	}
	if _, err := uuid.FromString(inv.LibraryID); err != nil {
		t.Fatalf("claimed blob library_id = %q, want minted UUID: %v", inv.LibraryID, err)
	}

	registry, _, err := loadMembersRegistryFromPath(filepath.Join(fedlibDir, "members.json"))
	if err != nil {
		t.Fatalf("reload registry: %v", err)
	}
	if _, ok := registry[inv.LibraryID]; !ok {
		t.Errorf("claimed blob UUID %q not the registry key: %+v", inv.LibraryID, registry)
	}
}

func TestReinvite_EmptyLabelRejectedForNewPrefix(t *testing.T) {
	_ = testSetup(t)
	fedlibDir := t.TempDir()

	_, _, err := captureInviteOutput(t, runNilCtx(reinviteCmd("", "dora", fedlibDir).Run))
	if err == nil {
		t.Fatal("expected error for empty label on new prefix")
	}
	if !strings.Contains(err.Error(), "<label> is required") {
		t.Errorf("unexpected error: %v", err)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Alias-safe prefix validation: '_', '.', and a leading '-' are
// rejected at invite time (deliberate tightening — decision 4).
// ═══════════════════════════════════════════════════════════════════

func TestReinvite_NonAliasSafePrefixRejected(t *testing.T) {
	_ = testSetup(t)
	fedlibDir := t.TempDir()

	for _, prefix := range []string{"ali_ce", "ali.ce", "-alice"} {
		_, _, err := captureInviteOutput(t, runNilCtx(reinviteCmd("Alice", prefix, fedlibDir).Run))
		if err == nil {
			t.Errorf("prefix %q: expected rejection, got nil", prefix)
			continue
		}
		if !strings.Contains(err.Error(), prefix) {
			t.Errorf("prefix %q: error does not name the prefix: %v", prefix, err)
		}
	}
}

// ═══════════════════════════════════════════════════════════════════
// Phase 4 golden: stdout is exactly the blob + newline; stderr carries
// the copy-pasteable join + publish lines embedding the same blob.
// ═══════════════════════════════════════════════════════════════════

func TestInvite_StdoutBlobOnlyAndStderrJoinLines(t *testing.T) {
	_ = testSetup(t)
	fedlibDir := t.TempDir()

	stdout, stderr, err := captureInviteOutput(t, runNilCtx(reinviteCmd("Carol", "carol", fedlibDir).Run))
	if err != nil {
		t.Fatalf("invite: %v", err)
	}

	blob := strings.TrimSuffix(stdout, "\n")
	if stdout != blob+"\n" || strings.Contains(blob, "\n") || !strings.HasPrefix(blob, fedlibinvite.WriteInvitePrefix) {
		t.Errorf("stdout is not exactly one blob line: %q", stdout)
	}

	// The alias is a positional argument and the invite arrives via -I; the
	// hint must render exactly what the parser accepts (see joinHint_test.go).
	wantJoin := "accorder lib join carol --invite '" + blob + "' -c /path/to/calibre/library"
	if !strings.Contains(stderr, wantJoin) {
		t.Errorf("stderr missing join line %q\nstderr:\n%s", wantJoin, stderr)
	}
	if !strings.Contains(stderr, "accorder lib publish carol") {
		t.Errorf("stderr missing publish line\nstderr:\n%s", stderr)
	}
	if !strings.Contains(stderr, "export ACCORDER_SECRETS_PASSPHRASE=") {
		t.Errorf("stderr missing passphrase placeholder line\nstderr:\n%s", stderr)
	}
}

// Re-invite hint embeds the identity-bearing blob (same blob as stdout).
func TestInvite_ReinviteHintEmbedsSameBlob(t *testing.T) {
	_ = testSetup(t)
	fedlibDir, _ := seedRegistry(t, map[string]calibre.LibraryMeta{
		readyMemberUUID: {Librarian: "Alice's Library", Prefix: "alice", State: "ready", DictID: 2},
	})

	stdout, stderr, err := captureInviteOutput(t, runNilCtx(reinviteCmd("", "alice", fedlibDir).Run))
	if err != nil {
		t.Fatalf("re-invite: %v", err)
	}
	blob := strings.TrimSuffix(stdout, "\n")
	if !strings.Contains(stderr, "accorder lib join alice --invite '"+blob+"'") {
		t.Errorf("stderr join line does not embed the stdout blob\nstderr:\n%s", stderr)
	}
}

// TestJoin_InviteFromFile: `lib join @<file>` reads the blob from the file,
// tolerating extra lines around it (e.g. a redirected invite stdout), and the
// joined alias resolves exactly as with a literal blob argument.
func TestJoin_InviteFromFile(t *testing.T) {
	testSetup(t)

	inv := &fedlibinvite.WriteInvite{
		FedlibID:  "fedlib-x",
		Backend:   "s3",
		Prefix:    "filey",
		AccessKey: "AK",
		SecretKey: "SK",
		Label:     "File Librarian",
	}
	blob := fedlibinvite.EncodeWriteInvite(inv)

	inviteFile := filepath.Join(t.TempDir(), "filey.invite")
	contents := blob + "\n\n~ ~ ~ ~ ~ <STATS> ~ ~ ~ ~ ~\nAlloc = 5 MiB\n"
	if err := os.WriteFile(inviteFile, []byte(contents), 0o600); err != nil {
		t.Fatal(err)
	}

	_, ctx := parseCLI(t, []string{"lib", "join", "fromfile", "--invite=@" + inviteFile, "--passphrase=pw"})
	join := &LibJoinCmd{Invite: "@" + inviteFile, CommonCommandFields: CommonCommandFields{ActionAlias: "fromfile"}}
	if err := join.Run(ctx); err != nil {
		t.Fatalf("lib join @file: %v", err)
	}

	alias := readAlias(t, "fromfile")
	if got := alias.Get("lib.build.librarian").String(); got != "File Librarian" {
		t.Errorf("lib.build.librarian = %q, want invite label", got)
	}
}

func TestResolveInviteArg_Errors(t *testing.T) {
	if _, err := resolveInviteArg("@/nonexistent/invite", false); err == nil {
		t.Error("missing file: want error, got nil")
	}

	noBlob := filepath.Join(t.TempDir(), "junk.invite")
	if err := os.WriteFile(noBlob, []byte("nothing here\n"), 0o600); err != nil {
		t.Fatal(err)
	}
	if _, err := resolveInviteArg("@"+noBlob, false); err == nil {
		t.Error("file without blob line: want error, got nil")
	}

	// Non-@ arguments pass through untouched.
	if got, err := resolveInviteArg("accorder-fedlib-invite:abc", false); err != nil || got != "accorder-fedlib-invite:abc" {
		t.Errorf("passthrough = %q, %v", got, err)
	}
}

// resolveOperatorRootKeys: config-dir defaults probed in order, explicit path
// errors when incomplete, absence is silent (callers fall back to flags).
func TestResolveOperatorRootKeys(t *testing.T) {
	testSetup(t)

	// Nothing present → no keys, no error.
	if k, _, _, err := resolveOperatorRootKeys(""); err != nil || k != "" {
		t.Fatalf("empty config dir: key=%q err=%v", k, err)
	}

	// Legacy default name, with the space-after-= form seen in production.
	legacy := filepath.Join(accorderConfigDir, "wasabi_root.keys")
	if err := os.WriteFile(legacy, []byte("access-key= AKROOT\nsecret-key= SKROOT\n"), 0o600); err != nil {
		t.Fatal(err)
	}
	k, s, src, err := resolveOperatorRootKeys("")
	if err != nil || k != "AKROOT" || s != "SKROOT" || src != legacy {
		t.Fatalf("legacy default: k=%q s=%q src=%q err=%v", k, s, src, err)
	}

	// operator_root.keys wins over the legacy name.
	preferred := filepath.Join(accorderConfigDir, "operator_root.keys")
	if err := os.WriteFile(preferred, []byte("access-key=AK2\nsecret-key=SK2\n"), 0o600); err != nil {
		t.Fatal(err)
	}
	if k, _, src, _ := resolveOperatorRootKeys(""); k != "AK2" || src != preferred {
		t.Fatalf("preference order: k=%q src=%q", k, src)
	}

	// Explicit path that is incomplete → loud error.
	bad := filepath.Join(t.TempDir(), "partial.keys")
	if err := os.WriteFile(bad, []byte("access-key=ONLY\n"), 0o600); err != nil {
		t.Fatal(err)
	}
	if _, _, _, err := resolveOperatorRootKeys(bad); err == nil {
		t.Fatal("incomplete explicit file: want error, got nil")
	}
}

// Per-fedlib defaults: first full invocation writes fedlibs.json; a later
// invocation with only --prefix/--fedlib-id recalls bucket/provider/endpoint/
// serve-alias/URL; a missing fedlib errors with the provide-once hint.
func TestInvite_FedlibDefaultsRememberedByID(t *testing.T) {
	testSetup(t)

	// Unknown fedlib + missing boring flags → friendly required error.
	bare := &FedlibMembersInviteCmd{Label: "X", Prefix: "alice", FedlibID: "nope"}
	if err := bare.Run(nil); err == nil || !strings.Contains(err.Error(), "remembered") {
		t.Fatalf("expected provide-once error, got %v", err)
	}

	// Seed the descriptor (one name: the id keys the offers dir directly).
	_ = saveFedlibDescriptor("motw", fedlibDescriptor{
		Version: fedlibDescriptorVersion,
	})

	// Full invocation (print-mint path: no network, no registry write) saves defaults.
	full := &FedlibMembersInviteCmd{
		Label: "X", Prefix: "alice", FedlibID: "motw",
		Bucket: "motw", S3Provider: "Wasabi", S3Endpoint: "https://s3.example",
		Endpoint:          "https://lib.example",
		PrintMintCommands: ptrTo(true),
	}
	if err := full.Run(nil); err != nil {
		t.Fatalf("full run: %v", err)
	}
	if d := loadFedlibDescriptor("motw"); d.Bucket != "motw" || d.Endpoint != "https://lib.example" {
		t.Fatalf("defaults not saved: %+v", d)
	}

	// Sparse invocation recalls them (print-mint output proves bucket resolved).
	sparse := &FedlibMembersInviteCmd{
		Label: "Y", Prefix: "bob", FedlibID: "motw",
		PrintMintCommands: ptrTo(true),
	}
	stdout, stderr, err := captureInviteOutput(t, runNilCtx(sparse.Run))
	if err != nil {
		t.Fatalf("sparse run: %v", err)
	}
	if !strings.Contains(stderr, `defaults for fedlib "motw" recalled`) {
		t.Fatalf("no recall notice on stderr:\n%s", stderr)
	}
	if !strings.Contains(stdout+stderr, "arn:aws:s3:::motw/bob") {
		t.Fatalf("recalled bucket did not reach the mint commands:\n%s%s", stdout, stderr)
	}

	// Explicit flag overrides and is written back.
	override := &FedlibMembersInviteCmd{
		Label: "Z", Prefix: "carol", FedlibID: "motw",
		Bucket:            "otherbucket",
		PrintMintCommands: ptrTo(true),
	}
	if err := override.Run(nil); err != nil {
		t.Fatalf("override run: %v", err)
	}
	if d := loadFedlibDescriptor("motw"); d.Bucket != "otherbucket" || d.S3Provider != "Wasabi" {
		t.Fatalf("write-through merge wrong: %+v", d)
	}
}
