package cmd

import (
	"accorder/pkg/calibre"
	"accorder/pkg/rclonexfer"
	"fmt"
	"log"
	"net"
	"net/http"
	"os"
	"path"
	"path/filepath"
	"reflect"
	"strings"

	"github.com/alecthomas/kong"
	uuid "github.com/satori/go.uuid"
)

type LibShareLiveCmd struct {
	CommonCommandFields
	GroupTorShare
	GroupS3Source
	Listen   string `name:"listen" json:"listen" help:"HTTP listen address." default:"127.0.0.1:8724"`
	OnlyTor  bool   `name:"only-tor" json:"-" help:"Tor only — do not expose an HTTP listener (requires a Tor-enabled build)."`
	OnlyHTTP bool   `name:"only-http" json:"-" help:"HTTP only — skip Tor even if available (Tor-enabled build only)."`
	Mode     string `name:"mode" json:"mode" help:"Access mode: public (everything open), offline-private (browse open, index gated), private (everything gated)." enum:"public,offline-private,private" default:"public"`
}

func (c *LibShareLiveCmd) pointerName() string {
	if c.LibraryName != "" {
		return c.LibraryName
	}
	return c.Librarian
}

func (c *LibShareLiveCmd) ResolvedMode() string {
	if c.Mode == "" {
		return "public"
	}
	return c.Mode
}

var indexArtifactRoutes = []string{
	"/_GENERATION",
	"/static/library_index.zst",
	"/static/library_index.jsonl.zst",
	"/static/library_index.manifest.json",
}

func indexFilesPrefix(indexPath string) string {
	books, err := calibre.AllBooksFromIndex(indexPath)
	if err != nil {
		return ""
	}
	for _, b := range books {
		if strings.HasPrefix(b.BaseURL, "/files/") {
			return calibre.PrefixFromBaseURL(b.BaseURL)
		}
	}
	return ""
}

func registerPrefixedFilesRoute(mux *http.ServeMux, prefix string, plain http.Handler) {
	if prefix == "" {
		return
	}
	pattern := "/files/" + prefix + "/"
	mux.Handle(pattern, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		r2 := r.Clone(r.Context())
		r2.URL.Path = "/files/" + strings.TrimPrefix(r.URL.Path, pattern)
		if r2.URL.RawPath != "" {
			r2.URL.RawPath = "/files/" + strings.TrimPrefix(r.URL.RawPath, pattern)
		}
		plain.ServeHTTP(w, r2)
	}))
}

func registerIndexArtifactRoutes(mux *http.ServeMux, h http.Handler, wrap func(http.Handler) http.Handler) {
	for _, p := range indexArtifactRoutes {
		if wrap != nil {
			mux.Handle(p, wrap(h))
		} else {
			mux.Handle(p, h)
		}
	}
}

// ResolveEffective derives the local index path from the Calibre
// directory. Pure and idempotent.
func (c *LibShareLiveCmd) ResolveEffective() []FieldIssue {
	if c.IndexPath == "" && c.CalibreDirectory != "" {
		c.IndexPath = filepath.Join(c.CalibreDirectory, "static", "library_index")
		c.provenanceTable().StampField(reflect.ValueOf(c).Elem(), "IndexPath", OriginDerived, "from --calibrepath")
	}
	return nil
}

func (c *LibShareLiveCmd) Run(ctx *kong.Context) error {
	if c.HandleShowConfig(c) {
		return nil
	}

	if c.OnlyTor && c.OnlyHTTP {
		return fmt.Errorf("lib share live: --only-tor and --only-http are mutually exclusive")
	}

	mode := c.ResolvedMode()
	if startTorFn != nil {
		if err := reconcileTorPublicAuthState(filepath.Join(accorderConfigDir, "tor", c.ActionAlias), mode); err != nil {
			return fmt.Errorf("lib share live: %w", err)
		}
	}

	if c.S3Source != nil && *c.S3Source {
		return c.runS3Source()
	}
	return c.runLocal(ctx)
}

func (c *LibShareLiveCmd) runLocal(ctx *kong.Context) error {
	if c.CalibreDirectory == "" {
		return fmt.Errorf("lib share live: --calibrepath is required in local mode")
	}
	if err := c.RequireExistingCalibreDir(); err != nil {
		return fmt.Errorf("lib share live: %w", err)
	}
	c.ResolveEffective()
	if err := c.ensureLocalIndex(ctx); err != nil {
		return fmt.Errorf("lib share live: %w", err)
	}

	mf, err := calibre.ReadExistingManifest(c.IndexPath)
	if err != nil {
		return fmt.Errorf("lib share live: read manifest: %w", err)
	}
	if err := writeGenerationSentinel(c.CalibreDirectory, mf.BaseGeneration, mf); err != nil {
		return fmt.Errorf("lib share live: %w", err)
	}

	src := c.IndexPath + ".zst"
	dst := filepath.Join(c.CalibreDirectory, "static", "library_index.zst")
	if err := copyFile(src, dst); err != nil {
		return fmt.Errorf("lib share live: copy index: %w", err)
	}
	manifestSrc := c.IndexPath + ".manifest.json"
	manifestDst := filepath.Join(c.CalibreDirectory, "static", "library_index.manifest.json")
	if err := copyFile(manifestSrc, manifestDst); err != nil {
		log.Printf("lib share live: copy manifest: %v (non-fatal — older builds may not produce one)", err)
	}

	jsonlSrc := c.IndexPath + ".jsonl.zst"
	jsonlDst := filepath.Join(c.CalibreDirectory, "static", "library_index.jsonl.zst")
	if err := copyFile(jsonlSrc, jsonlDst); err != nil {
		log.Printf("lib share live: stage jsonl.zst: %v (non-fatal — older builds may not produce one)", err)
	}

	mux := http.NewServeMux()
	fileServer := http.FileServer(http.Dir(c.CalibreDirectory))

	mode := c.ResolvedMode()
	var reg *grantRegistry
	if mode != "public" && !c.OnlyTor {
		authStateDir := filepath.Join(accorderConfigDir, "clearnet-lib", c.ActionAlias)
		var err error
		reg, err = newGrantRegistry(authStateDir)
		if err != nil {
			return fmt.Errorf("lib share live: auth registry: %w", err)
		}
		mux.HandleFunc("/redeem", makeRedeemHandler(reg))
		log.Printf("lib share live: %s mode (state: %s)", mode, authStateDir)
	}

	browserWrap := browserPlaneWrap(reg, mode)

	rootFiles := guardedFileHandler(fileServer)
	calibre.RegisterFrontendRoutesGated(mux, rootFiles, browserWrap)

	if reg != nil && (mode == "offline-private" || mode == "private") {
		registerIndexArtifactRoutes(mux, fileServer, func(h http.Handler) http.Handler { return withAuth(h, reg) })
	} else {
		registerIndexArtifactRoutes(mux, fileServer, nil)
	}
	for i := 1; i <= 8; i++ {
		mux.Handle(fmt.Sprintf("/static/data%d.js", i), applyWrap(browserWrap, fileServer))
	}

	filesPrefix := indexFilesPrefix(c.IndexPath)
	if filesPrefix != "" {
		log.Printf("lib share live: serving federation-member file links under /files/%s/", filesPrefix)
	}

	filesHandler := applyWrap(browserWrap, guardedFileHandler(http.StripPrefix("/files/", fileServer)))
	mux.Handle("/files/", filesHandler)
	registerPrefixedFilesRoute(mux, filesPrefix, filesHandler)

	var browserMux *http.ServeMux
	if mode == "offline-private" {
		browserMux = http.NewServeMux()
		calibre.RegisterFrontendRoutesWithFallback(browserMux, guardedFileHandler(fileServer))
		for i := 1; i <= 8; i++ {
			browserMux.Handle(fmt.Sprintf("/static/data%d.js", i), fileServer)
		}
		browserFiles := guardedFileHandler(http.StripPrefix("/files/", fileServer))
		browserMux.Handle("/files/", browserFiles)
		registerPrefixedFilesRoute(browserMux, filesPrefix, browserFiles)
	}

	return c.serveWithTransport(mux, browserMux)
}

func (c *LibShareLiveCmd) ensureLocalIndex(ctx *kong.Context) error {
	if _, err := os.Stat(c.IndexPath + ".zst"); err == nil {
		return nil
	} else if !os.IsNotExist(err) {
		return fmt.Errorf("probe index %s.zst: %w", c.IndexPath, err)
	}
	log.Printf("lib share live: no index at %s.zst — building first", c.IndexPath)
	build := &LibBuildCmd{}
	build.ActionAlias = c.ActionAlias
	build.CalibreDirectory = c.CalibreDirectory
	build.Librarian = c.Librarian
	build.LibraryID = c.LibraryID
	build.LibraryName = c.LibraryName
	build.IndexPath = c.IndexPath
	return build.Run(ctx)
}

func (c *LibShareLiveCmd) runS3Source() error {
	remoteName := "accorder-" + c.ActionAlias
	cacheDir := accorderCacheDir()

	if err := rclonexfer.SetCacheDir(cacheDir); err != nil {
		return fmt.Errorf("lib share live: set cache dir: %w", err)
	}
	rclonexfer.UseHostSignalHandler()
	rclonexfer.Initialize()
	defer rclonexfer.Finalize()

	// ca-120: inventory (report-only), per-remote-name mutation lock, and
	// the serve-start identity ledger append — the VFS root here is
	// <bucket>/<s3prefix>, both mutable, so this identity must be recorded
	// before the VFS starts.
	mutRelease, err := serveCacheStartup("lib share live", remoteName, path.Join(c.Bucket, c.S3Prefix))
	if err != nil {
		return err
	}
	defer mutRelease()

	_ = rclonexfer.DeleteRemote(remoteName)
	if err := rclonexfer.ConfigS3Remote(remoteName, rclonexfer.S3RemoteConfig{
		Provider:  c.S3Provider,
		AccessKey: c.S3AccessKey,
		SecretKey: c.S3SecretKey,
		Endpoint:  c.S3Endpoint,
	}); err != nil {
		return fmt.Errorf("lib share live: config s3 remote: %w", err)
	}
	defer func() {
		if err := rclonexfer.DeleteRemote(remoteName); err != nil {
			log.Printf("lib share live: cleanup remote: %v", err)
		}
	}()

	fsPath := remoteName + ":" + path.Join(c.Bucket, c.S3Prefix)
	if err := c.ensureRemoteIndex(remoteName, fsPath); err != nil {
		return fmt.Errorf("lib share live: ensure remote index: %w", err)
	}

	serveID, vfsAddr, err := rclonexfer.ServeHTTPWithVFS(fsPath, "127.0.0.1:0", rclonexfer.VFSOptions{
		CacheMode:    "full",
		CacheMaxSize: c.CacheSize,
		ReadOnly:     true,
	})
	if err != nil {
		return fmt.Errorf("lib share live: serve s3 webdav: %w", err)
	}
	defer func() {
		if stopErr := rclonexfer.StopServe(serveID); stopErr != nil {
			log.Printf("lib share live: stop serve: %v", stopErr)
		}
	}()

	log.Printf("lib share live: VFS-cached WebDAV serving %s on %s (cache: %s)", fsPath, vfsAddr, c.CacheSize)

	mux := http.NewServeMux()

	mode := c.ResolvedMode()
	var reg *grantRegistry
	if mode != "public" && !c.OnlyTor {
		authStateDir := filepath.Join(accorderConfigDir, "clearnet-lib", c.ActionAlias)
		var err error
		reg, err = newGrantRegistry(authStateDir)
		if err != nil {
			return fmt.Errorf("lib share live: auth registry: %w", err)
		}
		mux.HandleFunc("/redeem", makeRedeemHandler(reg))
		log.Printf("lib share live: %s mode (state: %s)", mode, authStateDir)
	}

	proxy := makeVFSProxy(vfsAddr)
	browserWrap := browserPlaneWrap(reg, mode)

	rootFiles := guardedFileHandler(http.HandlerFunc(proxy))
	calibre.RegisterFrontendRoutesGated(mux, rootFiles, browserWrap)
	for i := 1; i <= 8; i++ {
		mux.Handle(fmt.Sprintf("/static/data%d.js", i), applyWrap(browserWrap, http.HandlerFunc(proxy)))
	}
	if reg != nil && (mode == "offline-private" || mode == "private") {
		registerIndexArtifactRoutes(mux, http.HandlerFunc(proxy), func(h http.Handler) http.Handler { return withAuth(h, reg) })
	} else {
		registerIndexArtifactRoutes(mux, http.HandlerFunc(proxy), nil)
	}

	var filesPrefix string
	if c.IndexPath != "" {
		filesPrefix = indexFilesPrefix(c.IndexPath)
		if filesPrefix != "" {
			log.Printf("lib share live: serving federation-member file links under /files/%s/", filesPrefix)
		}
	}

	filesHandler := applyWrap(browserWrap, http.HandlerFunc(proxy))
	mux.Handle("/files/", filesHandler)
	registerPrefixedFilesRoute(mux, filesPrefix, filesHandler)

	var browserMux *http.ServeMux
	if mode == "offline-private" {
		browserMux = http.NewServeMux()
		calibre.RegisterFrontendRoutesWithFallback(browserMux, guardedFileHandler(http.HandlerFunc(proxy)))
		for i := 1; i <= 8; i++ {
			browserMux.HandleFunc(fmt.Sprintf("/static/data%d.js", i), proxy)
		}
		browserMux.HandleFunc("/files/", proxy)
		registerPrefixedFilesRoute(browserMux, filesPrefix, http.HandlerFunc(proxy))
	}

	return c.serveWithTransport(mux, browserMux)
}

func (c *LibShareLiveCmd) serveWithTransport(mux, browserMux *http.ServeMux) error {
	ln, err := net.Listen("tcp", c.Listen)
	if err != nil {
		return fmt.Errorf("lib share live: listen %s: %w", c.Listen, err)
	}

	mode := c.ResolvedMode()
	opts := ServeOptions{
		CommandName:    "lib share live",
		ServiceName:    "the library",
		OnlyTor:        c.OnlyTor,
		OnlyHTTP:       c.OnlyHTTP,
		TorAlias:       c.ActionAlias,
		StartTorFn:     startTorFn,
		StartDualTorFn: startDualTorFn,
		BrowserMux:     browserMux,
		FriendHintFn:   c.friendBrowseHint,
	}
	if mode == "offline-private" && startDualTorFn != nil {
		opts.DualOnionCfg = &DualOnionConfig{
			BrowserPublic: true,
			IndexPublic:   false,
		}
	}
	return serveHTTPWithTransport(ln, mux, opts)
}

func (c *LibShareLiveCmd) clearnetShareLines(bound net.Addr) []string {
	listen := c.Listen
	if bound != nil {
		listen = bound.String()
	}
	host, reachable, boundLoopback := hintHost(listen)
	url := "http://" + host + "/"

	size := ""
	if fi, err := os.Stat(c.IndexPath + ".zst"); err == nil && fi.Size() > 0 {
		size = fmt.Sprintf(" (%s)", humanSize(fi.Size()))
	}

	out := []string{fmt.Sprintf("`%s` is shared on %s", c.ActionAlias, url), ""}

	if boundLoopback {

		out = append(out,
			"This address is reachable only from this machine — re-serve with",
			"--listen 0.0.0.0:<port> to share it directly, or expose it through",
			"a tunnel or reverse proxy and share that address:",
			"")
	}

	librarianSlug := calibre.SlugifySourceName(c.Librarian)
	sourceSuggest := "remote-" + librarianSlug
	if librarianSlug == "" {
		sourceSuggest = "remote-library"
	}

	out = append(out, fmt.Sprintf("  accorder lib browse local-librarian --from %s --endpoint %s",
		sourceSuggest, url))

	out = append(out, "",
		fmt.Sprintf("They get the offline index%s and a web app to select, queue, download, and render into a library of their own.", size))

	if !reachable {
		out = append(out, "", "Replace the host with an address your friend can reach.")
	}
	return out
}

func (c *LibShareLiveCmd) friendBrowseHint(onions OnionAddrs, bound net.Addr) []string {
	mode := c.ResolvedMode()
	httpActive := !c.OnlyTor
	torActive := startTorFn != nil && !c.OnlyHTTP

	const sep = "~ ~ ~ ~"
	var out []string

	onion := onions.Single
	if onion == "" {
		onion = onions.Browser
	}
	if torActive && onion != "" {
		out = append(out,
			sep,
			fmt.Sprintf("Share `%s` library via Tor:", c.ActionAlias),
			"",
			"http://"+onion+"/",
			"")
		switch mode {
		case "offline-private":
			out = append(out, "Anyone with this onion address can browse the library as a regular web page; the index download and the files stay invite-only.")
		case "private":
			out = append(out, "This share runs in private mode — the onion address alone is not enough; access needs a granted invite.")
		default:
			out = append(out, "Anyone with this onion address would be able to access the shared library. They access a regular web page of this library.")
		}
	}
	if httpActive {
		out = append(out, sep)
		out = append(out, c.clearnetShareLines(bound)...)
	}
	if len(out) == 0 {
		return nil
	}
	footer := "To make the access invite-only both via `accorder lib browse` or Tor check out the documentation. (hint: `accorder lib share grant --help`)"
	if mode != "public" {
		footer = "Manage friend invites with `accorder lib share grant --help` and `accorder lib share revoke-grant --help`."
	}
	return append(out, sep, footer, sep)
}

func humanSize(n int64) string {
	switch {
	case n >= 1<<30:
		return fmt.Sprintf("%.1f GiB", float64(n)/(1<<30))
	case n >= 1<<20:
		return fmt.Sprintf("%.1f MiB", float64(n)/(1<<20))
	case n >= 1<<10:
		return fmt.Sprintf("%.1f KiB", float64(n)/(1<<10))
	default:
		return fmt.Sprintf("%d B", n)
	}
}

func makeVFSProxy(vfsAddr string) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		vfsURL := "http://" + vfsAddr + r.URL.Path
		proxyReq, err := http.NewRequestWithContext(r.Context(), r.Method, vfsURL, r.Body)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		proxyReq.Header = r.Header.Clone()
		resp, err := http.DefaultClient.Do(proxyReq)
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadGateway)
			return
		}
		defer resp.Body.Close()
		for k, vv := range resp.Header {
			for _, v := range vv {
				w.Header().Add(k, v)
			}
		}
		w.WriteHeader(resp.StatusCode)
		var buf [32 * 1024]byte
		for {
			n, readErr := resp.Body.Read(buf[:])
			if n > 0 {
				w.Write(buf[:n])
			}
			if readErr != nil {
				break
			}
		}
	}
}

func (c *LibShareLiveCmd) ensureRemoteIndex(remoteName, fsPath string) error {
	if c.IndexPath != "" {
		log.Printf("lib share live: Tier 1 — uploading local index from %s", c.IndexPath)
		mf, err := calibre.ReadExistingManifest(c.IndexPath)
		if err != nil {
			return fmt.Errorf("read manifest from %s: %w", c.IndexPath, err)
		}
		pfLib := calibre.PointerFileLibrary{UUID: c.LibraryID, Librarian: c.Librarian, Name: c.pointerName()}
		if err := calibre.WritePointerFile(c.IndexPath, mf, pfLib, true); err != nil {
			return fmt.Errorf("refresh pointer file: %w", err)
		}
		sourceRoot := c.CalibreDirectory
		if sourceRoot == "" {
			sourceRoot = filepath.Dir(filepath.Dir(c.IndexPath))
		}
		remoteState := (&libraryRemote{fsPath: fsPath}).commitState()
		if remoteState.Err != nil && !remoteState.Legacy {
			return fmt.Errorf("inspect remote source contract: %w", remoteState.Err)
		}
		sourceFingerprint, err := localSourceFingerprintForContract(sourceRoot, resolveUploadExcludes(sourceRoot, nil), remoteState.Pointer.SourceContract)
		if err != nil {
			return fmt.Errorf("fingerprint source for derived repair: %w", err)
		}
		localZst := c.IndexPath + ".zst"
		if err := uploadIndexAndGeneration(filepath.Dir(localZst), filepath.Base(localZst), fsPath, mf, sourceFingerprint); err != nil {
			return err
		}
		log.Printf("lib share live: uploaded index + _GENERATION + manifest to %s", fsPath)
		return nil
	}

	hasIndex, err := rclonexfer.FileExists(fsPath, "static/library_index.zst")
	if err != nil {
		return fmt.Errorf("probe remote index: %w", err)
	}
	hasGen, err := rclonexfer.FileExists(fsPath, "_GENERATION")
	if err != nil {
		return fmt.Errorf("probe remote generation: %w", err)
	}

	if hasIndex && hasGen {
		log.Printf("lib share live: Tier 2 — remote already has index + _GENERATION, serving as-is")
		return nil
	}

	log.Printf("lib share live: Tier 3 — auto-compiling index from remote metadata.db")

	tempDir, err := os.MkdirTemp("", "accorder-autoindex-*")
	if err != nil {
		return fmt.Errorf("create temp dir: %w", err)
	}
	defer os.RemoveAll(tempDir)

	if err := rclonexfer.CopyFile(
		fsPath,
		"metadata.db",
		tempDir,
		"metadata.db",
	); err != nil {
		return fmt.Errorf("download metadata.db: %w", err)
	}

	motwApp := &calibre.MotwStandaloneApp{
		CalibreDirectory: tempDir,
		Librarian:        c.Librarian,
		LibraryUUID:      c.LibraryID,
	}
	if err := motwApp.LoadBooksE(); err != nil {
		return fmt.Errorf("load books from metadata.db: %w", err)
	}
	log.Printf("lib share live: loaded %d books from metadata.db", len(motwApp.Books))

	jsonlPath := filepath.Join(tempDir, "books.jsonl")
	if err := motwApp.JsonLE(jsonlPath); err != nil {
		return fmt.Errorf("write temp JSONL: %w", err)
	}

	baseGen := uuid.Must(uuid.FromString(c.LibraryID))
	var bg [16]byte
	copy(bg[:], baseGen[:])

	indexPath := filepath.Join(tempDir, "library_index")
	motwSearch := &calibre.MotwSearch{
		JsonlPath:      jsonlPath,
		IndexPath:      indexPath,
		BaseGeneration: &bg,
	}
	idx, err := motwSearch.BuildIndex()
	if err != nil {
		return fmt.Errorf("build index: %w", err)
	}
	if err := motwSearch.CompressToFile(idx); err != nil {
		return fmt.Errorf("compress index: %w", err)
	}

	mf, err := calibre.ReadExistingManifest(indexPath)
	if err != nil {
		return fmt.Errorf("read auto-compiled manifest: %w", err)
	}
	pfLib := calibre.PointerFileLibrary{UUID: c.LibraryID, Librarian: c.Librarian, Name: c.pointerName()}
	if err := calibre.WritePointerFile(indexPath, mf, pfLib, true); err != nil {
		return fmt.Errorf("write pointer file: %w", err)
	}
	if err := uploadIndexAndGeneration(tempDir, "library_index.zst", fsPath, mf, ""); err != nil {
		return err
	}

	log.Printf("lib share live: auto-compiled and uploaded index (%d books) to %s", len(motwApp.Books), fsPath)
	return nil
}
