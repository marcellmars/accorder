//go:build !tailscale

package cmd

// Tests for per-fedlib librarian-name collision resolution (item 2b).
//

import (
	"testing"

	"accorder/pkg/calibre"
	"accorder/pkg/librarianname"
)

const memberID = "7c9e6679-7425-40de-944b-e07fc1f90ae7"

func TestResolveMemberLibrarian_NoCollisionKeepsName(t *testing.T) {
	registry := map[string]calibre.LibraryMeta{
		"other": {Librarian: "Somebody Else"},
	}
	name := librarianname.Generate(memberID, 0)
	if got := resolveMemberLibrarian(name, memberID, registry); got != name {
		t.Errorf("no collision: got %q, want %q", got, name)
	}
}

func TestResolveMemberLibrarian_GeneratedCollisionBumpsMiddle(t *testing.T) {
	name := librarianname.Generate(memberID, 0)
	registry := map[string]calibre.LibraryMeta{
		"other": {Librarian: name}, // existing member already has this name
	}
	got := resolveMemberLibrarian(name, memberID, registry)
	if got == name {
		t.Fatalf("generated collision not resolved: still %q", got)
	}
	want := librarianname.Generate(memberID, 1)
	if got != want {
		t.Errorf("bump: got %q, want %q", got, want)
	}
	if bump, ok := librarianname.IsGenerated(got, memberID); !ok || bump != 1 {
		t.Errorf("bumped name %q not detected as generated with bump 1 (bump=%d ok=%v)", got, bump, ok)
	}
}

func TestResolveMemberLibrarian_ProvidedCollisionWarnsUnchanged(t *testing.T) {
	registry := map[string]calibre.LibraryMeta{
		"other": {Librarian: "Alice"},
	}
	if got := resolveMemberLibrarian("Alice", memberID, registry); got != "Alice" {
		t.Errorf("provided collision must keep name: got %q", got)
	}
}

func TestResolveMemberLibrarian_ManyCollisionsResolveDistinctMiddles(t *testing.T) {

	// Simulate prior bumps already taken: bumps 0..4 occupied; the next
	// member with the same generated base name must land on bump 5.
	registry := map[string]calibre.LibraryMeta{}
	for b := 0; b < 5; b++ {
		registry[string(rune('a'+b))] = calibre.LibraryMeta{
			Librarian: librarianname.Generate(memberID, b),
		}
	}
	got := resolveMemberLibrarian(librarianname.Generate(memberID, 0), memberID, registry)
	want := librarianname.Generate(memberID, 5)
	if got != want {
		t.Errorf("got %q, want bump-5 %q", got, want)
	}

	// All occupied names + the new one are distinct.
	seen := map[string]bool{got: true}
	for _, m := range registry {
		if seen[m.Librarian] {
			t.Errorf("duplicate name %q in resolved set", m.Librarian)
		}
		seen[m.Librarian] = true
	}
}
