//go:build !tailscale

package cmd

import (
	"reflect"
	"strings"
	"testing"
)

// TestG1_BucketScoping locks in the bucket-prefix safety behaviour: a member
// publish must target <bucket>/<prefix>, and a BARE bucket inherited via the
// s3creds sharedgroup (e.g. "motw" left by `fedlib share live`) must be re-scoped
// — never used as-is (which would mirror-sync into the shared bucket root).
func TestG1_BucketScoping(t *testing.T) {
	_ = testSetup(t)
	// Key-file store: this test is about bucket scoping, not passphrase mode.
	// An empty Passphrase on the target exercises the resolver's X25519 fallback.
	store := testSecretsStore(t)
	_ = store.Set("myalias/write/access-key", "AK")
	_ = store.Set("myalias/write/secret-key", "SK")
	_ = store.Set("myalias/write/provider", "Wasabi")
	_ = store.Set("myalias/write/endpoint", "https://s3.wasabisys.com")
	_ = store.Set("myalias/write/bucket", "motw")
	_ = store.Set("myalias/write/prefix", "biopolitics")

	type tgt struct {
		GroupS3Credentials
		Passphrase string
	}

	cases := []struct {
		name           string
		bucket         string
		bucketExplicit bool
		want           string
	}{
		{"empty_scoped_from_store", "", false, "motw/biopolitics"},
		{"bare_inherited_rescoped", "motw", false, "motw/biopolitics"}, // the sharedgroup-leak bug
		{"explicit_bare_respected", "motw", true, "motw"},              // explicit flag wins (guard catches it later)
		{"already_scoped_unchanged", "motw/biopolitics", false, "motw/biopolitics"},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			target := tgt{GroupS3Credentials: GroupS3Credentials{Bucket: tc.bucket}}
			resolveS3CredsFromSecretsStore(reflect.ValueOf(&target).Elem(), "myalias", tc.bucketExplicit)
			if target.Bucket != tc.want {
				t.Errorf("Bucket = %q, want %q", target.Bucket, tc.want)
			}
		})
	}
}

// TestG1_BucketScoping_AllSetButBareInherited covers the s3creds-sharedgroup leak:
// even when ALL creds are already populated (inherited from an alias that
// `fedlib share live --bucket motw` saved), a BARE non-explicit bucket must still
// be re-scoped to <bucket>/<prefix> — the all-5-set fast path must not skip it.
func TestG1_BucketScoping_AllSetButBareInherited(t *testing.T) {
	_ = testSetup(t)
	store := testSecretsStore(t)
	_ = store.Set("myalias/write/bucket", "motw")
	_ = store.Set("myalias/write/prefix", "biopolitics")

	type tgt struct {
		GroupS3Credentials
		Passphrase string
	}
	target := tgt{GroupS3Credentials: GroupS3Credentials{
		Bucket: "motw", S3AccessKey: "AK", S3SecretKey: "SK",
		S3Provider: "Wasabi", S3Endpoint: "https://s3.wasabisys.com",
	}}
	resolveS3CredsFromSecretsStore(reflect.ValueOf(&target).Elem(), "myalias", false)
	if target.Bucket != "motw/biopolitics" {
		t.Errorf("bare inherited bucket (all creds set) not re-scoped: got %q, want motw/biopolitics", target.Bucket)
	}
}

// TestLibUpload_RefusesBareBucketSync verifies the hard safety guard: lib upload
// refuses to mirror-sync to a bare bucket (no prefix), the last line of defence
// against flooding/clobbering a shared bucket root.
func TestLibUpload_RefusesBareBucketSync(t *testing.T) {
	for _, b := range []string{"motw", "motw/", "/motw/"} {
		c := &LibUploadCmd{}
		c.Bucket = b
		err := c.runSyncMode()
		if err == nil || !strings.Contains(err.Error(), "bare bucket") {
			t.Errorf("runSyncMode(bucket=%q) should refuse, got: %v", b, err)
		}
	}
}
