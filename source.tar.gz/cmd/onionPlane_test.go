package cmd

import (
	"bufio"
	"net"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

// fakeConn feeds a fixed byte stream and records writes; RemoteAddr is loopback.
type fakeConn struct {
	net.Conn
	r *strings.Reader
}

func newFakeConn(data string) *fakeConn {
	return &fakeConn{r: strings.NewReader(data)}
}
func (c *fakeConn) Read(b []byte) (int, error)      { return c.r.Read(b) }
func (c *fakeConn) Write(b []byte) (int, error)     { return len(b), nil }
func (c *fakeConn) Close() error                    { return nil }
func (c *fakeConn) SetReadDeadline(time.Time) error { return nil }
func (c *fakeConn) RemoteAddr() net.Addr {
	return &net.TCPAddr{IP: net.IPv6loopback, Port: 1}
}

func TestReadProxyHeader_CircuitDistinct(t *testing.T) {
	// Two circuits: distinct low bits (0x66 vs 0x6a), zero-compressed form.
	c1, err := readProxyHeader(newFakeConn("PROXY TCP6 fc00:dead:beef:4dad::0:66 ::1 102 80\r\nGET / HTTP/1.1\r\n\r\n"))
	if err != nil {
		t.Fatal(err)
	}
	c2, err := readProxyHeader(newFakeConn("PROXY TCP6 fc00:dead:beef:4dad::0:6a ::1 106 80\r\nGET / HTTP/1.1\r\n\r\n"))
	if err != nil {
		t.Fatal(err)
	}
	h1, _, _ := net.SplitHostPort(c1.RemoteAddr().String())
	h2, _, _ := net.SplitHostPort(c2.RemoteAddr().String())
	if h1 == h2 {
		t.Fatalf("distinct circuits must yield distinct source hosts, both %q", h1)
	}
	if !strings.HasPrefix(h1, "fc00:dead:beef:4dad:") {
		t.Fatalf("unexpected synthetic host %q", h1)
	}
	// Buffered HTTP bytes after the PROXY line must still be readable.
	br := bufio.NewReader(c1)
	line, _ := br.ReadString('\n')
	if !strings.HasPrefix(line, "GET / HTTP") {
		t.Fatalf("PROXY parser ate the HTTP request: %q", line)
	}
}

func TestReadProxyHeader_RejectsNonProxy(t *testing.T) {
	if _, err := readProxyHeader(newFakeConn("GET / HTTP/1.1\r\n\r\n")); err == nil {
		t.Fatal("expected error for a connection with no PROXY header")
	}
}

func TestProxyProtoListener_JunkConnDoesNotKill(t *testing.T) {
	// A junk conn is skipped; a following valid conn is accepted.
	inner := &scriptedListener{conns: []net.Conn{
		newFakeConn("garbage no header\r\n"),
		newFakeConn("PROXY TCP6 fc00:dead:beef:4dad::0:1 ::1 1 80\r\nGET / HTTP/1.1\r\n\r\n"),
	}}
	l := &proxyProtoListener{Listener: inner}
	c, err := l.Accept()
	if err != nil {
		t.Fatalf("Accept should skip junk and return the valid conn, got %v", err)
	}
	if h, _, _ := net.SplitHostPort(c.RemoteAddr().String()); !strings.HasPrefix(h, "fc00:") {
		t.Fatalf("expected synthetic source, got %q", h)
	}
}

func TestStripForwardedHeaders(t *testing.T) {
	var seenXFF, seenXRI string
	h := stripForwardedHeaders(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		seenXFF = r.Header.Get("X-Forwarded-For")
		seenXRI = r.Header.Get("X-Real-IP")
	}))
	r := httptest.NewRequest("GET", "/files/x", nil)
	r.Header.Set("X-Forwarded-For", "1.2.3.4")
	r.Header.Set("X-Real-IP", "5.6.7.8")
	h.ServeHTTP(httptest.NewRecorder(), r)
	if seenXFF != "" || seenXRI != "" {
		t.Fatalf("forwarded headers must be stripped on the onion plane, got xff=%q xri=%q", seenXFF, seenXRI)
	}
}

// scriptedListener returns preloaded conns, then blocks-as-closed.
type scriptedListener struct {
	conns []net.Conn
	i     int
}

func (s *scriptedListener) Accept() (net.Conn, error) {
	if s.i >= len(s.conns) {
		return nil, net.ErrClosed
	}
	c := s.conns[s.i]
	s.i++
	return c, nil
}
func (s *scriptedListener) Close() error   { return nil }
func (s *scriptedListener) Addr() net.Addr { return &net.TCPAddr{IP: net.IPv4(127, 0, 0, 1)} }

func TestStartOnionPlane_EndToEnd(t *testing.T) {
	var seenRemote string
	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		seenRemote = r.RemoteAddr
		w.WriteHeader(200)
	})
	target, srv, err := startOnionPlane(mux)
	if err != nil {
		t.Fatal(err)
	}
	defer srv.Close()

	// target is "127.0.0.1:PORT" (torLoopbackTarget rewrites 0.0.0.0/:: to loopback).
	conn, err := net.DialTimeout("tcp", target, 5*time.Second)
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()
	_, _ = conn.Write([]byte("PROXY TCP6 fc00:dead:beef:4dad::0:2a ::1 42 80\r\n" +
		"GET / HTTP/1.1\r\nHost: x\r\nX-Forwarded-For: 9.9.9.9\r\n\r\n"))
	buf := make([]byte, 64)
	_ = conn.SetReadDeadline(time.Now().Add(5 * time.Second))
	if _, err := conn.Read(buf); err != nil {
		t.Fatalf("read response: %v", err)
	}
	if !strings.HasPrefix(seenRemote, "[fc00:dead:beef:4dad::2a]") {
		t.Fatalf("handler must see the synthetic PROXY source as RemoteAddr, got %q", seenRemote)
	}
}
