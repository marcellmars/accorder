//go:build !tailscale

package cmd

import (
	"context"
	"io"
	"os"
	"os/exec"
	"strings"
	"testing"
	"time"
)

// Exercise the real command with piped input/output. A completed build must not
// open a replacement console, consume stdin, or wait for keyboard input.
func TestFastBuildCompletionWithoutTerminal(t *testing.T) {
	if os.Getenv("ACCORDER_BUILD_OUTPUT_CHILD") == "1" {
		root := testSetup(t)
		seedPublishCalibreLibrary(t, root)
		build := fastBuildCommand(root)
		for range 2 {
			if err := build.Run(nil); err != nil {
				t.Fatal(err)
			}
		}
		input, err := io.ReadAll(os.Stdin)
		if err != nil || string(input) != "not terminal input\n" {
			t.Fatalf("build consumed piped input: %q, %v", input, err)
		}
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()
	child := exec.CommandContext(ctx, os.Args[0], "-test.run=^TestFastBuildCompletionWithoutTerminal$", "-test.count=1")
	child.Env = append(os.Environ(), "ACCORDER_BUILD_OUTPUT_CHILD=1")
	child.Stdin = strings.NewReader("not terminal input\n")
	output, err := child.CombinedOutput()
	if err != nil {
		t.Fatalf("headless build: %v (deadline=%v)\n%s", err, ctx.Err(), output)
	}
	if strings.Count(string(output), ".◟◜lib build◝◞.") != 2 || strings.Contains(string(output), "No progress, only collapse") {
		t.Fatalf("completed builds lost their result or tried to open a terminal:\n%s", output)
	}
}

func TestInteractiveTerminalRejectsNullDevice(t *testing.T) {
	input, output := os.Stdin, os.Stdout
	t.Cleanup(func() { os.Stdin, os.Stdout = input, output })
	null, err := os.OpenFile(os.DevNull, os.O_RDWR, 0)
	if err != nil {
		t.Fatal(err)
	}
	defer null.Close()
	os.Stdin, os.Stdout = null, null
	if interactiveTerminal() {
		t.Fatal("null devices must not enable interactive progress")
	}
}
