package cmd

import "testing"

// The fixtures below are the real key shapes observed in action_aliases.json:
// a plain `lib build` writes {librarian, calibrepath, libraryID} and nothing
// else, while a federation member additionally carries dictID, fedlibPrefix
// and keys-file. Everything this classifier decides rests on that difference.

const localBuildConfig = `{"vtc":{"lib":{"build":{
	"librarian":"Virtue The Cat",
	"calibrepath":"/home/v/Calibre",
	"libraryID":"2163d6cb-d79c-4f26-ae31-a1fc04b46d21"}}}}`

func TestClassifyJoinAlias_Classes(t *testing.T) {
	tests := []struct {
		name        string
		config      string
		keys        []string
		calibreDB   bool
		wantClass   joinAliasClass
		wantPrefix  string
		wantDictID  uint32
		description string
	}{
		{
			name:        "no stored identity is Fresh",
			config:      `{"vtc":{"lib":{"build":{"calibrepath":"/home/v/Calibre"}}}}`,
			calibreDB:   true,
			wantClass:   joinAliasFresh,
			description: "nothing to protect and nothing to replace",
		},
		{
			name:        "empty config is Fresh",
			config:      `{}`,
			calibreDB:   false,
			wantClass:   joinAliasFresh,
			description: "an alias that does not exist yet",
		},
		{
			name:        "plain lib build with a reachable source is LocalBuild",
			config:      localBuildConfig,
			calibreDB:   true,
			wantClass:   joinAliasLocalBuild,
			description: "the case the whole change exists to admit",
		},
		{
			name:        "plain lib build without metadata.db is NoSource",
			config:      localBuildConfig,
			calibreDB:   false,
			wantClass:   joinAliasNoSource,
			description: "adopting would strand a cache-only catalog",
		},
		{
			name: "operator bootstrap shape is ProtectedIdentity",
			config: `{"vtc":{"lib":{"build":{
				"libraryID":"2163d6cb-d79c-4f26-ae31-a1fc04b46d21",
				"fedlibPrefix":"biopolitics",
				"dictID":29}}}}`,
			calibreDB:   true,
			wantClass:   joinAliasProtectedIdentity,
			wantPrefix:  "biopolitics",
			wantDictID:  29,
			description: "lib build --fedlibPrefix --dictID is an operator repair, not a join",
		},
		{
			name: "dictID alone protects",
			config: `{"vtc":{"lib":{"build":{
				"libraryID":"2163d6cb-d79c-4f26-ae31-a1fc04b46d21",
				"dictID":55}}}}`,
			calibreDB:   true,
			wantClass:   joinAliasProtectedIdentity,
			wantDictID:  55,
			description: "a federation dictionary slot is a membership signal",
		},
		{
			name: "lib.upload.bucket protects the standalone publisher",
			config: `{"vtc":{"lib":{
				"build":{"libraryID":"2163d6cb-d79c-4f26-ae31-a1fc04b46d21"},
				"upload":{"bucket":"motw/marcell"}}}}`,
			calibreDB:   true,
			wantClass:   joinAliasProtectedIdentity,
			description: "published outside any federation is still published",
		},
		{
			name: "lib.publish.bucket protects",
			config: `{"vtc":{"lib":{
				"build":{"libraryID":"2163d6cb-d79c-4f26-ae31-a1fc04b46d21"},
				"publish":{"bucket":"motw/marcell"}}}}`,
			calibreDB:   true,
			wantClass:   joinAliasProtectedIdentity,
			description: "publish carries the same signal as upload",
		},
		{
			name:        "write credentials protect even with no stored identity",
			config:      `{"vtc":{"lib":{"build":{"calibrepath":"/home/v/Calibre"}}}}`,
			keys:        []string{"vtc/write/access-key", "vtc/write/secret-key"},
			calibreDB:   true,
			wantClass:   joinAliasProtectedIdentity,
			description: "anomalous state from a prior incomplete join refuses conservatively",
		},
		{
			name: "lib.build.bucket does NOT protect",
			config: `{"vtc":{"lib":{"build":{
				"libraryID":"2163d6cb-d79c-4f26-ae31-a1fc04b46d21",
				"bucket":"covers-source"}}}}`,
			calibreDB:   true,
			wantClass:   joinAliasLocalBuild,
			description: "lib.build.bucket serves --fetch-covers, not publication",
		},
		{
			name: "keys-file does NOT protect",
			config: `{"vtc":{"lib":{"build":{
				"libraryID":"2163d6cb-d79c-4f26-ae31-a1fc04b46d21",
				"keys-file":"/home/v/.config/accorder/keys/x.s3.keys"}}}}`,
			calibreDB:   true,
			wantClass:   joinAliasLocalBuild,
			description: "a keys-file path can be present on a pure local build",
		},
		{
			name: "empty-but-present fedlibPrefix still protects",
			config: `{"vtc":{"lib":{"build":{
				"libraryID":"2163d6cb-d79c-4f26-ae31-a1fc04b46d21",
				"fedlibPrefix":""}}}}`,
			calibreDB:   true,
			wantClass:   joinAliasProtectedIdentity,
			description: "existence is the signal, so a present-empty key is not silently ignored",
		},
		{
			name: "empty upload bucket does not protect",
			config: `{"vtc":{"lib":{
				"build":{"libraryID":"2163d6cb-d79c-4f26-ae31-a1fc04b46d21"},
				"upload":{"bucket":""}}}}`,
			calibreDB:   true,
			wantClass:   joinAliasLocalBuild,
			description: "an empty bucket string carries no membership meaning",
		},
		{
			name:        "write creds for a different alias are ignored",
			config:      localBuildConfig,
			keys:        []string{"othervtc/write/access-key", "vtc-two/write/access-key"},
			calibreDB:   true,
			wantClass:   joinAliasLocalBuild,
			description: "prefix match must be anchored to this alias",
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			got := classifyJoinAlias([]byte(tc.config), tc.keys, "vtc", tc.calibreDB)
			if got.Class != tc.wantClass {
				t.Errorf("class = %q, want %q (%s)", got.Class, tc.wantClass, tc.description)
			}
			if got.PriorPrefix != tc.wantPrefix {
				t.Errorf("PriorPrefix = %q, want %q", got.PriorPrefix, tc.wantPrefix)
			}
			if got.PriorDictID != tc.wantDictID {
				t.Errorf("PriorDictID = %d, want %d", got.PriorDictID, tc.wantDictID)
			}
		})
	}
}

// The prior UUID feeds the adoption compare-and-swap, so it must survive
// classification for every class that can reach adoption.
func TestClassifyJoinAlias_CapturesPriorUUID(t *testing.T) {
	const want = "2163d6cb-d79c-4f26-ae31-a1fc04b46d21"
	got := classifyJoinAlias([]byte(localBuildConfig), nil, "vtc", true)
	if got.PriorUUID != want {
		t.Fatalf("PriorUUID = %q, want %q", got.PriorUUID, want)
	}
	if got.Class != joinAliasLocalBuild {
		t.Fatalf("class = %q, want %q", got.Class, joinAliasLocalBuild)
	}
}

// A `vtc-two/write/...` key must not register as protection for `vtc`.
// Anchoring on "<alias>/write/" rather than "<alias>" is what prevents it.
func TestHasAliasWriteCreds_AnchorsOnAlias(t *testing.T) {
	tests := []struct {
		name string
		keys []string
		want bool
	}{
		{"exact alias namespace", []string{"vtc/write/access-key"}, true},
		{"sibling alias sharing a stem", []string{"vtc-two/write/access-key"}, false},
		{"unrelated namespace", []string{"vtc/pending/join"}, false},
		{"no keys", nil, false},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			if got := hasAliasWriteCreds(tc.keys, "vtc"); got != tc.want {
				t.Errorf("hasAliasWriteCreds(%v) = %v, want %v", tc.keys, got, tc.want)
			}
		})
	}
}

// A failed join leaves write credentials AND the pending record behind
// (SetMany writes them atomically); only a completed join clears the pending
// record. The retry the refusal prints must therefore not classify the alias
// as a live membership.
func TestClassifyJoinAlias_PendingJoinUnlocksRetry(t *testing.T) {
	credsAndPending := []string{"vtc/write/access-key", "vtc/write/secret-key", "vtc/pending/join"}
	got := classifyJoinAlias([]byte(localBuildConfig), credsAndPending, "vtc", true)
	if got.Class != joinAliasLocalBuild {
		t.Fatalf("class with creds+pending = %q, want %q (retry must stay adoptable)", got.Class, joinAliasLocalBuild)
	}
	// Without the pending record the same credentials mean a completed
	// membership and must protect.
	credsOnly := []string{"vtc/write/access-key", "vtc/write/secret-key"}
	if got := classifyJoinAlias([]byte(localBuildConfig), credsOnly, "vtc", true); got.Class != joinAliasProtectedIdentity {
		t.Fatalf("class with creds, no pending = %q, want %q", got.Class, joinAliasProtectedIdentity)
	}
	// A pending record for a DIFFERENT alias exempts nothing.
	foreignPending := []string{"vtc/write/access-key", "other/pending/join"}
	if got := classifyJoinAlias([]byte(localBuildConfig), foreignPending, "vtc", true); got.Class != joinAliasProtectedIdentity {
		t.Fatalf("class with foreign pending = %q, want %q", got.Class, joinAliasProtectedIdentity)
	}
}

// adoptedAliasCalibrePath is the legacy-alias fallback: an alias written
// before calibrepath entered sharedgroup:"lib" has only lib.build, and the
// generic backfill cannot reach LibJoinCmd's differently named field.
func TestAdoptedAliasCalibrePath(t *testing.T) {
	tests := []struct {
		name, config, want string
	}{
		{"join subtree wins", `{"vtc":{"lib":{"join":{"calibrepath":"/join/path"},"build":{"calibrepath":"/build/path"}}}}`, "/join/path"},
		{"legacy build-only alias", `{"vtc":{"lib":{"build":{"calibrepath":"/build/path"}}}}`, "/build/path"},
		{"no calibrepath anywhere", `{"vtc":{"lib":{"build":{"librarian":"x"}}}}`, ""},
		{"empty config", `{}`, ""},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			if got := adoptedAliasCalibrePath([]byte(tc.config), "vtc"); got != tc.want {
				t.Errorf("adoptedAliasCalibrePath = %q, want %q", got, tc.want)
			}
		})
	}
}
