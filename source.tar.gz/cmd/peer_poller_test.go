package cmd

import (
	"accorder/pkg/calibre"
	"accorder/pkg/torshare"
	"context"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"

	"github.com/goccy/go-json"
)

// ---------- probePeerGeneration unit tests ----------

func TestProbePeerGeneration_Healthy(t *testing.T) {

	// Build a minimal index to get a valid _GENERATION sentinel.
	libDir := t.TempDir()
	buildMinimalIndex(t, libDir)
	genData, err := os.ReadFile(filepath.Join(libDir, "_GENERATION"))
	if err != nil {
		t.Fatalf("read _GENERATION: %v", err)
	}

	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/_GENERATION" {
			http.NotFound(w, r)
			return
		}
		w.Write(genData)
	}))
	defer srv.Close()

	entry := memberPollEntry{
		Prefix:     "alice",
		Kind:       "peer",
		Endpoint:   srv.URL,
		GrantToken: "",
	}
	probeDir := t.TempDir()
	body, err := probePeerGeneration(context.Background(), entry, probeDir)
	if err != nil {
		t.Fatalf("probePeerGeneration: %v", err)
	}
	if len(body) != 24 {
		t.Fatalf("expected 24 bytes, got %d", len(body))
	}

	// Verify the local file was written.
	localPath := filepath.Join(probeDir, "alice__GENERATION")
	localData, err := os.ReadFile(localPath)
	if err != nil {
		t.Fatalf("read local file: %v", err)
	}
	if len(localData) != 24 {
		t.Fatalf("local file: expected 24 bytes, got %d", len(localData))
	}

	// Verify it decodes correctly.
	_, gen, err := torshare.DecodeGeneration(body)
	if err != nil {
		t.Fatalf("DecodeGeneration: %v", err)
	}
	t.Logf("probe returned generation=%d", gen)
}

func TestProbePeerGeneration_Unauthorized(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusUnauthorized)
	}))
	defer srv.Close()

	entry := memberPollEntry{
		Prefix:     "alice",
		Kind:       "peer",
		Endpoint:   srv.URL,
		GrantToken: "bad-token",
	}
	probeDir := t.TempDir()
	_, err := probePeerGeneration(context.Background(), entry, probeDir)
	if err == nil {
		t.Fatal("expected error for 401 response")
	}
}

func TestProbePeerGeneration_ConnectionRefused(t *testing.T) {
	entry := memberPollEntry{
		Prefix:     "alice",
		Kind:       "peer",
		Endpoint:   "http://127.0.0.1:1", // connection refused
		GrantToken: "",
	}
	probeDir := t.TempDir()
	_, err := probePeerGeneration(context.Background(), entry, probeDir)
	if err == nil {
		t.Fatal("expected error for connection refused")
	}
}

// ---------- Health monitor integration: retire/promote for peer members ----------

func TestPollMemberGenerations_PeerRetire(t *testing.T) {

	// A peer endpoint that always returns 500.
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusInternalServerError)
	}))
	defer srv.Close()

	tmp := t.TempDir()
	registryPath := filepath.Join(tmp, "members.json")
	registry := map[string]calibre.LibraryMeta{
		"peer-uuid": {
			Kind:       "peer",
			Prefix:     "peerlib",
			State:      "ready",
			Endpoint:   srv.URL,
			GrantToken: "tok",
		},
	}
	data, _ := json.Marshal(registry)
	os.WriteFile(registryPath, data, 0o600)

	mpc := &memberPollContext{
		pollSet:          buildMemberPollSet(registry),
		registryPrefixes: map[string]string{"peer-uuid": "peerlib"},
		registryPath:     registryPath,
		lastKnownGen:     make(map[string][24]byte),
		healthState:      make(map[string]*memberHealth),
	}

	probeDir := t.TempDir()

	// Simulate retireThreshold consecutive failures.
	for i := 0; i < retireThreshold; i++ {
		pollMemberGenerations(context.Background(), "", probeDir, mpc)
	}

	h := mpc.healthState["peer-uuid"]
	if h == nil {
		t.Fatal("expected health state for peer-uuid")
	}
	if h.ConsecErrors < retireThreshold {
		t.Errorf("expected ConsecErrors >= %d, got %d", retireThreshold, h.ConsecErrors)
	}

	// The member should be retired now.
	entry, ok := mpc.pollSet["peer-uuid"]
	if !ok {
		t.Fatal("peer-uuid should still be in poll set")
	}
	if entry.State != "retired" {
		t.Errorf("expected state=retired after %d failures, got %q", retireThreshold, entry.State)
	}
}

func TestPollMemberGenerations_PeerPromote(t *testing.T) {

	// Build a minimal index to get a valid _GENERATION sentinel.
	libDir := t.TempDir()
	buildMinimalIndex(t, libDir)
	genData, err := os.ReadFile(filepath.Join(libDir, "_GENERATION"))
	if err != nil {
		t.Fatalf("read _GENERATION: %v", err)
	}

	// Peer endpoint that always returns a healthy _GENERATION.
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/_GENERATION" {
			w.Write(genData)
			return
		}
		http.NotFound(w, r)
	}))
	defer srv.Close()

	tmp := t.TempDir()
	registryPath := filepath.Join(tmp, "members.json")
	registry := map[string]calibre.LibraryMeta{
		"peer-uuid": {
			Kind:       "peer",
			Prefix:     "peerlib",
			State:      "retired",
			Endpoint:   srv.URL,
			GrantToken: "",
		},
	}
	data, _ := json.Marshal(registry)
	os.WriteFile(registryPath, data, 0o600)

	mpc := &memberPollContext{
		pollSet:          buildMemberPollSet(registry),
		registryPrefixes: map[string]string{"peer-uuid": "peerlib"},
		registryPath:     registryPath,
		lastKnownGen:     make(map[string][24]byte),
		healthState:      make(map[string]*memberHealth),
	}

	probeDir := t.TempDir()

	// Simulate promoteThreshold consecutive healthy probes.
	for i := 0; i < promoteThreshold; i++ {
		pollMemberGenerations(context.Background(), "", probeDir, mpc)
	}

	h := mpc.healthState["peer-uuid"]
	if h == nil {
		t.Fatal("expected health state for peer-uuid")
	}
	if h.ConsecHealthy < promoteThreshold {
		t.Errorf("expected ConsecHealthy >= %d, got %d", promoteThreshold, h.ConsecHealthy)
	}

	entry, ok := mpc.pollSet["peer-uuid"]
	if !ok {
		t.Fatal("peer-uuid should still be in poll set")
	}
	if entry.State != "ready" {
		t.Errorf("expected state=ready after %d healthy probes, got %q", promoteThreshold, entry.State)
	}
}

func TestPollMemberGenerations_PeerBearerAuth(t *testing.T) {

	// Build a minimal index to get a valid _GENERATION sentinel.
	libDir := t.TempDir()
	buildMinimalIndex(t, libDir)
	genData, err := os.ReadFile(filepath.Join(libDir, "_GENERATION"))
	if err != nil {
		t.Fatalf("read _GENERATION: %v", err)
	}

	const validToken = "secret-peer-token"

	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		auth := r.Header.Get("Authorization")
		if auth != "Bearer "+validToken {
			w.WriteHeader(http.StatusUnauthorized)
			return
		}
		if r.URL.Path == "/_GENERATION" {
			w.Write(genData)
			return
		}
		http.NotFound(w, r)
	}))
	defer srv.Close()

	entry := memberPollEntry{
		Prefix:     "authed",
		Kind:       "peer",
		Endpoint:   srv.URL,
		GrantToken: validToken,
	}

	probeDir := t.TempDir()
	body, err := probePeerGeneration(context.Background(), entry, probeDir)
	if err != nil {
		t.Fatalf("probePeerGeneration with valid token: %v", err)
	}
	if len(body) != 24 {
		t.Fatalf("expected 24 bytes, got %d", len(body))
	}

	// With bad token, should fail.
	entry.GrantToken = "wrong-token"
	_, err = probePeerGeneration(context.Background(), entry, probeDir)
	if err == nil {
		t.Fatal("expected error with bad token")
	}
}
