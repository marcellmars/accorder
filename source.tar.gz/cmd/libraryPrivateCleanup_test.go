//go:build !tailscale

package cmd

import (
	"bytes"
	"encoding/hex"
	"errors"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
	"time"

	"accorder/pkg/calibre"
	"accorder/pkg/libraryflow"
)

func TestPrivateCleanupDirectories(t *testing.T) {
	for _, rule := range []string{"/**", "/static/**", "/.accorder/changes/**", "/Author/../Book/**", "Author/Book/**", "/Author\\Book/Test/**", "/Author/Book/../../**"} {
		if _, err := privateCleanupDirs([]string{rule}); err == nil {
			t.Errorf("accepted unsafe cleanup rule %q", rule)
		}
	}
	dirs, err := privateCleanupDirs([]string{"/.motw-upload-excludes", "/Author/Book/**", "/Author/Book/child/**", "/Author/Book/**", "/Author/Book-other/**"})
	if err != nil || !reflect.DeepEqual(dirs, []string{"Author/Book", "Author/Book-other"}) {
		t.Fatalf("directories = %v, %v", dirs, err)
	}
}

// The book is already private in the committed catalog. Injected remote files
// therefore simulate an older publisher's leak, with no pending catalog delta
// and no content-ledger record of those files (including an obsolete filename).
func privateCleanupFixture(t *testing.T) (string, string, *LibBuildCmd, *libraryCandidate) {
	t.Helper()
	root, remote, build := fastBuildPublishedFixture(t)
	fastBuildAddSecondBook(t, root)
	fastBuildSQL(t, root, `INSERT INTO tags(id,name) VALUES(1,'private'); INSERT INTO books_tags_link(book,tag) VALUES(2,1)`)
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	candidate, err := captureExistingCandidate(root, resolveUploadExcludes(root, nil))
	if err != nil {
		t.Fatal(err)
	}
	if err := publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: 25}); err != nil {
		t.Fatal(err)
	}
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	candidate, err = captureExistingCandidate(root, resolveUploadExcludes(root, nil))
	if err != nil || candidate.Change == nil || len(candidate.Change.Changes) != 0 {
		t.Fatalf("expected an already-current private catalog: %v", err)
	}
	for _, path := range privateCleanupLeaks {
		writeTestFile(t, remote, path, "leaked")
	}
	return root, remote, build, candidate
}

var privateCleanupLeaks = []string{
	"Author/Second (2)/old-name.epub",
	"Author/Second (2)/cover.jpg",
}

func TestPrivateCleanupPreviewBudgetAndCurrentRepair(t *testing.T) {
	root, remoteRoot, build, candidate := privateCleanupFixture(t)
	protected := []string{"_IDENTITY", ".accorder/changes/retained.manifest.json", "Author/Second (2)/retained.manifest.json"}
	for _, path := range protected {
		writeTestFile(t, remoteRoot, path, "retain")
	}
	before := fastBuildSnapshot(t, root, accorderConfigDir, remoteRoot)
	for _, dry := range []bool{true, false} {
		err := publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{DryRun: dry, MaxDeletes: 1})
		if err == nil || !strings.Contains(err.Error(), "exceeding --max-deletes=1") {
			t.Fatalf("deletion preflight did not refuse: %v", err)
		}
		if !reflect.DeepEqual(before, fastBuildSnapshot(t, root, accorderConfigDir, remoteRoot)) {
			t.Fatal("over-budget preflight changed files")
		}
	}
	output, _, err := captureInviteOutput(t, func() error {
		return publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{DryRun: true, MaxDeletes: 2})
	})
	if err != nil || !strings.Contains(output, "Remove remotely published private file: "+privateCleanupLeaks[0]) {
		t.Fatalf("cleanup preview missing: %v\n%s", err, output)
	}
	if !reflect.DeepEqual(before, fastBuildSnapshot(t, root, accorderConfigDir, remoteRoot)) {
		t.Fatal("cleanup preview changed files")
	}
	remote := &libraryRemote{fsPath: remoteRoot}
	initial := remote.commitState()
	if err := publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: 2}); err != nil {
		t.Fatal(err)
	}
	for _, path := range privateCleanupLeaks {
		if _, err := os.Stat(filepath.Join(remoteRoot, filepath.FromSlash(path))); !os.IsNotExist(err) {
			t.Fatalf("private file remains: %s: %v", path, err)
		}
	}
	for _, path := range protected {
		data, err := os.ReadFile(filepath.Join(remoteRoot, filepath.FromSlash(path)))
		if err != nil || string(data) != "retain" {
			t.Fatalf("protected file changed: %s: %v", path, err)
		}
	}
	if data, err := os.ReadFile(filepath.Join(root, "Author/Second (2)/Second - Author.epub")); err != nil || string(data) != "epub" {
		t.Fatalf("local private payload changed: %v", err)
	}
	current := remote.commitState()
	if !current.Committed || current.Generation <= initial.Generation || current.Writer.Marker.SeatID != initial.Writer.Marker.SeatID {
		t.Fatal("cleanup did not commit a new generation with the same owner")
	}
	manifestPath := generationChangeManifestPath(hex.EncodeToString(current.GenerationRaw))
	data, err := os.ReadFile(filepath.Join(remoteRoot, manifestPath))
	if err != nil {
		t.Fatal(err)
	}
	manifest, err := calibre.DecodeGenerationChangeManifest(data, calibre.GenerationChangeLimits{})
	if err != nil || manifest.Scope != calibre.GenerationChangeScopeCoarse {
		t.Fatalf("old leaked files need conservative cache invalidation: %v", err)
	}
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	candidate, err = captureExistingCandidate(root, resolveUploadExcludes(root, nil))
	if err != nil {
		t.Fatal(err)
	}
	if err := publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: 0}); err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(remote.commitState().GenerationRaw, current.GenerationRaw) {
		t.Fatal("already-clean retry created an unnecessary generation")
	}
}

func TestPrivateCleanupFailureAndRetry(t *testing.T) {
	for _, failure := range []string{"shared-budget", "writer-lost", "interrupted", "partial-delete", "late-file"} {
		t.Run(failure, func(t *testing.T) {
			root, remoteRoot, build, candidate := privateCleanupFixture(t)
			remote := &libraryRemote{fsPath: remoteRoot}
			initial := remote.commitState()
			limit := 25
			if failure == "shared-budget" {
				writeTestFile(t, remoteRoot, "obsolete-one.txt", "old")
				writeTestFile(t, remoteRoot, "obsolete-two.txt", "old")
				limit = 3 // Two private files reserve two; mirror may delete only one.
			}
			publishCommitStageHook = func(stage string) error {
				if stage == "before-private-cleanup" && failure == "writer-lost" {
					return writeAndVerifyWriter(remote, libraryflow.ClaimWriter("another-seat", "other", time.Now(), &initial.Writer.Marker))
				}
				if stage == "after-private-cleanup" && failure == "interrupted" {
					return errors.New("injected cleanup interruption")
				}
				if stage == "after-private-delete" && failure == "partial-delete" {
					return errors.New("injected partial deletion")
				}
				if stage == "before-private-cleanup" && failure == "late-file" {
					writeTestFile(t, remoteRoot, "Author/Second (2)/late.pdf", "late")
				}
				return nil
			}
			t.Cleanup(func() { publishCommitStageHook = nil })
			err := publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: limit})
			publishCommitStageHook = nil
			if err == nil {
				t.Fatal("injected failure allowed publication")
			}
			if !bytes.Equal(initial.GenerationRaw, remote.commitState().GenerationRaw) {
				t.Fatal("failure advanced generation")
			}
			if failure == "shared-budget" || failure == "writer-lost" {
				for _, path := range privateCleanupLeaks {
					if _, err := os.Stat(filepath.Join(remoteRoot, path)); err != nil {
						t.Fatalf("cleanup ran despite failed mirror/ownership: %v", err)
					}
				}
			}
			if failure == "writer-lost" {
				return // A different owner needs explicit user reconciliation.
			}
			// Command recovery resumes only the approved paths, including when
			// some or all of them were already removed before interruption.
			upload := &LibUploadCmd{GroupLib: build.GroupLib, GroupS3Credentials: GroupS3Credentials{Bucket: "bucket/alice"}, MaxDeletes: 25}
			upload.ActionAlias = "alice"
			if err := upload.Run(nil); failure == "late-file" {
				if err == nil || !strings.Contains(err.Error(), "reconciliation") {
					t.Fatalf("recovery expanded the approved cleanup: %v", err)
				}
				if _, err := os.Stat(publishRecoveryPath("alice")); err != nil {
					t.Fatal("lost recovery record on changed cleanup")
				}
				return
			} else if err != nil {
				t.Fatal(err)
			}
			remaining, err := planPrivateCleanup(remote, []string{"Author/Second (2)"})
			if err != nil || len(remaining) != 0 {
				t.Fatalf("retry left private files: %v %v", remaining, err)
			}
			if _, err := os.Stat(filepath.Join(root, "Author/Second (2)/Second - Author.pdf")); err != nil {
				t.Fatal("retry removed local private book")
			}
			if remote.commitState().Generation <= initial.Generation {
				t.Fatal("retry lost the cache-refresh generation after removing leaked files")
			}
		})
	}
}
