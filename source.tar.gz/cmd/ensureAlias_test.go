//go:build !tailscale

package cmd

// Tests for the browse-to-alias linkage (library-name-to-alias triage):
// slugification, alias creation with identity mint + sibling fan-out
// against the real action_aliases.json, idempotency, and the
// different-calibre-dir conflict guard.

import (
	"os"
	"path/filepath"
	"testing"
)

func TestSlugifyAlias(t *testing.T) {
	cases := []struct{ in, want string }{
		{"CLI Test", "cli-test"},
		{"MY LIBRARY", "my-library"},
		{"  spaced   out  ", "spaced-out"},
		{"Already-Dashed--Name", "already-dashed-name"},
		{"Ünïcode Ärt", "ncode-rt"},
		{"dots.and_underscores", "dots.and_underscores"},
		{"!!!", ""},
		{"", ""},
	}
	for _, c := range cases {
		if got := slugifyAlias(c.in); got != c.want {
			t.Errorf("slugifyAlias(%q) = %q, want %q", c.in, got, c.want)
		}
	}
}

func TestEnsureAliasForBrowse_MintsAndPropagates(t *testing.T) {
	libDir := testSetup(t)
	_, ctx := parseCLI(t, []string{"lib", "build", "seed", "-c", libDir})

	alias, err := ensureAliasForBrowse(ctx, "CLI Test", libDir, "")
	if err != nil {
		t.Fatalf("ensureAliasForBrowse: %v", err)
	}
	if alias != "cli-test" {
		t.Fatalf("alias = %q, want cli-test", alias)
	}

	stored := readAlias(t, "cli-test")
	id := stored.Get("lib.build.libraryID").String()
	if id == "" {
		t.Fatal("libraryID not minted under lib.build")
	}
	if got := stored.Get("lib.share.live.libraryID").String(); got != id {
		t.Errorf("lib.share.live.libraryID = %q, want propagated %q", got, id)
	}
	if got := stored.Get("lib.build.librarian").String(); got == "" {
		t.Error("librarian not minted")
	}
	if got := stored.Get("lib.build.calibrepath").String(); got != libDir {
		t.Errorf("calibrepath = %q, want %q", got, libDir)
	}
	// calibrepath fans out with the rest of the sharedgroup:"lib" fields, so
	// `lib share live` local mode finds its library without any flag.
	if got := stored.Get("lib.share.live.calibrepath").String(); got != libDir {
		t.Errorf("lib.share.live.calibrepath = %q, want %q", got, libDir)
	}

	// A fresh-process sibling parse resolves the minted identity.
	_, ctx2 := parseCLI(t, []string{"lib", "share", "live", "cli-test"})
	_ = ctx2
}

func TestEnsureAliasForBrowse_Idempotent(t *testing.T) {
	libDir := testSetup(t)
	_, ctx := parseCLI(t, []string{"lib", "build", "seed", "-c", libDir})

	if _, err := ensureAliasForBrowse(ctx, "CLI Test", libDir, ""); err != nil {
		t.Fatalf("first call: %v", err)
	}
	first, err := os.ReadFile(savedActionAliases)
	if err != nil {
		t.Fatalf("read aliases: %v", err)
	}

	if _, err := ensureAliasForBrowse(ctx, "CLI Test", libDir, ""); err != nil {
		t.Fatalf("second call: %v", err)
	}
	second, err := os.ReadFile(savedActionAliases)
	if err != nil {
		t.Fatalf("read aliases: %v", err)
	}
	if string(first) != string(second) {
		t.Error("second identical call modified action_aliases.json")
	}
}

func TestEnsureAliasForBrowse_ConflictingCalibreDirRefused(t *testing.T) {
	libDir := testSetup(t)
	otherDir := filepath.Join(filepath.Dir(libDir), "otherlib")
	_ = os.MkdirAll(otherDir, 0755)
	_, ctx := parseCLI(t, []string{"lib", "build", "seed", "-c", libDir})

	if _, err := ensureAliasForBrowse(ctx, "CLI Test", libDir, ""); err != nil {
		t.Fatalf("first call: %v", err)
	}
	before, _ := os.ReadFile(savedActionAliases)

	_, err := ensureAliasForBrowse(ctx, "CLI Test", otherDir, "")
	if err == nil {
		t.Fatal("expected conflict error for a different calibre dir, got nil")
	}
	after, _ := os.ReadFile(savedActionAliases)
	if string(before) != string(after) {
		t.Error("conflicting call modified action_aliases.json")
	}
}

func TestEnsureAliasForBrowse_EmptySlugRejected(t *testing.T) {
	libDir := testSetup(t)
	_, ctx := parseCLI(t, []string{"lib", "build", "seed", "-c", libDir})

	if _, err := ensureAliasForBrowse(ctx, "!!!", libDir, ""); err == nil {
		t.Fatal("expected error for a name that slugs to empty")
	}
}

// TestEnsureAliasForBrowse_HonorsProvidedLibrarian is the regression for the
// browse-settings bug: a librarian the user set (here passed through from browse
// settings) must be saved as-is, not replaced by a generated name.
func TestEnsureAliasForBrowse_HonorsProvidedLibrarian(t *testing.T) {
	libDir := testSetup(t)
	_, ctx := parseCLI(t, []string{"lib", "build", "seed", "-c", libDir})

	if _, err := ensureAliasForBrowse(ctx, "CLI Test", libDir, "Majstor Smora"); err != nil {
		t.Fatalf("ensureAliasForBrowse: %v", err)
	}
	stored := readAlias(t, "cli-test")
	if got := stored.Get("lib.build.librarian").String(); got != "Majstor Smora" {
		t.Errorf("librarian = %q, want %q (provided name must be honored, not generated)", got, "Majstor Smora")
	}
	if got := stored.Get("lib.share.live.librarian").String(); got != "Majstor Smora" {
		t.Errorf("lib.share.live.librarian = %q, want propagated %q", got, "Majstor Smora")
	}
}
