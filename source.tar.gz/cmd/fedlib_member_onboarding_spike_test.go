//go:build !tailscale

package cmd

import (
	"accorder/pkg/calibre"
	"accorder/pkg/rclonexfer"
	"encoding/json"
	"os"
	"path/filepath"
	"sync"
	"testing"
	"time"

	"github.com/go-playground/validator/v10"
)

// ===========================================================================
// Spike Hypothesis 1: Programmatically setting GroupS3Credentials fields
// before validation will satisfy validate:"required" without appearing in
// getProvidedFlagNames().
//

// This tests whether code that runs between Kong parse and validate.Struct()
// can inject values into the CLI struct such that:
// (a) validation passes for required fields
// (b) those fields are NOT saved to the action alias config (because they
//     weren't in providedFlags)
//

// Strategy: Parse a `lib upload` command without S3 flags (which normally
// fails validation). Before validation runs, programmatically set the fields.
// Since AfterApply calls validate.Struct() during kong.Parse, we can't
// intercept — so instead we test the two sub-mechanisms independently:
//   1. getProvidedFlagNames only returns flags that were CLI-provided
//   2. validate.Struct() passes when fields have values, regardless of source
// ===========================================================================

func TestSpike_ValidationPassesForProgrammaticFields(t *testing.T) {
	_ = testSetup(t)

	// Sub-test A: validate.Struct passes on a struct with programmatically
	// set fields (no Kong involvement — just the validator).
	t.Run("validator_accepts_programmatic_values", func(t *testing.T) {
		initValidator()

		// Construct a GroupS3Credentials with all required fields set
		// programmatically (not from CLI parsing).
		creds := GroupS3Credentials{
			Bucket:      "test-bucket",
			S3AccessKey: "AKIAIOSFODNN7EXAMPLE",
			S3SecretKey: "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
			S3Provider:  "Wasabi",
			S3Endpoint:  "https://s3.wasabisys.com",
		}

		err := validate.Struct(creds)
		if err != nil {
			t.Fatalf("validate.Struct failed on programmatically-set fields: %v", err)
		}
		t.Logf("VALIDATED: validate.Struct passes for programmatically-set required fields")
	})

	// Sub-test B: getProvidedFlagNames only captures CLI-provided flags.
	// Parse a fedlib build command with --output-path but WITHOUT S3 flags.
	// Verify that S3-related names are NOT in providedFlags.
	//

	// KEY INSIGHT: validate.Struct(cli) validates the ENTIRE CLI tree, so
	// sibling commands' required fields also generate errors. The AfterApply
	// hook filters these by actionPath (line 271 of cli.go). This test
	// verifies the sub-mechanisms independently:
	//   1. providedFlags snapshot excludes programmatically-set fields
	//   2. validate.Struct on the TARGET COMMAND struct (not whole CLI) passes
	t.Run("provided_flags_excludes_programmatic", func(t *testing.T) {
		tmpDir := t.TempDir()
		outputPath := filepath.Join(tmpDir, "output")
		_ = os.MkdirAll(outputPath, 0o755)

		// Create a members.json with only local members so validation
		// won't require S3 creds.
		membersJSON := map[string]calibre.LibraryMeta{
			"uuid-local-1111": {
				Librarian: "Alice",
				Prefix:    "alice",
				Kind:      "local",
				LocalPath: tmpDir,
			},
		}
		membersData, _ := json.MarshalIndent(membersJSON, "", "  ")
		_ = os.WriteFile(filepath.Join(outputPath, "members.json"), membersData, 0o644)

		// Parse with only --output-path (no S3 flags).
		// FedlibBuildCmd uses validate:"omitempty" for S3 fields, not
		// validate:"required", so this parse should succeed.
		cli, ctx := parseCLI(t, []string{
			"fedlib", "build", "myalias",
			"--output-path", outputPath,
		})

		provided := getProvidedFlagNames(ctx)

		// output-path should be in provided
		if _, ok := provided["output-path"]; !ok {
			t.Errorf("expected 'output-path' in providedFlags, got: %v", provided)
		}

		// S3 fields should NOT be in provided
		for _, key := range []string{"bucket", "s3-access-key", "s3-secret-key", "s3-provider", "s3-endpoint"} {
			if _, ok := provided[key]; ok {
				t.Errorf("unexpected S3 flag %q in providedFlags (was not CLI-provided)", key)
			}
		}

		// Now simulate programmatic injection: set S3 fields on the
		// FedlibBuildCmd struct AFTER parse. Verify they're there.
		buildCmd := &cli.Fedlib.Build
		buildCmd.Bucket = "injected-bucket"
		buildCmd.S3AccessKey = "AKIAINJECTED"
		buildCmd.S3SecretKey = "injected-secret"
		buildCmd.S3Provider = "Wasabi"
		buildCmd.S3Endpoint = "https://s3.wasabisys.com"

		// Validate just the FedlibBuildCmd struct (not the whole CLI).
		// This is what matters: the AfterApply hook validates the whole
		// CLI but filters errors by actionPath. For the target command,
		// programmatically-set fields should pass.
		err := validate.Struct(buildCmd)
		if err != nil {
			t.Fatalf("validate.Struct(FedlibBuildCmd) failed after programmatic injection: %v", err)
		}

		// Full CLI validation produces errors for OTHER commands' required
		// fields (siblings with validate:"required"). This is expected and
		// handled by the actionPath filter in AfterApply. Confirm:
		fullErr := validate.Struct(cli)
		if fullErr == nil {
			t.Logf("NOTE: full CLI validation passed — no sibling required fields")
		} else {
			t.Logf("EXPECTED: full CLI validation has %d errors (sibling commands' required fields — filtered by actionPath in AfterApply)",
				len(fullErr.(validator.ValidationErrors)))
		}

		// And the injected values should NOT be in providedFlags
		// (providedFlags is a snapshot from parse time).
		for _, key := range []string{"bucket", "s3-access-key", "s3-secret-key", "s3-provider", "s3-endpoint"} {
			if _, ok := provided[key]; ok {
				t.Errorf("S3 flag %q appeared in providedFlags after programmatic set — should not", key)
			}
		}

		t.Logf("VALIDATED: programmatic field injection passes target-command validation and stays out of providedFlags")
	})

	// Sub-test C: If GroupS3Credentials (with validate:"required") is
	// embedded in a struct and fields are programmatically set, validation
	// passes — confirming the approach works for the upload command's
	// required S3 creds.
	t.Run("required_s3_creds_accept_programmatic", func(t *testing.T) {
		initValidator()

		// Create a minimal struct that embeds GroupS3Credentials with
		// validate:"required" tags.
		type TestCmd struct {
			GroupS3Credentials
		}
		cmd := TestCmd{}
		cmd.Bucket = "my-bucket"
		cmd.S3AccessKey = "AKIATEST"
		cmd.S3SecretKey = "secret"
		cmd.S3Provider = "AWS"
		cmd.S3Endpoint = "https://s3.amazonaws.com"

		err := validate.Struct(cmd)
		if err != nil {
			t.Fatalf("validate.Struct failed on embedded GroupS3Credentials: %v", err)
		}
		t.Logf("VALIDATED: embedded GroupS3Credentials with validate:\"required\" accepts programmatic values")
	})
}

// ===========================================================================
// Spike Hypothesis 2: FedlibBuildCmd.Run() can be called in-process from
// within fedlib share live (rclone re-init, concurrent index build, etc.)
//

// The concern: FedlibBuildCmd.Run() calls rclonexfer.Initialize() and
// defers Finalize(). If the serve process already has rclone initialized
// (from setupAggregateServeRclone), does a second Initialize()/Finalize()
// pair corrupt the first?
//

// Strategy:
// 1. Test that double Initialize() doesn't panic or error.
// 2. Test that Finalize() + re-Initialize() works (sequential lifecycle).
// 3. Test that rclone operations work after re-init.
// ===========================================================================

func TestSpike_RcloneDoubleInit(t *testing.T) {

	// Test A: Double Initialize should not panic.
	// librclone.Initialize() is documented as safe to call multiple times.
	t.Run("double_init_no_panic", func(t *testing.T) {
		rclonexfer.Initialize()
		defer rclonexfer.Finalize()

		// Second init — should be safe.
		rclonexfer.Initialize()

		// Verify rclone is functional: configure a local remote.
		tmpDir := t.TempDir()
		err := rclonexfer.ConfigHTTPRemote("spike-test-double", "http://localhost:9999")
		if err != nil {
			t.Fatalf("ConfigHTTPRemote failed after double init: %v", err)
		}
		_ = rclonexfer.DeleteRemote("spike-test-double")
		_ = tmpDir

		t.Logf("VALIDATED: double rclonexfer.Initialize() does not panic and rclone remains functional")
	})

	// Test B: Sequential lifecycle — init, finalize, re-init, use.
	// This simulates what would happen if FedlibBuildCmd.Run() calls
	// its own Init/Finalize pair while the serve process has already
	// finalized its own pair.
	t.Run("sequential_init_finalize_reinit", func(t *testing.T) {

		// First lifecycle (serve process setup)
		rclonexfer.Initialize()

		// Configure a remote under the first init
		err := rclonexfer.ConfigHTTPRemote("spike-serve", "http://localhost:8888")
		if err != nil {
			t.Fatalf("first ConfigHTTPRemote failed: %v", err)
		}

		// Second lifecycle (build cmd) — init while first is still active
		rclonexfer.Initialize()
		err = rclonexfer.ConfigHTTPRemote("spike-build", "http://localhost:7777")
		if err != nil {
			t.Fatalf("second ConfigHTTPRemote failed: %v", err)
		}

		// Build cmd finishes — calls Finalize
		rclonexfer.Finalize()

		// The serve process's remote should still work after the build's
		// Finalize. This is the critical test: does Finalize() from the
		// build goroutine kill the serve process's rclone state?
		//

		// NOTE: librclone uses a global singleton. Finalize() tears down
		// ALL state. This is the key finding.
		//

		// Try to use rclone after the nested Finalize:
		err = rclonexfer.ConfigHTTPRemote("spike-after-finalize", "http://localhost:6666")
		if err != nil {

			// If this fails, Finalize() killed global state.
			// We need to re-init.
			t.Logf("FINDING: ConfigHTTPRemote failed after nested Finalize: %v", err)
			t.Logf("Re-initializing rclone...")
			rclonexfer.Initialize()
			err = rclonexfer.ConfigHTTPRemote("spike-after-reinit", "http://localhost:6666")
			if err != nil {
				t.Fatalf("ConfigHTTPRemote failed even after re-init: %v", err)
			}
			t.Logf("IMPORTANT: rclone Finalize() is global — nested Init/Finalize pairs are NOT safe")
			t.Logf("INVALIDATED: FedlibBuildCmd.Run() cannot call Finalize() while serve process has rclone active")
			rclonexfer.Finalize()
		} else {
			t.Logf("VALIDATED: rclone survives nested Init/Finalize (reference-counted or idempotent)")
			_ = rclonexfer.DeleteRemote("spike-after-finalize")
			rclonexfer.Finalize()
		}

		// Cleanup
		// (remotes may have been destroyed by Finalize — best effort)
		rclonexfer.Initialize()
		_ = rclonexfer.DeleteRemote("spike-serve")
		_ = rclonexfer.DeleteRemote("spike-build")
		_ = rclonexfer.DeleteRemote("spike-after-finalize")
		_ = rclonexfer.DeleteRemote("spike-after-reinit")
		rclonexfer.Finalize()
	})

	// Test C: Concurrent rclone config operations.
	// If the build runs in a goroutine, can two goroutines configure
	// different remotes simultaneously?
	t.Run("concurrent_config_operations", func(t *testing.T) {
		rclonexfer.Initialize()
		defer rclonexfer.Finalize()

		var wg sync.WaitGroup
		errs := make([]error, 2)

		wg.Add(2)
		go func() {
			defer wg.Done()
			errs[0] = rclonexfer.ConfigHTTPRemote("spike-concurrent-a", "http://localhost:1111")
		}()
		go func() {
			defer wg.Done()
			errs[1] = rclonexfer.ConfigHTTPRemote("spike-concurrent-b", "http://localhost:2222")
		}()
		wg.Wait()

		for i, err := range errs {
			if err != nil {
				t.Errorf("concurrent config %d failed: %v", i, err)
			}
		}

		_ = rclonexfer.DeleteRemote("spike-concurrent-a")
		_ = rclonexfer.DeleteRemote("spike-concurrent-b")

		t.Logf("VALIDATED: concurrent rclone ConfigHTTPRemote calls succeed")
	})
}

// ===========================================================================
// Spike Hypothesis 3: Polling each member's <prefix>/_GENERATION via
// rclonexfer.CopyFile adds acceptable overhead per tick (N HEAD requests
// per poll interval).
//

// Strategy: We can't test real S3 without credentials, so we test the
// local-to-local CopyFile path (which exercises the same librclone RPC
// machinery) and measure overhead. This gives us a lower bound on the
// per-file overhead.
// ===========================================================================

func TestSpike_GenerationPollOverhead(t *testing.T) {
	rclonexfer.Initialize()
	defer rclonexfer.Finalize()

	srcDir := t.TempDir()
	dstDir := t.TempDir()

	// Create N small _GENERATION files (16 bytes each, like real ones).
	N := 10
	for i := 0; i < N; i++ {
		prefix := filepath.Join(srcDir, "member"+string(rune('A'+i)))
		_ = os.MkdirAll(prefix, 0o755)
		genContent := []byte("0123456789abcdef") // 16 bytes, like a real generation stamp
		_ = os.WriteFile(filepath.Join(prefix, "_GENERATION"), genContent, 0o644)
	}

	// Measure time to copy all N _GENERATION files (local-to-local).
	start := time.Now()
	for i := 0; i < N; i++ {
		prefix := "member" + string(rune('A'+i))
		srcFS := srcDir
		dstFS := dstDir

		// Ensure destination directory exists
		memberDst := filepath.Join(dstDir, prefix)
		_ = os.MkdirAll(memberDst, 0o755)

		err := rclonexfer.CopyFile(srcFS, filepath.Join(prefix, "_GENERATION"), dstFS, filepath.Join(prefix, "_GENERATION"))
		if err != nil {
			t.Fatalf("CopyFile for %s/_GENERATION: %v", prefix, err)
		}
	}
	elapsed := time.Since(start)

	t.Logf("Copied %d _GENERATION files (local→local) in %v (avg %v/file)",
		N, elapsed, elapsed/time.Duration(N))

	// Verify files were actually copied.
	for i := 0; i < N; i++ {
		prefix := "member" + string(rune('A'+i))
		data, err := os.ReadFile(filepath.Join(dstDir, prefix, "_GENERATION"))
		if err != nil {
			t.Errorf("read copied _GENERATION for %s: %v", prefix, err)
		}
		if len(data) != 16 {
			t.Errorf("_GENERATION for %s: got %d bytes, want 16", prefix, len(data))
		}
	}

	// Acceptable threshold: local-to-local should be well under 5s.
	// The real S3 path will add network latency, but this confirms the
	// rclone RPC overhead itself is not the bottleneck.
	if elapsed > 5*time.Second {
		t.Errorf("INVALIDATED: %d local CopyFile calls took %v (> 5s threshold)", N, elapsed)
	} else {
		t.Logf("VALIDATED: %d CopyFile calls complete in %v — rclone RPC overhead is acceptable", N, elapsed)
		t.Logf("NOTE: Real S3 will add ~50-200ms per HEAD+GET per file depending on region/provider")
		t.Logf("For N=10 members, expect ~0.5-2s per poll tick with S3 (acceptable for 60s interval)")
	}
}

// ===========================================================================
// Spike Hypothesis 4 (graduated, arm retired): the key-rename
// (invited:<prefix> → real UUID) integrity arm was retired by
// operator-minted-member-uuid — the placeholder convention it asserted
// is no longer written by new binaries, and the rekey lifecycle is
// production-covered by TestG4_ReconcileFallbackRekey and the same-key
// confirm leg (G4) of TestFedlib_E2E_WasabiOnboarding
// (spike_validation_coverage rule 5).
//
// What remains: the serve process reads the registry once at startup
// (scanMembersForServe) while the poller rewrites it — does
// loadMembersRegistryFromPath stay correct under concurrent
// saveMembersRegistry rewrites?
// ===========================================================================

func TestSpike_RegistryConcurrentReadWrite(t *testing.T) {
	registryDir := t.TempDir()
	registryPath := filepath.Join(registryDir, "members.json")

	// Sub-test B: concurrent read while write is in progress.
	// Since the serve process reads once at startup and the registry
	// uses os.WriteFile (atomic on most filesystems via rename), this
	// should be safe.
	t.Run("concurrent_read_during_write", func(t *testing.T) {

		// Reset registry.
		reg := map[string]calibre.LibraryMeta{
			"uuid-bob-existing": {
				Librarian: "Bob",
				Prefix:    "bob",
			},
			"uuid-alice-real-1111": {
				Librarian: "Alice",
				Prefix:    "alice-prefix",
			},
		}
		if err := saveMembersRegistry(registryPath, reg); err != nil {
			t.Fatalf("save: %v", err)
		}

		var wg sync.WaitGroup
		readErrors := make([]error, 100)
		writeErrors := make([]error, 10)

		// Start 100 concurrent readers.
		for i := 0; i < 100; i++ {
			wg.Add(1)
			go func(idx int) {
				defer wg.Done()
				loaded, _, err := loadMembersRegistryFromPath(registryPath)
				if err != nil {
					readErrors[idx] = err
					return
				}

				// Registry should always have at least 1 entry (the
				// writer adds entries but doesn't delete all of them).
				if len(loaded) == 0 {
					readErrors[idx] = os.ErrInvalid
				}
			}(i)
		}

		// Start 10 concurrent writers that modify and save.
		for i := 0; i < 10; i++ {
			wg.Add(1)
			go func(idx int) {
				defer wg.Done()
				r := map[string]calibre.LibraryMeta{
					"uuid-bob-existing": {
						Librarian: "Bob",
						Prefix:    "bob",
					},
					"uuid-writer-" + string(rune('A'+idx)): {
						Librarian: "Writer" + string(rune('A'+idx)),
						Prefix:    "writer-" + string(rune('a'+idx)),
					},
				}
				writeErrors[idx] = saveMembersRegistry(registryPath, r)
			}(i)
		}

		wg.Wait()

		readFails := 0
		for _, err := range readErrors {
			if err != nil {
				readFails++
			}
		}
		writeFails := 0
		for _, err := range writeErrors {
			if err != nil {
				writeFails++
			}
		}

		t.Logf("Concurrent access: %d/%d reads failed, %d/%d writes failed",
			readFails, 100, writeFails, 10)

		if writeFails > 0 {
			t.Errorf("INVALIDATED: %d write failures during concurrent access", writeFails)
		}

		// Some read failures are acceptable if os.WriteFile is not
		// atomic (mid-write reads get partial JSON). Log the finding.
		if readFails > 0 {
			t.Logf("FINDING: %d/%d reads failed during concurrent writes — os.WriteFile is not atomic", readFails, 100)
			t.Logf("This is acceptable because the serve process reads registry once at startup, not continuously")
		} else {
			t.Logf("VALIDATED: all concurrent reads succeeded — os.WriteFile appears atomic on this filesystem")
		}

		// Final integrity check: the file should be valid JSON.
		final, _, err := loadMembersRegistryFromPath(registryPath)
		if err != nil {
			t.Fatalf("final read after concurrent access: %v", err)
		}
		if len(final) < 2 {
			t.Errorf("final registry has %d entries, expected >= 2", len(final))
		}
		t.Logf("VALIDATED: registry file is valid JSON after concurrent read/write")
	})
}

// ===========================================================================
// Spike Hypothesis 5 (G3): Wasabi IAM sub-user with scoped credentials.
//

// This is a live test that requires real Wasabi credentials. It is gated
// by the WASABI_ROOT_ACCESS_KEY and WASABI_ROOT_SECRET_KEY environment
// variables. If absent, the test is skipped.
//

// Strategy: Use aws-sdk-go-v2 with custom IAM endpoint at iam.wasabisys.com
// to create a throwaway sub-user, attach a scoped policy, create access keys,
// verify the scoped key can write inside its prefix but is denied outside,
// then tear down.
// ===========================================================================

func TestSpike_WasabiIAMScopedCredentials(t *testing.T) {
	rootAccessKey := os.Getenv("WASABI_ROOT_ACCESS_KEY")
	rootSecretKey := os.Getenv("WASABI_ROOT_SECRET_KEY")
	testBucket := os.Getenv("WASABI_TEST_BUCKET")

	if rootAccessKey == "" || rootSecretKey == "" || testBucket == "" {
		t.Skip("Skipping Wasabi IAM spike: WASABI_ROOT_ACCESS_KEY, WASABI_ROOT_SECRET_KEY, and WASABI_TEST_BUCKET required")
	}

	// This test would require importing aws-sdk-go-v2 which is not
	// currently a dependency. Rather than adding a dependency for a
	// spike test, we document the test plan and validate it can be
	// done using the existing rclone infrastructure.
	//

	// The actual IAM operations (CreateUser, PutUserPolicy, CreateAccessKey)
	// are not available via rclone — they require direct AWS SDK calls.
	//

	// What we CAN test: given a scoped key (manually provisioned), verify
	// that rclonexfer.CopyFile works for writes inside the prefix and
	// fails for writes outside the prefix.
	scopedAccessKey := os.Getenv("WASABI_SCOPED_ACCESS_KEY")
	scopedSecretKey := os.Getenv("WASABI_SCOPED_SECRET_KEY")
	scopedPrefix := os.Getenv("WASABI_SCOPED_PREFIX") // e.g. "motw/spiketest"

	if scopedAccessKey == "" || scopedSecretKey == "" || scopedPrefix == "" {
		t.Skip("Skipping scoped-key verification: WASABI_SCOPED_ACCESS_KEY, WASABI_SCOPED_SECRET_KEY, WASABI_SCOPED_PREFIX required")
	}

	rclonexfer.Initialize()
	defer rclonexfer.Finalize()

	remoteName := "spike-wasabi-scoped"
	_ = rclonexfer.DeleteRemote(remoteName)
	if err := rclonexfer.ConfigS3Remote(remoteName, rclonexfer.S3RemoteConfig{
		Provider:  "Wasabi",
		AccessKey: scopedAccessKey,
		SecretKey: scopedSecretKey,
		Endpoint:  "https://s3.wasabisys.com",
	}); err != nil {
		t.Fatalf("ConfigS3Remote: %v", err)
	}
	defer func() { _ = rclonexfer.DeleteRemote(remoteName) }()

	bucketFS := remoteName + ":" + testBucket

	// Write a test file to a temp dir.
	tmpDir := t.TempDir()
	testContent := []byte("spike-test-content-" + time.Now().Format(time.RFC3339))
	_ = os.WriteFile(filepath.Join(tmpDir, "spike_test.txt"), testContent, 0o644)

	// Test A: Write inside scoped prefix should succeed.
	t.Run("write_inside_prefix", func(t *testing.T) {
		err := rclonexfer.CopyFile(tmpDir, "spike_test.txt", bucketFS, scopedPrefix+"/spike_test.txt")
		if err != nil {
			t.Fatalf("INVALIDATED: CopyFile to scoped prefix failed: %v", err)
		}
		t.Logf("VALIDATED: write to %s/spike_test.txt succeeded with scoped key", scopedPrefix)

		// Cleanup: delete the test file.
		// (rclonexfer doesn't have a DeleteFile, so we skip cleanup for now)
	})

	// Test B: Write outside scoped prefix should be denied.
	t.Run("write_outside_prefix_denied", func(t *testing.T) {
		err := rclonexfer.CopyFile(tmpDir, "spike_test.txt", bucketFS, "motw/other-prefix/spike_test.txt")
		if err == nil {
			t.Errorf("INVALIDATED: CopyFile to motw/other-prefix/ SUCCEEDED — scoped key is not restricted!")
		} else {
			t.Logf("VALIDATED: write to motw/other-prefix/ denied as expected: %v", err)
		}
	})
}
