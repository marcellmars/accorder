package cmd

import (
	"encoding/hex"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"testing"

	"accorder/pkg/calibre"
	"accorder/pkg/rclonexfer"
)

func TestAddRecordDirectoriesStopsAtMemberLimit(t *testing.T) {
	directories := make([]string, aggregateChangeMaxMemberDirs+1)
	for i := range directories {
		directories[i] = "book/" + strconv.Itoa(i)
	}
	books := make(map[string]struct{})
	assets := map[string]struct{}{"member/static": {}}
	err := addRecordDirectories("member", calibre.CatalogRecordInfo{FormatDirectories: directories}, true, false, books, assets)
	if !errors.Is(err, errMemberDirectoryLimit) {
		t.Fatalf("directory limit error=%v", err)
	}
	if got := len(books) + len(assets); got != aggregateChangeMaxMemberDirs+1 {
		t.Fatalf("retained directories=%d, want bounded overflow observation %d", got, aggregateChangeMaxMemberDirs+1)
	}
}

func TestDeriveMemberChangeResultExactAdjacent(t *testing.T) {
	oldBook := generationCandidateBook()
	newBook := cloneGenerationCandidateBook(oldBook)
	newBook.Title = "Edited"
	newBook.TitleSort = "Edited"
	libDir := t.TempDir()
	oldToken, oldPointer, oldChecksum := writeMemberChangeEndpoint(t, libDir, oldBook, 1)
	writeCachedMemberCommit(t, libDir, oldToken, oldPointer)
	stage := t.TempDir()
	newToken, newPointer, newChecksum := writeMemberChangeEndpoint(t, stage, newBook, 2)
	diff := generationEndpointDiff(t, oldBook, newBook)

	bucket := t.TempDir()
	prefix := "member"
	writeExactMemberManifest(t, bucket, prefix, oldBook.LibraryUUID, oldToken, newToken, oldChecksum, newChecksum, diff.Changes)
	rclonexfer.Initialize()
	defer rclonexfer.Finalize()
	target, err := decodeAggregateGenerationToken(newToken)
	if err != nil {
		t.Fatal(err)
	}
	result := deriveMemberChangeResult(bucket, libDir, stage, prefix, oldBook.LibraryUUID, observedMemberTransition{
		LibraryUUID: oldBook.LibraryUUID, PreviousGeneration: hex.EncodeToString(oldToken),
		ObservedGeneration: hex.EncodeToString(newToken),
	}, target, newPointer)
	if result.Scope != calibre.GenerationChangeScopeExact || result.Reason != "" {
		t.Fatalf("result=%+v", result)
	}
	for _, want := range []string{"member/Author", "member/Author/Book (1)"} {
		if !containsString(result.BooksDirectories, want) {
			t.Errorf("books dirs %v omit %q", result.BooksDirectories, want)
		}
	}
	for _, want := range []string{"member/Author", "member/Author/Book (1)", "member/static"} {
		if !containsString(result.AssetsDirectories, want) {
			t.Errorf("assets dirs %v omit %q", result.AssetsDirectories, want)
		}
	}
	wrongSource := newPointer
	wrongSource.SourceFingerprint = strings.Repeat("b", 64)
	result = deriveMemberChangeResult(bucket, libDir, stage, prefix, oldBook.LibraryUUID, observedMemberTransition{
		LibraryUUID: oldBook.LibraryUUID, PreviousGeneration: hex.EncodeToString(oldToken),
		ObservedGeneration: hex.EncodeToString(newToken),
	}, target, wrongSource)
	if result.Scope != calibre.GenerationChangeScopeCoarse || result.Reason != "manifest-source-mismatch" {
		t.Fatalf("source mismatch result=%+v", result)
	}
}

// TestDeriveMemberChangeResultExactWithRealisticTrailingSlashDirectoryPath
// guards the full producer-to-consumer path with a book shaped like every
// real Calibre loader actually produces one: pkg/calibre/calibre.go's SQLite
// and JSON-unmarshal paths both write File.DirectoryPath with a trailing path
// separator (e.g. "Author/Book (1)/"), unlike the generationCandidateBook
// fixture used elsewhere in this package, which omits it. Without
// normalizing that trailing separator before it reaches
// CatalogRecordInfo.FormatDirectories, addEndpointDirectory's strict
// NormalizePath(directory) == directory check rejects every touched book
// that has any format file, and deriveMemberChangeResult always downgrades
// to coarse("endpoint-path-invalid") in production.
func TestDeriveMemberChangeResultExactWithRealisticTrailingSlashDirectoryPath(t *testing.T) {
	oldBook := generationCandidateBook()
	oldBook.Formats[0].DirectoryPath += "/"
	newBook := cloneGenerationCandidateBook(oldBook)
	newBook.Title = "Edited"
	newBook.TitleSort = "Edited"

	libDir := t.TempDir()
	oldToken, oldPointer, oldChecksum := writeMemberChangeEndpoint(t, libDir, oldBook, 1)
	writeCachedMemberCommit(t, libDir, oldToken, oldPointer)
	stage := t.TempDir()
	newToken, newPointer, newChecksum := writeMemberChangeEndpoint(t, stage, newBook, 2)
	diff := generationEndpointDiff(t, oldBook, newBook)

	bucket := t.TempDir()
	prefix := "member"
	writeExactMemberManifest(t, bucket, prefix, oldBook.LibraryUUID, oldToken, newToken, oldChecksum, newChecksum, diff.Changes)
	rclonexfer.Initialize()
	defer rclonexfer.Finalize()
	target, err := decodeAggregateGenerationToken(newToken)
	if err != nil {
		t.Fatal(err)
	}
	result := deriveMemberChangeResult(bucket, libDir, stage, prefix, oldBook.LibraryUUID, observedMemberTransition{
		LibraryUUID: oldBook.LibraryUUID, PreviousGeneration: hex.EncodeToString(oldToken),
		ObservedGeneration: hex.EncodeToString(newToken),
	}, target, newPointer)
	if result.Scope != calibre.GenerationChangeScopeExact || result.Reason != "" {
		t.Fatalf("a realistic trailing-slash DirectoryPath must not force a coarse fallback: result=%+v", result)
	}
	if !containsString(result.BooksDirectories, "member/Author/Book (1)") {
		t.Errorf("books dirs %v omit the book's own directory", result.BooksDirectories)
	}
}

func TestDeriveMemberChangeResultRepeatedIDFallsBack(t *testing.T) {
	oldBook := generationCandidateBook()
	middleBook := cloneGenerationCandidateBook(oldBook)
	middleBook.Title = "Middle"
	middleBook.TitleSort = "Middle"
	newBook := cloneGenerationCandidateBook(oldBook)
	newBook.Title = "New"
	newBook.TitleSort = "New"
	libDir := t.TempDir()
	oldToken, oldPointer, oldChecksum := writeMemberChangeEndpoint(t, libDir, oldBook, 1)
	writeCachedMemberCommit(t, libDir, oldToken, oldPointer)
	middleDir := t.TempDir()
	middleToken, _, middleChecksum := writeMemberChangeEndpoint(t, middleDir, middleBook, 2)
	stage := t.TempDir()
	newToken, newPointer, newChecksum := writeMemberChangeEndpoint(t, stage, newBook, 3)

	bucket := t.TempDir()
	prefix := "member"
	writeExactMemberManifest(t, bucket, prefix, oldBook.LibraryUUID, oldToken, middleToken, oldChecksum, middleChecksum, generationEndpointDiff(t, oldBook, middleBook).Changes)
	writeExactMemberManifest(t, bucket, prefix, oldBook.LibraryUUID, middleToken, newToken, middleChecksum, newChecksum, generationEndpointDiff(t, middleBook, newBook).Changes)
	rclonexfer.Initialize()
	defer rclonexfer.Finalize()
	target, err := decodeAggregateGenerationToken(newToken)
	if err != nil {
		t.Fatal(err)
	}
	result := deriveMemberChangeResult(bucket, libDir, stage, prefix, oldBook.LibraryUUID, observedMemberTransition{
		LibraryUUID: oldBook.LibraryUUID, PreviousGeneration: hex.EncodeToString(oldToken),
		ObservedGeneration: hex.EncodeToString(middleToken),
	}, target, newPointer)
	if result.Scope != calibre.GenerationChangeScopeCoarse || result.Reason != "manifest-repeated-id" {
		t.Fatalf("result=%+v", result)
	}
}

func TestDeriveMemberChangeResultUnsafeEndpointPathFallsBack(t *testing.T) {
	oldBook := generationCandidateBook()
	newBook := cloneGenerationCandidateBook(oldBook)
	newBook.Title = "Edited"
	newBook.TitleSort = "Edited"
	file := *newBook.Formats[0]
	file.DirectoryPath = "../outside"
	newBook.Formats = []*calibre.File{&file}
	libDir := t.TempDir()
	oldToken, oldPointer, oldChecksum := writeMemberChangeEndpoint(t, libDir, oldBook, 1)
	writeCachedMemberCommit(t, libDir, oldToken, oldPointer)
	stage := t.TempDir()
	newToken, newPointer, newChecksum := writeMemberChangeEndpoint(t, stage, newBook, 2)

	bucket := t.TempDir()
	prefix := "member"
	writeExactMemberManifest(t, bucket, prefix, oldBook.LibraryUUID, oldToken, newToken, oldChecksum, newChecksum, generationEndpointDiff(t, oldBook, newBook).Changes)
	rclonexfer.Initialize()
	defer rclonexfer.Finalize()
	target, err := decodeAggregateGenerationToken(newToken)
	if err != nil {
		t.Fatal(err)
	}
	result := deriveMemberChangeResult(bucket, libDir, stage, prefix, oldBook.LibraryUUID, observedMemberTransition{
		LibraryUUID: oldBook.LibraryUUID, PreviousGeneration: hex.EncodeToString(oldToken),
		ObservedGeneration: hex.EncodeToString(newToken),
	}, target, newPointer)
	if result.Scope != calibre.GenerationChangeScopeCoarse || result.Reason != "endpoint-path-invalid" {
		t.Fatalf("result=%+v", result)
	}
}

func writeMemberChangeEndpoint(t *testing.T, dir string, book *calibre.Book, generation uint64) ([]byte, calibre.PointerFile, string) {
	t.Helper()
	jsonl := filepath.Join(dir, "books.jsonl")
	f, err := os.Create(jsonl)
	if err != nil {
		t.Fatal(err)
	}
	if err := json.NewEncoder(f).Encode(book); err != nil {
		_ = f.Close()
		t.Fatal(err)
	}
	if err := f.Close(); err != nil {
		t.Fatal(err)
	}
	base := generationChangeBase()
	indexPath := filepath.Join(dir, "library_index")
	search := &calibre.MotwSearch{JsonlPath: jsonl, IndexPath: indexPath, BaseGeneration: &base, StartGeneration: generation}
	index, err := search.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := search.CompressToFile(index); err != nil {
		t.Fatal(err)
	}
	mf, err := calibre.ReadExistingManifest(indexPath)
	if err != nil {
		t.Fatal(err)
	}
	if err := calibre.WritePointerFile(indexPath, mf, calibre.PointerFileLibrary{UUID: book.LibraryUUID, Librarian: "member"}, true); err != nil {
		t.Fatal(err)
	}
	pointer, err := calibre.ReadPointerFile(indexPath + ".manifest.json")
	if err != nil {
		t.Fatal(err)
	}
	pointer, err = calibre.BindPointerCommit(pointer, strings.Repeat("a", 64), generation)
	if err != nil {
		t.Fatal(err)
	}
	checksumBytes, err := calibre.CatalogChecksum([]*calibre.Book{book})
	if err != nil {
		t.Fatal(err)
	}
	checksum := hex.EncodeToString(checksumBytes[:])
	pointer.CatalogChecksum = checksum
	token := generationChangeMemberToken(generation)
	return token, pointer, checksum
}

func writeCachedMemberCommit(t *testing.T, libDir string, token []byte, pointer calibre.PointerFile) {
	t.Helper()
	if err := os.WriteFile(filepath.Join(libDir, ".member_generation"), token, 0o644); err != nil {
		t.Fatal(err)
	}
	data, err := json.MarshalIndent(pointer, "", "  ")
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(libDir, ".member_pointer"), data, 0o644); err != nil {
		t.Fatal(err)
	}
}

func generationEndpointDiff(t *testing.T, oldBook, newBook *calibre.Book) calibre.CatalogDiff {
	t.Helper()
	oldInfo, err := calibre.CatalogRecordInfoForBook(oldBook)
	if err != nil {
		t.Fatal(err)
	}
	diff, err := calibre.CompileCatalogDiffFromRecordInfos([]*calibre.Book{newBook}, map[string]calibre.CatalogRecordInfo{oldBook.Id: oldInfo})
	if err != nil {
		t.Fatal(err)
	}
	return diff
}

func writeExactMemberManifest(t *testing.T, bucket, prefix, libraryUUID string, fromToken, toToken []byte, fromChecksum, toChecksum string, changes []calibre.GenerationChange) {
	t.Helper()
	count := uint32(1)
	manifest := calibre.GenerationChangeManifest{
		Version: calibre.GenerationChangeManifestVersion, Scope: calibre.GenerationChangeScopeExact,
		LibraryUUID: libraryUUID, FromGeneration: hex.EncodeToString(fromToken), ToGeneration: hex.EncodeToString(toToken),
		TargetSourceFingerprint: strings.Repeat("a", 64), FromLiveCount: &count, ToLiveCount: count,
		FromCatalogChecksum: fromChecksum, ToCatalogChecksum: toChecksum,
		Changes: make([]calibre.GenerationChange, len(changes)),
	}
	copy(manifest.Changes, changes)
	data, err := calibre.EncodeGenerationChangeManifest(manifest)
	if err != nil {
		t.Fatal(err)
	}
	full := filepath.Join(bucket, prefix, filepath.FromSlash(generationChangeManifestPath(manifest.ToGeneration)))
	if err := os.MkdirAll(filepath.Dir(full), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(full, data, 0o644); err != nil {
		t.Fatal(err)
	}
}

func cloneGenerationCandidateBook(book *calibre.Book) *calibre.Book {
	clone := *book
	clone.Authors = append(make([]string, 0, len(book.Authors)), book.Authors...)
	clone.Formats = append(make([]*calibre.File, 0, len(book.Formats)), book.Formats...)
	clone.Identifiers = append(make([]*calibre.Identifier, 0, len(book.Identifiers)), book.Identifiers...)
	clone.Languages = append(make([]string, 0, len(book.Languages)), book.Languages...)
	clone.Tags = append(make([]string, 0, len(book.Tags)), book.Tags...)
	return &clone
}
