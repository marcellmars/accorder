package cmd

import (
	"accorder/pkg/calibre"
	"accorder/pkg/torinvite"
	"fmt"
	"os"
)

type LibIndexAddCmd struct {
	Name       string `arg:"" help:"Name for the source."`
	Endpoint   string `name:"endpoint" help:"HTTP(S) endpoint URL." validate:"omitempty,url"`
	InviteBlob string `name:"invite" help:"Invite blob (accorder-invite:...)." validate:"omitempty" secret:"redact"`
}

func (c *LibIndexAddCmd) Run() error {
	if c.Endpoint == "" && c.InviteBlob == "" {
		return fmt.Errorf("lib index add: at least one of --endpoint or --invite is required")
	}
	regName := calibre.SlugifySourceName(c.Name)
	if regName == "" {
		return fmt.Errorf("name %q normalizes to empty", c.Name)
	}
	entry := SourceEntry{}
	if c.Endpoint != "" {
		normalized, nerr := normalizeClearnetEndpoint(c.Endpoint)
		if nerr != nil {
			return nerr
		}
		entry.Endpoint = normalized
	}
	if c.InviteBlob != "" {
		decoded, err := torinvite.Decode(c.InviteBlob)
		if err != nil {
			return fmt.Errorf("decode invite: %w", err)
		}
		entry.Invite = c.InviteBlob
		entry.PublisherType = decoded.PublisherType
		if decoded.Endpoint != "" && entry.Endpoint == "" {
			ne, nerr := normalizeClearnetEndpoint(decoded.Endpoint)
			if nerr != nil {
				return fmt.Errorf("invite contains invalid endpoint %q: %w", decoded.Endpoint, nerr)
			}
			entry.Endpoint = ne
		}
	}
	// Convenience: for a clearnet endpoint, fetch the index now into the same cache
	// `lib browse` uses, so a later browse is instant and `lib index recompile`
	// works without a separate browse first. The download is idempotent (an
	// existing cached copy — e.g. from a prior browse — is reused) and non-fatal;
	// learning the library UUID lets us record it on the registry entry up front.
	if entry.Endpoint != "" {
		uuid, downloaded, derr := downloadIndexToBrowseCache(entry.Endpoint)
		if derr == nil {
			entry.UUID = uuid
		}
		if err := registrySet(regName, entry); err != nil {
			return err
		}
		if derr != nil {
			fmt.Fprintf(os.Stderr, "Source %q registered (index not cached: %v).\n  Browse it to cache: accorder lib browse <alias> --from %s\n", regName, derr, regName)
			return nil
		}
		cached := "index cached"
		if !downloaded {
			cached = "index already cached"
		}
		fmt.Fprintf(os.Stderr, "Source %q registered (%s).\n  Recompile with descriptions: accorder lib index recompile %s --descriptions\n  Browse:                      accorder lib browse <alias> --from %s\n", regName, cached, regName, regName)
		return nil
	}

	if err := registrySet(regName, entry); err != nil {
		return err
	}
	fmt.Fprintf(os.Stderr, "Source %q registered. Browse it to cache over Tor: accorder lib browse <alias> --from %s\n", regName, regName)
	return nil
}
