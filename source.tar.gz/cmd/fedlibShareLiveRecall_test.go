package cmd

// Task C: `fedlib share live --aggregate-path` is optional and recalled from the
// federation descriptor's fedlib-path (where `fedlib build` writes the
// aggregate). Explicit flag wins; a clear error fires when neither supplies a
// path. These call Run() directly — it populates c.AggregatePath from the
// descriptor near the top, then bails out at the members-registry read (no
// network), so the recalled value is observable on the receiver afterward.

import (
	"strings"
	"testing"
)

func TestFedlibShareLive_AggregatePathRecalledFromDescriptor(t *testing.T) {
	testSetup(t)
	aggDir := t.TempDir()
	desc := fedlibDescriptor{Version: fedlibDescriptorVersion, FedlibPath: aggDir, Mode: "public"}
	if err := saveFedlibDescriptor("testfed", desc); err != nil {
		t.Fatal(err)
	}

	c := &FedlibShareLiveCmd{}
	c.ActionAlias = "testfed"
	_ = c.Run() // fails later (empty members registry) — recall runs first

	if c.AggregatePath != aggDir {
		t.Errorf("aggregate-path not recalled from descriptor: got %q, want %q", c.AggregatePath, aggDir)
	}
}

func TestFedlibShareLive_AggregatePathExplicitFlagWins(t *testing.T) {
	testSetup(t)
	descDir := t.TempDir()
	explicit := t.TempDir()
	desc := fedlibDescriptor{Version: fedlibDescriptorVersion, FedlibPath: descDir, Mode: "public"}
	if err := saveFedlibDescriptor("testfed", desc); err != nil {
		t.Fatal(err)
	}

	c := &FedlibShareLiveCmd{}
	c.ActionAlias = "testfed"
	c.AggregatePath = explicit
	_ = c.Run()

	if c.AggregatePath != explicit {
		t.Errorf("explicit --aggregate-path overridden by descriptor: got %q, want %q", c.AggregatePath, explicit)
	}
}

func TestFedlibShareLive_AggregatePathMissingErrors(t *testing.T) {
	testSetup(t)
	desc := fedlibDescriptor{Version: fedlibDescriptorVersion, Mode: "public"} // no FedlibPath
	if err := saveFedlibDescriptor("testfed", desc); err != nil {
		t.Fatal(err)
	}

	c := &FedlibShareLiveCmd{}
	c.ActionAlias = "testfed"
	err := c.Run()
	if err == nil || !strings.Contains(err.Error(), "--aggregate-path is required") {
		t.Errorf("expected '--aggregate-path is required' error, got: %v", err)
	}
}
