package cmd

import (
	"accorder/pkg/calibre"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"

	"github.com/goccy/go-json"
)

// ===========================================================================
// Spike Hypothesis 1: fedlib build can read local indexes from disk and
// produce the same aggregate output as the S3 path.
//

// Strategy: create two synthetic MWSC indexes on disk (one per "library"),
// then replicate the core aggregation logic (AllBooksFromIndex → merge →
// BuildIndex + CompressToFile → AllBooksFromIndex roundtrip) without any
// rclone/S3 involvement.
// ===========================================================================

// seedLocalLibrary creates a minimal MWSC index at dir/library_index.zst
// containing n books tagged with the given librarian and libraryUUID.
// Returns the index base path (without .zst).
func seedLocalLibrary(tb testing.TB, dir string, n int, librarian, libraryUUID, prefix string) string {
	tb.Helper()

	if err := os.MkdirAll(dir, 0o755); err != nil {
		tb.Fatal(err)
	}

	jsonlPath := filepath.Join(dir, "books.jsonl")
	f, err := os.Create(jsonlPath)
	if err != nil {
		tb.Fatal(err)
	}
	defer f.Close()

	for i := 0; i < n; i++ {
		book := calibre.Book{
			Title:        fmt.Sprintf("Book %d by %s", i, librarian),
			Authors:      []string{librarian},
			Tags:         []string{"spike-test"},
			LastModified: fmt.Sprintf("2024-01-%02dT00:00:00+00:00", (i%28)+1),
			LibraryUUID:  libraryUUID,
			Librarian:    librarian,
			Id:           fmt.Sprintf("%s-book-%d", libraryUUID, i),
			BaseURL:      "/files/" + prefix,
			LibraryUrl:   "/files/" + prefix + "/",
		}
		data, err := json.Marshal(book)
		if err != nil {
			tb.Fatal(err)
		}
		f.Write(append(data, '\n'))
	}

	indexPath := filepath.Join(dir, "library_index")
	ms := &calibre.MotwSearch{
		JsonlPath:            jsonlPath,
		IndexPath:            indexPath,
		IndexAggregateFields: true,
	}
	idx, err := ms.BuildIndex()
	if err != nil {
		tb.Fatalf("BuildIndex for %s: %v", librarian, err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		tb.Fatalf("CompressToFile for %s: %v", librarian, err)
	}
	return indexPath
}

func TestSpike_LocalDiskAggregateBuild(t *testing.T) {
	root := t.TempDir()

	// Create two local libraries.
	lib1Dir := filepath.Join(root, "libs", "alice")
	lib1Index := seedLocalLibrary(t, lib1Dir, 5, "Alice", "uuid-alice-1111", "alice")

	lib2Dir := filepath.Join(root, "libs", "bob")
	lib2Index := seedLocalLibrary(t, lib2Dir, 3, "Bob", "uuid-bob-2222", "bob")

	// Read books from each local index (the same call fedlibBuild uses after
	// rclone fetches the file — proving the local path works identically).
	aliceBooks, err := calibre.AllBooksFromIndex(lib1Index)
	if err != nil {
		t.Fatalf("AllBooksFromIndex(alice): %v", err)
	}
	bobBooks, err := calibre.AllBooksFromIndex(lib2Index)
	if err != nil {
		t.Fatalf("AllBooksFromIndex(bob): %v", err)
	}

	t.Logf("alice: %d books, bob: %d books", len(aliceBooks), len(bobBooks))

	if len(aliceBooks) != 5 {
		t.Errorf("alice book count: got %d, want 5", len(aliceBooks))
	}
	if len(bobBooks) != 3 {
		t.Errorf("bob book count: got %d, want 3", len(bobBooks))
	}

	// Merge and build aggregate index — same as fedlibBuild.go:154-195.
	var allBooks []*calibre.Book
	allBooks = append(allBooks, aliceBooks...)
	allBooks = append(allBooks, bobBooks...)

	aggJSONLPath := filepath.Join(root, "aggregate.jsonl")
	af, err := os.Create(aggJSONLPath)
	if err != nil {
		t.Fatal(err)
	}
	for _, b := range allBooks {
		data, err := json.Marshal(b)
		if err != nil {
			t.Fatal(err)
		}
		af.Write(append(data, '\n'))
	}
	af.Close()

	aggIndexPath := filepath.Join(root, "library_index")
	ms := &calibre.MotwSearch{
		JsonlPath:            aggJSONLPath,
		IndexPath:            aggIndexPath,
		IndexAggregateFields: true,
	}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatalf("aggregate BuildIndex: %v", err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatalf("aggregate CompressToFile: %v", err)
	}

	// Verify the aggregate index can be read back.
	roundtripBooks, err := calibre.AllBooksFromIndex(aggIndexPath)
	if err != nil {
		t.Fatalf("AllBooksFromIndex(aggregate): %v", err)
	}
	if len(roundtripBooks) != 8 {
		t.Errorf("aggregate book count: got %d, want 8", len(roundtripBooks))
	}

	// Verify identity is preserved: all books retain their librarian and
	// library_uuid from the source libraries.
	aliceCount, bobCount := 0, 0
	for _, b := range roundtripBooks {
		switch b.Librarian {
		case "Alice":
			aliceCount++
			if b.LibraryUUID != "uuid-alice-1111" {
				t.Errorf("alice book %s has wrong library_uuid: %s", b.Id, b.LibraryUUID)
			}
		case "Bob":
			bobCount++
			if b.LibraryUUID != "uuid-bob-2222" {
				t.Errorf("bob book %s has wrong library_uuid: %s", b.Id, b.LibraryUUID)
			}
		default:
			t.Errorf("unexpected librarian %q on book %s", b.Librarian, b.Id)
		}
	}
	if aliceCount != 5 {
		t.Errorf("alice books in aggregate: got %d, want 5", aliceCount)
	}
	if bobCount != 3 {
		t.Errorf("bob books in aggregate: got %d, want 3", bobCount)
	}

	t.Logf("VALIDATED: local disk → AllBooksFromIndex → merge → BuildIndex → CompressToFile → roundtrip AllBooksFromIndex works for %d books from %d libraries", len(roundtripBooks), 2)
}

// ===========================================================================
// Spike Hypothesis 2: The aggregate mux can serve mixed /files/{prefix}/
// routes — some backed by http.FileServer (local), some backed by a VFS
// proxy (remote) — on a single mux.
//

// Strategy: create a real http.ServeMux, register one prefix via FileServer
// (local dir) and another via a reverse-proxy to a test HTTP server (fake
// VFS). Verify both routes serve correct content.
// ===========================================================================

func TestSpike_MixedRouteMux(t *testing.T) {

	// --- Local library: create a temp dir with a file to serve. ---
	localDir := t.TempDir()
	localPrefix := "locallib"
	localBookContent := []byte("local epub content")
	bookDir := filepath.Join(localDir, "42", "99")
	if err := os.MkdirAll(bookDir, 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(bookDir, "book.epub"), localBookContent, 0o644); err != nil {
		t.Fatal(err)
	}

	// --- Remote library: stand up a test HTTP server as the VFS backend. ---
	remotePrefix := "remotelib"
	remoteBookContent := []byte("remote epub from VFS")
	vfsServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {

		// The VFS backend receives the full path; in production it's rewritten
		// by the reverse proxy. Here we just echo back the content.
		w.Header().Set("Content-Type", "application/epub+zip")
		w.Write(remoteBookContent)
	}))
	defer vfsServer.Close()

	// --- Build mux with mixed routes. ---
	mux := http.NewServeMux()

	// Route 1: local prefix → http.FileServer
	localFS := http.FileServer(http.Dir(localDir))
	localPattern := "/files/" + localPrefix + "/"
	mux.Handle(localPattern, http.StripPrefix(localPattern, localFS))

	// Route 2: remote prefix → reverse proxy to fake VFS
	remotePattern := "/files/" + remotePrefix + "/"
	mux.HandleFunc(remotePattern, func(w http.ResponseWriter, r *http.Request) {

		// Simplified VFS proxy (mirrors registerAggregateRoutes pattern).
		vfsURL := vfsServer.URL + r.URL.Path
		proxyReq, err := http.NewRequestWithContext(r.Context(), r.Method, vfsURL, nil)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		resp, err := http.DefaultClient.Do(proxyReq)
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadGateway)
			return
		}
		defer resp.Body.Close()
		for k, vv := range resp.Header {
			for _, v := range vv {
				w.Header().Add(k, v)
			}
		}
		w.WriteHeader(resp.StatusCode)
		io.Copy(w, resp.Body)
	})

	// --- Test server wrapping the mux. ---
	ts := httptest.NewServer(mux)
	defer ts.Close()

	// Test 1: local route serves the file from disk.
	t.Run("local_fileserver", func(t *testing.T) {
		resp, err := http.Get(ts.URL + "/files/" + localPrefix + "/42/99/book.epub")
		if err != nil {
			t.Fatal(err)
		}
		defer resp.Body.Close()
		if resp.StatusCode != 200 {
			t.Fatalf("local route status: got %d, want 200", resp.StatusCode)
		}
		body, _ := io.ReadAll(resp.Body)
		if string(body) != string(localBookContent) {
			t.Errorf("local route body: got %q, want %q", body, localBookContent)
		}
		t.Logf("local route OK: served %d bytes from disk", len(body))
	})

	// Test 2: remote route proxies to the VFS backend.
	t.Run("remote_vfs_proxy", func(t *testing.T) {
		resp, err := http.Get(ts.URL + "/files/" + remotePrefix + "/55/66/remote_book.epub")
		if err != nil {
			t.Fatal(err)
		}
		defer resp.Body.Close()
		if resp.StatusCode != 200 {
			t.Fatalf("remote route status: got %d, want 200", resp.StatusCode)
		}
		body, _ := io.ReadAll(resp.Body)
		if string(body) != string(remoteBookContent) {
			t.Errorf("remote route body: got %q, want %q", body, remoteBookContent)
		}
		t.Logf("remote route OK: proxied %d bytes from VFS", len(body))
	})

	// Test 3: routes don't interfere — requesting a non-existent local file
	// returns 404, not the remote content.
	t.Run("no_cross_contamination", func(t *testing.T) {
		resp, err := http.Get(ts.URL + "/files/" + localPrefix + "/nonexistent.epub")
		if err != nil {
			t.Fatal(err)
		}
		defer resp.Body.Close()
		if resp.StatusCode != 404 {
			t.Errorf("missing local file: got status %d, want 404", resp.StatusCode)
		}
		t.Logf("cross-contamination check OK: missing local file returns %d", resp.StatusCode)
	})

	// Test 4: unknown prefix returns 404.
	t.Run("unknown_prefix_404", func(t *testing.T) {
		resp, err := http.Get(ts.URL + "/files/unknownlib/book.epub")
		if err != nil {
			t.Fatal(err)
		}
		defer resp.Body.Close()
		if resp.StatusCode != 404 {
			t.Errorf("unknown prefix: got status %d, want 404", resp.StatusCode)
		}
		t.Logf("unknown prefix check OK: returns %d", resp.StatusCode)
	})

	t.Logf("VALIDATED: mixed /files/{prefix}/ routes (local FileServer + VFS proxy) work correctly on a single mux")
}

// ===========================================================================
// Spike Hypothesis 3: Per-fedlib members.json can coexist with the action-
// alias system. The action-alias system keys on command paths (e.g.,
// "fedlib.build"); the members registry is a separate file keyed on UUID.
//

// Strategy: write a members.json beside the aggregate output path, then read
// it back using the same readAggregateRegistry function. Verify that the
// action-alias file format (saved in accorderConfigDir) and the per-fedlib
// members.json format are the same map[string]calibre.LibraryMeta.
// ===========================================================================

func TestSpike_PerFedlibMembersJSON(t *testing.T) {
	outputDir := t.TempDir()

	// Simulate a per-fedlib members.json beside the aggregate output.
	registry := map[string]calibre.LibraryMeta{
		"uuid-alice-1111": {
			Librarian: "Alice",
			Prefix:    "alice",
		},
		"uuid-bob-2222": {
			Librarian: "Bob",
			Prefix:    "bob",
			State:     "off",
		},
	}

	membersPath := filepath.Join(outputDir, "members.json")
	data, err := json.MarshalIndent(registry, "", "  ")
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(membersPath, data, 0o644); err != nil {
		t.Fatal(err)
	}

	// Read it back with the same function used by fedlibBuild.
	got, err := readAggregateRegistry(membersPath)
	if err != nil {
		t.Fatalf("readAggregateRegistry: %v", err)
	}

	if len(got) != 2 {
		t.Fatalf("registry length: got %d, want 2", len(got))
	}

	// Verify Alice.
	alice, ok := got["uuid-alice-1111"]
	if !ok {
		t.Fatal("alice not found in registry")
	}
	if alice.Librarian != "Alice" || alice.Prefix != "alice" || alice.State != "" {
		t.Errorf("alice: got %+v, want {Librarian:Alice, Prefix:alice, State:\"\"}", alice)
	}

	// Verify Bob (disabled).
	bob, ok := got["uuid-bob-2222"]
	if !ok {
		t.Fatal("bob not found in registry")
	}
	if bob.Librarian != "Bob" || bob.Prefix != "bob" || bob.State != "off" {
		t.Errorf("bob: got %+v, want {Librarian:Bob, Prefix:bob, State:off}", bob)
	}

	// Verify that action aliases (stored in a separate config dir) don't
	// interfere. The key insight: action aliases are stored under
	// accorderConfigDir/action_aliases.json and keyed on command paths
	// (e.g., "fedlib.build.myagg"), while the per-fedlib members.json is
	// keyed on UUIDs and lives beside the aggregate output. They're
	// completely separate namespaces.
	//

	// Simulate: write a fake action alias file, then verify both files can
	// coexist and be read independently.
	aliasDir := filepath.Join(outputDir, "config")
	if err := os.MkdirAll(aliasDir, 0o755); err != nil {
		t.Fatal(err)
	}
	aliasContent := []byte(`{
		"fedlib.build.myagg": {
			"output-path": "/tmp/myagg",
			"bucket": "my-bucket",
			"s3-access-key": "AKIA...",
			"s3-secret-key": "secret",
			"s3-provider": "Wasabi",
			"s3-endpoint": "https://s3.wasabisys.com"
		}
	}`)
	aliasPath := filepath.Join(aliasDir, "action_aliases.json")
	if err := os.WriteFile(aliasPath, aliasContent, 0o644); err != nil {
		t.Fatal(err)
	}

	// Re-read members.json — still works after alias file exists.
	got2, err := readAggregateRegistry(membersPath)
	if err != nil {
		t.Fatalf("readAggregateRegistry (second read): %v", err)
	}
	if len(got2) != 2 {
		t.Fatalf("second read: registry length: got %d, want 2", len(got2))
	}

	// Verify the alias file didn't corrupt the members registry.
	aliasData, err := os.ReadFile(aliasPath)
	if err != nil {
		t.Fatal(err)
	}
	var aliasMap map[string]json.RawMessage
	if err := json.Unmarshal(aliasData, &aliasMap); err != nil {
		t.Fatalf("parse alias file: %v", err)
	}
	if _, ok := aliasMap["fedlib.build.myagg"]; !ok {
		t.Error("alias key 'fedlib.build.myagg' missing after members.json read")
	}

	// Bonus: verify that members.json with new-format fields (Locator, Kind)
	// deserializes correctly with the current LibraryMeta struct (unknown
	// fields are silently ignored by Go's json.Unmarshal).
	futureJSON := []byte(`{
		"uuid-future-3333": {
			"librarian": "Charlie",
			"prefix": "charlie",
			"locator": {"kind": "local", "path": "/data/charlie"},
			"kind": "local",
			"read_creds": "ref:charlie-creds",
			"health": {"status": "ok", "last_check": "2026-06-03T12:00:00Z"}
		}
	}`)
	futurePath := filepath.Join(outputDir, "future_members.json")
	if err := os.WriteFile(futurePath, futureJSON, 0o644); err != nil {
		t.Fatal(err)
	}
	futureReg, err := readAggregateRegistry(futurePath)
	if err != nil {
		t.Fatalf("readAggregateRegistry(future format): %v", err)
	}
	charlie, ok := futureReg["uuid-future-3333"]
	if !ok {
		t.Fatal("charlie not found in future-format registry")
	}
	if charlie.Librarian != "Charlie" || charlie.Prefix != "charlie" {
		t.Errorf("charlie: got %+v, want {Librarian:Charlie, Prefix:charlie}", charlie)
	}

	// The extra fields (locator, kind, read_creds, health) are silently
	// ignored — no error. This confirms forward compatibility.

	t.Logf("VALIDATED: per-fedlib members.json coexists with action-alias system; readAggregateRegistry works from any path; future fields are forward-compatible")
}
