package cmd

import (
	"crypto/sha256"
	"encoding/hex"
	"regexp"
	"strings"
)

// Redaction classes for --show-config. Deny-by-default: a flag renders its
// value only when this file affirmatively classifies it safe. A flag that is
// neither listed in safeFlagNames nor tagged secret: renders <redacted>, so
// an unclassified addition fails toward hiding rather than leaking. The
// reflection test in showConfigClass_test.go names any such flag.
type redactClass int

const (
	classSafe redactClass = iota
	// classRedact prints <redacted> with no fingerprint. For low-entropy or
	// structured secrets (passphrases, invite blobs): a stable unsalted hash
	// would permit offline dictionary checking and cross-output correlation
	// while adding no diagnostic value.
	classRedact
	// classFingerprint prints <redacted:xxxxxxxx>. For high-entropy keys,
	// where "do both boxes hold the same key?" is the real diagnostic
	// question and 8 hex of SHA-256 over a high-entropy secret is not
	// invertible.
	classFingerprint
)

// credentialNamePattern is the Layer 2 safety net. It does not classify —
// safeFlagNames does. It exists to catch a newly added credential field
// that someone also added to the safe list by reflex.
var credentialNamePattern = regexp.MustCompile(
	`(?i)(secret|passphrase|password|token|access.?key|private.?key|auth.?key|invite|cookie|bearer|credential)`)

// safeFlagNames lists every flag whose VALUE is safe to print. Sorted, one
// per line, so the security-relevant review is reading this list rather
// than auditing hundreds of struct tags.
//
// Adding a flag here is the affirmative act of declaring "this value may be
// printed and pasted into a chat log". Do not add a flag that carries a
// key, token, passphrase, invite blob, or anything bearer-equivalent.
var safeFlagNames = map[string]bool{
	"accept-defaults":            true,
	"aggregate-path":             true,
	"allow-full-reupload":        true,
	"allow-full-rebuild":         true,
	"append":                     true,
	"apply":                      true,
	"apply-cache-trees":          true,
	"attest-no-serves":           true,
	"baseurl":                    true,
	"bucket":                     true,
	"cache-dir":                  true,
	"cache-max-age":              true,
	"cache-min-free":             true,
	"cache-size":                 true,
	"cache-size-assets":          true,
	"calibrepath":                true,
	"compact":                    true,
	"compact-if-needed":          true,
	"config-dir":                 true,
	"config-home":                true,
	"descriptions":               true,
	"dictID":                     true,
	"dir-cache-time":             true,
	"discard-pending":            true,
	"download-dir":               true,
	"dry-run":                    true,
	"egress-budget-usd":          true,
	"egress-burst":               true,
	"egress-limit":               true,
	"egress-monthly-allowance":   true,
	"egress-price-per-gb":        true,
	"endpoint":                   true,
	"exclude":                    true,
	"exec-path":                  true,
	"fedlib-path":                true,
	"fedlibPrefix":               true,
	"fetch-covers":               true,
	"files":                      true,
	"files-root":                 true,
	"finish-interrupted-publish": true,
	"force":                      true,
	"friend":                     true,
	"from":                       true,
	"home":                       true,
	"iam-endpoint":               true,
	"index":                      true,
	"index-path":                 true,
	"input":                      true,
	"insecure":                   true,
	"json":                       true,
	"json-export":                true,
	"json-path":                  true,
	"jsonl-export":               true,
	"jsonl-path":                 true,
	"keys-file":                  true,
	"librarian":                  true,
	"library-name":               true,
	"libraryID":                  true,
	"limit":                      true,
	"list":                       true,
	"listen":                     true,
	"local-path":                 true,
	"local-wins":                 true,
	"max-deletes":                true,
	"memory-limit":               true,
	"member-change-request":      true,
	"meter-bucket-granularity":   true,
	"meter-max-distinct":         true,
	"meter-max-sessions":         true,
	"meter-window":               true,
	"mode":                       true,
	"no-cover-sync":              true,
	"no-enable":                  true,
	"no-monolithic-rebuild":      true,
	"offer":                      true,
	"offer-expiry":               true,
	"offline":                    true,
	"offset":                     true,
	"only-http":                  true,
	"only-tor":                   true,
	"operator-root-keys-file":    true,
	"output":                     true,
	"output-path":                true,
	"pointer-url":                true,
	"poll-interval":              true,
	"pprof-listen":               true,
	"prefix":                     true,
	"print-mint-commands":        true,
	"prune":                      true,
	"public":                     true,
	"query":                      true,
	"rclone-log-level":           true,
	"remote-wins":                true,
	"s3-endpoint":                true,
	"s3-prefix":                  true,
	"serve-arg":                  true,
	"s3-provider":                true,
	"s3-source":                  true,
	"skip-upload":                true,
	"sort":                       true,
	"timeout":                    true,
	"timeout-start":              true,
	"to-key-file":                true,
	"unit-dir":                   true,
	"unit-name":                  true,
	"upload-prefix":              true,
	"user":                       true,
	"verbose":                    true,
	"wait":                       true,
	"yes":                        true,
	"zotero-path":                true,
}

// classifyFlag reports how a flag's value should render. The struct tag
// wins when present, so a credential field carries its classification next
// to its declaration; otherwise the central safe list decides. secretSpec
// is the raw `secret:"..."` tag value ("" when absent).
func classifyFlag(flagName, secretSpec string) redactClass {
	switch {
	case secretSpec == "":
		// fall through to the registry
	case strings.HasPrefix(secretSpec, "redact,fingerprint"):
		return classFingerprint
	case strings.HasPrefix(secretSpec, "redact"):
		return classRedact
	case secretSpec == "safe":
		return classSafe
	}
	if safeFlagNames[flagName] {
		return classSafe
	}
	return classRedact
}

// renderValue applies the class. Field NAMES always print; only values are
// withheld, so absence from the output is never ambiguous.
func renderValue(raw string, class redactClass) string {
	if raw == "" {
		return "(unset)"
	}
	switch class {
	case classFingerprint:
		return "<redacted:" + fingerprint(raw) + ">"
	case classRedact:
		return "<redacted>"
	default:
		return raw
	}
}

func fingerprint(v string) string {
	sum := sha256.Sum256([]byte(v))
	return hex.EncodeToString(sum[:])[:8]
}
