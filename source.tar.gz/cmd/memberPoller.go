package cmd

import (
	"accorder/pkg/calibre"
	"accorder/pkg/librarianname"
	"accorder/pkg/rclonexfer"
	"bufio"
	"context"
	"crypto/sha256"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
	"sync/atomic"
	"time"
)

type memberPollEntry struct {
	Prefix     string
	State      string // "ready", "invited", "retired", etc.
	Kind       string // "", "local", "rclone", "peer"
	Endpoint   string // only for Kind=="peer"
	GrantToken string // only for Kind=="peer"
}

type memberHealth struct {
	LastProbe     time.Time
	LastHealthy   time.Time // last successful probe — gates the retire grace period
	Latency       time.Duration
	ConsecErrors  int
	ConsecHealthy int
	RetiredAt     time.Time
	Since         time.Time
}

const (
	retireThreshold  = 3 // consecutive probe failures before ready→retired
	promoteThreshold = 2 // consecutive healthy probes before retired→ready
	// retireGracePeriod: a member healthy this recently is NOT retired on a failure
	// burst — only after SUSTAINED failure. Avoids evicting a just-confirmed member on
	// a transient probe blip (e.g. a brief S3/librclone object-visibility 404 right
	// after it published), which would drop it from the served aggregate.
	retireGracePeriod = 90 * time.Second
)

func buildMemberPollSet(registry map[string]calibre.LibraryMeta) map[string]memberPollEntry {
	set := make(map[string]memberPollEntry, len(registry))
	for uuid, meta := range registry {
		if meta.State == "disabled" {
			continue
		}
		if meta.IsLocal() {
			continue
		}
		if meta.Prefix == "" {
			continue
		}
		set[uuid] = memberPollEntry{
			Prefix:     meta.Prefix,
			State:      meta.State,
			Kind:       meta.Kind,
			Endpoint:   meta.Endpoint,
			GrantToken: meta.GrantToken,
		}
	}
	return set
}

type memberPollContext struct {
	pollSet           map[string]memberPollEntry
	registryPrefixes  map[string]string
	registryPath      string
	lastKnownGen      map[string][24]byte
	lastTickChanges   map[string]genChange
	lastMemberDigest  [16]byte
	membershipChanged bool
	healthState       map[string]*memberHealth
}

type genChange struct {
	prev    [24]byte
	hadPrev bool
}

func (mpc *memberPollContext) revertLastChanges() {
	for prefix, ch := range mpc.lastTickChanges {
		if ch.hadPrev {
			mpc.lastKnownGen[prefix] = ch.prev
		} else {
			delete(mpc.lastKnownGen, prefix)
		}
	}
	mpc.lastTickChanges = nil
}

// rollback undoes one tick's observations after its rebuild did not land:
// generations revert so the change is re-detected, and the topology flag is
// restored so a membership change is not downgraded to a prefix change.
func (mpc *memberPollContext) rollback(membershipChanged bool) {
	mpc.revertLastChanges()
	mpc.membershipChanged = membershipChanged
}

func (mpc *memberPollContext) getOrCreateHealth(uuid string) *memberHealth {
	if mpc.healthState == nil {
		mpc.healthState = make(map[string]*memberHealth)
	}
	h, ok := mpc.healthState[uuid]
	if !ok {
		h = &memberHealth{Since: time.Now()}
		mpc.healthState[uuid] = h
	}
	return h
}

func probePeerGeneration(ctx context.Context, entry memberPollEntry, probeDir string) ([]byte, error) {
	client := newBrowseClearnetHTTPClient(entry.GrantToken, "")
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, entry.Endpoint+"/_GENERATION", nil)
	if err != nil {
		return nil, fmt.Errorf("peer probe %s: %w", entry.Prefix, err)
	}
	resp, err := client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("peer probe %s: %w", entry.Prefix, err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("peer probe %s: status %d", entry.Prefix, resp.StatusCode)
	}
	body, err := io.ReadAll(io.LimitReader(resp.Body, 256))
	if err != nil {
		return nil, fmt.Errorf("peer probe %s: read body: %w", entry.Prefix, err)
	}
	genLocalName := entry.Prefix + "__GENERATION"
	if err := os.WriteFile(filepath.Join(probeDir, genLocalName), body, 0o644); err != nil {
		return nil, fmt.Errorf("peer probe %s: write local: %w", entry.Prefix, err)
	}
	return body, nil
}

func pollMemberGenerations(ctx context.Context, bucketFS, probeDir string, mpc *memberPollContext) (changed bool, changedUUIDs []string) {
	mpc.lastTickChanges = make(map[string]genChange)
	type pollItem struct {
		uuid  string
		entry memberPollEntry
	}
	items := make([]pollItem, 0, len(mpc.pollSet))
	for uuid, entry := range mpc.pollSet {
		items = append(items, pollItem{uuid, entry})
	}
	for _, it := range items {
		uuid, entry := it.uuid, it.entry
		if ctx.Err() != nil {
			return changed, changedUUIDs
		}

		h := mpc.getOrCreateHealth(uuid)
		probeStart := time.Now()

		genLocalName := entry.Prefix + "__GENERATION"
		var probeErr error
		if entry.Kind == "peer" {
			_, probeErr = probePeerGeneration(ctx, entry, probeDir)
		} else {
			genRemotePath := entry.Prefix + "/_GENERATION"
			// An invited member has published nothing yet, so a missing
			// _GENERATION is the expected observation for the whole waiting
			// period — indefinitely, if they never join. Copying it anyway
			// makes rclone's RC layer log `ERROR : rc: "operations/copyfile":
			// error: object not found` once per poll: a permanent ERROR stream
			// for a member that is simply not here yet. During the 2026-08-30
			// outage that stream read like a lead and cost real triage time.
			//
			// operations/stat reports a miss as (nil, nil) with status 200 and
			// logs nothing, so waiting is silent and the first publish is still
			// picked up on the very next poll. A ready member keeps the direct
			// copy: there a missing _GENERATION is genuinely anomalous, and the
			// ERROR is the signal it should be.
			if entry.State == "invited" {
				obj, statErr := rclonexfer.StatObject(bucketFS, genRemotePath)
				if statErr == nil && obj == nil {
					// Still waiting. Not an error, so health is left untouched
					// rather than accruing failures against a member that has
					// not been asked to be reachable yet.
					continue
				}
			}
			probeErr = rclonexfer.CopyFile(bucketFS, genRemotePath, probeDir, genLocalName)
		}
		if probeErr != nil {
			h.LastProbe = probeStart
			h.Latency = time.Since(probeStart)
			h.ConsecErrors++
			h.ConsecHealthy = 0
			recentlyHealthy := !h.LastHealthy.IsZero() && time.Since(h.LastHealthy) < retireGracePeriod
			if isMemberActive(entry.State) && h.ConsecErrors >= retireThreshold && !recentlyHealthy {
				log.Printf("fedlib share live: member %s retired (%d consecutive probe failures, last healthy %s ago)", entry.Prefix, h.ConsecErrors, time.Since(h.LastHealthy).Truncate(time.Second))
				h.RetiredAt = time.Now()
				if persistErr := persistMemberState(mpc.registryPath, uuid, "retired"); persistErr != nil {
					log.Printf("fedlib share live: member %s: persist retire: %v", entry.Prefix, persistErr)
				} else {
					mpc.pollSet[uuid] = memberPollEntry{Prefix: entry.Prefix, State: "retired", Kind: entry.Kind, Endpoint: entry.Endpoint, GrantToken: entry.GrantToken}
					mpc.membershipChanged = true
				}
			}
			continue
		}

		h.LastProbe = probeStart
		h.LastHealthy = probeStart
		h.Latency = time.Since(probeStart)
		h.ConsecErrors = 0
		h.ConsecHealthy++

		if entry.State == "retired" && h.ConsecHealthy >= promoteThreshold {
			log.Printf("fedlib share live: member %s promoted (%d consecutive healthy probes)", entry.Prefix, h.ConsecHealthy)
			h.RetiredAt = time.Time{}
			if persistErr := persistMemberState(mpc.registryPath, uuid, "ready"); persistErr != nil {
				log.Printf("fedlib share live: member %s: persist promote: %v", entry.Prefix, persistErr)
			} else {
				mpc.pollSet[uuid] = memberPollEntry{Prefix: entry.Prefix, State: "ready", Kind: entry.Kind, Endpoint: entry.Endpoint, GrantToken: entry.GrantToken}
				mpc.membershipChanged = true
			}
		}

		genBytes, err := os.ReadFile(filepath.Join(probeDir, genLocalName))
		if err != nil {
			continue
		}
		token, err := decodeAggregateGenerationToken(genBytes)
		if err != nil {
			log.Printf("fedlib share live: member %s: decode _GENERATION: %v", entry.Prefix, err)
			continue
		}
		_, gen := token.parts()
		cur := [24]byte(token)

		prev, known := mpc.lastKnownGen[entry.Prefix]
		if known && cur == prev {
			continue
		}

		resolvedUUID := uuid
		if entry.State == "invited" {
			realUUID, err := reconcileInvitedMember(uuid, entry.Prefix, bucketFS, mpc)
			if err != nil {
				// Do not consume the generation: the index or registry failure may
				// be transient, and the unchanged token must retry reconciliation
				// on the next poll.
				log.Printf("fedlib share live: member %s reconciliation failed (will retry): %v", entry.Prefix, err)
				continue
			}
			// The first successful reconcile makes a previously absent member
			// visible. Mark topology in this tick so the matching aggregate
			// publication uses a full VFS directory forget; the next digest
			// refresh is too late for the first hot-swap.
			mpc.membershipChanged = true
			resolvedUUID = realUUID
		}

		mpc.lastKnownGen[entry.Prefix] = cur

		if !known && entry.State != "invited" {
			continue
		}

		mpc.lastTickChanges[entry.Prefix] = genChange{prev: prev, hadPrev: known}

		log.Printf("fedlib share live: member %s generation changed (gen=%d); rebuilding aggregate", entry.Prefix, gen)
		changed = true
		changedUUIDs = append(changedUUIDs, resolvedUUID)
	}
	return changed, changedUUIDs
}

func persistMemberState(registryPath, uuid, state string) error {
	return mutateMembersRegistryLocked(registryPath, func(registry map[string]calibre.LibraryMeta) error {
		m, exists := registry[uuid]
		if !exists {
			return fmt.Errorf("member %s not found in registry", uuid)
		}
		m.State = state
		registry[uuid] = m
		return nil
	})
}

func reconcileInvitedMember(oldUUID, prefix, bucketFS string, mpc *memberPollContext) (string, error) {
	tmpDir, err := os.MkdirTemp("", "reconcile-"+prefix+"-*")
	if err != nil {
		return oldUUID, fmt.Errorf("mktemp: %w", err)
	}
	defer os.RemoveAll(tmpDir)

	indexRemote := prefix + "/static/library_index.zst"
	if err := rclonexfer.CopyFile(bucketFS, indexRemote, tmpDir, "library_index.zst"); err != nil {
		return oldUUID, fmt.Errorf("fetch index: %w", err)
	}

	indexPath := filepath.Join(tmpDir, "library_index")
	books, err := calibre.AllBooksFromIndex(indexPath)
	if err != nil {
		return oldUUID, fmt.Errorf("read index: %w", err)
	}
	if len(books) == 0 {
		return oldUUID, fmt.Errorf("index is empty")
	}

	realUUID := books[0].LibraryUUID
	if realUUID == "" {
		return oldUUID, fmt.Errorf("LibraryUUID is empty in index")
	}

	registry, registryPath, err := loadMembersRegistryFromPath(mpc.registryPath)
	if err != nil {
		return oldUUID, fmt.Errorf("load registry: %w", err)
	}

	found := false
	for uuid, meta := range registry {
		if meta.State == "invited" && meta.Prefix == prefix {
			delete(registry, uuid)
			libName := meta.Librarian
			if libName == "" {
				libName = books[0].Librarian
			}
			libName = resolveMemberLibrarian(libName, realUUID, registry)
			registry[realUUID] = calibre.LibraryMeta{
				Librarian: libName,
				Prefix:    meta.Prefix,
				State:     "ready",
				Kind:      meta.Kind,
			}
			found = true
			break
		}
	}
	if !found {
		return oldUUID, fmt.Errorf("no invited entry found for prefix %s", prefix)
	}

	if err := saveMembersRegistry(registryPath, registry); err != nil {
		return oldUUID, fmt.Errorf("save registry: %w", err)
	}

	oldEntry := mpc.pollSet[oldUUID]
	delete(mpc.pollSet, oldUUID)
	mpc.pollSet[realUUID] = memberPollEntry{
		Prefix:     prefix,
		State:      "ready",
		Kind:       oldEntry.Kind,
		Endpoint:   oldEntry.Endpoint,
		GrantToken: oldEntry.GrantToken,
	}

	delete(mpc.registryPrefixes, oldUUID)
	mpc.registryPrefixes[realUUID] = prefix

	if oldUUID == realUUID {
		log.Printf("fedlib share live: member %s confirmed: invited→ready (operator-minted UUID %s)", prefix, realUUID)
	} else {
		log.Printf("fedlib share live: member %s reconciled via rekey: invited→ready (%s → %s)", prefix, oldUUID, realUUID)
	}
	return realUUID, nil
}

func resolveMemberLibrarian(name, memberUUID string, registry map[string]calibre.LibraryMeta) string {
	taken := make(map[string]bool, len(registry))
	for _, m := range registry {
		taken[m.Librarian] = true
	}
	if name == "" || !taken[name] {
		return name
	}
	if bump, ok := librarianname.IsGenerated(name, memberUUID); ok {
		poolSize := librarianname.MiddlePoolSize()
		for b := 1; b < poolSize; b++ {
			cand := librarianname.Generate(memberUUID, (bump+b)%poolSize)
			if !taken[cand] {
				log.Printf("fedlib: generated librarian name %q collides with another member — using %q instead; consider setting a real name with --librarian",
					name, cand)
				return cand
			}
		}
		log.Printf("fedlib: generated librarian name %q collides and the middle-name pool is exhausted — keeping it; consider setting a real name with --librarian", name)
		return name
	}
	log.Printf("fedlib: librarian name %q collides with another member's name — keeping it; consider distinct names per member", name)
	return name
}

func buildChildRebuildArgs(p AggregateServeParams) []string {
	args := []string{
		"fedlib", "build", p.ActionAlias,
	}
	// One name: the positional IS the federation id. The fedlib serve's alias
	// names its descriptor (recall fills only unset targets, and every
	// build-relevant flag below is explicit, so recall is inert); a funnel
	// serve's alias names none, which is the explicit-flags path.
	args = append(args,
		"--output-path", p.AggregatePath,
		"--upload-prefix", p.UploadPrefix,
		"--bucket", p.Bucket,
		"--keys-file", p.KeysFile,
		"--s3-provider", p.S3Provider,
		"--s3-endpoint", p.S3Endpoint,
	)
	if !p.AllowFullRebuild {
		args = append(args, "--no-monolithic-rebuild")
	}
	return args
}

func childRebuildEnv(environ []string, p AggregateServeParams) []string {
	env := make([]string, 0, len(environ)+2)
	for _, kv := range environ {
		if strings.HasPrefix(kv, "GOMEMLIMIT=") ||
			strings.HasPrefix(kv, "S3_ACCESS_KEY=") ||
			strings.HasPrefix(kv, "S3_SECRET_KEY=") {
			continue
		}
		env = append(env, kv)
	}
	if p.S3AccessKey != "" {
		env = append(env, "S3_ACCESS_KEY="+p.S3AccessKey)
	}
	if p.S3SecretKey != "" {
		env = append(env, "S3_SECRET_KEY="+p.S3SecretKey)
	}
	return env
}

func runSubprocessBuildWithChanges(ctx context.Context, p AggregateServeParams, membershipChanged bool, transitions ...observedMemberTransition) (spawned bool, err error) {
	exe, err := os.Executable()
	if err != nil {
		return false, fmt.Errorf("rebuild child: resolve executable: %w", err)
	}
	env := childRebuildEnv(os.Environ(), p)
	// The daemon always does a full (splice) recompose — it deliberately does NOT
	// dispatch the incremental fast-path (which would set ACCORDER_CHANGED_MEMBERS).
	// Incremental appends a per-member delta whose tombstones can leave a member
	// transiently double-listed in the served catalog (the "259↔172" flip — the old
	// copy not yet hidden alongside the freshly-appended one), whereas a splice
	// recompose lists every active member exactly once and is always self-consistent.
	// Rebuilds are already single-flight (runGuardedRebuild) + serialized, so "always
	// full" simply makes each serialized rebuild correct rather than racing two
	// strategies that disagree. (The caller logs which members changed.)
	if membershipChanged {
		env = append(env, "ACCORDER_MEMBERSHIP_CHANGED=1")
	}
	args := buildChildRebuildArgs(p)
	if len(transitions) > 0 {
		requestPath, err := writeMemberChangeRequest(filepath.Join(p.AggregatePath, ".accorder"), transitions)
		if err != nil {
			return false, fmt.Errorf("rebuild child: write member change request: %w", err)
		}
		defer os.Remove(requestPath)
		args = append(args, "--member-change-request", requestPath)
	}
	return runChildBuild(ctx, exe, args, env)
}

func runChildBuild(ctx context.Context, exe string, args, env []string) (spawned bool, err error) {
	cmd := exec.CommandContext(ctx, exe, args...)
	cmd.Env = env
	stderr, err := cmd.StderrPipe()
	if err != nil {
		return false, fmt.Errorf("rebuild child: stderr pipe: %w", err)
	}
	cmd.Stdout = io.Discard
	if err := cmd.Start(); err != nil {
		return false, fmt.Errorf("rebuild child: start: %w", err)
	}
	sc := bufio.NewScanner(stderr)
	sc.Buffer(make([]byte, 0, 64*1024), 1<<20)
	for sc.Scan() {
		log.Printf("fedlib rebuild[child %d]: %s", cmd.Process.Pid, sc.Text())
	}
	if scanErr := sc.Err(); scanErr != nil {
		log.Printf("fedlib rebuild[child %d]: log forwarding stopped: %v", cmd.Process.Pid, scanErr)
		_, _ = io.Copy(io.Discard, stderr)
	}
	return true, cmd.Wait()
}

var rebuildInFlight atomic.Bool

func runGuardedRebuild(fn func()) bool {
	if !rebuildInFlight.CompareAndSwap(false, true) {
		return false
	}
	defer rebuildInFlight.Store(false)
	fn()
	return true
}

func inProcessBuildCmd(p AggregateServeParams, bucketFS string) *FedlibBuildCmd {
	buildCmd := &FedlibBuildCmd{
		OutputPath:          p.AggregatePath,
		UploadPrefix:        p.UploadPrefix,
		Bucket:              p.Bucket,
		KeysFile:            p.KeysFile,
		S3AccessKey:         p.S3AccessKey,
		S3SecretKey:         p.S3SecretKey,
		S3Provider:          p.S3Provider,
		S3Endpoint:          p.S3Endpoint,
		SkipRcloneInit:      true,
		ExternalBucket:      bucketFS,
		NoMonolithicRebuild: !p.AllowFullRebuild,
	}
	buildCmd.ActionAlias = p.ActionAlias
	return buildCmd
}

func runInProcessBuild(p AggregateServeParams, bucketFS string, transitions ...observedMemberTransition) error {
	command := inProcessBuildCmd(p, bucketFS)
	command.ObservedMemberTransitions = append([]observedMemberTransition(nil), transitions...)
	return command.Run()
}

func (mpc *memberPollContext) refreshPollSet() {
	registry, _, err := loadMembersRegistryFromPath(mpc.registryPath)
	if err != nil {
		return
	}

	fresh := buildMemberPollSet(registry)
	digest := computeMemberDigest(fresh)
	if mpc.lastMemberDigest != [16]byte{} && digest != mpc.lastMemberDigest {
		mpc.membershipChanged = true
		log.Printf("fedlib share live: membership digest changed — will force full rebuild")
	}
	mpc.lastMemberDigest = digest

	mpc.pollSet = fresh
	for uuid, entry := range fresh {
		mpc.registryPrefixes[uuid] = entry.Prefix
	}

	for uuid := range mpc.healthState {
		if _, exists := fresh[uuid]; !exists {
			delete(mpc.healthState, uuid)
		}
	}
}

func computeMemberDigest(pollSet map[string]memberPollEntry) [16]byte {
	uuids := make([]string, 0, len(pollSet))
	for uuid := range pollSet {
		uuids = append(uuids, uuid)
	}
	sort.Strings(uuids)
	h := sha256.New()
	for _, u := range uuids {
		fmt.Fprintf(h, "%s\x00", u)
	}
	var d [16]byte
	copy(d[:], h.Sum(nil))
	return d
}
