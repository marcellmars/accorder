//go:build !tailscale

package cmd


// Shared test helpers for the effective-config and config-safety suites.
// Kept in their own file with the loosest constraint their users need:
// showConfig_test.go is !tailscale && !tor, but the ca-125/ca-127 suites
// (fedlibShareLiveConfig_test.go, selectedValidation_test.go) are
// !tailscale and must also compile under -tags tor.

import (
	"os"
	"path/filepath"
	"testing"
)

// captureShowConfig runs args (which must include -s) and returns what the
// renderer printed.
func captureShowConfig(t *testing.T, args []string) string {
	t.Helper()
	tmp, err := os.CreateTemp(t.TempDir(), "out")
	if err != nil {
		t.Fatal(err)
	}
	prev := showConfigOut
	showConfigOut = tmp
	defer func() { showConfigOut = prev }()

	_, ctx := parseCLI(t, args)
	if err := ctx.Run(); err != nil {
		t.Fatalf("run %v: %v", args, err)
	}
	showConfigOut = prev
	tmp.Close()
	b, err := os.ReadFile(tmp.Name())
	if err != nil {
		t.Fatal(err)
	}
	return string(b)
}

// snapshotDir records every file path and its bytes, so a later comparison
// proves nothing was created, deleted, or modified.
func snapshotDir(t *testing.T, root string) map[string]string {
	t.Helper()
	out := map[string]string{}
	_ = filepath.Walk(root, func(p string, info os.FileInfo, err error) error {
		if err != nil || info.IsDir() {
			return nil
		}
		b, rerr := os.ReadFile(p)
		if rerr != nil {
			return nil
		}
		out[p] = string(b)
		return nil
	})
	return out
}
