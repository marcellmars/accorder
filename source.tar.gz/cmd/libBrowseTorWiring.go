//go:build tor

package cmd

import (
	"accorder/internal/torclient"
	"accorder/internal/torclientauth"
	"accorder/pkg/torinvite"
	"context"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"time"
)

func init() { browseTorDialFn = torDialBrowse }

func torDialBrowse(inv *torinvite.InviteV2, alias, configDir string) (string, func(), error) {
	authDir := filepath.Join(configDir, "tor", "browse", alias)
	if err := os.MkdirAll(authDir, 0700); err != nil {
		return "", nil, fmt.Errorf("mkdir auth dir: %w", err)
	}
	if inv.Auth != nil {
		if err := torclientauth.WriteAuthPrivateFile(authDir, inv.Onion, inv.Auth.KeyPrivB32); err != nil {
			return "", nil, fmt.Errorf("write auth_private: %w", err)
		}
	}

	log.Println("browse: starting managed Tor...")
	torInst, err := torclient.Spawn(authDir)
	if err != nil {
		return "", nil, err
	}

	bootstrapCtx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
	defer cancel()
	if err := torInst.WaitBootstrap(bootstrapCtx); err != nil {
		torInst.Close()
		return "", nil, fmt.Errorf("tor bootstrap: %w", err)
	}
	log.Println("browse: Tor bootstrapped")

	socksAddr := torInst.SocksAddr()
	cleanup := func() { torInst.Close() }
	return socksAddr, cleanup, nil
}
