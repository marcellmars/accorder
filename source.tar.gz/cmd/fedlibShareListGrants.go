package cmd

import (
	"fmt"
	"os"
	"path/filepath"
	"time"

	"github.com/alecthomas/kong"
)

type FedlibShareListGrantsCmd struct {
	CommonCommandFields
}

func (c *FedlibShareListGrantsCmd) Run(ctx *kong.Context) error {
	if c.HandleShowConfig(c) {
		return nil
	}

	stateDir := filepath.Join(accorderConfigDir, "clearnet", c.ActionAlias)
	reg, err := newGrantRegistry(stateDir)
	if err != nil {
		return fmt.Errorf("fedlib share list-grants: %w", err)
	}

	grants := reg.list()
	if len(grants) == 0 {
		fmt.Fprintln(os.Stderr, "fedlib share list-grants: no grants")
		return nil
	}
	for _, g := range grants {
		status := "active"
		if g.Revoked {
			status = "revoked"
		} else if g.Expires != nil && time.Now().After(*g.Expires) {
			status = "expired"
		}
		exp := "never"
		if g.Expires != nil {
			exp = g.Expires.Format(time.RFC3339)
		}
		fmt.Fprintf(os.Stderr, "%-20s  created=%-25s  expires=%-25s  status=%s\n",
			g.Friend, g.Created.Format(time.RFC3339), exp, status)
	}
	return nil
}
