//go:build !tailscale

package cmd

import (
	"accorder/pkg/calibre"
	"path/filepath"
	"sync"
	"testing"
)

// TestRefreshPollSet_PicksUpNewMember verifies #5: a member invited AFTER the
// poller started is added to the live poll set on the next refresh (no restart).
func TestRefreshPollSet_PicksUpNewMember(t *testing.T) {
	tmp := testSetup(t)
	registryPath := filepath.Join(tmp, "members.json")
	initialPollSet := map[string]memberPollEntry{"uuid-alice": {Prefix: "alice", State: "ready"}}

	// Start with one ready S3 member already tracked.
	if err := saveMembersRegistry(registryPath, map[string]calibre.LibraryMeta{
		"uuid-alice": {Librarian: "Alice", Prefix: "alice", State: "ready"},
	}); err != nil {
		t.Fatal(err)
	}
	mpc := &memberPollContext{
		pollSet:          initialPollSet,
		registryPrefixes: map[string]string{"uuid-alice": "alice"},
		registryPath:     registryPath,
		lastKnownGen:     map[string][24]byte{},
		lastMemberDigest: computeMemberDigest(initialPollSet),
	}

	// Operator invites new members while serving. "invited:bob" is a
	// DELIBERATE legacy fixture (registry written by an older binary);
	// "uuid-dora-invited" is the shape new binaries write
	// (operator-minted-member-uuid). The poll set is key-agnostic, so
	// both must be picked up.
	if err := saveMembersRegistry(registryPath, map[string]calibre.LibraryMeta{
		"uuid-alice":        {Librarian: "Alice", Prefix: "alice", State: "ready"},
		"invited:bob":       {Librarian: "Bob", Prefix: "bob", State: "invited"},
		"uuid-dora-invited": {Librarian: "Dora", Prefix: "dora", State: "invited"},
		"local-carol":       {Librarian: "Carol", Prefix: "carol", Kind: "local", LocalPath: "/x"},
	}); err != nil {
		t.Fatal(err)
	}

	mpc.refreshPollSet()
	if !mpc.membershipChanged {
		t.Error("refreshPollSet did not classify members added before the first refresh as a topology change")
	}

	if _, ok := mpc.pollSet["invited:bob"]; !ok {
		t.Errorf("refreshPollSet did not pick up the legacy invited member; pollSet=%v", mpc.pollSet)
	}
	if mpc.registryPrefixes["invited:bob"] != "bob" {
		t.Errorf("registryPrefixes not updated for new member: %v", mpc.registryPrefixes)
	}
	if entry, ok := mpc.pollSet["uuid-dora-invited"]; !ok {
		t.Errorf("refreshPollSet did not pick up the real-UUID-keyed invited member; pollSet=%v", mpc.pollSet)
	} else if entry.State != "invited" {
		t.Errorf("dora state = %q, want invited", entry.State)
	}
	if mpc.registryPrefixes["uuid-dora-invited"] != "dora" {
		t.Errorf("registryPrefixes not updated for minted invited member: %v", mpc.registryPrefixes)
	}
	if _, ok := mpc.pollSet["local-carol"]; ok {
		t.Error("local member must not be added to the poll set")
	}
	if len(mpc.pollSet) != 3 {
		t.Errorf("pollSet size = %d, want 3 (alice + bob + dora)", len(mpc.pollSet))
	}
}

// TestRefreshPollSet_SkipsReconciledPrefix verifies refresh does not re-add a
// prefix already tracked under another (reconciled) UUID.
func TestRefreshPollSet_SkipsReconciledPrefix(t *testing.T) {
	tmp := testSetup(t)
	registryPath := filepath.Join(tmp, "members.json")
	// Registry has the reconciled (real UUID, ready) entry.
	if err := saveMembersRegistry(registryPath, map[string]calibre.LibraryMeta{
		"real-uuid-bob": {Librarian: "Bob", Prefix: "bob", State: "ready"},
	}); err != nil {
		t.Fatal(err)
	}
	mpc := &memberPollContext{
		pollSet:          map[string]memberPollEntry{"real-uuid-bob": {Prefix: "bob", State: "ready"}},
		registryPrefixes: map[string]string{"real-uuid-bob": "bob"},
		registryPath:     registryPath,
		lastKnownGen:     map[string][24]byte{},
	}
	mpc.refreshPollSet()
	if len(mpc.pollSet) != 1 {
		t.Errorf("pollSet size = %d, want 1 (no duplicate for prefix bob)", len(mpc.pollSet))
	}
}

// TestSaveMembersRegistry_AtomicUnderConcurrency verifies #6: concurrent readers
// never observe a half-written registry (atomic temp+rename). Before the fix this
// raced (~5% corrupt reads with os.WriteFile).
func TestSaveMembersRegistry_AtomicUnderConcurrency(t *testing.T) {
	tmp := testSetup(t)
	registryPath := filepath.Join(tmp, "members.json")
	base := map[string]calibre.LibraryMeta{"uuid-a": {Librarian: "A", Prefix: "a", State: "ready"}}
	if err := saveMembersRegistry(registryPath, base); err != nil {
		t.Fatal(err)
	}

	var wg sync.WaitGroup
	var readErrs int
	var mu sync.Mutex

	// 10 writers
	for i := 0; i < 10; i++ {
		wg.Add(1)
		go func(n int) {
			defer wg.Done()
			reg := map[string]calibre.LibraryMeta{
				"uuid-a":                          {Librarian: "A", Prefix: "a", State: "ready"},
				"invited:p" + string(rune('0'+n)): {Librarian: "P", Prefix: "p", State: "invited"},
			}
			_ = saveMembersRegistry(registryPath, reg)
		}(i)
	}
	// 100 readers
	for i := 0; i < 100; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			if _, _, err := loadMembersRegistryFromPath(registryPath); err != nil {
				mu.Lock()
				readErrs++
				mu.Unlock()
			}
		}()
	}
	wg.Wait()

	if readErrs != 0 {
		t.Errorf("atomic write violated: %d/100 concurrent reads saw a corrupt/half-written registry", readErrs)
	}
	// Final state is valid JSON.
	if _, _, err := loadMembersRegistryFromPath(registryPath); err != nil {
		t.Fatalf("final registry not loadable: %v", err)
	}
}
