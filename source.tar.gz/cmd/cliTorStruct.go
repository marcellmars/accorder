//go:build tor && !tailscale

package cmd

type CLI struct {
	Globals
	Lib struct {
		Build  LibBuildCmd  `cmd:"" help:"Build a library into a static browse site + search index." group:"lib" json:"build"`
		Import LibImportCmd `cmd:"" help:"Sync a Calibre library from a Zotero BetterBibTeX export (add/update; --prune removes)." group:"lib" json:"import"`
		Search LibSearchCmd `cmd:"" help:"Search a library index." group:"lib" json:"search"`
		Index  struct {
			Info      LibIndexInfoCmd      `cmd:"" help:"Inspect a search index." group:"lib" json:"info"`
			Download  LibIndexDownloadCmd  `cmd:"" help:"Fetch and cache a remote search index." group:"lib" json:"download"`
			Recompile LibIndexRecompileCmd `cmd:"" help:"Recompile a cached index with additional fields." json:"recompile"`
			List      LibIndexListCmd      `cmd:"" help:"List registered source libraries." json:"list"`
			Add       LibIndexAddCmd       `cmd:"" help:"Register a source library." json:"add"`
			Rename    LibIndexRenameCmd    `cmd:"" help:"Rename a registered source." json:"rename"`
			Remove    LibIndexRemoveCmd    `cmd:"" help:"Remove a registered source." json:"remove"`
		} `cmd:"" help:"Manage search indexes." json:"index"`
		Share struct {
			Live        LibShareLiveCmd           `cmd:"" help:"Share library via Tor onion + HTTP." group:"lib" json:"live"`
			Address     LibShareAddressCmd        `cmd:"" help:"Re-print the onion address(es) for an alias." group:"lib" json:"address"`
			GrantTor    LibShareGrantCmd          `cmd:"grant-tor" help:"Grant a friend access via the Tor onion." group:"lib" json:"grant-tor"`
			Grant       LibShareGrantClearnetCmd  `cmd:"grant" help:"Issue a clearnet (HTTP) browse invite for a friend." group:"lib" json:"grant"`
			RevokeGrant LibShareRevokeClearnetCmd `cmd:"revoke-grant" help:"Revoke grants for a friend." group:"lib" json:"revoke-grant"`
			ListGrants  LibShareListGrantsCmd     `cmd:"list-grants" help:"List clearnet grants." group:"lib" json:"list-grants"`
			ResetGrants LibShareResetGrantsCmd    `cmd:"reset-grants" help:"Rotate signing key and invalidate all grants." group:"lib" json:"reset-grants"`
		} `cmd:"" help:"Share the library." json:"share"`
		Browse   LibBrowseCmd   `cmd:"" help:"Browse a friend's shared library." group:"lib" json:"browse"`
		Upload   LibUploadCmd   `cmd:"" help:"Upload library files to cloud storage, building first when needed." group:"lib" json:"upload"`
		Download LibDownloadCmd `cmd:"" help:"Download library files (e.g. metadata.db) from cloud storage." group:"lib" json:"download"`
		Publish  LibPublishCmd  `cmd:"" help:"Build + upload (shortcut)." group:"lib" json:"publish"`
		Join     LibJoinCmd     `cmd:"" help:"Join a federation using an invite blob." group:"lib" json:"join"`
		Status   LibStatusCmd   `cmd:"" help:"Show local, remote, and writer-seat state." group:"lib" json:"status"`
		Sync     LibSyncCmd     `cmd:"" help:"Safely pull a newer published library snapshot." group:"lib" json:"sync"`
		Seat     LibSeatCmd     `cmd:"" help:"Show or transfer the active writer seat." group:"lib" json:"seat"`
	} `cmd:"" help:"Work with a single library." json:"lib"`
	Fedlib struct {
		Build   FedlibBuildCmd   `cmd:"" help:"Build the federated aggregate index." group:"fedlib" json:"build"`
		Members FedlibMembersCmd `cmd:"" help:"Manage federation membership." group:"fedlib" json:"members"`
		Invites FedlibInvitesCmd `cmd:"" help:"Manage claim-once invite offers." group:"fedlib" json:"invites"`
		Config  FedlibConfigCmd  `cmd:"" help:"Manage federation descriptors." group:"fedlib" json:"config"`
		Share   struct {
			Live        FedlibShareLiveCmd           `cmd:"" help:"Serve the aggregate over HTTP + Tor." group:"fedlib" json:"live"`
			GrantTor    FedlibShareGrantCmd          `cmd:"grant-tor" help:"Grant a friend access via the Tor onion." group:"fedlib" json:"grant-tor"`
			Grant       FedlibShareGrantClearnetCmd  `cmd:"grant" help:"Issue a clearnet (HTTP) browse invite for a friend." group:"fedlib" json:"grant"`
			RevokeGrant FedlibShareRevokeClearnetCmd `cmd:"revoke-grant" help:"Revoke grants for a friend." group:"fedlib" json:"revoke-grant"`
			ListGrants  FedlibShareListGrantsCmd     `cmd:"list-grants" help:"List clearnet grants." group:"fedlib" json:"list-grants"`
			ResetGrants FedlibShareResetGrantsCmd    `cmd:"reset-grants" help:"Rotate signing key and invalidate all grants." group:"fedlib" json:"reset-grants"`
		} `cmd:"" help:"Share the federation." json:"share"`
		Service FedlibServiceCmd `cmd:"" help:"Manage the systemd unit that runs this federation's serve." group:"fedlib" json:"service"`
		Backup  FedlibBackupCmd  `cmd:"" help:"Back up identity and credential files — everything in the accorder config dir except caches, backups, logs, and locks." group:"fedlib" json:"backup"`
		Restore FedlibRestoreCmd `cmd:"" help:"Restore federation identity files from a backup tarball." group:"fedlib" json:"restore"`
	} `cmd:"" help:"Work with the federation." json:"fedlib"`
	Doctor  DoctorCmd  `cmd:"" help:"Check this instance: version, serve readiness, cache vs cap, config rot, backup age. Works over --on; --wait blocks until the serve is ready." json:"doctor"`
	Secrets SecretsCmd `cmd:"" help:"Manage the local encrypted secrets store." json:"secrets"`
	Config  AliasesCmd `cmd:"" aliases:"aliases" help:"List and manage saved action aliases (stored in action_aliases.json)."`
}
