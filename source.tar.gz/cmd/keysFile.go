package cmd

import (
	"fmt"
	"log"
	"os"
	"path/filepath"
	"reflect"
	"strings"

	"github.com/tidwall/gjson"
	"github.com/tidwall/sjson"
)

type s3KeysFile struct {
	AccessKey string
	SecretKey string
	Provider  string
	Endpoint  string
	Bucket    string
	Prefix    string
}

func defaultKeysFilePath(alias string) string {
	return filepath.Join(accorderConfigDir, "keys", alias+".s3.keys")
}

func parseKeysFile(path string) (s3KeysFile, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return s3KeysFile{}, err
	}
	var kf s3KeysFile
	for _, line := range strings.Split(string(data), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		key, value, found := strings.Cut(line, "=")
		if !found {
			continue
		}
		key = strings.TrimSpace(key)
		value = strings.TrimSpace(value)
		switch key {
		case "access-key":
			kf.AccessKey = value
		case "secret-key":
			kf.SecretKey = value
		case "provider":
			kf.Provider = value
		case "endpoint":
			kf.Endpoint = value
		case "bucket":
			kf.Bucket = value
		case "prefix", "s3-prefix":
			kf.Prefix = value
		}
	}
	return kf, nil
}

func writeKeysFile(path string, kf s3KeysFile) error {
	if err := os.MkdirAll(filepath.Dir(path), 0o700); err != nil {
		return fmt.Errorf("create keys dir: %w", err)
	}
	var b strings.Builder
	write := func(key, value string) {
		if value != "" {
			fmt.Fprintf(&b, "%s=%s\n", key, value)
		}
	}
	write("access-key", kf.AccessKey)
	write("secret-key", kf.SecretKey)
	write("provider", kf.Provider)
	write("endpoint", kf.Endpoint)
	write("bucket", kf.Bucket)
	write("prefix", kf.Prefix)
	tmp := path + ".tmp"
	if err := os.WriteFile(tmp, []byte(b.String()), 0o600); err != nil {
		return fmt.Errorf("write keys-file: %w", err)
	}
	if err := os.Rename(tmp, path); err != nil {
		return fmt.Errorf("write keys-file: %w", err)
	}
	return nil
}

func mergedKeysFile(target reflect.Value) string {
	if target.Kind() == reflect.Ptr {
		target = target.Elem()
	}
	return fieldStringValue(target, "KeysFile")
}

func resolveOperatorS3Creds(target reflect.Value, alias string, providedFlags map[string]struct{}, rcs ...*resolveCtx) {
	rc := resolveCtxOf(rcs)
	if target.Kind() == reflect.Ptr {
		target = target.Elem()
	}

	for _, e := range []struct{ field, env string }{
		{"S3AccessKey", "S3_ACCESS_KEY"},
		{"S3SecretKey", "S3_SECRET_KEY"},
	} {
		if fieldStringValue(target, e.field) == "" {
			if v := os.Getenv(e.env); v != "" {
				setFieldString(target, e.field, v)
				// Not a kong env: tag — kong never sees this, so the
				// renderer would report "default" without this stamp.
				rc.prov.StampField(target, e.field, OriginEnv, e.env)
			}
		}
	}

	keysPath := fieldStringValue(target, "KeysFile")
	// Under credentialOnly a non-empty KeysFile came from the descriptor
	// snapshot (ca-125), naming an operator-managed file possibly shared
	// with fedlib build. Explicit creds must never rewrite it (see below).
	descriptorSelected := rc.credentialOnly && keysPath != ""
	if keysPath == "" {
		keysPath = defaultKeysFilePath(alias)
	} else if rc.credentialOnly && !filepath.IsAbs(keysPath) {
		// A descriptor-selected keys path is config-dir-relative (matching
		// ResolveEffective), not CWD-relative like an explicit flag.
		keysPath = filepath.Join(accorderConfigDir, keysPath)
	}

	credProvided := false
	for _, flag := range []string{"s3-access-key", "s3-secret-key", "s3-provider", "s3-endpoint"} {
		if _, ok := providedFlags[flag]; ok {
			credProvided = true
			break
		}
	}

	var fileBucket, filePrefix, fileProvider, fileEndpoint string
	if kf, err := parseKeysFile(keysPath); err == nil {
		fileBucket, filePrefix = kf.Bucket, kf.Prefix
		fileProvider, fileEndpoint = kf.Provider, kf.Endpoint
		resolved := 0
		fills := []struct{ field, value string }{
			{"S3AccessKey", kf.AccessKey},
			{"S3SecretKey", kf.SecretKey},
		}
		if !rc.credentialOnly {
			fills = append(fills, []struct{ field, value string }{
				{"S3Provider", kf.Provider},
				{"S3Endpoint", kf.Endpoint},
				{"Bucket", kf.Bucket},
				{"S3Prefix", kf.Prefix},
			}...)
		}
		for _, f := range fills {
			if f.value == "" || fieldStringValue(target, f.field) != "" {
				continue
			}
			setFieldString(target, f.field, f.value)
			rc.prov.StampField(target, f.field, OriginKeysFile, keysPath)
			resolved++
		}
		if resolved > 0 {
			log.Printf("[B1] keys-file: resolved %d S3 field(s) for alias %q from %s", resolved, alias, keysPath)
		}
	} else if rc.credentialOnly && fieldStringValue(target, "KeysFile") != "" {
		// ca-131: the descriptor-selected keys path is the only keys path
		// live serve reads — no fallback to the default migration path.
		// Failing to read it (including "missing") must be loud, or the
		// serve later dies at RequireS3Creds without naming the file it
		// needed.
		log.Printf("[B1] WARNING: descriptor-selected keys-file %s unreadable (%v) — live serve reads no other keys path; provide credentials via flags, S3_ACCESS_KEY/S3_SECRET_KEY, or the secrets store, or fix the descriptor's keys_file", keysPath, err)
	} else if !os.IsNotExist(err) {
		log.Printf("[B1] keys-file %s: %v", keysPath, err)
	}

	if credProvided && !rc.readOnly {
		if descriptorSelected {
			// Never truncate-and-rewrite the descriptor-selected keys file:
			// it may hold the federation's write credentials (read by fedlib
			// build), and this caller's explicit pair may be narrower
			// (read-only serve creds). Explicit creds apply to this
			// invocation only.
			log.Printf("[B1] explicit S3 credentials used for this run only — not saved to descriptor-selected keys file %s (edit that file or the secrets store to change persistent credentials)", keysPath)
		} else {
			// Round-trip file-held fields the target may not carry: under
			// credentialOnly the provider/endpoint fills above were skipped
			// (identity is descriptor-owned), so writing the target's values
			// alone would silently strip provider=/endpoint= from a keys
			// file that fedlib build also reads.
			out := s3KeysFile{
				AccessKey: fieldStringValue(target, "S3AccessKey"),
				SecretKey: fieldStringValue(target, "S3SecretKey"),
				Provider:  firstNonEmpty(fieldStringValue(target, "S3Provider"), fileProvider),
				Endpoint:  firstNonEmpty(fieldStringValue(target, "S3Endpoint"), fileEndpoint),
				Bucket:    fileBucket,
				Prefix:    filePrefix,
			}
			if err := writeKeysFile(keysPath, out); err != nil {
				log.Printf("[B1] save keys-file %s: %v", keysPath, err)
			} else {
				log.Printf("[B1] saved S3 credentials to %s (credentials never persist in action_aliases.json)", keysPath)
			}
		}
	}

	_, bucketExplicit := providedFlags["bucket"]
	if fieldStringValue(target, "S3AccessKey") == "" || fieldStringValue(target, "S3SecretKey") == "" {
		resolveS3CredsFromSecretsStore(target, alias, bucketExplicit, rc)
	}

	if rc.credentialOnly {
		// The bucket is descriptor-owned here, not alias-stored; the
		// scoping warning below does not apply.
		return
	}
	bucket := fieldStringValue(target, "Bucket")
	if !bucketExplicit && bucket != "" && !isScopedBucket(bucket) {
		log.Printf("[pq-21] WARNING: alias-stored bucket %q has no prefix and --bucket was not provided — operations target the bucket root; pass --bucket=%s/<prefix> to scope it", bucket, bucket)
	}
}

var aliasCredKeys = []string{"s3-access-key", "s3-secret-key", "s3-provider", "s3-endpoint"}

func migrateAliasCredentials(configBytes *[]byte) bool {
	type aliasCreds struct {
		kf    s3KeysFile
		paths []string
	}
	found := make(map[string]*aliasCreds)

	root := gjson.ParseBytes(*configBytes)
	root.ForEach(func(aliasKey, aliasVal gjson.Result) bool {
		alias := aliasKey.String()
		var walk func(prefix string, v gjson.Result)
		walk = func(prefix string, v gjson.Result) {
			v.ForEach(func(k, val gjson.Result) bool {
				p := prefix + "." + k.String()
				switch {
				case val.Type == gjson.String && isAliasCredKey(k.String()):
					ac := found[alias]
					if ac == nil {
						ac = &aliasCreds{}
						found[alias] = ac
					}
					switch k.String() {
					case "s3-access-key":
						ac.kf.AccessKey = val.String()
					case "s3-secret-key":
						ac.kf.SecretKey = val.String()
					case "s3-provider":
						ac.kf.Provider = val.String()
					case "s3-endpoint":
						ac.kf.Endpoint = val.String()
					}
					ac.paths = append(ac.paths, p)
				case val.IsObject():
					walk(p, val)
				}
				return true
			})
		}
		if aliasVal.IsObject() {
			walk(alias, aliasVal)
		}
		return true
	})

	if len(found) == 0 {
		return false
	}

	migrated := false
	for alias, ac := range found {
		keysPath := defaultKeysFilePath(alias)
		if _, err := os.Stat(keysPath); os.IsNotExist(err) {
			if err := writeKeysFile(keysPath, ac.kf); err != nil {
				log.Printf("[B1] migration: preserve credentials for alias %q failed (%v) — leaving alias file untouched", alias, err)
				continue
			}
		} else if err != nil {
			// A stat failure that is not "missing" (unreadable dir, a file
			// where the keys dir should be) proves nothing about whether
			// the credentials were preserved — deleting the raw keys here
			// would be the only copy lost. Fail closed: leave the alias
			// untouched.
			log.Printf("[B1] migration: cannot stat %s (%v) — leaving alias %q untouched", keysPath, err, alias)
			continue
		}
		for _, p := range ac.paths {
			*configBytes, _ = sjson.DeleteBytes(*configBytes, p)
		}
		migrated = true
		log.Printf("[B1] MIGRATION: S3 credentials for alias %q moved out of action_aliases.json into %s (plaintext, 0600). Operator commands read it automatically; librarian commands use the encrypted secrets store (lib join / ACCORDER_SECRETS_PASSPHRASE).", alias, keysPath)
	}
	if migrated {
		saveActionAliases(*configBytes)
	}
	return migrated
}

func isAliasCredKey(key string) bool {
	for _, k := range aliasCredKeys {
		if key == k {
			return true
		}
	}
	return false
}
