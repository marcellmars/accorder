//go:build !tailscale

package cmd

import (
	"io/fs"
	"os"
	"path/filepath"
	"reflect"
	"sort"
	"strings"
	"testing"

	"accorder/pkg/libraryflow"
)

func TestParallelInventoryMatchesWalkDir(t *testing.T) {
	root := t.TempDir()
	for _, rel := range []string{"metadata.db", "Author/Book (1)/book.epub", "Author/Book (1)/cover.jpg", "Other/Nested/Book (2)/book.pdf", "static/catalog.jsonl", ".accorder/state"} {
		writeTestFile(t, root, rel, rel)
	}
	var want []libraryflow.Object
	err := filepath.WalkDir(root, func(path string, entry fs.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if entry.IsDir() {
			return nil
		}
		info, err := entry.Info()
		if err != nil {
			return err
		}
		rel, err := filepath.Rel(root, path)
		if err != nil {
			return err
		}
		want = append(want, libraryflow.NewLocalObjectAt(filepath.ToSlash(rel), path, info))
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
	sort.Slice(want, func(i, j int) bool { return want[i].Path < want[j].Path })
	for _, workers := range []int{1, 2, 16} {
		got, err := parallelLocalObjects(root, workers)
		if err != nil || !reflect.DeepEqual(got, want) {
			t.Fatalf("workers=%d: got=%+v want=%+v err=%v", workers, got, want, err)
		}
	}
	if _, err := parallelLocalObjects(filepath.Join(root, "missing"), 16); !os.IsNotExist(err) {
		t.Fatalf("missing root: %v", err)
	}
	if _, err := parallelLocalObjects(root, 0); err == nil {
		t.Fatal("zero workers accepted")
	}
}

// Kept separate from native Windows command roots: creating a symlink can
// require privileges, while the acceptance inventory oracle itself cannot skip.
func TestParallelInventoryRejectsSymlinks(t *testing.T) {
	root := t.TempDir()
	target := t.TempDir()
	writeTestFile(t, target, "outside.epub", "outside")
	if err := os.Symlink(target, filepath.Join(root, "hidden")); err != nil {
		t.Skipf("symlink creation unavailable: %v", err)
	}
	if objects, err := parallelLocalObjects(root, 16); err == nil || !strings.Contains(err.Error(), "refusing symlink") || objects != nil {
		t.Fatalf("symlink inventory: objects=%+v err=%v", objects, err)
	}
}
