//go:build !tailscale

package cmd

import (
	"os"
	"path/filepath"
	"reflect"
	"sync"
	"testing"
	"time"

	"accorder/pkg/libraryflow"
)

// Apply the same unavailable-capability injection to direct probes and the
// consolidated scan. Optimization must not bypass refusal regression tests.
func withoutSourceCapability(t *testing.T, matches func(string) bool) {
	t.Helper()
	probe, observe := sourceLocalFileEvidence, sourceObserveLocalObject
	sourceLocalFileEvidence = func(path string) (string, string) {
		id, capability := probe(path)
		if matches(path) {
			capability = ""
		}
		return id, capability
	}
	sourceObserveLocalObject = func(rel, path string, info os.FileInfo) (libraryflow.Object, string, string) {
		object, id, capability := observe(rel, path, info)
		if matches(path) {
			capability = ""
		}
		return object, id, capability
	}
	t.Cleanup(func() { sourceLocalFileEvidence, sourceObserveLocalObject = probe, observe })
}

func TestSourceObservationMatchesSeparateEvidence(t *testing.T) {
	root := testSetup(t)
	seedPublishCalibreLibrary(t, root)
	installation, err := loadOrCreateInstallation()
	if err != nil {
		t.Fatal(err)
	}
	inventory, err := parallelInventory(root, 16, true)
	if err != nil {
		t.Fatal(err)
	}
	oldLedger, oldEvidence, oldChanged, oldRemoved, err := buildSourceEvidence(root, inventory.Objects, nil, nil, nil, installation.SeatID)
	if err != nil {
		t.Fatal(err)
	}
	ledger, evidence, changed, removed, err := buildSourceEvidence(root, inventory.Objects, nil, nil, nil, installation.SeatID, inventory)
	if err != nil || !reflect.DeepEqual(ledger, oldLedger) || !reflect.DeepEqual(evidence, oldEvidence) || !reflect.DeepEqual(changed, oldChanged) || !reflect.DeepEqual(removed, oldRemoved) {
		t.Fatalf("combined observation differs from separate probes: %v", err)
	}
	// No root's capability can substitute for a failed file observation.
	file := inventory.Files[fastBuildPayload]
	file.Evidence.Capability = ""
	inventory.Files[fastBuildPayload] = file
	ledger, evidence, _, _, err = buildSourceEvidence(root, inventory.Objects, nil, nil, nil, installation.SeatID, inventory)
	if err != nil {
		t.Fatal(err)
	}
	if err := requireSourceCoherence(root, ledger, evidence); err == nil {
		t.Fatal("missing per-file capability accepted")
	}
	other := t.TempDir()
	if _, _, _, _, err := buildSourceEvidence(other, inventory.Objects, nil, nil, nil, installation.SeatID, inventory); err == nil {
		t.Fatal("cross-root observation accepted")
	}
	objects := append([]libraryflow.Object(nil), inventory.Objects...)
	objects[0].Size++
	if _, _, _, _, err := buildSourceEvidence(root, objects, nil, nil, nil, installation.SeatID, inventory); err == nil {
		t.Fatal("mismatched observation accepted")
	}
}

func TestSourceObservationDoesNotCrossValidationBoundary(t *testing.T) {
	root := testSetup(t)
	seedPublishCalibreLibrary(t, root)
	build := fastBuildCommand(root)
	if err := build.Run(nil); err != nil {
		t.Fatal(err)
	}
	candidate, err := captureExistingCandidate(root, resolveUploadExcludes(root, nil))
	if err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(root, fastBuildPayload)
	info, err := os.Stat(path)
	if err != nil {
		t.Fatal(err)
	}
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	data[0] ^= 1
	if err := os.WriteFile(path, data, 0o644); err != nil {
		t.Fatal(err)
	}
	if err := os.Chtimes(path, info.ModTime(), info.ModTime()); err != nil {
		t.Fatal(err)
	}
	fastBuildCalibreEdit(t, root, 1)
	if err := verifyLocalPublishCandidate(candidate); err == nil {
		t.Fatal("fresh validation reused pre-edit observation")
	}
}

func countLibraryScans(t *testing.T, run func() error) map[string]int {
	t.Helper()
	var mu sync.Mutex
	counts := map[string]int{}
	old := libraryWorkObserver
	libraryWorkObserver = func(stage string, _ time.Duration, _ int) { mu.Lock(); counts[stage]++; mu.Unlock() }
	defer func() { libraryWorkObserver = old }()
	if err := run(); err != nil {
		t.Fatal(err)
	}
	return counts
}

func TestSourceObservationCommandScanBudget(t *testing.T) {
	root := testSetup(t)
	seedPublishCalibreLibrary(t, root)
	build := fastBuildCommand(root)
	for _, label := range []string{"first", "unchanged"} {
		counts := countLibraryScans(t, func() error { return build.Run(nil) })
		wantDatabase := 0
		if label == "first" {
			wantDatabase = 1
		}
		if counts["inventory"] != 0 || counts["database-inventory"] != wantDatabase || counts["checkpoint-load"] != 1 {
			t.Fatalf("%s build scans: %v", label, counts)
		}
	}
	upload := &LibUploadCmd{GroupLib: build.GroupLib}
	upload.ActionAlias = build.ActionAlias
	counts := countLibraryScans(t, func() error {
		_, _, err := upload.prepareUploadCandidate(nil, resolveUploadExcludes(root, nil))
		return err
	})
	if counts["inventory"] != 0 || counts["checkpoint-load"] != 1 {
		t.Fatalf("current upload preparation scans: %v", counts)
	}
	command := &LibPublishCmd{GroupLib: build.GroupLib}
	command.ActionAlias = build.ActionAlias
	counts = countLibraryScans(t, func() error { _, err := buildPublishCandidate(nil, command); return err })
	if counts["inventory"] != 0 || counts["candidate-attachment"] != 1 {
		t.Fatalf("publish preparation scans: %v", counts)
	}
	command.DryRun = true
	counts = countLibraryScans(t, func() error { _, err := buildPublishCandidate(nil, command); return err })
	if counts["inventory"] != 0 || counts["build-command"] != 0 {
		t.Fatalf("preview scans: %v", counts)
	}
	// A changed upload still builds automatically, retaining the initial
	// stale-candidate check, build before/after checks and the final handoff.
	fastBuildSQL(t, root, "UPDATE books SET title='Changed title' WHERE id=1")
	counts = countLibraryScans(t, func() error {
		_, _, err := upload.prepareUploadCandidate(nil, resolveUploadExcludes(root, nil))
		return err
	})
	if counts["inventory"] != 0 || counts["build-command"] != 1 {
		t.Fatalf("automatic build scan budget: %v", counts)
	}
}

func TestSourceObservationLegacyCaptureUsesSingleInventory(t *testing.T) {
	root := testSetup(t)
	writeTestFile(t, root, "metadata.db", "legacy external catalog")
	excludes := []string{"/Private/**"}
	writeTestFile(t, root, "Private/skip.epub", "private")
	want, _, err := libraryflow.SourceFingerprint(root, excludes)
	if err != nil {
		t.Fatal(err)
	}
	counts := countLibraryScans(t, func() error {
		candidate, err := captureExistingCandidate(root, excludes)
		if err == nil && (candidate.SourceFingerprint != want || candidate.Change != nil) {
			t.Fatalf("legacy fingerprint/eligibility changed: %+v", candidate)
		}
		return err
	})
	if counts["inventory"] != 1 {
		t.Fatalf("legacy capture scans: %v", counts)
	}
}

func TestSourceObservationPublicPublishRetainsFinalChecks(t *testing.T) {
	root := testSetup(t)
	seedPublishCalibreLibrary(t, root)
	withLocalCommandRemote(t, t.TempDir())
	build := fastBuildCommand(root)
	command := &LibPublishCmd{GroupLib: build.GroupLib, MaxDeletes: 25}
	command.ActionAlias = build.ActionAlias
	counts := countLibraryScans(t, func() error { return command.Run(nil) })
	t.Logf("full public publish scan/phase counts: %v", counts)
	// Check before transfer, after transfer and before activation. Preview and
	// private cleanup have their own boundaries; this ordinary publish does not.
	if counts["publish-coherence"] != 3 || counts["inventory"] != 0 {
		t.Fatalf("publication dropped or duplicated an independent scan: %v", counts)
	}
}
