package cmd

// Build-generic test helpers shared across all build variants (cq-41).
// Deliberately unconstrained: the tor- and tailscale-tagged cmd suites
// must compile too, and these helpers reference only symbols every
// variant defines — including CLI{}, which each build-tag struct file
// declares under the same name.

import (
	"accorder/pkg/secrets"
	"io"
	"os"
	"path/filepath"
	"reflect"
	"testing"

	"github.com/alecthomas/kong"
	"github.com/tidwall/gjson"
)

// testSetup creates a temp directory for alias persistence and initializes
// the validator. Returns the temp dir path for use as calibrepath.
func testSetup(t *testing.T) string {
	t.Helper()
	tmpDir := t.TempDir()
	// Clear any inherited passphrase so secrets-store mode selection is
	// deterministic: without this, a developer with ACCORDER_SECRETS_PASSPHRASE
	// exported silently pushes every test onto age's scrypt path (~9s per store
	// operation under -race). Tests that mean to exercise passphrase mode set it
	// explicitly on the command struct instead.
	t.Setenv("ACCORDER_SECRETS_PASSPHRASE", "")
	savedActionAliases = filepath.Join(tmpDir, "action_aliases.json")
	sourceRegistryPath = filepath.Join(tmpDir, "indices.json")
	accorderConfigDir = tmpDir
	_ = os.WriteFile(savedActionAliases, []byte("{}"), 0644)
	validate = nil
	initValidator()

	// Clear shared group cache between tests.
	sharedGroupCache = make(map[reflect.Type]map[string]struct{})

	// Create a subdirectory to use as a valid calibre library path.
	libDir := filepath.Join(tmpDir, "testlib")
	_ = os.MkdirAll(libDir, 0755)
	return libDir
}

// testSecretsStore returns a key-file-backed secrets store for the isolated
// config dir, generating the X25519 key if absent, and clears any inherited
// ACCORDER_SECRETS_PASSPHRASE so mode selection is deterministic.
//
// Prefer this over secrets.NewStore(path, passphrase) in tests that merely need
// *a* working store. Passphrase mode runs age's scrypt KDF at its default work
// factor (logN=18) on EVERY load and save — Store.Get decrypts the whole file
// per call — which costs ~9s per operation under -race and is what makes the
// cmd package exceed its test timeout (cq-36). Key-file mode is X25519: no KDF.
//
// Use an explicit passphrase only in tests that exercise passphrase behaviour
// itself (secretsKeyB4_test.go, and the reinvite stderr-placeholder assertion).
func testSecretsStore(t *testing.T) *secrets.Store {
	t.Helper()
	t.Setenv("ACCORDER_SECRETS_PASSPHRASE", "")
	id, err := loadOrGenerateSecretsKey(true)
	if err != nil {
		t.Fatalf("testSecretsStore: generate secrets key: %v", err)
	}
	return secrets.NewStoreWithIdentity(filepath.Join(accorderConfigDir, "secrets.age"), id)
}

// parseCLI creates a fresh CLI, parses args. Kong automatically calls
// AfterApply during Parse since CLI implements the AfterApply interface.
func parseCLI(t *testing.T, args []string) (*CLI, *kong.Context) {
	t.Helper()
	cli := &CLI{}
	app, err := kong.New(cli,
		kong.Name("test"),
		kong.Exit(func(int) {}),
		kong.Bind(cli),
	)
	if err != nil {
		t.Fatalf("kong.New: %v", err)
	}
	ctx, err := app.Parse(args)
	if err != nil {
		t.Fatalf("kong.Parse(%v): %v", args, err)
	}
	return cli, ctx
}

// readAlias reads a specific alias from the config file.
func readAlias(t *testing.T, alias string) gjson.Result {
	t.Helper()
	data, err := os.ReadFile(savedActionAliases)
	if err != nil {
		t.Fatalf("read aliases: %v", err)
	}
	return gjson.GetBytes(data, alias)
}

func parseCLIErr(t *testing.T, args []string) (*CLI, *kong.Context, error) {
	t.Helper()
	cli := &CLI{}
	app, err := kong.New(cli,
		kong.Name("test"),
		kong.Exit(func(int) {}),
		kong.Bind(cli),
	)
	if err != nil {
		t.Fatalf("kong.New: %v", err)
	}
	ctx, err := app.Parse(args)
	return cli, ctx, err
}

// captureInviteOutput runs fn with os.Stdout/os.Stderr redirected to
// pipes and returns what was written to each.
func captureInviteOutput(t *testing.T, fn func() error) (stdout, stderr string, err error) {
	t.Helper()
	oldOut, oldErr := os.Stdout, os.Stderr
	rOut, wOut, pipeErr := os.Pipe()
	if pipeErr != nil {
		t.Fatalf("pipe: %v", pipeErr)
	}
	rErr, wErr, pipeErr := os.Pipe()
	if pipeErr != nil {
		t.Fatalf("pipe: %v", pipeErr)
	}
	os.Stdout, os.Stderr = wOut, wErr
	defer func() { os.Stdout, os.Stderr = oldOut, oldErr }()
	err = fn()
	wOut.Close()
	wErr.Close()
	outBytes, _ := io.ReadAll(rOut)
	errBytes, _ := io.ReadAll(rErr)
	return string(outBytes), string(errBytes), err
}

func ptrTo[T any](v T) *T { return &v }

func captureStdout(t *testing.T, fn func()) string {
	t.Helper()
	old := os.Stdout
	r, w, err := os.Pipe()
	if err != nil {
		t.Fatalf("pipe: %v", err)
	}
	os.Stdout = w
	defer func() { os.Stdout = old }()
	fn()
	_ = w.Close()
	out, _ := io.ReadAll(r)
	return string(out)
}

func reinviteCmd(label, prefix, fedlibPath string) *FedlibMembersInviteCmd {
	return &FedlibMembersInviteCmd{
		Label:       label,
		Prefix:      prefix,
		FedlibID:    "fed-1",
		S3AccessKey: "AK",
		S3SecretKey: "SK",
		S3Provider:  "Wasabi",
		S3Endpoint:  "https://s3.test",
		Bucket:      "motw",
		FedlibPath:  fedlibPath,
	}
}
