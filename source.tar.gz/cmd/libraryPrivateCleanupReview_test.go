//go:build !tailscale

package cmd

import (
	"bytes"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"accorder/pkg/calibre"
	"accorder/pkg/libraryflow"
	"accorder/pkg/torshare"
	"github.com/rclone/rclone/fs/filter"
)

func interruptPrivateCleanup(t *testing.T, candidate *libraryCandidate) {
	t.Helper()
	stopped := errors.New("interrupt after first private deletion")
	publishCommitStageHook = func(stage string) error {
		if stage == "after-private-delete" {
			return stopped
		}
		return nil
	}
	t.Cleanup(func() { publishCommitStageHook = nil })
	err := publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: 25})
	publishCommitStageHook = nil
	if !errors.Is(err, stopped) {
		t.Fatalf("did not interrupt private cleanup: %v", err)
	}
}

func cleanupReviewCommand(build *LibBuildCmd, publish, finish bool, limit int) error {
	if publish {
		cmd := &LibPublishCmd{GroupLib: build.GroupLib, MaxDeletes: limit, FinishInterruptedPublish: finish}
		cmd.ActionAlias = "alice"
		return cmd.Run(nil)
	}
	cmd := &LibUploadCmd{GroupLib: build.GroupLib, GroupS3Credentials: GroupS3Credentials{Bucket: "bucket/alice"}, MaxDeletes: limit, FinishInterruptedPublish: finish}
	cmd.ActionAlias = "alice"
	return cmd.Run(nil)
}

func TestPrivateCleanupRecoveryHonorsInvocationLimit(t *testing.T) {
	for _, publish := range []bool{false, true} {
		name := "upload"
		if publish {
			name = "publish"
		}
		t.Run(name, func(t *testing.T) {
			root, remoteRoot, build, candidate := privateCleanupFixture(t)
			interruptPrivateCleanup(t, candidate)
			release, err := acquireLibraryExecutionLock("alice")
			if err != nil {
				t.Fatal(err)
			}
			release()
			before := fastBuildSnapshot(t, root, accorderConfigDir, remoteRoot)
			if err := cleanupReviewCommand(build, publish, false, 0); err == nil || !strings.Contains(err.Error(), "--max-deletes=0") {
				t.Fatalf("zero did not block recovery deletion: %v", err)
			}
			if !bytes.Equal([]byte(before), []byte(fastBuildSnapshot(t, root, accorderConfigDir, remoteRoot))) {
				t.Fatal("zero-limit recovery mutated state")
			}
			if err := cleanupReviewCommand(build, publish, false, 1); err != nil {
				t.Fatal(err)
			}
			remaining, err := planPrivateCleanup(&libraryRemote{fsPath: remoteRoot}, []string{"Author/Second (2)"})
			if err != nil || len(remaining) != 0 {
				t.Fatalf("remaining=%v err=%v", remaining, err)
			}
		})
	}
}

func advanceCleanupRemote(t *testing.T, remote *libraryRemote) remoteLibrarySnapshot {
	t.Helper()
	snapshot := remote.commitState()
	base, _, err := torshare.DecodeGeneration(snapshot.GenerationRaw)
	if err != nil {
		t.Fatal(err)
	}
	pointer, err := calibre.BindPointerCommit(snapshot.Pointer, snapshot.SourceFingerprint, snapshot.Generation+100)
	if err != nil {
		t.Fatal(err)
	}
	raw, err := json.MarshalIndent(pointer, "", "  ")
	if err != nil {
		t.Fatal(err)
	}
	if err := remote.write(memberPointerPath, raw); err != nil {
		t.Fatal(err)
	}
	if err := remote.write(libraryflow.GenerationPath, torshare.EncodeGeneration(base, snapshot.Generation+100)); err != nil {
		t.Fatal(err)
	}
	return remote.commitState()
}

func TestPrivateCleanupRejectsChangedCommit(t *testing.T) {
	for _, stage := range []string{"after-private-delete", "before-manifest", "before-pointer", "before-sentinel"} {
		for _, recovering := range []bool{false, true} {
			if recovering && stage != "after-private-delete" {
				continue
			}
			name := stage
			if recovering {
				name += "-recovery"
			}
			t.Run(name, func(t *testing.T) {
				_, remoteRoot, build, candidate := privateCleanupFixture(t)
				writeTestFile(t, remoteRoot, "Author/Second (2)/zz.pdf", "third")
				if recovering {
					interruptPrivateCleanup(t, candidate)
				}
				remote := &libraryRemote{fsPath: remoteRoot}
				var advanced remoteLibrarySnapshot
				deletes := 0
				publishCommitStageHook = func(s string) error {
					if s == "after-private-delete" {
						deletes++
					}
					if s == stage && len(advanced.GenerationRaw) == 0 {
						advanced = advanceCleanupRemote(t, remote)
					}
					return nil
				}
				t.Cleanup(func() { publishCommitStageHook = nil })
				var err error
				if recovering {
					err = cleanupReviewCommand(build, false, false, 25)
				} else {
					err = publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: 25})
				}
				publishCommitStageHook = nil
				if err == nil || !strings.Contains(err.Error(), "remote library changed") {
					t.Fatalf("accepted changed commit: %v", err)
				}
				current := remote.commitState()
				if !bytes.Equal(current.GenerationRaw, advanced.GenerationRaw) || !bytes.Equal(current.PointerRaw, advanced.PointerRaw) {
					t.Fatal("overwrote the newer remote commit")
				}
				if stage == "after-private-delete" && deletes != 1 {
					t.Fatalf("deleted %d files using stale approval", deletes)
				}
			})
		}
	}
}

func TestPrivateCleanupLiteralDirectoryRules(t *testing.T) {
	for _, dir := range []string{"Author/[Second] (2)", "Author/Second*? (2)", "Author/{Second,Other} (2)", "Author/{{literal}} (2)"} {
		rule := "/" + dir + "/**"
		dirs, err := privateCleanupDirs([]string{rule})
		if err != nil || len(dirs) != 1 || dirs[0] != dir {
			t.Fatalf("literal directory changed: %v %v", dirs, err)
		}
		compiled, err := filter.GlobPathToRegexp(rcloneUploadExcludes([]string{rule})[0], false)
		if err != nil || !compiled.MatchString(dir+"/book.epub") || compiled.MatchString("Author/S (2)/book.epub") {
			t.Fatalf("incorrect literal rclone rule for %q: %v", dir, err)
		}
	}
}

func TestPrivateCleanupBracketedBookPublication(t *testing.T) {
	for _, fullCopy := range []bool{false, true} {
		name := "mirror"
		if fullCopy {
			name = "full-copy"
		}
		t.Run(name, func(t *testing.T) {
			root, remoteRoot, build := fastBuildPublishedFixture(t)
			fastBuildAddSecondBook(t, root)
			dir := "Author/[Second] {draft} (2)"
			if err := os.Rename(filepath.Join(root, "Author/Second (2)"), filepath.Join(root, dir)); err != nil {
				t.Fatal(err)
			}
			fastBuildSQL(t, root, `UPDATE books SET path='Author/[Second] {draft} (2)' WHERE id=2; INSERT INTO tags(id,name) VALUES(1,'private'); INSERT INTO books_tags_link(book,tag) VALUES(2,1)`)
			writeTestFile(t, root, "Author/S draft (2)/keep.epub", "public")
			writeTestFile(t, remoteRoot, "Author/S draft (2)/keep.epub", "public")
			if err := build.Run(nil); err != nil {
				t.Fatal(err)
			}
			candidate, err := captureExistingCandidate(root, resolveUploadExcludes(root, nil))
			if err != nil {
				t.Fatal(err)
			}
			if fullCopy {
				candidate.Change.CompleteOverwrite = true
				if err := saveLocalChangeCandidate(root, *candidate.Change); err != nil {
					t.Fatal(err)
				}
			}
			// No private remote directory on the first publication; next time
			// inject an old filename so literal cleanup is exercised as well.
			for _, leak := range []bool{false, true} {
				if leak {
					writeTestFile(t, remoteRoot, dir+"/obsolete.epub", "private")
					if err := build.Run(nil); err != nil {
						t.Fatal(err)
					}
					candidate, err = captureExistingCandidate(root, resolveUploadExcludes(root, nil))
					if err != nil {
						t.Fatal(err)
					}
					if fullCopy {
						candidate.Change.CompleteOverwrite = true
						if err := saveLocalChangeCandidate(root, *candidate.Change); err != nil {
							t.Fatal(err)
						}
					}
				}
				publishCommitStageHook = func(stage string) error {
					if stage == "after-mirror" || stage == "before-private-cleanup" || stage == "before-manifest" {
						if _, err := os.Stat(filepath.Join(remoteRoot, dir, "Second - Author.epub")); !os.IsNotExist(err) {
							return errors.New("private format uploaded before cleanup")
						}
					}
					return nil
				}
				t.Cleanup(func() { publishCommitStageHook = nil })
				if err := publishCandidate("alice", fastBuildLibraryID, GroupS3Credentials{}, candidate, publishOptions{MaxDeletes: 25, AllowCompleteOverwrite: true}); err != nil {
					t.Fatal(err)
				}
				publishCommitStageHook = nil
				remaining, err := planPrivateCleanup(&libraryRemote{fsPath: remoteRoot}, []string{dir})
				if err != nil || len(remaining) != 0 {
					t.Fatalf("private paths remain: %v %v", remaining, err)
				}
			}
			if data, err := os.ReadFile(filepath.Join(remoteRoot, "Author/S draft (2)/keep.epub")); err != nil || string(data) != "public" {
				t.Fatalf("public neighbor changed: %v", err)
			}
		})
	}
}

func TestPrivateCleanupFinishUploadedSnapshotAfterLocalEdits(t *testing.T) {
	for _, publish := range []bool{false, true} {
		name := "upload"
		if publish {
			name = "publish"
		}
		t.Run(name, func(t *testing.T) {
			root, remoteRoot, build, candidate := privateCleanupFixture(t)
			interruptPrivateCleanup(t, candidate)
			fastBuildSQL(t, root, `UPDATE books SET title='Later',sort='Later' WHERE id=1`)
			writeTestFile(t, root, fastBuildPayload, "edit")
			localDB, err := os.ReadFile(filepath.Join(root, "metadata.db"))
			if err != nil {
				t.Fatal(err)
			}
			if err := cleanupReviewCommand(build, publish, false, 25); err == nil || !strings.Contains(err.Error(), "--finish-interrupted-publish") {
				t.Fatalf("missing recovery instruction: %v", err)
			}
			if err := build.Run(nil); err == nil {
				t.Fatal("build overwrote interrupted snapshot")
			}
			if err := cleanupReviewCommand(build, publish, true, 0); err == nil || !strings.Contains(err.Error(), "--max-deletes=0") {
				t.Fatalf("explicit completion bypassed zero: %v", err)
			}
			if err := cleanupReviewCommand(build, publish, true, 1); err != nil {
				t.Fatal(err)
			}
			if data, err := os.ReadFile(filepath.Join(root, "metadata.db")); err != nil || !bytes.Equal(data, localDB) {
				t.Fatalf("completion overwrote local edits: %v", err)
			}
			if data, err := os.ReadFile(filepath.Join(remoteRoot, fastBuildPayload)); err != nil || string(data) != "old!" {
				t.Fatalf("completion uploaded later edits: %v", err)
			}
			if err := build.Run(nil); err != nil {
				t.Fatal(err)
			}
			change, err := loadLocalChangeCandidate(root)
			if err != nil || !containsString(change.ForcePaths, fastBuildPayload) {
				t.Fatalf("later payload edit lost: %v", err)
			}
			if err := cleanupReviewCommand(build, publish, false, 25); err != nil {
				t.Fatal(err)
			}
			if data, err := os.ReadFile(filepath.Join(remoteRoot, fastBuildPayload)); err != nil || string(data) != "edit" {
				t.Fatalf("next publication lost edits: %v", err)
			}
		})
	}
}
