//go:build !tailscale

package cmd

// Promoted Phase 0 spike for fedlib-reinvite-identity (was
// joinChainIdentity_spike_test.go): validates that an invite-adopted
// libraryID (storeInviteLibraryID, the production feature-3 write that
// runs inside join.Run BEFORE runJoinPublish) flows
// alias -> ensureAliasSetup -> build -> index with NO fresh mint
// ("[CFG] minted libraryID" never logged), and lands where the publish/
// poll path reads it (calibre.AllBooksFromIndex -> books[0].LibraryUUID,
// memberPoller.go:115-123). Plus the precedence arms.
//
// Precedence has been revised twice. The original design let a stored
// identity win over a conflicting invite with a warning; bfd9e8b made that
// refusal fail closed; join-adopts-local-profile then narrowed the refusal
// to aliases carrying a membership or publish signal, so an alias holding
// nothing but a locally minted UUID now adopts the invite's identity
// instead of being refused. An identity-less blob still mints as it always
// did. See classifyJoinAlias for the classes.

import (
	"bytes"
	"log"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"accorder/pkg/calibre"
	"accorder/pkg/fedlibinvite"

	"github.com/tidwall/sjson"
)

const adoptedUUID = "9f3b1c2e-4d5a-4b6c-8d7e-0f1a2b3c4d5e"

// runAdoptedJoin drives the production join chain with an
// identity-bearing invite blob: join.Run adopts inv.LibraryID via
// storeInviteLibraryID before runJoinPublish. The invite carries no
// remote config, so runJoinPublish bails at the bucket check
// (libJoin.go:105-107) — AFTER ensureAliasSetup ran.
func runAdoptedJoin(t *testing.T, libDir string) {
	t.Helper()
	if err := os.WriteFile(filepath.Join(libDir, "metadata.db"), []byte("stub"), 0o644); err != nil {
		t.Fatal(err)
	}
	inv := &fedlibinvite.WriteInvite{
		FedlibID: "fedlib-x", Backend: "s3", Prefix: "alice",
		AccessKey: "AK", SecretKey: "SK", Label: "Alice's Library",
		LibraryID: adoptedUUID,
	}
	blob := fedlibinvite.EncodeWriteInvite(inv)
	_, ctx := parseCLI(t, []string{"lib", "join", "adopt", "--invite", blob, "--passphrase=pw", "--calibrepath=" + libDir})

	join := &LibJoinCmd{Invite: blob, CommonCommandFields: CommonCommandFields{ActionAlias: "adopt"}, CalibrePath: libDir}
	err := join.Run(ctx)
	if err == nil || !strings.Contains(err.Error(), "bucket") {
		t.Fatalf("expected remote-config bail after ensureAliasSetup, got: %v", err)
	}
}

// captureLog redirects the standard logger (both mint sites log via
// log.Printf: ensureAlias.go:71, setupDefaults.go:51) for the test.
func captureLog(t *testing.T) *bytes.Buffer {
	t.Helper()
	var buf bytes.Buffer
	log.SetOutput(&buf)
	t.Cleanup(func() { log.SetOutput(os.Stderr) })
	return &buf
}

// ═══════════════════════════════════════════════════════════════════
// Seam 1: lib join with an identity-bearing invite — ensureAliasSetup
// resolves the adopted UUID, mints nothing, and the UUID stays
// propagated to every sharedgroup:"lib" sibling a fresh-process
// build/publish/share resolves from.
// ═══════════════════════════════════════════════════════════════════

func TestJoin_AdoptedLibraryIDResolvesWithoutMint(t *testing.T) {
	libDir := testSetup(t)
	logBuf := captureLog(t)

	runAdoptedJoin(t, libDir)

	if strings.Contains(logBuf.String(), "minted libraryID") {
		t.Errorf("fresh mint despite adopted libraryID:\n%s", logBuf.String())
	}
	alias := readAlias(t, "adopt")
	for _, path := range []string{"lib.build", "lib.share.live", "lib.upload", "lib.publish"} {
		if got := alias.Get(path + ".libraryID").String(); got != adoptedUUID {
			t.Errorf("%s.libraryID = %q, want adopted %q", path, got, adoptedUUID)
		}
	}
}

// ═══════════════════════════════════════════════════════════════════
// Seam 2: after the adopted join, a fresh-parse flagless
// `lib build adopt --index` resolves the adopted UUID (no mint) and
// the REAL index build embeds it where the aggregate poller reads it
// (AllBooksFromIndex -> books[0].LibraryUUID, memberPoller.go:123).
// ═══════════════════════════════════════════════════════════════════

func TestJoin_AdoptedLibraryIDLandsInBuiltIndex(t *testing.T) {
	libDir := testSetup(t)
	logBuf := captureLog(t)

	runAdoptedJoin(t, libDir)

	// JSONL at the alias's default cache path (applyBuildDefaults), with
	// books stamped the way the bare build stamps them from c.LibraryID.
	seedCmdJSONL(t, filepath.Join(accorderConfigDir, "cache", "adopt.jsonl"), adoptedUUID, "Alice's Library", 3)

	// A federation-member index build (--fedlibPrefix, here adopted from the
	// invite's prefix "alice") requires a unique DictID >= 2; supply it like a
	// real lib join / operator build would.
	_, ctx, err := parseCLIErr(t, []string{"lib", "build", "adopt", "--index", "--dictID", "2"})
	if err != nil {
		t.Fatalf("flagless lib build after adopted join: %v", err)
	}
	build := ctx.Selected().Target.Interface().(LibBuildCmd)
	if build.LibraryID != adoptedUUID {
		t.Fatalf("build resolved libraryID %q, want adopted %q", build.LibraryID, adoptedUUID)
	}
	if err := build.Run(ctx); err != nil {
		t.Fatalf("lib build --index: %v", err)
	}
	if strings.Contains(logBuf.String(), "minted libraryID") {
		t.Errorf("fresh mint somewhere in the chain:\n%s", logBuf.String())
	}

	books, err := calibre.AllBooksFromIndex(filepath.Join(libDir, "static", "library_index"))
	if err != nil {
		t.Fatalf("read built index (poller path): %v", err)
	}
	if len(books) == 0 {
		t.Fatal("built index is empty")
	}
	if books[0].LibraryUUID != adoptedUUID {
		t.Errorf("index books[0].LibraryUUID = %q, want adopted %q (memberPoller.go:123 read)", books[0].LibraryUUID, adoptedUUID)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Precedence: a stored alias libraryID makes a conflicting invite fail closed;
// credentials/pending state can be retried under another alias, and the active
// identity remains untouched.
// ═══════════════════════════════════════════════════════════════════

func TestJoin_StoredLibraryIDConflictFailsClosed(t *testing.T) {
	_ = testSetup(t)
	const storedUUID = "11111111-2222-4333-8444-555555555555"

	// Pre-seed the alias with a different identity (production primitives).
	configBytes := loadActionAliases()
	configBytes, err := sjson.SetBytes(configBytes, "adopt.lib.build.libraryID", storedUUID)
	if err != nil {
		t.Fatalf("pre-seed stored libraryID: %v", err)
	}
	saveActionAliases(configBytes)

	inv := &fedlibinvite.WriteInvite{
		FedlibID: "fedlib-x", Backend: "s3", Prefix: "alice",
		AccessKey: "AK", SecretKey: "SK", LibraryID: adoptedUUID,
	}
	blob := fedlibinvite.EncodeWriteInvite(inv)
	_, ctx := parseCLI(t, []string{"lib", "join", "adopt", "--invite", blob, "--passphrase=pw"})
	join := &LibJoinCmd{Invite: blob, CommonCommandFields: CommonCommandFields{ActionAlias: "adopt"}}

	_, stderr, err := captureInviteOutput(t, func() error { return join.Run(ctx) })
	if err == nil || !strings.Contains(err.Error(), storedUUID) || !strings.Contains(err.Error(), adoptedUUID) {
		t.Fatalf("lib join conflict error = %v; stderr=%s", err, stderr)
	}
	alias := readAlias(t, "adopt")
	if got := alias.Get("lib.build.libraryID").String(); got != storedUUID {
		t.Errorf("stored libraryID = %q, want surviving %q", got, storedUUID)
	}
}

// Matching stored identity: silent no-op (no warning, value unchanged).
func TestJoin_MatchingStoredLibraryIDIsSilentNoop(t *testing.T) {
	_ = testSetup(t)

	configBytes := loadActionAliases()
	configBytes, err := sjson.SetBytes(configBytes, "adopt.lib.build.libraryID", adoptedUUID)
	if err != nil {
		t.Fatalf("pre-seed stored libraryID: %v", err)
	}
	saveActionAliases(configBytes)

	inv := &fedlibinvite.WriteInvite{
		FedlibID: "fedlib-x", Backend: "s3", Prefix: "alice",
		AccessKey: "AK", SecretKey: "SK", LibraryID: adoptedUUID,
	}
	blob := fedlibinvite.EncodeWriteInvite(inv)
	_, ctx := parseCLI(t, []string{"lib", "join", "adopt", "--invite", blob, "--passphrase=pw"})
	join := &LibJoinCmd{Invite: blob, CommonCommandFields: CommonCommandFields{ActionAlias: "adopt"}}

	_, stderr, err := captureInviteOutput(t, func() error { return join.Run(ctx) })
	if err != nil {
		t.Fatalf("lib join: %v", err)
	}
	if strings.Contains(stderr, "WARNING") {
		t.Errorf("unexpected warning for matching stored identity:\n%s", stderr)
	}
	if got := readAlias(t, "adopt").Get("lib.build.libraryID").String(); got != adoptedUUID {
		t.Errorf("libraryID = %q, want unchanged %q", got, adoptedUUID)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Regression guard: an identity-less blob still mints exactly as today.
// ═══════════════════════════════════════════════════════════════════

// Two machines, one blob (operator-minted-member-uuid success
// criterion 2): the operator's invite command mints the identity, and
// the SAME blob accepted on two fresh machines (independent config
// dirs) resolves to the SAME libraryID on both — no ordering, no
// re-invite.
func TestJoin_SameBlobTwoMachinesSameIdentity(t *testing.T) {

	// Operator seat: the real invite command mints the member identity.
	_ = testSetup(t)
	fedlibDir := t.TempDir()
	stdout, _, err := captureInviteOutput(t, runNilCtx(reinviteCmd("Dana", "dana", fedlibDir).Run))
	if err != nil {
		t.Fatalf("operator invite: %v", err)
	}
	minted := decodeStdoutBlob(t, stdout).LibraryID
	if minted == "" {
		t.Fatal("operator invite produced an identityless blob")
	}
	identityOnly := decodeStdoutBlob(t, stdout)
	identityOnly.RemoteConfig = nil // this test isolates identity adoption, not remote recovery
	blob := fedlibinvite.EncodeWriteInvite(identityOnly)

	// Member seats: each testSetup rebinds the config globals to a fresh
	// temp dir — a fresh machine. Join without --calibrepath stops after
	// storeInviteLibraryID, before any publish.
	var got [2]string
	for i := range got {
		_ = testSetup(t)
		_, ctx := parseCLI(t, []string{"lib", "join", "dana", "--invite", blob, "--passphrase=pw"})
		join := &LibJoinCmd{Invite: blob, CommonCommandFields: CommonCommandFields{ActionAlias: "dana"}}
		if err := join.Run(ctx); err != nil {
			t.Fatalf("machine %d join: %v", i+1, err)
		}
		got[i] = readAlias(t, "dana").Get("lib.build.libraryID").String()
	}

	if got[0] != minted || got[1] != minted {
		t.Errorf("machine identities = %q, %q; want operator-minted %q on both", got[0], got[1], minted)
	}
}

func TestJoin_IdentitylessBlobStillMints(t *testing.T) {
	libDir := testSetup(t)
	logBuf := captureLog(t)

	if err := os.WriteFile(filepath.Join(libDir, "metadata.db"), []byte("stub"), 0o644); err != nil {
		t.Fatal(err)
	}
	inv := &fedlibinvite.WriteInvite{
		FedlibID: "fedlib-x", Backend: "s3", Prefix: "bob",
		AccessKey: "AK", SecretKey: "SK",
	}
	blob := fedlibinvite.EncodeWriteInvite(inv)
	_, ctx := parseCLI(t, []string{"lib", "join", "mintme", "--invite", blob, "--passphrase=pw", "--calibrepath=" + libDir})
	join := &LibJoinCmd{Invite: blob, CommonCommandFields: CommonCommandFields{ActionAlias: "mintme"}, CalibrePath: libDir}
	err := join.Run(ctx)
	if err == nil || !strings.Contains(err.Error(), "bucket") {
		t.Fatalf("expected remote-config bail, got: %v", err)
	}

	if !strings.Contains(logBuf.String(), "minted libraryID") {
		t.Errorf("identity-less join did not mint:\n%s", logBuf.String())
	}
	id := readAlias(t, "mintme").Get("lib.build.libraryID").String()
	if id == "" {
		t.Fatal("no libraryID persisted for identity-less join")
	}
	if id == adoptedUUID {
		t.Errorf("identity-less join somehow adopted %q", adoptedUUID)
	}
}
