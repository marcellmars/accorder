package cmd

import (
	"accorder/pkg/calibre"
	"encoding/hex"
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

func readAndValidateDerivedFamily(localDir, indexName string) (calibre.PointerFile, calibre.Manifest, error) {
	indexPath := filepath.Join(localDir, filepath.FromSlash(indexName))
	if !strings.HasSuffix(indexPath, ".zst") {
		return calibre.PointerFile{}, calibre.Manifest{}, fmt.Errorf("derived index %s must end in .zst", indexName)
	}
	mf, err := calibre.ReadManifestFromZst(indexPath)
	if err != nil {
		return calibre.PointerFile{}, calibre.Manifest{}, err
	}
	pointerPath := strings.TrimSuffix(indexPath, ".zst") + ".manifest.json"
	pointer, err := calibre.ReadPointerFile(pointerPath)
	if err != nil {
		return calibre.PointerFile{}, calibre.Manifest{}, err
	}
	if err := validateDerivedFamily(localDir, indexName, pointer, mf); err != nil {
		return calibre.PointerFile{}, calibre.Manifest{}, err
	}
	return pointer, mf, nil
}

func validateDerivedFamily(localDir, indexName string, pointer calibre.PointerFile, mf calibre.Manifest) error {
	if filepath.Base(pointer.Index.URL) != filepath.Base(indexName) {
		return fmt.Errorf("pointer index URL %q does not name %q", pointer.Index.URL, filepath.Base(indexName))
	}
	if pointer.Index.BaseGeneration != hex.EncodeToString(mf.BaseGeneration[:]) {
		return fmt.Errorf("pointer/index base generation mismatch")
	}
	if pointer.Index.NumBooks != mf.NumBooks || pointer.Index.Regions != len(mf.Regions) ||
		pointer.Index.Tombstones != len(mf.Tombstones) || pointer.Index.ChunkSize != mf.ChunkSize {
		return fmt.Errorf("pointer/index manifest lineage mismatch")
	}
	jsonlName := strings.TrimSuffix(indexName, ".zst") + ".jsonl.zst"
	if pointer.Index.JsonlURL == "" {
		if _, err := os.Stat(filepath.Join(localDir, filepath.FromSlash(jsonlName))); err == nil {
			return fmt.Errorf("derived JSONL exists but pointer declares no JSONL lineage")
		} else if !os.IsNotExist(err) {
			return err
		}
		return nil
	}
	if filepath.Base(pointer.Index.JsonlURL) != filepath.Base(jsonlName) {
		return fmt.Errorf("pointer JSONL URL %q does not name %q", pointer.Index.JsonlURL, filepath.Base(jsonlName))
	}
	info, err := os.Stat(filepath.Join(localDir, filepath.FromSlash(jsonlName)))
	if err != nil {
		return fmt.Errorf("pointer-declared JSONL: %w", err)
	}
	if info.Size() != pointer.Index.JsonlBytes {
		return fmt.Errorf("pointer JSONL size %d does not match artifact size %d", pointer.Index.JsonlBytes, info.Size())
	}
	var rawBytes int64
	for _, region := range mf.Regions {
		rawBytes += int64(region.DisplayLen)
	}
	if pointer.Index.JsonlRawBytes != rawBytes {
		return fmt.Errorf("pointer JSONL raw size does not match index manifest")
	}
	return nil
}
