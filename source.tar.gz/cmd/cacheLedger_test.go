package cmd

import (
	"os"
	"strings"
	"testing"
)

func TestLedger_AppendReplayRoundTrip(t *testing.T) {
	testSetup(t)
	ledgerServeStart(t, "accorder-serve-a", "bucket")
	ledgerServeStart(t, "accorder-serve-a", "bucket/other") // root drift: two active roots

	records, malformed, err := readLedger()
	if err != nil || malformed {
		t.Fatalf("read: malformed=%v err=%v", malformed, err)
	}
	view := replayLedger(records)
	if len(view.activeRoots["accorder-serve-a"]) != 2 {
		t.Fatalf("active roots = %v", view.activeRoots["accorder-serve-a"])
	}
}

func TestLedger_RenameTombstonesSourceActivatesDestination(t *testing.T) {
	testSetup(t)
	ledgerServeStart(t, "accorder-serve-a", "bucket")
	if err := withGCLock(func() error {
		return appendLedgerRecord(ledgerRecord{Type: "rename",
			FromRemote: "accorder-serve-a", FromRoot: "bucket",
			ToRemote: "accorder-serve-b", ToRoot: "bucket", Cmd: "test"})
	}); err != nil {
		t.Fatal(err)
	}
	records, _, _ := readLedger()
	view := replayLedger(records)
	if len(view.activeRoots["accorder-serve-a"]) != 0 {
		t.Fatal("source key not tombstoned by rename")
	}
	if !view.activeRoots["accorder-serve-b"]["bucket"] {
		t.Fatal("destination key not activated by rename — migrated tree would be unledgered until the next serve start")
	}

	// serve-start after a delete tombstone re-activates the key.
	if err := withGCLock(func() error {
		return appendLedgerRecord(ledgerRecord{Type: "delete", Remote: "accorder-serve-b", Root: "bucket", Cmd: "test"})
	}); err != nil {
		t.Fatal(err)
	}
	ledgerServeStart(t, "accorder-serve-b", "bucket")
	records, _, _ = readLedger()
	view = replayLedger(records)
	if !view.activeRoots["accorder-serve-b"]["bucket"] {
		t.Fatal("serve-start after delete tombstone did not re-activate")
	}
}

func TestLedger_TruncatedTailToleratedAndRepaired(t *testing.T) {
	testSetup(t)
	ledgerServeStart(t, "accorder-serve-a", "bucket")

	// Simulate a crash mid-append: partial trailing line, no newline.
	f, err := os.OpenFile(identityLedgerPath(), os.O_APPEND|os.O_WRONLY, 0o600)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := f.WriteString(`{"v":1,"type":"serve-st`); err != nil {
		t.Fatal(err)
	}
	f.Close()

	records, malformed, err := readLedger()
	if err != nil || malformed {
		t.Fatalf("truncated tail treated as malformed (malformed=%v err=%v)", malformed, err)
	}
	if len(records) != 1 {
		t.Fatalf("records = %d, want 1 (partial dropped)", len(records))
	}

	// The next append repairs the tail; a subsequent parse is clean and
	// carries both complete records.
	ledgerServeStart(t, "accorder-serve-b", "bucket")
	data, _ := os.ReadFile(identityLedgerPath())
	if strings.Contains(string(data), "serve-st\"") || strings.Count(string(data), "\n") != 2 {
		t.Fatalf("tail not repaired: %q", string(data))
	}
	records, malformed, err = readLedger()
	if err != nil || malformed || len(records) != 2 {
		t.Fatalf("post-repair parse: %d records malformed=%v err=%v", len(records), malformed, err)
	}
}

func TestLedger_MaliciousRecordsRejected(t *testing.T) {
	testSetup(t)

	// Appending path-escape attempts must fail validation.
	bad := []ledgerRecord{
		{Type: "serve-start", Remote: "accorder-../../etc", Root: "bucket"},
		{Type: "serve-start", Remote: "accorder-x/y", Root: "bucket"},
		{Type: "serve-start", Remote: "notaccorder-x", Root: "bucket"},
		{Type: "serve-start", Remote: "accorder-x", Root: "/abs"},
		{Type: "serve-start", Remote: "accorder-x", Root: "a/../b"},
		{Type: "delete", DictFile: "../x.dict"},
		{Type: "dict-write", DictFile: "/abs.dict"},
	}
	for _, rec := range bad {
		if err := withGCLock(func() error { return appendLedgerRecord(rec) }); err == nil {
			t.Errorf("append accepted malicious record %+v", rec)
		}
	}

	// A syntactically valid but malicious record read from disk drops the
	// ledger to malformed (report-only), and nothing builds a path from it.
	if err := os.MkdirAll(cacheLocksDir(), 0o700); err != nil {
		t.Fatal(err)
	}
	line := `{"v":1,"type":"serve-start","remote":"accorder-x/../../evil","root":"bucket","ts":"2026-01-01T00:00:00Z"}` + "\n"
	if err := os.WriteFile(identityLedgerPath(), []byte(line), 0o600); err != nil {
		t.Fatal(err)
	}
	_, malformed, err := readLedger()
	if err != nil || !malformed {
		t.Fatalf("malicious on-disk record not flagged malformed (err=%v)", err)
	}
}

func TestLedgerBatchRejectsInvalidSecondRowWithoutWritingFirst(t *testing.T) {
	testSetup(t)
	ledgerServeStart(t, "accorder-serve-existing", "bucket")
	before, err := os.ReadFile(identityLedgerPath())
	if err != nil {
		t.Fatal(err)
	}
	err = withGCLock(func() error {
		return appendLedgerRecords([]ledgerRecord{
			{Type: "serve-start", Remote: "accorder-serve-books", Root: "bucket", Cmd: "test"},
			{Type: "serve-start", Remote: "invalid-assets", Root: "bucket", Cmd: "test"},
		})
	})
	if err == nil {
		t.Fatal("batch with invalid assets row succeeded")
	}
	after, err := os.ReadFile(identityLedgerPath())
	if err != nil {
		t.Fatal(err)
	}
	if string(after) != string(before) {
		t.Fatalf("batch wrote a one-row prefix before rejecting its second row:\nbefore=%q\nafter=%q", before, after)
	}
}
