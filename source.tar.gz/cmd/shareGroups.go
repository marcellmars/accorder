package cmd

import (
	"accorder/pkg/calibre"
	"accorder/pkg/libraryflow"
	"accorder/pkg/rclonexfer"
	"accorder/pkg/torshare"
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"strings"

	"github.com/klauspost/compress/zstd"
)

type GroupTorShare struct {
	GroupLibDir
	Librarian   string `short:"l" json:"librarian" help:"The catalog's librarian name (auto-generated when omitted)." validate:"omitempty,personname" sharedgroup:"lib" gen:"librarian"`
	LibraryID   string `name:"libraryID" short:"i" json:"libraryID" help:"The catalog's UUID (auto-generated when omitted)." validate:"omitempty,uuid" sharedgroup:"lib" gen:"uuid"`
	LibraryName string `name:"library-name" json:"library-name" help:"Human name for this library (stamped into the pointer file for remote browsers)." validate:"omitempty" sharedgroup:"lib"`
	IndexPath   string `name:"index-path" json:"index-path" help:"Path to MWSC index. Required for local mode; optional escape hatch in S3 mode." validate:"omitempty,filepath" sharedgroup:"lib"`
}

type GroupS3Source struct {
	S3Source    *bool  `name:"s3-source" json:"s3-source" help:"Serve from S3 remote instead of local directory."`
	Bucket      string `name:"bucket" json:"bucket" propagate:"-" help:"S3 bucket name." validate:"required_with=S3Source"`
	S3AccessKey string `name:"s3-access-key" json:"s3-access-key" alias:"-" help:"S3 access key (must have s3:PutObject for first share; read-only keys only work with pre-uploaded index)." validate:"required_with=S3Source" sharedgroup:"s3creds" secret:"redact,fingerprint"`
	S3SecretKey string `name:"s3-secret-key" json:"s3-secret-key" alias:"-" help:"S3 secret key (must have s3:PutObject for first share)." validate:"required_with=S3Source" sharedgroup:"s3creds" secret:"redact,fingerprint"`
	S3Provider  string `name:"s3-provider" json:"s3-provider" alias:"-" help:"S3 provider (e.g. Wasabi, AWS)." validate:"required_with=S3Source" sharedgroup:"s3creds"`
	S3Endpoint  string `name:"s3-endpoint" json:"s3-endpoint" alias:"-" help:"S3 endpoint URL." validate:"required_with=S3Source" sharedgroup:"s3creds"`
	S3Prefix    string `name:"s3-prefix" json:"s3-prefix" propagate:"-" help:"Path inside bucket (e.g. marcell)." validate:"required_with=S3Source"`
	CacheSize   string `name:"cache-size" json:"cache-size" help:"VFS cache size cap (e.g. 2Gi, 500M)." default:"2Gi" sharedgroup:"s3creds"`
}

func copyFile(src, dst string) error {
	if a, e1 := filepath.Abs(src); e1 == nil {
		if b, e2 := filepath.Abs(dst); e2 == nil && a == b {
			return nil
		}
	}
	if err := os.MkdirAll(filepath.Dir(dst), 0755); err != nil {
		return err
	}
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	out, err := os.Create(dst)
	if err != nil {
		return err
	}
	defer out.Close()
	if _, err := io.Copy(out, in); err != nil {
		return err
	}
	return out.Close()
}

func compressFileZstd(src, dst string) (err error) {
	srcInfo, err := os.Stat(src)
	if err != nil {
		return fmt.Errorf("stat src %s: %w", src, err)
	}
	if dstInfo, dstErr := os.Stat(dst); dstErr == nil && dstInfo.ModTime().After(srcInfo.ModTime()) {
		return nil
	}
	if err := os.MkdirAll(filepath.Dir(dst), 0755); err != nil {
		return err
	}
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	tmp := dst + ".tmp"
	out, err := os.Create(tmp)
	if err != nil {
		return err
	}
	defer func() {
		if err != nil {
			os.Remove(tmp)
		}
	}()
	zw, err := zstd.NewWriter(out, zstd.WithEncoderLevel(zstd.SpeedBestCompression))
	if err != nil {
		out.Close()
		return fmt.Errorf("zstd writer: %w", err)
	}
	if _, err = io.Copy(zw, in); err != nil {
		zw.Close()
		out.Close()
		return err
	}
	if err = zw.Close(); err != nil {
		out.Close()
		return err
	}
	if err = out.Close(); err != nil {
		return err
	}
	err = os.Rename(tmp, dst)
	return err
}

func s3DiagnosticHint(err error) {
	if strings.Contains(err.Error(), "AccessDenied") || strings.Contains(err.Error(), "403") {
		log.Printf("share: S3 upload failed with access denied — ensure your S3 keys have s3:PutObject permission (read-only keys only work when the remote already has an index)")
	}
}

func uploadIndexAndGeneration(localDir, indexName, fsPath string, mf calibre.Manifest, expectedSource string) error {
	manifestLocal := strings.TrimSuffix(indexName, ".zst") + ".manifest.json"
	pointer, err := calibre.ReadPointerFile(filepath.Join(localDir, manifestLocal))
	if err != nil {
		return fmt.Errorf("derived repair: read local pointer: %w", err)
	}
	if err := validateDerivedFamily(localDir, indexName, pointer, mf); err != nil {
		return fmt.Errorf("derived repair: incomplete/stale artifact family: %w", err)
	}
	remote := &libraryRemote{fsPath: fsPath}
	before := remote.commitState()
	if before.Writer.Kind == "invalid" || before.Writer.Kind == "unreadable" {
		return fmt.Errorf("derived repair: invalid/unreadable _WRITER: %w", before.Writer.Err)
	}
	// A remote that carries neither a pointer nor a _GENERATION has nothing to
	// repair — it is a first publish. `lib share live` Tier 3 (auto-compile
	// from a remote metadata.db) is exactly that case, so it may bootstrap, but
	// only when both objects are proven absent. An unreadable remote makes the
	// reads below fail with something other than not-found, so bootstrap stays
	// false and nothing is ever treated as free because it could not be seen.
	bootstrap := false
	if !before.Committed && !before.Legacy {
		_, pointerErr := remote.read(memberPointerPath, 4<<20)
		_, generationErr := remote.read(libraryflow.GenerationPath, 1<<20)
		bootstrap = errors.Is(pointerErr, errRemoteObjectNotFound) &&
			errors.Is(generationErr, errRemoteObjectNotFound)
	}

	sourceFingerprint := before.SourceFingerprint
	nextGeneration := before.Generation + 1
	if bootstrap {
		// The one path with no published-state files to read, so the objects
		// themselves are the only source of truth for the fingerprint. This is
		// why inspect() still exists, and it runs once per bucket rather than
		// on every command.
		listed := remote.inspect()
		if listed.InventoryToken == "" {
			return fmt.Errorf("bootstrap publish: could not list the remote prefix: %w", listed.Err)
		}
		// Validate the complete bootstrap source before uploading derived output.
		// In particular, an empty/partial prefix must remain byte-for-byte intact
		// when metadata.db is absent.
		sourceFingerprint, err = remote.sourceFingerprint(listed.Inventory)
		if err != nil {
			return fmt.Errorf("bootstrap publish: remote source fingerprint (upload the library payload first): %w", err)
		}
		if expectedSource != "" && sourceFingerprint != expectedSource {
			return fmt.Errorf("derived repair: local build source is stale; run `accorder lib publish` first")
		}

		ready := remote.inspect()
		if ready.Committed || ready.Legacy || ready.InventoryToken != listed.InventoryToken ||
			ready.Writer.Kind != before.Writer.Kind || !bytes.Equal(ready.Writer.Raw, before.Writer.Raw) {
			return fmt.Errorf("bootstrap publish: remote changed before index upload; retry")
		}
		readySource, readyErr := remote.sourceFingerprint(ready.Inventory)
		if readyErr != nil || readySource != sourceFingerprint {
			return fmt.Errorf("bootstrap publish: remote source changed before index upload; retry")
		}
		if _, pointerErr := remote.read(memberPointerPath, 4<<20); !errors.Is(pointerErr, errRemoteObjectNotFound) {
			return fmt.Errorf("bootstrap publish: manifest appeared before index upload; retry")
		}
		if _, generationErr := remote.read(libraryflow.GenerationPath, 1<<20); !errors.Is(generationErr, errRemoteObjectNotFound) {
			return fmt.Errorf("bootstrap publish: generation appeared before index upload; retry")
		}
		nextGeneration = 1
	} else {
		if before.Err != nil || !before.Committed {
			return fmt.Errorf("derived repair requires a coherent version 2 remote snapshot; run `accorder lib publish` first: %v", before.Err)
		}
		if expectedSource != "" && before.SourceFingerprint != expectedSource {
			return fmt.Errorf("derived repair: local build source is stale; run `accorder lib publish` first")
		}
		if pointer.Library.UUID != before.Pointer.Library.UUID {
			return fmt.Errorf("derived repair: local pointer UUID %s does not match remote %s", pointer.Library.UUID, before.Pointer.Library.UUID)
		}
		ready := remote.commitState()
		if ready.Err != nil || !sameRemoteApproval(before, ready) || !bytes.Equal(before.Writer.Raw, remote.readWriter().Raw) {
			return fmt.Errorf("derived repair: remote changed before index upload; retry")
		}
	}

	if err := rclonexfer.CopyFileOverwrite(localDir, indexName, fsPath, "static/library_index.zst"); err != nil {
		s3DiagnosticHint(err)
		return fmt.Errorf("upload index: %w", err)
	}

	jsonlLocal := strings.TrimSuffix(indexName, ".zst") + ".jsonl.zst"
	if _, err := os.Stat(filepath.Join(localDir, jsonlLocal)); err == nil {
		if err := rclonexfer.CopyFileOverwrite(localDir, jsonlLocal, fsPath, "static/library_index.jsonl.zst"); err != nil {
			s3DiagnosticHint(err)
			return fmt.Errorf("upload jsonl.zst: %w", err)
		}
	}

	if bootstrap {
		objects, listErr := remote.list()
		if listErr != nil {
			return fmt.Errorf("bootstrap publish: list remote: %w", listErr)
		}
		afterSource, sourceErr := remote.sourceFingerprint(objects)
		if sourceErr != nil || afterSource != sourceFingerprint {
			return fmt.Errorf("bootstrap publish: remote source changed during index upload")
		}
		if _, pointerErr := remote.read(memberPointerPath, 4<<20); !errors.Is(pointerErr, errRemoteObjectNotFound) {
			return fmt.Errorf("bootstrap publish: manifest appeared during index upload; retry")
		}
		if _, generationErr := remote.read(libraryflow.GenerationPath, 1<<20); !errors.Is(generationErr, errRemoteObjectNotFound) {
			return fmt.Errorf("bootstrap publish: generation appeared during index upload; retry")
		}
	} else {
		afterPayload := remote.commitState()
		if afterPayload.Err != nil || afterPayload.SourceFingerprint != before.SourceFingerprint ||
			afterPayload.Generation != before.Generation || !bytes.Equal(afterPayload.PointerRaw, before.PointerRaw) {
			return fmt.Errorf("derived repair: remote source changed during index upload")
		}
	}
	if !bytes.Equal(before.Writer.Raw, remote.readWriter().Raw) {
		return fmt.Errorf("derived repair: writer marker changed during index upload")
	}

	pointer, err = calibre.BindPointerCommit(pointer, sourceFingerprint, nextGeneration)
	if err != nil {
		return err
	}
	pointerRaw, err := json.MarshalIndent(pointer, "", "  ")
	if err != nil {
		return err
	}
	if err := remote.write(memberPointerPath, pointerRaw); err != nil {
		s3DiagnosticHint(err)
		return fmt.Errorf("upload manifest: %w", err)
	}
	if err := remote.write(libraryflow.GenerationPath, torshare.EncodeGeneration(mf.BaseGeneration, nextGeneration)); err != nil {
		s3DiagnosticHint(err)
		return fmt.Errorf("upload generation sentinel: %w", err)
	}
	if !bytes.Equal(before.Writer.Raw, remote.readWriter().Raw) {
		return fmt.Errorf("derived repair: writer marker was not preserved")
	}
	committed := remote.commitState()
	if committed.Err != nil || !committed.Committed || committed.Generation != nextGeneration ||
		committed.SourceFingerprint != sourceFingerprint || committed.Pointer.Library.UUID != pointer.Library.UUID {
		return fmt.Errorf("derived repair: final commit verification failed: %v", committed.Err)
	}
	return nil
}
