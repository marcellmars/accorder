package cmd

import (
	"fmt"
	"reflect"

	"github.com/alecthomas/kong"
)

type LibPublishCmd struct {
	CommonCommandFields
	GroupLib
	GroupS3Credentials
	Passphrase               string `name:"passphrase" json:"-" help:"Passphrase for the local secrets store (or set ACCORDER_SECRETS_PASSPHRASE)." env:"ACCORDER_SECRETS_PASSPHRASE" secret:"redact"`
	DryRun                   bool   `name:"dry-run" help:"Print the complete publish plan without changing local or remote state." json:"-"`
	FinishInterruptedPublish bool   `name:"finish-interrupted-publish" help:"Finish an interrupted private-file cleanup using the snapshot already uploaded. Later local edits stay pending; publish again to upload them." json:"-"`
	MaxDeletes               int    `name:"max-deletes" help:"Maximum remote file removals across the mirror and private-book cleanup; zero forbids removals. The mirror may stop after partial work." default:"25" json:"-"`
	LocalWins                bool   `name:"local-wins" help:"Publish the local snapshot after explicit divergence review; does not override seat or shrink checks." json:"-"`
	AllowCompleteOverwrite   bool   `name:"allow-full-reupload" help:"Allow Accorder to upload every public library file again when it cannot safely identify only the changed files. This can take much longer and use substantial bandwidth." json:"-"`
	Verbose                  bool   `name:"verbose" help:"Print every planned deletion." json:"-"`
	RcloneLogLevel           string `name:"rclone-log-level" json:"-" help:"Log level for the embedded rclone (EMERGENCY..DEBUG, OFF). Empty keeps rclone's default NOTICE. Use DEBUG to see every request the remote inspection issues, which is how you tell what a slow publish is actually waiting on. Never remembered by the action alias (diagnostic class)." enum:"EMERGENCY,ALERT,CRITICAL,ERROR,WARNING,NOTICE,INFO,DEBUG,OFF," default:""`
}

// ResolveEffective derives the build-side paths on the PARENT's fields.
// lib publish is a pipeline: Run constructs children and delegates. Under
// -s the children are deliberately NOT constructed — their addresses would
// not match the provenance table, which is keyed on this struct's fields —
// so the derived values are computed here instead and rendered from the
// parent, labelled by the child's flag names.
func (c *LibPublishCmd) ResolveEffective() []FieldIssue {
	probe := &LibBuildCmd{GroupLib: c.GroupLib}
	probe.ActionAlias = c.ActionAlias
	probe.setShowConfigContext(c.showConfigContext())
	probe.ResolveEffective()

	prov := c.provenanceTable()
	self := reflect.ValueOf(c).Elem()
	if c.IndexPath == "" && probe.IndexPath != "" {
		c.IndexPath = probe.IndexPath
		prov.StampField(self, "IndexPath", OriginDerived, "from --calibrepath (lib build)")
	}
	if c.JsonLPath == "" && probe.JsonLPath != "" {
		c.JsonLPath = probe.JsonLPath
		prov.StampField(self, "JsonLPath", OriginDerived, "cache dir + alias (lib build)")
	}
	return nil
}

func (c *LibPublishCmd) Run(ctx *kong.Context) error {
	if c.HandleShowConfig(c) {
		return nil
	}
	if c.FinishInterruptedPublish && c.DryRun {
		return fmt.Errorf("--finish-interrupted-publish cannot be combined with --dry-run; no files were changed")
	}

	if err := c.EnsureCalibreDir(ctx, c.ActionAlias); err != nil {
		return err
	}
	if !c.DryRun {
		release, err := acquireLibraryExecutionLock(c.ActionAlias)
		if err != nil {
			return fmt.Errorf("lib publish: %w", err)
		}
		defer release()
		if recovered, err := resumeBeforeBuild(c.ActionAlias, c.LibraryID, c.CalibreDirectory, c.GroupS3Credentials, publishOptions{MaxDeletes: c.MaxDeletes, FinishInterruptedPublish: c.FinishInterruptedPublish}); err != nil {
			return err
		} else if recovered {
			fmt.Println("Recovered the previously committed publication.")
			if c.FinishInterruptedPublish {
				fmt.Println("Later local edits were not uploaded. Run lib publish again to publish those edits.")
			}
			return nil
		}
	}
	candidate, err := buildPublishCandidate(ctx, c)
	if err != nil {
		return fmt.Errorf("lib publish: %w", err)
	}
	return publishCandidate(c.ActionAlias, c.LibraryID, c.GroupS3Credentials, candidate, publishOptions{
		DryRun: c.DryRun, MaxDeletes: c.MaxDeletes, LocalWins: c.LocalWins,
		AllowCompleteOverwrite: c.AllowCompleteOverwrite, Verbose: c.Verbose,
		RcloneLogLevel: c.RcloneLogLevel,
	})
}
