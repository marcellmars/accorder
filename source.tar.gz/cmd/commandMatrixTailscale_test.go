//go:build tailscale

package cmd

import "testing"

// The tailscale build adds Funnel beside the base set — it must never
// again REPLACE share live, the drift this workflow found and fixed
// (cq-38).
func TestCommandMatrix_TailscaleExtrasPresent(t *testing.T) {
	got := collectCommandPaths(t)
	for _, want := range []string{
		"lib.share.funnel",
		"fedlib.share.funnel",
	} {
		if !got[want] {
			t.Errorf("tailscale extra %q missing from the tailscale build", want)
		}
	}
}
