package cmd

import (
	"fmt"
	"path/filepath"

	"accorder/pkg/calibre"
	"accorder/pkg/torshare"
)

func writeGenerationSentinel(destDir string, base [16]byte, mf calibre.Manifest) error {
	genBytes := torshare.EncodeGeneration(base, mf.Generation)
	if err := atomicWriteFile(filepath.Join(destDir, "_GENERATION"), genBytes, 0o644); err != nil {
		return fmt.Errorf("write generation sentinel: %w", err)
	}
	return nil
}
