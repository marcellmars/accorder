//go:build !tailscale

package cmd

import (
	"accorder/pkg/calibre"
	"accorder/pkg/fedlibinvite"
	"accorder/pkg/libraryflow"
	"accorder/pkg/rclonexfer"
	"accorder/pkg/secrets"
	"accorder/pkg/torshare"
	"bytes"
	"database/sql"
	"encoding/hex"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/tidwall/sjson"
)

// TestSplitScopedBucketAgreesWithIsScopedBucket guards against the two
// bucket-scoping checks in the library-remote open path disagreeing: both
// must accept (and normalize identically) whatever isScopedBucket approves.
func TestSplitScopedBucketAgreesWithIsScopedBucket(t *testing.T) {
	for _, scoped := range []string{
		"motw/biopolitics",
		"/motw/biopolitics",
		"motw/biopolitics/",
		"/motw/biopolitics/",
	} {
		if !isScopedBucket(scoped) {
			t.Fatalf("test fixture %q is not accepted by isScopedBucket", scoped)
		}
		bucket, prefix, err := splitScopedBucket(scoped)
		if err != nil {
			t.Fatalf("splitScopedBucket(%q) rejected a value isScopedBucket accepted: %v", scoped, err)
		}
		if bucket != "motw" || prefix != "biopolitics" {
			t.Fatalf("splitScopedBucket(%q) = (%q, %q), want (\"motw\", \"biopolitics\")", scoped, bucket, prefix)
		}
	}
	for _, scoped := range []string{"", "motw", "/motw", "motw/", "/"} {
		if _, _, err := splitScopedBucket(scoped); err == nil {
			t.Fatalf("splitScopedBucket(%q) unexpectedly succeeded for a bare bucket", scoped)
		}
	}
}

func TestNormalizeS3EndpointAcceptsConfiguredForms(t *testing.T) {
	for _, test := range []struct {
		name     string
		endpoint string
		want     string
	}{
		{name: "scheme-less Wasabi", endpoint: "s3.wasabisys.com", want: "https://s3.wasabisys.com"},
		{name: "trimmed scheme-less", endpoint: "  s3.eu-central-1.wasabisys.com  ", want: "https://s3.eu-central-1.wasabisys.com"},
		{name: "explicit HTTPS", endpoint: "https://s3.wasabisys.com", want: "https://s3.wasabisys.com"},
		{name: "explicit HTTP", endpoint: "http://127.0.0.1:9000", want: "http://127.0.0.1:9000"},
		{name: "empty", endpoint: "  ", want: ""},
	} {
		t.Run(test.name, func(t *testing.T) {
			if got := normalizeS3Endpoint(test.endpoint); got != test.want {
				t.Fatalf("normalizeS3Endpoint(%q) = %q, want %q", test.endpoint, got, test.want)
			}
		})
	}
	config := libraryS3RemoteConfig(GroupS3Credentials{
		S3Provider: "Wasabi", S3AccessKey: "access", S3SecretKey: "secret",
		S3Endpoint: "  s3.wasabisys.com  ",
	})
	if config.Endpoint != "https://s3.wasabisys.com" {
		t.Fatalf("rclone endpoint = %q, want the shared normalized endpoint", config.Endpoint)
	}
}

func TestClassifyLibraryState(t *testing.T) {
	baseline := &libraryBaseline{RemoteSourceFingerprint: "base", LocalSourceFingerprint: "base"}
	for _, tc := range []struct {
		local, remote string
		baseline      *libraryBaseline
		want          string
	}{
		{"base", "base", baseline, "current"},
		{"local", "base", baseline, "local ahead"},
		{"base", "remote", baseline, "remote ahead"},
		{"same", "same", baseline, "current (already converged)"},
		{"local", "remote", baseline, "diverged"},
		{"", "remote", nil, "remote available; local library missing"},
		{"local", "remote", nil, "unbaselined; choose remote-wins or local-wins"},
	} {
		if got := classifyLibraryState(tc.local, tc.remote, tc.baseline); got != tc.want {
			t.Errorf("classify(%q,%q) = %q, want %q", tc.local, tc.remote, got, tc.want)
		}
	}
}

func TestValidateJoinDestinationAllowsRecoveryTarget(t *testing.T) {
	root := t.TempDir()
	absent := filepath.Join(root, "new-library")
	if err := validateJoinDestination(absent); err != nil {
		t.Fatalf("absent recovery destination: %v", err)
	}
	empty := filepath.Join(root, "empty")
	if err := os.Mkdir(empty, 0o755); err != nil {
		t.Fatal(err)
	}
	if err := validateJoinDestination(empty); err != nil {
		t.Fatalf("empty recovery destination: %v", err)
	}
	bad := filepath.Join(root, "not-calibre")
	if err := os.Mkdir(bad, 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(bad, "notes.txt"), []byte("mine"), 0o644); err != nil {
		t.Fatal(err)
	}
	if err := validateJoinDestination(bad); err == nil || !strings.Contains(err.Error(), "non-empty") {
		t.Fatalf("non-empty non-Calibre destination error = %v", err)
	}
}

func TestRemoteInspectionRequiresPointerSourceSentinelCoherence(t *testing.T) {
	testSetup(t)
	root := t.TempDir()
	writeTestFile(t, root, "metadata.db", "metadata")
	writeTestFile(t, root, "Author/Book (1)/book.epub", "payload")
	if err := os.MkdirAll(filepath.Join(root, "static"), 0o755); err != nil {
		t.Fatal(err)
	}
	fingerprint, _, err := libraryflow.SourceFingerprint(root, nil)
	if err != nil {
		t.Fatal(err)
	}
	pointer, err := calibre.BindPointerCommit(calibre.PointerFile{
		Version: 1,
		Library: calibre.PointerFileLibrary{UUID: "550e8400-e29b-41d4-a716-446655440000", Librarian: "Alice"},
		Index:   calibre.PointerFileIndex{NumBooks: 1},
	}, fingerprint, 47)
	if err != nil {
		t.Fatal(err)
	}
	if err := calibre.WritePointerDocument(filepath.Join(root, filepath.FromSlash(memberPointerPath)), pointer); err != nil {
		t.Fatal(err)
	}
	var base [16]byte
	base[0] = 1
	if err := os.WriteFile(filepath.Join(root, libraryflow.GenerationPath), torshare.EncodeGeneration(base, 47), 0o644); err != nil {
		t.Fatal(err)
	}

	if err := rclonexfer.SetCacheDir(accorderCacheDir()); err != nil {
		t.Fatal(err)
	}
	rclonexfer.Initialize()
	defer rclonexfer.Finalize()
	remote := &libraryRemote{fsPath: root}
	snapshot := remote.inspect()
	if snapshot.Err != nil || !snapshot.Committed || snapshot.Generation != 47 || snapshot.SourceFingerprint != fingerprint {
		t.Fatalf("snapshot = %+v", snapshot)
	}
	if err := os.WriteFile(filepath.Join(root, libraryflow.GenerationPath), torshare.EncodeGeneration(base, 48), 0o644); err != nil {
		t.Fatal(err)
	}
	broken := remote.inspect()
	if broken.Err == nil || broken.Committed {
		t.Fatalf("mismatched pointer/sentinel accepted: %+v", broken)
	}
}

func TestRemoteWriterInvalidIsNotFree(t *testing.T) {
	testSetup(t)
	root := t.TempDir()
	if err := rclonexfer.SetCacheDir(accorderCacheDir()); err != nil {
		t.Fatal(err)
	}
	rclonexfer.Initialize()
	defer rclonexfer.Finalize()
	remote := &libraryRemote{fsPath: root}
	if got := remote.readWriter(); got.Kind != "absent" {
		t.Fatalf("missing writer = %+v", got)
	}
	writeTestFile(t, root, libraryflow.WriterPath, `{"version":99,"state":"free"}`)
	if got := remote.readWriter(); got.Kind != "invalid" {
		t.Fatalf("forward writer = %+v", got)
	}
	marker := libraryflow.ClaimWriter("seat", "Alice laptop", time.Now(), nil)
	if err := writeAndVerifyWriter(remote, marker); err != nil {
		t.Fatal(err)
	}
	if got := remote.readWriter(); got.Kind != "valid" || got.Marker.SeatID != "seat" {
		t.Fatalf("claimed writer = %+v", got)
	}
}

func TestDerivedRepairPreservesWriterAndCommitsGenerationLast(t *testing.T) {
	testSetup(t)
	remoteRoot := t.TempDir()
	writeTestFile(t, remoteRoot, "metadata.db", "metadata")
	writeTestFile(t, remoteRoot, "Author/Book (1)/book.epub", "payload")
	writeTestFile(t, remoteRoot, "static/library_index.zst", "old-index")
	fingerprint, _, err := libraryflow.SourceFingerprint(remoteRoot, nil)
	if err != nil {
		t.Fatal(err)
	}
	pointer, err := calibre.BindPointerCommit(calibre.PointerFile{
		Version: 1,
		Library: calibre.PointerFileLibrary{UUID: "550e8400-e29b-41d4-a716-446655440000", Librarian: "Alice"},
		Index:   calibre.PointerFileIndex{URL: "library_index.zst", NumBooks: 1},
	}, fingerprint, 47)
	if err != nil {
		t.Fatal(err)
	}
	if err := calibre.WritePointerDocument(filepath.Join(remoteRoot, filepath.FromSlash(memberPointerPath)), pointer); err != nil {
		t.Fatal(err)
	}
	var base [16]byte
	base[0] = 7
	if err := os.WriteFile(filepath.Join(remoteRoot, libraryflow.GenerationPath), torshare.EncodeGeneration(base, 47), 0o644); err != nil {
		t.Fatal(err)
	}
	writer := libraryflow.ClaimWriter("seat-old", "Alice laptop", time.Now(), nil)
	writerRaw, _ := writer.Marshal()
	writeTestFile(t, remoteRoot, libraryflow.WriterPath, string(writerRaw))

	local := t.TempDir()
	writeTestFile(t, local, "library_index.zst", "new-index")
	if err := calibre.WritePointerDocument(filepath.Join(local, "library_index.manifest.json"), calibre.PointerFile{
		Version: 1,
		Library: pointer.Library,
		Index: calibre.PointerFileIndex{
			URL: "library_index.zst", NumBooks: 1, PointerGeneration: 2,
			BaseGeneration: "07000000000000000000000000000000",
		},
	}); err != nil {
		t.Fatal(err)
	}
	if err := rclonexfer.SetCacheDir(accorderCacheDir()); err != nil {
		t.Fatal(err)
	}
	rclonexfer.Initialize()
	defer rclonexfer.Finalize()
	if err := uploadIndexAndGeneration(local, "library_index.zst", remoteRoot, calibre.Manifest{BaseGeneration: base, NumBooks: 1}, fingerprint); err != nil {
		t.Fatal(err)
	}
	gotWriter, err := os.ReadFile(filepath.Join(remoteRoot, libraryflow.WriterPath))
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(gotWriter, writerRaw) {
		t.Fatalf("writer changed\ngot %s\nwant %s", gotWriter, writerRaw)
	}
	gotIndex, err := os.ReadFile(filepath.Join(remoteRoot, "static", "library_index.zst"))
	if err != nil || string(gotIndex) != "new-index" {
		t.Fatalf("same-size derived repair retained old index: %q, %v", gotIndex, err)
	}
	after := (&libraryRemote{fsPath: remoteRoot}).inspect()
	if after.Err != nil || !after.Committed || after.Generation != 48 || after.SourceFingerprint != fingerprint {
		t.Fatalf("derived repair snapshot = %+v", after)
	}
}

func TestExplicitDerivedUploadOverwritesSameSizeObject(t *testing.T) {
	testSetup(t)
	localRoot := t.TempDir()
	remoteRoot := t.TempDir()
	writeTestFile(t, localRoot, "library_index.zst", "new-index")
	writeTestFile(t, remoteRoot, "static/library_index.zst", "old-index")
	if err := rclonexfer.SetCacheDir(accorderCacheDir()); err != nil {
		t.Fatal(err)
	}
	rclonexfer.Initialize()
	defer rclonexfer.Finalize()
	remote := &libraryRemote{fsPath: remoteRoot}
	if err := remote.uploadFileAs(localRoot, "library_index.zst", "static/library_index.zst"); err != nil {
		t.Fatal(err)
	}
	got, err := os.ReadFile(filepath.Join(remoteRoot, "static", "library_index.zst"))
	if err != nil || string(got) != "new-index" {
		t.Fatalf("explicit same-size repair retained old bytes: %q, %v", got, err)
	}
}

func TestDerivedRepairBootstrapRejectsInvalidWriterBeforeUpload(t *testing.T) {
	testSetup(t)
	remoteRoot := t.TempDir()
	writeTestFile(t, remoteRoot, "metadata.db", "metadata")
	writeTestFile(t, remoteRoot, libraryflow.WriterPath, `{"version":99,"state":"free"}`)
	fingerprint, _, err := libraryflow.SourceFingerprint(remoteRoot, nil)
	if err != nil {
		t.Fatal(err)
	}
	local, mf := makeDerivedRepairFamily(t)
	before, err := snapshotTree(remoteRoot)
	if err != nil {
		t.Fatal(err)
	}
	if err := rclonexfer.SetCacheDir(accorderCacheDir()); err != nil {
		t.Fatal(err)
	}
	rclonexfer.Initialize()
	defer rclonexfer.Finalize()
	err = uploadIndexAndGeneration(local, "library_index.zst", remoteRoot, mf, fingerprint)
	if err == nil || !strings.Contains(err.Error(), "invalid/unreadable _WRITER") {
		t.Fatalf("invalid bootstrap writer error = %v", err)
	}
	after, err := snapshotTree(remoteRoot)
	if err != nil {
		t.Fatal(err)
	}
	if before != after {
		t.Fatalf("invalid-writer bootstrap mutated remote\nbefore: %s\nafter: %s", before, after)
	}
}

func TestDerivedRepairBootstrapRejectsMissingSourceBeforeUpload(t *testing.T) {
	testSetup(t)
	remoteRoot := t.TempDir()
	local, mf := makeDerivedRepairFamily(t)
	before, err := snapshotTree(remoteRoot)
	if err != nil {
		t.Fatal(err)
	}
	if err := rclonexfer.SetCacheDir(accorderCacheDir()); err != nil {
		t.Fatal(err)
	}
	rclonexfer.Initialize()
	defer rclonexfer.Finalize()
	err = uploadIndexAndGeneration(local, "library_index.zst", remoteRoot, mf, "")
	if err == nil || !strings.Contains(err.Error(), "upload the library payload first") {
		t.Fatalf("missing bootstrap source error = %v", err)
	}
	after, err := snapshotTree(remoteRoot)
	if err != nil {
		t.Fatal(err)
	}
	if before != after {
		t.Fatalf("source-less bootstrap mutated remote\nbefore: %s\nafter: %s", before, after)
	}
}

func TestDerivedRepairBootstrapCommitsValidatedSource(t *testing.T) {
	testSetup(t)
	remoteRoot := t.TempDir()
	writeTestFile(t, remoteRoot, "metadata.db", "metadata")
	writeTestFile(t, remoteRoot, "Author/Book (1)/book.epub", "payload")
	fingerprint, err := localSourceFingerprintForContract(remoteRoot, nil, calibre.CatalogSourceContract)
	if err != nil {
		t.Fatal(err)
	}
	local, mf := makeDerivedRepairFamily(t)
	if err := rclonexfer.SetCacheDir(accorderCacheDir()); err != nil {
		t.Fatal(err)
	}
	rclonexfer.Initialize()
	defer rclonexfer.Finalize()
	if err := uploadIndexAndGeneration(local, "library_index.zst", remoteRoot, mf, fingerprint); err != nil {
		t.Fatal(err)
	}
	after := (&libraryRemote{fsPath: remoteRoot}).inspect()
	if after.Err != nil || !after.Committed || after.Generation != 1 || after.SourceFingerprint != fingerprint || after.Pointer.SourceContract != calibre.CatalogSourceContract {
		t.Fatalf("bootstrap snapshot = %+v", after)
	}
}

func makeDerivedRepairFamily(t *testing.T) (string, calibre.Manifest) {
	t.Helper()
	local := t.TempDir()
	writeTestFile(t, local, "library_index.zst", "new-index")
	var base [16]byte
	base[0] = 7
	mf := calibre.Manifest{BaseGeneration: base, NumBooks: 1}
	if err := calibre.WritePointerDocument(filepath.Join(local, "library_index.manifest.json"), calibre.PointerFile{
		Version: 1,
		Library: calibre.PointerFileLibrary{
			UUID:      "550e8400-e29b-41d4-a716-446655440000",
			Librarian: "Alice",
		},
		Index: calibre.PointerFileIndex{
			URL:               "library_index.zst",
			NumBooks:          1,
			PointerGeneration: 2,
			BaseGeneration:    "07000000000000000000000000000000",
		},
	}); err != nil {
		t.Fatal(err)
	}
	return local, mf
}

func TestCaptureCandidateDoesNotTouchSourceOrMachineState(t *testing.T) {
	testSetup(t)
	root := t.TempDir()
	writeTestFile(t, root, "metadata.db", "metadata")
	writeTestFile(t, root, "Author/Book (1)/book.epub", "payload")
	before, err := snapshotTree(root)
	if err != nil {
		t.Fatal(err)
	}
	candidate, err := captureExistingCandidate(root, nil)
	if err != nil {
		t.Fatal(err)
	}
	// Capture describes the library where it stands. Publishing a real
	// collection through a byte-for-byte copy cost tens of gigabytes and
	// minutes per run, and opened the very window its own immutability check
	// then aborted on.
	if candidate.Root != root {
		t.Fatalf("capture copied the library to %s instead of publishing %s in place", candidate.Root, root)
	}
	siblings, err := os.ReadDir(filepath.Dir(root))
	if err != nil {
		t.Fatal(err)
	}
	for _, sibling := range siblings {
		if strings.Contains(sibling.Name(), "candidate") {
			t.Errorf("capture left a copy of the library beside it: %s", sibling.Name())
		}
	}
	after, err := snapshotTree(root)
	if err != nil {
		t.Fatal(err)
	}
	if before != after {
		t.Fatalf("source changed during candidate capture\nbefore: %s\nafter: %s", before, after)
	}
	if _, err := os.Stat(machineStateDir()); !os.IsNotExist(err) {
		t.Fatalf("candidate capture created machine state: %v", err)
	}
}

func TestCaptureRefusesWhileCalibreHoldsTheLibrary(t *testing.T) {
	testSetup(t)
	root := t.TempDir()
	writeTestFile(t, root, "metadata.db", "metadata")
	writeTestFile(t, root, "Author/Book (1)/book.epub", "payload")

	// SQLite keeps these beside the database only while a connection is open
	// and removes them on the last close, so either one means Calibre is
	// still holding the library the publish is about to read and write.
	for _, marker := range calibreOpenMarkers {
		writeTestFile(t, root, marker, "open")
		_, err := captureExistingCandidate(root, nil)
		if err == nil || !strings.Contains(err.Error(), "close Calibre") {
			t.Fatalf("capture with %s present = %v, want a refusal naming Calibre", marker, err)
		}
		if err := os.Remove(filepath.Join(root, marker)); err != nil {
			t.Fatal(err)
		}
	}

	if _, err := captureExistingCandidate(root, nil); err != nil {
		t.Fatalf("capture of a closed library: %v", err)
	}
}

func TestLibPublishDryRunChangesNothingLocalOrRemote(t *testing.T) {
	library := testSetup(t)
	seedPublishCalibreLibrary(t, library)
	remoteRoot := t.TempDir()
	withLocalCommandRemote(t, remoteRoot)

	jsonlTarget := filepath.Join(accorderCacheDir(), "alice.jsonl")
	writeTestFile(t, accorderCacheDir(), "alice.jsonl", "retained-before\n")
	beforeLibrary, err := snapshotTree(library)
	if err != nil {
		t.Fatal(err)
	}
	beforeRemote, err := snapshotTree(remoteRoot)
	if err != nil {
		t.Fatal(err)
	}
	beforeJSONL, err := os.ReadFile(jsonlTarget)
	if err != nil {
		t.Fatal(err)
	}

	command := &LibPublishCmd{
		GroupLib: GroupLib{
			GroupLibDir: GroupLibDir{CalibreDirectory: library},
			Librarian:   "Alice",
			LibraryID:   "550e8400-e29b-41d4-a716-446655440000",
			JsonLPath:   jsonlTarget,
		},
		DryRun: true, MaxDeletes: 25,
	}
	command.ActionAlias = "alice"
	if err := command.Run(nil); err == nil || !strings.Contains(err.Error(), "lib build") {
		t.Fatalf("missing-build preview: %v", err)
	}

	// --dry-run previews the upload of what `lib build` already wrote; it does
	// not build. The library snapshot below is the whole contract: a build
	// would have left a browse site, an index family and a pointer in it.
	afterLibrary, _ := snapshotTree(library)
	afterRemote, _ := snapshotTree(remoteRoot)
	afterJSONL, err := os.ReadFile(jsonlTarget)
	if err != nil {
		t.Fatal(err)
	}
	if beforeLibrary != afterLibrary {
		t.Fatalf("dry-run changed library\nbefore: %s\nafter: %s", beforeLibrary, afterLibrary)
	}
	if beforeRemote != afterRemote {
		t.Fatalf("dry-run changed remote\nbefore: %s\nafter: %s", beforeRemote, afterRemote)
	}
	if !bytes.Equal(beforeJSONL, afterJSONL) {
		t.Fatalf("dry-run changed retained JSONL\nbefore: %q\nafter: %q", beforeJSONL, afterJSONL)
	}
	if _, err := os.Stat(machineStateDir()); !os.IsNotExist(err) {
		t.Fatalf("dry-run created machine state: %v", err)
	}

	// A real publish still refreshes the retained catalog, but only after the
	// remote commit succeeds.
	command.DryRun = false
	if err := command.Run(nil); err != nil {
		t.Fatal(err)
	}
	publishedJSONL, err := os.ReadFile(jsonlTarget)
	if err != nil {
		t.Fatal(err)
	}
	if bytes.Equal(publishedJSONL, beforeJSONL) || !bytes.Contains(publishedJSONL, []byte(`"title":"Book"`)) {
		t.Fatalf("successful publish did not refresh retained JSONL: %q", publishedJSONL)
	}
}

const publishCalibreTestSchema = `
CREATE TABLE books (id INTEGER PRIMARY KEY, title TEXT, sort TEXT, pubdate TEXT, last_modified TEXT, uuid TEXT, path TEXT);
CREATE TABLE data (id INTEGER PRIMARY KEY, book INTEGER, format TEXT, uncompressed_size INTEGER, name TEXT);
CREATE TABLE tags (id INTEGER PRIMARY KEY, name TEXT);
CREATE TABLE books_tags_link (book INTEGER, tag INTEGER);
CREATE TABLE authors (id INTEGER PRIMARY KEY, name TEXT);
CREATE TABLE books_authors_link (book INTEGER, author INTEGER);
CREATE TABLE publishers (id INTEGER PRIMARY KEY, name TEXT);
CREATE TABLE books_publishers_link (book INTEGER, publisher INTEGER);
CREATE TABLE series (id INTEGER PRIMARY KEY, name TEXT);
CREATE TABLE books_series_link (book INTEGER, series INTEGER);
CREATE TABLE languages (id INTEGER PRIMARY KEY, lang_code TEXT);
CREATE TABLE books_languages_link (book INTEGER, lang_code INTEGER);
CREATE TABLE comments (id INTEGER PRIMARY KEY, book INTEGER, text TEXT);
CREATE TABLE identifiers (book INTEGER, type TEXT, val TEXT);
`

func seedPublishCalibreLibrary(t *testing.T, root string) {
	t.Helper()
	db, err := sql.Open("sqlite", filepath.Join(root, "metadata.db"))
	if err != nil {
		t.Fatal(err)
	}
	for _, statement := range strings.Split(publishCalibreTestSchema, ";") {
		if strings.TrimSpace(statement) == "" {
			continue
		}
		if _, err := db.Exec(statement); err != nil {
			_ = db.Close()
			t.Fatal(err)
		}
	}
	statements := []string{
		`INSERT INTO books(id,title,sort,pubdate,last_modified,uuid,path) VALUES (1,'Book','Book','2020-01-01T00:00:00+00:00','2026-08-20T00:00:00+00:00','book-uuid','Author/Book (1)')`,
		`INSERT INTO data(id,book,format,uncompressed_size,name) VALUES (1,1,'EPUB',7,'Book - Author')`,
		`INSERT INTO authors(id,name) VALUES (1,'Author')`,
		`INSERT INTO books_authors_link(book,author) VALUES (1,1)`,
	}
	for _, statement := range statements {
		if _, err := db.Exec(statement); err != nil {
			_ = db.Close()
			t.Fatal(err)
		}
	}
	if err := db.Close(); err != nil {
		t.Fatal(err)
	}
	writeTestFile(t, root, "Author/Book (1)/Book - Author.epub", "payload")
}

func TestLibUploadBuildsMissingOrStaleCandidateBeforeUploading(t *testing.T) {
	library := testSetup(t)
	seedPublishCalibreLibrary(t, library)
	remoteRoot := t.TempDir()
	withLocalCommandRemote(t, remoteRoot)

	command := &LibUploadCmd{
		GroupLib: GroupLib{
			GroupLibDir: GroupLibDir{CalibreDirectory: library},
			Librarian:   "Alice",
			LibraryID:   "550e8400-e29b-41d4-a716-446655440000",
		},
		GroupS3Credentials: GroupS3Credentials{Bucket: "bucket/alice"},
		MaxDeletes:         libraryflow.DefaultMaxDeletes,
	}
	command.ActionAlias = "alice"
	if err := command.Run(nil); err != nil {
		t.Fatal(err)
	}
	if _, err := loadLocalChangeCandidate(library); err != nil {
		t.Fatalf("lib upload did not leave a reusable build checkpoint: %v", err)
	}
	snapshot := (&libraryRemote{fsPath: remoteRoot}).commitState()
	if snapshot.Err != nil || !snapshot.Committed || snapshot.Pointer.Index.NumBooks != 1 {
		t.Fatalf("lib upload did not publish its automatic build: %+v", snapshot)
	}

	db, err := sql.Open("sqlite", filepath.Join(library, "metadata.db"))
	if err != nil {
		t.Fatal(err)
	}
	statements := []string{
		`INSERT INTO books(id,title,sort,pubdate,last_modified,uuid,path) VALUES (2,'New Book','New Book','2020-01-01T00:00:00+00:00','2026-09-04T00:00:00+00:00','new-book-uuid','Author/New Book (2)')`,
		`INSERT INTO data(id,book,format,uncompressed_size,name) VALUES (2,2,'EPUB',11,'New Book - Author')`,
		`INSERT INTO books_authors_link(book,author) VALUES (2,1)`,
	}
	for _, statement := range statements {
		if _, err := db.Exec(statement); err != nil {
			_ = db.Close()
			t.Fatal(err)
		}
	}
	if err := db.Close(); err != nil {
		t.Fatal(err)
	}
	writeTestFile(t, library, "Author/New Book (2)/New Book - Author.epub", "new payload")

	if err := command.Run(nil); err != nil {
		t.Fatalf("lib upload did not rebuild a stale candidate: %v", err)
	}
	snapshot = (&libraryRemote{fsPath: remoteRoot}).commitState()
	if snapshot.Err != nil || !snapshot.Committed || snapshot.Pointer.Index.NumBooks != 2 {
		t.Fatalf("lib upload did not publish the book added after the previous build: %+v", snapshot)
	}
}

func TestPartialUploadRejectsSourceAndCoordinationPaths(t *testing.T) {
	testSetup(t)
	root := t.TempDir()
	command := &LibUploadCmd{GroupLib: GroupLib{GroupLibDir: GroupLibDir{CalibreDirectory: root}}}
	command.ActionAlias = "alice"
	for _, path := range []string{"metadata.db", "Author/Book (1)/book.epub", "_GENERATION", "_WRITER", "notes.txt"} {
		if err := command.runDerivedRepair([]string{path}); err == nil || !strings.Contains(err.Error(), "use `accorder lib publish alice`") {
			t.Errorf("runDerivedRepair(%q) error = %v", path, err)
		}
	}
	command.Files = []string{"static/library_index.zst"}
	command.DryRun = true
	if err := command.Run(nil); err == nil || !strings.Contains(err.Error(), "no files were changed") {
		t.Fatalf("partial dry-run error = %v", err)
	}
	if _, err := os.Stat(machineStateDir()); !os.IsNotExist(err) {
		t.Fatalf("partial dry-run created machine state: %v", err)
	}
}

func TestRecoverSyncActivationBeforeAndAfterRename(t *testing.T) {
	t.Run("record only keeps old destination", func(t *testing.T) {
		testSetup(t)
		parent := t.TempDir()
		destination := filepath.Join(parent, "library")
		stage := filepath.Join(parent, ".library-incoming-test")
		writeTestFile(t, destination, "metadata.db", "old")
		writeTestFile(t, stage, "metadata.db", "new")
		record := syncActivationRecord{
			Version: machineStateVersion, Alias: "alice", LibraryID: "uuid",
			Destination: destination, Stage: stage, RemoteSourceFingerprint: "remote", Generation: 7,
		}
		if err := writeJSONAtomic(syncActivationPath("alice"), record); err != nil {
			t.Fatal(err)
		}
		if err := recoverSyncActivation("alice"); err != nil {
			t.Fatal(err)
		}
		data, _ := os.ReadFile(filepath.Join(destination, "metadata.db"))
		if string(data) != "old" {
			t.Fatalf("destination changed before activation: %q", data)
		}
		if _, err := os.Stat(stage); !os.IsNotExist(err) {
			t.Fatalf("owned stage not removed: %v", err)
		}
		if baseline, _ := loadBaseline("alice"); baseline != nil {
			t.Fatalf("baseline written for old destination: %+v", baseline)
		}
	})

	t.Run("stage rename rolls forward", func(t *testing.T) {
		testSetup(t)
		parent := t.TempDir()
		destination := filepath.Join(parent, "library")
		stage := filepath.Join(parent, ".library-incoming-test")
		writeTestFile(t, stage, "metadata.db", "new")
		record := syncActivationRecord{
			Version: machineStateVersion, Alias: "alice", LibraryID: "uuid",
			Destination: destination, Stage: stage, RemoteSourceFingerprint: "remote", Generation: 7,
		}
		if err := writeJSONAtomic(syncActivationPath("alice"), record); err != nil {
			t.Fatal(err)
		}
		if err := recoverSyncActivation("alice"); err != nil {
			t.Fatal(err)
		}
		data, _ := os.ReadFile(filepath.Join(destination, "metadata.db"))
		if string(data) != "new" {
			t.Fatalf("stage did not activate: %q", data)
		}
		baseline, err := loadBaseline("alice")
		if err != nil || baseline == nil || baseline.Generation != 7 {
			t.Fatalf("baseline = %+v, %v", baseline, err)
		}
	})
}

func TestRequireExistingCalibreDirGuardsMistypedPaths(t *testing.T) {
	group := &GroupLibDir{}
	if err := group.RequireExistingCalibreDir(); err != nil {
		t.Fatalf("empty calibrepath is the interactive-search case, not an error: %v", err)
	}
	group.CalibreDirectory = filepath.Join(t.TempDir(), "Typo")
	if err := group.RequireExistingCalibreDir(); err == nil || !strings.Contains(err.Error(), "not an existing directory") {
		t.Fatalf("missing directory error = %v", err)
	}
	file := filepath.Join(t.TempDir(), "notadir")
	if err := os.WriteFile(file, []byte("x"), 0o644); err != nil {
		t.Fatal(err)
	}
	group.CalibreDirectory = file
	if err := group.RequireExistingCalibreDir(); err == nil || !strings.Contains(err.Error(), "not an existing directory") {
		t.Fatalf("plain-file error = %v", err)
	}
	group.CalibreDirectory = t.TempDir()
	if err := group.RequireExistingCalibreDir(); err != nil {
		t.Fatalf("existing directory rejected: %v", err)
	}
	// EnsureCalibreDir is how build/import/upload/publish/funnel reach the
	// guard; a provided path must fail there, not later in SQLite.
	group.CalibreDirectory = filepath.Join(t.TempDir(), "Gone")
	if err := group.EnsureCalibreDir(nil, "alias"); err == nil || !strings.Contains(err.Error(), "not an existing directory") {
		t.Fatalf("EnsureCalibreDir error = %v", err)
	}
}

func TestSafePublishCommitsMirrorsAndProtectsCoordination(t *testing.T) {
	t.Run("first publish commits pointer then sentinel and baseline", func(t *testing.T) {
		testSetup(t)
		remoteRoot := t.TempDir()
		candidate := makePublishCandidate(t, "550e8400-e29b-41d4-a716-446655440000", "payload")
		withLocalCommandRemote(t, remoteRoot)
		if err := publishCandidate("alice", "550e8400-e29b-41d4-a716-446655440000", GroupS3Credentials{}, candidate, publishOptions{
			MaxDeletes: libraryflow.DefaultMaxDeletes,
		}); err != nil {
			t.Fatal(err)
		}
		snapshot := (&libraryRemote{fsPath: remoteRoot}).inspect()
		if snapshot.Err != nil || !snapshot.Committed || snapshot.SourceFingerprint != candidate.SourceFingerprint {
			t.Fatalf("published snapshot = %+v", snapshot)
		}
		if snapshot.Writer.Kind != "valid" || snapshot.Writer.Marker.State != "claimed" || snapshot.Writer.Marker.PublishedAt == nil {
			t.Fatalf("writer = %+v", snapshot.Writer)
		}
		baseline, err := loadBaseline("alice")
		if err != nil || baseline == nil || baseline.RemoteSourceFingerprint != candidate.SourceFingerprint {
			t.Fatalf("baseline = %+v, %v", baseline, err)
		}
	})

	t.Run("dry-run mutates nothing and the delete backstop holds", func(t *testing.T) {
		testSetup(t)
		remoteRoot := t.TempDir()
		writeTestFile(t, remoteRoot, "metadata.db", "metadata")
		writeTestFile(t, remoteRoot, "Author/Book (1)/book.epub", "payload")
		writeTestFile(t, remoteRoot, "Author/Old (2)/old.epub", "delete-me")
		seedCommittedRemote(t, remoteRoot, 9)
		candidate := makePublishCandidate(t, "550e8400-e29b-41d4-a716-446655440000", "payload")
		withLocalCommandRemote(t, remoteRoot)
		before, err := snapshotTree(remoteRoot)
		if err != nil {
			t.Fatal(err)
		}

		// --dry-run asks rclone what it would do and writes nothing on either
		// side, including the machine state a real publish creates.
		if err := publishCandidate("alice", "550e8400-e29b-41d4-a716-446655440000", GroupS3Credentials{}, candidate, publishOptions{
			DryRun: true, LocalWins: true, MaxDeletes: libraryflow.DefaultMaxDeletes,
		}); err == nil || !strings.Contains(err.Error(), "lib build") {
			t.Fatalf("missing-build dry-run: %v", err)
		}
		after, _ := snapshotTree(remoteRoot)
		if before != after {
			t.Fatal("dry-run changed remote state")
		}
		if _, err := os.Stat(machineStateDir()); !os.IsNotExist(err) {
			t.Fatalf("dry-run created machine state: %v", err)
		}

		// MaxDeletes is rclone's backstop rather than a preflight: it aborts
		// the sync rather than refusing before it starts, so what it
		// guarantees is that the commit record is never written on top of a
		// shrink the librarian did not allow.
		if err := publishCandidate("alice", "550e8400-e29b-41d4-a716-446655440000", GroupS3Credentials{}, candidate, publishOptions{
			LocalWins: true, MaxDeletes: 0, AllowCompleteOverwrite: true,
		}); err == nil {
			t.Fatal("publish needing one deletion succeeded with --max-deletes=0")
		}
		if committed := (&libraryRemote{fsPath: remoteRoot}).commitState(); committed.Generation != 9 {
			t.Fatalf("aborted shrink advanced the commit record to generation %d", committed.Generation)
		}

		// Allowed, the same publish deletes the obsolete object and commits.
		if err := publishCandidate("alice", "550e8400-e29b-41d4-a716-446655440000", GroupS3Credentials{}, candidate, publishOptions{
			LocalWins: true, MaxDeletes: libraryflow.DefaultMaxDeletes, AllowCompleteOverwrite: true,
		}); err != nil {
			t.Fatalf("allowed shrink: %v", err)
		}
		if _, err := os.Stat(filepath.Join(remoteRoot, "Author/Old (2)/old.epub")); !os.IsNotExist(err) {
			t.Fatalf("obsolete object not deleted: %v", err)
		}
		if _, err := os.Stat(filepath.Join(remoteRoot, libraryflow.WriterPath)); err != nil {
			t.Fatalf("writer marker not written: %v", err)
		}
	})

	t.Run("the mirror never removes the coordination objects", func(t *testing.T) {
		testSetup(t)
		remoteRoot := t.TempDir()
		writeTestFile(t, remoteRoot, "metadata.db", "metadata")
		writeTestFile(t, remoteRoot, "Author/Book (1)/book.epub", "payload")
		seedCommittedRemote(t, remoteRoot, 3)
		writeTestFile(t, remoteRoot, "_IDENTITY", "installation-identity")
		candidate := makePublishCandidate(t, "550e8400-e29b-41d4-a716-446655440000", "payload")
		withLocalCommandRemote(t, remoteRoot)

		// _WRITER and _IDENTITY exist only on the remote. A mirror that could
		// see them would delete them as "not present locally" — which is how
		// the first run of the rclone-backed publish lost the writer seat.
		if err := publishCandidate("alice", "550e8400-e29b-41d4-a716-446655440000", GroupS3Credentials{}, candidate, publishOptions{
			LocalWins: true, MaxDeletes: libraryflow.DefaultMaxDeletes, AllowCompleteOverwrite: true,
		}); err != nil {
			t.Fatal(err)
		}
		for _, rel := range []string{libraryflow.WriterPath, "_IDENTITY"} {
			if _, err := os.Stat(filepath.Join(remoteRoot, rel)); err != nil {
				t.Errorf("mirror removed the remote-only %s: %v", rel, err)
			}
		}
		committed := (&libraryRemote{fsPath: remoteRoot}).commitState()
		if committed.Err != nil || !committed.Committed {
			t.Fatalf("commit record after publish = %+v", committed)
		}
	})
}

func TestFirstPublishAdoptsPrivateExcludesDiscoveredByBuild(t *testing.T) {
	testSetup(t)
	remoteRoot := t.TempDir()
	library := filepath.Join(t.TempDir(), "Alice Library")
	writeTestFile(t, library, "metadata.db", "metadata")
	writeTestFile(t, library, "Author/Book (1)/book.epub", "payload")
	writeTestFile(t, library, "Private/Only (2)/private.epub", "private")
	// No .motw-upload-excludes: this library has never been published, so
	// capture cannot know a book is private until the build reports it.

	candidate, err := captureExistingCandidate(library, resolveUploadExcludes(library, nil))
	if err != nil {
		t.Fatal(err)
	}
	captured := candidate.SourceFingerprint

	// Stand in for `lib build`: it renders the site, builds the index, and
	// writes the exclusion manifest for the book tagged private.
	writeTestFile(t, candidate.Root, "BROWSE_LIBRARY.html", "<html>site</html>")
	writeTestFile(t, candidate.Root, "static/library_index.zst", "index")
	private := []string{"/Private/Only (2)/**"}
	if err := writeUploadExcludes(candidate.Root, private); err != nil {
		t.Fatal(err)
	}
	if err := reconcileCandidateExcludes(candidate, private); err != nil {
		t.Fatalf("build that discovered a private book was rejected as source tampering: %v", err)
	}
	if candidate.SourceFingerprint == captured {
		t.Fatal("fingerprint stayed on the capture-time value; the private book is still counted as published source")
	}

	pointer := calibre.PointerFile{
		Version: 1,
		Library: calibre.PointerFileLibrary{UUID: "550e8400-e29b-41d4-a716-446655440000", Librarian: "Alice"},
		Index:   calibre.PointerFileIndex{URL: "library_index.zst", NumBooks: 1},
	}
	if err := calibre.WritePointerDocument(filepath.Join(candidate.Root, filepath.FromSlash(memberPointerPath)), pointer); err != nil {
		t.Fatal(err)
	}
	var base [16]byte
	base[0] = 3
	if err := os.WriteFile(filepath.Join(candidate.Root, libraryflow.GenerationPath), torshare.EncodeGeneration(base, 1), 0o644); err != nil {
		t.Fatal(err)
	}
	if candidate.Objects, err = listLocalObjects(candidate.Root); err != nil {
		t.Fatal(err)
	}

	withLocalCommandRemote(t, remoteRoot)
	if err := publishCandidate("alice", "550e8400-e29b-41d4-a716-446655440000", GroupS3Credentials{}, candidate, publishOptions{
		MaxDeletes: libraryflow.DefaultMaxDeletes,
	}); err != nil {
		t.Fatalf("first publish of a library with private books: %v", err)
	}
	if _, err := os.Stat(filepath.Join(remoteRoot, "Private", "Only (2)", "private.epub")); !os.IsNotExist(err) {
		t.Errorf("private book was uploaded: %v", err)
	}
	// The remote derives its fingerprint from the objects it actually received,
	// so it can only agree with the post-build value.
	snapshot := (&libraryRemote{fsPath: remoteRoot}).inspect()
	if snapshot.Err != nil || !snapshot.Committed || snapshot.SourceFingerprint != candidate.SourceFingerprint {
		t.Fatalf("published snapshot = %+v", snapshot)
	}

	// The mirrored manifest carries the discovery back, so the next run
	// captures under the same exclude set and the library reads as current.
	if got, err := os.ReadFile(filepath.Join(library, uploadExcludesFile)); err != nil || string(got) != "/Private/Only (2)/**\n" {
		t.Fatalf("exclusion manifest in the library = %q, %v", got, err)
	}
	settled, _, err := libraryflow.SourceFingerprint(library, resolveUploadExcludes(library, nil))
	if err != nil {
		t.Fatal(err)
	}
	if settled != candidate.SourceFingerprint {
		t.Fatalf("library does not read as published: %s != %s", settled, candidate.SourceFingerprint)
	}
}

func TestPublishLeavesLibraryAgreeingWithTheBucket(t *testing.T) {
	testSetup(t)
	remoteRoot := t.TempDir()
	library := filepath.Join(t.TempDir(), "Alice Library")
	writeTestFile(t, library, "metadata.db", "metadata")
	writeTestFile(t, library, "Author/Book (1)/book.epub", "payload")
	writeTestFile(t, library, "Private/Only (2)/private.epub", "private")
	// Steady state from an earlier build, carrying one glob for a directory
	// that no longer exists.
	writeTestFile(t, library, uploadExcludesFile, "/Private/Only (2)/**\n/Gone/Author (9)/**\n")

	candidate, err := captureExistingCandidate(library, resolveUploadExcludes(library, nil))
	if err != nil {
		t.Fatal(err)
	}

	// Stand in for `lib build`, which writes into the library itself: it
	// renders the site, rebuilds the index family, and rewrites the exclusion
	// manifest from the books actually tagged private.
	writeTestFile(t, candidate.Root, "BROWSE_LIBRARY.html", "<html>site</html>")
	writeTestFile(t, candidate.Root, "static/library_index.zst", "index")
	if err := writeUploadExcludes(candidate.Root, []string{"/Private/Only (2)/**"}); err != nil {
		t.Fatal(err)
	}
	pointer := calibre.PointerFile{
		Version: 1,
		Library: calibre.PointerFileLibrary{UUID: "550e8400-e29b-41d4-a716-446655440000", Librarian: "Alice"},
		Index:   calibre.PointerFileIndex{URL: "library_index.zst", NumBooks: 1},
	}
	if err := calibre.WritePointerDocument(filepath.Join(candidate.Root, filepath.FromSlash(memberPointerPath)), pointer); err != nil {
		t.Fatal(err)
	}
	var base [16]byte
	base[0] = 3
	if err := os.WriteFile(filepath.Join(candidate.Root, libraryflow.GenerationPath), torshare.EncodeGeneration(base, 4), 0o644); err != nil {
		t.Fatal(err)
	}
	candidate.Excludes = resolveUploadExcludes(candidate.Root, nil)
	if candidate.Objects, err = listLocalObjects(candidate.Root); err != nil {
		t.Fatal(err)
	}
	// The dropped glob matched nothing, so narrowing the manifest leaves the
	// candidate's source content — and its fingerprint — exactly as captured.
	rebuilt, _, err := libraryflow.SourceFingerprint(candidate.Root, candidate.Excludes)
	if err != nil {
		t.Fatal(err)
	}
	if rebuilt != candidate.SourceFingerprint {
		t.Fatalf("test fixture changed candidate source: %s != %s", rebuilt, candidate.SourceFingerprint)
	}

	withLocalCommandRemote(t, remoteRoot)
	if err := publishCandidate("alice", "550e8400-e29b-41d4-a716-446655440000", GroupS3Credentials{}, candidate, publishOptions{
		MaxDeletes: libraryflow.DefaultMaxDeletes,
	}); err != nil {
		t.Fatal(err)
	}

	// The library must agree with the bucket it just published to, pointer and
	// sentinel alike — not with the pre-commit generation the build stamped.
	snapshot := (&libraryRemote{fsPath: remoteRoot}).inspect()
	if snapshot.Err != nil || !snapshot.Committed {
		t.Fatalf("published snapshot = %+v", snapshot)
	}
	localGeneration, err := os.ReadFile(filepath.Join(library, libraryflow.GenerationPath))
	if err != nil {
		t.Fatal(err)
	}
	if _, generation, err := torshare.DecodeGeneration(localGeneration); err != nil || generation != snapshot.Generation {
		t.Errorf("library generation = %d (%v), want published %d", generation, err, snapshot.Generation)
	}
	localPointer, err := os.ReadFile(filepath.Join(library, filepath.FromSlash(memberPointerPath)))
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(localPointer, snapshot.PointerRaw) {
		t.Error("library pointer file does not match the published pointer")
	}

	// Publishing touches no source content — private books above all — so the
	// baseline this publish saved still describes the library.
	if body, err := os.ReadFile(filepath.Join(library, "Private", "Only (2)", "private.epub")); err != nil || string(body) != "private" {
		t.Fatalf("private book was disturbed: %q, %v", body, err)
	}
	baseline, err := loadBaseline("alice")
	if err != nil || baseline == nil {
		t.Fatalf("baseline = %+v, %v", baseline, err)
	}
	after, _, err := libraryflow.SourceFingerprint(library, resolveUploadExcludes(library, nil))
	if err != nil {
		t.Fatal(err)
	}
	if after != baseline.LocalSourceFingerprint {
		t.Fatalf("publish moved the library off its baseline: %s != %s", after, baseline.LocalSourceFingerprint)
	}
}

func TestLibSyncUsesCleanSnapshotPreservesPrivateAndLeavesSeat(t *testing.T) {
	testSetup(t)
	remoteRoot := t.TempDir()
	writeTestFile(t, remoteRoot, "metadata.db", "metadata")
	writeTestFile(t, remoteRoot, "Author/Keep (1)/keep.epub", "keep")
	writeTestFile(t, remoteRoot, "Author/Remove (2)/remove.epub", "remove")
	seedCommittedRemote(t, remoteRoot, 20)
	withLocalCommandRemote(t, remoteRoot)
	destination := filepath.Join(t.TempDir(), "Alice Library")
	command := &LibSyncCmd{
		GroupLib: GroupLib{
			GroupLibDir: GroupLibDir{CalibreDirectory: destination},
			LibraryID:   "550e8400-e29b-41d4-a716-446655440000",
		},
		ExpectedLibraryID: "550e8400-e29b-41d4-a716-446655440000",
	}
	command.ActionAlias = "alice"
	if err := command.Run(nil); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(filepath.Join(destination, "Author/Remove (2)/remove.epub")); err != nil {
		t.Fatalf("initial sync missing published file: %v", err)
	}
	if _, err := os.Stat(filepath.Join(remoteRoot, libraryflow.WriterPath)); !os.IsNotExist(err) {
		t.Fatalf("sync changed writer seat: %v", err)
	}

	writeTestFile(t, destination, "Private/Only (3)/private.epub", "private")
	writeTestFile(t, destination, uploadExcludesFile, "/Private/Only (3)/**\n")
	writeTestFile(t, destination, "local-notes.txt", "retain only in old tree")
	if err := os.Remove(filepath.Join(remoteRoot, "Author/Remove (2)/remove.epub")); err != nil {
		t.Fatal(err)
	}
	seedCommittedRemote(t, remoteRoot, 21)
	command.RemoteWins = true
	if err := command.Run(nil); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(filepath.Join(destination, "Author/Remove (2)/remove.epub")); !os.IsNotExist(err) {
		t.Fatalf("remote deletion survived in active clean snapshot: %v", err)
	}
	if _, err := os.Stat(filepath.Join(destination, "Private/Only (3)/private.epub")); err != nil {
		t.Fatalf("identified private content was not preserved: %v", err)
	}
	if _, err := os.Stat(filepath.Join(destination, "local-notes.txt")); !os.IsNotExist(err) {
		t.Fatalf("arbitrary local-only file was promoted into active snapshot: %v", err)
	}
	retained, err := filepath.Glob(destination + ".local-*")
	if err != nil || len(retained) != 1 {
		t.Fatalf("retained old tree = %v, %v", retained, err)
	}
	if _, err := os.Stat(filepath.Join(retained[0], "local-notes.txt")); err != nil {
		t.Fatalf("arbitrary local-only file missing from retained old tree: %v", err)
	}
	if _, err := os.Stat(filepath.Join(remoteRoot, libraryflow.WriterPath)); !os.IsNotExist(err) {
		t.Fatalf("fast-forward sync changed writer seat: %v", err)
	}
}

// TestLibSyncConvergedRefreshPreservesContentLedgerBaseline guards a converged
// `lib sync` (source unchanged, only the remote generation moved — the
// "derived repair" case) against silently discarding an existing
// content-ledger baseline. Dropping it would force the very next `lib build`
// into a coarse "missing-content-baseline" fallback for a library that never
// actually changed.
func TestLibSyncConvergedRefreshPreservesContentLedgerBaseline(t *testing.T) {
	testSetup(t)
	const libraryID = "550e8400-e29b-41d4-a716-446655440000"
	remoteRoot := t.TempDir()
	writeTestFile(t, remoteRoot, "metadata.db", "metadata")
	writeTestFile(t, remoteRoot, "Author/Book (1)/book.epub", "payload")
	seedCommittedRemote(t, remoteRoot, 1)
	withLocalCommandRemote(t, remoteRoot)

	destination := filepath.Join(t.TempDir(), "Alice Library")
	command := &LibSyncCmd{
		GroupLib: GroupLib{
			GroupLibDir: GroupLibDir{CalibreDirectory: destination},
			LibraryID:   libraryID,
		},
		ExpectedLibraryID: libraryID,
	}
	command.ActionAlias = "alice"
	if err := command.Run(nil); err != nil {
		t.Fatal(err)
	}

	// Establish a content-ledger baseline for the now-activated destination,
	// exactly as a `lib build` + `lib publish` cycle would have.
	fingerprint, _, err := libraryflow.SourceFingerprint(destination, nil)
	if err != nil {
		t.Fatal(err)
	}
	objects, err := listLocalObjects(destination)
	if err != nil {
		t.Fatal(err)
	}
	ledger, _, _, err := buildContentLedger(destination, objects, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	if len(ledger) == 0 {
		t.Fatal("test fixture produced an empty content ledger")
	}
	const checksum = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
	var base [16]byte
	base[0] = 5
	firstToken := torshare.EncodeGeneration(base, 1)
	if err := saveBaseline("alice", libraryBaseline{
		LibraryID: libraryID, RemoteSourceFingerprint: fingerprint, LocalSourceFingerprint: fingerprint,
		Generation: 1, GenerationToken: hex.EncodeToString(firstToken), CatalogChecksum: checksum,
		ContentLedgerVersion: sourceEvidenceVersion, ContentLedger: ledger, Evidence: func() *sourceEvidence {
			saved, err := loadBaseline("alice")
			if err != nil {
				t.Fatal(err)
			}
			return saved.Evidence
		}(),
	}); err != nil {
		t.Fatal(err)
	}

	// The remote generation moves with the source untouched (a derived
	// repair), so the pointer keeps its fingerprint and only its generation
	// number and the trailing sentinel advance.
	secondToken := torshare.EncodeGeneration(base, 2)
	if err := os.WriteFile(filepath.Join(remoteRoot, libraryflow.GenerationPath), secondToken, 0o644); err != nil {
		t.Fatal(err)
	}
	pointerPath := filepath.Join(remoteRoot, filepath.FromSlash(memberPointerPath))
	pointer, err := calibre.ReadPointerFile(pointerPath)
	if err != nil {
		t.Fatal(err)
	}
	pointer.Generation = 2
	if err := calibre.WritePointerDocument(pointerPath, pointer); err != nil {
		t.Fatal(err)
	}

	if err := command.Run(nil); err == nil || !strings.Contains(err.Error(), "Matching names and sizes") {
		t.Fatalf("unrecorded repair must not rebind coverage: %v", err)
	}

	refreshed, err := loadBaseline("alice")
	if err != nil || refreshed == nil {
		t.Fatalf("baseline = %+v, %v", refreshed, err)
	}
	if refreshed.Generation != 1 {
		t.Fatalf("baseline generation = %d, want 1", refreshed.Generation)
	}
	if refreshed.ContentLedgerVersion != sourceEvidenceVersion || len(refreshed.ContentLedger) != len(ledger) {
		t.Fatalf("converged sync dropped the content-ledger baseline: %+v", refreshed)
	}
	if refreshed.CatalogChecksum != checksum {
		t.Fatalf("catalog checksum = %q, want preserved %q", refreshed.CatalogChecksum, checksum)
	}
	if refreshed.GenerationToken != hex.EncodeToString(firstToken) {
		t.Fatalf("generation token = %q, want preserved %q", refreshed.GenerationToken, hex.EncodeToString(firstToken))
	}
}

func TestLibJoinRecoversPublishedLibraryInOneCommand(t *testing.T) {
	testSetup(t)
	remoteRoot := t.TempDir()
	writeTestFile(t, remoteRoot, "metadata.db", "metadata")
	writeTestFile(t, remoteRoot, "Author/Book (1)/book.epub", "payload")
	seedCommittedRemote(t, remoteRoot, 30)
	withLocalCommandRemote(t, remoteRoot)
	destination := filepath.Join(t.TempDir(), "Alice Library")
	invite := &fedlibinvite.WriteInvite{
		FedlibID: "fed", Backend: "s3", Prefix: "alice", Label: "Alice",
		LibraryID: "550e8400-e29b-41d4-a716-446655440000", DictID: 4,
		AccessKey: "AK", SecretKey: "SK",
		RemoteConfig: map[string]string{"provider": "Wasabi", "endpoint": "https://s3.test", "bucket": "motw"},
	}
	blob := fedlibinvite.EncodeWriteInvite(invite)
	_, ctx := parseCLI(t, []string{"lib", "join", "alice", "--invite", blob, "--passphrase", "pw", "--calibrepath", destination})
	join := &LibJoinCmd{
		CommonCommandFields: CommonCommandFields{ActionAlias: "alice"},
		Invite:              blob, Passphrase: "pw", CalibrePath: destination,
	}
	if err := join.Run(ctx); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(filepath.Join(destination, "metadata.db")); err != nil {
		t.Fatalf("recovered metadata.db: %v", err)
	}
	alias := readAlias(t, "alice")
	if got := alias.Get("lib.build.libraryID").String(); got != invite.LibraryID {
		t.Fatalf("active libraryID = %q", got)
	}
	if got := alias.Get("lib.build.calibrepath").String(); got != destination {
		t.Fatalf("active calibrepath = %q", got)
	}
	store, err := resolveJoinSecretsStore("pw")
	if err != nil {
		t.Fatal(err)
	}
	if _, err := store.Get(pendingJoinKey("alice")); !errors.Is(err, secrets.ErrKeyNotFound) {
		t.Fatalf("pending join remained after activation: %v", err)
	}
	if _, err := os.Stat(filepath.Join(remoteRoot, libraryflow.WriterPath)); !os.IsNotExist(err) {
		t.Fatalf("join recovery changed writer seat: %v", err)
	}
}

func TestLibJoinConflictKeepsEncryptedPendingBundleAndNoActivation(t *testing.T) {
	testSetup(t)
	config, err := sjson.SetBytes(loadActionAliases(), "alice.lib.build.libraryID", "11111111-2222-4333-8444-555555555555")
	if err != nil {
		t.Fatal(err)
	}
	saveActionAliases(config)
	invite := &fedlibinvite.WriteInvite{
		FedlibID: "fed", Backend: "s3", Prefix: "alice", Label: "Alice",
		LibraryID: "550e8400-e29b-41d4-a716-446655440000", DictID: 4,
		AccessKey: "AKIA_SENTINEL_JOIN_CONFLICT_ACCESS_KEY", SecretKey: "SK_SENTINEL_JOIN_CONFLICT_SECRET_KEY",
		RemoteConfig: map[string]string{"provider": "Wasabi", "endpoint": "https://s3.test", "bucket": "motw"},
	}
	blob := fedlibinvite.EncodeWriteInvite(invite)
	_, ctx := parseCLI(t, []string{"lib", "join", "alice", "--invite", blob, "--passphrase", "pw"})
	join := &LibJoinCmd{CommonCommandFields: CommonCommandFields{ActionAlias: "alice"}, Invite: blob, Passphrase: "pw"}
	// This fixture carries no protection signal and no reachable metadata.db,
	// so the refusal that applies is the adoption guard, not the membership
	// conflict — an unprotected alias with a real Calibre source is now allowed
	// to adopt. The guarantees below are what this test exists to pin down and
	// they hold for either refusal: nothing activated, pending bundle intact,
	// nothing in plaintext. TestLibJoinProtectedAliasRefusesConflictingIdentity
	// covers the membership-conflict refusal.
	if err := join.Run(ctx); err == nil || !strings.Contains(err.Error(), "would strand the cached catalog") {
		t.Fatalf("join refusal error = %v", err)
	}
	if got := readAlias(t, "alice").Get("lib.build.libraryID").String(); got != "11111111-2222-4333-8444-555555555555" {
		t.Fatalf("active identity changed to %q", got)
	}
	store, err := resolveJoinSecretsStore("pw")
	if err != nil {
		t.Fatal(err)
	}
	pendingRaw, err := store.Get(pendingJoinKey("alice"))
	if err != nil || !strings.Contains(pendingRaw, invite.LibraryID) {
		t.Fatalf("pending identity = %q, %v", pendingRaw, err)
	}
	if got, err := store.Get("alice/write/access-key"); err != nil || got != "AKIA_SENTINEL_JOIN_CONFLICT_ACCESS_KEY" {
		t.Fatalf("stored write credential = %q, %v", got, err)
	}
	onDisk, err := os.ReadFile(secretsStorePath())
	if err != nil {
		t.Fatal(err)
	}
	if bytes.Contains(onDisk, []byte(invite.LibraryID)) || bytes.Contains(onDisk, []byte("AKIA_SENTINEL_JOIN_CONFLICT_ACCESS_KEY")) {
		t.Fatal("pending identity or credential leaked in plaintext")
	}
}

func TestLibSeatClaimReleaseForceAndInvalidMarker(t *testing.T) {
	testSetup(t)
	remoteRoot := t.TempDir()
	withLocalCommandRemote(t, remoteRoot)
	claim := &LibSeatClaimCmd{}
	claim.ActionAlias = "alice"
	if err := claim.Run(); err != nil {
		t.Fatal(err)
	}
	installation, err := loadInstallation()
	if err != nil {
		t.Fatal(err)
	}
	writer := (&libraryRemote{fsPath: remoteRoot}).readWriter()
	if writer.Kind != "valid" || writer.Marker.SeatID != installation.SeatID {
		t.Fatalf("claimed writer = %+v", writer)
	}
	release := &LibSeatReleaseCmd{}
	release.ActionAlias = "alice"
	if err := release.Run(); err != nil {
		t.Fatal(err)
	}
	writer = (&libraryRemote{fsPath: remoteRoot}).readWriter()
	if writer.Kind != "valid" || writer.Marker.State != "free" {
		t.Fatalf("released writer = %+v", writer)
	}

	other := libraryflow.ClaimWriter("other-seat", "Old laptop", time.Now(), nil)
	otherRaw, _ := other.Marshal()
	writeTestFile(t, remoteRoot, libraryflow.WriterPath, string(otherRaw))
	if err := claim.Run(); err == nil || !strings.Contains(err.Error(), "--force") {
		t.Fatalf("other-seat claim error = %v", err)
	}
	claim.Force = true
	if err := claim.Run(); err != nil {
		t.Fatal(err)
	}
	writer = (&libraryRemote{fsPath: remoteRoot}).readWriter()
	if writer.Marker.SeatID != installation.SeatID {
		t.Fatalf("forced writer = %+v", writer)
	}

	invalid := []byte(`{"version":99,"state":"free"}`)
	writeTestFile(t, remoteRoot, libraryflow.WriterPath, string(invalid))
	if err := claim.Run(); err == nil || !strings.Contains(err.Error(), "invalid") {
		t.Fatalf("invalid marker force error = %v", err)
	}
	got, _ := os.ReadFile(filepath.Join(remoteRoot, libraryflow.WriterPath))
	if !bytes.Equal(got, invalid) {
		t.Fatal("forced claim overwrote invalid marker")
	}
}

func TestLibStatusExplainsCurrentWriterAndPrivateScope(t *testing.T) {
	testSetup(t)
	remoteRoot := t.TempDir()
	writeTestFile(t, remoteRoot, "metadata.db", "metadata")
	writeTestFile(t, remoteRoot, "Author/Book (1)/book.epub", "payload")
	seedCommittedRemote(t, remoteRoot, 40)
	withLocalCommandRemote(t, remoteRoot)
	installation, err := loadOrCreateInstallation()
	if err != nil {
		t.Fatal(err)
	}
	marker := libraryflow.ClaimWriter(installation.SeatID, installation.SeatLabel, time.Now(), nil)
	published := time.Date(2026, 8, 19, 12, 0, 0, 0, time.UTC)
	marker.PublishedAt = &published
	markerRaw, _ := marker.Marshal()
	writeTestFile(t, remoteRoot, libraryflow.WriterPath, string(markerRaw))

	local := t.TempDir()
	writeTestFile(t, local, "metadata.db", "metadata")
	writeTestFile(t, local, "Author/Book (1)/book.epub", "payload")
	writeTestFile(t, local, "Private/Only (2)/private.epub", "private")
	writeTestFile(t, local, uploadExcludesFile, "/Private/Only (2)/**\n")
	fingerprint, _, err := libraryflow.SourceFingerprint(local, resolveUploadExcludes(local, nil))
	if err != nil {
		t.Fatal(err)
	}
	if err := saveBaseline("alice", libraryBaseline{
		LibraryID: "550e8400-e29b-41d4-a716-446655440000", RemoteSourceFingerprint: fingerprint,
		LocalSourceFingerprint: fingerprint, Generation: 40, UpdatedAt: time.Now(),
	}); err != nil {
		t.Fatal(err)
	}
	status := &LibStatusCmd{GroupLib: GroupLib{GroupLibDir: GroupLibDir{CalibreDirectory: local}}}
	status.ActionAlias = "alice"
	stdout, _, err := captureInviteOutput(t, status.Run)
	if err != nil {
		t.Fatal(err)
	}
	for _, want := range []string{
		"Library alice: current",
		"Remote: 2 published books, generation 40, published 2026-08-19T12:00:00Z",
		"Writer: \"" + installation.SeatLabel + "\" (this seat)",
		"Private: 1 local-only book directory (not recoverable from the bucket)",
	} {
		if !strings.Contains(stdout, want) {
			t.Errorf("status missing %q:\n%s", want, stdout)
		}
	}
}

func makePublishCandidate(t *testing.T, libraryID, payload string) *libraryCandidate {
	t.Helper()
	root := t.TempDir()
	writeTestFile(t, root, "metadata.db", "metadata")
	writeTestFile(t, root, "Author/Book (1)/book.epub", payload)
	writeTestFile(t, root, "static/library_index.zst", "index")
	pointer := calibre.PointerFile{
		Version: 1,
		Library: calibre.PointerFileLibrary{UUID: libraryID, Librarian: "Alice"},
		Index:   calibre.PointerFileIndex{URL: "library_index.zst", NumBooks: 1, PointerGeneration: 1},
	}
	if err := calibre.WritePointerDocument(filepath.Join(root, filepath.FromSlash(memberPointerPath)), pointer); err != nil {
		t.Fatal(err)
	}
	var base [16]byte
	base[0] = 3
	if err := os.WriteFile(filepath.Join(root, libraryflow.GenerationPath), torshare.EncodeGeneration(base, 1), 0o644); err != nil {
		t.Fatal(err)
	}
	fingerprint, _, err := libraryflow.SourceFingerprint(root, nil)
	if err != nil {
		t.Fatal(err)
	}
	objects, err := listLocalObjects(root)
	if err != nil {
		t.Fatal(err)
	}
	return &libraryCandidate{Root: root, SourceFingerprint: fingerprint, Objects: objects}
}

func seedCommittedRemote(t *testing.T, root string, generation uint64) {
	t.Helper()
	fingerprint, _, err := libraryflow.SourceFingerprint(root, nil)
	if err != nil {
		t.Fatal(err)
	}
	pointer, err := calibre.BindPointerCommit(calibre.PointerFile{
		Version: 1,
		Library: calibre.PointerFileLibrary{UUID: "550e8400-e29b-41d4-a716-446655440000", Librarian: "Alice"},
		Index:   calibre.PointerFileIndex{URL: "library_index.zst", NumBooks: 2},
	}, fingerprint, generation)
	if err != nil {
		t.Fatal(err)
	}
	if err := os.MkdirAll(filepath.Join(root, "static"), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := calibre.WritePointerDocument(filepath.Join(root, filepath.FromSlash(memberPointerPath)), pointer); err != nil {
		t.Fatal(err)
	}
	var base [16]byte
	base[0] = 5
	if err := os.WriteFile(filepath.Join(root, libraryflow.GenerationPath), torshare.EncodeGeneration(base, generation), 0o644); err != nil {
		t.Fatal(err)
	}
}

func withLocalCommandRemote(t *testing.T, root string) {
	t.Helper()
	if err := rclonexfer.SetCacheDir(accorderCacheDir()); err != nil {
		t.Fatal(err)
	}
	rclonexfer.Initialize()
	previous := openLibraryRemoteForCommand
	openLibraryRemoteForCommand = func(string, GroupS3Credentials) (*libraryRemote, error) {
		return &libraryRemote{fsPath: root}, nil
	}
	t.Cleanup(func() {
		openLibraryRemoteForCommand = previous
		rclonexfer.Finalize()
	})
}

func writeTestFile(t *testing.T, root, rel, body string) {
	t.Helper()
	path := filepath.Join(root, filepath.FromSlash(rel))
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(path, []byte(body), 0o644); err != nil {
		t.Fatal(err)
	}
}

func snapshotTree(root string) (string, error) {
	objects, err := listLocalObjects(root)
	if err != nil {
		return "", err
	}
	var b strings.Builder
	for _, object := range objects {
		data, err := os.ReadFile(filepath.Join(root, filepath.FromSlash(object.Path)))
		if err != nil {
			return "", err
		}
		b.WriteString(object.Path)
		b.WriteByte(':')
		b.Write(data)
		b.WriteByte('\n')
	}
	return b.String(), nil
}

// A protected alias — one already wired into a federation — must still refuse a
// conflicting identity, with the same no-activation / pending-preserved
// guarantees as the adoption guard. This is the invariant the narrowed gate is
// not allowed to weaken: only aliases with no protection signal became joinable.
func TestLibJoinProtectedAliasRefusesConflictingIdentity(t *testing.T) {
	testSetup(t)
	config, err := sjson.SetBytes(loadActionAliases(), "alice.lib.build.libraryID", "11111111-2222-4333-8444-555555555555")
	if err != nil {
		t.Fatal(err)
	}
	// The protection signal: alice already belongs to a federation prefix.
	config, err = sjson.SetBytes(config, "alice.lib.build.fedlibPrefix", "alice")
	if err != nil {
		t.Fatal(err)
	}
	saveActionAliases(config)

	// Same prefix, so the pre-claim structural check passes and the post-claim
	// UUID gate is the thing under test.
	invite := &fedlibinvite.WriteInvite{
		FedlibID: "fed", Backend: "s3", Prefix: "alice", Label: "Alice",
		LibraryID: "550e8400-e29b-41d4-a716-446655440000", DictID: 4,
		AccessKey: "AKIA_SENTINEL_PROTECTED_CONFLICT", SecretKey: "SK_SENTINEL_PROTECTED_CONFLICT",
		RemoteConfig: map[string]string{"provider": "Wasabi", "endpoint": "https://s3.test", "bucket": "motw"},
	}
	blob := fedlibinvite.EncodeWriteInvite(invite)
	_, ctx := parseCLI(t, []string{"lib", "join", "alice", "--invite", blob, "--passphrase", "pw"})
	join := &LibJoinCmd{CommonCommandFields: CommonCommandFields{ActionAlias: "alice"}, Invite: blob, Passphrase: "pw"}

	if err := join.Run(ctx); err == nil || !strings.Contains(err.Error(), "already belongs") {
		t.Fatalf("protected conflict error = %v", err)
	}
	if got := readAlias(t, "alice").Get("lib.build.libraryID").String(); got != "11111111-2222-4333-8444-555555555555" {
		t.Fatalf("active identity changed to %q", got)
	}
}

// A protected alias whose stored prefix differs from the invite's is refused
// before the claim, so the single-use offer survives the refusal.
func TestLibJoinProtectedAliasPrefixMismatchRefusesPreClaim(t *testing.T) {
	testSetup(t)
	config, err := sjson.SetBytes(loadActionAliases(), "alice.lib.build.libraryID", "11111111-2222-4333-8444-555555555555")
	if err != nil {
		t.Fatal(err)
	}
	config, err = sjson.SetBytes(config, "alice.lib.build.fedlibPrefix", "alice")
	if err != nil {
		t.Fatal(err)
	}
	saveActionAliases(config)

	invite := &fedlibinvite.WriteInvite{
		FedlibID: "fed", Backend: "s3", Prefix: "somewhere-else", Label: "Alice",
		LibraryID: "550e8400-e29b-41d4-a716-446655440000", DictID: 4,
		AccessKey: "AKIA_SENTINEL_PREFIX_MISMATCH", SecretKey: "SK_SENTINEL_PREFIX_MISMATCH",
		RemoteConfig: map[string]string{"provider": "Wasabi", "endpoint": "https://s3.test", "bucket": "motw"},
	}
	blob := fedlibinvite.EncodeWriteInvite(invite)
	_, ctx := parseCLI(t, []string{"lib", "join", "alice", "--invite", blob, "--passphrase", "pw"})
	join := &LibJoinCmd{CommonCommandFields: CommonCommandFields{ActionAlias: "alice"}, Invite: blob, Passphrase: "pw"}

	err = join.Run(ctx)
	if err == nil || !strings.Contains(err.Error(), "already belongs to prefix") {
		t.Fatalf("prefix mismatch error = %v", err)
	}
	if !strings.Contains(err.Error(), "NOT claimed") {
		t.Errorf("refusal should tell the operator the invite survives:\n%v", err)
	}
	// Nothing was stored: the refusal precedes the credential write.
	store, serr := resolveJoinSecretsStore("pw")
	if serr != nil {
		t.Fatal(serr)
	}
	if got, gerr := store.Get("alice/write/access-key"); gerr == nil {
		t.Errorf("credentials written before a pre-claim refusal: %q", got)
	}
}

// The headline case: a librarian who already ran `lib build` under their own
// alias joins with that same alias. The locally minted UUID was never
// published, so the federation's identity replaces it instead of being refused.
func TestLibJoinLocalBuildAliasAdoptsFederationIdentity(t *testing.T) {
	testSetup(t)
	const priorUUID = "2163d6cb-d79c-4f26-ae31-a1fc04b46d21"
	const adoptedUUID = "532f7ab7-3e46-4488-a38f-63283e8d6ea2"

	libDir := t.TempDir()
	if err := os.WriteFile(filepath.Join(libDir, "metadata.db"), []byte("stub"), 0o644); err != nil {
		t.Fatal(err)
	}
	config, err := sjson.SetBytes(loadActionAliases(), "vtc.lib.build.libraryID", priorUUID)
	if err != nil {
		t.Fatal(err)
	}
	config, err = sjson.SetBytes(config, "vtc.lib.build.calibrepath", libDir)
	if err != nil {
		t.Fatal(err)
	}
	saveActionAliases(config)

	// No remote config, so the chained publish bails at its bucket check —
	// after identity activation, which is what this test is about.
	invite := &fedlibinvite.WriteInvite{
		FedlibID: "motw", Backend: "s3", Prefix: "vtc", Label: "VirtueTheCat",
		LibraryID: adoptedUUID, DictID: 29,
		AccessKey: "AKIA_SENTINEL_ADOPT", SecretKey: "SK_SENTINEL_ADOPT",
	}
	blob := fedlibinvite.EncodeWriteInvite(invite)
	_, ctx := parseCLI(t, []string{"lib", "join", "vtc", "--invite", blob, "--passphrase", "pw"})
	join := &LibJoinCmd{
		CommonCommandFields: CommonCommandFields{ActionAlias: "vtc"},
		Invite:              blob, Passphrase: "pw", CalibrePath: libDir,
	}

	_, stderr, runErr := captureInviteOutput(t, func() error { return join.Run(ctx) })
	if runErr == nil || !strings.Contains(runErr.Error(), "bucket") {
		t.Fatalf("expected the remote-config bail after adoption, got: %v", runErr)
	}
	if got := readAlias(t, "vtc").Get("lib.build.libraryID").String(); got != adoptedUUID {
		t.Fatalf("libraryID = %q, want the adopted %q", got, adoptedUUID)
	}
	if !strings.Contains(stderr, "adopting federation identity") {
		t.Errorf("adoption should say so on stderr:\n%s", stderr)
	}
	if !strings.Contains(stderr, priorUUID) {
		t.Errorf("adoption should name the replaced UUID:\n%s", stderr)
	}
	// The librarian's own calibrepath survives the join.
	if got := readAlias(t, "vtc").Get("lib.build.calibrepath").String(); got != libDir {
		t.Errorf("calibrepath = %q, want %q", got, libDir)
	}
}

// A stale classification must not authorize a swap: if the alias acquired a
// membership signal after it was classified, the compare-and-swap refuses.
func TestAuthorizeAdoptionRefusesStaleClassification(t *testing.T) {
	const priorUUID = "2163d6cb-d79c-4f26-ae31-a1fc04b46d21"
	decision := joinAliasDecision{Class: joinAliasLocalBuild, PriorUUID: priorUUID}
	changed := []byte(`{"vtc":{"lib":{"build":{
		"libraryID":"2163d6cb-d79c-4f26-ae31-a1fc04b46d21",
		"fedlibPrefix":"claimed-meanwhile"}}}}`)

	err := authorizeAdoption(changed, "vtc", decision, priorUUID, "532f7ab7-3e46-4488-a38f-63283e8d6ea2")
	if err == nil || !strings.Contains(err.Error(), "changed while the invite was being claimed") {
		t.Fatalf("stale classification error = %v", err)
	}
	if !strings.Contains(err.Error(), "nothing was built or published") {
		t.Errorf("refusal should state what was not done:\n%v", err)
	}
}

// The population that matters: a legacy alias predating 2695dc0 holds
// calibrepath only under lib.build (no lib.join node), and the generic
// backfill cannot reach LibJoinCmd's CalibrePath field. Join must adopt that
// path itself — proven here the same way the study proved recall: point it at
// a regular file and watch destination validation fire before any claim.
func TestLibJoinAdoptsLegacyBuildCalibrepath(t *testing.T) {
	testSetup(t)
	notADir := filepath.Join(t.TempDir(), "NOT_A_DIR")
	if err := os.WriteFile(notADir, []byte("x"), 0o644); err != nil {
		t.Fatal(err)
	}
	config, err := sjson.SetBytes(loadActionAliases(), "legacy.lib.build.calibrepath", notADir)
	if err != nil {
		t.Fatal(err)
	}
	saveActionAliases(config)

	_, ctx := parseCLI(t, []string{"lib", "join", "legacy", "--invite", "garbage", "--passphrase", "pw"})
	join := &LibJoinCmd{CommonCommandFields: CommonCommandFields{ActionAlias: "legacy"}, Invite: "garbage", Passphrase: "pw"}
	err = join.Run(ctx)
	if err == nil || !strings.Contains(err.Error(), "is not a directory") {
		t.Fatalf("join did not adopt the legacy lib.build.calibrepath (want destination validation to fire): %v", err)
	}
}
