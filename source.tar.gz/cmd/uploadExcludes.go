package cmd

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

const uploadExcludesFile = ".motw-upload-excludes"

func writeUploadExcludes(calibreDir string, globs []string) error {
	path := filepath.Join(calibreDir, uploadExcludesFile)
	if len(globs) == 0 {
		if err := os.Remove(path); err != nil && !os.IsNotExist(err) {
			return fmt.Errorf("clear upload-excludes: %w", err)
		}
		return nil
	}
	return os.WriteFile(path, []byte(strings.Join(globs, "\n")+"\n"), 0o644)
}

func readUploadExcludes(calibreDir string) []string {
	b, err := os.ReadFile(filepath.Join(calibreDir, uploadExcludesFile))
	if err != nil {
		return nil
	}
	var out []string
	for _, line := range strings.Split(string(b), "\n") {
		if s := strings.TrimSpace(line); s != "" {
			out = append(out, s)
		}
	}
	return out
}

func resolveUploadExcludes(calibreDir string, inProcess []string) []string {
	return mergeUploadExcludes(inProcess, readUploadExcludes(calibreDir))
}

// currentUploadExcludes returns the authoritative exclude set derived by the
// build that is running now. Unlike resolveUploadExcludes it deliberately does
// not merge the persisted previous build, because doing so keeps a formerly
// private book excluded for one extra generation.
func currentUploadExcludes(inProcess []string) []string {
	return mergeUploadExcludes(inProcess)
}

func mergeUploadExcludes(groups ...[]string) []string {
	seen := map[string]bool{}
	var out []string
	add := func(g string) {
		if g == "" || seen[g] {
			return
		}
		seen[g] = true
		out = append(out, g)
	}
	for _, group := range groups {
		for _, g := range group {
			add(g)
		}
	}
	add("/" + uploadExcludesFile)
	return out
}

func indexSiblingRel(calibreDir, indexPath, suffix string) string {
	if calibreDir == "" {
		return ""
	}
	if indexPath == "" {
		indexPath = filepath.Join(calibreDir, "static", "library_index")
	}
	absDir, err := filepath.Abs(calibreDir)
	if err != nil {
		return ""
	}
	absIndex, err := filepath.Abs(indexPath)
	if err != nil {
		return ""
	}
	rel, err := filepath.Rel(absDir, absIndex+suffix)
	if err != nil || rel == ".." || strings.HasPrefix(rel, ".."+string(filepath.Separator)) {
		return ""
	}
	return filepath.ToSlash(rel)
}

func privateDirsFromExcludes(excludes []string) []string {
	var dirs []string
	for _, g := range excludes {
		if d := strings.TrimSuffix(g, "/**"); d != g {
			dirs = append(dirs, strings.TrimPrefix(d, "/"))
		}
	}
	return dirs
}

// Directory exclusions are literal paths in the build checkpoint and source
// inventory (including legacy checkpoints). Escape only at the rclone boundary
// so filenames such as [Second] cannot become patterns matching other books.
// Keep non-directory rules, such as **.manifest.json, as intentional globs.
func rcloneUploadExcludes(excludes []string) []string {
	out := make([]string, len(excludes))
	for i, rule := range excludes {
		if strings.HasPrefix(rule, "/") && strings.HasSuffix(rule, "/**") {
			var escaped strings.Builder
			for _, c := range strings.TrimSuffix(rule, "/**") {
				if strings.ContainsRune(`\*?[]{}`, c) {
					escaped.WriteByte('\\')
				}
				escaped.WriteRune(c)
			}
			out[i] = escaped.String() + "/**"
		} else {
			out[i] = rule
		}
	}
	return out
}
