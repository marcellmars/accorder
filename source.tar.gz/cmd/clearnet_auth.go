package cmd

import (
	"context"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"sync"
	"time"
)

const authCookieName = "accorder_auth"

type grantInfo struct {
	Friend  string     `json:"friend"`
	Token   string     `json:"token"`
	Created time.Time  `json:"created"`
	Revoked bool       `json:"revoked"`
	Expires *time.Time `json:"expires,omitempty"`
}

type grantRegistry struct {
	mu         sync.RWMutex
	signingKey []byte
	grants     map[string]grantInfo
	filePath   string
	keyPath    string
	lastMod    time.Time
	lastCheck  time.Time
}

const grantReloadInterval = 2 * time.Second

func newGrantRegistry(stateDir string) (*grantRegistry, error) {
	keyPath := filepath.Join(stateDir, "signing.key")
	grantsPath := filepath.Join(stateDir, "grants.json")

	if err := os.MkdirAll(stateDir, 0700); err != nil {
		return nil, fmt.Errorf("auth: mkdir state: %w", err)
	}

	key, err := loadOrGenerateKey(keyPath)
	if err != nil {
		return nil, err
	}

	reg := &grantRegistry{
		signingKey: key,
		grants:     make(map[string]grantInfo),
		filePath:   grantsPath,
		keyPath:    keyPath,
		lastCheck:  time.Now(),
	}

	if data, err := os.ReadFile(grantsPath); err == nil {
		var grants []grantInfo
		if err := json.Unmarshal(data, &grants); err != nil {
			return nil, fmt.Errorf("auth: corrupt grants.json: %w", err)
		}
		for _, g := range grants {
			reg.grants[g.Token] = g
		}
		if info, err := os.Stat(grantsPath); err == nil {
			reg.lastMod = info.ModTime()
		}
	}
	return reg, nil
}

func loadOrGenerateKey(path string) ([]byte, error) {
	if data, err := os.ReadFile(path); err == nil {
		if len(data) != 32 {
			return nil, fmt.Errorf("auth: signing key at %s has wrong length %d (expected 32) — refusing to rotate", path, len(data))
		}
		return data, nil
	}
	key := make([]byte, 32)
	if _, err := rand.Read(key); err != nil {
		return nil, fmt.Errorf("auth: generate key: %w", err)
	}
	if err := os.WriteFile(path, key, 0600); err != nil {
		return nil, fmt.Errorf("auth: write key: %w", err)
	}
	log.Printf("auth: generated new signing key at %s", path)
	return key, nil
}

func (r *grantRegistry) maybeReload() {
	r.mu.RLock()
	sinceCheck := time.Since(r.lastCheck)
	r.mu.RUnlock()
	if sinceCheck < grantReloadInterval {
		return
	}

	info, err := os.Stat(r.filePath)
	if err != nil {
		return
	}

	r.mu.RLock()
	stale := info.ModTime().After(r.lastMod)
	r.mu.RUnlock()
	if !stale {
		r.mu.Lock()
		r.lastCheck = time.Now()
		r.mu.Unlock()
		return
	}

	data, err := os.ReadFile(r.filePath)
	if err != nil {
		return
	}
	var grants []grantInfo
	if err := json.Unmarshal(data, &grants); err != nil {
		log.Printf("auth: reload grants.json: %v (keeping current)", err)
		return
	}

	r.mu.Lock()
	r.grants = make(map[string]grantInfo, len(grants))
	for _, g := range grants {
		r.grants[g.Token] = g
	}
	r.lastMod = info.ModTime()
	r.lastCheck = time.Now()
	r.mu.Unlock()
	log.Printf("auth: reloaded %d grants from %s", len(grants), r.filePath)
}

func (r *grantRegistry) issue(friend string, expires *time.Time) (string, error) {
	tokenBytes := make([]byte, 32)
	if _, err := rand.Read(tokenBytes); err != nil {
		return "", fmt.Errorf("auth: generate token: %w", err)
	}
	token := hex.EncodeToString(tokenBytes)

	r.mu.Lock()
	r.grants[token] = grantInfo{
		Friend:  friend,
		Token:   token,
		Created: time.Now(),
		Expires: expires,
	}
	err := r.persist()
	r.mu.Unlock()
	return token, err
}

func (r *grantRegistry) revoke(friend string) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	for token, g := range r.grants {
		if g.Friend == friend && !g.Revoked {
			g.Revoked = true
			r.grants[token] = g
		}
	}
	return r.persist()
}

func (r *grantRegistry) list() []grantInfo {
	r.mu.RLock()
	defer r.mu.RUnlock()
	out := make([]grantInfo, 0, len(r.grants))
	for _, g := range r.grants {
		out = append(out, g)
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Created.Before(out[j].Created) })
	return out
}

func (r *grantRegistry) reset() error {
	r.mu.Lock()
	defer r.mu.Unlock()
	key := make([]byte, 32)
	if _, err := rand.Read(key); err != nil {
		return fmt.Errorf("auth: generate key: %w", err)
	}
	if err := os.WriteFile(r.keyPath, key, 0600); err != nil {
		return fmt.Errorf("auth: write key: %w", err)
	}
	r.signingKey = key
	r.grants = make(map[string]grantInfo)
	return r.persist()
}

func (r *grantRegistry) validate(token string) (string, bool) {
	r.maybeReload()
	r.mu.RLock()
	defer r.mu.RUnlock()
	g, ok := r.grants[token]
	if !ok || g.Revoked {
		return "", false
	}
	if g.Expires != nil && time.Now().After(*g.Expires) {
		return "", false
	}
	return g.Friend, true
}

func (r *grantRegistry) persist() error {
	grants := make([]grantInfo, 0, len(r.grants))
	for _, g := range r.grants {
		grants = append(grants, g)
	}
	data, _ := json.MarshalIndent(grants, "", "  ")
	tmp := r.filePath + ".tmp"
	if err := os.WriteFile(tmp, data, 0600); err != nil {
		return fmt.Errorf("auth: write grants: %w", err)
	}
	if err := os.Rename(tmp, r.filePath); err != nil {
		_ = os.Remove(tmp)
		return fmt.Errorf("auth: persist: %w", err)
	}
	return nil
}

func (r *grantRegistry) signCookie(token string) string {
	mac := hmac.New(sha256.New, r.signingKey)
	mac.Write([]byte(token))
	sig := hex.EncodeToString(mac.Sum(nil))
	return token + "." + sig
}

func (r *grantRegistry) verifyCookie(value string) (string, bool) {
	dot := -1
	for i := len(value) - 1; i >= 0; i-- {
		if value[i] == '.' {
			dot = i
			break
		}
	}
	if dot < 1 {
		return "", false
	}
	token := value[:dot]
	sig := value[dot+1:]

	mac := hmac.New(sha256.New, r.signingKey)
	mac.Write([]byte(token))
	expected := hex.EncodeToString(mac.Sum(nil))
	if !hmac.Equal([]byte(sig), []byte(expected)) {
		return "", false
	}

	friend, ok := r.validate(token)
	if !ok {
		return "", false
	}
	return friend, true
}

type grantIDKeyType struct{}

var grantIDKey = grantIDKeyType{}

// resolveGrant extracts and validates a grant credential from the request.
// ok=true → friend valid. invalid=true → a credential was presented but failed.
// via reports the credential source ("bearer" or "cookie") so callers can
// preserve source-specific log lines. Mirrors withAuth's original precedence:
// a present-but-bad bearer never falls through to the cookie.
func resolveGrant(r *http.Request, reg *grantRegistry) (friend, via string, ok, invalid bool) {
	if auth := r.Header.Get("Authorization"); auth != "" {
		const prefix = "Bearer "
		if len(auth) > len(prefix) && auth[:len(prefix)] == prefix {
			if friend, ok := reg.validate(auth[len(prefix):]); ok {
				return friend, "bearer", true, false
			}
		}
		return "", "bearer", false, true
	}
	if c, err := r.Cookie(authCookieName); err == nil {
		if friend, ok := reg.verifyCookie(c.Value); ok {
			return friend, "cookie", true, false
		}
		return "", "cookie", false, true
	}
	return "", "", false, false
}

func withAuth(next http.Handler, reg *grantRegistry) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		friend, via, ok, _ := resolveGrant(r, reg)
		if !ok {
			http.Error(w, "Unauthorized", http.StatusUnauthorized)
			return
		}
		log.Printf("auth: %s ok friend=%s path=%s", via, friend, r.URL.Path)
		ctx := context.WithValue(r.Context(), grantIDKey, friend)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

// withAuthTag validates a credential when present and tags the request context
// with the friend's grant identity, but NEVER rejects — public-mode shares
// stay public. Invalid credentials are logged and served anonymously.
func withAuthTag(next http.Handler, reg *grantRegistry) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		friend, via, ok, invalid := resolveGrant(r, reg)
		if ok {
			log.Printf("auth: tag %s friend=%s path=%s", via, friend, r.URL.Path)
			ctx := context.WithValue(r.Context(), grantIDKey, friend)
			next.ServeHTTP(w, r.WithContext(ctx))
			return
		}
		if invalid {
			log.Printf("auth: tag invalid %s credential path=%s (serving anonymously)", via, r.URL.Path)
		}
		next.ServeHTTP(w, r)
	})
}

func makeRedeemHandler(reg *grantRegistry) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		token := r.URL.Query().Get("token")
		if token == "" {
			http.Error(w, "missing token", http.StatusBadRequest)
			return
		}
		friend, ok := reg.validate(token)
		if !ok {
			http.Error(w, "invalid or revoked token", http.StatusUnauthorized)
			return
		}
		http.SetCookie(w, &http.Cookie{
			Name:     authCookieName,
			Value:    reg.signCookie(token),
			Path:     "/",
			HttpOnly: true,
			SameSite: http.SameSiteLaxMode,
			MaxAge:   86400, // 24h
		})
		w.Header().Set("Content-Type", "application/json")
		fmt.Fprintf(w, `{"status":"ok","friend":%q}`, friend)
	}
}
