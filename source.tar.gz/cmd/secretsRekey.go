package cmd

import (
	"accorder/pkg/secrets"
	"fmt"
	"os"
	"strings"

	"golang.org/x/term"
)

type SecretsCmd struct {
	Rekey SecretsRekeyCmd `cmd:"" help:"Convert the secrets store between passphrase and key-file modes." json:"rekey"`
}

type SecretsRekeyCmd struct {
	ToPassphrase bool   `name:"to-passphrase" xor:"target" help:"Re-encrypt under a passphrase (prompts twice unless --passphrase/env is set)." secret:"safe"`
	ToKeyFile    bool   `name:"to-key-file" xor:"target" help:"Re-encrypt under the secrets.key identity (generates the key file if missing)."`
	Passphrase   string `name:"passphrase" env:"ACCORDER_SECRETS_PASSPHRASE" help:"Passphrase side of the conversion: the source for --to-key-file, the target for --to-passphrase." secret:"redact"`
}

func (c *SecretsRekeyCmd) Run() error {
	storePath := secretsStorePath()
	if _, err := os.Stat(storePath); os.IsNotExist(err) {
		return fmt.Errorf("secrets rekey: no store at %s", storePath)
	}

	switch {
	case c.ToKeyFile:
		return c.rekeyToKeyFile(storePath)
	case c.ToPassphrase:
		return c.rekeyToPassphrase(storePath)
	default:
		return fmt.Errorf("secrets rekey: one of --to-key-file or --to-passphrase is required")
	}
}

func (c *SecretsRekeyCmd) rekeyToKeyFile(storePath string) error {
	passphrase, err := promptSecretsPassphrase(c.Passphrase)
	if err != nil {
		return fmt.Errorf("secrets rekey: %w", err)
	}
	entries, err := readAllSecrets(secrets.NewStore(storePath, passphrase))
	if err != nil {
		return fmt.Errorf("secrets rekey: open with passphrase: %w (is the store already in key-file mode?)", err)
	}

	id, err := loadOrGenerateSecretsKey(true)
	if err != nil {
		return fmt.Errorf("secrets rekey: %w", err)
	}
	if err := secrets.NewStoreWithIdentity(storePath, id).WriteAll(entries); err != nil {
		return fmt.Errorf("secrets rekey: %w", err)
	}
	fmt.Fprintf(os.Stderr, "secrets rekey: re-encrypted %d entr%s under %s (key-file mode)\n",
		len(entries), pluralYIes(len(entries)), secretsKeyPath())
	return nil
}

func (c *SecretsRekeyCmd) rekeyToPassphrase(storePath string) error {
	id, err := loadOrGenerateSecretsKey(false)
	if err != nil {
		if os.IsNotExist(err) {
			return fmt.Errorf("secrets rekey: no key file at %s — the store is already in passphrase mode", secretsKeyPath())
		}
		return fmt.Errorf("secrets rekey: %w", err)
	}
	entries, err := readAllSecrets(secrets.NewStoreWithIdentity(storePath, id))
	if err != nil {
		return fmt.Errorf("secrets rekey: open with key file: %w", err)
	}

	passphrase := c.Passphrase
	if passphrase == "" {
		passphrase, err = promptNewPassphraseTwice()
		if err != nil {
			return fmt.Errorf("secrets rekey: %w", err)
		}
	}
	if err := secrets.NewStore(storePath, passphrase).WriteAll(entries); err != nil {
		return fmt.Errorf("secrets rekey: %w", err)
	}
	fmt.Fprintf(os.Stderr, "secrets rekey: re-encrypted %d entr%s under a passphrase — %s no longer decrypts the store (remove it when ready)\n",
		len(entries), pluralYIes(len(entries)), secretsKeyPath())
	return nil
}

func readAllSecrets(store *secrets.Store) (map[string]string, error) {
	names, err := store.List()
	if err != nil {
		return nil, err
	}
	entries := make(map[string]string, len(names))
	for _, name := range names {
		val, err := store.Get(name)
		if err != nil {
			return nil, err
		}
		entries[name] = val
	}
	return entries, nil
}

func promptNewPassphraseTwice() (string, error) {
	fd := int(os.Stdin.Fd())
	if !term.IsTerminal(fd) {
		return "", fmt.Errorf("--passphrase or ACCORDER_SECRETS_PASSPHRASE is required (no terminal to prompt on)")
	}
	fmt.Fprint(os.Stderr, "New secrets-store passphrase: ")
	first, err := term.ReadPassword(fd)
	fmt.Fprintln(os.Stderr)
	if err != nil {
		return "", fmt.Errorf("read passphrase: %w", err)
	}
	fmt.Fprint(os.Stderr, "Repeat passphrase: ")
	second, err := term.ReadPassword(fd)
	fmt.Fprintln(os.Stderr)
	if err != nil {
		return "", fmt.Errorf("read passphrase: %w", err)
	}
	p := strings.TrimSpace(string(first))
	if p == "" {
		return "", fmt.Errorf("empty passphrase")
	}
	if p != strings.TrimSpace(string(second)) {
		return "", fmt.Errorf("passphrases do not match")
	}
	return p, nil
}

func pluralYIes(n int) string {
	if n == 1 {
		return "y"
	}
	return "ies"
}
