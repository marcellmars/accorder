package cmd

import (
	"bytes"
	"fmt"
	"sort"
	"strings"

	"accorder/pkg/libraryflow"
	"accorder/pkg/rclonexfer"
)

// Compare both commit objects, including the deliberately mixed state between
// our pointer and sentinel writes. Writer ownership alone is not version
// authority. These are bounded reads, not a remote inventory scan or a CAS.
func requireRemoteCommitBytes(remote *libraryRemote, pointer, generation []byte) error {
	for _, expected := range []struct {
		path string
		raw  []byte
	}{
		{memberPointerPath, pointer}, {libraryflow.GenerationPath, generation},
	} {
		raw, present, err := readOptionalRemote(remote, expected.path, 4<<20)
		if err != nil {
			return err
		}
		if present != (len(expected.raw) > 0) || !bytes.Equal(raw, expected.raw) {
			return fmt.Errorf("remote library changed since publication was approved (%s); no further cleanup or activation is allowed", expected.path)
		}
	}
	return nil
}

func canFinishUploadedCleanup(record publishRecoveryRecord) bool {
	if record.Version != sourceEvidenceVersion || record.ContentLedgerVersion != sourceEvidenceVersion || len(record.PrivateCleanupTargets) == 0 {
		return false
	}
	switch record.Stage {
	case "private-cleanup", "payload-complete", "manifest-complete", "pointer-complete", "committed":
		return true
	}
	return false
}

func verifyPublishRecoverySource(root string, record publishRecoveryRecord, options publishOptions) error {
	if options.FinishInterruptedPublish && canFinishUploadedCleanup(record) {
		// The private-cleanup journal is written only after mirror, forced
		// copies and source verification have finished. Explicitly finish THAT
		// uploaded snapshot, not the changed local tree. Save its original
		// ledger/evidence as the baseline so subsequent edits remain pending.
		if err := validateSourceEvidence(record.ContentLedger, record.Evidence); err != nil {
			return err
		}
		fingerprint, err := sourceFingerprintFromContentLedger(record.ContentLedger)
		if err != nil || fingerprint != record.SourceFingerprint {
			return fmt.Errorf("saved uploaded snapshot is inconsistent; recovery retained: %v", err)
		}
		return nil
	}
	if err := verifyRecoverySource(root, record); err != nil {
		if canFinishUploadedCleanup(record) {
			return fmt.Errorf("%w; to finish the snapshot already uploaded, run `accorder lib publish %s --finish-interrupted-publish`; later local edits will remain pending", err, record.Alias)
		}
		return err
	}
	return nil
}

// privateCleanupDirs accepts only the literal, anchored book-directory rules
// produced by the build. Never turn arbitrary exclusion globs into deletions.
func privateCleanupDirs(excludes []string) ([]string, error) {
	seen := make(map[string]bool)
	var dirs []string
	for _, rule := range excludes {
		if !strings.HasSuffix(rule, "/**") {
			continue
		}
		dir := strings.TrimSuffix(strings.TrimPrefix(rule, "/"), "/**")
		normalized, err := libraryflow.NormalizePath(dir)
		if err != nil || normalized != dir || !strings.HasPrefix(rule, "/") ||
			!strings.Contains(dir, "/") || strings.ContainsAny(dir, "\\\r\n") ||
			!libraryflow.IsSourcePath(dir) {
			return nil, fmt.Errorf("cannot safely remove private files for exclusion %q; rebuild the library with valid book directory paths", rule)
		}
		if !seen[dir] {
			seen[dir] = true
			dirs = append(dirs, dir)
		}
	}
	sort.Strings(dirs)
	// Avoid listing overlapping prefixes twice.
	var roots []string
	for _, dir := range dirs {
		nested := false
		for _, root := range roots {
			nested = nested || strings.HasPrefix(dir, root+"/")
		}
		if !nested {
			roots = append(roots, dir)
		}
	}
	return roots, nil
}

func planPrivateCleanup(remote *libraryRemote, dirs []string) ([]rclonexfer.RemoteObject, error) {
	var targets []rclonexfer.RemoteObject
	for _, dir := range dirs {
		objects, err := rclonexfer.ListDirectoryObjects(remote.fsPath, dir)
		if err != nil {
			return nil, fmt.Errorf("list remotely published private files: %w", err)
		}
		for _, object := range objects {
			path, err := libraryflow.NormalizePath(object.Path)
			if err != nil || path != object.Path || strings.Contains(path, "\\") || !strings.HasPrefix(path, dir+"/") {
				return nil, fmt.Errorf("unsafe private cleanup object %q outside directory %q", object.Path, dir)
			}
			if !libraryflow.IsProtectedPath(path) {
				targets = append(targets, object)
			}
		}
	}
	return targets, nil
}

// executePrivateCleanup is shared by publication and crash recovery. Absence
// means a prior attempt already removed the file, never permission to expand
// the durable plan or its originally approved deletion budget.
func executePrivateCleanup(remote *libraryRemote, dirs, approved []string, maxDeletes int, guard func() error) error {
	allowed := make(map[string]bool, len(approved))
	for _, path := range approved {
		normalized, err := libraryflow.NormalizePath(path)
		inside := false
		for _, dir := range dirs {
			inside = inside || strings.HasPrefix(path, dir+"/")
		}
		if err != nil || path != normalized || strings.Contains(path, "\\") || !inside || libraryflow.IsProtectedPath(path) {
			return fmt.Errorf("unsafe saved private cleanup target %q", path)
		}
		allowed[path] = true
	}
	remaining, err := planPrivateCleanup(remote, dirs)
	if err != nil {
		return err
	}
	if maxDeletes < 0 || len(remaining) > maxDeletes {
		return fmt.Errorf("private cleanup needs %d remaining remote deletions, exceeding --max-deletes=%d; no private files were removed", len(remaining), maxDeletes)
	}
	for _, object := range remaining {
		if !allowed[object.Path] {
			return fmt.Errorf("private file %q appeared after cleanup approval; saved publication retained for reconciliation", object.Path)
		}
	}
	for _, object := range remaining {
		if err := guard(); err != nil {
			return err
		}
		if err := rclonexfer.DeleteFile(remote.fsPath, object.Path); err != nil {
			return fmt.Errorf("remove remotely published private file %q: %w", object.Path, err)
		}
		fmt.Printf("Removed remotely published private file: %s (local file retained)\n", object.Path)
		if err := runPublishCommitStageHook("after-private-delete"); err != nil {
			return err
		}
	}
	return nil
}
