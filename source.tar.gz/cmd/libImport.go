package cmd

import (
	"accorder/pkg/bibtexjson"
	"accorder/pkg/calibre"
	"context"
	"fmt"
	"os"

	"github.com/alecthomas/kong"
)

type LibImportCmd struct {
	CommonCommandFields
	ZoteroPath string `name:"zotero-path" short:"z" json:"zotero-path" help:"Path to a BetterBibTeX JSON export directory." validate:"required,dir"`
	Prune      *bool  `name:"prune" short:"p" json:"-" help:"Remove books imported under this alias that are absent from the current export."`
	Yes        *bool  `name:"yes" short:"y" json:"-" help:"Assume yes to confirmations (Calibre shutdown, --prune)."`
	GroupLibDir
	TeaOutputs
}

func (c *LibImportCmd) Run(ctx *kong.Context) error {
	c.Header = ".◟◜lib import◝◞."
	if c.HandleShowConfig(c) {
		return nil
	}
	if err := c.EnsureCalibreDir(ctx, c.ActionAlias); err != nil {
		return err
	}

	confirm := promptYesNo
	if c.Yes != nil && *c.Yes {
		confirm = func(string) bool { return true }
	}

	jsonPath, baseDir, err := calibre.LocateBetterBibTexExport(c.ZoteroPath)
	if err != nil {
		return fmt.Errorf("locate export: %w", err)
	}
	data, err := os.ReadFile(jsonPath)
	if err != nil {
		return fmt.Errorf("read export: %w", err)
	}
	bbt, err := bibtexjson.UnmarshalBetterBibTex(data)
	if err != nil {
		return fmt.Errorf("parse export: %w", err)
	}

	entries := calibre.EntriesFromBetterBibTex(bbt, baseDir)
	if len(entries) == 0 {
		fmt.Println("No importable items found in export.")
		return nil
	}

	exe := &calibre.CalibreExe{LibraryPath: c.CalibreDirectory}
	bundle := calibre.Bundle{Alias: c.ActionAlias, ExportID: string(bbt.Config.ID)}
	prune := c.Prune != nil && *c.Prune
	bgCtx := context.Background()

	if err := calibre.PreflightCalibre(bgCtx, confirm); err != nil {
		return err
	}

	stats, err := calibre.SyncEntries(bgCtx, exe, entries, bundle, prune, confirm)
	if err != nil {
		return fmt.Errorf("sync: %w", err)
	}

	if stats.Added > 0 || stats.Updated > 0 {
		if err := calibre.StampDefaultCovers(bgCtx, exe); err != nil {
			return fmt.Errorf("stamp covers: %w", err)
		}
	}

	fmt.Println(stats.Summary())
	if stats.Orphaned > 0 {
		fmt.Printf(">>>> %d book(s) imported under %q are no longer in this export — re-run with --prune to remove them\n",
			stats.Orphaned, c.ActionAlias)
	}
	return nil
}
