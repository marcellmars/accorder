package cmd

import (
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"sync/atomic"
	"testing"

	"accorder/pkg/secrets"
)

// A URL invite is a single-use offer that the claim POST burns on receipt.
// lib join must validate the secrets store BEFORE claiming, so an unusable store
// (here: a passphrase-protected store opened with the wrong passphrase) fails
// without spending the offer — and the error points at the escape hatches.
func TestLibJoin_UnusableStore_FailsBeforeClaim(t *testing.T) {
	dir := t.TempDir()
	accorderConfigDir = dir

	// Existing store sealed under "correct"; the join below supplies "wrong".
	storePath := filepath.Join(dir, "secrets.age")
	if err := secrets.NewStore(storePath, "correct").Set("probe", "x"); err != nil {
		t.Fatal(err)
	}

	var claimed atomic.Bool
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodPost && strings.HasSuffix(r.URL.Path, "/claim") {
			claimed.Store(true)
			w.WriteHeader(http.StatusOK)
			_, _ = w.Write([]byte(`{"version":1,"invite":"accorder-fedlib-invite:x"}`))
		}
	}))
	defer srv.Close()

	join := &LibJoinCmd{Invite: srv.URL + "/invite/tok", CommonCommandFields: CommonCommandFields{ActionAlias: "x"}, Passphrase: "wrong"}
	err := join.Run(nil)
	if err == nil {
		t.Fatal("want error for an unusable secrets store, got nil")
	}
	if !strings.Contains(err.Error(), "secrets rekey") {
		t.Errorf("error should point to the rekey escape hatch, got: %v", err)
	}
	if claimed.Load() {
		t.Error("offer was claimed despite the unusable store — the claim must come AFTER store validation")
	}
}
