//go:build !tailscale

package cmd

import (
	"reflect"
	"testing"
)

func TestOnFlag_EmptyDefault_NoIntercept(t *testing.T) {

	// BeforeApply on an empty onFlagInterceptor must return nil without
	// triggering SSH execution. This is critical because BeforeApply fires
	// for default values too (confirmed in spike A2).
	var o onFlagInterceptor
	if string(o) != "" {
		t.Fatal("zero-value onFlagInterceptor should be empty string")
	}

	// We can't call BeforeApply directly without a kong.Kong, but we
	// verify the guard condition: an empty interceptor does nothing.
	// The real integration test is TestOnFlag_DoesNotConflictOnSubcommands.
}

func TestOnFlag_ArgsReconstruction_SeparateValue(t *testing.T) {
	args := []string{"--on", "myserver", "fedlib", "build", "lib", "--output-path", "/tmp"}
	got := stripOnFlag(args)
	want := []string{"fedlib", "build", "lib", "--output-path", "/tmp"}
	if !reflect.DeepEqual(got, want) {
		t.Errorf("stripOnFlag(%v) = %v, want %v", args, got, want)
	}
}

func TestOnFlag_ArgsReconstruction_EqualsValue(t *testing.T) {
	args := []string{"--on=myserver", "fedlib", "build", "lib", "--output-path", "/tmp"}
	got := stripOnFlag(args)
	want := []string{"fedlib", "build", "lib", "--output-path", "/tmp"}
	if !reflect.DeepEqual(got, want) {
		t.Errorf("stripOnFlag(%v) = %v, want %v", args, got, want)
	}
}

func TestOnFlag_ArgsReconstruction_MidArgs(t *testing.T) {

	// --on can appear anywhere in the arg list (it's a global flag).
	args := []string{"fedlib", "--on", "myserver", "build", "lib"}
	got := stripOnFlag(args)
	want := []string{"fedlib", "build", "lib"}
	if !reflect.DeepEqual(got, want) {
		t.Errorf("stripOnFlag(%v) = %v, want %v", args, got, want)
	}
}

func TestOnFlag_ArgsReconstruction_NoOnFlag(t *testing.T) {
	args := []string{"fedlib", "build", "lib", "--output-path", "/tmp"}
	got := stripOnFlag(args)
	want := []string{"fedlib", "build", "lib", "--output-path", "/tmp"}
	if !reflect.DeepEqual(got, want) {
		t.Errorf("stripOnFlag(%v) = %v, want %v", args, got, want)
	}
}

func TestOnFlag_ArgsReconstruction_VersionOnly(t *testing.T) {
	args := []string{"--on", "myserver", "--version"}
	got := stripOnFlag(args)
	want := []string{"--version"}
	if !reflect.DeepEqual(got, want) {
		t.Errorf("stripOnFlag(%v) = %v, want %v", args, got, want)
	}
}

func TestExtractOnValue(t *testing.T) {

	// Regression: Kong assigns a flag's parsed value to the receiver only
	// AFTER BeforeApply runs, so onFlagInterceptor.BeforeApply cannot read the
	// server name from its receiver (it is always ""). The value must come from
	// os.Args via extractOnValue. The original implementation read string(o)
	// and silently ran every --on command locally — caught only by an in-wild
	// test against a real server.
	cases := []struct {
		name string
		args []string
		want string
	}{
		{"separate value", []string{"--on", "myserver", "fedlib", "build"}, "myserver"},
		{"equals value", []string{"--on=myserver", "fedlib", "build"}, "myserver"},
		{"mid args", []string{"fedlib", "--on", "myserver", "build"}, "myserver"},
		{"absent", []string{"fedlib", "build", "lib"}, ""},
		{"dangling --on at end", []string{"fedlib", "build", "--on"}, ""},
		{"empty equals", []string{"--on=", "fedlib"}, ""},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			if got := extractOnValue(tc.args); got != tc.want {
				t.Errorf("extractOnValue(%v) = %q, want %q", tc.args, got, tc.want)
			}
		})
	}
}

func TestShellQuote(t *testing.T) {

	// ssh re-parses its joined arguments through the remote shell, so args with
	// spaces or metacharacters must survive as single literal tokens.
	cases := []struct {
		in   string
		want string
	}{
		{"plain", "'plain'"},
		{"/my library", "'/my library'"},
		{"a'b", `'a'\''b'`},
		{"rm -rf /; echo", "'rm -rf /; echo'"},
	}
	for _, tc := range cases {
		if got := shellQuote(tc.in); got != tc.want {
			t.Errorf("shellQuote(%q) = %q, want %q", tc.in, got, tc.want)
		}
	}
}

func TestOnFlag_DoesNotConflictOnSubcommands(t *testing.T) {

	// Verify that adding On to Globals doesn't break parsing of existing
	// subcommands when --on is not provided.
	testSetup(t)
	libDir := t.TempDir()

	// Parse a representative command without --on.
	_, _ = parseCLI(t, []string{
		"lib", "build", "test-alias",
		"--calibrepath", libDir,
	})

	// If we get here, parseCLI didn't fatal — the On field doesn't conflict.
}
