package cmd

import (
	"accorder/pkg/calibre"
	"accorder/pkg/libraryflow"
	"accorder/pkg/rclonexfer"
	"accorder/pkg/torshare"
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"

	"github.com/tidwall/sjson"
)

// FedlibMembersReindexCmd assigns each member a unique per-member DictID (so the
// aggregate splice path composes instead of falling back to the monolithic OOM
// rebuild) and rebuilds + re-uploads that member's index carrying the new DictID
// AND a RecencyIndex (CompressToFile writes it). The re-stamp is content-neutral:
// it rebuilds from the member's own display JSONL, so no source / cover re-fetch.
//
// MEMORY: rebuilding a member materializes that member's books (BuildIndex +
// CompressToFile). Run this from an operator machine with adequate RAM, not from
// a memory-constrained serving box — a large member can use ~1 GB transiently.
type FedlibMembersReindexCmd struct {
	FedlibID string `arg:"" name:"fedlib-id" help:"Federation identifier (see 'fedlib config set')."`
	// OutputPath is accepted but not consulted: the registry path comes from
	// the descriptor (resolveFedlibRegistryPath with an empty override).
	// validate:"omitempty" keeps the ca-127 parse-time enforcement from
	// demanding a flag whose value this command never reads.
	OutputPath  string   `name:"output-path" help:"Path to the fedlib output directory (currently unused: the registry location comes from the federation descriptor)." validate:"omitempty"`
	DryRun      bool     `name:"dry-run" help:"List members that need DictID assignment without rebuilding."`
	Force       bool     `name:"force" help:"Reassign DictIDs for ALL members, not just legacy (DictID < 2)."`
	Prefixes    []string `name:"prefix" help:"Reindex only these member prefix(es) (repeatable) — targeted repair (e.g. a stale member), healed regardless of current DictID. Default: all per --force/legacy rules." validate:"omitempty"`
	Bucket      string   `name:"bucket" help:"S3 bucket (default: from the federation descriptor)." validate:"omitempty"`
	KeysFile    string   `name:"keys-file" help:"S3 keys-file for remote member download/upload (default: from the descriptor)." validate:"omitempty"`
	S3Provider  string   `name:"s3-provider" help:"S3 provider (default: from the descriptor)." validate:"omitempty"`
	S3Endpoint  string   `name:"s3-endpoint" help:"S3 endpoint (default: from the descriptor)." validate:"omitempty"`
	S3AccessKey string   `name:"s3-access-key" alias:"-" help:"S3 access key (overrides keys-file)." validate:"omitempty" secret:"redact,fingerprint"`
	S3SecretKey string   `name:"s3-secret-key" alias:"-" help:"S3 secret key (overrides keys-file)." validate:"omitempty" secret:"redact,fingerprint"`
}

func (c *FedlibMembersReindexCmd) Run() error {
	registryPath := resolveFedlibRegistryPath(c.FedlibID, "")
	registry, registryPath, err := loadMembersRegistryFromPath(registryPath)
	if err != nil {
		return err
	}
	if len(registry) == 0 {
		fmt.Fprintln(os.Stderr, "fedlib members reindex: no members in registry")
		return nil
	}

	uuids := make([]string, 0, len(registry))
	for u := range registry {
		uuids = append(uuids, u)
	}
	sort.Strings(uuids)

	type reindexTarget struct {
		uuid  string
		meta  calibre.LibraryMeta
		oldID uint32
		newID uint32
	}
	wantPrefix := make(map[string]bool, len(c.Prefixes))
	for _, p := range c.Prefixes {
		wantPrefix[p] = true
	}

	var targets []reindexTarget
	hasRemote := false
	for _, uuid := range uuids {
		meta := registry[uuid]
		if !meta.IsActive() {
			continue
		}
		if len(wantPrefix) > 0 {
			// Targeted repair: heal exactly the named prefixes, regardless of
			// current DictID (e.g. re-baking a stale member's BaseURL).
			if !wantPrefix[meta.Prefix] {
				continue
			}
		} else if !(c.Force || meta.DictID < 2) {
			continue
		}
		targets = append(targets, reindexTarget{uuid: uuid, meta: meta, oldID: meta.DictID})
		if !meta.IsLocal() {
			hasRemote = true
		}
	}

	if len(targets) == 0 {
		fmt.Fprintln(os.Stderr, "fedlib members reindex: all active members already have valid DictIDs")
		return nil
	}

	if c.DryRun {
		// Preview from the descriptor counter WITHOUT allocating (no side effects).
		next := loadFedlibDescriptor(c.FedlibID).NextDictID
		if next < 2 {
			next = 2
		}
		fmt.Fprintf(os.Stderr, "fedlib members reindex: dry-run — %d member(s) would be reindexed:\n", len(targets))
		for i, t := range targets {
			kind := "local"
			if !t.meta.IsLocal() {
				kind = "rclone"
			}
			fmt.Fprintf(os.Stderr, "  %s (%s, %s): DictID %d → %d (preview)\n", t.uuid, t.meta.Librarian, kind, t.oldID, next+uint32(i))
		}
		return nil
	}

	// Allocate unique DictIDs (file-locked, monotonic) only for a real run.
	for i := range targets {
		id, allocErr := allocateMemberDictID(c.FedlibID)
		if allocErr != nil {
			return fmt.Errorf("fedlib members reindex: %w (reindex aborted to prevent duplicate DictID assignment)", allocErr)
		}
		targets[i].newID = id
	}

	// Set up the S3 remote once, only if any target is remote.
	var bucketFS string
	if hasRemote {
		fs, cleanup, sErr := c.setupS3()
		if sErr != nil {
			return fmt.Errorf("fedlib members reindex: %w", sErr)
		}
		defer cleanup()
		bucketFS = fs
	}

	exe, err := os.Executable()
	if err != nil {
		return fmt.Errorf("fedlib members reindex: resolve executable: %w", err)
	}

	for _, t := range targets {
		fmt.Fprintf(os.Stderr, "fedlib members reindex: %s (%s): DictID %d → %d\n", t.uuid, t.meta.Librarian, t.oldID, t.newID)

		if t.meta.IsLocal() {
			if err := c.rebuildLocalMember(exe, t.uuid, t.meta, t.newID); err != nil {
				return fmt.Errorf("fedlib members reindex: rebuild local %s: %w", t.uuid, err)
			}
		} else {
			if t.meta.Prefix == "" {
				return fmt.Errorf("fedlib members reindex: remote member %s has no prefix", t.uuid)
			}
			if err := c.rebuildRemoteMember(t.meta.Prefix, t.newID, bucketFS); err != nil {
				return fmt.Errorf("fedlib members reindex: rebuild remote %s: %w", t.uuid, err)
			}
		}

		// Registry DictID is advanced only AFTER the index actually carries it
		// (local rebuild or remote rebuild+upload succeeded), so registry and the
		// on-disk/S3 index can never disagree.
		if err := mutateMembersRegistryLocked(registryPath, func(reg map[string]calibre.LibraryMeta) error {
			m, ok := reg[t.uuid]
			if !ok {
				return fmt.Errorf("member %s disappeared from registry during reindex", t.uuid)
			}
			m.DictID = t.newID
			reg[t.uuid] = m
			return nil
		}); err != nil {
			return fmt.Errorf("fedlib members reindex: update registry for %s: %w", t.uuid, err)
		}
		fmt.Fprintf(os.Stderr, "  done: %s DictID=%d\n", t.uuid, t.newID)
	}

	fmt.Fprintf(os.Stderr, "fedlib members reindex: done — %d member(s) reindexed\n", len(targets))
	return nil
}

// setupS3 resolves S3 credentials (flags → keys-file → descriptor) and configures
// an rclone remote, returning the bucket filesystem string and a cleanup func.
func (c *FedlibMembersReindexCmd) setupS3() (string, func(), error) {
	desc := loadFedlibDescriptor(c.FedlibID)

	bucket := firstNonEmpty(c.Bucket, desc.Bucket)
	provider := firstNonEmpty(c.S3Provider, desc.S3Provider)
	endpoint := firstNonEmpty(c.S3Endpoint, desc.S3Endpoint)
	access, secret := c.S3AccessKey, c.S3SecretKey

	if access == "" || secret == "" {
		keysPath := firstNonEmpty(c.KeysFile, desc.KeysFile)
		if keysPath != "" && !filepath.IsAbs(keysPath) {
			keysPath = filepath.Join(accorderConfigDir, keysPath)
		}
		if keysPath != "" {
			if kf, err := parseKeysFile(keysPath); err == nil {
				if access == "" {
					access = kf.AccessKey
				}
				if secret == "" {
					secret = kf.SecretKey
				}
				provider = firstNonEmpty(provider, kf.Provider)
				endpoint = firstNonEmpty(endpoint, kf.Endpoint)
			} else {
				return "", nil, fmt.Errorf("read keys-file %s: %w", keysPath, err)
			}
		}
	}
	if bucket == "" || access == "" || secret == "" || provider == "" || endpoint == "" {
		return "", nil, fmt.Errorf("incomplete S3 config for remote reindex (need bucket/provider/endpoint/access/secret — provide --keys-file or --bucket/--s3-* or set them in the descriptor)")
	}

	if err := rclonexfer.SetCacheDir(accorderCacheDir()); err != nil {
		return "", nil, fmt.Errorf("set cache dir: %w", err)
	}
	rclonexfer.Initialize()
	remoteName := "accorder-reindex-" + c.FedlibID
	_ = rclonexfer.DeleteRemote(remoteName)
	if err := rclonexfer.ConfigS3Remote(remoteName, rclonexfer.S3RemoteConfig{
		Provider:  provider,
		AccessKey: access,
		SecretKey: secret,
		Endpoint:  endpoint,
	}); err != nil {
		rclonexfer.Finalize()
		return "", nil, fmt.Errorf("config s3 remote: %w", err)
	}
	cleanup := func() {
		_ = rclonexfer.DeleteRemote(remoteName)
		rclonexfer.Finalize()
	}
	return remoteName + ":" + bucket, cleanup, nil
}

// rebuildRemoteMember downloads the member's current index from S3, re-stamps it
// with the new DictID (rebuilding from its own display JSONL — content unchanged,
// and CompressToFile now also writes a RecencyIndex), and uploads it back.
func (c *FedlibMembersReindexCmd) rebuildRemoteMember(prefix string, newDictID uint32, bucketFS string) error {
	tmpDir, err := os.MkdirTemp("", "reindex-"+prefix+"-*")
	if err != nil {
		return fmt.Errorf("mktemp: %w", err)
	}
	defer os.RemoveAll(tmpDir)
	memberRemote := &libraryRemote{fsPath: strings.TrimRight(bucketFS, "/") + "/" + strings.Trim(prefix, "/")}
	before := memberRemote.commitState()
	if before.Err != nil || !before.Committed {
		return fmt.Errorf("member %s derived repair requires a coherent version 2 snapshot: %v", prefix, before.Err)
	}
	if before.Writer.Kind == "invalid" || before.Writer.Kind == "unreadable" {
		return fmt.Errorf("member %s has invalid/unreadable _WRITER: %w", prefix, before.Writer.Err)
	}

	// 1. Download the member's current index.
	if err := rclonexfer.CopyFile(bucketFS, prefix+"/static/library_index.zst", tmpDir, "library_index.zst"); err != nil {
		return fmt.Errorf("download index: %w", err)
	}
	srcIdx := filepath.Join(tmpDir, "library_index")

	// 2. Extract its display JSONL and re-bake the federation BaseURL into every
	//    book. The original members were built without --fedlibPrefix (empty
	//    per-book baseurl); the old monolithic aggregate hid that by re-baking from
	//    the registry prefix, but the splice path frame-copies each book's baseurl
	//    AS-IS — so the member index MUST carry /files/<prefix> or covers and
	//    downloads 404. This mirrors `lib build --fedlibPrefix`.
	jsonl, err := calibre.ReadDisplayJSONL(srcIdx)
	if err != nil {
		return fmt.Errorf("extract display JSONL: %w", err)
	}
	baseURL, libURL := calibre.FilesBaseURL(prefix)
	var rebaked bytes.Buffer
	sc := bufio.NewScanner(bytes.NewReader(jsonl))
	sc.Buffer(make([]byte, 0, 1024*1024), 32*1024*1024)
	for sc.Scan() {
		line := bytes.TrimSpace(sc.Bytes())
		if len(line) == 0 {
			continue
		}
		out, err := sjson.SetBytes(line, "baseurl", baseURL)
		if err != nil {
			return fmt.Errorf("re-bake baseurl: %w", err)
		}
		out, err = sjson.SetBytes(out, "library_url", libURL)
		if err != nil {
			return fmt.Errorf("re-bake library_url: %w", err)
		}
		rebaked.Write(out)
		rebaked.WriteByte('\n')
	}
	if err := sc.Err(); err != nil {
		return fmt.Errorf("scan display JSONL: %w", err)
	}
	jsonlPath := filepath.Join(tmpDir, "books.jsonl")
	if err := os.WriteFile(jsonlPath, rebaked.Bytes(), 0o644); err != nil {
		return err
	}

	// 3. Rebuild with the new DictID (CompressToFile also writes RecencyIndex).
	outDir := filepath.Join(tmpDir, "out")
	staticDir := filepath.Join(outDir, "static")
	if err := os.MkdirAll(staticDir, 0o755); err != nil {
		return err
	}
	outIdx := filepath.Join(staticDir, "library_index")
	ms := &calibre.MotwSearch{
		JsonlPath:            jsonlPath,
		IndexPath:            outIdx,
		DictID:               newDictID,
		IndexAggregateFields: true,
	}
	idx, err := ms.BuildIndex()
	if err != nil {
		return fmt.Errorf("build index: %w", err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		return fmt.Errorf("compress index: %w", err)
	}

	// 4. Write the member _GENERATION sentinel.
	mf, err := calibre.ReadExistingManifest(outIdx)
	if err != nil {
		return fmt.Errorf("read rebuilt manifest: %w", err)
	}
	if err := writeGenerationSentinel(outDir, mf.BaseGeneration, mf); err != nil {
		return fmt.Errorf("write _GENERATION: %w", err)
	}

	// 5. Upload the rebuilt index + _GENERATION back to S3.
	ready := memberRemote.commitState()
	if ready.Err != nil || !sameRemoteApproval(before, ready) || !bytes.Equal(before.Writer.Raw, memberRemote.readWriter().Raw) {
		return fmt.Errorf("member %s changed while rebuilding; retry", prefix)
	}
	if err := rclonexfer.CopyFile(staticDir, "library_index.zst", bucketFS, prefix+"/static/library_index.zst"); err != nil {
		return fmt.Errorf("upload index: %w", err)
	}
	afterPayload := memberRemote.commitState()
	if afterPayload.Err != nil || afterPayload.SourceFingerprint != before.SourceFingerprint ||
		afterPayload.Generation != before.Generation || !bytes.Equal(afterPayload.PointerRaw, before.PointerRaw) {
		return fmt.Errorf("member %s source changed during derived repair", prefix)
	}
	if !bytes.Equal(before.Writer.Raw, memberRemote.readWriter().Raw) {
		return fmt.Errorf("member %s writer marker changed during derived repair", prefix)
	}
	if err := calibre.WritePointerFile(outIdx, mf, before.Pointer.Library, true); err != nil {
		return fmt.Errorf("write rebuilt pointer: %w", err)
	}
	pointer, err := calibre.ReadPointerFile(outIdx + ".manifest.json")
	if err != nil {
		return err
	}
	nextGeneration := before.Generation + 1
	pointer, err = calibre.BindPointerCommit(pointer, before.SourceFingerprint, nextGeneration)
	if err != nil {
		return err
	}
	pointerRaw, err := json.MarshalIndent(pointer, "", "  ")
	if err != nil {
		return err
	}
	if err := memberRemote.write(memberPointerPath, pointerRaw); err != nil {
		return fmt.Errorf("upload pointer: %w", err)
	}
	if err := memberRemote.write(libraryflow.GenerationPath, torshare.EncodeGeneration(mf.BaseGeneration, nextGeneration)); err != nil {
		return fmt.Errorf("upload _GENERATION: %w", err)
	}
	if !bytes.Equal(before.Writer.Raw, memberRemote.readWriter().Raw) {
		return fmt.Errorf("member %s writer marker was not preserved", prefix)
	}
	committed := memberRemote.commitState()
	if committed.Err != nil || !committed.Committed || committed.Generation != nextGeneration ||
		committed.SourceFingerprint != before.SourceFingerprint || committed.Pointer.Library.UUID != before.Pointer.Library.UUID {
		return fmt.Errorf("member %s final derived commit verification failed: %v", prefix, committed.Err)
	}
	fmt.Fprintf(os.Stderr, "  rebuilt+uploaded %s: %d books, DictID=%d, RecencyIndex=%d\n", prefix, mf.NumBooks, newDictID, len(mf.RecencyIndex))
	return nil
}

func (c *FedlibMembersReindexCmd) rebuildLocalMember(exe string, uuid string, meta calibre.LibraryMeta, newDictID uint32) error {
	indexPath := filepath.Join(meta.LocalPath, "static", "library_index")
	if _, err := os.Stat(indexPath + ".zst"); err != nil {
		return fmt.Errorf("local member index not found at %s.zst: %w", indexPath, err)
	}

	args := []string{
		"lib", "build",
		"--calibrepath", meta.LocalPath,
		"--index",
		"--compact",
		"--dictID", fmt.Sprintf("%d", newDictID),
	}
	if meta.Prefix != "" {
		args = append(args, "--fedlibPrefix", meta.Prefix)
	}

	fmt.Fprintf(os.Stderr, "  rebuilding local: %s %v\n", filepath.Base(exe), args)

	cmd := exec.Command(exe, args...)
	cmd.Stderr = os.Stderr
	cmd.Stdout = os.Stdout
	if err := cmd.Run(); err != nil {
		return fmt.Errorf("lib build subprocess: %w", err)
	}
	return nil
}

func firstNonEmpty(vals ...string) string {
	for _, v := range vals {
		if v != "" {
			return v
		}
	}
	return ""
}
