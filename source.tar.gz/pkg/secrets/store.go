package secrets

import (
	"bytes"
	"errors"
	"fmt"
	"io"
	"os"
	"sort"
	"sync"
	"testing"

	"filippo.io/age"
	"github.com/goccy/go-json"
)

// testScryptWorkFactor is the age scrypt work factor (2^10) used ONLY under
// `go test`, in place of age's default 2^18. It is applied via a
// testing.Testing() guard in save(), so it is unreachable from any real binary
// — see the comment there for why the guard lives in production code rather
// than behind an exported setter.
const testScryptWorkFactor = 10

// ErrKeyNotFound is returned by Get/Delete when the store exists but has no
// entry for the requested key. Callers for whom a missing key is a normal
// condition (e.g. a public browse source with no stored auth token) should
// match it with errors.Is rather than treating any error as fatal.
var ErrKeyNotFound = errors.New("secrets: key not found")

type Store struct {
	path       string
	passphrase string
	identity   age.Identity
	recipient  age.Recipient
	mu         sync.Mutex
}

func NewStore(path, passphrase string) *Store {
	return &Store{path: path, passphrase: passphrase}
}

func NewStoreWithIdentity(path string, id *age.X25519Identity) *Store {
	return &Store{path: path, identity: id, recipient: id.Recipient()}
}

func (s *Store) Get(name string) (string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	m, err := s.load()
	if err != nil {
		return "", err
	}
	val, ok := m[name]
	if !ok {
		return "", fmt.Errorf("%w: %q", ErrKeyNotFound, name)
	}
	return val, nil
}

// Verify reports whether the store is openable: it loads (and, for an existing
// store, decrypts) without exposing the contents. Returns nil for a fresh or
// empty store and for a correct passphrase/identity; a decrypt error when the
// passphrase/identity is wrong. Callers use this to validate the store BEFORE
// taking an irreversible step (e.g. claiming a single-use invite offer).
func (s *Store) Verify() error {
	s.mu.Lock()
	defer s.mu.Unlock()
	_, err := s.load()
	return err
}

func (s *Store) Set(name, value string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	m, err := s.load()
	if err != nil {
		return err
	}
	m[name] = value
	return s.save(m)
}

// SetMany updates a related credential bundle with one decrypt/encrypt/rename
// cycle. Callers use it when a partially stored bundle would not be safely
// resumable (for example a claim-once join's credentials plus pending identity).
func (s *Store) SetMany(values map[string]string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	m, err := s.load()
	if err != nil {
		return err
	}
	for name, value := range values {
		m[name] = value
	}
	return s.save(m)
}

func (s *Store) Delete(name string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	m, err := s.load()
	if err != nil {
		return err
	}
	if _, ok := m[name]; !ok {
		return fmt.Errorf("%w: %q", ErrKeyNotFound, name)
	}
	delete(m, name)
	return s.save(m)
}

func (s *Store) List() ([]string, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	m, err := s.load()
	if err != nil {
		return nil, err
	}
	names := make([]string, 0, len(m))
	for k := range m {
		names = append(names, k)
	}
	sort.Strings(names)
	return names, nil
}

func (s *Store) WriteAll(m map[string]string) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.save(m)
}

func (s *Store) load() (map[string]string, error) {
	data, err := os.ReadFile(s.path)
	if err != nil {
		if os.IsNotExist(err) {
			return make(map[string]string), nil
		}
		return nil, fmt.Errorf("secrets: read %s: %w", s.path, err)
	}
	if len(data) == 0 {
		return make(map[string]string), nil
	}

	identity := s.identity
	if identity == nil {
		var err error
		identity, err = age.NewScryptIdentity(s.passphrase)
		if err != nil {
			return nil, fmt.Errorf("secrets: create identity: %w", err)
		}
	}

	reader, err := age.Decrypt(bytes.NewReader(data), identity)
	if err != nil {
		return nil, fmt.Errorf("secrets: decrypt %s: %w", s.path, err)
	}
	plaintext, err := io.ReadAll(reader)
	if err != nil {
		return nil, fmt.Errorf("secrets: read decrypted: %w", err)
	}

	var m map[string]string
	if err := json.Unmarshal(plaintext, &m); err != nil {
		return nil, fmt.Errorf("secrets: parse decrypted JSON: %w", err)
	}
	if m == nil {
		m = make(map[string]string)
	}
	return m, nil
}

func (s *Store) save(m map[string]string) error {
	plaintext, err := json.MarshalIndent(m, "", "  ")
	if err != nil {
		return fmt.Errorf("secrets: marshal: %w", err)
	}

	recipient := s.recipient
	if recipient == nil {
		r, rerr := age.NewScryptRecipient(s.passphrase)
		if rerr != nil {
			return fmt.Errorf("secrets: create recipient: %w", rerr)
		}
		// Test-only cost reduction. age's default work factor (2^18) costs
		// ~9s per store operation under -race — Get decrypts the whole file
		// per call — which is what made accorder/cmd exceed its test timeout
		// (cq-36, cq-37).
		//
		// testing.Testing() is false in every non-test binary, so the weakened
		// factor is unreachable in production: it cannot be switched on by an
		// env var, a flag, or a stray caller. That fail-safe property is why
		// the knob lives here rather than behind an exported setter.
		//
		// Reading needs no matching change: ScryptIdentity accepts any factor
		// up to its maxWorkFactor (default 2^22), so a store written at either
		// factor decrypts fine — including a test-written store later opened
		// by a real binary.
		if testing.Testing() {
			r.SetWorkFactor(testScryptWorkFactor)
		}
		recipient = r
	}

	var buf bytes.Buffer
	w, err := age.Encrypt(&buf, recipient)
	if err != nil {
		return fmt.Errorf("secrets: encrypt: %w", err)
	}
	if _, err := w.Write(plaintext); err != nil {
		return fmt.Errorf("secrets: write encrypted: %w", err)
	}
	if err := w.Close(); err != nil {
		return fmt.Errorf("secrets: close encrypted: %w", err)
	}

	tmp := s.path + ".tmp"
	if err := os.WriteFile(tmp, buf.Bytes(), 0o600); err != nil {
		return fmt.Errorf("secrets: write %s: %w", tmp, err)
	}
	if err := os.Rename(tmp, s.path); err != nil {
		_ = os.Remove(tmp)
		return fmt.Errorf("secrets: rename %s: %w", s.path, err)
	}
	return nil
}
