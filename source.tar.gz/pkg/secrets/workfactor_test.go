package secrets

import (
	"bytes"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"filippo.io/age"
	"github.com/goccy/go-json"
)

// scryptLogN extracts the work factor from an age file's scrypt stanza, whose
// header line is `-> scrypt <base64 salt> <logN>`.
func scryptLogN(t *testing.T, path string) string {
	t.Helper()
	b, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("read %s: %v", path, err)
	}
	for _, line := range strings.Split(string(b), "\n") {
		if after, ok := strings.CutPrefix(line, "-> scrypt "); ok {
			fields := strings.Fields(after)
			if len(fields) != 2 {
				t.Fatalf("malformed scrypt stanza: %q", line)
			}
			return fields[1]
		}
	}
	t.Fatalf("no scrypt stanza in %s", path)
	return ""
}

// TestScryptWorkFactor_ReducedUnderTest pins the test-only cost reduction.
//
// If this fails with "18", the testing.Testing() guard in save() has been
// removed or bypassed and the cmd package will go back to exceeding its test
// timeout (cq-36). If it fails with anything else, the constant moved.
//
// The other half of the claim — that a REAL binary still writes 18 — cannot be
// asserted from a test, since testing.Testing() is true here by construction.
// It was verified out-of-band by running a non-test binary against this same
// package: it emitted `-> scrypt <salt> 18`.
func TestScryptWorkFactor_ReducedUnderTest(t *testing.T) {
	path := filepath.Join(t.TempDir(), "secrets.age")
	if err := NewStore(path, "pw").Set("k", "v"); err != nil {
		t.Fatalf("Set: %v", err)
	}
	if got := scryptLogN(t, path); got != "10" {
		t.Errorf("work factor = %s, want 10 (testing.Testing() guard in save() may have been removed)", got)
	}
}

// TestScryptWorkFactor_ProductionFileReadsBack guards the compatibility claim
// the guard rests on: a store written at age's DEFAULT factor — i.e. by a real
// binary — must still open here, where saves use the reduced factor. Without
// this, lowering the test factor could silently break tests' ability to read
// fixtures or real user stores.
func TestScryptWorkFactor_ProductionFileReadsBack(t *testing.T) {
	path := filepath.Join(t.TempDir(), "secrets.age")

	// Write at age's default work factor, bypassing save()'s test guard, to
	// stand in for a file produced by a production binary.
	plaintext, err := json.Marshal(map[string]string{"k": "v"})
	if err != nil {
		t.Fatal(err)
	}
	r, err := age.NewScryptRecipient("pw")
	if err != nil {
		t.Fatal(err)
	}
	var buf bytes.Buffer
	w, err := age.Encrypt(&buf, r)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := w.Write(plaintext); err != nil {
		t.Fatal(err)
	}
	if err := w.Close(); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(path, buf.Bytes(), 0o600); err != nil {
		t.Fatal(err)
	}

	if got := scryptLogN(t, path); got == "10" {
		t.Fatalf("fixture was written at the reduced factor; it must use age's default to be meaningful")
	}

	got, err := NewStore(path, "pw").Get("k")
	if err != nil {
		t.Fatalf("Get on a default-work-factor store: %v", err)
	}
	if got != "v" {
		t.Errorf("Get = %q, want %q", got, "v")
	}
}
