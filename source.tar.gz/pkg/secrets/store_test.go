package secrets

import (
	"os"
	"path/filepath"
	"testing"

	"filippo.io/age"
)

func TestStore_Verify(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "secrets.age")

	// Fresh (no file) store verifies OK — nothing to decrypt yet.
	if err := NewStore(path, "pw").Verify(); err != nil {
		t.Fatalf("fresh store Verify: %v", err)
	}
	// Populate under passphrase "correct".
	if err := NewStore(path, "correct").Set("k", "v"); err != nil {
		t.Fatal(err)
	}
	// Correct passphrase verifies OK; wrong passphrase fails (decrypt error).
	if err := NewStore(path, "correct").Verify(); err != nil {
		t.Errorf("correct passphrase Verify: %v", err)
	}
	if err := NewStore(path, "wrong").Verify(); err == nil {
		t.Error("wrong passphrase Verify: want error, got nil")
	}
}

func TestStore_RoundTrip(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "secrets.age")
	store := NewStore(path, "test-passphrase")

	// Set two secrets.
	if err := store.Set("key1", "value1"); err != nil {
		t.Fatalf("Set key1: %v", err)
	}
	if err := store.Set("key2", "value2"); err != nil {
		t.Fatalf("Set key2: %v", err)
	}

	// Get them back.
	v1, err := store.Get("key1")
	if err != nil {
		t.Fatalf("Get key1: %v", err)
	}
	if v1 != "value1" {
		t.Errorf("key1 = %q, want %q", v1, "value1")
	}

	v2, err := store.Get("key2")
	if err != nil {
		t.Fatalf("Get key2: %v", err)
	}
	if v2 != "value2" {
		t.Errorf("key2 = %q, want %q", v2, "value2")
	}

	// List.
	names, err := store.List()
	if err != nil {
		t.Fatalf("List: %v", err)
	}
	if len(names) != 2 || names[0] != "key1" || names[1] != "key2" {
		t.Errorf("List = %v, want [key1, key2]", names)
	}
}

func TestStore_Delete(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "secrets.age")
	store := NewStore(path, "test-passphrase")

	if err := store.Set("key1", "value1"); err != nil {
		t.Fatal(err)
	}
	if err := store.Delete("key1"); err != nil {
		t.Fatalf("Delete: %v", err)
	}
	if _, err := store.Get("key1"); err == nil {
		t.Error("expected error for deleted key")
	}

	// Delete non-existent key.
	if err := store.Delete("nonexistent"); err == nil {
		t.Error("expected error for non-existent key")
	}
}

func TestStore_GetMissing(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "secrets.age")
	store := NewStore(path, "test-passphrase")

	// Get from non-existent file returns error (key not found, not file error).
	_, err := store.Get("nonexistent")
	if err == nil {
		t.Error("expected error for missing key from empty store")
	}
}

func TestStore_EncryptedOnDisk(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "secrets.age")
	store := NewStore(path, "test-passphrase")

	if err := store.Set("secret-key", "super-secret-value"); err != nil {
		t.Fatal(err)
	}

	// Read raw file — should not contain plaintext.
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	content := string(data)
	if containsStr(content, "super-secret-value") {
		t.Error("encrypted file contains plaintext secret value")
	}
	if containsStr(content, "secret-key") {
		t.Error("encrypted file contains plaintext secret key name")
	}
}

func TestStore_WrongPassphrase(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "secrets.age")

	// Write with one passphrase.
	store1 := NewStore(path, "passphrase-one")
	if err := store1.Set("key", "value"); err != nil {
		t.Fatal(err)
	}

	// Read with a different passphrase — should fail.
	store2 := NewStore(path, "wrong-passphrase")
	_, err := store2.Get("key")
	if err == nil {
		t.Error("expected error for wrong passphrase")
	}
}

func TestStore_Overwrite(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "secrets.age")
	store := NewStore(path, "test-passphrase")

	if err := store.Set("key", "v1"); err != nil {
		t.Fatal(err)
	}
	if err := store.Set("key", "v2"); err != nil {
		t.Fatal(err)
	}

	val, err := store.Get("key")
	if err != nil {
		t.Fatal(err)
	}
	if val != "v2" {
		t.Errorf("key = %q, want %q", val, "v2")
	}
}

func TestStore_PersistAcrossInstances(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "secrets.age")

	// Write with one instance.
	store1 := NewStore(path, "shared-passphrase")
	if err := store1.Set("persist-key", "persist-value"); err != nil {
		t.Fatal(err)
	}

	// Read with a new instance (same path, same passphrase).
	store2 := NewStore(path, "shared-passphrase")
	val, err := store2.Get("persist-key")
	if err != nil {
		t.Fatal(err)
	}
	if val != "persist-value" {
		t.Errorf("persist-key = %q, want %q", val, "persist-value")
	}
}

func containsStr(s, substr string) bool {
	for i := 0; i <= len(s)-len(substr); i++ {
		if s[i:i+len(substr)] == substr {
			return true
		}
	}
	return false
}

func TestStore_IdentityRoundTrip(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "secrets.age")
	id, err := age.GenerateX25519Identity()
	if err != nil {
		t.Fatal(err)
	}
	store := NewStoreWithIdentity(path, id)

	if err := store.Set("key1", "value1"); err != nil {
		t.Fatalf("Set: %v", err)
	}

	// Fresh instance with the same identity reads it back.
	store2 := NewStoreWithIdentity(path, id)
	v, err := store2.Get("key1")
	if err != nil {
		t.Fatalf("Get: %v", err)
	}
	if v != "value1" {
		t.Errorf("key1 = %q, want %q", v, "value1")
	}
}

func TestStore_IdentityEncryptedOnDisk(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "secrets.age")
	id, err := age.GenerateX25519Identity()
	if err != nil {
		t.Fatal(err)
	}
	store := NewStoreWithIdentity(path, id)
	if err := store.Set("secret-key", "super-secret-value"); err != nil {
		t.Fatal(err)
	}
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	if containsStr(string(data), "super-secret-value") || containsStr(string(data), "secret-key") {
		t.Error("key-file-mode store leaks plaintext on disk")
	}
}

func TestStore_IdentityWrongKeyFails(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "secrets.age")
	id1, _ := age.GenerateX25519Identity()
	id2, _ := age.GenerateX25519Identity()

	if err := NewStoreWithIdentity(path, id1).Set("key", "value"); err != nil {
		t.Fatal(err)
	}
	if _, err := NewStoreWithIdentity(path, id2).Get("key"); err == nil {
		t.Error("wrong identity decrypted the store")
	}

	// A passphrase store cannot read a key-file store either.
	if _, err := NewStore(path, "any").Get("key"); err == nil {
		t.Error("scrypt store decrypted a key-file store")
	}
}

func TestStoreSetManyPersistsBundle(t *testing.T) {
	path := filepath.Join(t.TempDir(), "secrets.age")
	id, err := age.GenerateX25519Identity()
	if err != nil {
		t.Fatal(err)
	}
	store := NewStoreWithIdentity(path, id)
	if err := store.SetMany(map[string]string{"a": "one", "b": "two", "pending": "identity"}); err != nil {
		t.Fatal(err)
	}
	for name, want := range map[string]string{"a": "one", "b": "two", "pending": "identity"} {
		got, err := store.Get(name)
		if err != nil || got != want {
			t.Fatalf("Get(%q) = %q, %v; want %q", name, got, err, want)
		}
	}
}
