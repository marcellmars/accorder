package rclonexfer

import "testing"

func TestReadHandleCaching(t *testing.T) {
	for _, test := range []struct {
		opts VFSOptions
		want string
	}{
		{VFSOptions{CacheMode: "full", ReadOnly: true}, "0"},
		{VFSOptions{CacheMode: "full"}, ""},
		{VFSOptions{CacheMode: "off", ReadOnly: true}, ""},
		{VFSOptions{CacheMode: "full", ReadOnly: true, HandleCaching: "5s"}, "5s"},
	} {
		if got := readHandleCaching(test.opts); got != test.want {
			t.Fatalf("%+v: got %q want %q", test.opts, got, test.want)
		}
	}
}

func TestReadOnlyFullCacheImmediateEdit(t *testing.T) {
	h := newDirectoryCacheSpikeHarness(t)
	h.writeFile("member/book/book.epub", "old!")
	plane := h.startPlane("immediate-edit", "1h")
	requireDirectoryCacheSpikeGET(t, plane, "member/book/book.epub", 200, "old!")
	h.writeFile("member/book/book.epub", "new!")
	directoryCacheSpikeForget(t, plane.fs, "member/book")
	requireDirectoryCacheSpikeGET(t, plane, "member/book/book.epub", 200, "new!")
	// Still full mode, not a workaround that silently disables the disk cache.
	waitForDirectoryCacheSpikeFile(t, h.cacheDir, "book.epub")
}
