package rclonexfer

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/rclone/rclone/fs/config"
	"github.com/rclone/rclone/lib/diskusage"
)

// TestSpikeDifferentRemoteNamesCreateDifferentVFSTrees exercises the
// dependency boundary with two named local remotes over the same backing
// directory. Each remote serves one file through cache-mode=full; the fetched
// bytes must then exist only below that remote's own VFS tree.
func TestSpikeDifferentRemoteNamesCreateDifferentVFSTrees(t *testing.T) {
	backing := t.TempDir()
	cacheDir := t.TempDir()
	writeSpikeFile := func(rel, body string) {
		t.Helper()
		path := filepath.Join(backing, filepath.FromSlash(rel))
		if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(path, []byte(body), 0o644); err != nil {
			t.Fatal(err)
		}
	}
	writeSpikeFile("member/static/app.js", "ASSET-POOL-PAYLOAD")
	writeSpikeFile("member/Author/Title/book.epub", "BOOK-POOL-PAYLOAD")

	suffix := time.Now().UnixNano()
	booksRemote := fmt.Sprintf("splitvfs-books-%d", suffix)
	assetsRemote := fmt.Sprintf("splitvfs-assets-%d", suffix)
	remotes := []string{booksRemote, assetsRemote}

	previousCacheDir := config.GetCacheDir()
	previousConfigPath := config.GetConfigPath()
	if err := config.SetConfigPath(filepath.Join(t.TempDir(), "rclone.conf")); err != nil {
		t.Fatalf("set isolated rclone config: %v", err)
	}
	if err := SetCacheDir(cacheDir); err != nil {
		t.Fatalf("SetCacheDir: %v", err)
	}
	Initialize()
	var serveIDs []string
	t.Cleanup(func() {
		for i := len(serveIDs) - 1; i >= 0; i-- {
			if err := StopServe(serveIDs[i]); err != nil {
				t.Logf("StopServe(%s): %v", serveIDs[i], err)
			}
		}
		for i := len(remotes) - 1; i >= 0; i-- {
			if err := DeleteRemote(remotes[i]); err != nil {
				t.Logf("DeleteRemote(%s): %v", remotes[i], err)
			}
		}
		Finalize()
		if err := SetCacheDir(previousCacheDir); err != nil {
			t.Logf("restore cache dir: %v", err)
		}
		if err := config.SetConfigPath(previousConfigPath); err != nil {
			t.Logf("restore config path: %v", err)
		}
	})

	for _, name := range remotes {
		out, status := configRPC("config/create", mustJSON(map[string]any{
			"name":       name,
			"type":       "local",
			"parameters": map[string]string{},
		}))
		if status != http.StatusOK {
			t.Fatalf("config/create %s: status=%d out=%s", name, status, out)
		}
	}

	start := func(remote string) string {
		t.Helper()
		fsPath := remote + ":" + filepath.ToSlash(backing)
		id, addr, err := ServeHTTPWithVFS(fsPath, "127.0.0.1:0", VFSOptions{
			CacheMode:    "full",
			CacheMaxSize: "16Mi",
			CacheMaxAge:  "1h",
			ReadOnly:     true,
		})
		if err != nil {
			t.Fatalf("ServeHTTPWithVFS(%s): %v", remote, err)
		}
		serveIDs = append(serveIDs, id)
		return "http://" + addr
	}
	booksURL := start(booksRemote)
	assetsURL := start(assetsRemote)

	fetch := func(baseURL, rel, want string) {
		t.Helper()
		client := &http.Client{Timeout: 10 * time.Second}
		resp, err := client.Get(baseURL + "/" + rel)
		if err != nil {
			t.Fatalf("GET %s/%s: %v", baseURL, rel, err)
		}
		body, readErr := io.ReadAll(resp.Body)
		_ = resp.Body.Close()
		if readErr != nil {
			t.Fatalf("read %s: %v", rel, readErr)
		}
		if resp.StatusCode != http.StatusOK || string(body) != want {
			t.Fatalf("GET %s: status=%d body=%q, want status=200 body=%q", rel, resp.StatusCode, body, want)
		}
	}
	fetch(assetsURL, "member/static/app.js", "ASSET-POOL-PAYLOAD")
	fetch(booksURL, "member/Author/Title/book.epub", "BOOK-POOL-PAYLOAD")

	booksTree := filepath.Join(cacheDir, "vfs", booksRemote)
	assetsTree := filepath.Join(cacheDir, "vfs", assetsRemote)
	waitForSpikeCacheFile(t, booksTree, "book.epub")
	waitForSpikeCacheFile(t, assetsTree, "app.js")

	if spikeTreeContains(t, booksTree, "app.js") {
		t.Fatalf("asset leaked into books tree %s", booksTree)
	}
	if spikeTreeContains(t, assetsTree, "book.epub") {
		t.Fatalf("book leaked into assets tree %s", assetsTree)
	}
	for _, remote := range remotes {
		if info, err := os.Stat(filepath.Join(cacheDir, "vfsMeta", remote)); err != nil || !info.IsDir() {
			t.Fatalf("distinct vfsMeta tree missing for %s: %v", remote, err)
		}
	}

	t.Logf("books cached under %s; assets cached under %s", booksTree, assetsTree)
}

func TestSplitVFSCachesBooksQuotaCannotEvictAssetsAboveSharedFloor(t *testing.T) {
	backing := t.TempDir()
	cacheDir := t.TempDir()
	writeSized := func(rel string, size int) {
		t.Helper()
		path := filepath.Join(backing, filepath.FromSlash(rel))
		if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
			t.Fatal(err)
		}
		payload := make([]byte, size)
		for i := range payload {
			payload[i] = byte(i % 251)
		}
		if err := os.WriteFile(path, payload, 0o644); err != nil {
			t.Fatal(err)
		}
	}
	writeSized("member/Author/Title/cover.jpg", 64<<10)
	bookNames := make([]string, 6)
	for i := range bookNames {
		bookNames[i] = fmt.Sprintf("book-%d.epub", i)
		writeSized("member/Author/Title/"+bookNames[i], 96<<10)
	}

	space, err := diskusage.New(cacheDir)
	if err != nil {
		t.Skipf("disk free-space probe unavailable: %v", err)
	}
	const floor = uint64(2 * 1024 * 1024 * 1024)
	if space.Available <= floor+64<<20 {
		t.Skipf("scratch filesystem has only %d bytes available; cannot isolate max-size from 2Gi min-free", space.Available)
	}
	minimumFree := space.Available
	recordFree := func() {
		t.Helper()
		current, err := diskusage.New(cacheDir)
		if err != nil {
			t.Fatal(err)
		}
		if current.Available < minimumFree {
			minimumFree = current.Available
		}
	}

	suffix := time.Now().UnixNano()
	booksRemote := fmt.Sprintf("splitvfs-quota-books-%d", suffix)
	assetsRemote := fmt.Sprintf("splitvfs-quota-assets-%d", suffix)
	remotes := []string{booksRemote, assetsRemote}
	previousCacheDir := config.GetCacheDir()
	previousConfigPath := config.GetConfigPath()
	if err := config.SetConfigPath(filepath.Join(t.TempDir(), "rclone.conf")); err != nil {
		t.Fatalf("set isolated rclone config: %v", err)
	}
	if err := SetCacheDir(cacheDir); err != nil {
		t.Fatalf("SetCacheDir: %v", err)
	}
	Initialize()
	var serveIDs []string
	t.Cleanup(func() {
		for i := len(serveIDs) - 1; i >= 0; i-- {
			_ = StopServe(serveIDs[i])
		}
		for i := len(remotes) - 1; i >= 0; i-- {
			_ = DeleteRemote(remotes[i])
		}
		Finalize()
		_ = SetCacheDir(previousCacheDir)
		_ = config.SetConfigPath(previousConfigPath)
	})
	for _, name := range remotes {
		out, status := configRPC("config/create", mustJSON(map[string]any{
			"name": name, "type": "local", "parameters": map[string]string{},
		}))
		if status != http.StatusOK {
			t.Fatalf("config/create %s: status=%d out=%s", name, status, out)
		}
	}
	start := func(remote, cap string) string {
		t.Helper()
		id, addr, err := ServeHTTPWithVFS(remote+":"+filepath.ToSlash(backing), "127.0.0.1:0", VFSOptions{
			CacheMode: "full", CacheMaxSize: cap, CacheMaxAge: "1h",
			CacheMinFreeSpace: "2Gi", CachePollInterval: "100ms", HandleCaching: "100ms",
			ReadOnly: true,
		})
		if err != nil {
			t.Fatal(err)
		}
		serveIDs = append(serveIDs, id)
		return "http://" + addr
	}
	booksURL := start(booksRemote, "160Ki")
	assetsURL := start(assetsRemote, "1Mi")
	fetch := func(baseURL, rel string) {
		t.Helper()
		resp, err := (&http.Client{Timeout: 10 * time.Second}).Get(baseURL + "/" + rel)
		if err != nil {
			t.Fatal(err)
		}
		_, readErr := io.Copy(io.Discard, resp.Body)
		closeErr := resp.Body.Close()
		if resp.StatusCode != http.StatusOK || readErr != nil || closeErr != nil {
			t.Fatalf("GET %s: status=%d read=%v close=%v", rel, resp.StatusCode, readErr, closeErr)
		}
		recordFree()
	}
	coverRel := "member/Author/Title/cover.jpg"
	fetch(assetsURL, coverRel)
	assetsMeta := filepath.Join(cacheDir, "vfsMeta", assetsRemote)
	booksMeta := filepath.Join(cacheDir, "vfsMeta", booksRemote)
	waitForSpikeRangeBytes(t, assetsMeta, 64<<10, 5*time.Second)
	for _, name := range bookNames {
		fetch(booksURL, "member/Author/Title/"+name)
	}

	deadline := time.Now().Add(10 * time.Second)
	for {
		recordFree()
		booksBytes, ok := spikeRangeBytes(t, booksMeta)
		assetsBytes, assetsOK := spikeRangeBytes(t, assetsMeta)
		if ok && assetsOK && booksBytes <= 160<<10 && assetsBytes == 64<<10 {
			break
		}
		if time.Now().After(deadline) {
			t.Fatalf("quota did not settle independently: books=%d ok=%v assets=%d ok=%v", booksBytes, ok, assetsBytes, assetsOK)
		}
		time.Sleep(100 * time.Millisecond)
	}
	if minimumFree <= floor {
		t.Fatalf("scratch crossed the shared 2Gi floor: minimum available=%d", minimumFree)
	}
	if got, ok := spikeRangeBytes(t, assetsMeta); !ok || got != 64<<10 {
		t.Fatalf("books max-size churn evicted cover: assets ranges=%d ok=%v", got, ok)
	}
	t.Logf("books quota churn retained the 64KiB cover; minimum shared-disk free space %.2f GiB",
		float64(minimumFree)/(1024*1024*1024))
}

func waitForSpikeRangeBytes(t *testing.T, root string, want int64, timeout time.Duration) {
	t.Helper()
	deadline := time.Now().Add(timeout)
	for {
		if got, ok := spikeRangeBytes(t, root); ok && got == want {
			return
		}
		if time.Now().After(deadline) {
			got, ok := spikeRangeBytes(t, root)
			t.Fatalf("cached ranges under %s = %d, ok=%v, want %d", root, got, ok, want)
		}
		time.Sleep(25 * time.Millisecond)
	}
}

func spikeRangeBytes(t *testing.T, root string) (total int64, ok bool) {
	t.Helper()
	ok = true
	err := filepath.WalkDir(root, func(path string, entry os.DirEntry, err error) error {
		if err != nil {
			ok = false
			return nil
		}
		if !entry.Type().IsRegular() {
			return nil
		}
		data, err := os.ReadFile(path)
		if err != nil {
			ok = false
			return nil
		}
		var info struct {
			Rs []struct {
				Size int64
			}
		}
		if err := json.Unmarshal(data, &info); err != nil {
			ok = false
			return nil
		}
		for _, cached := range info.Rs {
			total += cached.Size
		}
		return nil
	})
	if err != nil {
		if os.IsNotExist(err) {
			return 0, false
		}
		t.Fatal(err)
	}
	return total, ok
}

func waitForSpikeCacheFile(t *testing.T, root, base string) {
	t.Helper()
	deadline := time.Now().Add(5 * time.Second)
	for {
		if spikeTreeContains(t, root, base) {
			return
		}
		if time.Now().After(deadline) {
			t.Fatalf("cached file %q did not appear under %s", base, root)
		}
		time.Sleep(25 * time.Millisecond)
	}
}

func spikeTreeContains(t *testing.T, root, base string) bool {
	t.Helper()
	found := false
	err := filepath.WalkDir(root, func(path string, entry os.DirEntry, err error) error {
		if err != nil {
			if os.IsNotExist(err) {
				return filepath.SkipAll
			}
			return err
		}
		if !entry.IsDir() && strings.EqualFold(entry.Name(), base) {
			found = true
			return filepath.SkipAll
		}
		return nil
	})
	if err != nil && !os.IsNotExist(err) {
		t.Fatalf("walk %s: %v", root, err)
	}
	return found
}
