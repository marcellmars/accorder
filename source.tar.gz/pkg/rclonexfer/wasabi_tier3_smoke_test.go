//go:build integration

package rclonexfer

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"accorder/pkg/calibre"

	_ "github.com/rclone/rclone/backend/s3"
	"github.com/rclone/rclone/librclone/librclone"
	uuid "github.com/satori/go.uuid"
)

// marcellUUID is the public library UUID for the live "marcell" Memory of the
// World library (from motw_libraries.json). It is not a secret.
const marcellUUID = "fac314b6-cfa9-4d2b-99d6-e40a37599cdd"

// TestWasabiTier3_AutoCompile is a live smoke test of share-tor's Tier 3
// (ensureRemoteIndex auto-compile) READ + COMPILE path against the real
// motw/marcell library. It calls the same real functions the implementation
// uses:
//
//	download metadata.db  -> rclonexfer.CopyFile (S3 -> local)
//	compile MWSC index    -> calibre.MotwStandaloneApp.LoadBooksE / JsonLE
//	                         calibre.MotwSearch.BuildIndex / CompressToFile
//

// This needs only read access (GetObject/ListBucket) and is safe — it never
// mutates the bucket. Skips when wasabi.keys is absent.
func TestWasabiTier3_AutoCompile(t *testing.T) {
	ak, sk := readWasabiKeys(t)
	if ak == "" || sk == "" {
		t.Skip("wasabi.keys not found or incomplete — skipping live S3 test")
	}

	Initialize()
	defer Finalize()

	const remote = "wasabi-tier3-smoke"
	if err := ConfigS3Remote(remote, S3RemoteConfig{Provider: "Wasabi", AccessKey: ak, SecretKey: sk, Endpoint: "s3.wasabisys.com"}); err != nil {
		t.Fatalf("config s3 remote: %v", err)
	}
	defer DeleteRemote(remote)

	srcFs := remote + ":motw/marcell"
	tempDir := t.TempDir()

	// --- FileExists (operations/stat) on a present and an absent path ---
	if ok, err := FileExists(srcFs, "metadata.db"); err != nil || !ok {
		t.Fatalf("FileExists(metadata.db) = %v, %v; want true, nil", ok, err)
	}
	if ok, err := FileExists(srcFs, "does-not-exist-xyzzy.bin"); err != nil || ok {
		t.Fatalf("FileExists(missing) = %v, %v; want false, nil", ok, err)
	}
	t.Log("FileExists stat-based existence check verified (present + absent)")

	// --- READ: download metadata.db from the live library (S3 -> local) ---
	if err := CopyFile(srcFs, "metadata.db", tempDir, "metadata.db"); err != nil {
		t.Fatalf("download metadata.db: %v", err)
	}
	dbInfo, err := os.Stat(filepath.Join(tempDir, "metadata.db"))
	if err != nil {
		t.Fatalf("stat downloaded metadata.db: %v", err)
	}
	t.Logf("downloaded metadata.db: %d bytes", dbInfo.Size())
	if dbInfo.Size() == 0 {
		t.Fatal("downloaded metadata.db is empty")
	}

	// --- COMPILE: real SQLite-path build chain ---
	motwApp := &calibre.MotwStandaloneApp{
		CalibreDirectory: tempDir,
		Librarian:        "marcell mars",
		LibraryUUID:      marcellUUID,
	}
	if err := motwApp.LoadBooksE(); err != nil {
		t.Fatalf("LoadBooksE from metadata.db: %v", err)
	}
	t.Logf("loaded %d books from metadata.db", len(motwApp.Books))
	if len(motwApp.Books) == 0 {
		t.Fatal("no books loaded from metadata.db")
	}

	jsonlPath := filepath.Join(tempDir, "books.jsonl")
	if err := motwApp.JsonLE(jsonlPath); err != nil {
		t.Fatalf("write temp JSONL: %v", err)
	}

	// Seed BaseGeneration from the library UUID, exactly as ensureRemoteIndex does.
	baseGen := uuid.Must(uuid.FromString(marcellUUID))
	var bg [16]byte
	copy(bg[:], baseGen[:])

	indexPath := filepath.Join(tempDir, "library_index")
	ms := &calibre.MotwSearch{
		JsonlPath:      jsonlPath,
		IndexPath:      indexPath,
		BaseGeneration: &bg,
	}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex: %v", err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatalf("CompressToFile: %v", err)
	}

	zstInfo, err := os.Stat(indexPath + ".zst")
	if err != nil {
		t.Fatalf("stat compiled index: %v", err)
	}
	t.Logf("compiled library_index.zst: %d bytes", zstInfo.Size())

	mf, err := calibre.ReadExistingManifest(indexPath)
	if err != nil {
		t.Fatalf("ReadExistingManifest: %v", err)
	}
	t.Logf("manifest: NumBooks=%d Generation=%d Regions=%d", mf.NumBooks, mf.Generation, len(mf.Regions))
	if mf.NumBooks == 0 {
		t.Fatal("manifest reports 0 books")
	}
	if mf.BaseGeneration != bg {
		t.Fatalf("BaseGeneration not seeded from UUID: got %x want %x", mf.BaseGeneration, bg)
	}
}

// TestWasabiTier3_WriteBack exercises the Tier 1/3 WRITE-BACK path: uploading
// to the motw bucket via rclonexfer.CopyFile (local -> S3). It uploads a small
// probe to a throwaway scratch prefix and purges it.
//

// This requires write-capable credentials. With the read-only "inspection"
// keys it is expected to fail at PutObject with AccessDenied — in that case the
// test skips (the write path is still validated structurally: no_check_bucket
// means the failure is PutObject, not the pre-flight CreateBucket).
func TestWasabiTier3_WriteBack(t *testing.T) {
	ak, sk := readWasabiKeys(t)
	if ak == "" || sk == "" {
		t.Skip("wasabi.keys not found or incomplete — skipping live S3 test")
	}

	Initialize()
	defer Finalize()

	const remote = "wasabi-tier3-wb"
	if err := ConfigS3Remote(remote, S3RemoteConfig{Provider: "Wasabi", AccessKey: ak, SecretKey: sk, Endpoint: "s3.wasabisys.com"}); err != nil {
		t.Fatalf("config s3 remote: %v", err)
	}
	defer DeleteRemote(remote)

	tempDir := t.TempDir()
	if err := os.WriteFile(filepath.Join(tempDir, "probe.bin"), []byte("tier3-writeback-probe"), 0644); err != nil {
		t.Fatalf("write probe: %v", err)
	}

	scratchFs := remote + ":" + fmt.Sprintf("motw/_tier3-wb-%d", time.Now().Unix())
	t.Logf("write-back scratch prefix: %s", scratchFs)
	defer func() {
		purgeIn, _ := json.Marshal(map[string]any{"fs": scratchFs, "remote": ""})
		out, status := librclone.RPC("operations/purge", string(purgeIn))
		t.Logf("cleanup operations/purge status=%d out=%s", status, out)
	}()

	err := CopyFile(tempDir, "probe.bin", scratchFs, "static/probe.bin")
	if err != nil {
		if strings.Contains(err.Error(), "AccessDenied") || strings.Contains(err.Error(), "403") {
			t.Skipf("write-back needs write-capable S3 keys; provided keys are read-only on motw: %v", err)
		}
		t.Fatalf("write-back upload: %v", err)
	}

	sizes, err := ListSizes(scratchFs, nil)
	if err != nil {
		t.Fatalf("list scratch prefix: %v", err)
	}
	if sz, ok := sizes["static/probe.bin"]; !ok {
		t.Fatalf("probe not found after upload (got %v)", sizes)
	} else {
		t.Logf("write-back confirmed: static/probe.bin (%d bytes) — write-capable keys", sz)
	}
}
