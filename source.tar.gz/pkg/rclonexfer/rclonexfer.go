package rclonexfer

import (
	"encoding/json"
	"fmt"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/rclone/rclone/fs"

	_ "github.com/rclone/rclone/backend/http"
	_ "github.com/rclone/rclone/backend/local"
	_ "github.com/rclone/rclone/backend/s3"
	_ "github.com/rclone/rclone/backend/webdav"
	_ "github.com/rclone/rclone/cmd/serve/http"
	_ "github.com/rclone/rclone/cmd/serve/webdav"
	"github.com/rclone/rclone/fs/config"
	_ "github.com/rclone/rclone/fs/operations"
	_ "github.com/rclone/rclone/fs/sync"
	"github.com/rclone/rclone/lib/atexit"
	"github.com/rclone/rclone/librclone/librclone"
)

type SyncStats struct {
	Bytes       int64 `json:"bytes"`
	TotalBytes  int64 `json:"totalBytes"`
	Checks      int64 `json:"checks"`
	TotalChecks int64 `json:"totalChecks"`
	Transfers   int64 `json:"transfers"`
	Deletes     int64 `json:"deletes"`
	Errors      int64 `json:"errors"`
	Finished    bool
	Success     bool
	Error       string
}

type RemoteObject struct {
	Path    string            `json:"path"`
	Size    int64             `json:"size"`
	ModTime time.Time         `json:"mod_time,omitempty"`
	Hashes  map[string]string `json:"hashes,omitempty"`
}

func mustJSON(v any) string {
	b, _ := json.Marshal(v)
	return string(b)
}

// librclone is a process-global singleton: Initialize/Finalize bring the whole
// engine up/down, and config mutations share one global config store. rcloneMu
// makes both safe. Initialize/Finalize are refcounted so a nested build (which
// runs its own Init/Finalize pair) cannot tear down the rclone state the serve
// daemon is still using; config mutations are serialized so concurrent
// config/create or config/delete calls (poller + build) cannot race the store.
// Long-running data ops (CopyFile, sync) deliberately do NOT take this lock —
// librclone handles concurrent transfers, and holding rcloneMu across a sync
// would serialize all I/O.
var (
	rcloneMu       sync.Mutex
	rcloneRefCount int
)

// UseHostSignalHandler makes the embedding process the sole owner of
// SIGINT/SIGTERM. Rclone's atexit package otherwise installs its own signal
// handler when an embedded HTTP serve starts and calls os.Exit(128+signal)
// after running dependency callbacks. The policy is process-global and
// irreversible, so callers must use it only for long-lived serve commands that
// explicitly stop every rclone resource they start.
func UseHostSignalHandler() {
	atexit.IgnoreSignals()
}

func Initialize() {
	rcloneMu.Lock()
	defer rcloneMu.Unlock()
	if rcloneRefCount == 0 {
		librclone.Initialize()
	}
	rcloneRefCount++
}

func Finalize() {
	rcloneMu.Lock()
	defer rcloneMu.Unlock()
	if rcloneRefCount == 0 {
		return // already finalized, or never initialized — tearing down again is unsafe
	}
	rcloneRefCount--
	if rcloneRefCount == 0 {
		librclone.Finalize()
	}
}

// configRPC serializes rclone config-store mutations (config/create,
// config/delete) under rcloneMu so concurrent callers cannot race the global
// config.
func configRPC(method, payload string) (string, int) {
	rcloneMu.Lock()
	defer rcloneMu.Unlock()
	return librclone.RPC(method, payload)
}

func ServeWebDAV(fsPath, addr string) (id, boundAddr string, err error) {
	return ServeWebDAVWithVFS(fsPath, addr, VFSOptions{})
}

func StopServe(id string) error {
	out, status := librclone.RPC("serve/stop", mustJSON(map[string]any{"id": id}))
	if status != 200 {
		return fmt.Errorf("rclonexfer: serve/stop: status %d: %s", status, out)
	}
	return nil
}

func ConfigWebDAVRemote(name, url string) error {
	out, status := configRPC("config/create", mustJSON(map[string]any{
		"name":       name,
		"type":       "webdav",
		"parameters": map[string]string{"url": url},
	}))
	if status != 200 {
		return fmt.Errorf("rclonexfer: config webdav: status %d: %s", status, out)
	}
	return nil
}

func ConfigHTTPRemote(name, url string) error {
	out, status := configRPC("config/create", mustJSON(map[string]any{
		"name":       name,
		"type":       "http",
		"parameters": map[string]string{"url": url},
	}))
	if status != 200 {
		return fmt.Errorf("rclonexfer: config http: status %d: %s", status, out)
	}
	return nil
}

func ConfigHTTPRemoteWithHeaders(name, url, headers string) error {
	params := map[string]string{"url": url}
	if headers != "" {
		params["headers"] = headers
	}
	out, status := configRPC("config/create", mustJSON(map[string]any{
		"name":       name,
		"type":       "http",
		"parameters": params,
	}))
	if status != 200 {
		return fmt.Errorf("rclonexfer: config http: status %d: %s", status, out)
	}
	return nil
}

func ConfigWebDAVRemoteWithHeaders(name, url, headers string) error {
	params := map[string]string{"url": url}
	if headers != "" {
		params["headers"] = headers
	}
	out, status := configRPC("config/create", mustJSON(map[string]any{
		"name":       name,
		"type":       "webdav",
		"parameters": params,
	}))
	if status != 200 {
		return fmt.Errorf("rclonexfer: config webdav: status %d: %s", status, out)
	}
	return nil
}

func SyncCopy(srcFs, dstFs string, includePatterns []string) (int64, error) {
	return syncCopy(srcFs, dstFs, includePatterns, nil, false)
}

func SyncCopySizeOnly(srcFs, dstFs string) (int64, error) {
	return syncCopy(srcFs, dstFs, nil, nil, true)
}

func SyncCopyFiltered(srcFs, dstFs string, includePatterns, excludePatterns []string, sizeOnly bool) (int64, error) {
	return syncCopy(srcFs, dstFs, includePatterns, excludePatterns, sizeOnly)
}

func syncCopy(srcFs, dstFs string, includePatterns, excludePatterns []string, sizeOnly bool) (int64, error) {
	cfg := map[string]any{
		"Inplace":       false,
		"PartialSuffix": ".rcpartial",
	}
	if sizeOnly {
		cfg["SizeOnly"] = true
	}
	params := map[string]any{
		"srcFs":   srcFs,
		"dstFs":   dstFs,
		"_async":  true,
		"_config": cfg,
	}
	if len(includePatterns) > 0 || len(excludePatterns) > 0 {
		filter := map[string]any{}
		if len(includePatterns) > 0 {
			filter["IncludeRule"] = includePatterns
		}
		if len(excludePatterns) > 0 {
			filter["ExcludeRule"] = excludePatterns
		}
		params["_filter"] = filter
	}

	out, status := librclone.RPC("sync/copy", mustJSON(params))
	if status != 200 {
		return 0, fmt.Errorf("rclonexfer: sync/copy: status %d: %s", status, out)
	}

	var resp struct {
		JobID int64 `json:"jobid"`
	}
	if err := json.Unmarshal([]byte(out), &resp); err != nil {
		return 0, fmt.Errorf("rclonexfer: parse job response: %w", err)
	}
	return resp.JobID, nil
}

// SyncOptions tune a mirror sync. The zero value is a plain mirror.
type SyncOptions struct {
	// DryRun asks rclone to report what it would transfer and delete without
	// touching the destination.
	DryRun bool
	// MaxDelete aborts the sync once more than this many deletions are
	// needed. Zero permits no deletions at all; negative leaves rclone's
	// default (unlimited). It is a backstop, not a preflight: rclone checks
	// it while running, so it can delete some objects before refusing.
	MaxDelete int
}

// SyncSync mirrors srcFs onto dstFs, deleting destination objects that the
// source no longer has. This is rclone's own sync engine: it enumerates both
// sides in parallel while transferring, which is the work accorder used to
// hand to it and should again.
func SyncSync(srcFs, dstFs string, includePatterns, excludePatterns []string, opts SyncOptions) (int64, error) {
	// This is the configuration the pre-bfd9e8b publish used, and it is the
	// reason that publish was fast on a real collection:
	//
	//   UseListR  one flat recursive listing instead of a request per
	//             directory. A 2,712-author library is 2,712 round trips
	//             without it, which is where a 25-minute enumeration goes.
	//   SizeOnly  compare by size alone. The alternative asks the backend for
	//             a hash or modification time per object, and on S3 an ETag
	//             that is not an MD5 costs a request each to resolve.
	//   Inplace   write to the final key rather than a .partial that then
	//             has to be renamed; on object storage a rename is a copy.
	cfg := map[string]any{
		"Inplace":            true,
		"UseListR":           true,
		"SizeOnly":           true,
		"CreateEmptySrcDirs": true,
	}
	if opts.DryRun {
		cfg["DryRun"] = true
	}
	if opts.MaxDelete >= 0 {
		cfg["MaxDelete"] = opts.MaxDelete
	}
	params := map[string]any{
		"srcFs":   srcFs,
		"dstFs":   dstFs,
		"_async":  true,
		"_config": cfg,
	}
	if len(includePatterns) > 0 || len(excludePatterns) > 0 {
		filter := map[string]any{}
		if len(includePatterns) > 0 {
			filter["IncludeRule"] = includePatterns
		}
		if len(excludePatterns) > 0 {
			filter["ExcludeRule"] = excludePatterns
		}
		params["_filter"] = filter
	}
	out, status := librclone.RPC("sync/sync", mustJSON(params))
	if status != 200 {
		return 0, fmt.Errorf("rclonexfer: sync/sync: status %d: %s", status, out)
	}
	var resp struct {
		JobID int64 `json:"jobid"`
	}
	if err := json.Unmarshal([]byte(out), &resp); err != nil {
		return 0, fmt.Errorf("rclonexfer: parse job response: %w", err)
	}
	return resp.JobID, nil
}

// CopyAllOverwrite asks rclone to enumerate the selected source tree and copy
// every matching file even when size and modification time match. It is the
// conservative correctness lane used after a SizeOnly mirror when the caller
// cannot retain a complete narrow set of possibly divergent payload paths.
// Unlike SyncSync it never deletes destination objects.
func CopyAllOverwrite(srcFs, dstFs string, includePatterns, excludePatterns []string) (int64, error) {
	params := map[string]any{
		"srcFs":  srcFs,
		"dstFs":  dstFs,
		"_async": true,
		"_config": map[string]any{
			"IgnoreTimes": true,
			"Inplace":     true,
			"UseListR":    true,
		},
	}
	if len(includePatterns) > 0 || len(excludePatterns) > 0 {
		filter := map[string]any{}
		if len(includePatterns) > 0 {
			filter["IncludeRule"] = includePatterns
		}
		if len(excludePatterns) > 0 {
			filter["ExcludeRule"] = excludePatterns
		}
		params["_filter"] = filter
	}
	out, status := librclone.RPC("sync/copy", mustJSON(params))
	if status != 200 {
		return 0, fmt.Errorf("rclonexfer: overwrite copy: status %d: %s", status, out)
	}
	var resp struct {
		JobID int64 `json:"jobid"`
	}
	if err := json.Unmarshal([]byte(out), &resp); err != nil {
		return 0, fmt.Errorf("rclonexfer: parse overwrite-copy response: %w", err)
	}
	return resp.JobID, nil
}

func ListSizes(fs string, includePatterns []string) (map[string]int64, error) {
	objects, err := ListObjects(fs, includePatterns, nil)
	if err != nil {
		return nil, err
	}
	sizes := make(map[string]int64, len(objects))
	for _, object := range objects {
		sizes[object.Path] = object.Size
	}
	return sizes, nil
}

func ListObjects(fs string, includePatterns, excludePatterns []string) ([]RemoteObject, error) {
	return listObjects(fs, "", includePatterns, excludePatterns, true)
}

// ListDirectoryObjects lists only descendants of remoteDir, with paths relative
// to fsPath. It requests neither hashes nor modification times. A missing
// directory is empty; other backend errors must not be mistaken for absence.
func ListDirectoryObjects(fsPath, remoteDir string) ([]RemoteObject, error) {
	if remoteDir == "" || remoteDir == "." {
		return nil, fmt.Errorf("rclonexfer: a directory prefix is required")
	}
	return listObjects(fsPath, remoteDir, nil, nil, false)
}

func listObjects(fs, remoteDir string, includePatterns, excludePatterns []string, showHash bool) ([]RemoteObject, error) {
	params := map[string]any{
		"fs":     fs,
		"remote": remoteDir,
		"opt":    map[string]any{"recurse": true, "filesOnly": true, "showHash": showHash, "noModTime": !showHash},
	}
	if len(includePatterns) > 0 || len(excludePatterns) > 0 {
		filter := map[string]any{}
		if len(includePatterns) > 0 {
			filter["IncludeRule"] = includePatterns
		}
		if len(excludePatterns) > 0 {
			filter["ExcludeRule"] = excludePatterns
		}
		params["_filter"] = filter
	}
	out, status := librclone.RPC("operations/list", mustJSON(params))
	// rc.Error maps fs.ErrorDirNotFound/ErrObjectNotFound to 404. Only a
	// prefix-scoped cleanup query treats this as an already-empty directory.
	if status == 404 && remoteDir != "" {
		return nil, nil
	}
	if status != 200 {
		return nil, fmt.Errorf("rclonexfer: operations/list %s: status %d: %s", fs, status, out)
	}
	var resp struct {
		List []struct {
			Path    string            `json:"Path"`
			Size    int64             `json:"Size"`
			IsDir   bool              `json:"IsDir"`
			ModTime string            `json:"ModTime"`
			Hashes  map[string]string `json:"Hashes"`
		} `json:"list"`
	}
	if err := json.Unmarshal([]byte(out), &resp); err != nil {
		return nil, fmt.Errorf("rclonexfer: parse list %s: %w", fs, err)
	}
	objects := make([]RemoteObject, 0, len(resp.List))
	for _, e := range resp.List {
		if e.IsDir {
			continue
		}
		var modTime time.Time
		if e.ModTime != "" {
			modTime, _ = time.Parse(time.RFC3339Nano, e.ModTime)
		}
		objects = append(objects, RemoteObject{Path: e.Path, Size: e.Size, ModTime: modTime, Hashes: e.Hashes})
	}
	sort.Slice(objects, func(i, j int) bool { return objects[i].Path < objects[j].Path })
	return objects, nil
}

func StatObject(fsPath, remotePath string) (*RemoteObject, error) {
	out, status := librclone.RPC("operations/stat", mustJSON(map[string]any{
		"fs": fsPath, "remote": remotePath, "opt": map[string]any{"showHash": true},
	}))
	if status != 200 {
		return nil, fmt.Errorf("rclonexfer: operations/stat %s/%s: status %d: %s", fsPath, remotePath, status, out)
	}
	var resp struct {
		Item *struct {
			Path    string            `json:"Path"`
			Name    string            `json:"Name"`
			Size    int64             `json:"Size"`
			ModTime string            `json:"ModTime"`
			Hashes  map[string]string `json:"Hashes"`
		} `json:"item"`
	}
	if err := json.Unmarshal([]byte(out), &resp); err != nil {
		return nil, fmt.Errorf("rclonexfer: parse stat %s/%s: %w", fsPath, remotePath, err)
	}
	if resp.Item == nil {
		return nil, nil
	}
	path := resp.Item.Path
	if path == "" {
		path = remotePath
	}
	var modTime time.Time
	if resp.Item.ModTime != "" {
		modTime, _ = time.Parse(time.RFC3339Nano, resp.Item.ModTime)
	}
	return &RemoteObject{Path: path, Size: resp.Item.Size, ModTime: modTime, Hashes: resp.Item.Hashes}, nil
}

func DeleteFile(fsPath, remotePath string) error {
	out, status := librclone.RPC("operations/deletefile", mustJSON(map[string]any{
		"fs": fsPath, "remote": remotePath,
	}))
	if status != 200 {
		return fmt.Errorf("rclonexfer: deletefile %s/%s: status %d: %s", fsPath, remotePath, status, out)
	}
	return nil
}

func VerifyAndRepairSync(srcFs, dstFs string, includePatterns []string) ([]string, error) {
	srcSizes, err := ListSizes(srcFs, includePatterns)
	if err != nil {
		return nil, fmt.Errorf("rclonexfer: list src: %w", err)
	}
	dstSizes, err := ListSizes(dstFs, nil)
	if err != nil {
		return nil, fmt.Errorf("rclonexfer: list dst: %w", err)
	}

	var repaired []string
	for path, srcSize := range srcSizes {
		dstSize, ok := dstSizes[path]
		if ok && dstSize == srcSize {
			continue
		}
		if err := CopyFile(srcFs, path, dstFs, path); err != nil {
			return repaired, fmt.Errorf("rclonexfer: repair %s (src %d, dst %d): %w", path, srcSize, dstSize, err)
		}
		repaired = append(repaired, path)
	}
	return repaired, nil
}

func CopyFile(srcFs, srcPath, dstFs, dstPath string) error {
	out, status := librclone.RPC("operations/copyfile", mustJSON(map[string]any{
		"srcFs":     srcFs,
		"srcRemote": srcPath,
		"dstFs":     dstFs,
		"dstRemote": dstPath,
	}))
	if status != 200 {
		return fmt.Errorf("rclonexfer: copyfile: status %d: %s", status, out)
	}
	return nil
}

// CopyFileOverwrite copies one object without rclone's size/time equality
// shortcut. Use it only when the caller has independent evidence that this
// path belongs to a changed publication; ordinary CopyFile retains the cheaper
// default comparison behavior.
func CopyFileOverwrite(srcFs, srcPath, dstFs, dstPath string) error {
	out, status := librclone.RPC("operations/copyfile", mustJSON(map[string]any{
		"srcFs":     srcFs,
		"srcRemote": srcPath,
		"dstFs":     dstFs,
		"dstRemote": dstPath,
		"_config": map[string]any{
			"IgnoreTimes": true,
			"Inplace":     true,
		},
	}))
	if status != 200 {
		return fmt.Errorf("rclonexfer: overwrite copyfile: status %d: %s", status, out)
	}
	return nil
}

func CopyFileAsync(srcFs, srcPath, dstFs, dstPath string) (int64, error) {
	out, status := librclone.RPC("operations/copyfile", mustJSON(map[string]any{
		"srcFs":     srcFs,
		"srcRemote": srcPath,
		"dstFs":     dstFs,
		"dstRemote": dstPath,
		"_async":    true,
		"_config": map[string]any{
			"Inplace":       false,
			"PartialSuffix": ".rcpartial",
		},
	}))
	if status != 200 {
		return 0, fmt.Errorf("rclonexfer: copyfile (async): status %d: %s", status, out)
	}
	var resp struct {
		JobID int64 `json:"jobid"`
	}
	if err := json.Unmarshal([]byte(out), &resp); err != nil {
		return 0, fmt.Errorf("rclonexfer: parse job response: %w", err)
	}
	return resp.JobID, nil
}

func StopJob(jobID int64) error {
	out, status := librclone.RPC("job/stop", fmt.Sprintf(`{"jobid":%d}`, jobID))
	if status != 200 {
		return fmt.Errorf("rclonexfer: job/stop: status %d: %s", status, out)
	}
	return nil
}

func PollProgress(jobID int64) <-chan SyncStats {
	ch := make(chan SyncStats, 1)
	go func() {
		defer close(ch)
		poll := func() bool {
			var stats SyncStats
			out, _ := librclone.RPC("core/stats", fmt.Sprintf(`{"group":"job/%d"}`, jobID))
			_ = json.Unmarshal([]byte(out), &stats)

			var job struct {
				Finished bool   `json:"finished"`
				Success  bool   `json:"success"`
				Error    string `json:"error"`
			}
			out, _ = librclone.RPC("job/status", fmt.Sprintf(`{"jobid":%d}`, jobID))
			_ = json.Unmarshal([]byte(out), &job)

			stats.Finished = job.Finished
			stats.Success = job.Success
			stats.Error = job.Error
			ch <- stats
			return job.Finished
		}
		if poll() {
			return
		}
		ticker := time.NewTicker(100 * time.Millisecond)
		defer ticker.Stop()
		for range ticker.C {
			if poll() {
				return
			}
		}
	}()
	return ch
}

func WaitJob(jobID int64) (SyncStats, error) {
	var last SyncStats
	for stats := range PollProgress(jobID) {
		last = stats
		if !stats.Finished {
			continue
		}
		if !stats.Success {
			if stats.Error == "" {
				stats.Error = "unknown transfer error"
			}
			return stats, fmt.Errorf("rclonexfer: job %d failed: %s", jobID, stats.Error)
		}
		return stats, nil
	}
	return last, fmt.Errorf("rclonexfer: job %d ended without a terminal status", jobID)
}

type VFSOptions struct {
	CacheMode         string // "off", "minimal", "writes", "full"
	CacheMaxSize      string // e.g. "2Gi", "10Gi"
	CacheMaxAge       string // e.g. "1h", "8760h"; rclone purges any NOT-IN-USE item on every cleaner pass when this is "0" (vfscache item.go: maxAge==0 => removeIt) — use a large duration, not "0", for quota-only eviction
	CacheMinFreeSpace string // disk-safety floor, e.g. "2Gi"; "0" disables
	CachePollInterval string // optional cleaner cadence; production uses rclone's default, scratch tests shorten it
	HandleCaching     string // optional handle grace; production uses rclone's default, scratch tests shorten it
	DirCacheTime      string // in-memory directory metadata lifetime, e.g. "24h"; parsed by rclone
	ReadOnly          bool
}

func ServeHTTPWithVFS(fsPath, addr string, vfsOpts VFSOptions) (id, boundAddr string, err error) {
	params := map[string]any{
		"type": "http",
		"fs":   fsPath,
		"addr": addr,
	}
	if vfsOpts.CacheMode != "" {
		params["vfs_cache_mode"] = vfsOpts.CacheMode
	}
	if vfsOpts.CacheMaxSize != "" {
		params["vfs_cache_max_size"] = vfsOpts.CacheMaxSize
	}
	if vfsOpts.CacheMaxAge != "" {
		params["vfs_cache_max_age"] = vfsOpts.CacheMaxAge
	}
	if vfsOpts.CacheMinFreeSpace != "" {
		params["vfs_cache_min_free_space"] = vfsOpts.CacheMinFreeSpace
	}
	if vfsOpts.CachePollInterval != "" {
		params["vfs_cache_poll_interval"] = vfsOpts.CachePollInterval
	}
	if vfsOpts.HandleCaching != "" {
		params["vfs_handle_caching"] = vfsOpts.HandleCaching
	}
	if vfsOpts.DirCacheTime != "" {
		params["dir_cache_time"] = vfsOpts.DirCacheTime
	}
	if vfsOpts.ReadOnly {
		params["read_only"] = true
	}
	out, status := librclone.RPC("serve/start", mustJSON(params))
	if status != 200 {
		return "", "", fmt.Errorf("rclonexfer: serve/start (http vfs): status %d: %s", status, out)
	}
	var resp struct {
		ID   string `json:"id"`
		Addr string `json:"addr"`
	}
	if err := json.Unmarshal([]byte(out), &resp); err != nil {
		return "", "", fmt.Errorf("rclonexfer: parse serve/start response: %w", err)
	}
	if resp.Addr == "" || resp.ID == "" {
		return "", "", fmt.Errorf("rclonexfer: serve/start returned empty id/addr: %s", out)
	}
	return resp.ID, resp.Addr, nil
}

func ServeWebDAVWithVFS(fsPath, addr string, vfsOpts VFSOptions) (id, boundAddr string, err error) {
	params := map[string]any{
		"type": "webdav",
		"fs":   fsPath,
		"addr": addr,
	}
	if vfsOpts.CacheMode != "" {
		params["vfs_cache_mode"] = vfsOpts.CacheMode
	}
	if vfsOpts.CacheMaxSize != "" {
		params["vfs_cache_max_size"] = vfsOpts.CacheMaxSize
	}
	if vfsOpts.CacheMaxAge != "" {
		params["vfs_cache_max_age"] = vfsOpts.CacheMaxAge
	}
	if vfsOpts.CacheMinFreeSpace != "" {
		params["vfs_cache_min_free_space"] = vfsOpts.CacheMinFreeSpace
	}
	if vfsOpts.CachePollInterval != "" {
		params["vfs_cache_poll_interval"] = vfsOpts.CachePollInterval
	}
	if vfsOpts.HandleCaching != "" {
		params["vfs_handle_caching"] = vfsOpts.HandleCaching
	}
	if vfsOpts.DirCacheTime != "" {
		params["dir_cache_time"] = vfsOpts.DirCacheTime
	}
	if vfsOpts.ReadOnly {
		params["read_only"] = true
	}
	out, status := librclone.RPC("serve/start", mustJSON(params))
	if status != 200 {
		return "", "", fmt.Errorf("rclonexfer: serve/start (vfs): status %d: %s", status, out)
	}
	var resp struct {
		ID   string `json:"id"`
		Addr string `json:"addr"`
	}
	if err := json.Unmarshal([]byte(out), &resp); err != nil {
		return "", "", fmt.Errorf("rclonexfer: parse serve/start response: %w", err)
	}
	if resp.Addr == "" || resp.ID == "" {
		return "", "", fmt.Errorf("rclonexfer: serve/start returned empty id/addr: %s", out)
	}
	return resp.ID, resp.Addr, nil
}

// ForgetVFSDirectories invalidates only in-memory directory metadata for one
// explicitly selected VFS. With no dirs it forgets that VFS's complete
// directory tree. Cached full-mode file data is not removed.
func ForgetVFSDirectories(fsPath string, dirs ...string) error {
	if strings.TrimSpace(fsPath) == "" {
		return fmt.Errorf("rclonexfer: vfs/forget: fs is required")
	}
	params := map[string]any{"fs": fsPath}
	for i, dir := range dirs {
		dir = strings.Trim(strings.TrimSpace(dir), "/")
		if dir == "" {
			return fmt.Errorf("rclonexfer: vfs/forget %s: directory %d is empty", fsPath, i+1)
		}
		// rclone's vfs/forget dispatches on the "dir" key prefix, so any
		// distinct suffix selects a directory.
		params[fmt.Sprintf("dir%d", i+1)] = dir
	}
	_, status := librclone.RPC("vfs/forget", mustJSON(params))
	if status != 200 {
		// The librclone error body echoes the complete input map, including
		// directory arguments. Keep member paths out of callers' durable logs.
		return fmt.Errorf("rclonexfer: vfs/forget %s: status %d", fsPath, status)
	}
	return nil
}

type S3RemoteConfig struct {
	Provider  string
	AccessKey string
	SecretKey string
	Endpoint  string
}

func ConfigS3Remote(name string, cfg S3RemoteConfig) error {
	out, status := configRPC("config/create", mustJSON(map[string]any{
		"name": name,
		"type": "s3",
		"parameters": map[string]string{
			"provider":          cfg.Provider,
			"access_key_id":     cfg.AccessKey,
			"secret_access_key": cfg.SecretKey,
			"endpoint":          cfg.Endpoint,
			"no_check_bucket":   "true",
		},
	}))
	if status != 200 {
		return fmt.Errorf("rclonexfer: config/create s3: status %d: %s", status, out)
	}
	return nil
}

func DeleteRemote(name string) error {
	out, status := configRPC("config/delete", mustJSON(map[string]any{"name": name}))
	if status != 200 {
		return fmt.Errorf("rclonexfer: config/delete: status %d: %s", status, out)
	}
	return nil
}

func FileExists(fsPath, remotePath string) (bool, error) {
	out, status := librclone.RPC("operations/stat", mustJSON(map[string]any{
		"fs":     fsPath,
		"remote": remotePath,
	}))
	if status != 200 {
		return false, fmt.Errorf("rclonexfer: operations/stat %s/%s: status %d: %s", fsPath, remotePath, status, out)
	}
	var resp struct {
		Item any `json:"item"`
	}
	if err := json.Unmarshal([]byte(out), &resp); err != nil {
		return false, fmt.Errorf("rclonexfer: parse stat %s/%s: %w", fsPath, remotePath, err)
	}
	return resp.Item != nil, nil
}

func SetCacheDir(path string) error {
	return config.SetCacheDir(path)
}

// LogLevels are the values SetLogLevel accepts, loudest last.
var LogLevels = []string{"EMERGENCY", "ALERT", "CRITICAL", "ERROR", "WARNING", "NOTICE", "INFO", "DEBUG", "OFF"}

// SetLogLevel raises the log level of the embedded rclone. It defaults to
// NOTICE, which suppresses everything logged at Infof — including the VFS cache
// cleaner's per-pass line:
//
//	vfs cache: cleaned: objects N (was M) in use K, to upload U, uploading V, total size X (was Y)
//
// That line is the only direct evidence of whether size-quota eviction is
// keeping up: it reports how many items are pinned in use (purgeOverQuota can
// only evict items where !item.inUse()) and whether the total is falling. Its
// ABSENCE from the journal is not evidence the cleaner is dead — at NOTICE it
// is simply never emitted. See ROADMAP ca-120.
//
// MUST be called AFTER Initialize(): librclone.Initialize calls
// fs/log.InitLogging, which resets the handler's level to fs.InitialLogLevel(),
// silently discarding a level set before it.
//
// The empty string is a no-op so callers can pass an unset flag straight
// through and leave rclone's default alone.
//
// Note this sets rclone's GLOBAL config, so it affects every rclone operation
// in the process, not just the VFS. INFO on a busy serve is chatty by design —
// it is a diagnostic, not a normal operating mode.
func SetLogLevel(level string) error {
	if level == "" {
		return nil
	}
	var lvl fs.LogLevel
	if err := lvl.Set(strings.ToUpper(strings.TrimSpace(level))); err != nil {
		return fmt.Errorf("rclonexfer: bad rclone log level %q (want one of %s): %w",
			level, strings.Join(LogLevels, ", "), err)
	}
	ci := fs.GetConfig(nil)
	ci.LogLevel = lvl
	// Setting ci.LogLevel alone is NOT enough. rclone's slog handler carries its
	// own level, which only fs.LogReload pushes into it (fs/log logReload ->
	// Handler.SetLevel). Skip this and the config reports INFO while the handler
	// still filters at NOTICE, so nothing extra is ever emitted — which looks
	// exactly like "the thing I wanted to observe is not happening".
	if fs.LogReload != nil {
		if err := fs.LogReload(ci); err != nil {
			return fmt.Errorf("rclonexfer: apply rclone log level %q: %w", level, err)
		}
	}
	return nil
}
