package rclonexfer

import (
	"context"
	"log/slog"
	"testing"

	"github.com/rclone/rclone/fs"
	fslog "github.com/rclone/rclone/fs/log"
)

// infoEmitted reports whether rclone's slog handler would actually emit an
// Info record. This is the observable that matters: ci.LogLevel is only
// bookkeeping until fs.LogReload pushes it into the handler, so a test that
// checks ci.LogLevel alone passes even when nothing is emitted.
func infoEmitted() bool {
	return fslog.Handler.Enabled(context.Background(), slog.LevelInfo)
}

// TestSetLogLevel covers the contract the ca-120 diagnostic depends on: an
// unset flag leaves rclone's default alone, a valid level actually changes what
// gets emitted, and a typo fails loudly rather than silently leaving NOTICE
// (which would keep the cache cleaner's stats invisible and read as "the
// cleaner isn't running").
func TestSetLogLevel(t *testing.T) {
	orig := fs.GetConfig(nil).LogLevel
	t.Cleanup(func() {
		fs.GetConfig(nil).LogLevel = orig
		if fs.LogReload != nil {
			_ = fs.LogReload(fs.GetConfig(nil))
		}
	})

	t.Run("empty is a no-op", func(t *testing.T) {
		if err := SetLogLevel("NOTICE"); err != nil {
			t.Fatal(err)
		}
		before := fs.GetConfig(nil).LogLevel
		if err := SetLogLevel(""); err != nil {
			t.Fatalf("SetLogLevel(\"\") = %v, want nil", err)
		}
		if got := fs.GetConfig(nil).LogLevel; got != before {
			t.Errorf("level = %v, want it left at %v", got, before)
		}
	})

	// The regression guard. Before the fs.LogReload call was added, SetLogLevel
	// set ci.LogLevel and returned — the handler kept filtering at NOTICE and no
	// Info record was ever emitted. Asserting on ci.LogLevel would NOT have
	// caught that; asserting on the handler does.
	t.Run("INFO actually reaches the handler", func(t *testing.T) {
		if err := SetLogLevel("NOTICE"); err != nil {
			t.Fatal(err)
		}
		if infoEmitted() {
			t.Fatal("Info records emitted at NOTICE; the handler is not being filtered, so this test cannot discriminate")
		}

		if err := SetLogLevel("INFO"); err != nil {
			t.Fatalf("SetLogLevel(\"INFO\") = %v, want nil", err)
		}
		if got := fs.GetConfig(nil).LogLevel; got != fs.LogLevelInfo {
			t.Errorf("ci.LogLevel = %v, want INFO", got)
		}
		if !infoEmitted() {
			t.Error("ci.LogLevel is INFO but the handler still suppresses Info records — fs.LogReload was not applied")
		}
	})

	t.Run("parses case-insensitively and trimmed", func(t *testing.T) {
		for _, in := range []string{"info", " INFO ", "Info"} {
			if err := SetLogLevel("NOTICE"); err != nil {
				t.Fatal(err)
			}
			if err := SetLogLevel(in); err != nil {
				t.Fatalf("SetLogLevel(%q) = %v, want nil", in, err)
			}
			if !infoEmitted() {
				t.Errorf("SetLogLevel(%q) did not raise the handler to INFO", in)
			}
		}
	})

	t.Run("rejects a bad level and leaves the config untouched", func(t *testing.T) {
		if err := SetLogLevel("NOTICE"); err != nil {
			t.Fatal(err)
		}
		if err := SetLogLevel("VERBOSE"); err == nil { // plausible typo; not an rclone level
			t.Fatal("SetLogLevel(\"VERBOSE\") = nil, want an error")
		}
		if got := fs.GetConfig(nil).LogLevel; got != fs.LogLevelNotice {
			t.Errorf("level = %v after a rejected set, want it unchanged at NOTICE", got)
		}
		if infoEmitted() {
			t.Error("handler raised to INFO by a rejected level")
		}
	})

	t.Run("every advertised level parses", func(t *testing.T) {
		for _, name := range LogLevels {
			if err := SetLogLevel(name); err != nil {
				t.Errorf("LogLevels advertises %q but SetLogLevel rejects it: %v", name, err)
			}
		}
	})
}
