//go:build integration

package rclonexfer

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/rclone/rclone/librclone/librclone"
)

// TestIncludeRuleFilter verifies that an IncludeRule allow-list actually
// drops files outside the list. Spins up a local WebDAV server over a temp
// fixture, runs sync/copy with includes, then asserts that excluded files
// did not appear at the destination.
func TestIncludeRuleFilter(t *testing.T) {
	src := t.TempDir()
	must := func(path, content string) {
		full := filepath.Join(src, path)
		if err := os.MkdirAll(filepath.Dir(full), 0755); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(full, []byte(content), 0644); err != nil {
			t.Fatal(err)
		}
	}
	must("BROWSE_LIBRARY.html", "ok")
	must("_GENERATION", "g")
	must("metadata.db", "should-be-excluded")
	must("static/data1.js", "ok")
	must("static/data2.js", "should-be-excluded")
	must("static/library_index.zst", "ok")
	must("static/css/bundle.css", "ok")
	must("static/js/bundle.js", "ok")
	must("Some Author/Some Title (1)/cover.jpg", "should-be-excluded")
	must("Some Author/Some Title (1)/Some Title - Some Author.epub", "should-be-excluded")

	Initialize()
	defer Finalize()

	id, addr, err := ServeWebDAV(src, "127.0.0.1:0")
	if err != nil {
		t.Fatalf("ServeWebDAV: %v", err)
	}
	defer StopServe(id)

	if err := ConfigWebDAVRemote("librarian-smoke", "http://"+addr+"/"); err != nil {
		t.Fatalf("ConfigWebDAVRemote: %v", err)
	}

	dst := t.TempDir()
	includes := []string{
		"BROWSE_LIBRARY.html",
		"_GENERATION",
		"static/data1.js",
		"static/library_index.zst",
		"static/css/**",
		"static/js/**",
	}

	// Sync synchronously by polling job to completion. SyncCopy returns
	// a jobID for the async path.
	jobID, err := SyncCopy("librarian-smoke:", dst, includes)
	if err != nil {
		t.Fatalf("SyncCopy: %v", err)
	}
	for stats := range PollProgress(jobID) {
		if stats.Finished {
			break
		}
	}

	// What should be present.
	mustExist := []string{
		"BROWSE_LIBRARY.html",
		"_GENERATION",
		"static/data1.js",
		"static/library_index.zst",
		"static/css/bundle.css",
		"static/js/bundle.js",
	}
	for _, p := range mustExist {
		if _, err := os.Stat(filepath.Join(dst, p)); err != nil {
			t.Errorf("missing expected file %q: %v", p, err)
		}
	}

	// What must be absent.
	mustBeAbsent := []string{
		"metadata.db",
		"static/data2.js",
		"Some Author/Some Title (1)/cover.jpg",
		"Some Author/Some Title (1)/Some Title - Some Author.epub",
	}
	for _, p := range mustBeAbsent {
		if _, err := os.Stat(filepath.Join(dst, p)); err == nil {
			t.Errorf("unexpected file present at dst: %s — filter did not drop it", p)
		}
	}

	// Dump dst tree on failure for debugging.
	if t.Failed() {
		var paths []string
		_ = filepath.Walk(dst, func(p string, info os.FileInfo, err error) error {
			if err == nil && !info.IsDir() {
				rel, _ := filepath.Rel(dst, p)
				paths = append(paths, rel)
			}
			return nil
		})
		t.Logf("dst tree:\n%s", strings.Join(paths, "\n"))
	}

	// Sanity: stats endpoint still returns valid JSON.
	out, _ := librclone.RPC("core/stats", "{}")
	var stats map[string]any
	_ = json.Unmarshal([]byte(out), &stats)
}
