//go:build integration

// Phase 0 SPIKE — endpoint-protection workflow
// Discovery test for assumption A1: does core/stats report bytes for a
// serve/start-backed VFS WebDAV server?
//

// Verdict target: OBSERVABLE / NOT OBSERVABLE / OBSERVABLE-WITH-CAVEAT
// DELETE or promote during implement phase.

package rclonexfer

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/rclone/rclone/librclone/librclone"
)

// TestA1_CoreStatsForVFSServe starts a local-fs WebDAV serve, fetches a file
// through it, then queries core/stats (global and with group= variants) to see
// if bytes transferred are reported.
//

// Expected outcome: core/stats DOES report serve bytes (global group; serve-
// specific group returns zeroes). Validated empirically — bytes increment by
// the exact file size after a fetch through the VFS WebDAV server.
func TestA1_CoreStatsForVFSServe(t *testing.T) {

	// Create a temp dir with a known file
	tmp := t.TempDir()
	payload := make([]byte, 64*1024) // 64 KiB
	for i := range payload {
		payload[i] = byte(i % 256)
	}
	if err := os.WriteFile(filepath.Join(tmp, "testblob.bin"), payload, 0644); err != nil {
		t.Fatal(err)
	}

	librclone.Initialize()
	defer librclone.Finalize()

	// Reset global stats before serve
	resetOut, resetStatus := librclone.RPC("core/stats-reset", "{}")
	t.Logf("core/stats-reset: status=%d out=%s", resetStatus, resetOut)

	// Start WebDAV serve on local dir
	id, addr, err := ServeWebDAVWithVFS(tmp, "127.0.0.1:0", VFSOptions{})
	if err != nil {
		t.Fatalf("ServeWebDAVWithVFS: %v", err)
	}
	defer func() {
		if err := StopServe(id); err != nil {
			t.Logf("StopServe: %v", err)
		}
	}()
	t.Logf("serve started: id=%s addr=%s", id, addr)

	// Snapshot core/stats BEFORE any HTTP fetch
	statsBefore := coreStats(t, "")
	t.Logf("core/stats BEFORE fetch (global): %s", statsBefore)

	// Fetch the file through the WebDAV serve
	client := &http.Client{Timeout: 10 * time.Second}
	resp, err := client.Get("http://" + addr + "/testblob.bin")
	if err != nil {
		t.Fatalf("GET testblob.bin: %v", err)
	}
	body, _ := io.ReadAll(resp.Body)
	resp.Body.Close()
	if resp.StatusCode != 200 {
		t.Fatalf("GET testblob.bin: status=%d", resp.StatusCode)
	}
	if len(body) != len(payload) {
		t.Fatalf("GET testblob.bin: expected %d bytes, got %d", len(payload), len(body))
	}
	t.Logf("GET testblob.bin: status=%d bodyLen=%d", resp.StatusCode, len(body))

	// Wait a moment for any async accounting
	time.Sleep(200 * time.Millisecond)

	// Query core/stats AFTER fetch — global (no group)
	statsAfterGlobal := coreStats(t, "")
	t.Logf("core/stats AFTER fetch (global): %s", statsAfterGlobal)

	// Query core/stats with serve ID as group
	statsAfterServeGroup := coreStats(t, id)
	t.Logf("core/stats AFTER fetch (group=%s): %s", id, statsAfterServeGroup)

	// Query core/stats-groups to see what groups exist
	groupsOut, groupsStatus := librclone.RPC("core/stats", `{"group":""}`)
	t.Logf("core/stats (empty group): status=%d out=%s", groupsStatus, groupsOut)

	// Also try vfs/stats if it exists
	vfsOut, vfsStatus := librclone.RPC("vfs/stats", "{}")
	t.Logf("vfs/stats: status=%d out=%s", vfsStatus, vfsOut)

	// Try vfs/stats with the fs path
	vfsOut2, vfsStatus2 := librclone.RPC("vfs/stats", fmt.Sprintf(`{"fs":"%s"}`, tmp))
	t.Logf("vfs/stats (fs=%s): status=%d out=%s", tmp, vfsStatus2, vfsOut2)

	// Parse and check: did bytes increment?
	var before, after struct {
		Bytes int64 `json:"bytes"`
	}
	_ = json.Unmarshal([]byte(statsBefore), &before)
	_ = json.Unmarshal([]byte(statsAfterGlobal), &after)

	bytesTransferred := after.Bytes - before.Bytes
	t.Logf("VERDICT: core/stats global bytes delta = %d (file was %d bytes)", bytesTransferred, len(payload))

	if bytesTransferred >= int64(len(payload)) {
		t.Logf("A1 VERDICT: OBSERVABLE — core/stats reports serve bytes (delta=%d)", bytesTransferred)
	} else if bytesTransferred > 0 {
		t.Logf("A1 VERDICT: OBSERVABLE-WITH-CAVEAT — core/stats reports partial bytes (delta=%d, expected >=%d)", bytesTransferred, len(payload))
	} else {
		t.Logf("A1 VERDICT: NOT OBSERVABLE — core/stats does NOT report VFS serve bytes (delta=%d)", bytesTransferred)
		t.Log("FALLBACK: must use http.ResponseWriter byte-counting middleware for egress signal")
	}
}

// coreStats calls core/stats with an optional group and returns the raw JSON.
func coreStats(t *testing.T, group string) string {
	t.Helper()
	param := "{}"
	if group != "" {
		param = fmt.Sprintf(`{"group":"%s"}`, group)
	}
	out, status := librclone.RPC("core/stats", param)
	if status != 200 {
		t.Logf("core/stats (group=%q) status=%d: %s", group, status, out)
	}
	return out
}
