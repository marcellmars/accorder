//go:build integration

package rclonexfer

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	_ "github.com/rclone/rclone/backend/s3"
	"github.com/rclone/rclone/librclone/librclone"
)

// readWasabiKeys reads access-key and secret-key from repo-root wasabi.keys.
// Returns ("","") if the file is missing; tests should t.Skip in that case.
func readWasabiKeys(t *testing.T) (ak, sk string) {
	t.Helper()
	data, err := os.ReadFile("../../wasabi.keys")
	if err != nil {
		return "", ""
	}
	for _, line := range strings.Split(string(data), "\n") {
		line = strings.TrimSpace(line)
		if k, v, ok := strings.Cut(line, "="); ok {
			switch strings.TrimSpace(k) {
			case "access-key":
				ak = strings.TrimSpace(v)
			case "secret-key":
				sk = strings.TrimSpace(v)
			}
		}
	}
	return ak, sk
}

// TestWasabiVFS_ConnectionString validates that serve/start (type=webdav)
// can serve a Wasabi S3 remote using an on-the-fly connection string fs,
// with VFS cache mode=full and a size cap, and returns real file bytes.
func TestWasabiVFS_ConnectionString(t *testing.T) {
	ak, sk := readWasabiKeys(t)
	if ak == "" || sk == "" {
		t.Skip("wasabi.keys not found or incomplete — skipping live S3 test")
	}

	librclone.Initialize()
	defer librclone.Finalize()

	// Query default cache dir via config/paths
	pathsOut, pathsStatus := librclone.RPC("config/paths", "{}")
	if pathsStatus != 200 {
		t.Fatalf("config/paths: status=%d", pathsStatus)
	}
	var paths struct{ Cache string }
	_ = json.Unmarshal([]byte(pathsOut), &paths)
	vfsCacheDir := filepath.Join(paths.Cache, "vfs")
	t.Logf("VFS cache dir: %s", vfsCacheDir)

	// On-the-fly connection string form
	fs := fmt.Sprintf(":s3,provider=Wasabi,access_key_id=%s,secret_access_key=%s,endpoint=s3.wasabisys.com:motw/marcell", ak, sk)

	in, _ := json.Marshal(map[string]any{
		"type":               "webdav",
		"fs":                 fs,
		"addr":               "127.0.0.1:0",
		"vfs_cache_mode":     "full",
		"vfs_cache_max_size": "2Gi",
	})
	out, status := librclone.RPC("serve/start", string(in))
	t.Logf("serve/start status=%d out=%s", status, out)
	if status != 200 {
		t.Fatalf("serve/start failed: status=%d out=%s", status, out)
	}

	var resp struct {
		ID   string `json:"id"`
		Addr string `json:"addr"`
	}
	if err := json.Unmarshal([]byte(out), &resp); err != nil {
		t.Fatalf("parse response: %v", err)
	}
	defer func() {
		stopIn, _ := json.Marshal(map[string]any{"id": resp.ID})
		stopOut, stopStatus := librclone.RPC("serve/stop", string(stopIn))
		t.Logf("serve/stop status=%d out=%s", stopStatus, stopOut)
	}()

	t.Logf("WebDAV serving at %s", resp.Addr)

	// Fetch BROWSE_LIBRARY.html — small HTML file, cache-miss from Wasabi
	client := &http.Client{Timeout: 30 * time.Second}
	url := "http://" + resp.Addr + "/BROWSE_LIBRARY.html"
	httpResp, err := client.Get(url)
	if err != nil {
		t.Fatalf("GET %s: %v", url, err)
	}
	body, _ := io.ReadAll(httpResp.Body)
	httpResp.Body.Close()
	t.Logf("GET %s: status=%d bodyLen=%d", url, httpResp.StatusCode, len(body))
	if httpResp.StatusCode != 200 {
		t.Fatalf("expected 200, got %d", httpResp.StatusCode)
	}
	if len(body) == 0 {
		t.Fatal("empty body")
	}

	// Verify VFS cache populated on disk
	time.Sleep(500 * time.Millisecond)
	found := false
	_ = filepath.Walk(vfsCacheDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return nil
		}
		if !info.IsDir() && info.Size() > 0 && strings.Contains(path, "BROWSE_LIBRARY") {
			t.Logf("cached file: %s (%d bytes)", path, info.Size())
			found = true
		}
		return nil
	})
	if found {
		t.Log("VFS cache populated — confirmed cache-mode=full is active")
	} else {
		t.Log("WARNING: BROWSE_LIBRARY.html not found in VFS cache")
	}
}

// TestWasabiVFS_NamedRemote validates serve/start with a named S3 remote
// (created via config/create) instead of a connection-string fs.
func TestWasabiVFS_NamedRemote(t *testing.T) {
	ak, sk := readWasabiKeys(t)
	if ak == "" || sk == "" {
		t.Skip("wasabi.keys not found or incomplete — skipping live S3 test")
	}

	librclone.Initialize()
	defer librclone.Finalize()

	// Create named remote via config/create
	cfgIn, _ := json.Marshal(map[string]any{
		"name": "wasabi-spike",
		"type": "s3",
		"parameters": map[string]string{
			"provider":          "Wasabi",
			"access_key_id":     ak,
			"secret_access_key": sk,
			"endpoint":          "s3.wasabisys.com",
		},
	})
	cfgOut, cfgStatus := librclone.RPC("config/create", string(cfgIn))
	t.Logf("config/create status=%d out=%s", cfgStatus, cfgOut)
	if cfgStatus != 200 {
		t.Fatalf("config/create failed: status=%d out=%s", cfgStatus, cfgOut)
	}
	defer func() {
		delIn, _ := json.Marshal(map[string]any{"name": "wasabi-spike"})
		librclone.RPC("config/delete", string(delIn))
	}()

	in, _ := json.Marshal(map[string]any{
		"type":               "webdav",
		"fs":                 "wasabi-spike:motw/marcell",
		"addr":               "127.0.0.1:0",
		"vfs_cache_mode":     "full",
		"vfs_cache_max_size": "2Gi",
	})
	out, status := librclone.RPC("serve/start", string(in))
	t.Logf("serve/start status=%d out=%s", status, out)
	if status != 200 {
		t.Fatalf("serve/start failed: status=%d out=%s", status, out)
	}

	var resp struct {
		ID   string `json:"id"`
		Addr string `json:"addr"`
	}
	if err := json.Unmarshal([]byte(out), &resp); err != nil {
		t.Fatalf("parse response: %v", err)
	}
	defer func() {
		stopIn, _ := json.Marshal(map[string]any{"id": resp.ID})
		stopOut, stopStatus := librclone.RPC("serve/stop", string(stopIn))
		t.Logf("serve/stop status=%d out=%s", stopStatus, stopOut)
	}()

	t.Logf("WebDAV serving at %s (named remote)", resp.Addr)

	// Fetch BROWSE_LIBRARY.html
	client := &http.Client{Timeout: 30 * time.Second}
	url := "http://" + resp.Addr + "/BROWSE_LIBRARY.html"
	httpResp, err := client.Get(url)
	if err != nil {
		t.Fatalf("GET %s: %v", url, err)
	}
	body, _ := io.ReadAll(httpResp.Body)
	httpResp.Body.Close()
	t.Logf("GET %s: status=%d bodyLen=%d", url, httpResp.StatusCode, len(body))
	if httpResp.StatusCode != 200 {
		t.Fatalf("expected 200, got %d", httpResp.StatusCode)
	}
	if len(body) == 0 {
		t.Fatal("empty body")
	}

	// Check cache in default location
	pathsOut, pathsStatus := librclone.RPC("config/paths", "{}")
	var paths struct{ Cache string }
	if pathsStatus == 200 {
		_ = json.Unmarshal([]byte(pathsOut), &paths)
	}
	vfsCacheDir := filepath.Join(paths.Cache, "vfs", "wasabi-spike")
	time.Sleep(500 * time.Millisecond)
	found := false
	_ = filepath.Walk(vfsCacheDir, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return nil
		}
		if !info.IsDir() && info.Size() > 0 && strings.Contains(path, "BROWSE_LIBRARY") {
			t.Logf("cached file: %s (%d bytes)", path, info.Size())
			found = true
		}
		return nil
	})
	if found {
		t.Log("VFS cache populated for named remote — confirmed")
	} else {
		t.Log("WARNING: BROWSE_LIBRARY.html not found in named remote cache dir")
	}

	// Clean up cache for this spike
	_ = os.RemoveAll(vfsCacheDir)
}
