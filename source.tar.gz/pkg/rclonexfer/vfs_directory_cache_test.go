package rclonexfer

import (
	"bytes"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/rclone/rclone/fs/config"
	"github.com/rclone/rclone/librclone/librclone"
)

type directoryCacheSpikeHarness struct {
	t          *testing.T
	backingDir string
	cacheDir   string
	remotes    []string
	serveIDs   []string
}

type directoryCacheSpikePlane struct {
	remoteName string
	fs         string
	baseURL    string
}

func newDirectoryCacheSpikeHarness(t *testing.T) *directoryCacheSpikeHarness {
	t.Helper()

	h := &directoryCacheSpikeHarness{
		t:          t,
		backingDir: t.TempDir(),
		cacheDir:   t.TempDir(),
	}
	previousCacheDir := config.GetCacheDir()
	previousConfigPath := config.GetConfigPath()
	initialized := false

	t.Cleanup(func() {
		for i := len(h.serveIDs) - 1; i >= 0; i-- {
			if err := StopServe(h.serveIDs[i]); err != nil {
				t.Logf("StopServe(%s): %v", h.serveIDs[i], err)
			}
		}
		for i := len(h.remotes) - 1; i >= 0; i-- {
			if err := DeleteRemote(h.remotes[i]); err != nil {
				t.Logf("DeleteRemote(%s): %v", h.remotes[i], err)
			}
		}
		if initialized {
			Finalize()
		}
		if err := SetCacheDir(previousCacheDir); err != nil {
			t.Logf("restore cache dir: %v", err)
		}
		if err := config.SetConfigPath(previousConfigPath); err != nil {
			t.Logf("restore config path: %v", err)
		}
	})

	if err := config.SetConfigPath(filepath.Join(t.TempDir(), "rclone.conf")); err != nil {
		t.Fatalf("set isolated rclone config: %v", err)
	}
	if err := SetCacheDir(h.cacheDir); err != nil {
		t.Fatalf("SetCacheDir: %v", err)
	}
	Initialize()
	initialized = true
	return h
}

func (h *directoryCacheSpikeHarness) writeFile(relativePath, body string) {
	h.t.Helper()
	path := filepath.Join(h.backingDir, filepath.FromSlash(relativePath))
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		h.t.Fatalf("create parent for %s: %v", relativePath, err)
	}
	if err := os.WriteFile(path, []byte(body), 0o644); err != nil {
		h.t.Fatalf("write %s: %v", relativePath, err)
	}
}

func (h *directoryCacheSpikeHarness) startPlane(label, dirCacheTime string) directoryCacheSpikePlane {
	h.t.Helper()

	remoteName := fmt.Sprintf("vfs-dir-cache-spike-%s-%d", label, time.Now().UnixNano())
	out, status := configRPC("config/create", mustJSON(map[string]any{
		"name":       remoteName,
		"type":       "local",
		"parameters": map[string]string{},
	}))
	if status != http.StatusOK {
		h.t.Fatalf("config/create %s: status=%d out=%s", remoteName, status, out)
	}
	h.remotes = append(h.remotes, remoteName)

	fsPath := remoteName + ":" + filepath.ToSlash(h.backingDir)
	id, addr, err := ServeHTTPWithVFS(fsPath, "127.0.0.1:0", VFSOptions{
		CacheMode:         "full",
		CacheMaxSize:      "16Mi",
		CacheMaxAge:       "1h",
		CachePollInterval: "1h",
		DirCacheTime:      dirCacheTime,
		ReadOnly:          true,
	})
	if err != nil {
		h.t.Fatalf("serve/start %s: %v", remoteName, err)
	}
	h.serveIDs = append(h.serveIDs, id)
	return directoryCacheSpikePlane{
		remoteName: remoteName,
		fs:         fsPath,
		baseURL:    "http://" + addr,
	}
}

func directoryCacheSpikeGET(t *testing.T, plane directoryCacheSpikePlane, relativePath string) (int, string) {
	t.Helper()
	client := &http.Client{Timeout: 10 * time.Second}
	response, err := client.Get(plane.baseURL + "/" + relativePath)
	if err != nil {
		t.Fatalf("GET %s from %s: %v", relativePath, plane.remoteName, err)
	}
	body, readErr := io.ReadAll(response.Body)
	closeErr := response.Body.Close()
	if readErr != nil || closeErr != nil {
		t.Fatalf("read GET %s from %s: read=%v close=%v", relativePath, plane.remoteName, readErr, closeErr)
	}
	return response.StatusCode, string(body)
}

func requireDirectoryCacheSpikeGET(t *testing.T, plane directoryCacheSpikePlane, relativePath string, wantStatus int, wantBody string) {
	t.Helper()
	status, body := directoryCacheSpikeGET(t, plane, relativePath)
	if status != wantStatus {
		t.Fatalf("GET %s from %s: status=%d body=%q, want status=%d", relativePath, plane.remoteName, status, body, wantStatus)
	}
	if wantBody != "" && body != wantBody {
		t.Fatalf("GET %s from %s: body=%q, want %q", relativePath, plane.remoteName, body, wantBody)
	}
}

func directoryCacheSpikeForget(t *testing.T, fsPath string, dirs ...string) {
	t.Helper()
	if err := ForgetVFSDirectories(fsPath, dirs...); err != nil {
		t.Fatalf("vfs/forget fs=%s dirs=%v: %v", fsPath, dirs, err)
	}
}

func waitForDirectoryCacheSpikeFile(t *testing.T, root, base string) string {
	t.Helper()
	deadline := time.Now().Add(5 * time.Second)
	for {
		var found string
		err := filepath.WalkDir(root, func(path string, entry os.DirEntry, err error) error {
			if err != nil {
				if os.IsNotExist(err) {
					return filepath.SkipAll
				}
				return err
			}
			if entry.Type().IsRegular() && entry.Name() == base {
				found = path
				return filepath.SkipAll
			}
			return nil
		})
		if err != nil && !os.IsNotExist(err) {
			t.Fatalf("walk VFS cache %s: %v", root, err)
		}
		if found != "" {
			return found
		}
		if time.Now().After(deadline) {
			t.Fatalf("cached file %q did not appear under %s", base, root)
		}
		time.Sleep(25 * time.Millisecond)
	}
}

func TestVFSDirectoryCacheInvalidation_RequiresExplicitFS(t *testing.T) {
	if err := ForgetVFSDirectories(""); err == nil || !strings.Contains(err.Error(), "fs is required") {
		t.Fatalf("empty fs error = %v", err)
	}
	if err := ForgetVFSDirectories("remote:bucket", "  /  "); err == nil || !strings.Contains(err.Error(), "directory 1 is empty") {
		t.Fatalf("empty directory error = %v", err)
	}
}

func TestVFSDirectoryCacheInvalidation_ErrorRedactsDirectories(t *testing.T) {
	const (
		fsPath     = "missing-remote:bucket"
		memberPath = "sensitive/member/path"
	)
	err := ForgetVFSDirectories(fsPath, memberPath)
	if err == nil {
		t.Fatal("forget against a missing VFS returned nil error")
	}
	if !strings.Contains(err.Error(), fsPath) || !strings.Contains(err.Error(), "status") {
		t.Fatalf("forget error lacks target identity or status: %v", err)
	}
	if strings.Contains(err.Error(), memberPath) {
		t.Fatalf("forget error exposed member path: %v", err)
	}
}

func TestVFSDirectoryCacheInvalidation_DirCacheTimeIsPerServe(t *testing.T) {
	h := newDirectoryCacheSpikeHarness(t)
	h.writeFile("member/seed.txt", "seed")
	shortTTL := h.startPlane("short-ttl", "150ms")
	longTTL := h.startPlane("long-ttl", "1h")

	requireDirectoryCacheSpikeGET(t, shortTTL, "member/seed.txt", http.StatusOK, "seed")
	requireDirectoryCacheSpikeGET(t, longTTL, "member/seed.txt", http.StatusOK, "seed")
	h.writeFile("member/after-warm.txt", "visible-after-short-ttl")
	time.Sleep(400 * time.Millisecond)

	requireDirectoryCacheSpikeGET(t, shortTTL, "member/after-warm.txt", http.StatusOK, "visible-after-short-ttl")
	requireDirectoryCacheSpikeGET(t, longTTL, "member/after-warm.txt", http.StatusNotFound, "")
	t.Log("dir_cache_time reached both serve/start instances independently: 150ms refreshed while 1h remained stale")
}

func TestVFSDirectoryCacheInvalidation_ScopedForgetSelectsOnePlane(t *testing.T) {
	h := newDirectoryCacheSpikeHarness(t)
	h.writeFile("member/seed.txt", "seed")
	books := h.startPlane("books", "1h")
	assets := h.startPlane("assets", "1h")

	requireDirectoryCacheSpikeGET(t, books, "member/seed.txt", http.StatusOK, "seed")
	requireDirectoryCacheSpikeGET(t, assets, "member/seed.txt", http.StatusOK, "seed")
	h.writeFile("member/committed.txt", "new-generation")

	out, status := librclone.RPC("vfs/forget", mustJSON(map[string]any{}))
	if status == http.StatusOK || !strings.Contains(out, "more than one VFS active") {
		t.Fatalf("unscoped vfs/forget: status=%d out=%s, want multi-VFS selection error", status, out)
	}
	requireDirectoryCacheSpikeGET(t, books, "member/committed.txt", http.StatusNotFound, "")
	requireDirectoryCacheSpikeGET(t, assets, "member/committed.txt", http.StatusNotFound, "")

	directoryCacheSpikeForget(t, books.fs, "member")
	requireDirectoryCacheSpikeGET(t, books, "member/committed.txt", http.StatusOK, "new-generation")
	requireDirectoryCacheSpikeGET(t, assets, "member/committed.txt", http.StatusNotFound, "")
	t.Log("explicit canonical fs selected only the books plane; assets retained its stale directory view")
}

func TestVFSDirectoryCacheInvalidation_ForgetKeepsFullModeBytes(t *testing.T) {
	h := newDirectoryCacheSpikeHarness(t)
	payload := strings.Repeat("cached-payload-", 1024)
	h.writeFile("member/retained.bin", payload)
	target := h.startPlane("data-target", "1h")
	_ = h.startPlane("selection-guard", "1h")

	requireDirectoryCacheSpikeGET(t, target, "member/retained.bin", http.StatusOK, payload)
	cacheRoot := filepath.Join(h.cacheDir, "vfs", target.remoteName)
	cacheFile := waitForDirectoryCacheSpikeFile(t, cacheRoot, "retained.bin")
	before, err := os.ReadFile(cacheFile)
	if err != nil {
		t.Fatalf("read cached data before forget: %v", err)
	}
	if !bytes.Equal(before, []byte(payload)) {
		t.Fatalf("cached data before forget has %d bytes, want exact %d-byte payload", len(before), len(payload))
	}

	directoryCacheSpikeForget(t, target.fs, "member")
	after, err := os.ReadFile(cacheFile)
	if err != nil {
		t.Fatalf("full-mode cache file disappeared through metadata forget: %v", err)
	}
	if !bytes.Equal(after, before) {
		t.Fatalf("full-mode cache bytes changed through metadata forget: before=%d after=%d", len(before), len(after))
	}
	t.Logf("metadata forget retained the exact %d-byte full-mode cache file %s", len(after), cacheFile)
}

func TestVFSDirectoryCacheInvalidation_ExistingMemberForgetRevealsChild(t *testing.T) {
	h := newDirectoryCacheSpikeHarness(t)
	h.writeFile("member/seed.txt", "seed")
	target := h.startPlane("existing-member", "1h")
	_ = h.startPlane("selection-guard", "1h")

	requireDirectoryCacheSpikeGET(t, target, "member/seed.txt", http.StatusOK, "seed")
	h.writeFile("member/new-book.epub", "committed-book")
	requireDirectoryCacheSpikeGET(t, target, "member/new-book.epub", http.StatusNotFound, "")

	directoryCacheSpikeForget(t, target.fs, "member")
	requireDirectoryCacheSpikeGET(t, target, "member/new-book.epub", http.StatusOK, "committed-book")
	t.Log("forgetting an already cached member made its newly committed child visible on the next request")
}

func TestVFSDirectoryCacheInvalidation_NewTopologyNeedsFullForget(t *testing.T) {
	h := newDirectoryCacheSpikeHarness(t)
	h.writeFile("existing/seed.txt", "seed")
	target := h.startPlane("new-topology", "1h")
	_ = h.startPlane("selection-guard", "1h")

	// Reading an existing top-level path warms the root without creating any
	// cached node for the new multi-segment topology introduced below.
	requireDirectoryCacheSpikeGET(t, target, "existing/seed.txt", http.StatusOK, "seed")
	h.writeFile("added/member/new-book.epub", "new-member-book")

	directoryCacheSpikeForget(t, target.fs, "added/member")
	requireDirectoryCacheSpikeGET(t, target, "added/member/new-book.epub", http.StatusNotFound, "")

	directoryCacheSpikeForget(t, target.fs)
	requireDirectoryCacheSpikeGET(t, target, "added/member/new-book.epub", http.StatusOK, "new-member-book")
	t.Log("selective forget returned success but could not reach an uncached ancestor; full targeted forget exposed the new topology")
}
