//go:build integration

// Discovery test (Phase 0 spike for aggregator-browse-pipeline workflow):
// validates whether rclone's `http` backend can list a remote HTTP directory
// AND copy its tree to a local destination via SyncCopy. If yes, the
// aggregator-mode download worker in pkg/browselocal can reuse the existing
// SyncCopy("librarian:" + DirPath, dst, nil) call unchanged. If no, the
// worker must switch to per-file CopyFile calls.

package rclonexfer

import (
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestHTTPRemoteSyncCopy(t *testing.T) {
	src := t.TempDir()
	bookDir := filepath.Join(src, "Alice", "Book")
	if err := os.MkdirAll(bookDir, 0o755); err != nil {
		t.Fatalf("mkdir src: %v", err)
	}
	wantEpub := []byte("EPUB-PAYLOAD-16B")
	wantCover := []byte("JPG-PAYLOAD-15B")
	if err := os.WriteFile(filepath.Join(bookDir, "Book.epub"), wantEpub, 0o644); err != nil {
		t.Fatalf("write epub: %v", err)
	}
	if err := os.WriteFile(filepath.Join(bookDir, "cover.jpg"), wantCover, 0o644); err != nil {
		t.Fatalf("write cover: %v", err)
	}

	srv := httptest.NewServer(http.FileServer(http.Dir(src)))
	defer srv.Close()

	Initialize()
	defer Finalize()

	if err := ConfigHTTPRemote("spike", srv.URL+"/"); err != nil {
		t.Fatalf("ConfigHTTPRemote: %v", err)
	}
	defer func() { _ = DeleteRemote("spike") }()

	dst := t.TempDir()
	jobID, err := SyncCopy("spike:Alice/Book", dst, nil)
	if err != nil {
		t.Fatalf("SyncCopy: %v", err)
	}

	deadline := time.After(30 * time.Second)
	var final SyncStats
	for stats := range PollProgress(jobID) {
		final = stats
		if stats.Finished {
			break
		}
		select {
		case <-deadline:
			_ = StopJob(jobID)
			t.Fatalf("SyncCopy job %d did not finish within 30s (stats: %+v)", jobID, stats)
		default:
		}
	}
	if !final.Success {
		t.Fatalf("SyncCopy job finished but Success=false (stats: %+v)", final)
	}

	for name, want := range map[string][]byte{"Book.epub": wantEpub, "cover.jpg": wantCover} {
		got, err := os.ReadFile(filepath.Join(dst, name))
		if err != nil {
			t.Fatalf("read %s from dst: %v", name, err)
		}
		if string(got) != string(want) {
			t.Fatalf("%s: got %q want %q", name, got, want)
		}
	}
	t.Logf("PASS: rclone http backend SyncCopy'd %d bytes across 2 files; transfers=%d", final.Bytes, final.Transfers)
}
