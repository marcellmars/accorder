//go:build integration

package rclonexfer

import (
	"encoding/json"
	"net"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/rclone/rclone/librclone/librclone"
)

// TestServeWebDAVHelper validates the rclonexfer.ServeWebDAV/StopServe pair —
// the helpers torshare uses to wrap librclone.RPC("serve/start", ...) without
// touching the raw RPC surface. Equivalent to R8a but via the public helper.
func TestServeWebDAVHelper(t *testing.T) {
	tmp := t.TempDir()
	if err := os.WriteFile(filepath.Join(tmp, "marker.txt"), []byte("hello"), 0644); err != nil {
		t.Fatal(err)
	}

	Initialize()
	defer Finalize()

	id, addr, err := ServeWebDAV(tmp, "127.0.0.1:0")
	if err != nil {
		t.Fatalf("ServeWebDAV: %v", err)
	}
	defer func() {
		if err := StopServe(id); err != nil {
			t.Logf("StopServe: %v", err)
		}
	}()
	if _, port, err := net.SplitHostPort(addr); err != nil || port == "" || port == "0" {
		t.Fatalf("ServeWebDAV did not assign a real port: addr=%q err=%v", addr, err)
	}
	t.Logf("ServeWebDAV: id=%s addr=%s", id, addr)

	if err := ConfigWebDAVRemote("librarian", "http://"+addr+"/"); err != nil {
		t.Fatalf("ConfigWebDAVRemote: %v", err)
	}

	lsIn, _ := json.Marshal(map[string]any{"fs": "librarian:", "remote": ""})
	lsOut, lsStatus := librclone.RPC("operations/list", string(lsIn))
	if lsStatus != 200 {
		t.Fatalf("operations/list status=%d out=%s", lsStatus, lsOut)
	}
	if !strings.Contains(lsOut, "marker.txt") {
		t.Fatalf("operations/list missing marker.txt: %s", lsOut)
	}
}

// TestR8a_ServeStartWebDAV validates the study's R8 assumption:
// librclone.RPC("serve/start", {"type":"webdav","fs":"libroot:","addr":"127.0.0.1:0"})
// returns an assigned port, and the resulting WebDAV server can be reached
// via the webdav backend within the same process.
func TestR8a_ServeStartWebDAV(t *testing.T) {
	tmp := t.TempDir()
	if err := os.WriteFile(filepath.Join(tmp, "marker.txt"), []byte("hello"), 0644); err != nil {
		t.Fatal(err)
	}

	librclone.Initialize()
	defer librclone.Finalize()

	in, _ := json.Marshal(map[string]any{
		"type": "webdav",
		"fs":   tmp,
		"addr": "127.0.0.1:0",
	})
	out, status := librclone.RPC("serve/start", string(in))
	if status != 200 {
		t.Fatalf("serve/start status=%d out=%s", status, out)
	}

	var resp struct {
		ID   string `json:"id"`
		Addr string `json:"addr"`
	}
	if err := json.Unmarshal([]byte(out), &resp); err != nil {
		t.Fatalf("parse serve/start response: %v (raw: %s)", err, out)
	}
	if resp.Addr == "" {
		t.Fatalf("serve/start returned empty addr: %s", out)
	}
	if _, port, err := net.SplitHostPort(resp.Addr); err != nil || port == "" || port == "0" {
		t.Fatalf("serve/start did not assign a real port: addr=%q err=%v", resp.Addr, err)
	}
	t.Logf("serve/start succeeded: id=%s addr=%s", resp.ID, resp.Addr)

	defer func() {
		stopIn, _ := json.Marshal(map[string]any{"id": resp.ID})
		stopOut, stopStatus := librclone.RPC("serve/stop", string(stopIn))
		if stopStatus != 200 {
			t.Logf("serve/stop status=%d out=%s", stopStatus, stopOut)
		}
	}()

	url := "http://" + resp.Addr + "/"
	if err := ConfigWebDAVRemote("librarian", url); err != nil {
		t.Fatalf("ConfigWebDAVRemote: %v", err)
	}

	lsIn, _ := json.Marshal(map[string]any{"fs": "librarian:", "remote": ""})
	lsOut, lsStatus := librclone.RPC("operations/list", string(lsIn))
	if lsStatus != 200 {
		t.Fatalf("operations/list status=%d out=%s", lsStatus, lsOut)
	}
	if !strings.Contains(lsOut, "marker.txt") {
		t.Fatalf("operations/list did not return marker.txt — webdav round-trip failed: %s", lsOut)
	}
	t.Logf("webdav round-trip succeeded: %s", lsOut)
}

// TestR8b_ALLPROXYHonored validates that HTTP_PROXY/HTTPS_PROXY (with
// socks5h:// scheme) is honored by rclone's HTTP client for non-loopback
// targets. Points the webdav remote at a fake .onion hostname; a
// proxyconnect error proves SOCKS5 was attempted, a no-such-host error
// would prove the proxy env was ignored.
//

// GOTCHA: Go's httpproxy.envOnce uses sync.Once to cache HTTP_PROXY at
// first read. Production code MUST set HTTP_PROXY before the first
// librclone.Initialize() (cmd/calibreBrowseCmd.go does this). Run this
// test individually (-run=TestR8b) — running after TestR8a fails because
// R8a's Initialize() locked the cached config to "no proxy".
func TestR8b_ALLPROXYHonored(t *testing.T) {

	// rclone calls http.ProxyFromEnvironment which only honors HTTP_PROXY/HTTPS_PROXY/NO_PROXY.
	// ALL_PROXY (curl convention) is NOT honored — the propose's design got this wrong.
	t.Setenv("ALL_PROXY", "socks5h://127.0.0.1:1")
	t.Setenv("HTTP_PROXY", "socks5h://127.0.0.1:1")
	t.Setenv("HTTPS_PROXY", "socks5h://127.0.0.1:1")
	t.Setenv("NO_PROXY", "")

	librclone.Initialize()
	defer librclone.Finalize()

	// fake .onion-shaped hostname — non-loopback, only resolvable via SOCKS proxy.
	// If ALL_PROXY is honored we see a SOCKS-dial error (port 1 closed).
	// If ALL_PROXY is ignored we see a DNS-lookup error.
	url := "http://fakefakefakefakefakefakefakefakefakefakefakefakefakeqxd.onion/"
	if err := ConfigWebDAVRemote("librarian", url); err != nil {
		t.Fatalf("ConfigWebDAVRemote: %v", err)
	}

	lsIn, _ := json.Marshal(map[string]any{"fs": "librarian:", "remote": ""})
	lsOut, lsStatus := librclone.RPC("operations/list", string(lsIn))
	if lsStatus == 200 {
		t.Fatalf("operations/list unexpectedly succeeded — impossible without a working proxy. out=%s", lsOut)
	}
	low := strings.ToLower(lsOut)
	socksAttempted := strings.Contains(low, "socks") ||
		strings.Contains(low, "dial tcp 127.0.0.1:1") ||
		strings.Contains(low, "127.0.0.1:1: connect")
	dnsAttempted := (strings.Contains(low, "no such host") ||
		strings.Contains(low, "lookup ") ||
		strings.Contains(low, "name resolution")) && !socksAttempted
	if dnsAttempted {
		t.Fatalf("operations/list failed with DNS error — ALL_PROXY NOT honored; .onion was resolved locally. status=%d out=%s", lsStatus, lsOut)
	}
	if !socksAttempted {
		t.Fatalf("operations/list failed but error doesn't look SOCKS-related. status=%d out=%s", lsStatus, lsOut)
	}
	t.Logf("ALL_PROXY honored — request routed via SOCKS5. status=%d out=%s", lsStatus, lsOut)
}
