package rclonexfer

import (
	"bytes"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestSpikeGenerationChangeSameSizeOverwrite(t *testing.T) {
	src := t.TempDir()
	dst := t.TempDir()
	path := filepath.Join("Author", "Book (1)", "book.epub")
	if err := os.MkdirAll(filepath.Join(src, filepath.Dir(path)), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.MkdirAll(filepath.Join(dst, filepath.Dir(path)), 0o755); err != nil {
		t.Fatal(err)
	}
	oldBytes := bytes.Repeat([]byte("A"), 4096)
	newBytes := bytes.Repeat([]byte("B"), len(oldBytes))
	oldTime := time.Date(2026, 9, 1, 12, 0, 0, 0, time.UTC)
	for root, data := range map[string][]byte{src: newBytes, dst: oldBytes} {
		full := filepath.Join(root, path)
		if err := os.WriteFile(full, data, 0o644); err != nil {
			t.Fatal(err)
		}
		if err := os.Chtimes(full, oldTime, oldTime); err != nil {
			t.Fatal(err)
		}
	}

	Initialize()
	defer Finalize()

	jobID, err := SyncSync(src, dst, nil, nil, SyncOptions{MaxDelete: -1})
	if err != nil {
		t.Fatal(err)
	}
	if _, err := WaitJob(jobID); err != nil {
		t.Fatal(err)
	}
	got, err := os.ReadFile(filepath.Join(dst, path))
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(got, oldBytes) {
		t.Fatal("size-only mirror unexpectedly replaced equal-size payload; spike no longer exercises the production gap")
	}

	if err := CopyFileOverwrite(src, filepath.ToSlash(path), dst, filepath.ToSlash(path)); err != nil {
		t.Fatal(err)
	}
	got, err = os.ReadFile(filepath.Join(dst, path))
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(got, newBytes) {
		t.Fatal("explicit CopyFile did not overwrite equal-size payload")
	}

	if err := os.WriteFile(filepath.Join(dst, path), oldBytes, 0o644); err != nil {
		t.Fatal(err)
	}
	if err := os.Chtimes(filepath.Join(dst, path), oldTime, oldTime); err != nil {
		t.Fatal(err)
	}
	jobID, err = CopyAllOverwrite(src, dst, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := WaitJob(jobID); err != nil {
		t.Fatal(err)
	}
	got, err = os.ReadFile(filepath.Join(dst, path))
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(got, newBytes) {
		t.Fatal("rclone-owned complete overwrite did not replace equal-size payload")
	}
}
