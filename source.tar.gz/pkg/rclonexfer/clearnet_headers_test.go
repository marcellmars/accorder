//go:build integration

// Verifies the rclone `headers` config-parameter format used by the clearnet
// invite credential path (ca-63). lib browse --http-endpoint --invite injects the
// bearer token via ConfigHTTPRemoteWithHeaders / ConfigWebDAVRemoteWithHeaders;
// if rclone's `headers` format were wrong the token would never reach the server
// and authenticated sync would silently 401. The clearnet e2e injects the header
// directly server-side and does NOT exercise the rclone client path — these tests
// close that gap (the proposal's highest-flagged implementation risk).

package rclonexfer

import (
	"bytes"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"sync"
	"testing"

	"github.com/rclone/rclone/librclone/librclone"
)

// TestServeHTTPWithVFS_FetchByPath proves the per-library-S3 / aggregator file
// plane works over HTTP with the VFS cache: serve a dir via ServeHTTPWithVFS, then
// fetch a book file by EXACT PATH through an HTTP remote — no WebDAV PROPFIND (the
// dominant cost over Tor). This is the non-Tor regression guard for the WebDAV→HTTP
// file-plane unification.
func TestServeHTTPWithVFS_FetchByPath(t *testing.T) {
	src := t.TempDir()
	bookDir := filepath.Join(src, "Author", "Book (1)")
	if err := os.MkdirAll(bookDir, 0o755); err != nil {
		t.Fatal(err)
	}
	want := []byte("EPUB-PAYLOAD-FROM-VFS")
	if err := os.WriteFile(filepath.Join(bookDir, "book.epub"), want, 0o644); err != nil {
		t.Fatal(err)
	}

	Initialize()
	defer Finalize()

	id, addr, err := ServeHTTPWithVFS(src, "127.0.0.1:0", VFSOptions{CacheMode: "full", ReadOnly: true})
	if err != nil {
		t.Fatalf("ServeHTTPWithVFS: %v", err)
	}
	defer func() { _ = StopServe(id) }()

	if err := ConfigHTTPRemote("vfs", "http://"+addr+"/"); err != nil {
		t.Fatalf("config http remote: %v", err)
	}
	dst := t.TempDir()
	if err := CopyFile("vfs:", "Author/Book (1)/book.epub", dst, "book.epub"); err != nil {
		t.Fatalf("CopyFile by exact path (no listing): %v", err)
	}
	got, err := os.ReadFile(filepath.Join(dst, "book.epub"))
	if err != nil {
		t.Fatalf("read fetched file: %v", err)
	}
	if !bytes.Equal(got, want) {
		t.Fatalf("fetched %q, want %q", got, want)
	}
}

// captureAuthServer serves an (empty) HTML directory listing while recording the
// Authorization header of the first request that carries one.
func captureAuthServer(got *string, mu *sync.Mutex) *httptest.Server {
	return httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if a := r.Header.Get("Authorization"); a != "" {
			mu.Lock()
			if *got == "" {
				*got = a
			}
			mu.Unlock()
		}
		w.Header().Set("Content-Type", "text/html")
		_, _ = w.Write([]byte("<html><body></body></html>"))
	}))
}

func TestConfigHTTPRemoteWithHeaders(t *testing.T) {
	var got string
	var mu sync.Mutex
	srv := captureAuthServer(&got, &mu)
	defer srv.Close()

	Initialize()
	defer Finalize()

	const want = "Bearer tok-http-123"
	if err := ConfigHTTPRemoteWithHeaders("hdrhttp", srv.URL, "Authorization,"+want); err != nil {
		t.Fatalf("config http remote: %v", err)
	}
	// Any op that reaches the remote root carries the header; a list suffices.
	out, status := librclone.RPC("operations/list", mustJSON(map[string]any{
		"fs":     "hdrhttp:",
		"remote": "",
	}))
	if status != 200 {
		t.Fatalf("operations/list status %d: %s", status, out)
	}
	mu.Lock()
	defer mu.Unlock()
	if got != want {
		t.Fatalf("rclone http backend sent Authorization=%q, want %q — the `headers` config format is wrong", got, want)
	}
}

func TestConfigWebDAVRemoteWithHeaders(t *testing.T) {
	var got string
	var mu sync.Mutex
	srv := captureAuthServer(&got, &mu)
	defer srv.Close()

	Initialize()
	defer Finalize()

	const want = "Bearer tok-dav-456"
	if err := ConfigWebDAVRemoteWithHeaders("hdrdav", srv.URL, "Authorization,"+want); err != nil {
		t.Fatalf("config webdav remote: %v", err)
	}
	// The webdav PROPFIND won't parse against a plain server, but the request still
	// reaches it carrying the Authorization header — which is what we verify. The op
	// error is expected and ignored.
	_, _ = librclone.RPC("operations/list", mustJSON(map[string]any{
		"fs":     "hdrdav:",
		"remote": "",
	}))
	mu.Lock()
	defer mu.Unlock()
	if got != want {
		t.Fatalf("rclone webdav backend sent Authorization=%q, want %q — the `headers` config format is wrong", got, want)
	}
}
