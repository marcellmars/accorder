package bubble

import "github.com/charmbracelet/bubbles/key"

type keymap struct {
	toggleBookCard key.Binding
	goHome         key.Binding
}

var Keymap = keymap{
	toggleBookCard: key.NewBinding(
		key.WithKeys(" "),
		key.WithHelp(" ", "toggle detailed book view"),
	),
	goHome: key.NewBinding(
		key.WithKeys("home"),
		key.WithHelp(" ", "go home"),
	),
}
