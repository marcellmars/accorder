package bubble

import (
	"strings"
	"testing"
)

func TestRenderCalibreOutputPreservesCompletedResult(t *testing.T) {
	for _, header := range []string{"", "lib build"} {
		got := RenderCalibreOutput(header, "Website: /scratch/BROWSE_LIBRARY.html (2 books)")
		if !strings.Contains(got, "Website: /scratch/BROWSE_LIBRARY.html (2 books)") || (header != "" && !strings.Contains(got, header)) {
			t.Fatalf("missing result/header: %q", got)
		}
	}
}
