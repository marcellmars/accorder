package bubble

import (
	"fmt"
	"strings"

	"github.com/charmbracelet/bubbles/progress"
	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
	"github.com/dustin/go-humanize"
)

var LastOutput strings.Builder
var (
	Finished           = false
	style              = lipgloss.NewStyle().Foreground(lipgloss.AdaptiveColor{Light: "236", Dark: "248"})
	fgColor            = lipgloss.NewStyle().Inherit(style).Render
	progressBarFgColor = lipgloss.NewStyle().Inherit(style).String()
	sectionColor       = lipgloss.NewStyle().Foreground(lipgloss.AdaptiveColor{Light: "202", Dark: "214"}).Padding(0, 0).Render
	helpStyle          = lipgloss.NewStyle().Foreground(lipgloss.AdaptiveColor{Light: "233", Dark: "245"})
	help               = lipgloss.NewStyle().Italic(true).Inherit(helpStyle).Padding(0, 1).Render
)

type RcloneStatsInfo struct {
	Bytes          int64   `json:"bytes"`
	Transfers      int64   `json:"transfers"`
	Speed          float64 `json:"speed"`
	TotalBytes     int64   `json:"totalBytes"`
	TotalTransfers int64   `json:"totalTransfers"`
	TotalChecks    int64   `json:"totalChecks"`
	Checks         int64   `json:"checks"`
}

type RcloneProgressMsg struct {
	RcloneCheckPercent    float64
	RcloneTransferPercent float64
	Quitable              bool
	RcloneHeader          string
	RcloneStatsInfo
}

type CalibreProgressMsg struct {
	CalibreHeader string
	CalibreOutput string
}

type Model struct {
	RcloneCheckProgress    progress.Model
	RcloneTransferProgress progress.Model
	Output                 string
	RcloneProgressMsg
	CalibreProgressMsg
}

func renderCalibreOutput(m Model) string {
	var output string
	if len(m.CalibreHeader) > 0 {
		output = sectionColor(m.CalibreHeader)
	}
	output = lipgloss.JoinVertical(lipgloss.Left, output, fgColor(m.CalibreOutput))
	return output
}

func renderRcloneOutput(m Model) string {
	checks := ""
	transfers := ""

	if m.RcloneProgressMsg.TotalChecks > 0 {
		if m.RcloneProgressMsg.TotalChecks == m.RcloneProgressMsg.Checks {
			checks = fmt.Sprintf("Checked %d files.\n",
				m.RcloneProgressMsg.TotalChecks,
			)
		} else {
			checks = fmt.Sprintf("Checking %d out of %d files:\n%s\n",
				m.RcloneProgressMsg.Checks,
				m.RcloneProgressMsg.TotalChecks,
				m.RcloneCheckProgress.ViewAs(m.RcloneCheckProgress.Percent()),
			)
		}
	}

	if m.RcloneProgressMsg.TotalBytes > 0 {
		if m.RcloneProgressMsg.TotalBytes == m.RcloneProgressMsg.Bytes {
			transfers = fmt.Sprintf("Transferred %s.\n",
				humanize.Bytes(uint64(m.RcloneProgressMsg.TotalBytes)),
			)
		} else {
			transfers = fmt.Sprintf("Transferring %s out of %s (%s/s):\n%s\n",
				humanize.Bytes(uint64(m.RcloneProgressMsg.Bytes)),
				humanize.Bytes(uint64(m.RcloneProgressMsg.TotalBytes)),
				humanize.Bytes(uint64(m.Speed)),
				m.RcloneTransferProgress.ViewAs(m.RcloneTransferProgress.Percent()),
			)
		}
	}
	var output string

	if len(m.RcloneHeader) > 0 {
		output = sectionColor(m.RcloneHeader)
	}
	output = lipgloss.JoinVertical(lipgloss.Left, output, fgColor(checks+transfers))

	if m.Quitable {
		output = lipgloss.JoinVertical(lipgloss.Left, output, help("Press 'q' to quit."))
	}
	return output
}

func RcloneProgressBarModel() Model {
	return Model{
		RcloneCheckProgress:    progress.New(progress.WithSolidFill(progressBarFgColor)),
		RcloneTransferProgress: progress.New(progress.WithSolidFill(progressBarFgColor)),
	}
}

func (m Model) Init() tea.Cmd {
	return nil
}

func (m Model) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.KeyMsg:
		if msg.String() == "q" && m.Quitable {
			Finished = true
			LastOutput.WriteString(m.Output)
			return m, tea.Quit
		}
	case RcloneProgressMsg:
		m.RcloneProgressMsg = msg
		m.RcloneCheckProgress.SetPercent(msg.RcloneCheckPercent)
		m.RcloneTransferProgress.SetPercent(msg.RcloneTransferPercent)
		m.Output = renderRcloneOutput(m)
		if msg.RcloneCheckPercent == 1.0 && msg.RcloneTransferPercent == 1.0 {
			Finished = true
			LastOutput.WriteString(m.Output)
			return m, tea.Quit
		}
	case CalibreProgressMsg:
		m.CalibreHeader = msg.CalibreHeader
		m.CalibreOutput = msg.CalibreOutput
		m.Output = renderCalibreOutput(m)
		return m, tea.Quit
	}
	return m, nil
}

func (m Model) View() string {
	return strings.TrimSpace(m.Output)
}
