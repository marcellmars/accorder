package librarianname

import (
	"fmt"
	"strings"
	"testing"
)

const testID = "550e8400-e29b-41d4-a716-446655440000"

func TestGenerate_Deterministic(t *testing.T) {
	a := Generate(testID, 0)
	b := Generate(testID, 0)
	if a != b {
		t.Errorf("Generate not deterministic: %q vs %q", a, b)
	}
	if parts := strings.Split(a, " "); len(parts) < 3 {
		t.Errorf("expected at least First Middle Last, got %q", a)
	}
}

func TestGenerate_DistinctIDsMostlyDistinctNames(t *testing.T) {
	seen := make(map[string]int)
	const n = 500
	for i := 0; i < n; i++ {
		id := fmt.Sprintf("00000000-0000-4000-8000-%012d", i)
		seen[Generate(id, 0)]++
	}

	// 66*130*57 ≈ 489k combinations; 500 samples should be nearly all
	// distinct (birthday bound ~ 500²/2/489k ≈ 0.26 expected collisions).
	if len(seen) < n-5 {
		t.Errorf("too many collisions: %d distinct names from %d ids", len(seen), n)
	}
}

func TestGenerate_BumpChangesOnlyMiddle(t *testing.T) {
	base := strings.Split(Generate(testID, 0), " ")
	bumped := strings.Split(Generate(testID, 1), " ")
	if len(base) < 3 || len(bumped) < 3 {
		t.Fatalf("unexpected shapes: %v vs %v", base, bumped)
	}
	if base[0] != bumped[0] {
		t.Errorf("bump changed first name: %q vs %q", base[0], bumped[0])
	}

	// Last name may contain spaces ("of Byzantium", "Van Swieten",
	// "La Fontaine") — compare the tail after first+middle.
	baseTail := strings.Join(base[2:], " ")
	bumpedTail := strings.Join(bumped[2:], " ")
	if baseTail != bumpedTail {
		t.Errorf("bump changed last name: %q vs %q", baseTail, bumpedTail)
	}
	if base[1] == bumped[1] {
		t.Errorf("bump did not change middle name: %q", base[1])
	}
}

func TestGenerate_BumpWrapsAndNegativeSafe(t *testing.T) {
	if got, want := Generate(testID, MiddlePoolSize()), Generate(testID, 0); got != want {
		t.Errorf("bump wrap: Generate(id, poolSize) = %q, want %q", got, want)
	}

	// Negative bump must not panic and must stay in pool.
	_ = Generate(testID, -1)
}

func TestIsGenerated(t *testing.T) {
	name := Generate(testID, 3)
	bump, ok := IsGenerated(name, testID)
	if !ok {
		t.Fatalf("IsGenerated(%q) = false, want true", name)
	}
	if bump != 3 {
		t.Errorf("IsGenerated bump = %d, want 3", bump)
	}
	if _, ok := IsGenerated("Hand Picked Name", testID); ok {
		t.Error("IsGenerated matched a non-generated name")
	}

	// A generated name for a DIFFERENT id should not match this id.
	other := Generate("660e8400-e29b-41d4-a716-446655440000", 0)
	if _, ok := IsGenerated(other, testID); ok && other != Generate(testID, 0) {
		t.Errorf("IsGenerated(%q) matched the wrong id", other)
	}
}

// personname validator shape (cmd/configuration.go): non-blank, no '/',
// '\\', control chars. Validate every pool entry once.
func TestPools_SatisfyPersonnameValidator(t *testing.T) {
	checkRune := func(t *testing.T, kind, s string) {
		t.Helper()
		if strings.TrimSpace(s) == "" {
			t.Errorf("%s pool has blank entry", kind)
		}
		for _, r := range s {
			if r == '/' || r == '\\' || r < 0x20 || r == 0x7f {
				t.Errorf("%s pool entry %q contains invalid rune %q", kind, s, r)
			}
		}
	}
	for _, s := range firstNames {
		checkRune(t, "first", s)
	}
	for _, s := range middleNames {
		checkRune(t, "middle", s)
	}
	for _, s := range lastNames {
		checkRune(t, "last", s)
	}
}

func TestPools_NoDuplicates(t *testing.T) {
	for kind, pool := range map[string][]string{
		"first": firstNames, "middle": middleNames, "last": lastNames,
	} {
		seen := make(map[string]struct{}, len(pool))
		for _, s := range pool {
			if _, dup := seen[s]; dup {
				t.Errorf("%s pool has duplicate %q", kind, s)
			}
			seen[s] = struct{}{}
		}
	}
}
