package librarianname

import (
	"crypto/sha256"
	"encoding/binary"
	"math/rand/v2"
)

func Generate(libraryID string, middleBump int) string {
	h := sha256.Sum256([]byte(libraryID))
	rng := rand.New(rand.NewPCG(
		binary.LittleEndian.Uint64(h[0:8]), binary.LittleEndian.Uint64(h[8:16])))
	first := firstNames[rng.IntN(len(firstNames))]
	last := lastNames[rng.IntN(len(lastNames))]
	middleBump %= len(middleNames)
	if middleBump < 0 {
		middleBump += len(middleNames)
	}
	middle := middleNames[(rng.IntN(len(middleNames))+middleBump)%len(middleNames)]
	return first + " " + middle + " " + last
}

func IsGenerated(name, libraryID string) (bump int, ok bool) {
	for b := 0; b < len(middleNames); b++ {
		if Generate(libraryID, b) == name {
			return b, true
		}
	}
	return 0, false
}

func MiddlePoolSize() int {
	return len(middleNames)
}
