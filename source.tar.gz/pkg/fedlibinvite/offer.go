package fedlibinvite

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/hkdf"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base32"
	"encoding/hex"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"github.com/goccy/go-json"
)

const (
	OfferVersion    = 1
	offerHKDFInfo   = "accorder-fedlib-offer-v1"
	DefaultOfferTTL = 168 * time.Hour
	offerTokenLen   = 26
)

type Offer struct {
	Version     int       `json:"version"`
	Prefix      string    `json:"prefix"`
	DisplayName string    `json:"display_name"`
	OfferKind   string    `json:"offer_kind,omitempty"`
	Created     time.Time `json:"created"`
	Expires     time.Time `json:"expires"`
	Nonce       []byte    `json:"nonce"`
	Ciphertext  []byte    `json:"ciphertext"`
}

func (o *Offer) IsPeerOffer() bool {
	return o.OfferKind == "peer"
}

func (o *Offer) Expired(now time.Time) bool {
	return now.After(o.Expires)
}

func NewOfferToken() (string, error) {
	b := make([]byte, 16)
	if _, err := rand.Read(b); err != nil {
		return "", fmt.Errorf("offer: generate token: %w", err)
	}
	return strings.ToLower(base32.StdEncoding.WithPadding(base32.NoPadding).EncodeToString(b)), nil
}

func ValidOfferToken(s string) bool {
	if len(s) != offerTokenLen {
		return false
	}
	for _, r := range s {
		isLower := r >= 'a' && r <= 'z'
		isDigit := r >= '2' && r <= '7'
		if !isLower && !isDigit {
			return false
		}
	}
	return true
}

func OfferFileName(token string) string {
	sum := sha256.Sum256([]byte(token))
	return hex.EncodeToString(sum[:]) + ".json"
}

func offerKey(token string) ([]byte, error) {
	key, err := hkdf.Key(sha256.New, []byte(token), nil, offerHKDFInfo, 32)
	if err != nil {
		return nil, fmt.Errorf("offer: derive key: %w", err)
	}
	return key, nil
}

func offerGCM(token string) (cipher.AEAD, error) {
	key, err := offerKey(token)
	if err != nil {
		return nil, err
	}
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, fmt.Errorf("offer: cipher: %w", err)
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, fmt.Errorf("offer: gcm: %w", err)
	}
	return gcm, nil
}

func SealOffer(token, blob, prefix, displayName string, expires time.Time) (*Offer, error) {
	gcm, err := offerGCM(token)
	if err != nil {
		return nil, err
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err := rand.Read(nonce); err != nil {
		return nil, fmt.Errorf("offer: generate nonce: %w", err)
	}
	return &Offer{
		Version:     OfferVersion,
		Prefix:      prefix,
		DisplayName: displayName,
		Created:     time.Now().UTC(),
		Expires:     expires.UTC(),
		Nonce:       nonce,
		Ciphertext:  gcm.Seal(nil, nonce, []byte(blob), nil),
	}, nil
}

func SealPeerOffer(token, federationID, prefix, displayName string, expires time.Time) (*Offer, error) {
	return SealOffer(token, federationID, prefix, displayName, expires)
}

func OpenOffer(token string, o *Offer) (string, error) {
	gcm, err := offerGCM(token)
	if err != nil {
		return "", err
	}
	if len(o.Nonce) != gcm.NonceSize() {
		return "", fmt.Errorf("offer: bad nonce length %d", len(o.Nonce))
	}
	plaintext, err := gcm.Open(nil, o.Nonce, o.Ciphertext, nil)
	if err != nil {
		return "", fmt.Errorf("offer: decrypt: %w", err)
	}
	return string(plaintext), nil
}

func WriteOffer(dir, token string, o *Offer) error {
	if err := os.MkdirAll(dir, 0o700); err != nil {
		return fmt.Errorf("offer: mkdir %s: %w", dir, err)
	}
	data, err := json.MarshalIndent(o, "", "  ")
	if err != nil {
		return fmt.Errorf("offer: marshal: %w", err)
	}
	tmp, err := os.CreateTemp(dir, ".offer-*")
	if err != nil {
		return fmt.Errorf("offer: temp file: %w", err)
	}
	tmpName := tmp.Name()
	cleanup := func() {
		_ = tmp.Close()
		_ = os.Remove(tmpName)
	}
	if _, err := tmp.Write(data); err != nil {
		cleanup()
		return fmt.Errorf("offer: write: %w", err)
	}
	if err := tmp.Chmod(0o600); err != nil {
		cleanup()
		return fmt.Errorf("offer: chmod: %w", err)
	}
	if err := tmp.Close(); err != nil {
		_ = os.Remove(tmpName)
		return fmt.Errorf("offer: close: %w", err)
	}
	if err := os.Rename(tmpName, filepath.Join(dir, OfferFileName(token))); err != nil {
		_ = os.Remove(tmpName)
		return fmt.Errorf("offer: rename: %w", err)
	}
	return nil
}

func ReadOffer(dir, token string) (*Offer, error) {
	data, err := os.ReadFile(filepath.Join(dir, OfferFileName(token)))
	if err != nil {
		return nil, err
	}
	var o Offer
	if err := json.Unmarshal(data, &o); err != nil {
		return nil, fmt.Errorf("offer: parse: %w", err)
	}
	return &o, nil
}

func ClaimOffer(dir, token string) (*Offer, error) {
	path := filepath.Join(dir, OfferFileName(token))
	burned := path + ".claimed-" + strconv.FormatInt(time.Now().UnixNano(), 36)
	if err := os.Rename(path, burned); err != nil {
		return nil, err
	}
	defer os.Remove(burned)
	data, err := os.ReadFile(burned)
	if err != nil {
		return nil, fmt.Errorf("offer: read claimed: %w", err)
	}
	var o Offer
	if err := json.Unmarshal(data, &o); err != nil {
		return nil, fmt.Errorf("offer: parse claimed: %w", err)
	}
	return &o, nil
}

func ListOffers(dir string) (map[string]*Offer, error) {
	entries, err := os.ReadDir(dir)
	if err != nil {
		if os.IsNotExist(err) {
			return map[string]*Offer{}, nil
		}
		return nil, fmt.Errorf("offer: read dir %s: %w", dir, err)
	}
	out := make(map[string]*Offer)
	for _, e := range entries {
		name := e.Name()
		if e.IsDir() || !strings.HasSuffix(name, ".json") || strings.HasPrefix(name, ".") {
			continue
		}
		data, err := os.ReadFile(filepath.Join(dir, name))
		if err != nil {
			continue
		}
		var o Offer
		if err := json.Unmarshal(data, &o); err != nil {
			continue
		}
		out[name] = &o
	}
	return out, nil
}

func SweepExpired(dir string) (int, error) {
	offers, err := ListOffers(dir)
	if err != nil {
		return 0, err
	}
	now := time.Now()
	removed := 0
	for name, o := range offers {
		if o.Expired(now) {
			if err := os.Remove(filepath.Join(dir, name)); err == nil {
				removed++
			}
		}
	}
	return removed, nil
}
