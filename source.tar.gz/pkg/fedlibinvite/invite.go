package fedlibinvite

import (
	"encoding/base64"
	"fmt"
	"strings"

	"github.com/goccy/go-json"
)

const WriteInvitePrefix = "accorder-fedlib-invite:"

type WriteInvite struct {
	FedlibID     string            `json:"fedlib_id"`
	Backend      string            `json:"backend"`
	RemoteConfig map[string]string `json:"remote_config"`
	Prefix       string            `json:"prefix"`
	AccessKey    string            `json:"access_key"`
	SecretKey    string            `json:"secret_key"`
	Label        string            `json:"label"`
	LibraryID    string            `json:"library_id,omitempty"` // existing member identity (re-invite); empty for new members
	DictID       uint32            `json:"dict_id,omitempty"`    // unique per-federation dictionary ID (v5 containers); 0 = legacy/unset
}

func EncodeWriteInvite(inv *WriteInvite) string {
	b, _ := json.Marshal(inv)
	return WriteInvitePrefix + base64.RawURLEncoding.EncodeToString(b)
}

func DecodeWriteInvite(blob string) (*WriteInvite, error) {
	if !strings.HasPrefix(blob, WriteInvitePrefix) {
		return nil, fmt.Errorf("fedlibinvite: invalid prefix (expected %q)", WriteInvitePrefix)
	}
	payload := strings.TrimPrefix(blob, WriteInvitePrefix)
	data, err := base64.RawURLEncoding.DecodeString(payload)
	if err != nil {
		return nil, fmt.Errorf("fedlibinvite: base64 decode: %w", err)
	}
	var inv WriteInvite
	if err := json.Unmarshal(data, &inv); err != nil {
		return nil, fmt.Errorf("fedlibinvite: json decode: %w", err)
	}
	for _, field := range []struct{ name, val string }{
		{"fedlib_id", inv.FedlibID},
		{"prefix", inv.Prefix},
		{"access_key", inv.AccessKey},
		{"secret_key", inv.SecretKey},
	} {
		if field.val == "" {
			return nil, fmt.Errorf("fedlibinvite: missing %s", field.name)
		}
	}
	return &inv, nil
}
