package fedlibinvite

import (
	"encoding/base64"
	"strings"
	"testing"
)

func TestEncodeDecodeRoundTrip(t *testing.T) {
	inv := &WriteInvite{
		FedlibID: "fed-123",
		Backend:  "s3",
		RemoteConfig: map[string]string{
			"provider": "Wasabi",
			"endpoint": "https://s3.wasabisys.com",
			"bucket":   "my-bucket",
		},
		Prefix:    "alice",
		AccessKey: "AKIA-test-key",
		SecretKey: "super-secret-key",
		Label:     "Alice's Library",
	}

	blob := EncodeWriteInvite(inv)

	if !strings.HasPrefix(blob, WriteInvitePrefix) {
		t.Errorf("blob missing prefix: got %q", blob[:30])
	}

	decoded, err := DecodeWriteInvite(blob)
	if err != nil {
		t.Fatalf("DecodeWriteInvite: %v", err)
	}

	if decoded.FedlibID != inv.FedlibID {
		t.Errorf("FedlibID = %q, want %q", decoded.FedlibID, inv.FedlibID)
	}
	if decoded.Backend != inv.Backend {
		t.Errorf("Backend = %q, want %q", decoded.Backend, inv.Backend)
	}
	if decoded.Prefix != inv.Prefix {
		t.Errorf("Prefix = %q, want %q", decoded.Prefix, inv.Prefix)
	}
	if decoded.AccessKey != inv.AccessKey {
		t.Errorf("AccessKey = %q, want %q", decoded.AccessKey, inv.AccessKey)
	}
	if decoded.SecretKey != inv.SecretKey {
		t.Errorf("SecretKey = %q, want %q", decoded.SecretKey, inv.SecretKey)
	}
	if decoded.Label != inv.Label {
		t.Errorf("Label = %q, want %q", decoded.Label, inv.Label)
	}
	if decoded.RemoteConfig["provider"] != "Wasabi" {
		t.Errorf("RemoteConfig[provider] = %q, want %q", decoded.RemoteConfig["provider"], "Wasabi")
	}
}

func TestDecodeInvalidPrefix(t *testing.T) {
	_, err := DecodeWriteInvite("invalid-prefix:abc123")
	if err == nil {
		t.Error("expected error for invalid prefix")
	}
}

func TestDecodeInvalidBase64(t *testing.T) {
	_, err := DecodeWriteInvite(WriteInvitePrefix + "!invalid!base64!")
	if err == nil {
		t.Error("expected error for invalid base64")
	}
}

func TestDecodeMissingPrefix(t *testing.T) {

	// Valid base64 JSON but missing the "prefix" field.
	inv := &WriteInvite{
		FedlibID:  "fed-123",
		Backend:   "s3",
		AccessKey: "ak",
		SecretKey: "sk",

		// Prefix is intentionally empty.
	}
	blob := EncodeWriteInvite(inv)
	_, err := DecodeWriteInvite(blob)
	if err == nil {
		t.Error("expected error for missing prefix")
	}
}

// ═══════════════════════════════════════════════════════════════════
// fedlib-reinvite-identity: optional library_id field tolerance.
// ═══════════════════════════════════════════════════════════════════

func TestEncodeDecodeRoundTripWithLibraryID(t *testing.T) {
	inv := &WriteInvite{
		FedlibID:  "fed-123",
		Backend:   "s3",
		Prefix:    "alice",
		AccessKey: "ak",
		SecretKey: "sk",
		Label:     "Alice's Library",
		LibraryID: "9f3b1c2e-4d5a-4b6c-8d7e-0f1a2b3c4d5e",
	}
	decoded, err := DecodeWriteInvite(EncodeWriteInvite(inv))
	if err != nil {
		t.Fatalf("DecodeWriteInvite: %v", err)
	}
	if decoded.LibraryID != inv.LibraryID {
		t.Errorf("LibraryID = %q, want %q", decoded.LibraryID, inv.LibraryID)
	}
}

func TestDecodeOldFormatBlobWithoutLibraryID(t *testing.T) {

	// Hand-encoded old-format JSON (no library_id key at all): a blob
	// produced by a pre-reinvite binary must decode with LibraryID == "".
	payload := `{"fedlib_id":"fed-123","backend":"s3","prefix":"alice","access_key":"ak","secret_key":"sk","label":"Alice"}`
	blob := WriteInvitePrefix + base64.RawURLEncoding.EncodeToString([]byte(payload))
	decoded, err := DecodeWriteInvite(blob)
	if err != nil {
		t.Fatalf("DecodeWriteInvite(old format): %v", err)
	}
	if decoded.LibraryID != "" {
		t.Errorf("LibraryID = %q, want empty for old-format blob", decoded.LibraryID)
	}
}

func TestDecodeBlobWithUnknownExtraField(t *testing.T) {

	// Forward tolerance: a blob from a NEWER binary carrying a field this
	// binary does not know still decodes.
	payload := `{"fedlib_id":"fed-123","backend":"s3","prefix":"alice","access_key":"ak","secret_key":"sk","label":"Alice","future_field":"x"}`
	blob := WriteInvitePrefix + base64.RawURLEncoding.EncodeToString([]byte(payload))
	decoded, err := DecodeWriteInvite(blob)
	if err != nil {
		t.Fatalf("DecodeWriteInvite(unknown field): %v", err)
	}
	if decoded.Prefix != "alice" {
		t.Errorf("Prefix = %q, want alice", decoded.Prefix)
	}
}

func TestEncodeOmitsEmptyLibraryID(t *testing.T) {

	// omitempty: new-member blobs must not grow a library_id key, so old
	// binaries see byte-compatible JSON shape.
	inv := &WriteInvite{
		FedlibID: "fed-123", Backend: "s3", Prefix: "alice",
		AccessKey: "ak", SecretKey: "sk",
	}
	blob := EncodeWriteInvite(inv)
	raw, err := base64.RawURLEncoding.DecodeString(strings.TrimPrefix(blob, WriteInvitePrefix))
	if err != nil {
		t.Fatalf("decode base64: %v", err)
	}
	if strings.Contains(string(raw), "library_id") {
		t.Errorf("empty LibraryID serialized anyway: %s", raw)
	}
}
