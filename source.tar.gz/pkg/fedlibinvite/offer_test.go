package fedlibinvite

import (
	"os"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

func testBlob(t *testing.T) string {
	t.Helper()
	return EncodeWriteInvite(&WriteInvite{
		FedlibID:  "fed-1",
		Backend:   "s3",
		Prefix:    "biopolitics",
		AccessKey: "AKIAEXAMPLESECRETID",
		SecretKey: "verysecretkeymaterial",
		Label:     "Test Librarian",
	})
}

func TestOffer_SealOpenRoundTrip(t *testing.T) {
	token, err := NewOfferToken()
	if err != nil {
		t.Fatal(err)
	}
	blob := testBlob(t)
	o, err := SealOffer(token, blob, "biopolitics", "Test Librarian", time.Now().Add(time.Hour))
	if err != nil {
		t.Fatal(err)
	}
	got, err := OpenOffer(token, o)
	if err != nil {
		t.Fatalf("OpenOffer: %v", err)
	}
	if got != blob {
		t.Fatalf("round-trip mismatch: got %q want %q", got, blob)
	}
}

func TestOffer_WrongTokenFailsDecrypt(t *testing.T) {
	token, _ := NewOfferToken()
	other, _ := NewOfferToken()
	o, err := SealOffer(token, testBlob(t), "p", "d", time.Now().Add(time.Hour))
	if err != nil {
		t.Fatal(err)
	}
	if _, err := OpenOffer(other, o); err == nil {
		t.Fatal("OpenOffer with wrong token succeeded; want authentication failure")
	}
}

func TestOffer_OnDiskNoPlaintext(t *testing.T) {
	dir := t.TempDir()
	token, _ := NewOfferToken()
	blob := testBlob(t)
	o, err := SealOffer(token, blob, "biopolitics", "Test Librarian", time.Now().Add(time.Hour))
	if err != nil {
		t.Fatal(err)
	}
	if err := WriteOffer(dir, token, o); err != nil {
		t.Fatal(err)
	}

	path := filepath.Join(dir, OfferFileName(token))
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	content := string(data)
	for _, secret := range []string{blob, "AKIAEXAMPLESECRETID", "verysecretkeymaterial", token} {
		if strings.Contains(content, secret) {
			t.Fatalf("on-disk offer contains plaintext secret %q", secret)
		}
	}

	info, err := os.Stat(path)
	if err != nil {
		t.Fatal(err)
	}
	if perm := info.Mode().Perm(); perm != 0o600 {
		t.Fatalf("offer file mode = %o, want 0600", perm)
	}
}

func TestOffer_ConcurrentClaimExactlyOneWins(t *testing.T) {
	dir := t.TempDir()
	token, _ := NewOfferToken()
	o, err := SealOffer(token, testBlob(t), "p", "d", time.Now().Add(time.Hour))
	if err != nil {
		t.Fatal(err)
	}
	if err := WriteOffer(dir, token, o); err != nil {
		t.Fatal(err)
	}

	const n = 32
	var wins atomic.Int64
	var wg sync.WaitGroup
	start := make(chan struct{})
	for range n {
		wg.Add(1)
		go func() {
			defer wg.Done()
			<-start
			if _, err := ClaimOffer(dir, token); err == nil {
				wins.Add(1)
			}
		}()
	}
	close(start)
	wg.Wait()

	if got := wins.Load(); got != 1 {
		t.Fatalf("concurrent claims: %d succeeded, want exactly 1", got)
	}

	// Burned: the offer file is gone.
	if _, err := os.Stat(filepath.Join(dir, OfferFileName(token))); !os.IsNotExist(err) {
		t.Fatalf("offer file still present after claim (err=%v)", err)
	}
}

func TestOffer_ClaimUnknownTokenIsNotExist(t *testing.T) {
	dir := t.TempDir()
	token, _ := NewOfferToken()
	if _, err := ClaimOffer(dir, token); !os.IsNotExist(err) {
		t.Fatalf("ClaimOffer on unknown token: err=%v, want IsNotExist", err)
	}
}

func TestOffer_ReadDoesNotBurn(t *testing.T) {
	dir := t.TempDir()
	token, _ := NewOfferToken()
	o, _ := SealOffer(token, testBlob(t), "p", "d", time.Now().Add(time.Hour))
	if err := WriteOffer(dir, token, o); err != nil {
		t.Fatal(err)
	}
	for range 3 {
		if _, err := ReadOffer(dir, token); err != nil {
			t.Fatalf("ReadOffer: %v", err)
		}
	}
	if _, err := ClaimOffer(dir, token); err != nil {
		t.Fatalf("ClaimOffer after reads: %v", err)
	}
}

func TestOffer_SweepExpired(t *testing.T) {
	dir := t.TempDir()

	live, _ := NewOfferToken()
	o1, _ := SealOffer(live, testBlob(t), "live", "d", time.Now().Add(time.Hour))
	if err := WriteOffer(dir, live, o1); err != nil {
		t.Fatal(err)
	}

	dead, _ := NewOfferToken()
	o2, _ := SealOffer(dead, testBlob(t), "dead", "d", time.Now().Add(-time.Hour))
	if err := WriteOffer(dir, dead, o2); err != nil {
		t.Fatal(err)
	}

	removed, err := SweepExpired(dir)
	if err != nil {
		t.Fatal(err)
	}
	if removed != 1 {
		t.Fatalf("SweepExpired removed %d, want 1", removed)
	}
	if _, err := ReadOffer(dir, live); err != nil {
		t.Fatalf("live offer swept: %v", err)
	}
	if _, err := ReadOffer(dir, dead); !os.IsNotExist(err) {
		t.Fatalf("dead offer survived sweep (err=%v)", err)
	}
}

func TestOffer_TokenShape(t *testing.T) {
	for range 50 {
		token, err := NewOfferToken()
		if err != nil {
			t.Fatal(err)
		}
		if !ValidOfferToken(token) {
			t.Fatalf("generated token %q fails ValidOfferToken", token)
		}
	}
	for _, bad := range []string{
		"",
		"short",
		strings.Repeat("a", 25),
		strings.Repeat("a", 27),
		strings.Repeat("A", 26),         // uppercase
		strings.Repeat("a", 25) + "1",   // '1' not in base32 alphabet
		strings.Repeat("a", 25) + "/",   // path char
		"../../../../etc/passwd_______", // traversal shape (28 chars)
	} {
		if ValidOfferToken(bad) {
			t.Fatalf("ValidOfferToken(%q) = true, want false", bad)
		}
	}
}

func TestOffer_ListOffersSkipsTempAndMissing(t *testing.T) {
	dir := t.TempDir()
	offers, err := ListOffers(filepath.Join(dir, "missing"))
	if err != nil {
		t.Fatalf("ListOffers on missing dir: %v", err)
	}
	if len(offers) != 0 {
		t.Fatalf("ListOffers on missing dir: %d entries", len(offers))
	}

	token, _ := NewOfferToken()
	o, _ := SealOffer(token, testBlob(t), "p", "d", time.Now().Add(time.Hour))
	if err := WriteOffer(dir, token, o); err != nil {
		t.Fatal(err)
	}

	// Stray temp file should be ignored.
	if err := os.WriteFile(filepath.Join(dir, ".offer-stray"), []byte("x"), 0o600); err != nil {
		t.Fatal(err)
	}
	offers, err = ListOffers(dir)
	if err != nil {
		t.Fatal(err)
	}
	if len(offers) != 1 {
		t.Fatalf("ListOffers: %d entries, want 1", len(offers))
	}
}
