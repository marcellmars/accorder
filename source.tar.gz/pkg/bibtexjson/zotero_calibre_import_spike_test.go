package bibtexjson_test

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"

	"accorder/pkg/bibtexjson"
)

// -----------------------------------------------------------------------
// H6: BBT Attachment dateModified/dateAdded presence
//

// The generated Go struct (Attachment) does NOT have dateModified/dateAdded
// fields. This test verifies:
//   a) The raw JSON does contain these fields in the sample export
//   b) They are present for ALL attachments (not just some)
//   c) Documents what the struct is silently dropping
//

// The relations/notes type mismatch this test originally had to work around
// ([]string in the struct vs objects in the JSON) was fixed in the same
// workflow — both are json.RawMessage now — so H6 also asserts that the real
// struct unmarshals the real export. See the cq-04 audit in
// quicktype_fields_test.go.
// -----------------------------------------------------------------------

// rawAttachment is a standalone struct (not embedding the generated one)
// to test date field presence without triggering other unmarshal issues.
type rawAttachment struct {
	Title        string  `json:"title"`
	Path         *string `json:"path,omitempty"`
	ContentType  *string `json:"contentType,omitempty"`
	DateModified *string `json:"dateModified,omitempty"`
	DateAdded    *string `json:"dateAdded,omitempty"`
}

// rawItem is a minimal item struct for extracting attachments with dates.
type rawItem struct {
	Title       *string         `json:"title,omitempty"`
	ItemKey     *string         `json:"itemKey,omitempty"`
	Attachments []rawAttachment `json:"attachments,omitempty"`
}

type rawExport struct {
	Items []rawItem `json:"items"`
}

func TestH6_BBTAttachmentDatesPresent(t *testing.T) {
	// The committed fixture. This originally read /tmp/export_from_zotero/aa.json
	// — the 2026-05-11 spike's scratch directory — which meant the test skipped
	// unconditionally once the fixture was committed here instead.
	exportPath := filepath.Join("..", "..", "cmd", "testdata", "export", "aa.json")

	data, err := os.ReadFile(exportPath)
	if err != nil {
		t.Skipf("H6 SKIP: BBT export not found at %s: %v", exportPath, err)
	}

	// Regression guard: the generated struct must unmarshal a real export.
	// It could not when H6 was written (Relations was []string against object
	// JSON); widening Relations and Notes to json.RawMessage fixed that, and
	// this asserts it stays fixed.
	if _, err := bibtexjson.UnmarshalBetterBibTex(data); err != nil {
		t.Errorf("H6: UnmarshalBetterBibTex failed on the real export: %v", err)
	}

	// Parse with our minimal raw struct that includes date fields
	var raw rawExport
	if err := json.Unmarshal(data, &raw); err != nil {
		t.Fatalf("failed to unmarshal with raw struct: %v", err)
	}

	totalAttachments := 0
	withDateModified := 0
	withDateAdded := 0
	missingDates := 0

	for _, item := range raw.Items {
		title := "unknown"
		if item.Title != nil {
			title = *item.Title
		}
		key := "unknown"
		if item.ItemKey != nil {
			key = *item.ItemKey
		}

		for j, att := range item.Attachments {
			totalAttachments++
			hasMod := att.DateModified != nil
			hasAdd := att.DateAdded != nil

			if hasMod {
				withDateModified++
			}
			if hasAdd {
				withDateAdded++
			}
			if !hasMod || !hasAdd {
				missingDates++
				t.Logf("H6 WARNING: item %s att %d missing dates: dateModified=%v dateAdded=%v",
					key, j, att.DateModified, att.DateAdded)
			} else {
				t.Logf("H6 OK: item %s (%s) att %d: dateModified=%s dateAdded=%s",
					key, title[:min(len(title), 30)], j, *att.DateModified, *att.DateAdded)
			}
		}
	}

	t.Logf("H6 SUMMARY: %d total attachments, %d with dateModified, %d with dateAdded, %d missing any date",
		totalAttachments, withDateModified, withDateAdded, missingDates)

	if totalAttachments == 0 {
		t.Error("H6 FAIL: no attachments found in export")
	} else if missingDates > 0 {
		t.Errorf("H6 PARTIAL: %d/%d attachments missing date fields", missingDates, totalAttachments)
	} else {
		t.Logf("H6 VALIDATED: all %d attachments have both dateModified and dateAdded", totalAttachments)
	}

	// Document that the existing Attachment struct is missing these fields
	t.Logf("H6 NOTE: bibtexjson.Attachment struct lacks dateModified/dateAdded fields — " +
		"these are silently dropped during UnmarshalBetterBibTex. The struct needs extending.")
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
