package bibtexjson_test

import (
	"encoding/json"
	"reflect"
	"sort"
	"strings"
	"testing"

	"accorder/pkg/bibtexjson"
)

// ═══════════════════════════════════════════════════════════════════
// ROADMAP cq-04 — standing audit of quicktype-generated field types.
//
// betterbibtexjson.go is quicktype output, and quicktype resolves polymorphic
// JSON (objects vs. strings) to whichever shape it saw. Twice this bit us:
// Item.Relations and Item.Notes were both generated as []string against JSON
// that actually carries objects, and both had to be re-typed json.RawMessage
// (workflow 2026-05-11_zotero-calibre-import; see
// .sit/howto/quicktype_struct_validation.md).
//
// These tests turn that one-time audit into a guard. Regenerating the structs
// from a new export, or hand-editing a field, fails here rather than at some
// user's `lib import`.
// ═══════════════════════════════════════════════════════════════════

// rawMessageFields are the fields deliberately widened to json.RawMessage
// because accorder does not consume them and their JSON shape is polymorphic.
var rawMessageFields = []string{"Extra", "Notes", "Relations"}

func TestItem_PolymorphicFieldsStayRawMessage(t *testing.T) {
	typ := reflect.TypeOf(bibtexjson.Item{})
	want := reflect.TypeOf(json.RawMessage{})

	for _, name := range rawMessageFields {
		f, ok := typ.FieldByName(name)
		if !ok {
			t.Errorf("Item.%s no longer exists; if it was renamed, update rawMessageFields", name)
			continue
		}
		if f.Type != want {
			t.Errorf("Item.%s is %s, want json.RawMessage — quicktype has re-narrowed a polymorphic field; "+
				"see .sit/howto/quicktype_struct_validation.md", name, f.Type)
		}
	}
}

// TestItem_NoUnexpectedStringSlices is the audit itself. Every []string field
// on Item is a claim that the JSON at that key is an array of plain strings.
// Item.Collections is the only field currently making that claim (BBT emits
// collection keys). Anything new appearing here has not been validated against
// a real export and is a Relations/Notes repeat waiting to happen.
func TestItem_NoUnexpectedStringSlices(t *testing.T) {
	allowed := map[string]bool{"Collections": true}

	typ := reflect.TypeOf(bibtexjson.Item{})
	var found []string
	for i := 0; i < typ.NumField(); i++ {
		f := typ.Field(i)
		if f.Type.Kind() == reflect.Slice && f.Type.Elem().Kind() == reflect.String {
			if !allowed[f.Name] {
				found = append(found, f.Name+" (json:"+strings.Split(f.Tag.Get("json"), ",")[0]+")")
			}
		}
	}
	sort.Strings(found)

	if len(found) > 0 {
		t.Errorf("unvalidated []string field(s) on Item: %s\n"+
			"Each must be checked against a real BetterBibTeX export before it is trusted. "+
			"If the JSON can hold objects, widen it to json.RawMessage (the Relations/Notes fix); "+
			"if it really is an array of strings, add it to the allowed set with a note. "+
			"See ROADMAP cq-04.", strings.Join(found, ", "))
	}
}
