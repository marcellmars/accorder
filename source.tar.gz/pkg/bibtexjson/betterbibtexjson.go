package bibtexjson

import "encoding/json"

func UnmarshalBetterBibTex(data []byte) (BetterBibTex, error) {
	var r BetterBibTex
	err := json.Unmarshal(data, &r)
	return r, err
}

func (r *BetterBibTex) Marshal() ([]byte, error) {
	return json.Marshal(r)
}

type BetterBibTex struct {
	Collections map[string]Collection             `json:"collections,omitempty"`
	Config      ClientConfigurationAtTimeOfExport `json:"config"`
	Items       []Item                            `json:"items"`
	Version     Version                           `json:"version"`
}

type Version struct {
	Zotero       string `json:"zotero"`
	BetterBibTex string `json:"bbt"`
}

type Collection struct {
	Collections []string `json:"collections"`
	Items       []int64  `json:"items"`
	Key         string   `json:"key"`
	Name        string   `json:"name"`
	Parent      *string  `json:"parent,omitempty"`
}

type ClientConfigurationAtTimeOfExport struct {
	ID              ID           `json:"id"`
	Label           *Label       `json:"label,omitempty"`
	LocaleDateOrder *string      `json:"localeDateOrder,omitempty"`
	Options         *Options     `json:"options,omitempty"`
	Preferences     *Preferences `json:"preferences,omitempty"`
}

type Options struct {
	Authors                *bool   `json:"Authors,omitempty"`
	ExportFileData         *bool   `json:"exportFileData,omitempty"`
	ExportNotes            *bool   `json:"exportNotes,omitempty"`
	Items                  *bool   `json:"Items,omitempty"`
	KeepUpdated            *bool   `json:"keepUpdated,omitempty"`
	Markdown               *bool   `json:"markdown,omitempty"`
	Normalize              *bool   `json:"Normalize,omitempty"`
	Preferences            *bool   `json:"Preferences,omitempty"`
	QuickCopyMode          *string `json:"quickCopyMode,omitempty"`
	Title                  *bool   `json:"Title,omitempty"`
	UseJournalAbbreviation *bool   `json:"useJournalAbbreviation,omitempty"`
	Worker                 *bool   `json:"worker,omitempty"`
	Year                   *bool   `json:"Year,omitempty"`
}

type Preferences struct {
	ASCII                           *string               `json:"ascii,omitempty"`
	ASCIIBibLaTeX                   *bool                 `json:"asciiBibLaTeX,omitempty"`
	ASCIIBibTeX                     *bool                 `json:"asciiBibTeX,omitempty"`
	AutoAbbrev                      *bool                 `json:"autoAbbrev,omitempty"`
	AutoAbbrevStyle                 *string               `json:"autoAbbrevStyle,omitempty"`
	AutoExport                      *AutoExport           `json:"autoExport,omitempty"`
	AutoExportDelay                 *float64              `json:"autoExportDelay,omitempty"`
	AutoExportIdleWait              *float64              `json:"autoExportIdleWait,omitempty"`
	AutoExportPathReplaceDiacritics *bool                 `json:"autoExportPathReplaceDiacritics,omitempty"`
	AutoExportPathReplaceDirSep     *string               `json:"autoExportPathReplaceDirSep,omitempty"`
	AutoExportPathReplaceSpace      *string               `json:"autoExportPathReplaceSpace,omitempty"`
	AutomaticTags                   *bool                 `json:"automaticTags,omitempty"`
	AutoPinDelay                    *float64              `json:"autoPinDelay,omitempty"`
	AuxImport                       *bool                 `json:"auxImport,omitempty"`
	BaseAttachmentPath              *string               `json:"baseAttachmentPath,omitempty"`
	BiblatexExtendedDateFormat      *bool                 `json:"biblatexExtendedDateFormat,omitempty"`
	BiblatexExtendedNameFormat      *bool                 `json:"biblatexExtendedNameFormat,omitempty"`
	BiblatexExtractEprint           *bool                 `json:"biblatexExtractEprint,omitempty"`
	BibtexEditionOrdinal            *bool                 `json:"bibtexEditionOrdinal,omitempty"`
	BibtexParticleNoOp              *bool                 `json:"bibtexParticleNoOp,omitempty"`
	BibtexURL                       *BibtexURL            `json:"bibtexURL,omitempty"`
	Cache                           *bool                 `json:"cache,omitempty"`
	CacheFlushInterval              *float64              `json:"cacheFlushInterval,omitempty"`
	Charmap                         *string               `json:"charmap,omitempty"`
	CiteCommand                     *string               `json:"citeCommand,omitempty"`
	CitekeyCaseInsensitive          *bool                 `json:"citekeyCaseInsensitive,omitempty"`
	CitekeyFold                     *bool                 `json:"citekeyFold,omitempty"`
	CitekeyFormat                   *string               `json:"citekeyFormat,omitempty"`
	CitekeySearch                   *bool                 `json:"citekeySearch,omitempty"`
	CitekeyUnsafeChars              *string               `json:"citekeyUnsafeChars,omitempty"`
	Csquotes                        *string               `json:"csquotes,omitempty"`
	DOIandURL                       *DOIandURL            `json:"DOIandURL,omitempty"`
	ExportBibTeXStrings             *ExportBibTeXStrings  `json:"exportBibTeXStrings,omitempty"`
	ExportBraceProtection           *bool                 `json:"exportBraceProtection,omitempty"`
	ExportTitleCase                 *bool                 `json:"exportTitleCase,omitempty"`
	ExtraMergeCitekeys              *bool                 `json:"extraMergeCitekeys,omitempty"`
	ExtraMergeCSL                   *bool                 `json:"extraMergeCSL,omitempty"`
	ExtraMergeTeX                   *bool                 `json:"extraMergeTeX,omitempty"`
	Git                             *string               `json:"git,omitempty"`
	Import                          *bool                 `json:"import,omitempty"`
	ImportBibTeXStrings             *bool                 `json:"importBibTeXStrings,omitempty"`
	ImportCaseProtection            *ImportCaseProtection `json:"importCaseProtection,omitempty"`
	ImportCitationKey               *bool                 `json:"importCitationKey,omitempty"`
	ImportDetectURLs                *bool                 `json:"importDetectURLs,omitempty"`
	ImportExtra                     *bool                 `json:"importExtra,omitempty"`
	ImportJabRefAbbreviations       *bool                 `json:"importJabRefAbbreviations,omitempty"`
	ImportJabRefStrings             *bool                 `json:"importJabRefStrings,omitempty"`
	ImportNoteToExtra               *string               `json:"importNoteToExtra,omitempty"`
	ImportSentenceCase              *ImportSentenceCase   `json:"importSentenceCase,omitempty"`
	ImportSentenceCaseQuoted        *bool                 `json:"importSentenceCaseQuoted,omitempty"`
	ImportUnknownTexCommand         *string               `json:"importUnknownTexCommand,omitempty"`
	ItemObserverDelay               *float64              `json:"itemObserverDelay,omitempty"`
	JabrefFormat                    *float64              `json:"jabrefFormat,omitempty"`
	Jieba                           *bool                 `json:"jieba,omitempty"`
	KeyConflictPolicy               *KeyConflictPolicy    `json:"keyConflictPolicy,omitempty"`
	KeyScope                        *KeyScope             `json:"keyScope,omitempty"`
	Kuroshiro                       *bool                 `json:"kuroshiro,omitempty"`
	Language                        *LanguageEnum         `json:"language,omitempty"`
	LogEvents                       *bool                 `json:"logEvents,omitempty"`
	MapMath                         *string               `json:"mapMath,omitempty"`
	MapText                         *string               `json:"mapText,omitempty"`
	Packages                        *string               `json:"packages,omitempty"`
	ParseParticles                  *bool                 `json:"parseParticles,omitempty"`
	PatchDates                      *string               `json:"patchDates,omitempty"`
	Postscript                      *string               `json:"postscript,omitempty"`
	PostscriptOverride              *string               `json:"postscriptOverride,omitempty"`
	PreferencesOverride             *string               `json:"preferencesOverride,omitempty"`
	QualityReport                   *bool                 `json:"qualityReport,omitempty"`
	QuickCopyEta                    *string               `json:"quickCopyEta,omitempty"`
	QuickCopyMode                   *QuickCopyMode        `json:"quickCopyMode,omitempty"`
	QuickCopyOrgMode                *QuickCopy            `json:"quickCopyOrgMode,omitempty"`
	QuickCopyPandocBrackets         *bool                 `json:"quickCopyPandocBrackets,omitempty"`
	QuickCopySelectLink             *QuickCopy            `json:"quickCopySelectLink,omitempty"`
	RawImports                      *bool                 `json:"rawImports,omitempty"`
	RawLaTag                        *string               `json:"rawLaTag,omitempty"`
	RelativeFilePaths               *bool                 `json:"relativeFilePaths,omitempty"`
	RetainCache                     *bool                 `json:"retainCache,omitempty"`
	ScrubDatabase                   *bool                 `json:"scrubDatabase,omitempty"`
	SeparatorList                   *string               `json:"separatorList,omitempty"`
	SeparatorNames                  *string               `json:"separatorNames,omitempty"`
	SkipFields                      *string               `json:"skipFields,omitempty"`
	SkipWords                       *string               `json:"skipWords,omitempty"`
	StartupProgress                 *string               `json:"startupProgress,omitempty"`
	Strings                         *string               `json:"strings,omitempty"`
	StringsOverride                 *string               `json:"stringsOverride,omitempty"`
	VerbatimFields                  *string               `json:"verbatimFields,omitempty"`
	WarnBulkModify                  *float64              `json:"warnBulkModify,omitempty"`
	WarnTitleCased                  *bool                 `json:"warnTitleCased,omitempty"`
}

type Item struct {
	AbstractNote        *string                `json:"abstractNote,omitempty"`
	AccessDate          *string                `json:"accessDate,omitempty"`
	AdminFlag           *string                `json:"adminFlag,omitempty"`
	AdoptionDate        *string                `json:"adoptionDate,omitempty"`
	ApplicationNumber   *string                `json:"applicationNumber,omitempty"`
	Archive             *string                `json:"archive,omitempty"`
	ArchiveCollection   *string                `json:"archiveCollection,omitempty"`
	ArchiveLocation     *string                `json:"archiveLocation,omitempty"`
	ArtworkSize         *string                `json:"artworkSize,omitempty"`
	AssemblyNumber      *string                `json:"assemblyNumber,omitempty"`
	Assignee            *string                `json:"assignee,omitempty"`
	Attachments         []Attachment           `json:"attachments,omitempty"`
	Authority           *string                `json:"authority,omitempty"`
	CallNumber          *string                `json:"callNumber,omitempty"`
	CitationKey         *string                `json:"citationKey,omitempty"`
	Code                *string                `json:"code,omitempty"`
	CodeNumber          *string                `json:"codeNumber,omitempty"`
	Collections         []string               `json:"collections,omitempty"`
	Committee           *string                `json:"committee,omitempty"`
	ConferenceDate      *string                `json:"conferenceDate,omitempty"`
	ConferenceName      *string                `json:"conferenceName,omitempty"`
	Country             *string                `json:"country,omitempty"`
	Court               *string                `json:"court,omitempty"`
	Creators            []Creator              `json:"creators,omitempty"`
	Date                *string                `json:"date,omitempty"`
	DateAdded           *string                `json:"dateAdded,omitempty"`
	DateAmended         *string                `json:"dateAmended,omitempty"`
	DateModified        *string                `json:"dateModified,omitempty"`
	Division            *string                `json:"division,omitempty"`
	DocumentName        *string                `json:"documentName,omitempty"`
	DocumentNumber      *string                `json:"documentNumber,omitempty"`
	Doi                 *string                `json:"DOI,omitempty"`
	Edition             *string                `json:"edition,omitempty"`
	Extra               json.RawMessage        `json:"extra,omitempty"`
	FilingDate          *string                `json:"filingDate,omitempty"`
	GazetteFlag         *string                `json:"gazetteFlag,omitempty"`
	Genre               *string                `json:"genre,omitempty"`
	History             *string                `json:"history,omitempty"`
	Institution         *string                `json:"institution,omitempty"`
	Isbn                *string                `json:"ISBN,omitempty"`
	Issn                *string                `json:"ISSN,omitempty"`
	Issue               *string                `json:"issue,omitempty"`
	IssuingAuthority    *string                `json:"issuingAuthority,omitempty"`
	ItemID              *int64                 `json:"itemID,omitempty"`
	ItemType            *ItemItemType          `json:"itemType,omitempty"`
	JournalAbbreviation *string                `json:"journalAbbreviation,omitempty"`
	Jurisdiction        *string                `json:"jurisdiction,omitempty"`
	ItemKey             *string                `json:"itemKey,omitempty"`
	Language            *string                `json:"language,omitempty"`
	LegalStatus         *string                `json:"legalStatus,omitempty"`
	LegislativeBody     *string                `json:"legislativeBody,omitempty"`
	LibraryCatalog      *string                `json:"libraryCatalog,omitempty"`
	Medium              *string                `json:"medium,omitempty"`
	MeetingName         *string                `json:"meetingName,omitempty"`
	MeetingNumber       *string                `json:"meetingNumber,omitempty"`
	Multi               map[string]interface{} `json:"multi,omitempty"`
	NewsCaseDate        *string                `json:"newsCaseDate,omitempty"`
	Note                *string                `json:"note,omitempty"`
	Notes               json.RawMessage        `json:"notes,omitempty"`
	Number              *string                `json:"number,omitempty"`
	NumberOfVolumes     *string                `json:"numberOfVolumes,omitempty"`
	NumPages            *string                `json:"numPages,omitempty"`
	OpeningDate         *string                `json:"openingDate,omitempty"`
	Opus                *string                `json:"opus,omitempty"`
	OriginalDate        *string                `json:"originalDate,omitempty"`
	Pages               *string                `json:"pages,omitempty"`
	ParentTreaty        *string                `json:"parentTreaty,omitempty"`
	Place               *string                `json:"place,omitempty"`
	PriorityDate        *string                `json:"priorityDate,omitempty"`
	PriorityNumbers     *string                `json:"priorityNumbers,omitempty"`
	ProgrammingLanguage *string                `json:"programmingLanguage,omitempty"`
	PublicationDate     *string                `json:"publicationDate,omitempty"`
	PublicationNumber   *string                `json:"publicationNumber,omitempty"`
	PublicationTitle    *string                `json:"publicationTitle,omitempty"`
	Publisher           *string                `json:"publisher,omitempty"`
	References          *string                `json:"references,omitempty"`
	RegnalYear          *string                `json:"regnalYear,omitempty"`
	Reign               *string                `json:"reign,omitempty"`
	Relations           json.RawMessage        `json:"relations,omitempty"`
	Reporter            *string                `json:"reporter,omitempty"`
	ResolutionLabel     *string                `json:"resolutionLabel,omitempty"`
	Rights              *string                `json:"rights,omitempty"`
	RunningTime         *string                `json:"runningTime,omitempty"`
	Scale               *string                `json:"scale,omitempty"`
	Section             *string                `json:"section,omitempty"`
	Series              *string                `json:"series,omitempty"`
	SeriesNumber        *string                `json:"seriesNumber,omitempty"`
	SeriesText          *string                `json:"seriesText,omitempty"`
	SeriesTitle         *string                `json:"seriesTitle,omitempty"`
	Session             *string                `json:"session,omitempty"`
	ShortTitle          *string                `json:"shortTitle,omitempty"`
	SigningDate         *string                `json:"signingDate,omitempty"`
	Status              *string                `json:"status,omitempty"`
	SupplementName      *string                `json:"supplementName,omitempty"`
	System              *string                `json:"system,omitempty"`
	Tags                []ItemTag              `json:"tags,omitempty"`
	Title               *string                `json:"title,omitempty"`
	Type                *string                `json:"type,omitempty"`
	URI                 *string                `json:"uri,omitempty"`
	URL                 *string                `json:"url,omitempty"`
	VersionNumber       *string                `json:"versionNumber,omitempty"`
	Volume              *string                `json:"volume,omitempty"`
	VolumeTitle         *string                `json:"volumeTitle,omitempty"`
	YearAsVolume        *string                `json:"yearAsVolume,omitempty"`
}

type Attachment struct {
	AccessDate   *string             `json:"accessDate,omitempty"`
	ContentType  *string             `json:"contentType,omitempty"`
	DateAdded    *string             `json:"dateAdded,omitempty"`
	DateModified *string             `json:"dateModified,omitempty"`
	ItemType     *AttachmentItemType `json:"itemType,omitempty"`
	Key          *string             `json:"key,omitempty"`
	LinkMode     *string             `json:"linkMode,omitempty"`
	Path         *string             `json:"path,omitempty"`
	Relations    json.RawMessage     `json:"relations,omitempty"`
	Select       *string             `json:"select,omitempty"`
	Tags         []AttachmentTag     `json:"tags,omitempty"`
	Title        string              `json:"title"`
	URI          *string             `json:"uri,omitempty"`
	URL          *string             `json:"url,omitempty"`
}

type AttachmentTag struct {
	Tag  string `json:"tag"`
	Type *int64 `json:"type,omitempty"`
}

type Creator struct {
	CreatorType *CreatorType           `json:"creatorType,omitempty"`
	FirstName   *string                `json:"firstName,omitempty"`
	LastName    *string                `json:"lastName,omitempty"`
	Multi       map[string]interface{} `json:"multi,omitempty"`
	Name        *string                `json:"name,omitempty"`
}

type ItemTag struct {
	Tag  string `json:"tag"`
	Type *int64 `json:"type,omitempty"`
}

type ID string

const (
	The36A3B0B5Bad04A04B79B441C7Cef77DB ID = "36a3b0b5-bad0-4a04-b79b-441c7cef77db"
)

type Label string

const (
	BetterBibTeXJSON Label = "BetterBibTeX JSON"
)

type AutoExport string

const (
	AutoExportOff AutoExport = "off"
	Idle          AutoExport = "idle"
	Immediate     AutoExport = "immediate"
)

type BibtexURL string

const (
	BibtexURLNote BibtexURL = "note"
	BibtexURLOff  BibtexURL = "off"
	BibtexURLURL  BibtexURL = "url"
	NoteURLIsh    BibtexURL = "note-url-ish"
	URLIsh        BibtexURL = "url-ish"
)

type DOIandURL string

const (
	DOIandURLBoth DOIandURL = "both"
	DOIandURLURL  DOIandURL = "url"
	Doi           DOIandURL = "doi"
)

type ExportBibTeXStrings string

const (
	Detect                 ExportBibTeXStrings = "detect"
	ExportBibTeXStringsOff ExportBibTeXStrings = "off"
	Match                  ExportBibTeXStrings = "match"
	MatchReverse           ExportBibTeXStrings = "match+reverse"
)

type ImportCaseProtection string

const (
	AsNeeded                ImportCaseProtection = "as-needed"
	ImportCaseProtectionOff ImportCaseProtection = "off"
	ImportCaseProtectionOn  ImportCaseProtection = "on"
)

type ImportSentenceCase string

const (
	ImportSentenceCaseOff ImportSentenceCase = "off"
	ImportSentenceCaseOn  ImportSentenceCase = "on"
	OnGuess               ImportSentenceCase = "on+guess"
)

type KeyConflictPolicy string

const (
	Change KeyConflictPolicy = "change"
	Keep   KeyConflictPolicy = "keep"
)

type KeyScope string

const (
	Global  KeyScope = "global"
	Library KeyScope = "library"
)

type LanguageEnum string

const (
	Langid       LanguageEnum = "langid"
	Language     LanguageEnum = "language"
	LanguageBoth LanguageEnum = "both"
)

type QuickCopyMode string

const (
	Citekeys    QuickCopyMode = "citekeys"
	Eta         QuickCopyMode = "eta"
	Gitbook     QuickCopyMode = "gitbook"
	Jekyll      QuickCopyMode = "jekyll"
	Jupyter     QuickCopyMode = "jupyter"
	Latex       QuickCopyMode = "latex"
	OrgRef      QuickCopyMode = "orgRef"
	OrgRef3     QuickCopyMode = "orgRef3"
	Orgmode     QuickCopyMode = "orgmode"
	Pandoc      QuickCopyMode = "pandoc"
	RoamCiteKey QuickCopyMode = "roamCiteKey"
	RtfScan     QuickCopyMode = "rtfScan"
	Selectlink  QuickCopyMode = "selectlink"
)

type QuickCopy string

const (
	Citationkey QuickCopy = "citationkey"
	Zotero      QuickCopy = "zotero"
)

type AttachmentItemType string

const (
	PurpleAttachment AttachmentItemType = "attachment"
)

type CreatorType string

const (
	Artist         CreatorType = "artist"
	AttorneyAgent  CreatorType = "attorneyAgent"
	Author         CreatorType = "author"
	BookAuthor     CreatorType = "bookAuthor"
	Cartographer   CreatorType = "cartographer"
	CastMember     CreatorType = "castMember"
	Commenter      CreatorType = "commenter"
	Composer       CreatorType = "composer"
	Contributor    CreatorType = "contributor"
	Cosponsor      CreatorType = "cosponsor"
	Counsel        CreatorType = "counsel"
	Director       CreatorType = "director"
	Editor         CreatorType = "editor"
	Guest          CreatorType = "guest"
	Interviewee    CreatorType = "interviewee"
	Interviewer    CreatorType = "interviewer"
	Inventor       CreatorType = "inventor"
	Performer      CreatorType = "performer"
	Podcaster      CreatorType = "podcaster"
	Presenter      CreatorType = "presenter"
	Producer       CreatorType = "producer"
	Programmer     CreatorType = "programmer"
	Recipient      CreatorType = "recipient"
	ReviewedAuthor CreatorType = "reviewedAuthor"
	Scriptwriter   CreatorType = "scriptwriter"
	SeriesEditor   CreatorType = "seriesEditor"
	Sponsor        CreatorType = "sponsor"
	TestimonyBy    CreatorType = "testimonyBy"
	Translator     CreatorType = "translator"
	WordsBy        CreatorType = "wordsBy"
)

type ItemItemType string

const (
	Annotation          ItemItemType = "annotation"
	Artwork             ItemItemType = "artwork"
	AudioRecording      ItemItemType = "audioRecording"
	Bill                ItemItemType = "bill"
	BlogPost            ItemItemType = "blogPost"
	Book                ItemItemType = "book"
	BookSection         ItemItemType = "bookSection"
	Case                ItemItemType = "case"
	Classic             ItemItemType = "classic"
	ComputerProgram     ItemItemType = "computerProgram"
	ConferencePaper     ItemItemType = "conferencePaper"
	Dataset             ItemItemType = "dataset"
	DictionaryEntry     ItemItemType = "dictionaryEntry"
	Document            ItemItemType = "document"
	Email               ItemItemType = "email"
	EncyclopediaArticle ItemItemType = "encyclopediaArticle"
	Film                ItemItemType = "film"
	FluffyAttachment    ItemItemType = "attachment"
	ForumPost           ItemItemType = "forumPost"
	Gazette             ItemItemType = "gazette"
	Hearing             ItemItemType = "hearing"
	InstantMessage      ItemItemType = "instantMessage"
	Interview           ItemItemType = "interview"
	ItemTypeNote        ItemItemType = "note"
	JournalArticle      ItemItemType = "journalArticle"
	LegalCommentary     ItemItemType = "legalCommentary"
	Letter              ItemItemType = "letter"
	MagazineArticle     ItemItemType = "magazineArticle"
	Manuscript          ItemItemType = "manuscript"
	Map                 ItemItemType = "map"
	NewspaperArticle    ItemItemType = "newspaperArticle"
	Patent              ItemItemType = "patent"
	Podcast             ItemItemType = "podcast"
	Preprint            ItemItemType = "preprint"
	Presentation        ItemItemType = "presentation"
	RadioBroadcast      ItemItemType = "radioBroadcast"
	Regulation          ItemItemType = "regulation"
	Report              ItemItemType = "report"
	Standard            ItemItemType = "standard"
	Statute             ItemItemType = "statute"
	Thesis              ItemItemType = "thesis"
	Treaty              ItemItemType = "treaty"
	TvBroadcast         ItemItemType = "tvBroadcast"
	VideoRecording      ItemItemType = "videoRecording"
	Webpage             ItemItemType = "webpage"
)
