//go:build integration && wasabi_e2e && calibre_e2e

package browselocal

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

// TestLibUpload_RetroactivePrivateDelete verifies the privacy fix: a book tagged
// "private" AFTER it was already published must have its files DELETED from the
// remote on the next upload — not merely skipped. Without --delete-excluded,
// rclone leaves excluded dest files in place, so the "private" book stays
// publicly fetchable. Round-trips against live Wasabi on a throwaway prefix.
//
// Run: go test -tags 'integration wasabi_e2e calibre_e2e' -run TestLibUpload_RetroactivePrivateDelete ./pkg/browselocal/
func TestLibUpload_RetroactivePrivateDelete(t *testing.T) {
	c, ok := resolveWasabiFullKeys(t)
	if !ok {
		t.Skip("wasabi_full.keys not found at repo root — skipping")
	}
	if _, err := exec.LookPath("calibredb"); err != nil {
		t.Skip("calibredb not on PATH — skipping")
	}
	const pfx = "zz-e2e-private"
	const libID = "bbbbbbbb-0000-4000-8000-000000000002"

	bin := buildAccorderBinary(t)
	env := append(os.Environ(), "XDG_CONFIG_HOME="+t.TempDir())
	lib := filepath.Join(t.TempDir(), "lib")
	purge := func() { _ = rclonePurge(c, "motw/"+pfx) }
	purge()
	t.Cleanup(purge)

	addBook := func(title string) string {
		t.Helper()
		f := filepath.Join(t.TempDir(), title+".txt")
		if err := os.WriteFile(f, []byte("body of "+title), 0o644); err != nil {
			t.Fatal(err)
		}
		out, err := exec.Command("calibredb", "add", f, "--library-path", lib).CombinedOutput()
		if err != nil {
			t.Fatalf("calibredb add %s: %v\n%s", title, err, out)
		}
		// "Added book ids: N"
		fields := strings.Fields(string(out))
		return fields[len(fields)-1]
	}
	runAcc := func(args ...string) {
		t.Helper()
		cmd := exec.Command(bin, args...)
		cmd.Env = env
		if out, err := cmd.CombinedOutput(); err != nil {
			t.Fatalf("accorder %s: %v\n%s", strings.Join(args, " "), err, out)
		}
	}
	build := func() {
		t.Helper()
		runAcc("lib", "build", "--calibrepath", lib, "--librarian", "tester", "--libraryID", libID,
			"--jsonl-export", "--jsonl-path", lib+".jsonl")
		runAcc("lib", "build", "--calibrepath", lib, "--librarian", "tester", "--libraryID", libID,
			"--index", "--index-path", lib+"/static/library_index", "--jsonl-path", lib+".jsonl")
	}
	upload := func() {
		t.Helper()
		runAcc("lib", "upload", "priv", "--calibrepath", lib, "--librarian", "tester", "--libraryID", libID,
			"--bucket", "motw/"+pfx, "--s3-access-key", c.accessKey, "--s3-secret-key", c.secretKey,
			"--s3-provider", "Wasabi", "--s3-endpoint", "s3.wasabisys.com")
	}
	remoteList := func() string {
		t.Helper()
		cmd := exec.Command("rclone", "lsf", "-R", "was:motw/"+pfx+"/")
		cmd.Env = rcloneEnv(c)
		out, err := cmd.CombinedOutput()
		if err != nil {
			t.Fatalf("rclone lsf: %v\n%s", err, out)
		}
		return string(out)
	}

	// --- publish two PUBLIC books ---
	addBook("PublicAlpha")
	addBook("SecretBeta")
	build()
	upload()
	if r := remoteList(); !strings.Contains(r, "PublicAlpha") || !strings.Contains(r, "SecretBeta") {
		t.Fatalf("both books should be on S3 after first upload, got:\n%s", r)
	}
	t.Log("OK: both books published to S3")

	// --- tag SecretBeta "private", rebuild, re-upload ---
	calibredb := func(args ...string) {
		t.Helper()
		if out, err := exec.Command("calibredb", append(args, "--library-path", lib)...).CombinedOutput(); err != nil {
			t.Fatalf("calibredb %v: %v\n%s", args, err, out)
		}
	}
	// find SecretBeta's id (calibredb search prints matching ids) and tag it private
	idOut, err := exec.Command("calibredb", "search", "title:SecretBeta", "--library-path", lib).CombinedOutput()
	if err != nil {
		t.Fatalf("calibredb search: %v\n%s", err, idOut)
	}
	id := strings.TrimSpace(string(idOut))
	if id == "" {
		t.Fatalf("could not find SecretBeta id")
	}
	calibredb("set_metadata", id, "--field", "tags:private")
	build()
	upload()

	// --- SecretBeta's files must be GONE from S3; PublicAlpha untouched ---
	r := remoteList()
	if strings.Contains(r, "SecretBeta") {
		t.Fatalf("retroactively-private book is STILL on S3 (should be deleted):\n%s", r)
	}
	if !strings.Contains(r, "PublicAlpha") {
		t.Fatalf("public book was wrongly deleted:\n%s", r)
	}
	t.Log("OK: retroactively-private book deleted from S3; public book intact")
}
