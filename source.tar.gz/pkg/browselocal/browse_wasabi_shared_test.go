//go:build integration && (wasabi_e2e || wasabi_bulk_e2e)

package browselocal

import (
	"bufio"
	"context"
	"encoding/json"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"
	"testing"
	"time"
)

// This file holds helpers shared by the live Wasabi tiers of the browse e2e
// harness — the cheap smoke (tier D, //go:build wasabi_e2e,
// TestBrowse_E2E_WasabiSmoke) and the heavy bulk run (//go:build
// wasabi_bulk_e2e, TestBrowse_E2E_WasabiBulk). Build constraint covers both
// tags so either tier compiles standalone.

// --- credentials ----------------------------------------------------------

type wasabiCreds struct {
	bucket, accessKey, secretKey, provider, endpoint, uploadPrefix string
	source                                                         string
}

// maskKey shows only the head/tail of a secret so logs never leak it.
func maskKey(s string) string {
	if len(s) <= 6 {
		return "***"
	}
	return s[:3] + "***" + s[len(s)-2:]
}

// resolveWasabiCreds reads S3 creds at runtime: env vars first, then the
// "aggtest" alias in ~/.config/accorder/action_aliases.json. Returns
// ok=false if access/secret/bucket/endpoint cannot all be resolved.
func resolveWasabiCreds(t *testing.T) (wasabiCreds, bool) {
	t.Helper()
	c := wasabiCreds{
		bucket:       os.Getenv("S3_BUCKET"),
		accessKey:    os.Getenv("S3_ACCESS_KEY"),
		secretKey:    os.Getenv("S3_SECRET_KEY"),
		provider:     os.Getenv("S3_PROVIDER"),
		endpoint:     os.Getenv("S3_ENDPOINT"),
		uploadPrefix: os.Getenv("S3_UPLOAD_PREFIX"),
		source:       "env",
	}
	if c.accessKey != "" && c.secretKey != "" && c.bucket != "" && c.endpoint != "" {
		applyCredDefaults(&c)
		return c, true
	}

	// Fall back to the aggtest alias.
	home, err := os.UserHomeDir()
	if err != nil {
		return c, false
	}
	aliasPath := filepath.Join(home, ".config", "accorder", "action_aliases.json")
	data, err := os.ReadFile(aliasPath)
	if err != nil {
		return c, false
	}
	var root map[string]json.RawMessage
	if err := json.Unmarshal(data, &root); err != nil {
		return c, false
	}
	aggtest, ok := root["aggtest"]
	if !ok {
		return c, false
	}
	node := findS3Node(aggtest)
	if node == nil {
		return c, false
	}
	if c.accessKey == "" {
		c.accessKey = node["s3-access-key"]
	}
	if c.secretKey == "" {
		c.secretKey = node["s3-secret-key"]
	}
	if c.bucket == "" {
		c.bucket = node["bucket"]
	}
	if c.provider == "" {
		c.provider = node["s3-provider"]
	}
	if c.endpoint == "" {
		c.endpoint = node["s3-endpoint"]
	}
	if c.uploadPrefix == "" {
		c.uploadPrefix = node["upload-prefix"]
	}
	c.source = "aggtest alias (" + aliasPath + ")"
	if c.accessKey == "" || c.secretKey == "" || c.bucket == "" || c.endpoint == "" {
		return c, false
	}
	applyCredDefaults(&c)
	return c, true
}

func applyCredDefaults(c *wasabiCreds) {
	if c.provider == "" {
		c.provider = "Wasabi"
	}
	if c.uploadPrefix == "" {
		c.uploadPrefix = "aggregate"
	}
}

// findS3Node walks the nested aggtest alias tree and returns the first object
// that carries an "s3-access-key" key, flattened to a string map. The aggtest
// alias is shaped aggtest → <group> → <subcommand> → {flags}, with creds under
// e.g. motw.serve.
func findS3Node(raw json.RawMessage) map[string]string {
	var obj map[string]json.RawMessage
	if err := json.Unmarshal(raw, &obj); err != nil {
		return nil
	}
	if _, hasKey := obj["s3-access-key"]; hasKey {
		out := make(map[string]string, len(obj))
		for k, v := range obj {
			var s string
			if json.Unmarshal(v, &s) == nil {
				out[k] = s
			}
		}
		return out
	}
	for _, v := range obj {
		if node := findS3Node(v); node != nil {
			return node
		}
	}
	return nil
}

// --- aggregate path --------------------------------------------------------

// resolveAggregatePath returns the local aggregate index dir if its
// library_index.zst exists; "" otherwise. Honors ACCORDER_AGG_PATH (which may
// point at either the dir or the .zst directly), else the default
// ~/CalibreLibraries/aggregate-build.
func resolveAggregatePath() string {
	candidate := os.Getenv("ACCORDER_AGG_PATH")
	if candidate == "" {
		home, err := os.UserHomeDir()
		if err != nil {
			return ""
		}
		candidate = filepath.Join(home, "CalibreLibraries", "aggregate-build")
	}
	if strings.HasSuffix(candidate, ".zst") {
		if _, err := os.Stat(candidate); err == nil {
			return filepath.Dir(candidate)
		}
		return ""
	}
	if _, err := os.Stat(filepath.Join(candidate, "library_index.zst")); err == nil {
		return candidate
	}
	return ""
}

// --- serve subprocess ------------------------------------------------------

var serveBoundRE = regexp.MustCompile(`HTTP bound on (\S+)`)

// startServe launches `accorder motw serve` as a subprocess against the real
// Wasabi aggregate, parses the bound address from its stderr, polls until GET /
// answers 200, and registers a cleanup that kills the process. Returns the
// serve base URL (with trailing slash).
//
// The serve alias is fixed to "smoketest" so its on-disk VFS blob cache (under
// <accorderConfigDir>/cache/vfs/accorder-serve-smoketest:<bucket>, CacheMode
// full, 10Gi, no age eviction) is REUSED across runs and across both Wasabi
// tiers — once a blob is pulled from S3 it is served from disk on every later
// run, so re-runs incur ~no Wasabi egress.
func startServe(t *testing.T, ctx context.Context, binPath, workDir string, c wasabiCreds) string {
	t.Helper()

	args := []string{
		"motw", "serve", "smoketest",
		"--aggregate-path", workDir,
		"--upload-prefix", c.uploadPrefix,
		"--bucket", c.bucket,
		"--s3-access-key", c.accessKey,
		"--s3-secret-key", c.secretKey,
		"--s3-provider", c.provider,
		"--s3-endpoint", c.endpoint,
		"--listen", "127.0.0.1:0",
		"--poll-interval", "0",
	}
	cmd := exec.CommandContext(ctx, binPath, args...)

	stderr, err := cmd.StderrPipe()
	if err != nil {
		t.Fatalf("serve stderr pipe: %v", err)
	}
	// Discard stdout (none expected; log goes to stderr).
	cmd.Stdout = io.Discard

	if err := cmd.Start(); err != nil {
		t.Fatalf("start serve: %v", err)
	}
	t.Cleanup(func() {
		if cmd.Process != nil {
			_ = cmd.Process.Kill()
		}
		_ = cmd.Wait()
	})

	// Parse stderr for the bound address; forward lines to the test log
	// (binary masks its own secrets — it never logs the keys).
	addrCh := make(chan string, 1)
	go func() {
		sc := bufio.NewScanner(stderr)
		sc.Buffer(make([]byte, 0, 64*1024), 1<<20)
		for sc.Scan() {
			line := sc.Text()
			t.Logf("[serve] %s", line)
			if m := serveBoundRE.FindStringSubmatch(line); m != nil {
				select {
				case addrCh <- m[1]:
				default:
				}
			}
		}
	}()

	var addr string
	select {
	case addr = <-addrCh:
	case <-time.After(120 * time.Second):
		t.Fatal("serve did not report 'HTTP bound on <addr>' within 120s (S3 fetch of aggregate likely failed or is slow)")
	}

	host := addr
	if strings.HasPrefix(host, "[::]") {
		host = "127.0.0.1" + strings.TrimPrefix(host, "[::]")
	}
	serveURL := "http://" + host + "/"

	// Poll GET / until 200 (frontend root route).
	client := &http.Client{Timeout: 5 * time.Second}
	ready := false
	for deadline := time.Now().Add(30 * time.Second); time.Now().Before(deadline); {
		resp, err := client.Get(serveURL)
		if err == nil {
			io.Copy(io.Discard, resp.Body)
			resp.Body.Close()
			if resp.StatusCode == http.StatusOK {
				ready = true
				break
			}
		}
		time.Sleep(200 * time.Millisecond)
	}
	if !ready {
		t.Fatalf("serve bound on %s but GET / never returned 200 within 30s", serveURL)
	}
	return serveURL
}

// resolveServeAggCache returns the persistent serve aggregate cache dir
// (ACCORDER_SMOKE_AGG_CACHE, else <UserCacheDir>/accorder/wasabi-smoke-agg).
// Persistent (not t.TempDir) so the serve's generation-skip avoids re-pulling
// the ~150 MiB index on every run. Shared by both Wasabi tiers.
func resolveServeAggCache(t *testing.T) string {
	t.Helper()
	dir := os.Getenv("ACCORDER_SMOKE_AGG_CACHE")
	if dir == "" {
		base, derr := os.UserCacheDir()
		if derr != nil || base == "" {
			base = os.TempDir()
		}
		dir = filepath.Join(base, "accorder", "wasabi-smoke-agg")
	}
	if err := os.MkdirAll(dir, 0o755); err != nil {
		t.Fatalf("mkdir serve agg cache %s: %v", dir, err)
	}
	return dir
}

// buildAccorderBinaryWasabi compiles the real accorder binary into a temp dir
// and returns its path. Named distinctly from the `integration`-tagged
// buildAccorderBinary (fedlib_local_aggregate_e2e_test.go), which is also
// compiled under the wasabi_e2e tags — sharing the name redeclares it.
func buildAccorderBinaryWasabi(t *testing.T) string {
	t.Helper()
	binPath := filepath.Join(t.TempDir(), "accorder")
	repoRoot, err := filepath.Abs("../..")
	if err != nil {
		t.Fatalf("resolve repo root: %v", err)
	}
	build := exec.Command("go", "build", "-o", binPath, ".")
	build.Dir = repoRoot
	if out, err := build.CombinedOutput(); err != nil {
		t.Fatalf("build accorder: %v\n%s", err, out)
	}
	return binPath
}

// startServeOnAgg builds the binary, starts serve against the persistent agg
// cache + real Wasabi, and returns the serve URL. ctx cancels on cleanup.
func startServeOnAgg(t *testing.T, c wasabiCreds) string {
	t.Helper()
	binPath := buildAccorderBinaryWasabi(t)
	serveWorkDir := resolveServeAggCache(t)
	serveCtx, serveCancel := context.WithCancel(context.Background())
	t.Cleanup(serveCancel)
	return startServe(t, serveCtx, binPath, serveWorkDir, c)
}
