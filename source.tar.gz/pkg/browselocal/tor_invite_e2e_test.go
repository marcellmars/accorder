//go:build integration

package browselocal

import "testing"

// All Tor tests are PLACEHOLDERS — not required for ca-63 done criteria.
// They document the intended Tor e2e coverage for a follow-up workflow.
// Each skips immediately so they never fail or overstate coverage.

func TestStandalone_E2E_TorPublic(t *testing.T) {
	t.Skip("placeholder — Tor e2e not yet implemented")
}

func TestStandalone_E2E_TorInviteOnly(t *testing.T) {
	t.Skip("placeholder — Tor e2e not yet implemented")
}

func TestFedlib_E2E_TorPublic(t *testing.T) {
	t.Skip("placeholder — Tor e2e not yet implemented")
}

func TestFedlib_E2E_TorInviteOnly(t *testing.T) {
	t.Skip("placeholder — Tor e2e not yet implemented")
}
