package browselocal

// Unit tests for the library_name settings field (narrative-setup-defaults
// item 3): default when settings.json absent, round-trip persistence,
// 32-rune clamp.
//

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func newSettingsTestSession(t *testing.T) *librarySession {
	t.Helper()
	return &librarySession{cacheDir: t.TempDir()}
}

func settingsGetMap(t *testing.T, s *librarySession) map[string]any {
	t.Helper()
	res, err := s.handleSettingsGet()
	if err != nil {
		t.Fatalf("handleSettingsGet: %v", err)
	}
	m, ok := res.(map[string]any)
	if !ok {
		t.Fatalf("handleSettingsGet returned %T, want map", res)
	}
	return m
}

func TestSettings_LibraryNameDefaultsWhenAbsent(t *testing.T) {
	s := newSettingsTestSession(t)
	s.loadSettings() // no settings.json in cacheDir

	m := settingsGetMap(t, s)
	if got := m["library_name"]; got != defaultLibraryName {
		t.Errorf("library_name = %v, want %q", got, defaultLibraryName)
	}
}

func TestSettings_LibraryNameRoundTrip(t *testing.T) {
	s := newSettingsTestSession(t)
	s.loadSettings()

	args, _ := json.Marshal(map[string]string{"library_name": "Marcell's Shelf"})
	if _, err := s.handleSettingsSet(args); err != nil {
		t.Fatalf("handleSettingsSet: %v", err)
	}

	// In-memory.
	if got := settingsGetMap(t, s)["library_name"]; got != "Marcell's Shelf" {
		t.Errorf("in-memory library_name = %v, want Marcell's Shelf", got)
	}

	// Persisted: a fresh session over the same cacheDir loads it back.
	s2 := &librarySession{cacheDir: s.cacheDir}
	s2.loadSettings()
	if got := settingsGetMap(t, s2)["library_name"]; got != "Marcell's Shelf" {
		t.Errorf("reloaded library_name = %v, want Marcell's Shelf", got)
	}
}

func TestSettings_LibraryNameClampedTo32Runes(t *testing.T) {
	s := newSettingsTestSession(t)
	s.loadSettings()

	long := strings.Repeat("ä", 40) // multi-byte runes: clamp counts runes, not bytes
	args, _ := json.Marshal(map[string]string{"library_name": long})
	if _, err := s.handleSettingsSet(args); err != nil {
		t.Fatalf("handleSettingsSet: %v", err)
	}
	got, _ := settingsGetMap(t, s)["library_name"].(string)
	if r := []rune(got); len(r) != 32 {
		t.Errorf("clamped length = %d runes, want 32", len(r))
	}
	if !strings.HasPrefix(long, got) {
		t.Errorf("clamped value %q is not a prefix of the input", got)
	}

	// The clamped value is what lands on disk.
	data, err := os.ReadFile(filepath.Join(s.cacheDir, "settings.json"))
	if err != nil {
		t.Fatalf("read settings.json: %v", err)
	}
	var onDisk map[string]string
	if err := json.Unmarshal(data, &onDisk); err != nil {
		t.Fatalf("parse settings.json: %v", err)
	}
	if r := []rune(onDisk["library_name"]); len(r) != 32 {
		t.Errorf("on-disk clamped length = %d runes, want 32", len(r))
	}
}

func TestSettings_EmptyLibraryNameKeepsCurrent(t *testing.T) {
	s := newSettingsTestSession(t)
	s.loadSettings()

	args, _ := json.Marshal(map[string]string{"library_name": "First Name"})
	if _, err := s.handleSettingsSet(args); err != nil {
		t.Fatalf("handleSettingsSet: %v", err)
	}

	// Empty string follows the existing "set only if non-empty" convention.
	args2, _ := json.Marshal(map[string]string{"library_path": "/some/path"})
	if _, err := s.handleSettingsSet(args2); err != nil {
		t.Fatalf("handleSettingsSet: %v", err)
	}
	if got := settingsGetMap(t, s)["library_name"]; got != "First Name" {
		t.Errorf("library_name = %v, want unchanged 'First Name'", got)
	}
}

func TestSettings_EnsureAliasCalledAndPersisted(t *testing.T) {
	s := newSettingsTestSession(t)
	s.loadSettings()
	var gotName, gotPath string
	s.opts.EnsureAlias = func(name, path, librarian string) (string, error) {
		gotName, gotPath = name, path
		return "cli-test", nil
	}

	args, _ := json.Marshal(map[string]string{
		"library_path": "/tmp/lib",
		"library_name": "CLI Test",
	})
	res, err := s.handleSettingsSet(args)
	if err != nil {
		t.Fatalf("handleSettingsSet: %v", err)
	}
	if gotName != "CLI Test" || gotPath != "/tmp/lib" {
		t.Errorf("EnsureAlias called with (%q, %q), want (CLI Test, /tmp/lib)", gotName, gotPath)
	}
	if m := res.(map[string]any); m["alias"] != "cli-test" {
		t.Errorf("response alias = %v, want cli-test", m["alias"])
	}
	if got := settingsGetMap(t, s)["alias"]; got != "cli-test" {
		t.Errorf("settings get alias = %v, want cli-test", got)
	}

	// Persisted: a fresh session over the same cacheDir loads the alias back.
	s2 := &librarySession{cacheDir: s.cacheDir}
	s2.loadSettings()
	if got := settingsGetMap(t, s2)["alias"]; got != "cli-test" {
		t.Errorf("reloaded alias = %v, want cli-test", got)
	}
}

func TestSettings_EnsureAliasLinksDefaultName(t *testing.T) {
	s := newSettingsTestSession(t)
	s.loadSettings()
	var gotName string
	s.opts.EnsureAlias = func(name, path, librarian string) (string, error) {
		gotName = name
		return "my-library", nil
	}

	// The untouched default name links too: saving just a library path is
	// the quickest route to a shareable library.
	args, _ := json.Marshal(map[string]string{"library_path": "/tmp/lib"})
	res, err := s.handleSettingsSet(args)
	if err != nil {
		t.Fatalf("handleSettingsSet: %v", err)
	}
	if gotName != defaultLibraryName {
		t.Errorf("EnsureAlias called with %q, want %q", gotName, defaultLibraryName)
	}
	if m := res.(map[string]any); m["alias"] != "my-library" {
		t.Errorf("response alias = %v, want my-library", m["alias"])
	}
}

func TestSettings_EnsureAliasSkippedWithoutPath(t *testing.T) {
	s := newSettingsTestSession(t)
	s.loadSettings()
	called := false
	s.opts.EnsureAlias = func(name, path, librarian string) (string, error) {
		called = true
		return "x", nil
	}

	// Named library but no path: no linkage.
	args, _ := json.Marshal(map[string]string{"library_name": "CLI Test"})
	if _, err := s.handleSettingsSet(args); err != nil {
		t.Fatalf("handleSettingsSet: %v", err)
	}
	if called {
		t.Error("EnsureAlias called without a library_path")
	}
}

func TestSettings_EnsureAliasErrorSurfacedNotFatal(t *testing.T) {
	s := newSettingsTestSession(t)
	s.loadSettings()
	s.opts.EnsureAlias = func(name, path, librarian string) (string, error) {
		return "cli-test", fmt.Errorf("alias %q already points elsewhere", "cli-test")
	}

	args, _ := json.Marshal(map[string]string{
		"library_path": "/tmp/lib",
		"library_name": "CLI Test",
	})
	res, err := s.handleSettingsSet(args)
	if err != nil {
		t.Fatalf("handleSettingsSet should not fail on alias error: %v", err)
	}
	m := res.(map[string]any)
	if m["saved"] != true {
		t.Error("settings not saved despite alias error")
	}
	if _, ok := m["alias_error"]; !ok {
		t.Error("alias_error missing from response")
	}
	if m["alias"] != nil {
		t.Errorf("alias should not be set on error, got %v", m["alias"])
	}
}

func TestEnsureAliasLink_FiresOnOpenMyLibraryAndBuild(t *testing.T) {
	s := newSettingsTestSession(t)
	s.loadSettings()
	calls := 0
	s.opts.EnsureAlias = func(name, path, librarian string) (string, error) {
		calls++
		return "my-library", nil
	}
	s.mu.Lock()
	s.libraryPath = t.TempDir()
	s.mu.Unlock()

	if _, err := s.handleBuild(); err != nil {
		t.Fatalf("handleBuild: %v", err)
	}
	if calls != 1 {
		t.Errorf("EnsureAlias calls after handleBuild = %d, want 1", calls)
	}

	if _, err := s.handleOpenMyLibrary(); err != nil {
		t.Fatalf("handleOpenMyLibrary: %v", err)
	}
	if calls != 2 {
		t.Errorf("EnsureAlias calls after handleOpenMyLibrary = %d, want 2", calls)
	}

	// Both handlers spawn a fire-and-forget build that writes into libraryPath.
	// Await them before the test returns, or t.TempDir cleanup races the still-
	// running builds ("directory not empty").
	s.buildWg.Wait()

	// The linked alias is visible to settings get and persisted.
	if got := settingsGetMap(t, s)["alias"]; got != "my-library" {
		t.Errorf("alias = %v, want my-library", got)
	}
	s2 := &librarySession{cacheDir: s.cacheDir}
	s2.loadSettings()
	if got := settingsGetMap(t, s2)["alias"]; got != "my-library" {
		t.Errorf("reloaded alias = %v, want my-library", got)
	}
}

// --calibrepath / --librarian arrive via Options; settings/get must surface them
// before the first SETTINGS save so the form pre-fills and the SELECT/QUEUE gate
// (library_path && librarian) passes without a SETTINGS stop.
func TestSettings_OptsSeedGetBeforeFirstSave(t *testing.T) {
	s := newSettingsTestSession(t)
	s.opts = Options{CalibrePath: "/home/w/Calibre/alice", Librarian: "alice"}
	s.loadSettings()

	m := settingsGetMap(t, s)
	if got := m["library_path"]; got != "/home/w/Calibre/alice" {
		t.Errorf("library_path = %v, want the --calibrepath value", got)
	}
	if got := m["librarian"]; got != "alice" {
		t.Errorf("librarian = %v, want the --librarian value", got)
	}
}

// A saved SETTINGS value must win over the CLI seed — the fallback only fills a
// still-empty field, it does not override what the user typed.
func TestSettings_SavedValueWinsOverOptsSeed(t *testing.T) {
	s := newSettingsTestSession(t)
	s.opts = Options{CalibrePath: "/cli/path", Librarian: "cli-name"}
	s.loadSettings()

	args, _ := json.Marshal(map[string]string{
		"library_path": "/typed/path",
		"librarian":    "typed-name",
	})
	if _, err := s.handleSettingsSet(args); err != nil {
		t.Fatalf("handleSettingsSet: %v", err)
	}

	m := settingsGetMap(t, s)
	if got := m["library_path"]; got != "/typed/path" {
		t.Errorf("library_path = %v, want the saved value to win", got)
	}
	if got := m["librarian"]; got != "typed-name" {
		t.Errorf("librarian = %v, want the saved value to win", got)
	}
}
