//go:build integration && wasabi_e2e

package browselocal

import (
	"accorder/pkg/torinvite"
	"bytes"
	"context"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"
	"testing"
	"time"

	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/launcher"
)

// TestFedlib_E2E_WasabiBiopolitics is the LIVE (non-hermetic) browser-level guarantee
// for the federation we ship by hand in scripts/share_browse_matrix.sh: an aggregate
// with biopolitics served from REAL Wasabi S3 (motw/biopolitics) plus the three local
// libraries (MarcellMarsBooks, FooBar, FigureItOut) when present on disk. It exercises
// the access-modes work end to end over clearnet HTTP:
//
//	fedlib members add  (biopolitics S3 + the local libs that exist)
//	fedlib build        (fetch member indexes from Wasabi + disk, upload to a THROWAWAY prefix)
//	fedlib share live --mode offline-private
//	  → GET /                          == 200 (browser plane open)
//	  → GET /static/library_index.zst  == 401 (index plane gated, grants=0)
//	  → grant on the LIVE server, then bearer GET index == 200 (live grants.json reload, NO restart)
//	  → Rod renders biopolitics books from the served aggregate (server-side /search + /books)
//	  → GET /files/biopolitics/<book>/cover.jpg == 200 (VFS proxy streams from S3)
//
// Credentials come from wasabi_full.keys (the operator cred file). Skips cleanly when
// the keys file or biopolitics is absent. Writes only to an isolated `zz-e2e-biopolitics`
// prefix and purges it (before + after) — never the shared motw root.
//
// Run: go test -tags 'integration wasabi_e2e' -run TestFedlib_E2E_WasabiBiopolitics ./pkg/browselocal/
func TestFedlib_E2E_WasabiBiopolitics(t *testing.T) {
	c, ok := resolveWasabiFullKeys(t)
	if !ok {
		t.Skip("biopolitics e2e: wasabi_full.keys not found at repo root — skipping live test")
	}

	const (
		bioID     = "ee0bdf36-ff42-418b-ac3d-bb983fb96f5a"
		bioPrefix = "biopolitics"
		uploadPfx = "zz-e2e-biopolitics"
		fedID     = "zz-e2e-biop-fed"
	)
	if !wasabiPathExists(t, c, "motw/"+bioPrefix+"/static/library_index.zst") {
		t.Skip("biopolitics e2e: motw/biopolitics/static/library_index.zst not on Wasabi — skipping")
	}

	bin := buildAccorderBinary(t) // the integration-tagged builder (cwd build)
	cfgDir := t.TempDir()
	work := t.TempDir()
	env := append(os.Environ(), "XDG_CONFIG_HOME="+cfgDir)
	s3 := []string{
		"--bucket", "motw",
		"--s3-access-key", c.accessKey, "--s3-secret-key", c.secretKey,
		"--s3-provider", "Wasabi", "--s3-endpoint", "s3.wasabisys.com",
	}

	// Isolated upload prefix: purge any stale copy now and on cleanup.
	purge := func() { _ = rclonePurge(c, "motw/"+uploadPfx) }
	purge()
	t.Cleanup(purge)

	runAcc := func(args ...string) string {
		t.Helper()
		cmd := exec.Command(bin, args...)
		cmd.Env = env
		out, err := cmd.CombinedOutput()
		if err != nil {
			t.Fatalf("accorder %s failed: %v\n%s", strings.Join(args, " "), err, out)
		}
		return string(out)
	}

	// --- membership: biopolitics (S3) + the local libs that are present ---
	runAcc("fedlib", "members", "add", fedID, bioID, "--librarian", "biopolitics",
		"--prefix", bioPrefix, "--fedlib-path", work)
	locals := []struct{ uuid, librarian, path, prefix string }{
		{"fac314b6-cfa9-4d2b-99d6-e40a37599cdd", "marcell mars", "/home/w/CalibreLibraries/MarcellMarsBooks", "mmb"},
		{"22222222-0000-4000-8000-000000000002", "foobar", "/home/w/CalibreLibraries/FooBar", "foobar"},
		{"33333333-0000-4000-8000-000000000003", "figureitout", "/home/w/CalibreLibraries/FigureItOut", "fio"},
	}
	localCount := 0
	for _, l := range locals {
		if _, err := os.Stat(filepath.Join(l.path, "static", "library_index.zst")); err != nil {
			t.Logf("biopolitics e2e: local member %s absent — aggregate will omit it", l.prefix)
			continue
		}
		runAcc("fedlib", "members", "add", fedID, l.uuid, "--librarian", l.librarian,
			"--local-path", l.path, "--prefix", l.prefix, "--fedlib-path", work)
		localCount++
	}
	t.Logf("biopolitics e2e: aggregate = biopolitics (S3) + %d local member(s)", localCount)

	// --- build the aggregate (fetch biopolitics from Wasabi) + upload to the throwaway prefix ---
	buildArgs := append([]string{"fedlib", "build", "--output-path", work, "--upload-prefix", uploadPfx}, s3...)
	runAcc(buildArgs...)
	if _, err := os.Stat(filepath.Join(work, "library_index.zst")); err != nil {
		t.Fatalf("biopolitics e2e: aggregate index not produced: %v", err)
	}

	// --- serve over HTTP in offline-private ---
	// Seed the federation descriptor: the serve reads storage identity + mode
	// (descriptor-as-policy) from it via the positional id; only the S3 access/secret
	// keys stay as serve flags.
	runAcc("fedlib", "config", "set", fedID,
		"--bucket", "motw", "--s3-provider", "Wasabi", "--s3-endpoint", "s3.wasabisys.com",
		"--upload-prefix", uploadPfx, "--mode", "offline-private")

	addr := freeLoopbackAddr(t)
	serveCtx, cancel := context.WithCancel(context.Background())
	defer cancel()
	var serveLog bytes.Buffer
	serveArgs := []string{"fedlib", "share", "live", fedID, "--aggregate-path", work,
		"--s3-access-key", c.accessKey, "--s3-secret-key", c.secretKey,
		"--only-http", "--poll-interval", "0", "--listen", addr}
	srv := exec.CommandContext(serveCtx, bin, serveArgs...)
	srv.Env = env
	srv.Stdout = &serveLog
	srv.Stderr = &serveLog
	if err := srv.Start(); err != nil {
		t.Fatalf("start fedlib share live: %v", err)
	}
	defer func() { cancel(); _ = srv.Wait() }()

	base := "http://" + addr + "/"
	waitHTTP(t, base, 90*time.Second) // GET / (SPA root) — open in offline-private

	// --- index plane gated: 401 without a grant ---
	if got := httpStatus(t, base+"static/library_index.zst", ""); got != http.StatusUnauthorized {
		t.Fatalf("offline-private: /static/library_index.zst no-auth -> %d, want 401\nserve log:\n%s", got, serveLog.String())
	}
	t.Log("OK: index plane returns 401 without a grant (offline-private)")

	// --- live grant reload: grant on the RUNNING server, no restart, then 200 ---
	grantOut := runAcc("fedlib", "share", "grant", fedID, "--friend", "testt", "--endpoint", base)
	blob := regexp.MustCompile(`accorder-invite:[A-Za-z0-9_-]+`).FindString(grantOut)
	if blob == "" {
		t.Fatalf("grant did not print an invite blob:\n%s", grantOut)
	}
	inv, err := torinvite.Decode(blob)
	if err != nil || inv.Auth == nil || inv.Auth.Token == "" {
		t.Fatalf("decode invite: %v (auth=%+v)", err, inv.Auth)
	}
	bearer := "Bearer " + inv.Auth.Token
	flipped := false
	for deadline := time.Now().Add(20 * time.Second); time.Now().Before(deadline); {
		if httpStatus(t, base+"static/library_index.zst", bearer) == http.StatusOK {
			flipped = true
			break
		}
		time.Sleep(time.Second)
	}
	if !flipped {
		t.Fatalf("index did not flip to 200 after live grant (no restart) within 20s\nserve log:\n%s", serveLog.String())
	}
	t.Log("OK: index flips 401→200 after grant on the live server (no restart)")

	// --- Rod: the served aggregate renders biopolitics books (server-side /search + /books) ---
	l := launcher.New().Headless(true)
	u, err := l.Launch()
	if err != nil {
		t.Fatalf("launcher: %v", err)
	}
	defer l.Cleanup()
	browser := rod.New().ControlURL(u)
	if err := browser.Connect(); err != nil {
		t.Fatalf("rod.Connect: %v", err)
	}
	defer browser.Close()
	page := browser.MustPage("about:blank")
	defer page.Close()
	watchConsole(t, page)
	// Deterministic + paging-independent: search the SPA for a biopolitics author
	// (Michel Foucault) and assert real book results render. Once local members are
	// mixed in, the default newest page can omit any specific biopolitics title, so
	// we search rather than scan the landing page.
	if err := page.Navigate(base + "#/search/authors/Foucault"); err != nil {
		t.Fatalf("navigate: %v", err)
	}
	page.Timeout(25 * time.Second).MustWait(
		`() => document.querySelectorAll('a[href^="#/book/"]').length + document.querySelectorAll('.cover').length > 0`)
	t.Log("OK: SPA search for a biopolitics author (Foucault) renders book results")

	// --- download a biopolitics book file via the VFS proxy (offline-private leaves /files/ open) ---
	cover := (&url.URL{Path: "/files/biopolitics/Kurt Johansson/Aleksej Gastev_ Proletarian Bard of the Machine Age (1)/cover.jpg"}).String()
	if got := httpStatus(t, strings.TrimRight(base, "/")+cover, ""); got != http.StatusOK {
		t.Fatalf("biopolitics cover via /files/ (VFS proxy) -> %d, want 200", got)
	}
	t.Log("OK: biopolitics book file streamed from S3 via the VFS proxy (200)")
}

// resolveWasabiFullKeys reads the operator cred file (wasabi_full.keys at repo root).
// Format: `access-key= <val>` / `secret-key= <val>` (leading-space tolerated). Bucket /
// provider / endpoint are fixed to the shared motw / Wasabi values.
func resolveWasabiFullKeys(t *testing.T) (wasabiCreds, bool) {
	t.Helper()
	root, err := filepath.Abs("../..")
	if err != nil {
		return wasabiCreds{}, false
	}
	data, err := os.ReadFile(filepath.Join(root, "wasabi_full.keys"))
	if err != nil {
		return wasabiCreds{}, false
	}
	var ak, sk string
	for _, line := range strings.Split(string(data), "\n") {
		line = strings.TrimSpace(line)
		if v, found := strings.CutPrefix(line, "access-key="); found {
			ak = strings.TrimSpace(v)
		}
		if v, found := strings.CutPrefix(line, "secret-key="); found {
			sk = strings.TrimSpace(v)
		}
	}
	if ak == "" || sk == "" {
		return wasabiCreds{}, false
	}
	return wasabiCreds{
		bucket: "motw", accessKey: ak, secretKey: sk,
		provider: "Wasabi", endpoint: "s3.wasabisys.com", source: "wasabi_full.keys",
	}, true
}

// rcloneEnv builds an rclone env with an inline `was:` S3 remote from the creds.
func rcloneEnv(c wasabiCreds) []string {
	return append(os.Environ(),
		"RCLONE_CONFIG_WAS_TYPE=s3",
		"RCLONE_CONFIG_WAS_PROVIDER="+c.provider,
		"RCLONE_CONFIG_WAS_ENDPOINT="+c.endpoint,
		"RCLONE_CONFIG_WAS_ACCESS_KEY_ID="+c.accessKey,
		"RCLONE_CONFIG_WAS_SECRET_ACCESS_KEY="+c.secretKey,
	)
}

// wasabiPathExists reports whether a path under the bucket exists (rclone lsf).
func wasabiPathExists(t *testing.T, c wasabiCreds, bucketPath string) bool {
	t.Helper()
	cmd := exec.Command("rclone", "lsf", "was:"+bucketPath)
	cmd.Env = rcloneEnv(c)
	out, err := cmd.CombinedOutput()
	return err == nil && len(bytes.TrimSpace(out)) > 0
}

// rclonePurge removes a throwaway prefix from the shared bucket (best effort).
func rclonePurge(c wasabiCreds, bucketPath string) error {
	cmd := exec.Command("rclone", "purge", "was:"+bucketPath)
	cmd.Env = rcloneEnv(c)
	return cmd.Run()
}

// httpStatus does a GET with an optional Authorization header and returns the status code.
func httpStatus(t *testing.T, url, authorization string) int {
	t.Helper()
	req, err := http.NewRequest(http.MethodGet, url, nil)
	if err != nil {
		t.Fatalf("new request %s: %v", url, err)
	}
	if authorization != "" {
		req.Header.Set("Authorization", authorization)
	}
	resp, err := (&http.Client{Timeout: 20 * time.Second}).Do(req)
	if err != nil {
		return 0
	}
	defer resp.Body.Close()
	return resp.StatusCode
}
