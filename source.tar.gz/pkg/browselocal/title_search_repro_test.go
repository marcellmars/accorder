//go:build integration

package browselocal

import (
	"accorder/pkg/calibre"
	"context"
	"encoding/json"
	"os"
	"strings"
	"sync"
	"testing"

	"github.com/ysmood/gson"
)

// realIndexPath is the bare path (no .zst suffix — Open appends it)
// pointing at the live MarcellMarsBooks MWSC index built earlier in the
// session. Skip the test if it's not on disk so the suite stays portable.
const realIndexPath = "/tmp/marcell-idx"

// realSessionResponder exposes the real librarySession through tests
// that need it. The recorder fields (mu, calls) exist only because some
// tests inspect the call history via direct field access; if no test
// reads them, they can be dropped.
type realSessionResponder struct {
	session *librarySession
	mu      sync.Mutex
	calls   []rpcCall
}

func (r *realSessionResponder) handle(arg gson.JSON) (interface{}, error) {
	var c rpcCall
	if err := json.Unmarshal([]byte(arg.Str()), &c); err != nil {
		return nil, err
	}
	resp, err := r.session.handleRPC(arg.Str())
	r.mu.Lock()
	r.calls = append(r.calls, c)
	r.mu.Unlock()
	if err != nil {
		return nil, err
	}
	b, _ := json.Marshal(resp)
	return string(b), nil
}

func setupRealSession(t *testing.T) *realSessionResponder {
	t.Helper()
	if _, err := os.Stat(realIndexPath + ".zst"); err != nil {
		t.Skipf("real index %s.zst not on disk; skipping (run `accorder calibre build --index --index-path=%s ...` first)", realIndexPath, realIndexPath)
	}
	ms := &calibre.MotwSearch{IndexPath: realIndexPath}
	opened, err := ms.Open()
	if err != nil {
		t.Fatalf("MotwSearch.Open: %v", err)
	}
	t.Cleanup(func() { opened.Close() })

	tmpCache := t.TempDir()
	typeahead, err := opened.Typeahead(tmpCache)
	if err != nil {
		t.Fatalf("OpenedSearch.Typeahead: %v", err)
	}
	t.Cleanup(func() {
		if typeahead != nil {
			typeahead.Close()
		}
	})

	session := &librarySession{
		opened:    opened,
		typeahead: typeahead,
		cacheDir:  tmpCache,
		opts:      Options{},
	}
	return &realSessionResponder{session: session}
}

// TestAutocomplete_ReturnsFullEntities asserts the new contract:
// field-specific autocomplete returns full entity strings (full author
// names, real titles, tag strings), one entry per unique entity,
// preserving typeahead's rank order.
func TestAutocomplete_ReturnsFullEntities(t *testing.T) {
	resp := setupRealSession(t)

	cases := []struct {
		name   string
		field  string
		prefix string
		expect func(t *testing.T, items []string)
	}{
		{
			name:   "author 'jod' → full author names",
			field:  "author",
			prefix: "jod",
			expect: func(t *testing.T, items []string) {
				if len(items) == 0 {
					t.Fatal("expected ≥1 suggestion")
				}
				found := false
				for _, it := range items {
					if it == "Jodi Dean" {
						found = true
					}
					if !strings.Contains(strings.ToLower(it), "jod") {
						t.Errorf("suggestion %q doesn't contain 'jod'", it)
					}
					if strings.ToLower(it) == it && it != "jodi" {
						t.Errorf("suggestion %q is all-lowercase — looks like a token, not full name", it)
					}
				}
				if !found {
					t.Errorf("expected 'Jodi Dean' (full name) in suggestions; got %v", items)
				}
			},
		},
		{
			name:   "author 'fou' → 'Michel Foucault'",
			field:  "author",
			prefix: "fou",
			expect: func(t *testing.T, items []string) {
				wantContains := "Foucault"
				found := false
				for _, it := range items {
					if strings.Contains(it, wantContains) {
						found = true
						break
					}
				}
				if !found {
					t.Errorf("expected an entry containing %q; got %v", wantContains, items)
				}
			},
		},
		{
			name:   "title 'com' → real titles (not sort)",
			field:  "title",
			prefix: "com",
			expect: func(t *testing.T, items []string) {
				if len(items) == 0 {
					t.Fatal("expected ≥1 title suggestion for 'com'")
				}
				for _, it := range items {
					if !strings.Contains(strings.ToLower(it), "com") {
						t.Errorf("title %q does not contain 'com'", it)
					}
					if strings.HasSuffix(strings.ToLower(it), ", the") || strings.HasSuffix(strings.ToLower(it), ", a") || strings.HasSuffix(strings.ToLower(it), ", an") {
						t.Errorf("title %q looks like a TitleSort form; should be Book.Title", it)
					}
				}
			},
		},
		{
			name:   "deduplication — no exact duplicates",
			field:  "author",
			prefix: "j",
			expect: func(t *testing.T, items []string) {
				seen := map[string]bool{}
				for _, it := range items {
					if seen[it] {
						t.Errorf("duplicate entry %q in suggestions", it)
					}
					seen[it] = true
				}
			},
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			args, _ := json.Marshal(map[string]any{"field": tc.field, "prefix": tc.prefix, "limit": 10})
			out, err := resp.session.handleAutocomplete(args)
			if err != nil {
				t.Fatalf("handleAutocomplete: %v", err)
			}
			b, _ := json.Marshal(out)
			var env struct {
				Items []string `json:"_items"`
			}
			_ = json.Unmarshal(b, &env)
			t.Logf("autocomplete(field=%s, prefix=%s) → %d entities: %v", tc.field, tc.prefix, len(env.Items), env.Items)
			tc.expect(t, env.Items)
		})
	}
}

// TestHandleSearch_MultiTokenNarrowsResults — the post-filter must
// narrow "sean dockray" to books authored by Sean Dockray specifically
// (1 book), not all books matching the "sean" token (11 books).
func TestHandleSearch_MultiTokenNarrowsResults(t *testing.T) {
	resp := setupRealSession(t)

	cases := []struct {
		field   string
		query   string
		wantMin int
		wantMax int
	}{
		{"author", "sean", 5, 50},        // wide token-match — many "Sean Anyone"
		{"author", "sean dockray", 1, 1}, // narrow to one author
		{"author", "Sean Dockray", 1, 1}, // case-insensitive
		{"author", "jodi", 11, 11},       // single token — unchanged

		// "jodi dean" should narrow to books whose author entry contains
		// "jodi dean". May be 10 or 11 depending on whether a co-author
		// happens to be named "jodi <other>".
		{"author", "jodi dean", 10, 11},
		{"title", "comrade", 2, 3}, // single token title

		// Real autocomplete passes the full title — substring filter ok.
		{"title", "Comrade: An Essay on Political Belonging", 1, 1},
	}
	for _, tc := range cases {
		args, _ := json.Marshal(map[string]any{"field": tc.field, "query": tc.query, "offset": 0, "limit": 48})
		out, err := resp.session.handleSearch(args)
		if err != nil {
			t.Errorf("handleSearch(%s, %q): %v", tc.field, tc.query, err)
			continue
		}
		envelope := out.(map[string]any)
		items, _ := envelope["_items"].([]*calibre.Book)
		t.Logf("search(%s, %q) → %d books", tc.field, tc.query, len(items))
		if len(items) < tc.wantMin || len(items) > tc.wantMax {
			t.Errorf("  expected [%d..%d], got %d", tc.wantMin, tc.wantMax, len(items))
		}
	}
}

// TestRepro_SeanDockrayPhraseSearch — the user-reported behavior:
// "if `sea` is completed to any `sean ____` it shows all `sean`
// results not reduced to `sean dockra` for example". Test whether
// Search(author, "sean dockray", ModePrefix) narrows the result to
// books by Sean Dockray, or widens to all books with author tokens
// matching "sean" (i.e. token-level matching ignoring "dockray").
func TestRepro_SeanDockrayPhraseSearch(t *testing.T) {
	resp := setupRealSession(t)
	opts := calibre.SearchOptions{Limit: 48, Offset: 0, SortMode: calibre.SortRelevance}
	for _, q := range []string{"sean", "sean dockray", "Sean Dockray", "dockray"} {
		query := calibre.SearchQuery{Field: calibre.FieldAuthor, Text: q, Mode: calibre.ModePrefix}
		books, stats, err := resp.session.opened.Search(context.Background(), query, opts)
		if err != nil {
			t.Errorf("Search(author, %q): %v", q, err)
			continue
		}
		authors := map[string]int{}
		for _, b := range books {
			for _, a := range b.Authors {
				authors[a]++
			}
		}
		t.Logf("Search(author, %q) → %d books, total=%d, distinct author names: %d", q, len(books), stats.BooksMatched, len(authors))
		if len(authors) <= 8 {
			for a, c := range authors {
				t.Logf("    %q: %d books", a, c)
			}
		}
	}
}

// TestHandleSearch_PaginationOffsetReturnsDistinctBooks verifies that
// changing offset actually pages through the result set — i.e. that
// page 1 books != page 2 books. If they're the same, the UI's keyed
// `{#each books as book (book._id)}` would not re-render anything
// because svelte sees the keys as unchanged.
func TestHandleSearch_PaginationOffsetReturnsDistinctBooks(t *testing.T) {
	resp := setupRealSession(t)

	getIDs := func(field, query string, offset, limit int) []string {
		args, _ := json.Marshal(map[string]any{"field": field, "query": query, "offset": offset, "limit": limit})
		out, err := resp.session.handleSearch(args)
		if err != nil {
			t.Fatalf("handleSearch(field=%s offset=%d): %v", field, offset, err)
		}
		envelope := out.(map[string]any)
		books := envelope["_items"].([]*calibre.Book)
		ids := []string{}
		for _, b := range books {
			ids = append(ids, b.Id)
		}
		return ids
	}

	cases := []struct{ field, query string }{
		{"author", "john"},
		{"tag", "rulingclassstudies"},
	}
	for _, tc := range cases {
		t.Run(tc.field+"/"+tc.query, func(t *testing.T) {
			page1 := getIDs(tc.field, tc.query, 0, 48)
			page2 := getIDs(tc.field, tc.query, 48, 48)
			t.Logf("page1 (offset=0): %d books, first id=%v last id=%v", len(page1), firstOrEmpty(page1), lastOrEmpty(page1))
			t.Logf("page2 (offset=48): %d books, first id=%v last id=%v", len(page2), firstOrEmpty(page2), lastOrEmpty(page2))
			set1 := map[string]bool{}
			for _, id := range page1 {
				set1[id] = true
			}
			overlap := 0
			for _, id := range page2 {
				if set1[id] {
					overlap++
				}
			}
			if overlap > 0 {
				t.Errorf("page1 ∩ page2 has %d overlapping books — pagination is returning the same hits at different offsets", overlap)
			}
		})
	}
}

func firstOrEmpty(s []string) string {
	if len(s) == 0 {
		return ""
	}
	return s[0]
}
func lastOrEmpty(s []string) string {
	if len(s) == 0 {
		return ""
	}
	return s[len(s)-1]
}

// TestHandleSearch_PaginationLinks verifies that when total hits exceed
// a single page, the envelope includes `_links.prev` and `_links.next`
// pointing at the right `/search/<field>/<query>/page/<N>` href so
// NavBar.svelte can render the "<< prev" / "next >>" links.
// Reproduces the user-reported missing-pagination bug.
func TestHandleSearch_PaginationLinks(t *testing.T) {
	resp := setupRealSession(t)

	cases := []struct {
		name     string
		query    string
		field    string
		offset   int
		limit    int
		wantPrev bool
		wantNext bool
	}{
		{
			name:     "page 1 of many — next only",
			query:    "rulingclassstudies",
			field:    "tag",
			offset:   0,
			limit:    48,
			wantPrev: false,
			wantNext: true, // 101 hits → page 2 exists
		},
		{
			name:     "page 2 of 3 — both prev and next",
			query:    "rulingclassstudies",
			field:    "tag",
			offset:   48,
			limit:    48,
			wantPrev: true,
			wantNext: true, // 101 hits, page 2 covers 48-95, page 3 (96-100) exists
		},
		{
			name:     "page 3 of 3 — prev only",
			query:    "rulingclassstudies",
			field:    "tag",
			offset:   96,
			limit:    48,
			wantPrev: true,
			wantNext: false,
		},
		{
			name:     "single-page result — neither",
			query:    "jodi",
			field:    "author",
			offset:   0,
			limit:    48,
			wantPrev: false,
			wantNext: false, // 11 hits fit in one page
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			args, _ := json.Marshal(map[string]any{"field": tc.field, "query": tc.query, "offset": tc.offset, "limit": tc.limit})
			out, err := resp.session.handleSearch(args)
			if err != nil {
				t.Fatalf("handleSearch: %v", err)
			}
			b, _ := json.Marshal(out)
			var env struct {
				Items []map[string]any `json:"_items"`
				Meta  struct {
					Total int `json:"total"`
				} `json:"_meta"`
				Links map[string]map[string]string `json:"_links"`
			}
			if err := json.Unmarshal(b, &env); err != nil {
				t.Fatalf("parse: %v", err)
			}
			t.Logf("query=%q offset=%d → total=%d, links=%v", tc.query, tc.offset, env.Meta.Total, env.Links)

			_, hasPrev := env.Links["prev"]
			_, hasNext := env.Links["next"]
			if hasPrev != tc.wantPrev {
				t.Errorf("prev link present=%v, want %v (env.Links=%v)", hasPrev, tc.wantPrev, env.Links)
			}
			if hasNext != tc.wantNext {
				t.Errorf("next link present=%v, want %v (env.Links=%v)", hasNext, tc.wantNext, env.Links)
			}
			if hasNext {
				href := env.Links["next"]["href"]
				if href == "" {
					t.Error("next.href is empty")
				}

				// App.svelte renders <a href=\"#{navbarLinks.next.href}\"> so href
				// must start with "/" to land in the hash router.
				if href != "" && href[0] != '/' {
					t.Errorf("next.href = %q, want leading slash so hash becomes '#/search/...'", href)
				}
			}
		})
	}
}

// TestRepro_FullEntitySearch asserts what Search returns when given a
// multi-word query that matches the full indexed entity ("jodi dean"
// vs "jodi"). The new autocomplete returns full entities, so this is
// the query shape the search will receive when the user clicks a
// suggestion.
func TestRepro_FullEntitySearch(t *testing.T) {
	resp := setupRealSession(t)
	opts := calibre.SearchOptions{Limit: 48, Offset: 0, SortMode: calibre.SortRelevance}
	for _, q := range []string{"jodi", "jodi dean", "Jodi Dean", "dean"} {
		query := calibre.SearchQuery{Field: calibre.FieldAuthor, Text: q, Mode: calibre.ModePrefix}
		books, stats, err := resp.session.opened.Search(context.Background(), query, opts)
		if err != nil {
			t.Errorf("Search(author, %q): %v", q, err)
			continue
		}
		t.Logf("Search(author, %q, ModePrefix) → %d books, total=%d", q, len(books), stats.BooksMatched)
	}
	for _, q := range []string{"comrade", "Comrade", "comrade: an essay", "comrade essay"} {
		query := calibre.SearchQuery{Field: calibre.FieldTitle, Text: q, Mode: calibre.ModePrefix}
		books, stats, err := resp.session.opened.Search(context.Background(), query, opts)
		if err != nil {
			t.Errorf("Search(title, %q): %v", q, err)
			continue
		}
		t.Logf("Search(title, %q, ModePrefix) → %d books, total=%d", q, len(books), stats.BooksMatched)
	}
}

// TestRepro_BookPointerAliasing checks whether OpenedSearch.Search
// returns 11 distinct Books with distinct IDs, or 11 pointers aliased
// to one. The fallback loop's `seen[bk.Id]` dedupe accidentally blocks
// 10 of 11 books — suggests aliasing or duplicate IDs in the result.
func TestRepro_BookPointerAliasing(t *testing.T) {
	resp := setupRealSession(t)
	q := calibre.SearchQuery{Field: calibre.FieldAuthor, Text: "jodi", Mode: calibre.ModePrefix}
	opts := calibre.SearchOptions{Limit: 48, Offset: 0, SortMode: calibre.SortRelevance}
	books, _, err := resp.session.opened.Search(context.Background(), q, opts)
	if err != nil {
		t.Fatal(err)
	}
	if len(books) < 2 {
		t.Skip("need ≥ 2 books for aliasing check")
	}
	ids := map[string]int{}
	titles := map[string]int{}
	ptrs := map[*calibre.Book]int{}
	for i, bk := range books {
		ids[bk.Id]++
		titles[bk.Title]++
		ptrs[bk]++
		t.Logf("[%d] ptr=%p id=%q title=%q", i, bk, bk.Id, bk.Title)
	}
	t.Logf("distinct ids: %d, distinct titles: %d, distinct pointers: %d (total: %d)",
		len(ids), len(titles), len(ptrs), len(books))
	if len(ids) < len(books) {
		t.Errorf("BUG: %d books returned but only %d distinct Ids", len(books), len(ids))
	}
}

// TestRepro_FallbackMimicLoop replicates the fallback logic from
// handleSearch directly in a test, to bisect whether the lost results
// are in OpenedSearch.Search or in handleSearch's surrounding code.
func TestRepro_FallbackMimicLoop(t *testing.T) {
	resp := setupRealSession(t)
	opts := calibre.SearchOptions{Limit: 48, Offset: 0, SortMode: calibre.SortRelevance}

	qTitle := calibre.SearchQuery{Field: calibre.FieldTitle, Text: "jodi", Mode: calibre.ModePrefix}
	books, _, _ := resp.session.opened.Search(context.Background(), qTitle, opts)
	t.Logf("primary title:  %d books", len(books))

	seen := map[string]bool{}
	for _, f := range []calibre.SearchField{calibre.FieldTitle, calibre.FieldAuthor, calibre.FieldTag} {
		if f == calibre.FieldTitle {
			continue
		}
		fq := calibre.SearchQuery{Field: f, Text: "jodi", Mode: calibre.ModePrefix}
		more, _, _ := resp.session.opened.Search(context.Background(), fq, opts)
		t.Logf("fallback %-7s: %d books returned from Search", f, len(more))
		added := 0
		for _, bk := range more {
			if !seen[bk.Id] {
				seen[bk.Id] = true
				books = append(books, bk)
				added++
			}
		}
		t.Logf("  %d new (not seen) added; books total now=%d", added, len(books))
	}
	t.Logf("final: %d books after fallback", len(books))
}

// TestRepro_HandleSearchFallbackCount directly inspects how many books
// handleSearch returns after fallback for the title=jodi case.
func TestRepro_HandleSearchFallbackCount(t *testing.T) {
	resp := setupRealSession(t)
	args, _ := json.Marshal(map[string]any{"field": "title", "query": "jodi", "offset": 0, "limit": 48})
	out, err := resp.session.handleSearch(args)
	if err != nil {
		t.Fatal(err)
	}
	envelope := out.(map[string]any)
	items := envelope["_items"]
	switch v := items.(type) {
	case []*calibre.Book:
		t.Logf("envelope _items is []*Book with %d entries", len(v))
		for i, bk := range v {
			t.Logf("  [%d] _id=%s title=%q", i, bk.Id, bk.Title)
		}
	case []any:
		t.Logf("envelope _items is []any with %d entries", len(v))
	default:
		t.Logf("envelope _items is %T: %v", items, items)
	}
}

// TestRepro_TitleSearchFallback asserts the cross-field fallback: when
// title-mode search for "jodi" returns no title prefix matches, the
// handler now retries against author/tag fields and surfaces those
// books instead. The envelope carries `_meta.fallback_field` so the UI
// can show "found via authors" or similar messaging.
func TestRepro_TitleSearchFallback(t *testing.T) {
	resp := setupRealSession(t)
	args, _ := json.Marshal(map[string]any{"field": "title", "query": "jodi", "offset": 0, "limit": 48})
	out, err := resp.session.handleSearch(args)
	if err != nil {
		t.Fatalf("handleSearch returned error: %v", err)
	}
	b, _ := json.Marshal(out)
	t.Logf("search(field=title, query=jodi) envelope (with fallback): %s", string(b))

	var env struct {
		Items []map[string]any `json:"_items"`
		Meta  struct {
			Total         int    `json:"total"`
			Page          int    `json:"page"`
			MaxResults    int    `json:"max_results"`
			FallbackField string `json:"fallback_field"`
		} `json:"_meta"`
		Links struct {
			Self struct {
				Href string `json:"href"`
			} `json:"self"`
		} `json:"_links"`
	}
	if err := json.Unmarshal(b, &env); err != nil {
		t.Fatalf("parse envelope: %v", err)
	}
	if env.Links.Self.Href != "/search/title/jodi" {
		t.Errorf("_links.self.href = %q, want %q", env.Links.Self.Href, "/search/title/jodi")
	}
	if env.Meta.MaxResults != 48 {
		t.Errorf("_meta.max_results = %d, want 48", env.Meta.MaxResults)
	}
	if len(env.Items) == 0 {
		t.Errorf("expected fallback to surface author-jodi books; got 0 items")
	}
	if env.Meta.FallbackField == "" {
		t.Errorf("expected _meta.fallback_field to be set when fallback fires; got empty")
	}
	t.Logf("fallback brought in %d books via field=%s", len(env.Items), env.Meta.FallbackField)
}

// TestRepro_RepeatedOpenedSearch — call OpenedSearch.Search several times
// to check whether internal state leaks across calls (suspected cause of
// the fallback returning 1 book instead of 11).
func TestRepro_RepeatedOpenedSearch(t *testing.T) {
	resp := setupRealSession(t)
	opts := calibre.SearchOptions{Limit: 48, Offset: 0, SortMode: calibre.SortRelevance}

	// Same query twice — should be deterministic.
	q := calibre.SearchQuery{Field: calibre.FieldAuthor, Text: "jodi", Mode: calibre.ModePrefix}
	books1, stats1, err1 := resp.session.opened.Search(context.Background(), q, opts)
	if err1 != nil {
		t.Fatalf("first search: %v", err1)
	}
	books2, stats2, err2 := resp.session.opened.Search(context.Background(), q, opts)
	if err2 != nil {
		t.Fatalf("second search: %v", err2)
	}
	t.Logf("first  Search(author, jodi) → %d books, stats.BooksMatched=%d", len(books1), stats1.BooksMatched)
	t.Logf("second Search(author, jodi) → %d books, stats.BooksMatched=%d", len(books2), stats2.BooksMatched)

	// Different field then same — checks for cross-field leakage.
	qt := calibre.SearchQuery{Field: calibre.FieldTitle, Text: "jodi", Mode: calibre.ModePrefix}
	booksT, statsT, _ := resp.session.opened.Search(context.Background(), qt, opts)
	booksA, statsA, _ := resp.session.opened.Search(context.Background(), q, opts)
	t.Logf("after Search(title, jodi) → %d books, total=%d", len(booksT), statsT.BooksMatched)
	t.Logf("then  Search(author, jodi) → %d books, total=%d", len(booksA), statsA.BooksMatched)

	if len(books1) != len(books2) {
		t.Errorf("non-deterministic: %d vs %d for identical queries", len(books1), len(books2))
	}
	if len(booksA) != len(books1) {
		t.Errorf("cross-field leak: after title-search the same author-search returned %d (was %d)", len(booksA), len(books1))
	}
}

// TestRepro_AuthorSearchHits sanity-checks that an author search the
// user-mode "authors/jodi" goes through, returning at least one book.
func TestRepro_AuthorSearchHits(t *testing.T) {
	resp := setupRealSession(t)
	args, _ := json.Marshal(map[string]any{"field": "author", "query": "jodi", "offset": 0, "limit": 48})
	out, err := resp.session.handleSearch(args)
	if err != nil {
		t.Fatalf("handleSearch: %v", err)
	}
	b, _ := json.Marshal(out)
	var env struct {
		Items []map[string]any `json:"_items"`
		Meta  struct{ Total int }
	}
	_ = json.Unmarshal(b, &env)
	t.Logf("search(field=author, query=jodi) → %d hits", len(env.Items))
	if len(env.Items) == 0 {
		t.Errorf("expected at least one author-jodi hit on the live index; got 0 — typeahead inconsistency?")
	}
}

// TestRepro_TitleAutocompleteVsSearch verifies the user-reported claim:
// "autocomplete suggests `jodi` for title prefix `jod`, but searching
// `titles/jodi` returns nothing".
//

// This is a Go-side test (no rod) — directly exercises the typeahead and
// search code paths to determine whether the bug is in the index, the
// handlers, or the UI bridging.
func TestRepro_TitleAutocompleteVsSearch(t *testing.T) {
	resp := setupRealSession(t)

	// 1. Autocomplete: field=title, prefix=jod
	autoArgs, _ := json.Marshal(map[string]any{"field": "title", "prefix": "jod", "limit": 12})
	autoOut, err := resp.session.handleAutocomplete(autoArgs)
	if err != nil {
		t.Fatalf("handleAutocomplete: %v", err)
	}
	autoBytes, _ := json.Marshal(autoOut)
	var autoResp struct {
		Items []string `json:"_items"`
	}
	_ = json.Unmarshal(autoBytes, &autoResp)
	t.Logf("autocomplete(field=title, prefix=jod) → %d suggestions: %v", len(autoResp.Items), autoResp.Items)

	if len(autoResp.Items) == 0 {
		t.Log("typeahead returned zero title suggestions for prefix 'jod' — probing adjacent paths:")
		for _, field := range []string{"", "author", "tag"} {
			args, _ := json.Marshal(map[string]any{"field": field, "prefix": "jod", "limit": 12})
			out, err := resp.session.handleAutocomplete(args)
			if err != nil {
				t.Logf("  field=%q error: %v", field, err)
				continue
			}
			b, _ := json.Marshal(out)
			var r struct {
				Items []string `json:"_items"`
			}
			_ = json.Unmarshal(b, &r)
			t.Logf("  field=%q → %d suggestions: %v", field, len(r.Items), r.Items)
		}
		return
	}

	// 2. For each suggested term, run a real search and check the result.
	for _, term := range autoResp.Items {
		searchArgs, _ := json.Marshal(map[string]any{"field": "title", "query": term, "offset": 0, "limit": 48})
		searchOut, sErr := resp.session.handleSearch(searchArgs)
		if sErr != nil {
			t.Errorf("handleSearch(title, %q): %v", term, sErr)
			continue
		}
		envelope, _ := json.Marshal(searchOut)
		var sResp struct {
			Items []map[string]any `json:"_items"`
			Meta  struct {
				Total int `json:"total"`
			} `json:"_meta"`
		}
		_ = json.Unmarshal(envelope, &sResp)
		t.Logf("search(field=title, query=%q) → %d hits (meta.total=%d)", term, len(sResp.Items), sResp.Meta.Total)

		if len(sResp.Items) == 0 {
			t.Errorf("DIVERGENCE: typeahead suggested title term %q but search(title=%q) returned zero hits", term, term)
			t.Logf("  this is the bug the user is hitting — autocomplete promises results that search can't deliver")
		} else {

			// Sanity: at least one result's title actually starts with the prefix.
			matchedPrefix := false
			matchedTerm := false
			for _, b := range sResp.Items {
				title, _ := b["title"].(string)
				ltitle := strings.ToLower(title)
				if strings.HasPrefix(ltitle, "jod") {
					matchedPrefix = true
				}
				if strings.Contains(ltitle, strings.ToLower(term)) {
					matchedTerm = true
				}
			}
			t.Logf("  matchedPrefix=%v matchedTerm=%v (first hit title=%q)", matchedPrefix, matchedTerm, sResp.Items[0]["title"])
		}
	}
}
