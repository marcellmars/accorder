//go:build integration

package browselocal

import (
	"accorder/pkg/calibre"
	"context"
	"fmt"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/launcher"
)

// TestFedlib_E2E_LocalAggregate is the browser-level guarantee for the
// fedlib LOCAL-disk aggregate serve (WF1 storage engine + membership):
//
//	fedlib members add --local-path  (x2, two synthetic on-disk libraries)
//	fedlib build  --output-path      (NO S3 — "all members are local")
//	fedlib share live --only-http    (serves the local aggregate over HTTP)
//	→ Rod drives a real headless Chromium against the LIVE HTTP server
//	  (the served SPA fetches /search, /books, /files/ over HTTP — not the
//	  backend_rpc desktop bridge), asserting:
//	    - the covers grid renders books from BOTH local members,
//	    - the fingerprint mosaics paint from the index (zero /files/ cover fetch),
//	    - a /files/{prefix}/.../cover.jpg request is served from local disk (200).
//
// Unlike the other harness tests (in-process librarySession over backend_rpc),
// this exercises the full real CLI + the all-local serve dispatch end to end.
func TestFedlib_E2E_LocalAggregate(t *testing.T) {
	bin := buildAccorderBinary(t)

	// --- two synthetic on-disk libraries, distinct UUIDs ---
	aliceUUID := "11111111-1111-4111-8111-111111111111"
	bobUUID := "22222222-2222-4222-8222-222222222222"
	aliceDir := makeLocalLibrary(t, "Alice", aliceUUID, []*calibre.Book{
		fpBook("a-1", "Cybernetics and Society", "Norbert Wiener", "Alice", aliceUUID, "Sbb9l4QI"),
		fpBook("a-2", "The Society of the Spectacle", "Guy Debord", "Alice", aliceUUID, "/////78F"),
	})
	bobDir := makeLocalLibrary(t, "Bob", bobUUID, []*calibre.Book{
		fpBook("b-1", "Simians, Cyborgs, and Women", "Donna Haraway", "Bob", bobUUID, "JEmSJFkL"),
	})

	out := t.TempDir()
	run := func(args ...string) {
		t.Helper()
		cmd := exec.Command(bin, args...)
		if outb, err := cmd.CombinedOutput(); err != nil {
			t.Fatalf("accorder %s failed: %v\n%s", strings.Join(args, " "), err, outb)
		}
	}

	// --- membership: two local members, no creds, no invite (one name: the
	// first add write-throughs --fedlib-path into the "localfed" descriptor,
	// which the serve below resolves from its positional) ---
	run("fedlib", "members", "add", "localfed", aliceUUID, "--local-path", aliceDir, "--prefix", "alice", "--fedlib-path", out)
	run("fedlib", "members", "add", "localfed", bobUUID, "--local-path", bobDir, "--prefix", "bob", "--fedlib-path", out)

	// --- build the aggregate from local disk (NO S3) ---
	buildOut, err := exec.Command(bin, "fedlib", "build", "--output-path", out).CombinedOutput()
	if err != nil {
		t.Fatalf("fedlib build failed: %v\n%s", err, buildOut)
	}
	if !strings.Contains(string(buildOut), "all members are local; skipping upload") {
		t.Fatalf("expected local-only build (no upload); got:\n%s", buildOut)
	}
	if _, err := os.Stat(filepath.Join(out, "library_index.zst")); err != nil {
		t.Fatalf("aggregate index not produced: %v", err)
	}

	// --- serve the local aggregate over HTTP ---
	addr := freeLoopbackAddr(t)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	srv := exec.CommandContext(ctx, bin, "fedlib", "share", "live", "localfed",
		"--aggregate-path", out, "--only-http", "--mode", "public", "--listen", addr)
	if err := srv.Start(); err != nil {
		t.Fatalf("start fedlib share live: %v", err)
	}
	defer func() { cancel(); _ = srv.Wait() }()
	base := "http://" + addr
	waitHTTP(t, base+"/_GENERATION", 20*time.Second)

	// --- Rod against the LIVE server ---
	l := launcher.New().Headless(true)
	u, err := l.Launch()
	if err != nil {
		t.Fatalf("launcher: %v", err)
	}
	defer l.Cleanup()
	browser := rod.New().ControlURL(u)
	if err := browser.Connect(); err != nil {
		t.Fatalf("rod.Connect: %v", err)
	}
	defer browser.Close()
	page := browser.MustPage("about:blank")
	defer page.Close()
	watchConsole(t, page)

	if err := page.Navigate(base + "/#/?"); err != nil {
		t.Fatalf("navigate: %v", err)
	}

	// Books from BOTH local members render (served by the all-local aggregate).
	for _, want := range []string{"Cybernetics and Society", "Simians, Cyborgs, and Women"} {
		page.Timeout(20 * time.Second).MustWait(fmt.Sprintf(
			`() => ((document.body && document.body.innerText) || "").includes(%q)`, want))
	}
	t.Log("OK: served local aggregate renders books from both members")

	// The covers grid paints fingerprint mosaics from the index (no /files/ fetch).
	page.Timeout(15 * time.Second).MustWait(`() => {
		if ([...document.querySelectorAll('.cover')].some(d => (d.getAttribute('style')||'').includes('data:image/svg+xml'))) return true;
		const el = [...document.querySelectorAll('div')].find(d => d.children.length === 0 &&
			/^show (covers|list)$/.test((d.textContent||'').replace(/\s+/g,' ').trim()));
		if (el) el.click();
		return false;
	}`)
	mosaics := page.MustEval(`() => [...document.querySelectorAll('.cover')]
		.filter(d => (d.getAttribute('style')||'').includes('data:image/svg+xml')).length`).Int()
	if mosaics < 3 {
		t.Fatalf("covers grid painted %d fingerprint mosaics, want >= 3 (one per book)", mosaics)
	}
	t.Logf("OK: %d fingerprint mosaics painted from the index (zero-egress grid)", mosaics)

	// /files/{prefix}/.../cover.jpg is served from the local member's disk (200).
	coverURL := base + "/files/alice/Norbert%20Wiener/Cybernetics%20(1)/cover.jpg"
	resp, err := http.Get(coverURL)
	if err != nil {
		t.Fatalf("GET cover: %v", err)
	}
	resp.Body.Close()
	if resp.StatusCode != 200 {
		t.Fatalf("/files/ cover from local disk -> HTTP %d, want 200", resp.StatusCode)
	}
	t.Log("OK: /files/{prefix}/<cover> served from local member disk (200)")
}

// fpBook builds a fingerprinted book whose cover_url + dir_path resolve under a
// local member's /files/{prefix}/ route on disk.
func fpBook(id, title, author, librarian, uuid, fp string) *calibre.Book {
	dir := author + "/" + strings.SplitN(title, " ", 2)[0] + " (1)"
	return &calibre.Book{
		Id:               id,
		LibraryUUID:      uuid,
		Title:            title,
		Authors:          []string{author},
		Tags:             []string{"x"},
		Formats:          []*calibre.File{{Format: "EPUB", DirectoryPath: dir, Name: "book.epub", Size: 1}},
		BaseURL:          "/files/local",
		CoverUrl:         dir + "/cover.jpg",
		LibraryUrl:       "/files/local/",
		CoverFingerprint: fp,
		Librarian:        librarian,
		LastModified:     "2024-12-03T00:00:00+00:00",
	}
}

// makeLocalLibrary writes a synthetic accorder-served library directory:
// static/library_index.zst (built from books) + a cover.jpg on disk per book
// (so the served /files/{prefix}/<cover_url> route has a real file).
func makeLocalLibrary(t *testing.T, librarian, uuid string, books []*calibre.Book) string {
	t.Helper()
	dir := t.TempDir()
	buildFixtureIndex(t, dir, books) // writes dir/static/library_index.zst
	for _, b := range books {
		if b.CoverUrl == "" {
			continue
		}
		p := filepath.Join(dir, filepath.FromSlash(b.CoverUrl))
		if err := os.MkdirAll(filepath.Dir(p), 0755); err != nil {
			t.Fatal(err)
		}
		// minimal JPEG header bytes — enough for an HTTP 200 from http.FileServer.
		if err := os.WriteFile(p, []byte{0xFF, 0xD8, 0xFF, 0xD9}, 0644); err != nil {
			t.Fatal(err)
		}
	}
	return dir
}

// buildAccorderBinary builds the accorder CLI once into a temp path.
func buildAccorderBinary(t *testing.T) string {
	t.Helper()
	bin := filepath.Join(t.TempDir(), "accorder")
	cmd := exec.Command("go", "build", "-o", bin, "accorder")
	if out, err := cmd.CombinedOutput(); err != nil {
		t.Fatalf("build accorder: %v\n%s", err, out)
	}
	return bin
}

func freeLoopbackAddr(t *testing.T) string {
	t.Helper()
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	addr := ln.Addr().String()
	_ = ln.Close()
	return addr
}

func waitHTTP(t *testing.T, url string, d time.Duration) {
	t.Helper()
	deadline := time.Now().Add(d)
	for time.Now().Before(deadline) {
		if resp, err := http.Get(url); err == nil {
			resp.Body.Close()
			if resp.StatusCode == 200 {
				return
			}
		}
		time.Sleep(200 * time.Millisecond)
	}
	t.Fatalf("server did not serve %s within %s", url, d)
}
