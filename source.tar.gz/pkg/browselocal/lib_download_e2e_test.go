//go:build integration && wasabi_e2e

package browselocal

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

// TestLibDownload_Wasabi verifies the inverse of `lib upload`: it pulls content
// DOWN from motw/<prefix>/ — selectively (`--files metadata.db`, NOT the book
// blobs) and in full — and refuses a bare bucket. Round-trips against live Wasabi
// on a throwaway prefix (purged before+after).
//
// Run: go test -tags 'integration wasabi_e2e' -run TestLibDownload_Wasabi ./pkg/browselocal/
func TestLibDownload_Wasabi(t *testing.T) {
	c, ok := resolveWasabiFullKeys(t)
	if !ok {
		t.Skip("lib download e2e: wasabi_full.keys not found at repo root — skipping")
	}
	const pfx = "zz-e2e-download"

	bin := buildAccorderBinary(t)
	env := append(os.Environ(), "XDG_CONFIG_HOME="+t.TempDir())
	purge := func() { _ = rclonePurge(c, "motw/"+pfx) }
	purge()
	t.Cleanup(purge)

	// --- seed motw/<pfx>/ with a metadata.db + a book blob (via rclone) ---
	const dbContent = "SQLite format 3\x00 (pretend library DB)"
	src := t.TempDir()
	dlWrite(t, filepath.Join(src, "metadata.db"), []byte(dbContent))
	dlWrite(t, filepath.Join(src, "Author", "Title (1)", "book.epub"), []byte("epub blob bytes"))
	seed := exec.Command("rclone", "copy", src, "was:motw/"+pfx)
	seed.Env = rcloneEnv(c)
	if out, err := seed.CombinedOutput(); err != nil {
		t.Fatalf("seed via rclone: %v\n%s", err, out)
	}

	s3 := []string{
		"--bucket", "motw/" + pfx,
		"--s3-access-key", c.accessKey, "--s3-secret-key", c.secretKey,
		"--s3-provider", "Wasabi", "--s3-endpoint", "s3.wasabisys.com",
	}
	runAcc := func(args ...string) string {
		t.Helper()
		cmd := exec.Command(bin, args...)
		cmd.Env = env
		out, err := cmd.CombinedOutput()
		if err != nil {
			t.Fatalf("accorder %s failed: %v\n%s", strings.Join(args, " "), err, out)
		}
		return string(out)
	}

	// --- 1. selective: --files metadata.db pulls ONLY the DB ---
	dst := t.TempDir()
	runAcc(append([]string{"lib", "download", "dl", "--calibrepath", dst, "--files", "metadata.db"}, s3...)...)
	if b, err := os.ReadFile(filepath.Join(dst, "metadata.db")); err != nil || string(b) != dbContent {
		t.Fatalf("selective: metadata.db missing or mismatched: err=%v", err)
	}
	if _, err := os.Stat(filepath.Join(dst, "Author")); err == nil {
		t.Fatalf("selective: book blob was downloaded but should have been excluded")
	}
	t.Log("OK: lib download --files metadata.db pulled only the DB (no book blobs)")

	// --- 2. full copy: no --files pulls the whole prefix ---
	dst2 := t.TempDir()
	runAcc(append([]string{"lib", "download", "dl2", "--calibrepath", dst2}, s3...)...)
	if _, err := os.Stat(filepath.Join(dst2, "metadata.db")); err != nil {
		t.Fatalf("full: metadata.db missing: %v", err)
	}
	if _, err := os.Stat(filepath.Join(dst2, "Author", "Title (1)", "book.epub")); err != nil {
		t.Fatalf("full: book blob missing: %v", err)
	}
	t.Log("OK: lib download (no --files) pulled the whole prefix")

	// --- 3. bare-bucket guard ---
	bad := exec.Command(bin, "lib", "download", "dl3", "--calibrepath", t.TempDir(),
		"--bucket", "motw", "--s3-access-key", c.accessKey, "--s3-secret-key", c.secretKey,
		"--s3-provider", "Wasabi", "--s3-endpoint", "s3.wasabisys.com")
	bad.Env = env
	out, err := bad.CombinedOutput()
	if err == nil || !strings.Contains(string(out), "bare bucket") {
		t.Fatalf("bare-bucket guard did not fire: err=%v out=%s", err, out)
	}
	t.Log("OK: lib download refuses a bare bucket")
}

func dlWrite(t *testing.T, path string, b []byte) {
	t.Helper()
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(path, b, 0o644); err != nil {
		t.Fatal(err)
	}
}
