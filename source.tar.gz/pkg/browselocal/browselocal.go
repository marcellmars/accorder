package browselocal

import (
	"accorder/pkg/calibre"
	"accorder/pkg/rclonexfer"
	"accorder/pkg/torinvite"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/launcher"
	"github.com/go-rod/rod/lib/launcher/flags"
	"github.com/go-rod/rod/lib/proto"
	uuid "github.com/satori/go.uuid"
	"github.com/ysmood/gson"
)

type Options struct {
	CalibrePath       string
	Librarian         string
	DownloadDir       string
	Invite            *torinvite.InviteV2
	SocksAddr         string
	FilesRoot         string
	RedeemURL         string
	RemoteFilesPrefix string
	EnsureAlias       func(libraryName, libraryPath, librarian string) (string, error)

	HTTPClient *http.Client
	BaseURL    string
}

func Run(cacheDir string, opts Options) error {
	indexPath := filepath.Join(cacheDir, "static", "library_index")
	indexZst := indexPath + ".zst"

	var session *librarySession
	if _, err := os.Stat(indexZst); err == nil {
		ms := &calibre.MotwSearch{IndexPath: indexPath}
		opened, err := ms.Open()
		if err != nil {
			log.Printf("browselocal: failed to open search index: %v (search will be unavailable)", err)
		} else {
			defer opened.Close()

			typeahead, err := opened.Typeahead(cacheDir)
			if err != nil {
				log.Printf("browselocal: failed to open typeahead: %v (autocomplete will be unavailable)", err)
			}
			if typeahead != nil {
				defer typeahead.Close()
			}

			session = &librarySession{
				opened:         opened,
				typeahead:      typeahead,
				cacheDir:       cacheDir,
				opts:           opts,
				selection:      make(map[string]bool),
				selectionBooks: make(map[string]*calibre.Book),
				downloadCh:     make(chan *queueItem, 256),
				stagedPages:    make(map[proto.TargetTargetID]bool),
			}
		}
	}

	newLauncher := func(noSandbox bool) *launcher.Launcher {
		l := launcher.New().
			Headless(false).
			Set(flags.Flag("disable-extensions")).
			Set(flags.Flag("disable-plugins")).
			Set(flags.Flag("disable-sync")).
			Set(flags.Flag("disable-translate")).
			Set(flags.Flag("no-first-run")).
			Set(flags.Flag("no-default-browser-check")).
			Set(flags.Flag("disable-background-networking")).
			Set(flags.Flag("disable-default-apps")).
			Set(flags.Flag("disable-component-update")).
			Set(flags.Flag("disable-domain-reliability")).
			Set(flags.Flag("disable-features"), "OptimizationHints,MediaRouter,PostQuantumKyber").
			Set(flags.Flag("safebrowsing-disable-auto-update")).
			Set(flags.Flag("disable-quic")).
			Set(flags.Flag("disable-ipv6")).
			Set(flags.Flag("webrtc-ip-handling-policy"), "disable_non_proxied_udp").
			Set(flags.Flag("metrics-recording-only")).
			Set(flags.Flag("no-pings")).
			Set(flags.Flag("start-maximized"))
		if opts.SocksAddr != "" {
			l = l.
				Set(flags.Flag("proxy-server"), "socks5://"+opts.SocksAddr).
				Set(flags.Flag("proxy-bypass-list"), "<-loopback>")
		}
		if runtime.GOOS == "linux" && os.Getenv("WAYLAND_DISPLAY") != "" {
			l = l.Set(flags.Flag("ozone-platform"), "wayland")
		}
		if runtime.GOOS == "windows" {
			l = l.Leakless(false)
		}
		if noSandbox {
			l = l.Set(flags.Flag("no-sandbox"))
		}
		return l
	}

	url, err := newLauncher(false).Launch()
	if err != nil && runtime.GOOS == "linux" && isSandboxLaunchErr(err) {
		log.Printf("browselocal: chromium sandbox unavailable, retrying with --no-sandbox")
		url, err = newLauncher(true).Launch()
	}
	if err != nil {
		return fmt.Errorf("browselocal: launch chromium: %w", err)
	}

	browser := rod.New().ControlURL(url)
	if err := browser.Connect(); err != nil {
		return fmt.Errorf("browselocal: connect to browser: %w", err)
	}
	defer browser.Close()

	if session != nil {
		session.browser = browser
		session.loadSettings()
	}

	page, err := browser.Page(proto.TargetCreateTarget{})
	if err != nil {
		return fmt.Errorf("browselocal: create page: %w", err)
	}

	if err := (proto.EmulationClearDeviceMetricsOverride{}).Call(page); err != nil {
		log.Printf("browselocal: clear device metrics override: %v (UI may be cramped)", err)
	}

	if session != nil {
		page.MustExpose("backend_rpc", func(arg gson.JSON) (interface{}, error) {
			return session.handleRPC(arg.Str())
		})
	}

	if opts.RedeemURL != "" {
		if err := page.Navigate(opts.RedeemURL); err != nil {
			return fmt.Errorf("browselocal: redeem token: %w", err)
		}
		page.MustWaitStable()
		log.Printf("browselocal: redeemed auth token, cookie set")
	}

	htmlPath := filepath.Join(cacheDir, "BROWSE_LIBRARY.html")
	if err := page.Navigate("file://" + htmlPath + "#/?"); err != nil {
		return fmt.Errorf("browselocal: navigate: %w", err)
	}

	log.Println("browselocal: library opened in browser — close the browser window to exit")

	mainTarget := page.TargetID
	wait := browser.EachEvent(func(e *proto.TargetTargetDestroyed) bool {
		return e.TargetID == mainTarget
	})
	wait()

	return nil
}

type librarySession struct {
	opened    *calibre.OpenedSearch
	typeahead calibre.TypeaheadIndex
	cacheDir  string
	opts      Options

	mu               sync.Mutex
	queue            []*queueItem
	selection        map[string]bool
	selectionBooks   map[string]*calibre.Book
	downloadCh       chan *queueItem
	workerOnce       sync.Once
	importMu         sync.Mutex
	buildStatus      string // "", "building", "built", "build_failed"
	buildError       string
	bytesTransferred int64

	libraryPath   string
	librarianName string
	libraryName   string
	aliasName     string

	browser     *rod.Browser
	stagedPages map[proto.TargetTargetID]bool

	// buildWg tracks the fire-and-forget builds spawned by handleBuild /
	// handleOpenMyLibrary so a caller (or a test) can await them; without it
	// an in-flight build keeps writing generation dirs into the library path
	// after the request returns.
	buildWg sync.WaitGroup
}

const (
	statusQueued      = "queued"
	statusDownloading = "downloading"
	statusDone        = "done"
	statusFailed      = "failed"
	statusPaused      = "paused"
	statusCanceled    = "canceled"
)

const (
	buildBuilding = "building"
	buildBuilt    = "built"
	buildFailed   = "build_failed"
)

type queueItem struct {
	BookID       string        `json:"book_id"`
	DirPath      string        `json:"dir_path"`
	Prefix       string        `json:"prefix,omitempty"`
	Title        string        `json:"title"`
	LastModified string        `json:"last_modified,omitempty"`
	FileSize     int64         `json:"file_size"`
	Progress     int           `json:"progress"`
	Status       string        `json:"status"` // "queued", "downloading", "done", "failed", "paused", "canceled"
	Error        string        `json:"error,omitempty"`
	JobID        int64         `json:"job_id,omitempty"`
	Rec          *calibre.Book `json:"-"`
}

func isSandboxLaunchErr(err error) bool {
	if err == nil {
		return false
	}
	msg := err.Error()
	return strings.Contains(msg, "No usable sandbox") ||
		strings.Contains(msg, "zygote_host_impl_linux") ||
		strings.Contains(msg, "Operation not permitted") && strings.Contains(msg, "namespace")
}

func queueItemToMap(item *queueItem) map[string]any {
	m := map[string]any{
		"_id":         item.BookID,
		"book_id":     item.BookID,
		"title":       item.Title,
		"dir_path":    item.DirPath,
		"status":      item.Status,
		"progress":    item.Progress,
		"error":       item.Error,
		"library_url": "",
	}
	if item.Rec != nil {
		m["authors"] = item.Rec.Authors
		m["pubdate"] = item.Rec.Pubdate
		m["last_modified"] = item.Rec.LastModified
		m["tags"] = item.Rec.Tags
		m["formats"] = item.Rec.Formats
		m["cover_url"] = item.Rec.CoverUrl
		m["abstract"] = item.Rec.Abstract
		m["publisher"] = item.Rec.Publisher
		m["librarian"] = item.Rec.Librarian
	}
	return m
}

func (item *queueItem) localPath(dlFolder string) string {
	if item.Prefix != "" {
		return filepath.Join(dlFolder, item.Prefix, item.DirPath)
	}
	return filepath.Join(dlFolder, item.DirPath)
}

type rpcRequest struct {
	Service string          `json:"service"`
	Method  string          `json:"method"`
	Args    json.RawMessage `json:"args"`
}

func (s *librarySession) handleRPC(payload string) (any, error) {
	var req rpcRequest
	if err := json.Unmarshal([]byte(payload), &req); err != nil {
		return nil, fmt.Errorf("backend_rpc: parse request: %w", err)
	}

	switch req.Service {
	case "session":
		return s.handleSession(req.Method, req.Args)
	case "library":
		return s.handleLibrary(req.Method, req.Args)
	default:
		return nil, fmt.Errorf("backend_rpc: unknown service %q", req.Service)
	}
}

func (s *librarySession) handleSession(method string, args json.RawMessage) (any, error) {
	switch method {
	case "mode":
		return "browse", nil
	case "lastCalibrePath":
		return s.opts.CalibrePath, nil
	case "reachability":
		return map[string]string{"status": "connected"}, nil
	case "capabilities":
		ifc := uint32(3)
		if s.opened != nil {
			mf := s.opened.Manifest()
			if mf.IndexedFieldCount >= 4 {
				ifc = mf.IndexedFieldCount
			}
		}
		return map[string]uint32{"indexedFieldCount": ifc}, nil
	default:
		return nil, fmt.Errorf("session: unknown method %q", method)
	}
}

func (s *librarySession) handleLibrary(method string, args json.RawMessage) (any, error) {
	switch method {
	case "search":
		return s.handleSearch(args)
	case "autocomplete":
		return s.handleAutocomplete(args)
	case "books":
		return s.handleBooks(args)
	case "book":
		return s.handleBook(args)
	case "librarians":
		return s.handleLibrarians()
	case "queue":
		return s.handleQueue()
	case "toggleQueue":
		return s.handleToggleQueue(args)
	case "clearQueue":
		return s.handleClearQueue()
	case "fetchBatch":
		return s.handleFetchBatch()
	case "selection/toggle":
		return s.handleSelectionToggle(args)
	case "selection/count":
		return s.handleSelectionCount()
	case "selection/selectAll":
		return s.handleSelectionSelectAll(args)
	case "selection/clear":
		return s.handleSelectionClear()
	case "selection/enqueue":
		return s.handleSelectionEnqueue()
	case "batchStatus":
		return s.handleBatchStatus()
	case "download/item":
		return s.handleDownloadItem(args)
	case "download/pause":
		return s.handleDownloadPause(args)
	case "download/resume":
		return s.handleDownloadResume(args)
	case "download/cancel":
		return s.handleDownloadCancel(args)
	case "queue/remove":
		return s.handleQueueRemove(args)
	case "queue/clearNotDownloading":
		return s.handleQueueClearNotDownloading()
	case "batch/pause":
		return s.handleBatchPause()
	case "batch/resume":
		return s.handleBatchResume()
	case "settings/get":
		return s.handleSettingsGet()
	case "settings/set":
		return s.handleSettingsSet(args)
	case "openBuilt":
		return s.handleOpenBuilt()
	case "build":
		return s.handleBuild()
	case "buildStatus":
		return s.handleBuildStatus()
	case "openMyLibrary":
		return s.handleOpenMyLibrary()
	case "calibre/import":
		return s.handleCalibreImport(args)
	default:
		return nil, fmt.Errorf("library: unknown method %q", method)
	}
}

func (s *librarySession) handleSearch(args json.RawMessage) (any, error) {
	if s.opened == nil {
		return nil, fmt.Errorf("search index not available")
	}
	var req struct {
		Query  string `json:"query"`
		Field  string `json:"field"`
		Offset int    `json:"offset"`
		Limit  int    `json:"limit"`
	}
	if err := json.Unmarshal(args, &req); err != nil {
		return nil, err
	}
	var books []*calibre.Book
	var stats calibre.SearchStats
	fallbackUsed := ""

	if strings.EqualFold(strings.TrimSpace(req.Field), "librarian") {
		all, lerr := s.opened.BooksByLibrarian(context.Background(), req.Query)
		if lerr != nil {
			return nil, lerr
		}
		sort.Sort(sort.Reverse(calibre.CalibreBooksByLastModified(all)))
		books = all
		stats.BooksMatched = len(all)
	} else {
		field, err := calibre.ParseSearchField(req.Field)
		if err != nil {
			return nil, err
		}
		q := calibre.SearchQuery{Field: field, Text: req.Query, Mode: calibre.ModeExact}
		opts := calibre.SearchOptions{Limit: req.Limit, Offset: req.Offset, SortMode: calibre.SortRelevance}
		var serr error
		books, stats, serr = s.opened.Search(context.Background(), q, opts)
		if serr != nil {
			return nil, serr
		}

		if len(books) == 0 && req.Query != "" && field != calibre.FieldAll {
			seen := map[string]bool{}
			for _, f := range []calibre.SearchField{calibre.FieldTitle, calibre.FieldAuthor, calibre.FieldTag} {
				if f == field {
					continue
				}
				fq := calibre.SearchQuery{Field: f, Text: req.Query, Mode: calibre.ModeExact}
				more, moreStats, mErr := s.opened.Search(context.Background(), fq, opts)
				if mErr != nil {
					continue
				}
				for _, bk := range more {
					if !seen[bk.Id] {
						seen[bk.Id] = true
						books = append(books, bk)
						if fallbackUsed == "" {
							fallbackUsed = string(f)
						}
					}
				}
				stats.BooksMatched += moreStats.BooksMatched
			}
		}
	}

	limit := req.Limit
	if limit == 0 {
		limit = 48
	}
	page := req.Offset/limit + 1

	total := stats.BooksMatched
	if req.Offset > 0 && req.Offset < len(books) {
		books = books[req.Offset:]
	} else if req.Offset >= len(books) {
		books = nil
	}
	if len(books) > limit {
		books = books[:limit]
	}
	meta := map[string]any{
		"total":       total,
		"page":        page,
		"max_results": limit,
	}
	if fallbackUsed != "" {
		meta["fallback_field"] = fallbackUsed
	}

	base := "/search/" + req.Field + "/" + req.Query
	pageURL := func(p int) string {
		if p <= 1 {
			return base
		}
		return base + "/page/" + strconv.Itoa(p)
	}
	links := map[string]any{
		"self": map[string]any{"href": pageURL(page)},
	}
	totalPages := (total + limit - 1) / limit
	if page > 1 {
		links["prev"] = map[string]any{"href": pageURL(page - 1)}
		links["first"] = map[string]any{"href": pageURL(1)}
	}
	if page < totalPages {
		links["next"] = map[string]any{"href": pageURL(page + 1)}
		links["last"] = map[string]any{"href": pageURL(totalPages)}
	}
	return map[string]any{
		"_items": books,
		"_meta":  meta,
		"_links": links,
	}, nil
}

func (s *librarySession) handleAutocomplete(args json.RawMessage) (any, error) {
	if s.typeahead == nil {
		return map[string]any{"_items": []string{}}, nil
	}
	var req struct {
		Field  string `json:"field"`
		Prefix string `json:"prefix"`
		Limit  int    `json:"limit"`
	}
	if err := json.Unmarshal(args, &req); err != nil {
		return nil, err
	}
	limit := req.Limit
	if limit == 0 {
		limit = 10
	}
	prefix := strings.ToLower(strings.TrimSpace(req.Prefix))

	var field calibre.SearchField
	if req.Field != "" {
		var ferr error
		if field, ferr = calibre.ParseSearchField(req.Field); ferr != nil {
			return nil, ferr
		}
	}

	entities, err := calibre.SuggestEntities(s.typeahead, field, prefix, limit)
	if err != nil {
		return nil, err
	}
	if entities == nil {
		entities = []string{}
	}
	return map[string]any{"_items": entities}, nil
}

func (s *librarySession) handleLibrarians() (any, error) {
	if s.opened == nil {
		return map[string]any{"_items": []string{}}, nil
	}
	libs, err := s.opened.Librarians(context.Background())
	if err != nil {
		return nil, err
	}
	if libs == nil {
		libs = []string{}
	}
	return map[string]any{"_items": libs}, nil
}

func (s *librarySession) handleBooks(args json.RawMessage) (any, error) {
	if s.opened == nil {
		return nil, fmt.Errorf("search index not available")
	}
	var req struct {
		Offset int `json:"offset"`
		Limit  int `json:"limit"`
	}
	if err := json.Unmarshal(args, &req); err != nil {
		return nil, err
	}
	limit := req.Limit
	if limit <= 0 {
		limit = 48
	}
	offset := req.Offset
	if offset < 0 {
		offset = 0
	}
	books, total, err := s.opened.PageBooks(context.Background(), offset, limit)
	if err != nil {
		return nil, err
	}
	page := offset/limit + 1
	totalPages := (total + limit - 1) / limit
	pageHref := func(p int) string {
		if p <= 1 {
			return "/books"
		}
		return "/books/page/" + strconv.Itoa(p)
	}
	links := map[string]any{"self": map[string]any{"href": "books"}}
	if page > 1 {
		links["prev"] = map[string]any{"href": pageHref(page - 1)}
		links["first"] = map[string]any{"href": pageHref(1)}
	}
	if page < totalPages {
		links["next"] = map[string]any{"href": pageHref(page + 1)}
		links["last"] = map[string]any{"href": pageHref(totalPages)}
	}
	return map[string]any{
		"_items": books,
		"_meta":  map[string]any{"total": total, "page": page, "max_results": limit},
		"_links": links,
	}, nil
}

func (s *librarySession) handleBook(args json.RawMessage) (any, error) {
	if s.opened == nil {
		return nil, fmt.Errorf("search index not available")
	}
	var req struct {
		ID string `json:"id"`
	}
	if err := json.Unmarshal(args, &req); err != nil {
		return nil, err
	}
	if req.ID == "" {
		return nil, fmt.Errorf("missing book id")
	}
	return s.opened.LookupByID(context.Background(), req.ID)
}

func (s *librarySession) handleQueue() (any, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return map[string]any{"_items": s.queue}, nil
}

func (s *librarySession) handleToggleQueue(args json.RawMessage) (any, error) {
	var req struct {
		BookID  string `json:"book_id"`
		DirPath string `json:"dir_path"`
		BaseURL string `json:"base_url"`
	}
	if err := json.Unmarshal(args, &req); err != nil {
		return nil, err
	}

	prefix := ""
	if strings.HasPrefix(req.BaseURL, "/files/") {
		prefix = strings.TrimPrefix(req.BaseURL, "/")
	}

	s.mu.Lock()
	defer s.mu.Unlock()

	for i, item := range s.queue {
		if item.BookID == req.BookID && item.DirPath == req.DirPath {
			s.queue = append(s.queue[:i], s.queue[i+1:]...)
			return map[string]any{"action": "removed", "queue_size": len(s.queue)}, nil
		}
	}
	s.queue = append(s.queue, &queueItem{
		BookID:  req.BookID,
		DirPath: req.DirPath,
		Prefix:  prefix,
		Status:  statusQueued,
	})
	return map[string]any{"action": "added", "queue_size": len(s.queue)}, nil
}

func (s *librarySession) handleClearQueue() (any, error) {
	dlDir := s.getDownloadDir()
	s.mu.Lock()
	for _, it := range s.queue {
		if it.Status == statusDownloading {
			stopJobAsync(it.JobID)
		}
		go removeDownloadFiles(dlDir, it)
	}
	s.queue = nil
	s.mu.Unlock()
	return map[string]any{"cleared": true}, nil
}

const downloadConcurrency = 8

func (s *librarySession) ensureWorker() {
	s.workerOnce.Do(func() {
		for i := 0; i < downloadConcurrency; i++ {
			go s.downloadWorker()
		}
	})
}

func stopJobAsync(jobID int64) {
	if jobID > 0 {
		go func() { _ = rclonexfer.StopJob(jobID) }()
	}
}

func (s *librarySession) handleFetchBatch() (any, error) {
	s.mu.Lock()
	var queued int
	for _, item := range s.queue {
		if item.Status == statusQueued {
			queued++
			s.downloadCh <- item
		}
	}
	s.mu.Unlock()

	s.ensureWorker()

	return map[string]any{"started": true, "count": queued}, nil
}

func (s *librarySession) selectedIDsLocked() []string {
	ids := make([]string, 0, len(s.selection))
	for id := range s.selection {
		ids = append(ids, id)
	}
	return ids
}

func (s *librarySession) handleSelectionToggle(args json.RawMessage) (any, error) {
	var req struct {
		BookID string        `json:"book_id"`
		Book   *calibre.Book `json:"book"`
	}
	if err := json.Unmarshal(args, &req); err != nil {
		return nil, err
	}

	s.mu.Lock()
	defer s.mu.Unlock()

	if s.selection[req.BookID] {
		delete(s.selection, req.BookID)
		delete(s.selectionBooks, req.BookID)
	} else {
		s.selection[req.BookID] = true
		if req.Book != nil {
			s.selectionBooks[req.BookID] = req.Book
		}
	}

	ids := s.selectedIDsLocked()
	return map[string]any{
		"selected":     s.selection[req.BookID],
		"count":        len(s.selection),
		"selected_ids": ids,
	}, nil
}

func (s *librarySession) handleSelectionCount() (any, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return map[string]any{"count": len(s.selection)}, nil
}

func (s *librarySession) handleSelectionSelectAll(args json.RawMessage) (any, error) {
	var req struct {
		Field string `json:"field"`
		Query string `json:"query"`
	}
	if err := json.Unmarshal(args, &req); err != nil {
		return nil, err
	}

	if s.opened == nil {
		return nil, fmt.Errorf("search index not available")
	}

	const selectAllLimit = 120
	gated := func(matched int) (any, error) {
		s.mu.Lock()
		defer s.mu.Unlock()
		ids := s.selectedIDsLocked()
		return map[string]any{
			"gated":        true,
			"limit":        selectAllLimit,
			"matched":      matched,
			"count":        len(s.selection),
			"selected_ids": ids,
		}, nil
	}

	var books []*calibre.Book
	if strings.TrimSpace(req.Query) == "" {
		all, total, err := s.opened.PageBooks(context.Background(), 0, selectAllLimit+1)
		if err != nil {
			return nil, fmt.Errorf("selectAll: page: %w", err)
		}
		if total > selectAllLimit {
			return gated(total)
		}
		books = all
	} else {
		field, err := calibre.ParseSearchField(req.Field)
		if err != nil {
			return nil, err
		}
		q := calibre.SearchQuery{Field: field, Text: req.Query, Mode: calibre.ModeExact}
		opts := calibre.SearchOptions{Limit: selectAllLimit + 1, Offset: 0}
		found, _, err := s.opened.Search(context.Background(), q, opts)
		if err != nil {
			return nil, err
		}
		if len(found) > selectAllLimit {
			return gated(len(found))
		}
		books = found
	}

	s.mu.Lock()
	defer s.mu.Unlock()

	allSelected := true
	for _, bk := range books {
		if !s.selection[bk.Id] {
			allSelected = false
			break
		}
	}

	toggledOn := !allSelected
	for _, bk := range books {
		if toggledOn {
			s.selection[bk.Id] = true
			s.selectionBooks[bk.Id] = bk
		} else {
			delete(s.selection, bk.Id)
			delete(s.selectionBooks, bk.Id)
		}
	}

	ids := s.selectedIDsLocked()
	return map[string]any{
		"count":        len(s.selection),
		"toggled_on":   toggledOn,
		"selected_ids": ids,
	}, nil
}

func (s *librarySession) handleSelectionClear() (any, error) {
	s.mu.Lock()
	s.selection = make(map[string]bool)
	s.selectionBooks = make(map[string]*calibre.Book)
	s.mu.Unlock()
	return map[string]any{"cleared": true}, nil
}

func (s *librarySession) handleSelectionEnqueue() (any, error) {
	s.mu.Lock()
	ids := s.selectedIDsLocked()
	resolved := make(map[string]*calibre.Book, len(ids))
	var missing []string
	for _, id := range ids {
		if bk := s.selectionBooks[id]; bk != nil {
			resolved[id] = bk
		} else {
			missing = append(missing, id)
		}
	}
	s.mu.Unlock()

	if len(missing) > 0 && s.opened != nil {
		ctx := context.Background()
		for _, id := range missing {
			if bk, err := s.opened.LookupByID(ctx, id); err == nil && bk != nil {
				resolved[id] = bk
			}
		}
	}

	books := make([]*calibre.Book, 0, len(resolved))
	for _, bk := range resolved {
		books = append(books, bk)
	}
	sort.SliceStable(books, func(i, j int) bool {
		return books[i].LastModified > books[j].LastModified
	})

	s.mu.Lock()
	defer s.mu.Unlock()

	before := len(s.queue)
	existing := make(map[string]*queueItem, len(s.queue))
	seenKey := make(map[string]bool, len(s.queue))
	for _, it := range s.queue {
		existing[it.BookID] = it
		if it.Rec != nil {
			seenKey[bookDedupKey(it.Rec.Title, it.Rec.Authors)] = true
		} else {
			seenKey[bookDedupKey(it.Title, nil)] = true
		}
	}

	deduped := 0
	for _, bk := range books {
		if existing[bk.Id] == nil {
			key := bookDedupKey(bk.Title, bk.Authors)
			if seenKey[key] {
				deduped++
				continue
			}
			seenKey[key] = true
		}
		dirPath := ""
		var fileSize int64
		if len(bk.Formats) > 0 {
			dirPath = bk.Formats[0].DirectoryPath
			for _, f := range bk.Formats {
				fileSize += f.Size
			}
		}
		prefix := ""
		if strings.HasPrefix(bk.BaseURL, "/files/") {
			prefix = strings.TrimPrefix(bk.BaseURL, "/")
		}

		if it := existing[bk.Id]; it != nil {
			it.DirPath = dirPath
			it.Prefix = prefix
			it.Title = bk.Title
			it.FileSize = fileSize
			it.LastModified = bk.LastModified
			it.Rec = bk
		} else {
			ni := &queueItem{
				BookID:       bk.Id,
				DirPath:      dirPath,
				Prefix:       prefix,
				Title:        bk.Title,
				FileSize:     fileSize,
				LastModified: bk.LastModified,
				Status:       statusQueued,
				Rec:          bk,
			}
			s.queue = append(s.queue, ni)
			existing[bk.Id] = ni
		}
	}

	s.selection = make(map[string]bool)
	s.selectionBooks = make(map[string]*calibre.Book)

	if len(s.queue) != before {
		s.buildStatus = ""
		s.buildError = ""
	}

	items := make([]map[string]any, 0, len(s.queue))
	for _, it := range s.queue {
		items = append(items, queueItemToMap(it))
	}
	return map[string]any{
		"count":        len(s.queue),
		"items":        items,
		"selected_ids": []string{},
		"deduped":      deduped,
	}, nil
}

func bookDedupKey(title string, authors []string) string {
	norm := func(s string) string { return strings.ToLower(strings.TrimSpace(s)) }
	parts := make([]string, len(authors))
	for i, a := range authors {
		parts[i] = norm(a)
	}
	return norm(title) + "\x00" + strings.Join(parts, "&")
}

func (s *librarySession) handleBatchStatus() (any, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	items := make([]map[string]any, len(s.queue))
	var downloading, done, failed int
	for i, item := range s.queue {
		items[i] = queueItemToMap(item)
		switch item.Status {
		case statusDownloading:
			downloading++
		case statusDone:
			done++
		case statusFailed:
			failed++
		}
	}

	return map[string]any{
		"items":        items,
		"downloading":  downloading,
		"done":         done,
		"failed":       failed,
		"total":        len(s.queue),
		"build_status": s.buildStatus,
		"build_error":  s.buildError,
	}, nil
}

func (s *librarySession) downloadWorker() {
	for item := range s.downloadCh {
		s.mu.Lock()
		if item.Status != statusQueued {
			s.mu.Unlock()
			continue
		}
		item.Status = statusDownloading
		item.Progress = 0
		s.mu.Unlock()

		dlFolder := s.getDownloadDir()
		dstFs := item.localPath(dlFolder)
		if err := os.MkdirAll(dstFs, 0755); err != nil {
			s.mu.Lock()
			item.Status = statusFailed
			item.Error = err.Error()
			s.mu.Unlock()
			continue
		}

		if s.opts.FilesRoot == "" {
			s.downloadRemoteFiles(item, dstFs)
			continue
		}

		srcFs := filepath.Join(s.opts.FilesRoot, item.DirPath)
		jobID, err := rclonexfer.SyncCopySizeOnly(srcFs, dstFs)
		if err != nil {
			s.mu.Lock()
			item.Status = statusFailed
			item.Error = err.Error()
			s.mu.Unlock()
			continue
		}

		s.mu.Lock()
		item.JobID = jobID
		s.mu.Unlock()

		for stats := range rclonexfer.PollProgress(jobID) {
			s.mu.Lock()
			if item.Status == statusPaused || item.Status == statusCanceled {
				s.mu.Unlock()
				break
			}
			if stats.TotalBytes > 0 {
				item.Progress = int(float64(stats.Bytes) / float64(stats.TotalBytes) * 100)
			}
			if stats.Finished {
				if stats.Success {
					item.Status = statusDone
					item.Progress = 100
					s.bytesTransferred += stats.Bytes
				} else {
					item.Status = statusFailed
					item.Error = "transfer failed"
				}
				s.mu.Unlock()
				break
			}
			s.mu.Unlock()
		}
	}
}

type httpStatusError struct {
	code int
	url  string
}

func (e *httpStatusError) Error() string {
	return fmt.Sprintf("GET %s: status %d", e.url, e.code)
}

func httpDownloadFile(client *http.Client, url, dstPath string) (int64, error) {
	resp, err := client.Get(url)
	if err != nil {
		return 0, fmt.Errorf("GET %s: %w", url, err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return 0, &httpStatusError{code: resp.StatusCode, url: url}
	}

	dir := filepath.Dir(dstPath)
	tmp, err := os.CreateTemp(dir, ".dl-*.tmp")
	if err != nil {
		return 0, fmt.Errorf("create temp: %w", err)
	}
	tmpPath := tmp.Name()
	cleanup := true
	defer func() {
		if cleanup {
			_ = os.Remove(tmpPath)
		}
	}()

	n, err := io.Copy(tmp, resp.Body)
	if err != nil {
		tmp.Close()
		return 0, fmt.Errorf("write %s: %w", dstPath, err)
	}
	if err := tmp.Sync(); err != nil {
		tmp.Close()
		return 0, fmt.Errorf("sync %s: %w", dstPath, err)
	}
	if err := tmp.Close(); err != nil {
		return 0, fmt.Errorf("close temp: %w", err)
	}
	cleanup = false
	if err := os.Rename(tmpPath, dstPath); err != nil {
		return 0, err
	}
	return n, nil
}

func httpDownloadFileRetry(client *http.Client, url, dstPath string) (int64, error) {
	var err error
	var n int64
	for attempt := 1; attempt <= 4; attempt++ {
		if n, err = httpDownloadFile(client, url, dstPath); err == nil {
			return n, nil
		}
		var se *httpStatusError
		if errors.As(err, &se) && se.code >= 400 && se.code < 500 {
			return 0, err
		}
		if attempt < 4 {
			backoff := time.Duration(attempt*attempt*5) * time.Second
			log.Printf("browselocal: download %s attempt %d/4 failed (%v) — retrying in %s",
				filepath.Base(dstPath), attempt, err, backoff)
			time.Sleep(backoff)
		}
	}
	return 0, err
}

func (s *librarySession) downloadRemoteFiles(item *queueItem, dstFs string) {
	prefix := item.Prefix
	if prefix == "" {
		prefix = s.opts.RemoteFilesPrefix
	}
	relDir := ""
	if prefix != "" {
		relDir = prefix + "/"
	}
	relDir += item.DirPath

	seen := map[string]bool{}
	var names []string
	add := func(n string) {
		if n == "" || seen[n] {
			return
		}
		seen[n] = true
		names = append(names, n)
	}
	if item.Rec != nil {
		for _, f := range item.Rec.Formats {
			if f != nil {
				add(f.Name)
			}
		}
	}
	add("cover.jpg")
	add("metadata.opf")

	const maxParallel = 4
	sem := make(chan struct{}, maxParallel)
	var wg sync.WaitGroup
	got, done := 0, 0
	total := len(names)

	for _, name := range names {
		s.mu.Lock()
		st := item.Status
		s.mu.Unlock()
		if st == statusPaused || st == statusCanceled {
			break
		}
		sem <- struct{}{}
		wg.Add(1)
		go func(name string) {
			defer wg.Done()
			defer func() { <-sem }()
			dst := filepath.Join(dstFs, name)
			ok := false
			var addBytes int64 = -1
			if fi, err := os.Stat(dst); err == nil && fi.Size() > 0 {
				ok = true
			} else if s.opts.HTTPClient != nil {
				if fileURL, uerr := url.JoinPath(s.opts.BaseURL, relDir, name); uerr != nil {
					log.Printf("browselocal: bad URL %s/%s: %v (skipping)", relDir, name, uerr)
				} else if n, derr := httpDownloadFileRetry(s.opts.HTTPClient, fileURL, dst); derr != nil {
					log.Printf("browselocal: download %s/%s: %v (skipping)", relDir, name, derr)
				} else {
					ok = true
					addBytes = n
				}
			} else {
				log.Printf("browselocal: no remote transport configured for %s/%s (skipping)", strings.TrimRight(relDir, "/"), name)
			}
			s.mu.Lock()
			if ok {
				got++
			}
			if addBytes >= 0 {
				s.bytesTransferred += addBytes
			}
			done++
			if total > 0 {
				item.Progress = done * 100 / total
			}
			s.mu.Unlock()
		}(name)
	}
	wg.Wait()

	s.mu.Lock()
	if item.Status == statusPaused || item.Status == statusCanceled {
		s.mu.Unlock()
		return
	}
	if got == 0 {
		item.Status = statusFailed
		item.Error = "no files downloaded"
	} else {
		item.Status = statusDone
		item.Progress = 100
	}
	s.mu.Unlock()
}

func collectFormatFiles(bookDir string) ([]string, error) {
	entries, err := os.ReadDir(bookDir)
	if err != nil {
		return nil, err
	}
	var files []string
	for _, e := range entries {
		if e.IsDir() || e.Name() == "metadata.opf" || e.Name() == "cover.jpg" {
			continue
		}
		files = append(files, filepath.Join(bookDir, e.Name()))
	}
	return files, nil
}

type importPending struct {
	item  *queueItem
	files []string
	rev   string
	opf   string
	id    int
}

func (s *librarySession) importBooksBatch(items []*queueItem) {
	s.importMu.Lock()
	defer s.importMu.Unlock()

	s.mu.Lock()
	libPath := s.libraryPath
	s.mu.Unlock()
	if libPath == "" {
		return
	}

	dlDir := s.getDownloadDir()
	exe := &calibre.CalibreExe{LibraryPath: libPath}
	ctx := context.Background()

	tracked, terr := exe.ImportedAccorderBooks(ctx)
	if terr != nil {
		tracked = map[string]calibre.ImportedBook{}
	}

	var todo []importPending
	for _, item := range items {
		s.mu.Lock()
		done := item.Status == statusDone
		s.mu.Unlock()
		if !done {
			continue
		}
		bookDir := item.localPath(dlDir)
		files, err := collectFormatFiles(bookDir)
		if err != nil {
			log.Printf("browselocal: batch-import %s: readdir: %v", item.BookID, err)
			continue
		}
		if len(files) == 0 {
			continue
		}
		rev := calibre.ImportRevision(item.LastModified, files)
		if existing, found := tracked[item.BookID]; found && existing.Rev == rev {
			continue
		}
		opf := filepath.Join(bookDir, "metadata.opf")
		if _, err := os.Stat(opf); err != nil {
			opf = ""
		}
		todo = append(todo, importPending{item: item, files: files, rev: rev, opf: opf})
	}
	if len(todo) == 0 {
		return
	}

	const addChunk = 100
	for start := 0; start < len(todo); start += addChunk {
		end := start + addChunk
		if end > len(todo) {
			end = len(todo)
		}
		chunk := todo[start:end]
		primaries := make([]string, len(chunk))
		for i := range chunk {
			primaries[i] = chunk[i].files[0]
		}
		batchIDs, err := exe.AddBatch(ctx, primaries)
		if err == nil && len(batchIDs) == len(chunk) {
			for i := range chunk {
				chunk[i].id = batchIDs[i]
			}
			continue
		}
		if err != nil {
			log.Printf("browselocal: batch add failed (%v) — per-book fallback for %d books", err, len(chunk))
		} else {
			log.Printf("browselocal: batch add returned %d ids for %d files — per-book fallback", len(batchIDs), len(chunk))
		}
		for i := range chunk {
			id, aerr := exe.Add(ctx, chunk[i].item.Title, chunk[i].files[0])
			if aerr != nil {
				log.Printf("browselocal: batch-import %s: add: %v", chunk[i].item.BookID, aerr)
				continue
			}
			chunk[i].id = id
		}
	}

	imported := 0
	for _, p := range todo {
		if p.id == 0 {
			continue
		}
		for _, f := range p.files[1:] {
			if aerr := exe.AddFormat(ctx, p.id, f); aerr != nil {
				log.Printf("browselocal: batch-import %s/%s: %v", p.item.BookID, filepath.Base(f), aerr)
			}
		}
		idField := "accorder:" + p.item.BookID + ",accorder_rev:" + p.rev
		fields := map[string]string{"identifiers": idField}
		coverPath := filepath.Join(p.item.localPath(dlDir), "cover.jpg")
		if _, statErr := os.Stat(coverPath); statErr == nil {
			fields["cover"] = coverPath
		}
		if merr := exe.SetMetadataWithOPF(ctx, p.id, p.opf, fields); merr != nil {
			log.Printf("browselocal: batch-import %s/metadata: %v", p.item.BookID, merr)
		}
		imported++
	}
	log.Printf("browselocal: batch-imported %d book(s) into %s", imported, libPath)
}

func (s *librarySession) handleDownloadItem(args json.RawMessage) (any, error) {
	var req struct {
		BookID string `json:"book_id"`
	}
	if err := json.Unmarshal(args, &req); err != nil {
		return nil, err
	}

	s.mu.Lock()
	for _, item := range s.queue {
		if item.BookID == req.BookID && item.Status == statusQueued {
			s.downloadCh <- item
			s.mu.Unlock()

			s.ensureWorker()

			return map[string]any{"started": true, "book_id": req.BookID}, nil
		}
	}
	s.mu.Unlock()
	return nil, fmt.Errorf("book %s not found in queue or not in queued state", req.BookID)
}

func (s *librarySession) handleDownloadPause(args json.RawMessage) (any, error) {
	var req struct {
		BookID string `json:"book_id"`
	}
	if err := json.Unmarshal(args, &req); err != nil {
		return nil, err
	}

	s.mu.Lock()
	defer s.mu.Unlock()

	for _, item := range s.queue {
		if item.BookID == req.BookID && item.Status == statusDownloading {
			stopJobAsync(item.JobID)
			item.Status = statusPaused
			return map[string]any{"paused": true, "book_id": req.BookID}, nil
		}
	}
	return nil, fmt.Errorf("book %s not currently downloading", req.BookID)
}

func (s *librarySession) handleDownloadResume(args json.RawMessage) (any, error) {
	var req struct {
		BookID string `json:"book_id"`
	}
	if err := json.Unmarshal(args, &req); err != nil {
		return nil, err
	}

	s.mu.Lock()
	for _, item := range s.queue {
		if item.BookID == req.BookID && item.Status == statusPaused {
			item.Status = statusQueued
			s.downloadCh <- item
			s.mu.Unlock()

			s.ensureWorker()

			return map[string]any{"resumed": true, "book_id": req.BookID}, nil
		}
	}
	s.mu.Unlock()
	return nil, fmt.Errorf("book %s not in paused state", req.BookID)
}

func (s *librarySession) handleDownloadCancel(args json.RawMessage) (any, error) {
	var req struct {
		BookID string `json:"book_id"`
	}
	if err := json.Unmarshal(args, &req); err != nil {
		return nil, err
	}

	dlFolder := s.getDownloadDir()
	s.mu.Lock()
	defer s.mu.Unlock()

	for _, item := range s.queue {
		if item.BookID == req.BookID && (item.Status == statusDownloading || item.Status == statusPaused || item.Status == statusQueued) {
			if item.Status == statusDownloading {
				stopJobAsync(item.JobID)
			}
			item.Status = statusCanceled
			partialDir := item.localPath(dlFolder)
			go cleanPartials(partialDir)
			return map[string]any{"canceled": true, "book_id": req.BookID}, nil
		}
	}
	return nil, fmt.Errorf("book %s not in cancelable state", req.BookID)
}

func (s *librarySession) handleQueueRemove(args json.RawMessage) (any, error) {
	var req struct {
		BookID string `json:"book_id"`
	}
	if err := json.Unmarshal(args, &req); err != nil {
		return nil, err
	}
	dlDir := s.getDownloadDir()
	s.mu.Lock()
	defer s.mu.Unlock()
	kept := s.queue[:0]
	removed := false
	for _, it := range s.queue {
		if it.BookID == req.BookID {
			removed = true
			if it.Status == statusDownloading {
				stopJobAsync(it.JobID)
			}
			go removeDownloadFiles(dlDir, it)
			continue
		}
		kept = append(kept, it)
	}
	s.queue = kept
	return map[string]any{"removed": removed, "queue_size": len(s.queue)}, nil
}

func (s *librarySession) handleQueueClearNotDownloading() (any, error) {
	dlDir := s.getDownloadDir()
	s.mu.Lock()
	defer s.mu.Unlock()
	kept := s.queue[:0]
	var cleared int
	for _, it := range s.queue {
		if it.Status == statusDownloading {
			kept = append(kept, it)
			continue
		}
		cleared++
		go removeDownloadFiles(dlDir, it)
	}
	s.queue = kept
	return map[string]any{"cleared": cleared, "queue_size": len(s.queue)}, nil
}

func (s *librarySession) handleBatchPause() (any, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	var paused int
	for _, item := range s.queue {
		if item.Status == statusDownloading {
			stopJobAsync(item.JobID)
			item.Status = statusPaused
			paused++
		}
	}
	return map[string]any{"paused": paused}, nil
}

func (s *librarySession) handleBatchResume() (any, error) {
	s.mu.Lock()
	var resumed int
	for _, item := range s.queue {
		if item.Status == statusPaused {
			item.Status = statusQueued
			s.downloadCh <- item
			resumed++
		}
	}
	s.mu.Unlock()

	if resumed > 0 {
		s.ensureWorker()
	}

	return map[string]any{"resumed": resumed}, nil
}

func cleanPartials(dir string) {
	entries, err := os.ReadDir(dir)
	if err != nil {
		return
	}
	for _, e := range entries {
		if strings.HasSuffix(e.Name(), ".rcpartial") {
			os.Remove(filepath.Join(dir, e.Name()))
		}
	}
}

func removeDownloadFiles(dlFolder string, item *queueItem) {
	p := item.localPath(dlFolder)
	rel, err := filepath.Rel(dlFolder, p)
	if err != nil || rel == "." || rel == ".." || strings.HasPrefix(rel, ".."+string(filepath.Separator)) {
		cleanPartials(p)
		return
	}
	_ = os.RemoveAll(p)
}

func (s *librarySession) getDownloadDir() string {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.opts.DownloadDir != "" {
		os.MkdirAll(s.opts.DownloadDir, 0755)
		return s.opts.DownloadDir
	}
	dir := filepath.Join(s.cacheDir, "downloads")
	os.MkdirAll(dir, 0755)
	return dir
}

const defaultLibraryName = "MY LIBRARY"

func clampLibraryName(s string) string {
	r := []rune(s)
	if len(r) > 32 {
		r = r[:32]
	}
	return string(r)
}

func (s *librarySession) loadSettings() {
	s.mu.Lock()
	if s.libraryName == "" {
		s.libraryName = defaultLibraryName
	}
	s.mu.Unlock()
	s.restoreSavedSettings()
	s.mu.Lock()
	if s.libraryPath == "" {
		s.libraryPath = s.opts.CalibrePath
	}
	if s.librarianName == "" {
		s.librarianName = s.opts.Librarian
	}
	s.mu.Unlock()
}

func (s *librarySession) restoreSavedSettings() {
	data, err := os.ReadFile(filepath.Join(s.cacheDir, "settings.json"))
	if err != nil {
		return
	}
	var settings struct {
		LibraryPath    string `json:"library_path"`
		DownloadFolder string `json:"download_folder"`
		Librarian      string `json:"librarian"`
		LibraryName    string `json:"library_name"`
		Alias          string `json:"alias"`
	}
	if err := json.Unmarshal(data, &settings); err != nil {
		return
	}
	libPath := settings.LibraryPath
	if libPath == "" {
		libPath = settings.DownloadFolder
	}
	s.mu.Lock()
	s.libraryPath = libPath
	s.librarianName = settings.Librarian
	if settings.LibraryName != "" {
		s.libraryName = clampLibraryName(settings.LibraryName)
	}
	s.aliasName = settings.Alias
	s.mu.Unlock()
}

func (s *librarySession) handleSettingsGet() (any, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	libraryName := s.libraryName
	if libraryName == "" {
		libraryName = defaultLibraryName
	}
	return map[string]any{
		"library_path": s.libraryPath,
		"librarian":    s.librarianName,
		"library_name": libraryName,
		"alias":        s.aliasName,
	}, nil
}

func (s *librarySession) handleSettingsSet(args json.RawMessage) (any, error) {
	var req struct {
		LibraryPath string `json:"library_path"`
		Librarian   string `json:"librarian"`
		LibraryName string `json:"library_name"`
	}
	if err := json.Unmarshal(args, &req); err != nil {
		return nil, err
	}

	s.mu.Lock()
	if req.LibraryPath != "" {
		s.libraryPath = req.LibraryPath
	}
	if req.Librarian != "" {
		s.librarianName = req.Librarian
	}
	if req.LibraryName != "" {
		s.libraryName = clampLibraryName(req.LibraryName)
	}
	s.mu.Unlock()

	resp := map[string]any{"saved": true}
	if alias, err := s.ensureAliasLink(); err != nil {
		resp["alias_error"] = err.Error()
	} else if alias != "" {
		resp["alias"] = alias
	}

	if err := s.writeSettingsFile(); err != nil {
		return nil, err
	}

	return resp, nil
}

func (s *librarySession) ensureAliasLink() (string, error) {
	s.mu.Lock()
	lname := s.libraryName
	lp := s.libraryPath
	librarian := s.librarianName
	s.mu.Unlock()
	if s.opts.EnsureAlias == nil || lname == "" || lp == "" {
		return "", nil
	}
	alias, err := s.opts.EnsureAlias(lname, lp, librarian)
	if err != nil {
		log.Printf("browselocal: ensure alias: %v", err)
		return "", err
	}
	s.mu.Lock()
	changed := s.aliasName != alias
	s.aliasName = alias
	s.mu.Unlock()
	if changed {
		if err := s.writeSettingsFile(); err != nil {
			log.Printf("browselocal: persist alias to settings: %v", err)
		}
	}
	return alias, nil
}

func (s *librarySession) writeSettingsFile() error {
	s.mu.Lock()
	settingsData, _ := json.Marshal(map[string]string{
		"library_path": s.libraryPath,
		"librarian":    s.librarianName,
		"library_name": s.libraryName,
		"alias":        s.aliasName,
	})
	s.mu.Unlock()
	if err := os.WriteFile(filepath.Join(s.cacheDir, "settings.json"), settingsData, 0644); err != nil {
		return fmt.Errorf("settings: write: %w", err)
	}
	return nil
}

func (s *librarySession) triggerBuild() {
	s.mu.Lock()
	s.buildStatus = buildBuilding
	libPath := s.libraryPath
	librarian := s.librarianName
	s.mu.Unlock()

	if libPath == "" {
		s.mu.Lock()
		s.buildStatus = buildFailed
		s.buildError = "library_path not configured"
		s.mu.Unlock()
		return
	}

	outputDir := libPath
	if err := os.MkdirAll(outputDir, 0755); err != nil {
		s.mu.Lock()
		s.buildStatus = buildFailed
		s.buildError = err.Error()
		s.mu.Unlock()
		return
	}

	ns := uuid.NewV5(uuid.NamespaceURL, "accorder://browse-seal")
	sealUUID := uuid.NewV5(ns, s.cacheDir).String()
	motw := &calibre.MotwStandaloneApp{
		CalibreDirectory: libPath + "/",
		Librarian:        librarian,
		LibraryUUID:      sealUUID,
	}

	if err := motw.LoadBooksE(); err != nil {
		s.mu.Lock()
		s.buildStatus = buildFailed
		s.buildError = err.Error()
		log.Printf("browselocal: build failed (load): %v", err)
		s.mu.Unlock()
		return
	}

	for _, book := range motw.Books {
		if book.CoverFingerprint != "" {
			continue
		}
		if fp, ok := calibre.LocalCoverFingerprint(libPath, book.CoverUrl); ok {
			book.CoverFingerprint = fp
		}
	}

	if err := calibre.RenderBooksBundle(outputDir, motw.Books); err != nil {
		s.mu.Lock()
		s.buildStatus = buildFailed
		s.buildError = err.Error()
		log.Printf("browselocal: build failed (render): %v", err)
		s.mu.Unlock()
		return
	}

	s.mu.Lock()
	s.buildStatus = buildBuilt
	s.buildError = ""
	log.Printf("browselocal: build complete at %s (%d books)", outputDir, len(motw.Books))
	s.mu.Unlock()
}

func (s *librarySession) handleBuild() (any, error) {
	_, _ = s.ensureAliasLink()
	s.buildWg.Add(1)
	go func() {
		defer s.buildWg.Done()
		s.triggerBuild()
	}()
	return map[string]any{"building": true}, nil
}

func (s *librarySession) handleBuildStatus() (any, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	var libraryHTMLPath string
	if s.buildStatus == buildBuilt && s.libraryPath != "" {
		libraryHTMLPath = filepath.Join(s.libraryPath, "BROWSE_LIBRARY.html")
	}

	return map[string]any{
		"build_status":      s.buildStatus,
		"build_error":       s.buildError,
		"library_html_path": libraryHTMLPath,
	}, nil
}

func (s *librarySession) handleOpenMyLibrary() (any, error) {
	s.mu.Lock()
	libPath := s.libraryPath
	items := make([]*queueItem, len(s.queue))
	copy(items, s.queue)
	if libPath == "" {
		s.mu.Unlock()
		return nil, fmt.Errorf("library_path not configured")
	}
	s.buildStatus = buildBuilding
	s.buildError = ""
	s.mu.Unlock()

	_, _ = s.ensureAliasLink()

	s.buildWg.Add(1)
	go func() {
		defer s.buildWg.Done()
		s.importBooksBatch(items)
		if _, err := os.Stat(filepath.Join(libPath, "metadata.db")); err != nil {
			exe := &calibre.CalibreExe{LibraryPath: libPath}
			if _, lerr := exe.Books(context.Background()); lerr != nil {
				log.Printf("browselocal: openMyLibrary: ensure library: %v", lerr)
			}
		}
		s.triggerBuild()
	}()

	return map[string]any{"building": true}, nil
}

func (s *librarySession) handleOpenBuilt() (any, error) {
	if s.browser == nil {
		return nil, fmt.Errorf("browser not available")
	}

	s.mu.Lock()
	if s.buildStatus != buildBuilt {
		s.mu.Unlock()
		return nil, fmt.Errorf("library not built yet (status: %s)", s.buildStatus)
	}
	s.mu.Unlock()

	dlFolder := s.getDownloadDir()

	page, err := s.browser.Page(proto.TargetCreateTarget{})
	if err != nil {
		return nil, fmt.Errorf("openBuilt: create page: %w", err)
	}

	if err := (proto.EmulationClearDeviceMetricsOverride{}).Call(page); err != nil {
		log.Printf("browselocal: openBuilt: clear device metrics: %v", err)
	}

	page.MustExpose("backend_rpc", func(arg gson.JSON) (interface{}, error) {
		var req rpcRequest
		if err := json.Unmarshal([]byte(arg.Str()), &req); err != nil {
			return nil, err
		}
		if req.Service == "session" && req.Method == "mode" {
			return "staged", nil
		}
		return s.handleRPC(arg.Str())
	})

	s.mu.Lock()
	s.stagedPages[page.TargetID] = true
	s.mu.Unlock()

	go s.browser.EachEvent(func(e *proto.TargetTargetDestroyed) bool {
		if e.TargetID == page.TargetID {
			s.mu.Lock()
			delete(s.stagedPages, e.TargetID)
			s.mu.Unlock()
			return true
		}
		return false
	})()

	htmlPath := filepath.Join(dlFolder, "BROWSE_LIBRARY.html")
	if err := page.Navigate("file://" + htmlPath); err != nil {
		return nil, fmt.Errorf("openBuilt: navigate: %w", err)
	}

	return map[string]any{"library_path": dlFolder}, nil
}

func (s *librarySession) handleCalibreImport(args json.RawMessage) (any, error) {
	var req struct {
		CalibrePath string   `json:"calibre_path"`
		BookIDs     []string `json:"book_ids"`
	}
	if err := json.Unmarshal(args, &req); err != nil {
		return nil, err
	}

	calibrePath := req.CalibrePath
	if calibrePath == "" {
		s.mu.Lock()
		calibrePath = s.libraryPath
		s.mu.Unlock()
	}
	if calibrePath == "" {
		return nil, fmt.Errorf("library path not configured")
	}

	dlFolder := s.getDownloadDir()
	exe := &calibre.CalibreExe{LibraryPath: calibrePath}
	ctx := context.Background()

	tracked, terr := exe.ImportedAccorderBooks(ctx)
	if terr != nil {
		tracked = map[string]calibre.ImportedBook{}
	}

	s.mu.Lock()
	items := make([]*queueItem, len(s.queue))
	copy(items, s.queue)
	s.mu.Unlock()

	var imported, updated, skipped, errors []string

	for _, item := range items {
		if item.Status != statusDone {
			continue
		}
		if len(req.BookIDs) > 0 {
			wanted := false
			for _, id := range req.BookIDs {
				if id == item.BookID {
					wanted = true
					break
				}
			}
			if !wanted {
				continue
			}
		}

		bookDir := item.localPath(dlFolder)
		formatFiles, err := collectFormatFiles(bookDir)
		if err != nil {
			errors = append(errors, fmt.Sprintf("%s: %v", item.BookID, err))
			continue
		}
		if len(formatFiles) == 0 {
			continue
		}

		rev := calibre.ImportRevision(item.LastModified, formatFiles)
		opfPath := filepath.Join(bookDir, "metadata.opf")
		_, opfErr := os.Stat(opfPath)
		hasOPF := opfErr == nil
		idField := "accorder:" + item.BookID + ",accorder_rev:" + rev

		if existing, found := tracked[item.BookID]; found {
			if existing.Rev == rev {
				skipped = append(skipped, item.BookID)
				continue
			}
			metaChanged, formatChanged := calibre.RevisionChanged(existing.Rev, rev)
			cid := existing.CalibreID

			if formatChanged {
				have := make(map[string]bool)
				for _, ext := range calibre.FormatExts(formatFiles) {
					have[ext] = true
				}
				for _, f := range formatFiles {
					if aErr := exe.AddFormat(ctx, cid, f); aErr != nil {
						errors = append(errors, fmt.Sprintf("%s/%s: %v", item.BookID, filepath.Base(f), aErr))
					}
				}
				for _, ext := range existing.Formats {
					if !have[ext] {
						if rErr := exe.RemoveFormat(ctx, cid, ext); rErr != nil {
							errors = append(errors, fmt.Sprintf("%s/-%s: %v", item.BookID, ext, rErr))
						}
					}
				}
			}
			if metaChanged && hasOPF {
				if mErr := exe.SetMetadataFromOPF(ctx, cid, opfPath); mErr != nil {
					errors = append(errors, fmt.Sprintf("%s/metadata.opf: %v", item.BookID, mErr))
				}
			}
			if mErr := exe.SetMetadata(ctx, cid, map[string]string{"identifiers": idField}); mErr != nil {
				errors = append(errors, fmt.Sprintf("%s/identifier: %v", item.BookID, mErr))
			}
			tracked[item.BookID] = calibre.ImportedBook{CalibreID: cid, Rev: rev, Formats: calibre.FormatExts(formatFiles)}
			updated = append(updated, item.BookID)
			continue
		}

		bookID, addErr := exe.Add(ctx, item.Title, formatFiles[0])
		if addErr != nil {
			errors = append(errors, fmt.Sprintf("%s: %v", item.BookID, addErr))
			continue
		}
		imported = append(imported, formatFiles[0])
		for _, f := range formatFiles[1:] {
			if aErr := exe.AddFormat(ctx, bookID, f); aErr != nil {
				errors = append(errors, fmt.Sprintf("%s/%s: %v", item.BookID, filepath.Base(f), aErr))
			} else {
				imported = append(imported, f)
			}
		}
		if hasOPF {
			if mErr := exe.SetMetadataFromOPF(ctx, bookID, opfPath); mErr != nil {
				errors = append(errors, fmt.Sprintf("%s/metadata.opf: %v", item.BookID, mErr))
			}
		}
		if mErr := exe.SetMetadata(ctx, bookID, map[string]string{"identifiers": idField}); mErr != nil {
			errors = append(errors, fmt.Sprintf("%s/identifier: %v", item.BookID, mErr))
		}
		tracked[item.BookID] = calibre.ImportedBook{CalibreID: bookID, Rev: rev, Formats: calibre.FormatExts(formatFiles)}
	}

	return map[string]any{
		"imported":      imported,
		"updated":       updated,
		"skipped":       skipped,
		"errors":        errors,
		"count":         len(imported),
		"updated_count": len(updated),
		"skipped_count": len(skipped),
	}, nil
}
