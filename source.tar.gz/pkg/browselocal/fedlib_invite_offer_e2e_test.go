//go:build integration

package browselocal

//

// Through-the-binary tier for the offer/claim flow (fedlib-reinvite-identity
// late-retro 1: stdout contracts must be asserted through main(), not only
// in-process — process-level stderr noise was invisible to the in-process golden test).
//
//	fedlib members invite --offer   → stdout is EXACTLY one claim-URL line
//	fedlib share live               → GET info (never burns), POST claim (burns once)
//	lib join <blob> (no passphrase) → B4: generates secrets.key (0600), join succeeds
//

// The claim POST runs over loopback HTTP because the local serve has no TLS;
// the https-only enforcement of `lib join <url>` is client-side and asserted
// by cmd unit tests (TestJoinClaim_PlainHTTPRefused). The full https URL-join
// leg is the manual live-deploy smoke (see proposal Verification Plan).
//

// Run: go test -tags integration -run TestFedlibInviteOffer_E2E ./pkg/browselocal/

import (
	"accorder/pkg/calibre"
	"bytes"
	"encoding/json"
	"io"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestFedlibInviteOffer_E2E_BinaryStdoutClaimAndB4Join(t *testing.T) {
	bin := buildAccorderBinary(t)

	cfgDir := t.TempDir()
	work := t.TempDir()

	// No ACCORDER_SECRETS_PASSPHRASE in the child env: the B4 join leg must
	// succeed with no env var at all.
	env := []string{"XDG_CONFIG_HOME=" + cfgDir, "PATH=" + os.Getenv("PATH"), "HOME=" + os.Getenv("HOME")}

	runAcc := func(args ...string) (stdout, stderr string) {
		t.Helper()
		cmd := exec.Command(bin, args...)
		cmd.Env = env
		var outBuf, errBuf bytes.Buffer
		cmd.Stdout, cmd.Stderr = &outBuf, &errBuf
		if err := cmd.Run(); err != nil {
			t.Fatalf("accorder %s failed: %v\nstdout:\n%s\nstderr:\n%s",
				strings.Join(args, " "), err, outBuf.String(), errBuf.String())
		}
		return outBuf.String(), errBuf.String()
	}

	// --- one local member so the aggregate serve has something to load ---
	aliceUUID := "11111111-1111-4111-8111-111111111111"
	aliceDir := makeLocalLibrary(t, "Alice", aliceUUID, []*calibre.Book{
		fpBook("a-1", "Cybernetics and Society", "Norbert Wiener", "Alice", aliceUUID, "Sbb9l4QI"),
	})
	runAcc("fedlib", "members", "add", "motw", aliceUUID, "--local-path", aliceDir, "--prefix", "alice", "--fedlib-path", work)
	runAcc("fedlib", "build", "--output-path", work)

	// --- seed the descriptor: one name — the serve reads storage-identity
	// from it, and offers are sealed under clearnet/<id>/invites. ---
	runAcc("fedlib", "config", "set", "motw", "--mode", "public",
		"--bucket", "motw", "--s3-provider", "Wasabi", "--s3-endpoint", "https://s3.test")

	// --- serve FIRST (production shape: offers are sealed while the serve
	// runs and read per-request — no restart, no reload loop). Inviting first
	// would also flip the registry to "has rclone members" and make the serve
	// demand S3 creds. ---
	addr := freeLoopbackAddr(t)
	srv := exec.Command(bin, "fedlib", "share", "live", "motw",
		"--aggregate-path", work, "--only-http", "--listen", addr)
	srv.Env = env
	var serveLog bytes.Buffer
	srv.Stdout, srv.Stderr = &serveLog, &serveLog
	if err := srv.Start(); err != nil {
		t.Fatalf("start fedlib share live: %v", err)
	}
	defer func() { _ = srv.Process.Kill(); _ = srv.Wait() }()
	defer func() {
		if t.Failed() {
			t.Logf("serve log:\n%s", serveLog.String())
		}
	}()
	base := "http://" + addr
	waitHTTP(t, base+"/_GENERATION", 20*time.Second)

	// --- operator: invite --offer through the real binary, mid-serve ---
	stdout, stderr := runAcc("fedlib", "members", "invite", "motw", "Carol",
		"--prefix", "carol",
		"--s3-access-key", "AK", "--s3-secret-key", "SK",
		"--s3-provider", "Wasabi", "--s3-endpoint", "https://s3.test", "--bucket", "motw",
		"--fedlib-path", work,
		"--offer", "--endpoint", "https://lib.example.org")

	line := strings.TrimSuffix(stdout, "\n")
	if stdout != line+"\n" || strings.Contains(line, "\n") || !strings.HasPrefix(line, "https://lib.example.org/invite/") {
		t.Fatalf("offer-mode stdout through the binary is not exactly one URL line: %q", stdout)
	}
	u, err := url.Parse(line)
	if err != nil {
		t.Fatalf("stdout does not parse as URL: %v", err)
	}
	token := strings.TrimPrefix(u.Path, "/invite/")
	if strings.Contains(stderr, "export ACCORDER_SECRETS_PASSPHRASE=") {
		t.Fatalf("offer-mode stderr still tells the member to export a passphrase:\n%s", stderr)
	}
	if !strings.Contains(stderr, "accorder lib join carol --invite '"+line+"'") {
		t.Fatalf("offer-mode stderr missing the URL join one-liner:\n%s", stderr)
	}

	offerPath := filepath.Join(cfgDir, "accorder", "clearnet", "motw", "invites")
	entries, err := os.ReadDir(offerPath)
	if err != nil || len(entries) != 1 {
		t.Fatalf("offers dir %s: entries=%v err=%v, want exactly 1 sealed offer", offerPath, entries, err)
	}

	// GET info never burns (link-preview simulation).
	for range 2 {
		resp, err := http.Get(base + "/invite/" + token)
		if err != nil {
			t.Fatalf("GET info: %v", err)
		}
		body, _ := io.ReadAll(resp.Body)
		resp.Body.Close()
		if resp.StatusCode != 200 || !strings.Contains(string(body), "carol") {
			t.Fatalf("GET info: status %d body %q\nserve:\n%s", resp.StatusCode, body, serveLog.String())
		}
	}
	if entries, _ := os.ReadDir(offerPath); len(entries) != 1 {
		t.Fatalf("GET info burned or duplicated the offer: %d entries", len(entries))
	}

	// POST claim burns exactly once.
	claim := func() (int, string) {
		t.Helper()
		resp, err := http.Post(base+"/invite/"+token+"/claim", "application/json", nil)
		if err != nil {
			t.Fatalf("POST claim: %v", err)
		}
		defer resp.Body.Close()
		body, _ := io.ReadAll(resp.Body)
		return resp.StatusCode, string(body)
	}
	status, body := claim()
	if status != 200 {
		t.Fatalf("first claim: status %d body %q\nserve:\n%s", status, body, serveLog.String())
	}
	var envelope struct {
		Version int    `json:"version"`
		Invite  string `json:"invite"`
	}
	if err := json.Unmarshal([]byte(body), &envelope); err != nil || envelope.Version != 1 ||
		!strings.HasPrefix(envelope.Invite, "accorder-fedlib-invite:") {
		t.Fatalf("claim envelope malformed: %q (err=%v)", body, err)
	}
	if status, _ := claim(); status != 404 {
		t.Fatalf("second claim: status %d, want 404 (single-use)", status)
	}

	// --- member: B4 passphrase-free join with the claimed blob ---
	// The blob names a bucket on a fake endpoint and this seat has no Calibre
	// library, so the join cannot end in a publish; what this leg asserts is
	// the credential/key side effects. Run it tolerantly: credential storage
	// and the confirmation line happen before any remote inspection, and both
	// the remote-inspection failure and the incomplete-join report are
	// legitimate non-zero endings here.
	joinCmd := exec.Command(bin, "lib", "join", "carol", "-I", envelope.Invite)
	joinCmd.Env = env
	joinOut, joinErr := joinCmd.CombinedOutput()
	if joinErr != nil &&
		!strings.Contains(string(joinOut), "published nothing") &&
		!strings.Contains(string(joinOut), "inspect published library") {
		t.Fatalf("join failed outside the two tolerated endings: %v\n%s", joinErr, joinOut)
	}
	if !strings.Contains(string(joinOut), "configured alias \"carol\"") {
		t.Fatalf("join output missing confirmation:\n%s", joinOut)
	}
	keyPath := filepath.Join(cfgDir, "accorder", "secrets.key")
	info, err := os.Stat(keyPath)
	if err != nil {
		t.Fatalf("B4: secrets.key not generated by passphrase-less join: %v", err)
	}
	if perm := info.Mode().Perm(); perm != 0o600 {
		t.Fatalf("secrets.key mode = %o, want 0600", perm)
	}
	t.Log("OK: offer URL on stdout (one line), GET info burn-free, POST claim single-use, B4 join with zero env vars")
}
