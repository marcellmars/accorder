//go:build integration

package browselocal

import (
	"os"
	"path/filepath"
	"sync"
	"testing"
	"time"

	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/launcher"
	"github.com/ysmood/gson"
)

// TestBrowse_E2E_EmbeddedViewerIsStandalone proves the MY LIBRARY built-library
// viewer renders identically to opening file://…/BROWSE_LIBRARY.html directly,
// even though it runs inside an <iframe> that inherits the parent page's
// backend_rpc. The embedded app must ignore that inherited backend and behave as
// a pure portable library (no [ADD TO QUEUE], zero backend calls).
//
// The parent.html exposes backend_rpc (which rod propagates into the child frame,
// exactly as the real MY LIBRARY iframe inherits it) and records every call. The
// embedded portable bundle must make NONE.
func TestBrowse_E2E_EmbeddedViewerIsStandalone(t *testing.T) {
	dir := writeFixture(t)

	// Parent shell: just an iframe to the built portable library. The parent does
	// NOT load the bundle, so any recorded backend_rpc call originates in the iframe.
	parent := `<!doctype html><html><head><meta charset="utf-8"></head>
<body style="margin:0">
<iframe id="lib" src="BROWSE_LIBRARY.html" style="width:100vw;height:100vh;border:0"></iframe>
</body></html>`
	if err := os.WriteFile(filepath.Join(dir, "parent.html"), []byte(parent), 0644); err != nil {
		t.Fatal(err)
	}

	l := launcher.New().Headless(true)
	u, err := l.Launch()
	if err != nil {
		t.Fatalf("launcher: %v", err)
	}
	defer l.Cleanup()
	browser := rod.New().ControlURL(u)
	if err := browser.Connect(); err != nil {
		t.Fatalf("rod.Connect: %v", err)
	}
	defer browser.Close()

	page := browser.MustPage("about:blank")
	defer page.Close()

	var mu sync.Mutex
	var calls int
	page.MustExpose("backend_rpc", func(arg gson.JSON) (interface{}, error) {
		mu.Lock()
		calls++
		mu.Unlock()
		// Respond plausibly so a (wrongly) backend-coupled iframe wouldn't hang —
		// the assertion is on the call COUNT, not on a stalled await.
		return map[string]any{"_items": []any{}}, nil
	})

	if err := page.Navigate("file://" + filepath.Join(dir, "parent.html")); err != nil {
		t.Fatalf("navigate: %v", err)
	}

	frame := page.MustElement("#lib").MustFrame()

	// Sanity: the iframe really DID inherit backend_rpc (otherwise this test would
	// pass trivially without exercising the ignore-the-inherited-backend path).
	if !frame.Timeout(10 * time.Second).MustEval(`() => typeof window.backend_rpc === "function"`).Bool() {
		t.Fatal("precondition failed: iframe did not inherit parent backend_rpc; test cannot validate standalone behavior")
	}

	// The embedded app renders the portable data1.js books (covers grid).
	frame.Timeout(15 * time.Second).MustWait(`() => ((document.body && document.body.innerText) || "").includes("Front Book A")`)

	// Standalone behavior: no queue button anywhere in the embedded viewer.
	if frame.MustEval(`() => ((document.body && document.body.innerText) || "").includes("[ADD TO QUEUE]")`).Bool() {
		t.Fatal("embedded viewer shows [ADD TO QUEUE]; it must render as a backend-less portable library")
	}

	// Give any stray onMount backend call (e.g. session/mode) time to fire.
	time.Sleep(1500 * time.Millisecond)

	mu.Lock()
	got := calls
	mu.Unlock()
	if got != 0 {
		t.Fatalf("embedded viewer made %d backend_rpc call(s); a pure standalone library must make none", got)
	}

	t.Logf("OK: embedded MY LIBRARY viewer ignores the inherited backend — renders portable, zero backend calls")
}
