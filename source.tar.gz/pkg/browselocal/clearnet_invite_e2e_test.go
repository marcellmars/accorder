//go:build integration

package browselocal

import (
	"accorder/pkg/calibre"
	"accorder/pkg/torinvite"
	"bytes"
	"context"
	"net/http"
	"net/http/cookiejar"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/launcher"
)

// Standalone lib tests — operator testm. These use a SYNTHETIC library (covers +
// index), never the real MarcellMarsBooks: standalone `lib share live` writes a
// _GENERATION sentinel + copies the index INTO the calibre dir, so it must not run
// against the real 30G library. The real library is exercised read-only by the
// fedlib aggregate tests below. The fedlib path is the real-asset coverage.

func TestStandalone_E2E_FileRender(t *testing.T) {

	// (a) file:// standalone render — the default `lib build` offline static site
	// (BROWSE_LIBRARY.html + inline portable data1.js) renders in a browser with NO
	// server. Long-standing feature (broadly covered by the TestBrowse_E2E_* suite);
	// asserted here so the standalone matrix row is a real test, not a stub.
	dir := writeFixture(t)
	l := launcher.New().Headless(true)
	u, err := l.Launch()
	if err != nil {
		t.Fatalf("launcher: %v", err)
	}
	defer l.Cleanup()
	browser := rod.New().ControlURL(u)
	if err := browser.Connect(); err != nil {
		t.Fatalf("rod.Connect: %v", err)
	}
	defer browser.Close()
	page := browser.MustPage("about:blank")
	defer page.Close()
	watchConsole(t, page)

	fileURL := "file://" + filepath.Join(dir, "BROWSE_LIBRARY.html") + "#/?t=l"
	if err := page.Navigate(fileURL); err != nil {
		t.Fatalf("navigate file://: %v", err)
	}
	page.Timeout(20 * time.Second).MustWait(
		`() => ((document.body && document.body.innerText) || "").includes("Front Book A")`)
	t.Log("OK: standalone file:// render — offline static site renders books with no server")
}

// standaloneFixture builds a synthetic single library (covers + index) plus a
// SEPARATE index base path (so runLocal's copyFile is never src==dst), a hermetic
// XDG_CONFIG_HOME env (no stale 'default' action-alias whose saved S3 creds would
// divert lib share live into S3-source mode), and a unique alias shared by grant+serve.
func standaloneFixture(t *testing.T) (libDir, idxBase string, env []string, alias string) {
	t.Helper()
	const uuid = "00000000-0000-4000-8000-000000000001"
	libDir = makeLocalLibrary(t, "testm", uuid, []*calibre.Book{
		fpBook("s-1", "Cybernetics and Society", "Norbert Wiener", "testm", uuid, "Sbb9l4QI"),
		fpBook("s-2", "The Society of the Spectacle", "Guy Debord", "testm", uuid, "/////78F"),
	})
	idxBase = filepath.Join(t.TempDir(), "idx")
	raw, err := os.ReadFile(filepath.Join(libDir, "static", "library_index.zst"))
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(idxBase+".zst", raw, 0644); err != nil {
		t.Fatal(err)
	}
	env = append(os.Environ(), "XDG_CONFIG_HOME="+t.TempDir())
	alias = "e2estandalone"
	return libDir, idxBase, env, alias
}

// extractInvite pulls the accorder-invite: blob line out of grant stdout,
// tolerating any trailing log or diagnostic lines.
func extractInvite(t *testing.T, out []byte) string {
	t.Helper()
	for _, line := range strings.Split(string(out), "\n") {
		if s := strings.TrimSpace(line); strings.HasPrefix(s, "accorder-invite:") {
			return s
		}
	}
	t.Fatalf("no invite blob in grant output:\n%s", out)
	return ""
}

func TestLibShare_PerLibrary_HTTPCatalogByPath(t *testing.T) {

	// Regression guard for the founding lib share<->browse flow (the WebDAV→HTTP fix):
	// the per-library serve must expose the catalog (_GENERATION, static/library_index.zst,
	// static/data1.js) by EXACT PATH over plain HTTP — what `lib browse` (per_library, now
	// HTTP) fetches without any WebDAV/PROPFIND. Also asserts the served index is not
	// truncated by the copyFile src==dst self-copy. Non-Tor proxy for the Tor browse leg.
	bin := buildAccorderBinary(t)
	const uuid = "44444444-4444-4444-8444-444444444444"
	libDir := makeLocalLibrary(t, "foo", uuid, []*calibre.Book{
		fpBook("f-1", "Foo Title", "Foo Author", "foo", uuid, "Sbb9l4QI"),
	})
	if err := os.WriteFile(filepath.Join(libDir, "static", "data1.js"),
		[]byte("CALIBRE_BOOKS1={portable:true,books:[]};"), 0644); err != nil {
		t.Fatal(err)
	}
	idxPath := filepath.Join(libDir, "static", "library_index.zst")
	idxSize := func() int64 {
		fi, err := os.Stat(idxPath)
		if err != nil {
			return -1
		}
		return fi.Size()
	}
	before := idxSize()

	addr := freeLoopbackAddr(t)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	srv := exec.CommandContext(ctx, bin, "lib", "share", "live", "perlibhttp",
		"--calibrepath", libDir, "--index-path", filepath.Join(libDir, "static", "library_index"),
		"--librarian", "foo", "--libraryID", uuid, "--only-http", "--mode", "public", "--listen", addr)
	srv.Env = append(os.Environ(), "XDG_CONFIG_HOME="+t.TempDir()) // hermetic: no stale S3Source alias
	if err := srv.Start(); err != nil {
		t.Fatalf("start lib share live: %v", err)
	}
	defer func() { cancel(); _ = srv.Wait() }()
	base := "http://" + addr
	waitHTTP(t, base+"/", 30*time.Second)

	for _, p := range []string{"/_GENERATION", "/static/library_index.zst", "/static/data1.js"} {
		resp, err := http.Get(base + p)
		if err != nil {
			t.Fatalf("GET %s: %v", p, err)
		}
		resp.Body.Close()
		if resp.StatusCode != 200 {
			t.Fatalf("per-library serve %s: expected 200, got %d (must be reachable by path over HTTP)", p, resp.StatusCode)
		}
	}
	t.Log("OK: per-library serve exposes catalog (_GENERATION + library_index.zst + data1.js) by path")

	if after := idxSize(); after != before || after <= 0 {
		t.Fatalf("served index size changed %d -> %d (copyFile src==dst truncation regression)", before, after)
	}
	t.Log("OK: served index intact after serve (no self-copy truncation)")
}

func TestStandalone_E2E_HTTPOpen(t *testing.T) {

	// (b) HTTP public: lib share live --only-http --mode public (explicit;
	// standalone clearnet auth is invite-only by default (runLocal wraps /files/
	// public is also the default mode since share-access-modes).
	bin := buildAccorderBinary(t)
	libDir, idxBase, env, alias := standaloneFixture(t)
	addr := freeLoopbackAddr(t)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	srv := exec.CommandContext(ctx, bin, "lib", "share", "live", alias,
		"--calibrepath", libDir, "--only-http", "--mode", "public", "--listen", addr,
		"--librarian", "testm", "--libraryID", "00000000-0000-4000-8000-000000000001",
		"--index-path", idxBase)
	srv.Env = env
	if err := srv.Start(); err != nil {
		t.Fatalf("start lib share live: %v", err)
	}
	defer func() { cancel(); _ = srv.Wait() }()
	base := "http://" + addr
	waitHTTP(t, base+"/", 30*time.Second) // SPA root (embedded, unauthenticated) = readiness

	resp, err := http.Get(base + "/files/")
	if err != nil {
		t.Fatalf("GET /files/: %v", err)
	}
	resp.Body.Close()
	if resp.StatusCode == 401 {
		t.Fatalf("standalone --mode public /files/: got 401, expected open access")
	}
	t.Log("OK: standalone HTTP public — /files/ accessible without auth")
}

func TestStandalone_E2E_HTTPInviteOnly(t *testing.T) {

	// (c) HTTP invite-only: lib share grant --friend testt →
	//     lib share live --only-http --mode private (everything gated) → unauth /files/* = 401,
	//     then 200 via bearer header, then SPA renders after the /redeem cookie.
	bin := buildAccorderBinary(t)
	libDir, idxBase, env, alias := standaloneFixture(t)
	addr := freeLoopbackAddr(t)

	// Grant + serve share the same hermetic config + alias → clearnet-lib/<alias>.
	grantCmd := exec.Command(bin, "lib", "share", "grant", alias,
		"--friend", "testt", "--endpoint", "http://"+addr+"/")
	grantCmd.Env = env
	grantOut, err := grantCmd.Output()
	if err != nil {
		t.Fatalf("lib share grant: %v", err)
	}
	inv, err := torinvite.Decode(extractInvite(t, grantOut))
	if err != nil {
		t.Fatalf("decode invite: %v", err)
	}

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	srv := exec.CommandContext(ctx, bin, "lib", "share", "live", alias,
		"--calibrepath", libDir, "--only-http", "--mode", "private", "--listen", addr,
		"--librarian", "testm", "--libraryID", "00000000-0000-4000-8000-000000000001",
		"--index-path", idxBase)
	srv.Env = env
	if err := srv.Start(); err != nil {
		t.Fatalf("start lib share live: %v", err)
	}
	defer func() { cancel(); _ = srv.Wait() }()
	base := "http://" + addr
	waitHTTP(t, base+"/", 30*time.Second)

	coverPath := discoverCoverURL(t, libDir, "") // standalone: no per-member prefix
	coverURL := (&url.URL{Scheme: "http", Host: addr, Path: coverPath}).String()

	// 401 gate (unauthenticated)
	resp, err := http.Get(coverURL)
	if err != nil {
		t.Fatalf("GET %s: %v", coverURL, err)
	}
	resp.Body.Close()
	if resp.StatusCode != 401 {
		t.Fatalf("unauthenticated %s: expected 401, got %d", coverPath, resp.StatusCode)
	}
	t.Log("OK: standalone 401 gate confirmed")

	// Bearer header (rclone sync path) → 200
	req, _ := http.NewRequest("GET", coverURL, nil)
	req.Header.Set("Authorization", "Bearer "+inv.Auth.Token)
	resp2, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("bearer request: %v", err)
	}
	resp2.Body.Close()
	if resp2.StatusCode != 200 {
		t.Fatalf("bearer %s: expected 200, got %d", coverPath, resp2.StatusCode)
	}
	t.Log("OK: standalone bearer auth — 200 after token")

	// Cookie path (browser/SPA credential): GET /redeem?token= sets the
	// accorder_auth cookie; the jar then carries it to /files/ → 200. Asserted at
	// the HTTP level (the SPA render itself is covered by other browse tests).
	jar, _ := cookiejar.New(nil)
	client := &http.Client{Jar: jar}
	rr, err := client.Get(base + "/redeem?token=" + inv.Auth.Token)
	if err != nil {
		t.Fatalf("redeem: %v", err)
	}
	rr.Body.Close()
	if rr.StatusCode != 200 {
		t.Fatalf("redeem: expected 200, got %d", rr.StatusCode)
	}
	cr, err := client.Get(coverURL)
	if err != nil {
		t.Fatalf("cookie GET %s: %v", coverPath, err)
	}
	cr.Body.Close()
	if cr.StatusCode != 200 {
		t.Fatalf("cookie auth %s: expected 200, got %d", coverPath, cr.StatusCode)
	}
	t.Log("OK: standalone cookie auth — /redeem cookie authorizes /files/")
}

// Fedlib aggregate tests

func TestFedlib_E2E_ClearnetHTTPPublic(t *testing.T) {
	bin := buildAccorderBinary(t)
	aggDir, libs, env := setupFedlibAggregate(t, bin)
	addr := freeLoopbackAddr(t)

	// Issue a clearnet grant BEFORE serve starts (same hermetic config → same
	// registry dir), so tag-only auth on the public share can class it.
	// The action alias MUST match the serve's (registry dir is keyed by alias:
	// clearnet/<alias>/signing.key) or the grant lands in a different registry.
	grantCmd := exec.Command(bin, "fedlib", "share", "grant", fedlibE2EID,
		"--friend", "classy", "--endpoint", "http://"+addr+"/")
	grantCmd.Env = env
	grantOut, err := grantCmd.Output()
	if err != nil {
		t.Fatalf("grant: %v", err)
	}
	inv, err := torinvite.Decode(extractInvite(t, grantOut))
	if err != nil {
		t.Fatalf("decode invite: %v", err)
	}

	var serveLog bytes.Buffer
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	srv := exec.CommandContext(ctx, bin, "fedlib", "share", "live", fedlibE2EID,
		"--aggregate-path", aggDir, "--only-http", "--mode", "public", "--listen", addr)
	srv.Env = env
	srv.Stderr = &serveLog
	if err := srv.Start(); err != nil {
		t.Fatalf("start fedlib share live: %v", err)
	}
	defer func() { cancel(); _ = srv.Wait() }()
	base := "http://" + addr
	waitHTTP(t, base+"/_GENERATION", 30*time.Second)

	coverURL := discoverCoverURL(t, libs["MarcellMarsBooks"], "mmb")
	resp, err := http.Get(base + coverURL)
	if err != nil {
		t.Fatalf("GET %s: %v", coverURL, err)
	}
	resp.Body.Close()
	if resp.StatusCode != 200 {
		t.Fatalf("public %s: expected 200, got %d", coverURL, resp.StatusCode)
	}

	// Session classing (tag-only auth): all three classes are served identically
	// on a public share — only the serve-log class differs.
	doGET := func(mutate func(*http.Request)) int {
		req, _ := http.NewRequest("GET", base+coverURL, nil)
		if mutate != nil {
			mutate(req)
		}
		r, gerr := http.DefaultClient.Do(req)
		if gerr != nil {
			t.Fatalf("GET %s: %v", coverURL, gerr)
		}
		r.Body.Close()
		return r.StatusCode
	}
	if code := doGET(func(r *http.Request) {
		r.Header.Set("Authorization", "Bearer "+inv.Auth.Token)
	}); code != 200 {
		t.Fatalf("valid bearer on public: expected 200, got %d", code)
	}
	if code := doGET(func(r *http.Request) {
		r.Header.Set("Authorization", "Bearer garbage-token")
	}); code != 200 {
		t.Fatalf("mode contract violated: garbage bearer on public must still be 200, got %d", code)
	}
	if code := doGET(func(r *http.Request) {
		r.Header.Set("X-Accorder-Client", "lib-browse/e2e")
	}); code != 200 {
		t.Fatalf("announced client on public: expected 200, got %d", code)
	}

	// Stop the serve, then assert the log classed all three correctly.
	// (serveLog is only safe to read after Wait.)
	cancel()
	_ = srv.Wait()
	logs := serveLog.String()
	for _, want := range []string{
		"class=anon",                          // plain public fetch
		"session=grant:classy class=grant",    // valid bearer tagged
		"auth: tag invalid bearer credential", // garbage bearer warned, served anon
		"class=accorder",                      // announced client
	} {
		if !strings.Contains(logs, want) {
			t.Fatalf("serve log missing %q\n--- serve log ---\n%s", want, logs)
		}
	}
	t.Log("OK: fedlib HTTP public — open access + session classing (anon/grant/accorder)")
}

// TestFedlib_E2E_ClearnetHTTPInviteOnly asserts the invite-only file plane:
// under `--mode private` every route is gated, so an unauthenticated /files/
// fetch must 401 while all three credential carriers (bearer, redeem cookie)
// reach 200 — and the serve log must class the authenticated fetches to the
// granted friend. Mirrors the technique of its public sibling above.
func TestFedlib_E2E_ClearnetHTTPInviteOnly(t *testing.T) {
	bin := buildAccorderBinary(t)
	aggDir, libs, env := setupFedlibAggregate(t, bin)
	addr := freeLoopbackAddr(t)

	// Issue the grant BEFORE serve starts, in the same hermetic config so the
	// signing key matches. The action alias MUST be passed (registry dir is keyed
	// by alias: clearnet/<alias>/signing.key) or the grant lands in the default
	// registry while the serve reads clearnet/<fedlibE2EID>/.
	grantCmd := exec.Command(bin, "fedlib", "share", "grant", fedlibE2EID,
		"--friend", "testt", "--endpoint", "http://"+addr+"/")
	grantCmd.Env = env
	grantOut, err := grantCmd.Output() // stdout = blob (msg goes to stderr)
	if err != nil {
		t.Fatalf("grant: %v", err)
	}
	inv, err := torinvite.Decode(extractInvite(t, grantOut))
	if err != nil {
		t.Fatalf("decode invite: %v", err)
	}

	var serveLog bytes.Buffer
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	srv := exec.CommandContext(ctx, bin, "fedlib", "share", "live", fedlibE2EID,
		"--aggregate-path", aggDir, "--only-http", "--mode", "private", "--listen", addr)
	srv.Env = env
	srv.Stderr = &serveLog
	if err := srv.Start(); err != nil {
		t.Fatalf("start fedlib share live: %v", err)
	}
	defer func() { cancel(); _ = srv.Wait() }()
	base := "http://" + addr
	// Private mode gates /_GENERATION too (fedlibShareLive.go), so readiness must
	// carry the bearer — an unauthenticated poll would spin until the deadline.
	waitHTTPAuth(t, base+"/_GENERATION", inv.Auth.Token, 30*time.Second)

	// 401 gate (unauthenticated) — any /files/ path is rejected before file lookup.
	coverPath := discoverCoverURL(t, libs["MarcellMarsBooks"], "mmb")
	coverURL := (&url.URL{Scheme: "http", Host: addr, Path: coverPath}).String()
	resp, err := http.Get(coverURL)
	if err != nil {
		t.Fatalf("GET %s: %v", coverPath, err)
	}
	resp.Body.Close()
	if resp.StatusCode != 401 {
		t.Fatalf("unauthenticated %s: expected 401, got %d", coverPath, resp.StatusCode)
	}
	t.Log("OK: fedlib 401 gate confirmed")

	// Bearer header (rclone sync path) → 200
	req, _ := http.NewRequest("GET", coverURL, nil)
	req.Header.Set("Authorization", "Bearer "+inv.Auth.Token)
	resp2, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("bearer request: %v", err)
	}
	resp2.Body.Close()
	if resp2.StatusCode != 200 {
		t.Fatalf("bearer %s: expected 200, got %d", coverPath, resp2.StatusCode)
	}
	t.Log("OK: fedlib bearer auth — 200 after token")

	// Cookie path (browser/SPA credential): /redeem sets accorder_auth; the jar
	// then carries it to /files/ → 200. Asserted at the HTTP level.
	jar, _ := cookiejar.New(nil)
	client := &http.Client{Jar: jar}
	rr, err := client.Get(base + "/redeem?token=" + inv.Auth.Token)
	if err != nil {
		t.Fatalf("redeem: %v", err)
	}
	rr.Body.Close()
	if rr.StatusCode != 200 {
		t.Fatalf("redeem: expected 200, got %d", rr.StatusCode)
	}
	cr, err := client.Get(coverURL)
	if err != nil {
		t.Fatalf("cookie GET %s: %v", coverPath, err)
	}
	cr.Body.Close()
	if cr.StatusCode != 200 {
		t.Fatalf("cookie auth %s: expected 200, got %d", coverPath, cr.StatusCode)
	}
	t.Log("OK: fedlib cookie auth — /redeem cookie authorizes /files/")

	// A garbage bearer must NOT pass the gate: unlike a public share (where
	// withAuthTag serves invalid credentials anonymously), private wraps the
	// route in withAuth, which rejects.
	badReq, _ := http.NewRequest("GET", coverURL, nil)
	badReq.Header.Set("Authorization", "Bearer garbage-token")
	badResp, err := http.DefaultClient.Do(badReq)
	if err != nil {
		t.Fatalf("garbage bearer request: %v", err)
	}
	badResp.Body.Close()
	if badResp.StatusCode != 401 {
		t.Fatalf("mode contract violated: garbage bearer on private must 401, got %d", badResp.StatusCode)
	}

	// Stop the serve, then assert the log classed the authenticated fetches to
	// the granted friend. (serveLog is only safe to read after Wait.)
	cancel()
	_ = srv.Wait()
	logs := serveLog.String()
	for _, want := range []string{
		"auth: bearer ok friend=testt",    // bearer accepted by withAuth
		"auth: cookie ok friend=testt",    // redeem cookie accepted by withAuth
		"session=grant:testt class=grant", // authenticated fetches classed to the friend
	} {
		if !strings.Contains(logs, want) {
			t.Fatalf("serve log missing %q\n--- serve log ---\n%s", want, logs)
		}
	}
	t.Log("OK: fedlib HTTP invite-only — 401 gate + bearer/cookie auth + grant classing")
}

// waitHTTPAuth is waitHTTP with a bearer credential, for shares whose readiness
// endpoint is itself gated (--mode private gates /_GENERATION).
func waitHTTPAuth(t *testing.T, url, token string, d time.Duration) {
	t.Helper()
	deadline := time.Now().Add(d)
	for time.Now().Before(deadline) {
		req, _ := http.NewRequest("GET", url, nil)
		req.Header.Set("Authorization", "Bearer "+token)
		if resp, err := http.DefaultClient.Do(req); err == nil {
			resp.Body.Close()
			if resp.StatusCode == 200 {
				return
			}
		}
		time.Sleep(200 * time.Millisecond)
	}
	t.Fatalf("server did not serve %s (authenticated) within %s", url, d)
}

// fedlibE2EID is the federation id seeded into the hermetic descriptor that the
// fedlib aggregate serve now requires via its positional federation id.
const fedlibE2EID = "e2e"

func setupFedlibAggregate(t *testing.T, bin string) (string, map[string]string, []string) {
	t.Helper()
	libs := map[string]string{
		"MarcellMarsBooks": "/home/w/CalibreLibraries/MarcellMarsBooks",
		"FooBar":           "/home/w/CalibreLibraries/FooBar",
		"FigureItOut":      "/home/w/CalibreLibraries/FigureItOut",
	}
	for name, path := range libs {
		if _, err := os.Stat(path); err != nil {
			t.Skipf("library %s not found at %s", name, path)
		}
	}

	// Hermetic config dir: the descriptor seed, grant signing keys, and any alias
	// writes land in a throwaway XDG_CONFIG_HOME, never the real ~/.config.
	env := append(os.Environ(), "XDG_CONFIG_HOME="+t.TempDir())
	run := func(args ...string) {
		t.Helper()
		cmd := exec.Command(bin, args...)
		cmd.Env = env
		if out, err := cmd.CombinedOutput(); err != nil {
			t.Fatalf("accorder %s: %v\n%s", strings.Join(args, " "), err, out)
		}
	}

	// Build index for FooBar and FigureItOut if needed
	indexBuilds := map[string]struct{ librarian, uuid string }{
		"FooBar":      {"foobar-librarian", "33333333-3333-4333-8333-333333333333"},
		"FigureItOut": {"figureitout-librarian", "44444444-4444-4444-8444-444444444444"},
	}
	for name, meta := range indexBuilds {
		indexPath := filepath.Join(libs[name], "static", "library_index.zst")
		if _, err := os.Stat(indexPath); err != nil {
			idxBase := filepath.Join(libs[name], "static", "library_index")
			run("lib", "build",
				"--calibrepath", libs[name],
				"--librarian", meta.librarian,
				"--libraryID", meta.uuid,
				"--index", "--index-path", idxBase)
			t.Logf("built index for %s", name)
		}
	}

	aggDir := t.TempDir()

	run("fedlib", "members", "add", fedlibE2EID, "marcellmarsbooks-uuid",
		"--librarian", "testm", "--local-path", libs["MarcellMarsBooks"],
		"--prefix", "mmb", "--fedlib-path", aggDir)
	run("fedlib", "members", "add", fedlibE2EID, "foobar-uuid",
		"--librarian", "foobar-librarian", "--local-path", libs["FooBar"],
		"--prefix", "foobar", "--fedlib-path", aggDir)
	run("fedlib", "members", "add", fedlibE2EID, "figureitout-uuid",
		"--librarian", "figureitout-librarian", "--local-path", libs["FigureItOut"],
		"--prefix", "fio", "--fedlib-path", aggDir)

	run("fedlib", "build", "--output-path", aggDir)

	// Seed the federation descriptor the serve now requires (positional). The
	// aggregate is local (members.json under aggDir) so no bucket/creds are needed;
	// mode is left to each test's --mode flag / ResolvedMode default.
	run("fedlib", "config", "set", fedlibE2EID)

	return aggDir, libs, env
}

func discoverCoverURL(t *testing.T, libraryDir, prefix string) string {
	t.Helper()
	var coverURL string
	filepath.WalkDir(libraryDir, func(path string, d os.DirEntry, err error) error {
		if err != nil || coverURL != "" {
			return filepath.SkipDir
		}
		if d.Name() == "cover.jpg" {
			rel, _ := filepath.Rel(libraryDir, path)
			if prefix == "" {
				// Standalone serve mounts http.Dir(library) at /files/ (no per-member prefix).
				coverURL = "/files/" + filepath.ToSlash(rel)
			} else {
				coverURL = "/files/" + prefix + "/" + filepath.ToSlash(rel)
			}
			return filepath.SkipAll
		}
		return nil
	})
	if coverURL == "" {
		t.Skipf("no cover.jpg found in %s", libraryDir)
	}
	return coverURL
}
