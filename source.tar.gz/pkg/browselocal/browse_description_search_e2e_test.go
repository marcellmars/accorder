//go:build integration

package browselocal

import (
	"encoding/json"
	"fmt"
	"path/filepath"
	"slices"
	"sync"
	"testing"
	"time"

	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/launcher"
	"github.com/ysmood/gson"
)

// TestBrowse_E2E_DescriptionSearchWiring drives the real Svelte SPA (compiled
// bundle) headlessly and asserts the web-UI wiring for description search:
//
//  1. SearchBar probes session/capabilities and, when indexedFieldCount>=4,
//     promotes the search-mode dropdown to default "all" and offers
//     "description" (the conditional dropdown). At <4 the legacy modes stay.
//  2. Selecting "all"/"description" routes a ranked backend library/search
//     with the field passed through verbatim (FIELD_MAP passthrough), and the
//     returned book renders.
//
// The backend is mocked via backend_rpc so the test exercises the SPA wiring,
// not the Go search engine (that is covered by pkg/calibre unit tests).
func TestBrowse_E2E_DescriptionSearchWiring(t *testing.T) {
	for _, ifc := range []int{4, 3} {
		t.Run(fmt.Sprintf("indexedFieldCount=%d", ifc), func(t *testing.T) {
			dir := writeFixture(t)

			l := launcher.New().Headless(true)
			u, err := l.Launch()
			if err != nil {
				t.Fatalf("launcher: %v", err)
			}
			defer l.Cleanup()
			browser := rod.New().ControlURL(u)
			if err := browser.Connect(); err != nil {
				t.Fatalf("rod.Connect: %v", err)
			}
			defer browser.Close()
			page := browser.MustPage("about:blank")
			defer page.Close()

			var mu sync.Mutex
			var searchFields []string
			page.MustExpose("backend_rpc", func(arg gson.JSON) (interface{}, error) {
				var c rpcCall
				if err := json.Unmarshal([]byte(arg.Str()), &c); err != nil {
					return nil, err
				}
				switch c.Service + "/" + c.Method {
				case "session/mode":
					return "browse", nil
				case "session/reachability":
					return map[string]string{"status": "connected"}, nil
				case "session/capabilities":
					return map[string]uint32{"indexedFieldCount": uint32(ifc)}, nil
				case "library/settings/get":
					return map[string]any{"library_path": "/tmp/lib", "librarian": "test"}, nil
				case "library/books":
					return bookListResult("b1", "Plain Book"), nil
				case "library/search":
					field, _ := c.Args["field"].(string)
					mu.Lock()
					searchFields = append(searchFields, field)
					mu.Unlock()
					// Encode the field in the title so each mode's render is distinct —
					// otherwise the second iteration's wait passes against the first
					// iteration's stale DOM and proves nothing.
					return bookListResult("q-"+field, "Result for "+field), nil
				}
				return map[string]any{"_items": []any{}}, nil
			})

			watchConsole(t, page)

			base := "file://" + filepath.Join(dir, "BROWSE_LIBRARY.html")
			if err := page.Navigate(base + "#/?t=l"); err != nil {
				t.Fatalf("navigate: %v", err)
			}
			page.Timeout(15 * time.Second).MustWait(`() => document.querySelector('table') !== null`)

			modeButtons := func() string {
				return `[...document.querySelectorAll('div.dropdown button')].map(b => b.textContent.trim().toUpperCase())`
			}
			dropdownItems := `[...document.querySelectorAll('li.dropdown-li')].map(e => e.textContent.trim().toUpperCase())`

			if ifc >= 4 {
				// capabilities>=4 → default mode promoted to ALL, DESCRIPTION offered.
				page.Timeout(10 * time.Second).MustWait(`() => ` + modeButtons() + `.includes('ALL')`)
				if !page.MustEval(`() => ` + dropdownItems + `.includes('DESCRIPTION')`).Bool() {
					t.Fatalf("indexedFieldCount=%d: DESCRIPTION mode not offered in dropdown", ifc)
				}

				// Each new mode routes a ranked backend search with the field intact,
				// and the returned book renders.
				for _, mode := range []string{"all", "description"} {
					page.MustEval(fmt.Sprintf(`() => { location.hash = '#/search/%s/quantum' }`, mode))
					page.Timeout(10 * time.Second).MustWait(fmt.Sprintf(
						`() => document.body && document.body.innerText.includes('Result for %s')`, mode))
				}

				mu.Lock()
				got := slices.Clone(searchFields)
				mu.Unlock()
				if !slices.Contains(got, "all") || !slices.Contains(got, "description") {
					t.Fatalf("backend did not receive all+description search fields; got %v", got)
				}
			} else {
				// capabilities<4 → legacy dropdown: default AUTHORS, no ALL/DESCRIPTION.
				page.Timeout(10 * time.Second).MustWait(`() => ` + modeButtons() + `.includes('AUTHORS')`)
				offered := page.MustEval(`() => ` + dropdownItems + `.concat(` + modeButtons() + `)`).Arr()
				for _, it := range offered {
					if s := it.Str(); s == "DESCRIPTION" || s == "ALL" {
						t.Fatalf("indexedFieldCount=%d: %q offered without descriptions; all=%v", ifc, s, offered)
					}
				}
			}
		})
	}
}

// bookListResult builds the _items/_meta/_links envelope the SPA expects from
// library/books and library/search, carrying one book with the given id+title.
func bookListResult(id, title string) map[string]any {
	return map[string]any{
		"_items": []map[string]any{{
			"_id": id, "title": title, "authors": []string{"Author"},
			"librarian": "test", "library_url": "", "cover_url": "",
			"tags": []string{}, "formats": []map[string]any{}, "last_modified": "2024-01-01",
		}},
		"_meta":  map[string]any{"total": 1, "page": 1, "max_results": 48},
		"_links": map[string]any{"self": map[string]any{"href": "/books"}},
	}
}
