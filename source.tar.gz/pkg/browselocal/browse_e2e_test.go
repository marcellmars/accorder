//go:build integration

package browselocal

import (
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/launcher"
	"github.com/go-rod/rod/lib/launcher/flags"
	"github.com/ysmood/gson"
)

// e2eResponder is a stand-in for librarySession that returns canned
// responses to backend_rpc calls and records every invocation. The
// test asserts on the recorded shape.
type e2eResponder struct {
	mu              sync.Mutex
	autocompleteHit chan struct{}
	calls           []rpcCall
}

func newResponder() *e2eResponder {
	return &e2eResponder{
		autocompleteHit: make(chan struct{}, 32),
	}
}

func (r *e2eResponder) handle(arg gson.JSON) (interface{}, error) {
	var c rpcCall
	if err := json.Unmarshal([]byte(arg.Str()), &c); err != nil {
		return nil, err
	}
	r.mu.Lock()
	r.calls = append(r.calls, c)
	r.mu.Unlock()

	switch c.Service + "/" + c.Method {
	case "session/mode":
		return "browse", nil
	case "session/reachability":
		return map[string]string{"status": "connected"}, nil
	// NEW gate: configured = library_path && librarian. Without both set the
	// SETTINGS WALL replaces the table and these e2e tests never render rows.
	case "library/settings/get":
		return map[string]any{"library_path": "/tmp/lib", "librarian": "test"}, nil
	case "library/autocomplete":
		select {
		case r.autocompleteHit <- struct{}{}:
		default:
		}
		// Fuzzy-fallback shape: for the one-edit typo "foucalt" the server
		// admits only the correctly-spelled entity, which does NOT contain
		// the typed substring — the UI must exempt it from local narrowing.
		if pf, _ := c.Args["prefix"].(string); strings.Contains(pf, "foucalt") {
			return map[string]any{"_items": []string{"Foucault, Michel"}}, nil
		}
		return map[string]any{"_items": []string{"Foucault, Michel", "Foucault, History", "Foucault, Power"}}, nil
	case "library/search":
		return map[string]any{
			"_items": []map[string]any{
				{
					"_id": "search-result-1", "title": "Discipline and Punish",
					"authors": []string{"Michel Foucault"}, "year": "1975",
					"librarian": "test", "library_url": "", "cover_url": "",
					"tags":    []string{},
					"formats": []map[string]any{},
					"pubdate": "1975-01-01", "abstract": "",
					"last_modified": "2025-01-01",
				},
				{
					"_id": "search-result-2", "title": "The Order of Things",
					"authors": []string{"Michel Foucault"}, "year": "1966",
					"librarian": "test", "library_url": "", "cover_url": "",
					"tags":    []string{},
					"formats": []map[string]any{},
					"pubdate": "1966-01-01", "abstract": "",
					"last_modified": "2025-01-01",
				},
			},
			"_meta":  map[string]any{"total": 2, "page": 1, "max_results": 48},
			"_links": map[string]any{"self": map[string]any{"href": "search/titles/foucault"}},
		}, nil
	}
	return map[string]any{"_items": []any{}}, nil
}

func (r *e2eResponder) waitAutocomplete(t *testing.T, d time.Duration) {
	t.Helper()
	select {
	case <-r.autocompleteHit:
	case <-time.After(d):
		r.dumpCalls(t)
		t.Fatalf("no library/autocomplete call within %s", d)
	}
}

func (r *e2eResponder) dumpCalls(t *testing.T) {
	r.mu.Lock()
	defer r.mu.Unlock()
	var lines []string
	for _, c := range r.calls {
		args, _ := json.Marshal(c.Args)
		lines = append(lines, fmt.Sprintf("  %s/%s %s", c.Service, c.Method, args))
	}
	t.Logf("backend_rpc calls so far (%d):\n%s", len(r.calls), strings.Join(lines, "\n"))
}

func copyFile(t *testing.T, dst, src string) {
	t.Helper()
	in, err := os.Open(src)
	if err != nil {
		t.Fatalf("open %s: %v", src, err)
	}
	defer in.Close()
	if err := os.MkdirAll(filepath.Dir(dst), 0755); err != nil {
		t.Fatal(err)
	}
	out, err := os.Create(dst)
	if err != nil {
		t.Fatalf("create %s: %v", dst, err)
	}
	defer out.Close()
	if _, err := io.Copy(out, in); err != nil {
		t.Fatal(err)
	}
}

// fixtureData1 returns a minimal portable data1.js with three books.
// last_modified-descending so App.svelte's sort doesn't reorder unpredictably.
func fixtureData1() string {
	books := []map[string]any{
		{"_id": "front-1", "title": "Front Book A", "authors": []string{"Auth A"}, "year": "2024", "librarian": "test", "library_url": "", "cover_url": "", "tags": []string{}, "formats": []map[string]any{}, "pubdate": "2024-01-01", "abstract": "", "last_modified": "2024-12-01"},
		{"_id": "front-2", "title": "Front Book B", "authors": []string{"Auth B"}, "year": "2023", "librarian": "test", "library_url": "", "cover_url": "", "tags": []string{}, "formats": []map[string]any{}, "pubdate": "2023-06-01", "abstract": "", "last_modified": "2023-11-15"},
		{"_id": "front-3", "title": "Front Book C", "authors": []string{"Auth C"}, "year": "2022", "librarian": "test", "library_url": "", "cover_url": "", "tags": []string{}, "formats": []map[string]any{}, "pubdate": "2022-03-01", "abstract": "", "last_modified": "2022-09-01"},
	}
	b, _ := json.Marshal(map[string]any{"portable": true, "books": books})
	return "CALIBRE_BOOKS1=" + string(b) + ";"
}

func writeFixture(t *testing.T) string {
	t.Helper()
	dir := t.TempDir()
	copyFile(t, filepath.Join(dir, "static", "js", "bundle.js"), "../calibre/embResources/static/js/bundle.js")
	copyFile(t, filepath.Join(dir, "static", "css", "bundle.css"), "../calibre/embResources/static/css/bundle.css")
	if err := os.WriteFile(filepath.Join(dir, "static", "data1.js"), []byte(fixtureData1()), 0644); err != nil {
		t.Fatal(err)
	}
	for i := 2; i <= 8; i++ {
		stub := fmt.Sprintf("CALIBRE_BOOKS%d={books:[]};", i)
		if err := os.WriteFile(filepath.Join(dir, "static", fmt.Sprintf("data%d.js", i)), []byte(stub), 0644); err != nil {
			t.Fatal(err)
		}
	}
	html := `<!doctype html>
<html><head>
<meta charset='utf-8'>
<meta name='viewport' content='width=device-width'>
<title>Memory of the World Library</title>
<link rel='stylesheet' href='static/css/bundle.css'>
<script src='static/data1.js'></script>
<script defer src='static/js/bundle.js'></script>
</head><body></body></html>`
	if err := os.WriteFile(filepath.Join(dir, "BROWSE_LIBRARY.html"), []byte(html), 0644); err != nil {
		t.Fatal(err)
	}
	return dir
}

// TestBrowse_E2E_PaginationClick_Headed runs the same pagination
// reproducer in HEADED mode against a real Chromium window — last
// resort to chase a bug that headless e2e doesn't surface. Auto-skips
// without a display.
func TestBrowse_E2E_PaginationClick_Headed(t *testing.T) {
	if os.Getenv("DISPLAY") == "" && os.Getenv("WAYLAND_DISPLAY") == "" {
		t.Skip("no display")
	}
	runPaginationClickTest(t, false)
}

// TestBrowse_E2E_PaginationClick verifies that clicking the rendered
// "next >>" link triggers a new library/search call with offset=48
// (page 2) and updates the table. Reproduces the user-reported bug
// "clicking next does nothing".
//

// Applies the full production hardening flag set (--proxy-server,
// --disable-quic, --disable-ipv6, --webrtc-ip-handling-policy, etc.)
// so the test exercises the same Chromium configuration the friend
// hits in real use — hash navigation must not depend on flags that
// govern HTTP/network behavior.
func TestBrowse_E2E_PaginationClick(t *testing.T) {
	runPaginationClickTest(t, true)
}

func runPaginationClickTest(t *testing.T, headless bool) {
	dir := writeFixture(t)

	l := launcher.New().Headless(headless).
		Set(flags.Flag("disable-extensions")).
		Set(flags.Flag("disable-plugins")).
		Set(flags.Flag("disable-sync")).
		Set(flags.Flag("no-first-run")).
		Set(flags.Flag("no-default-browser-check")).
		Set(flags.Flag("disable-background-networking")).
		Set(flags.Flag("disable-default-apps")).
		Set(flags.Flag("disable-component-update")).
		Set(flags.Flag("disable-domain-reliability")).
		Set(flags.Flag("disable-features"), "OptimizationHints,MediaRouter,PostQuantumKyber").
		Set(flags.Flag("safebrowsing-disable-auto-update")).
		Set(flags.Flag("disable-quic")).
		Set(flags.Flag("disable-ipv6")).
		Set(flags.Flag("webrtc-ip-handling-policy"), "disable_non_proxied_udp").
		Set(flags.Flag("metrics-recording-only")).
		Set(flags.Flag("no-pings")).
		Set(flags.Flag("proxy-server"), "socks5://127.0.0.1:1").
		Set(flags.Flag("proxy-bypass-list"), "<-loopback>")
	u, err := l.Launch()
	if err != nil {
		t.Fatalf("launcher: %v", err)
	}
	defer l.Cleanup()

	browser := rod.New().ControlURL(u)
	if err := browser.Connect(); err != nil {
		t.Fatalf("rod.Connect: %v", err)
	}
	defer browser.Close()

	page := browser.MustPage("about:blank")
	defer page.Close()

	// Responder that returns paginated results — 101 hits total, 48 per page.
	// Page 1 has next; page 2 has prev+next; page 3 has prev only.
	rec := newResponder()
	page.MustExpose("backend_rpc", func(arg gson.JSON) (interface{}, error) {
		var c rpcCall
		if err := json.Unmarshal([]byte(arg.Str()), &c); err != nil {
			return nil, err
		}
		rec.mu.Lock()
		rec.calls = append(rec.calls, c)
		rec.mu.Unlock()
		switch c.Service + "/" + c.Method {
		case "session/mode":
			return "browse", nil
		case "session/reachability":
			return map[string]string{"status": "connected"}, nil
		// NEW gate: both settings fields set so the table renders (no wall).
		case "library/settings/get":
			return map[string]any{"library_path": "/tmp/lib", "librarian": "test"}, nil
		case "library/autocomplete":
			return map[string]any{"_items": []string{}}, nil
		case "library/search":
			offset := 0
			if v, ok := c.Args["offset"].(float64); ok {
				offset = int(v)
			}
			query, _ := c.Args["query"].(string)
			field, _ := c.Args["field"].(string)
			total := 101
			limit := 48
			pageNum := offset/limit + 1
			totalPages := (total + limit - 1) / limit

			// Synthesize books for this page.
			start := offset
			end := offset + limit
			if end > total {
				end = total
			}
			items := []map[string]any{}
			for i := start; i < end; i++ {
				items = append(items, map[string]any{
					"_id":           fmt.Sprintf("book-%d", i),
					"title":         fmt.Sprintf("Book Number %d", i),
					"authors":       []string{"Test Author"},
					"year":          "2024",
					"librarian":     "test",
					"library_url":   "",
					"cover_url":     "",
					"tags":          []string{},
					"formats":       []map[string]any{},
					"pubdate":       "2024-01-01",
					"abstract":      "",
					"last_modified": "2024-12-01",
				})
			}
			base := "/search/" + field + "/" + query
			pageURL := func(p int) string {
				if p <= 1 {
					return base
				}
				return base + "/page/" + fmt.Sprint(p)
			}
			links := map[string]map[string]string{
				"self": {"href": pageURL(pageNum)},
			}
			if pageNum > 1 {
				links["prev"] = map[string]string{"href": pageURL(pageNum - 1)}
				links["first"] = map[string]string{"href": pageURL(1)}
			}
			if pageNum < totalPages {
				links["next"] = map[string]string{"href": pageURL(pageNum + 1)}
				links["last"] = map[string]string{"href": pageURL(totalPages)}
			}
			return map[string]any{
				"_items": items,
				"_meta":  map[string]any{"total": total, "page": pageNum, "max_results": limit},
				"_links": links,
			}, nil
		}
		return map[string]any{"_items": []any{}}, nil
	})

	watchConsole(t, page)

	fileURL := "file://" + filepath.Join(dir, "BROWSE_LIBRARY.html") + "#/search/tags/rulingclassstudies?t=l"
	if err := page.Navigate(fileURL); err != nil {
		t.Fatalf("navigate: %v", err)
	}

	page.Timeout(15 * time.Second).MustWait(`() => document.querySelector('table tbody tr') !== null && document.querySelectorAll('table tbody tr').length > 3`)

	// At this point page 1 is rendered. NavBar's "next >>" link should be active.
	// Find it and click.
	// Click the actual <a> element — exercising the same code path as a
	// user click, not a programmatic location.hash assignment (the two
	// can diverge if a click handler somewhere preventDefaults or if the
	// element isn't reachable in the DOM).
	clicked := page.MustEval(`() => {
		const links = document.querySelectorAll('a');
		for (const a of links) {
			if (a.textContent.trim().match(/next/i) && a.getAttribute('href') && a.getAttribute('href').includes('page/2')) {
				a.click();
				return a.getAttribute('href');
			}
		}
		return "";
	}`).Str()
	if clicked == "" {
		t.Fatal("no <a> with href containing 'page/2' and text 'next' found — next link not rendered")
	}
	t.Logf("clicked next link: %s", clicked)

	// Wait for the second library/search call with offset=48.
	deadline := time.Now().Add(5 * time.Second)
	var page2Call *rpcCall
	for time.Now().Before(deadline) {
		rec.mu.Lock()
		for i := len(rec.calls) - 1; i >= 0; i-- {
			c := rec.calls[i]
			if c.Method != "search" {
				continue
			}
			if off, _ := c.Args["offset"].(float64); int(off) == 48 {
				page2Call = &c
				break
			}
		}
		rec.mu.Unlock()
		if page2Call != nil {
			break
		}
		time.Sleep(50 * time.Millisecond)
	}
	if page2Call == nil {
		rec.dumpCalls(t)
		t.Fatal("clicking 'next >>' did not trigger a library/search with offset=48 — the click chain is broken")
	}

	// Verify the table updated to page 2 contents.
	page.Timeout(5 * time.Second).MustWait(`() => {
		const rows = document.querySelectorAll('table tbody tr');
		for (const r of rows) {
			if (r.textContent.includes("Book Number 48")) return true;
		}
		return false;
	}`)
}

// TestBrowse_E2E_BookModalClick verifies that clicking a book title in
// the search results opens a BookModal populated with that book's data
// — the second user-reported bug.
func TestBrowse_E2E_BookModalClick(t *testing.T) {
	dir := writeFixture(t)

	l := launcher.New().Headless(true)
	u, err := l.Launch()
	if err != nil {
		t.Fatalf("launcher: %v", err)
	}
	defer l.Cleanup()
	browser := rod.New().ControlURL(u)
	if err := browser.Connect(); err != nil {
		t.Fatalf("rod.Connect: %v", err)
	}
	defer browser.Close()

	page := browser.MustPage("about:blank")
	defer page.Close()

	rec := newResponder()
	page.MustExpose("backend_rpc", func(arg gson.JSON) (interface{}, error) {
		var c rpcCall
		if err := json.Unmarshal([]byte(arg.Str()), &c); err != nil {
			return nil, err
		}
		rec.mu.Lock()
		rec.calls = append(rec.calls, c)
		rec.mu.Unlock()
		switch c.Service + "/" + c.Method {
		case "session/mode":
			return "browse", nil
		// NEW gate: both settings fields set so the table renders (no wall).
		case "library/settings/get":
			return map[string]any{"library_path": "/tmp/lib", "librarian": "test"}, nil
		case "library/search":

			// Return a single result not in CALIBRE_BOOKS1 — clicking it must
			// fetch the book via backend, not from data1.js corpus.
			return map[string]any{
				"_items": []map[string]any{
					{
						"_id": "remote-book-xyz", "title": "Remote Only Title",
						"authors":     []string{"Test Author"},
						"library_url": "",
						"cover_url":   "",
						"tags":        []string{},
						"formats":     []map[string]any{},
						"pubdate":     "2024-01-01", "abstract": "Detail abstract.",
						"last_modified": "2024-12-01",
					},
				},
				"_meta":  map[string]any{"total": 1, "page": 1, "max_results": 48},
				"_links": map[string]map[string]string{"self": {"href": "/search/tags/x"}},
			}, nil
		case "library/book":
			id, _ := c.Args["id"].(string)
			if id == "remote-book-xyz" {
				return map[string]any{
					"_id": "remote-book-xyz", "title": "Remote Only Title",
					"authors":     []string{"Test Author"},
					"library_url": "",
					"cover_url":   "",
					"tags":        []string{},
					"formats":     []map[string]any{},
					"pubdate":     "2024-01-01", "abstract": "Detail abstract.",
					"last_modified": "2024-12-01",
					"publisher":     "Test Pub",
					"year":          "2024",
				}, nil
			}
			return nil, fmt.Errorf("unknown id %q", id)
		}
		return map[string]any{"_items": []any{}}, nil
	})

	watchConsole(t, page)

	fileURL := "file://" + filepath.Join(dir, "BROWSE_LIBRARY.html") + "#/search/tags/x?t=l"
	if err := page.Navigate(fileURL); err != nil {
		t.Fatalf("navigate: %v", err)
	}

	// Wait for the result row to appear.
	page.Timeout(15 * time.Second).MustWait(`() => {
		const rows = document.querySelectorAll('table tbody tr');
		for (const r of rows) {
			if (r.textContent.includes("Remote Only Title")) return true;
		}
		return false;
	}`)

	// Click the book title link.
	page.MustEval(`() => {
		const links = document.querySelectorAll('a[href^="#/book/"]');
		for (const a of links) {
			if (a.textContent.includes("Remote Only Title")) {
				a.click();
				return;
			}
		}
		throw new Error("no book link found");
	}`)

	// Wait for BookModal to render with the book title visible in modal scope.
	page.Timeout(5 * time.Second).MustWait(`() => {
		const modal = document.querySelector('.modal');
		if (!modal) return false;
		return modal.textContent.includes("Remote Only Title");
	}`)
}

// TestBrowse_E2E_ListAutocompleteSearch loads BROWSE_LIBRARY.html from a
// real file:// fixture, forces list view via the t=l hash, exposes
// backend_rpc to a recorder/responder, and verifies that typing in the
// search bar triggers autocomplete RPCs and that a search routes through.
//

// Mirrors the production browse flow exactly: file:// navigation, the
// embedded bundle.js, real svelte runtime — only backend_rpc is stubbed.
func TestBrowse_E2E_ListAutocompleteSearch(t *testing.T) {
	dir := writeFixture(t)

	l := launcher.New().Headless(true)
	u, err := l.Launch()
	if err != nil {
		t.Fatalf("launcher: %v", err)
	}
	defer l.Cleanup()

	browser := rod.New().ControlURL(u)
	if err := browser.Connect(); err != nil {
		t.Fatalf("rod.Connect: %v", err)
	}
	defer browser.Close()

	// Open about:blank first, expose binding, THEN navigate to file://.
	// rod's Expose registers a CDP Runtime.addBinding (survives navigation)
	// and also re-adds the JS shim via Page.AddScriptToEvaluateOnNewDocument
	// so window.backend_rpc is in scope before any page script runs.
	page := browser.MustPage("about:blank")
	defer page.Close()

	resp := newResponder()
	page.MustExpose("backend_rpc", resp.handle)
	watchConsole(t, page)

	fileURL := "file://" + filepath.Join(dir, "BROWSE_LIBRARY.html") + "#/?t=l"
	if err := page.Navigate(fileURL); err != nil {
		t.Fatalf("navigate: %v", err)
	}

	// Wait for the svelte app to mount and render the LibraryTable.
	// In list view (t=true) the LibraryTable component renders a <table>.
	page.Timeout(15 * time.Second).MustWait(`() => document.querySelector('table') !== null`)

	// Sanity: backend is available to the JS world.
	hasBackend := page.MustEval(`() => typeof window.backend_rpc === 'function'`).Bool()
	if !hasBackend {
		t.Fatal("window.backend_rpc not set after navigation — MustExpose did not survive")
	}

	// Verify we are in list view (LibraryTable rendered, no LibraryCovers grid).
	tableRows := page.MustEval(`() => document.querySelectorAll('table tr').length`).Int()
	if tableRows < 2 { // header + at least one body row
		t.Fatalf("list view did not render books from data1.js: only %d <tr> in DOM", tableRows)
	}

	// Type into the search input. SearchBar uses on:keyup and svelte's
	// $: fetchCompletion(selection) reactive runs after every selection
	// change. With hasAccorderBackend() true, the 4-char gate is bypassed.
	input := page.MustElement(`input[aria-label="Search"]`)
	input.MustClick()
	input.MustInput("hist")

	// At least one library/autocomplete must reach the responder.
	resp.waitAutocomplete(t, 5*time.Second)

	// Assert the call shape: field=titles, prefix non-empty.
	resp.mu.Lock()
	var lastAuto *rpcCall
	for i := len(resp.calls) - 1; i >= 0; i-- {
		if resp.calls[i].Method == "autocomplete" {
			lastAuto = &resp.calls[i]
			break
		}
	}
	resp.mu.Unlock()
	if lastAuto == nil {
		t.Fatal("autocomplete call vanished from recorder")
	}
	if pf, _ := lastAuto.Args["prefix"].(string); pf == "" {
		t.Errorf("autocomplete prefix empty; args=%v", lastAuto.Args)
	}
	if f, _ := lastAuto.Args["field"].(string); f == "" {
		t.Errorf("autocomplete field empty; args=%v", lastAuto.Args)
	}

	// Verify suggestions made it into the DOM. Candidate list shows when
	// candidates non-empty; <li> elements live under #candidateList.
	page.Timeout(5 * time.Second).MustWait(`() => {
		const lis = document.querySelectorAll('#candidateList li');
		for (const li of lis) {
			if (li.textContent.includes("Foucault")) return true;
		}
		return false;
	}`)

	// Trigger a search by setting location.hash — same path SearchBar's
	// search() function uses. dispatchHash() calls fetchBooks which routes
	// through fetchVia → backend_rpc.
	//

	// Multiple library/search calls have already fired during mount (the
	// initial "books" URL + each data2..8.js load callback re-runs
	// dispatchHash). We poll for one whose query contains "foucault"
	// instead of trusting the last call.
	page.MustEval(`() => { location.hash = "#/search/titles/foucault?t=l"; }`)

	deadline := time.Now().Add(5 * time.Second)
	var foucaultCall *rpcCall
	for time.Now().Before(deadline) {
		resp.mu.Lock()
		for i := len(resp.calls) - 1; i >= 0; i-- {
			c := resp.calls[i]
			if c.Method != "search" {
				continue
			}
			if q, _ := c.Args["query"].(string); strings.Contains(strings.ToLower(q), "foucault") {
				foucaultCall = &c
				break
			}
		}
		resp.mu.Unlock()
		if foucaultCall != nil {
			break
		}
		time.Sleep(50 * time.Millisecond)
	}
	if foucaultCall == nil {
		resp.dumpCalls(t)
		t.Fatal("no library/search call with query containing 'foucault' within 5s")
	}
	if f, _ := foucaultCall.Args["field"].(string); f != "title" {
		t.Errorf("search field = %q, want \"title\"; args=%v", f, foucaultCall.Args)
	}

	// Verify the search results rendered in the list view.
	page.Timeout(5 * time.Second).MustWait(`() => {
		const rows = document.querySelectorAll('table tbody tr');
		for (const r of rows) {
			if (r.textContent.includes("Discipline and Punish")) return true;
		}
		return false;
	}`)

	// Fuzzy-fallback UI case: type the one-edit typo "foucalt". The stubbed
	// server admits only "Foucault, Michel", which does NOT contain the
	// typed substring — pre-exemption, SearchBar's local narrowing filter
	// would drop it. It must be visible because it is in the latest server
	// response. Meanwhile the candidates cached from the earlier "hist"
	// fetch ("Foucault, History", "Foucault, Power") are NOT in the latest
	// response and don't substring-match "foucalt": narrowing must still
	// hide them.
	input.MustSelectAllText()
	input.MustInput("foucalt")
	resp.waitAutocomplete(t, 5*time.Second)
	page.Timeout(5 * time.Second).MustWait(`() => {
		const lis = document.querySelectorAll('#candidateList li');
		let fuzzyVisible = false;
		for (const li of lis) {
			if (li.textContent.includes("Foucault, History")) return false; // cached, must stay narrowed
			if (li.textContent.includes("Foucault, Power")) return false;   // cached, must stay narrowed
			if (li.textContent.includes("Foucault, Michel")) fuzzyVisible = true;
		}
		return fuzzyVisible;
	}`)
}
