package browselocal

import (
	"os"
	"path/filepath"
	"testing"
)

// TestRemoveDownloadFiles verifies that clearing a queue entry deletes that
// book's downloaded files (not just its .rcpartial fragments), leaves siblings
// alone, and never deletes the download root for an item with no safe subpath.
func TestRemoveDownloadFiles(t *testing.T) {
	root := t.TempDir()
	mkBook := func(dirPath, file string) (*queueItem, string) {
		it := &queueItem{BookID: dirPath, DirPath: dirPath}
		dir := it.localPath(root)
		if err := os.MkdirAll(dir, 0o755); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(filepath.Join(dir, file), []byte("x"), 0o644); err != nil {
			t.Fatal(err)
		}
		return it, dir
	}

	target, targetDir := mkBook("Author/Title (1)", "book.epub")
	_, siblingDir := mkBook("Author/Other (2)", "keep.epub")

	// clearing the target removes its whole directory ...
	removeDownloadFiles(root, target)
	if _, err := os.Stat(targetDir); !os.IsNotExist(err) {
		t.Fatalf("target book dir should be deleted, stat err = %v", err)
	}
	// ... but the sibling book under the same author survives.
	if _, err := os.Stat(filepath.Join(siblingDir, "keep.epub")); err != nil {
		t.Fatalf("sibling book must survive, got %v", err)
	}

	// guard: an item with an empty DirPath (localPath == root) must NOT delete
	// the whole download directory — it falls back to cleaning only partials.
	removeDownloadFiles(root, &queueItem{BookID: "z"})
	if _, err := os.Stat(root); err != nil {
		t.Fatalf("download root must survive an empty-DirPath item, got %v", err)
	}
	if _, err := os.Stat(siblingDir); err != nil {
		t.Fatalf("sibling must survive the guard fallback, got %v", err)
	}
}
