//go:build integration

package browselocal

import (
	"net/url"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/launcher"
	"github.com/go-rod/rod/lib/proto"
)

// consoleAllowlist holds substrings of benign browser console.error /
// exception messages that must NOT fail a test. Keep this list tight: only
// add an entry with a comment explaining why the message is genuinely benign.
// A `file:///books` "Failed to fetch" must NOT be on this list — that is
// exactly the class of bug this gate exists to catch.
var consoleAllowlist = []string{
	// favicon.ico is requested by Chromium for every file:// page; there is no
	// favicon on the bare BROWSE_LIBRARY.html harness so the fetch 404s.
	"favicon",
}

// watchConsole subscribes to the page's Runtime console + exception events
// and fails the test (via t.Cleanup) if any browser console.error or
// uncaught exception fired that is not on consoleAllowlist. This closes the
// gap where a green e2e suite missed real frontend failures (e.g. a
// `file:///books` "Failed to fetch" that rendered zero books).
//
// It uses go-rod's CDP event API: proto.RuntimeConsoleAPICalled with
// Type==error, and proto.RuntimeExceptionThrown. proto.RuntimeEnable is
// called first so the Runtime domain emits these events.
func watchConsole(t *testing.T, page *rod.Page) {
	t.Helper()
	cw := startConsoleWatch(t, page)
	t.Cleanup(func() {
		if probs := cw.problems(); len(probs) > 0 {
			t.Errorf("watchConsole: %d browser console error(s)/exception(s) fired:\n  %s",
				len(probs), strings.Join(probs, "\n  "))
		}
	})
}

// consoleWatch is the testable core behind watchConsole: it subscribes to the
// CDP Runtime console + exception events and accumulates non-allowlisted
// problems. watchConsole turns a non-empty problems list into a test failure;
// the gate's own self-test (TestConsoleGate_CatchesError) inspects problems()
// directly to prove the subscription actually fires.
type consoleWatch struct {
	mu   sync.Mutex
	hits []string
}

func (cw *consoleWatch) problems() []string {
	cw.mu.Lock()
	defer cw.mu.Unlock()
	out := make([]string, len(cw.hits))
	copy(out, cw.hits)
	return out
}

func startConsoleWatch(t *testing.T, page *rod.Page) *consoleWatch {
	t.Helper()

	if err := (proto.RuntimeEnable{}).Call(page); err != nil {
		t.Fatalf("watchConsole: enable Runtime domain: %v", err)
	}

	cw := &consoleWatch{}

	allowed := func(msg string) bool {
		low := strings.ToLower(msg)
		for _, a := range consoleAllowlist {
			if strings.Contains(low, strings.ToLower(a)) {
				return true
			}
		}
		return false
	}

	go page.EachEvent(
		func(e *proto.RuntimeConsoleAPICalled) {
			if e.Type != proto.RuntimeConsoleAPICalledTypeError {
				return
			}
			var parts []string
			for _, arg := range e.Args {
				if arg == nil {
					continue
				}
				if s := arg.Value.Str(); s != "" {
					parts = append(parts, s)
				} else if arg.Description != "" {
					parts = append(parts, arg.Description)
				}
			}
			msg := strings.Join(parts, " ")
			if allowed(msg) {
				return
			}
			cw.mu.Lock()
			cw.hits = append(cw.hits, "console.error: "+msg)
			cw.mu.Unlock()
		},
		func(e *proto.RuntimeExceptionThrown) {
			msg := ""
			if e.ExceptionDetails != nil {
				msg = e.ExceptionDetails.Text
				if e.ExceptionDetails.Exception != nil {
					if d := e.ExceptionDetails.Exception.Description; d != "" {
						msg = d
					}
				}
			}
			if allowed(msg) {
				return
			}
			cw.mu.Lock()
			cw.hits = append(cw.hits, "uncaught exception: "+msg)
			cw.mu.Unlock()
		},
	)()

	return cw
}

// TestConsoleGate_CatchesError proves the gate actually fires: it subscribes
// the real consoleWatch to a page, emits a console.error and throws an
// uncaught exception from page JS, and asserts both were captured. It also
// asserts a "favicon" message is allowlisted (not captured). If this test
// regresses, the gate is silently dead and the e2e suite is back to missing
// frontend failures.
func TestConsoleGate_CatchesError(t *testing.T) {
	l := launcher.New().Headless(true)
	u, err := l.Launch()
	if err != nil {
		t.Fatalf("launcher: %v", err)
	}
	defer l.Cleanup()

	browser := rod.New().ControlURL(u)
	if err := browser.Connect(); err != nil {
		t.Fatalf("rod.Connect: %v", err)
	}
	defer browser.Close()

	page := browser.MustPage("data:text/html," + url.PathEscape("<!doctype html><title>gate</title>"))
	defer page.Close()

	cw := startConsoleWatch(t, page)

	// Allowlisted: must NOT be captured.
	page.MustEval(`() => console.error("GET file:///favicon.ico net::ERR_FILE_NOT_FOUND")`)
	// Real failures: a console.error and an uncaught throw — both must fire.
	page.MustEval(`() => console.error("Failed to fetch file:///books")`)
	page.MustEval(`() => { setTimeout(() => { throw new Error("kaboom from page"); }, 0); }`)

	deadline := time.Now().Add(5 * time.Second)
	var probs []string
	for time.Now().Before(deadline) {
		probs = cw.problems()
		if len(probs) >= 2 {
			break
		}
		time.Sleep(50 * time.Millisecond)
	}

	joined := strings.Join(probs, "\n")
	if !strings.Contains(joined, "Failed to fetch file:///books") {
		t.Errorf("gate did not capture the console.error; problems=%v", probs)
	}
	if !strings.Contains(joined, "kaboom from page") {
		t.Errorf("gate did not capture the uncaught exception; problems=%v", probs)
	}
	if strings.Contains(joined, "favicon") {
		t.Errorf("gate captured an allowlisted (favicon) message; problems=%v", probs)
	}
	if t.Failed() {
		return
	}
	t.Logf("gate captured %d real problem(s), favicon allowlisted: %v", len(probs), probs)
}
