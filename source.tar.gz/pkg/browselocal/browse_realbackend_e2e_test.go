//go:build integration

package browselocal

import (
	"accorder/pkg/calibre"
	"accorder/pkg/rclonexfer"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/launcher"
	"github.com/go-rod/rod/lib/proto"
	"github.com/ysmood/gson"
)

// fixtureBooks returns the ~3 books written into the fixture index. They carry
// the fields the SELECT table renders (title/authors/tags/formats)
// plus _id/last_modified the selection + ordering paths depend on.
// last_modified-descending so the index's newest-first ordering is stable.
func fixtureBooks() []*calibre.Book {
	return []*calibre.Book{
		{
			Id:           "real-1",
			CalibreID:    1,
			Title:        "Cybernetics and Society",
			Authors:      []string{"Norbert Wiener"},
			Tags:         []string{"systems", "information theory"},
			Formats:      []*calibre.File{{Format: "EPUB", DirectoryPath: "Norbert Wiener/Cybernetics (1)", Name: "Cybernetics.epub", Size: 111}},
			BaseURL:      "/files/aggregate-a",
			CoverUrl:     "",
			LibraryUrl:   "",
			Librarian:    "test",
			LastModified: "2024-12-03T00:00:00+00:00",
		},
		{
			Id:           "real-2",
			CalibreID:    2,
			Title:        "The Society of the Spectacle",
			Authors:      []string{"Guy Debord"},
			Tags:         []string{"philosophy", "media"},
			Formats:      []*calibre.File{{Format: "PDF", DirectoryPath: "Guy Debord/Spectacle (2)", Name: "Spectacle.pdf", Size: 222}},
			BaseURL:      "/files/aggregate-a",
			CoverUrl:     "",
			LibraryUrl:   "",
			Librarian:    "test",
			LastModified: "2024-12-02T00:00:00+00:00",
		},
		{
			Id:           "real-3",
			CalibreID:    3,
			Title:        "Simians, Cyborgs, and Women",
			Authors:      []string{"Donna Haraway"},
			Tags:         []string{"feminism", "science studies"},
			Formats:      []*calibre.File{{Format: "EPUB", DirectoryPath: "Donna Haraway/Simians (3)", Name: "Simians.epub", Size: 333}},
			BaseURL:      "/files/aggregate-a",
			CoverUrl:     "",
			LibraryUrl:   "",
			Librarian:    "test",
			LastModified: "2024-12-01T00:00:00+00:00",
		},
	}
}

// buildFixtureIndex hand-writes the fixture books as JSONL, runs the real
// MotwSearch.BuildIndex + CompressToFile, and leaves
// <cacheDir>/static/library_index.zst (the path browselocal.Run opens).
// Returns the index path prefix (without .zst).
func buildFixtureIndex(t *testing.T, cacheDir string, books []*calibre.Book, dictID ...uint32) string {
	t.Helper()
	staticDir := filepath.Join(cacheDir, "static")
	if err := os.MkdirAll(staticDir, 0755); err != nil {
		t.Fatal(err)
	}

	jsonlPath := filepath.Join(cacheDir, "books.jsonl")
	f, err := os.Create(jsonlPath)
	if err != nil {
		t.Fatal(err)
	}
	for _, bk := range books {
		line, err := json.Marshal(bk)
		if err != nil {
			f.Close()
			t.Fatalf("marshal book %s: %v", bk.Id, err)
		}
		if _, err := f.Write(append(line, '\n')); err != nil {
			f.Close()
			t.Fatal(err)
		}
	}
	if err := f.Close(); err != nil {
		t.Fatal(err)
	}

	indexPath := filepath.Join(staticDir, "library_index")
	ms := &calibre.MotwSearch{JsonlPath: jsonlPath, IndexPath: indexPath}
	if len(dictID) > 1 {
		t.Fatal("buildFixtureIndex accepts at most one dictionary ID")
	}
	if len(dictID) == 1 {
		ms.DictID = dictID[0]
	}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex: %v", err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatalf("CompressToFile: %v", err)
	}
	if _, err := os.Stat(indexPath + ".zst"); err != nil {
		t.Fatalf("expected %s.zst to exist: %v", indexPath, err)
	}
	return indexPath
}

// newRealSession builds a real librarySession (same package) backed by the
// fixture index. libraryPath/librarianName are set so the SETTINGS gate is
// satisfied (settings/get returns both ⇒ no SETTINGS WALL). No calibredb, no
// network — handleBooks/handleSelectionToggle/handleSelectionEnqueue run for
// real against the on-disk index.
func newRealSession(t *testing.T, cacheDir, indexPath string) *librarySession {
	t.Helper()
	opened, err := (&calibre.MotwSearch{IndexPath: indexPath}).Open()
	if err != nil {
		t.Fatalf("MotwSearch.Open: %v", err)
	}
	t.Cleanup(func() { opened.Close() })

	libDir := t.TempDir()
	s := &librarySession{
		opened:         opened,
		cacheDir:       cacheDir,
		opts:           Options{DownloadDir: filepath.Join(cacheDir, "downloads")},
		selection:      make(map[string]bool),
		selectionBooks: make(map[string]*calibre.Book),
		downloadCh:     make(chan *queueItem, 256),
		stagedPages:    make(map[proto.TargetTargetID]bool),
		libraryPath:    libDir,
		librarianName:  "test",
	}
	return s
}

// TestBrowse_E2E_RealBackend drives the REAL handlers (no stub) over the real
// frontend bundle in headless Chromium. backend_rpc → session.handleRPC, so:
//   - handleBooks serves the 3 fixture books over the index (the /books-routing
//     path the stub never tested — would have caught the file:///books CORS bug),
//   - a row checkbox click fires real handleSelectionToggle,
//   - the QUEUE tab click fires real handleSelectionEnqueue (which
//     calls selectedIDsLocked — would have caught the infinite recursion),
//   - enqueue clears the selection AND the batch view lists the book.
//
// watchConsole fails the test on any console.error/uncaught exception.
func TestBrowse_E2E_RealBackend(t *testing.T) {
	cacheDir := t.TempDir()
	books := fixtureBooks()
	indexPath := buildFixtureIndex(t, cacheDir, books)

	// Real UI shell from this binary's embedded assets.
	if err := calibre.CopyBrowseUIAssets(cacheDir); err != nil {
		t.Fatalf("CopyBrowseUIAssets: %v", err)
	}
	// portable:false ⇒ the app routes /books through backend_rpc (handleBooks),
	// not the data1.js mock corpus.
	if err := os.WriteFile(filepath.Join(cacheDir, "static", "data1.js"),
		[]byte("CALIBRE_BOOKS1={portable:false,books:[]};"), 0644); err != nil {
		t.Fatal(err)
	}

	session := newRealSession(t, cacheDir, indexPath)

	l := launcher.New().Headless(true)
	u, err := l.Launch()
	if err != nil {
		t.Fatalf("launcher: %v", err)
	}
	defer l.Cleanup()

	browser := rod.New().ControlURL(u)
	if err := browser.Connect(); err != nil {
		t.Fatalf("rod.Connect: %v", err)
	}
	defer browser.Close()
	session.browser = browser

	page := browser.MustPage("about:blank")
	defer page.Close()
	page.MustExpose("backend_rpc", func(arg gson.JSON) (interface{}, error) {
		return session.handleRPC(arg.Str())
	})
	watchConsole(t, page)

	fileURL := "file://" + filepath.Join(cacheDir, "BROWSE_LIBRARY.html") + "#/?t=l"
	if err := page.Navigate(fileURL); err != nil {
		t.Fatalf("navigate: %v", err)
	}

	clickTab := func(label string) {
		t.Helper()
		ok := page.MustEval(`(label) => {
			const btns = [...document.querySelectorAll('nav button')];
			const hit = btns.find(b => b.textContent.includes('[' + label + ']'));
			if (!hit) return false;
			hit.click();
			return true;
		}`, label).Bool()
		if !ok {
			dumpBody(t, page)
			t.Fatalf("could not find TabHeader button %q", label)
		}
	}

	// --- SELECT: 3 fixture books served by REAL handleBooks ---
	// Wait for a REAL book title (not just >=3 rows, which the loading
	// placeholders also satisfy — that raced the real-books fetch).
	page.Timeout(15 * time.Second).MustWait(`() => ((document.body && document.body.innerText) || "").includes('Cybernetics and Society')`)

	// --- TabHeader pipeline: 4 steps ---
	page.Timeout(15 * time.Second).MustWait(`() => {
		const t = (document.body && document.body.innerText) || "";
		return t.includes('[SETTINGS]') && t.includes('[SELECT]') &&
		       t.includes('[QUEUE]') && t.includes('[MY LIBRARY]');
	}`)
	t.Log("OK: TabHeader pipeline rendered (all 4 steps)")
	bodyText := page.MustEval(`() => document.body.innerText`).Str()
	for _, want := range []string{"Cybernetics and Society", "The Society of the Spectacle", "Simians, Cyborgs, and Women"} {
		if !strings.Contains(bodyText, want) {
			dumpBody(t, page)
			t.Fatalf("BROWSE table missing fixture book %q (real handleBooks did not serve it)", want)
		}
	}
	t.Log("OK: real handleBooks served 3 fixture books into SELECT table")

	// --- select first row ([ADD TO QUEUE]) → real handleSelectionToggle ---
	page.MustEval(`() => [...document.querySelectorAll('table tbody span')].find(e => e.textContent.trim() === '[ADD TO QUEUE]').click()`)
	// The real toggle updates s.selection; confirm via the QUEUE badge (1)
	// AND by reading the session's selection count back in-process.
	page.Timeout(5 * time.Second).MustWait(`() => {
		const btns = [...document.querySelectorAll('nav button')];
		const b = btns.find(x => x.textContent.includes('[QUEUE]'));
		return b && b.textContent.includes('(1)');
	}`)
	session.mu.Lock()
	selCount := len(session.selection)
	session.mu.Unlock()
	if selCount != 1 {
		t.Fatalf("after checkbox click, real session.selection has %d entries, want 1", selCount)
	}
	t.Log("OK: checkbox click drove real handleSelectionToggle (session.selection size = 1)")

	// --- QUEUE tab → real handleSelectionEnqueue ---
	clickTab("QUEUE")
	// Enqueue moves selection → queue and CLEARS selection. Wait for the batch
	// header to render (batch mode), then assert both effects.
	page.Timeout(5 * time.Second).MustWait(`() => document.body.innerText.includes('[DOWNLOAD ALL]')`)

	// Real effect 1: the queue now lists the selected book.
	deadline := time.Now().Add(5 * time.Second)
	var queuedTitle string
	for time.Now().Before(deadline) {
		session.mu.Lock()
		if len(session.queue) == 1 {
			queuedTitle = session.queue[0].Title
		}
		qLen := len(session.queue)
		selN := len(session.selection)
		session.mu.Unlock()
		if qLen == 1 && selN == 0 {
			break
		}
		time.Sleep(50 * time.Millisecond)
	}
	session.mu.Lock()
	gotQueue := len(session.queue)
	gotSel := len(session.selection)
	session.mu.Unlock()
	if gotQueue != 1 {
		dumpBody(t, page)
		t.Fatalf("after enqueue, real session.queue has %d items, want 1", gotQueue)
	}
	if queuedTitle != "Cybernetics and Society" {
		t.Fatalf("queued book title = %q, want %q", queuedTitle, "Cybernetics and Society")
	}
	// Real effect 2: selection CLEARED (checkboxes uncheck).
	if gotSel != 0 {
		t.Fatalf("after enqueue, real session.selection has %d entries, want 0 (cleared)", gotSel)
	}
	t.Log("OK: QUEUE tab drove real handleSelectionEnqueue (queue=1, selection cleared)")

	// The batch view must list the enqueued book by title.
	page.Timeout(5 * time.Second).MustWait(`() => document.body.innerText.includes('Cybernetics and Society')`)
	t.Log("OK: QUEUE view lists the enqueued fixture book")
}

func dumpBody(t *testing.T, page *rod.Page) {
	t.Helper()
	txt := page.MustEval(`() => document.body.innerText`).Str()
	if len(txt) > 2000 {
		txt = txt[:2000] + fmt.Sprintf("... (%d more bytes)", len(txt)-2000)
	}
	t.Logf("page innerText:\n%s", txt)
}

// coverFixtureBooks returns books carrying non-zero CoverFingerprints AND a
// cover_url/library_url the OLD grid would have eagerly fetched. This lets the
// covers grid be asserted on two contracts at once: (a) BookCard paints the
// decoded SVG mosaic as the cover background, and (b) it makes NO /files/
// cover-image request (the zero-egress grid contract this workflow delivers).
// The fingerprints are valid 6-byte little-endian packings (luma 3b×12 + Cb/Cr
// 4b), generated to mirror pkg/calibre/fingerprint.go.
func coverFixtureBooks() []*calibre.Book {
	return []*calibre.Book{
		{
			Id:               "fp-1",
			CalibreID:        1,
			Title:            "Cybernetics and Society",
			Authors:          []string{"Norbert Wiener"},
			Tags:             []string{"systems"},
			Formats:          []*calibre.File{{Format: "EPUB", DirectoryPath: "Norbert Wiener/Cybernetics (1)", Name: "Cybernetics.epub", Size: 111}},
			BaseURL:          "/files/aggregate-a",
			CoverUrl:         "Norbert Wiener/Cybernetics (1)/cover.jpg",
			LibraryUrl:       "/files/aggregate-a/",
			CoverFingerprint: "Sbb9l4QI", // luma gradient rows 1/3/7/2, neutral chroma
			Librarian:        "test",
			LastModified:     "2024-12-03T00:00:00+00:00",
		},
		{
			Id:               "fp-2",
			CalibreID:        2,
			Title:            "The Society of the Spectacle",
			Authors:          []string{"Guy Debord"},
			Tags:             []string{"media"},
			Formats:          []*calibre.File{{Format: "PDF", DirectoryPath: "Guy Debord/Spectacle (2)", Name: "Spectacle.pdf", Size: 222}},
			BaseURL:          "/files/aggregate-a",
			CoverUrl:         "Guy Debord/Spectacle (2)/cover.jpg",
			LibraryUrl:       "/files/aggregate-a/",
			CoverFingerprint: "/////78F", // bright, warm chroma
			Librarian:        "test",
			LastModified:     "2024-12-02T00:00:00+00:00",
		},
		{
			Id:               "fp-3",
			CalibreID:        3,
			Title:            "Simians, Cyborgs, and Women",
			Authors:          []string{"Donna Haraway"},
			Tags:             []string{"feminism"},
			Formats:          []*calibre.File{{Format: "EPUB", DirectoryPath: "Donna Haraway/Simians (3)", Name: "Simians.epub", Size: 333}},
			BaseURL:          "/files/aggregate-a",
			CoverUrl:         "Donna Haraway/Simians (3)/cover.jpg",
			LibraryUrl:       "/files/aggregate-a/",
			CoverFingerprint: "JEmSJFkL", // mid luma, cool chroma
			Librarian:        "test",
			LastModified:     "2024-12-01T00:00:00+00:00",
		},
	}
}

// TestBrowse_E2E_CoverFingerprintMosaic drives the real frontend bundle over a
// fixture index whose books carry cover fingerprints, switches to the covers
// grid via the "show covers" toggle, and asserts that BookCard:
//   - paints the decoded SVG mosaic (data:image/svg+xml) as the cover background
//     for every fingerprinted book (covers come from the index, zero network), and
//   - makes NO real cover <img> fetch (/files/.../cover.jpg) in the grid — the
//     zero-egress contract this workflow delivers.
//
// watchConsole fails the test on any console.error/uncaught exception.
func TestBrowse_E2E_CoverFingerprintMosaic(t *testing.T) {
	cacheDir := t.TempDir()
	books := coverFixtureBooks()
	indexPath := buildFixtureIndex(t, cacheDir, books)

	if err := calibre.CopyBrowseUIAssets(cacheDir); err != nil {
		t.Fatalf("CopyBrowseUIAssets: %v", err)
	}
	// portable:false ⇒ /books routes through backend_rpc (handleBooks), not the
	// data1.js mock corpus — the index path that carries cover_fingerprint.
	if err := os.WriteFile(filepath.Join(cacheDir, "static", "data1.js"),
		[]byte("CALIBRE_BOOKS1={portable:false,books:[]};"), 0644); err != nil {
		t.Fatal(err)
	}

	session := newRealSession(t, cacheDir, indexPath)

	// Backend contract: handleBooks must emit cover_fingerprint on /books items
	// (isolates a backend regression from a frontend one).
	rawBooks, err := session.handleBooks(json.RawMessage(`{"offset":0,"limit":48}`))
	if err != nil {
		t.Fatalf("handleBooks: %v", err)
	}
	rawJSON, _ := json.Marshal(rawBooks)
	if !strings.Contains(string(rawJSON), `"cover_fingerprint":"Sbb9l4QI"`) {
		t.Fatalf("handleBooks response missing cover_fingerprint; got: %s", rawJSON)
	}
	t.Log("OK: handleBooks emits cover_fingerprint on /books items")

	l := launcher.New().Headless(true)
	u, err := l.Launch()
	if err != nil {
		t.Fatalf("launcher: %v", err)
	}
	defer l.Cleanup()

	browser := rod.New().ControlURL(u)
	if err := browser.Connect(); err != nil {
		t.Fatalf("rod.Connect: %v", err)
	}
	defer browser.Close()
	session.browser = browser

	page := browser.MustPage("about:blank")
	defer page.Close()
	page.MustExpose("backend_rpc", func(arg gson.JSON) (interface{}, error) {
		return session.handleRPC(arg.Str())
	})
	watchConsole(t, page)

	fileURL := "file://" + filepath.Join(cacheDir, "BROWSE_LIBRARY.html") + "#/?t=l"
	if err := page.Navigate(fileURL); err != nil {
		t.Fatalf("navigate: %v", err)
	}

	// Wait for the real books to land (list view first).
	page.Timeout(15 * time.Second).MustWait(`() => ((document.body && document.body.innerText) || "").includes('Cybernetics and Society')`)

	// Switch to the covers grid via the "show covers" toggle in MotwHeader
	// (frontend/src/MotwHeader.svelte:62). App.svelte's onMount runs an async
	// session/mode RPC that sets t=true (browse ⇒ list) when it resolves, which
	// can revert a single toggle click — so poll-and-click until the covers grid
	// renders. Target the LEAF element carrying the onclick (children.length===0);
	// its wrapper div has identical text but no handler (a parent click won't fire
	// the child's listener).
	page.Timeout(15 * time.Second).MustWait(`() => {
		if (document.querySelectorAll('.cover').length > 0) return true;
		const el = [...document.querySelectorAll('div')].find(d =>
			d.children.length === 0 &&
			/^show (covers|list)$/.test((d.textContent || '').replace(/\s+/g, ' ').trim()));
		if (el) el.click();
		return false;
	}`)

	// BookCard '.cover' tiles render in the grid; wait for the decoded SVG mosaic
	// to appear as an inline background-image (the gray placeholder lives in the
	// stylesheet, so only the fp mosaic shows up in the inline style attribute).
	page.Timeout(10 * time.Second).MustWait(`() => [...document.querySelectorAll('.cover')]
		.some(d => (d.getAttribute('style') || '').includes('data:image/svg+xml'))`)

	mosaicCount := page.MustEval(`() => [...document.querySelectorAll('.cover')]
		.filter(d => (d.getAttribute('style') || '').includes('data:image/svg+xml')).length`).Int()
	if mosaicCount < 3 {
		dumpBody(t, page)
		t.Fatalf("covers grid painted %d fingerprint mosaics, want >= 3 (one per fixture book)", mosaicCount)
	}
	t.Logf("OK: %d BookCard fingerprint mosaics rendered from the index (no network)", mosaicCount)

	// Zero-egress contract: no <img> in the grid points at a cover / /files/ path.
	// (Format download icons are data: URIs, so they don't match.)
	coverImgs := page.MustEval(`() => [...document.querySelectorAll('img')].filter(im => {
		const s = im.getAttribute('src') || '';
		return s.includes('/files/') || s.includes('cover.jpg');
	}).length`).Int()
	if coverImgs != 0 {
		dumpBody(t, page)
		t.Fatalf("covers grid issued %d real cover <img> fetches, want 0 (zero-egress)", coverImgs)
	}
	t.Log("OK: covers grid made no /files/ cover-image fetch")
}

// TestBrowse_E2E_CoversDefaultAndPersist verifies the two view-state rules:
//  1. The covers grid is the DEFAULT view on open (no "t=l" in the hash).
//  2. The [show covers]/[show list] choice PERSISTS across navigation — it is
//     not reset by dispatchHash or the async session/mode RPC (the old bug).
func TestBrowse_E2E_CoversDefaultAndPersist(t *testing.T) {
	cacheDir := t.TempDir()
	books := coverFixtureBooks()
	indexPath := buildFixtureIndex(t, cacheDir, books)

	if err := calibre.CopyBrowseUIAssets(cacheDir); err != nil {
		t.Fatalf("CopyBrowseUIAssets: %v", err)
	}
	if err := os.WriteFile(filepath.Join(cacheDir, "static", "data1.js"),
		[]byte("CALIBRE_BOOKS1={portable:false,books:[]};"), 0644); err != nil {
		t.Fatal(err)
	}

	session := newRealSession(t, cacheDir, indexPath)

	l := launcher.New().Headless(true)
	u, err := l.Launch()
	if err != nil {
		t.Fatalf("launcher: %v", err)
	}
	defer l.Cleanup()
	browser := rod.New().ControlURL(u)
	if err := browser.Connect(); err != nil {
		t.Fatalf("rod.Connect: %v", err)
	}
	defer browser.Close()
	session.browser = browser
	page := browser.MustPage("about:blank")
	defer page.Close()
	page.MustExpose("backend_rpc", func(arg gson.JSON) (interface{}, error) {
		return session.handleRPC(arg.Str())
	})
	watchConsole(t, page)

	// Open WITHOUT t=l — the browse session's real entry hash ("#/?").
	fileURL := "file://" + filepath.Join(cacheDir, "BROWSE_LIBRARY.html") + "#/?"
	if err := page.Navigate(fileURL); err != nil {
		t.Fatalf("navigate: %v", err)
	}
	page.Timeout(15 * time.Second).MustWait(`() => ((document.body && document.body.innerText) || "").includes('Cybernetics and Society')`)

	covers := func() int {
		return page.MustEval(`() => document.querySelectorAll('.cover').length`).Int()
	}
	tables := func() int {
		return page.MustEval(`() => document.querySelectorAll('table').length`).Int()
	}
	clickToggle := func() {
		page.MustEval(`() => {
			const el = [...document.querySelectorAll('div')].find(d =>
				d.children.length === 0 &&
				/^show (covers|list)$/.test((d.textContent || '').replace(/\s+/g, ' ').trim()));
			if (el) el.click();
		}`)
	}
	// navigate fires a real hashchange → dispatchHash (the path that used to
	// reset the view). "#/?" and "#/books" both load the book list.
	navigate := func(hash string) {
		page.MustEval(`(h) => { location.hash = h; }`, hash)
		time.Sleep(300 * time.Millisecond)
	}

	// 1) DEFAULT = covers grid, no table.
	page.Timeout(10 * time.Second).MustWait(`() => document.querySelectorAll('.cover').length > 0`)
	if tables() != 0 {
		dumpBody(t, page)
		t.Fatalf("default view should be covers, but found %d table(s)", tables())
	}
	t.Log("OK: covers grid is the default view (no t=l)")

	// 2a) [show list] → table; then navigate → must STAY a table.
	clickToggle()
	page.Timeout(5 * time.Second).MustWait(`() => document.querySelectorAll('table').length > 0`)
	navigate("#/books")
	if tables() == 0 || covers() != 0 {
		dumpBody(t, page)
		t.Fatalf("after [show list] + navigation: tables=%d covers=%d, want list to persist", tables(), covers())
	}
	t.Log("OK: list view persists across navigation")

	// 2b) [show covers] → grid; then navigate → must STAY covers.
	clickToggle()
	page.Timeout(5 * time.Second).MustWait(`() => document.querySelectorAll('.cover').length > 0`)
	navigate("#/?")
	if covers() == 0 || tables() != 0 {
		dumpBody(t, page)
		t.Fatalf("after [show covers] + navigation: covers=%d tables=%d, want covers to persist", covers(), tables())
	}
	t.Log("OK: covers view persists across navigation")
}

// TestBrowse_E2E_LocalFilesRootDownload verifies the QUEUE download in a
// fully-local browse: with Options.FilesRoot set, the download worker copies a
// book's folder from FilesRoot + dir_path on disk into the download dir (a
// local file move via rclone), with no remote "librarian:" source.
func TestBrowse_E2E_LocalFilesRootDownload(t *testing.T) {
	cacheDir := t.TempDir()
	books := coverFixtureBooks()
	indexPath := buildFixtureIndex(t, cacheDir, books)

	// On-disk "library" the download copies FROM (files-root + book dir path).
	filesRoot := t.TempDir()
	dirPath := "Norbert Wiener/Cybernetics (1)" // == coverFixtureBooks()[0] Formats[0].DirectoryPath
	bookDir := filepath.Join(filesRoot, dirPath)
	if err := os.MkdirAll(bookDir, 0755); err != nil {
		t.Fatal(err)
	}
	wantContent := []byte("epub-bytes-for-cybernetics")
	if err := os.WriteFile(filepath.Join(bookDir, "Cybernetics.epub"), wantContent, 0644); err != nil {
		t.Fatal(err)
	}
	downloadDir := t.TempDir()

	// Real embedded rclone for the local→local copy.
	if err := rclonexfer.SetCacheDir(t.TempDir()); err != nil {
		t.Fatalf("SetCacheDir: %v", err)
	}
	rclonexfer.Initialize()
	defer rclonexfer.Finalize()

	opened, err := (&calibre.MotwSearch{IndexPath: indexPath}).Open()
	if err != nil {
		t.Fatalf("MotwSearch.Open: %v", err)
	}
	defer opened.Close()

	s := &librarySession{
		opened:         opened,
		cacheDir:       cacheDir,
		opts:           Options{FilesRoot: filesRoot, DownloadDir: downloadDir},
		selection:      make(map[string]bool),
		selectionBooks: make(map[string]*calibre.Book),
		downloadCh:     make(chan *queueItem, 256),
		stagedPages:    make(map[proto.TargetTargetID]bool),
	}

	// Enqueue the book and run the real batch download.
	if _, err := s.handleToggleQueue(json.RawMessage(`{"book_id":"fp-1","dir_path":"Norbert Wiener/Cybernetics (1)","base_url":"/files/aggregate-a"}`)); err != nil {
		t.Fatalf("handleToggleQueue: %v", err)
	}
	if _, err := s.handleFetchBatch(); err != nil {
		t.Fatalf("handleFetchBatch: %v", err)
	}

	// Wait for the copy to finish.
	deadline := time.Now().Add(20 * time.Second)
	var status, errMsg string
	for time.Now().Before(deadline) {
		s.mu.Lock()
		if len(s.queue) > 0 {
			status = s.queue[0].Status
			errMsg = s.queue[0].Error
		}
		s.mu.Unlock()
		if status == statusDone || status == statusFailed {
			break
		}
		time.Sleep(100 * time.Millisecond)
	}
	if status != statusDone {
		t.Fatalf("download status = %q (err %q), want %q", status, errMsg, statusDone)
	}

	// The epub must have been copied to <downloadDir>/<prefix>/<dirPath>/.
	dst := filepath.Join(downloadDir, "files/aggregate-a", dirPath, "Cybernetics.epub")
	got, err := os.ReadFile(dst)
	if err != nil {
		t.Fatalf("expected copied file at %s: %v", dst, err)
	}
	if string(got) != string(wantContent) {
		t.Fatalf("copied content mismatch: got %q want %q", got, wantContent)
	}
	t.Logf("OK: local files-root download copied %s (%d bytes)", dst, len(got))
}

// TestBrowse_E2E_NoFingerprintRendersRealCover verifies the portable/standalone
// fallback (e.g. the MY LIBRARY built site, whose data1.js carries no
// fingerprints): a book with no cover_fingerprint but a cover_url must render
// the real cover <img> in the grid — otherwise the grid would be blank, which
// is the regression that hid MY LIBRARY covers.
func TestBrowse_E2E_NoFingerprintRendersRealCover(t *testing.T) {
	cacheDir := t.TempDir()
	books := []*calibre.Book{
		{
			Id:           "nofp-1",
			CalibreID:    1,
			Title:        "No Fingerprint Book",
			Authors:      []string{"Ada Lovelace"},
			Tags:         []string{"x"},
			Formats:      []*calibre.File{{Format: "EPUB", DirectoryPath: "Ada Lovelace/Notes (1)", Name: "Notes.epub", Size: 1}},
			BaseURL:      "/files/local",
			CoverUrl:     "Ada Lovelace/Notes (1)/cover.jpg",
			LibraryUrl:   "/files/local/",
			Librarian:    "test",
			LastModified: "2024-12-03T00:00:00+00:00",
			// CoverFingerprint intentionally empty (portable data1.js has none).
		},
	}
	indexPath := buildFixtureIndex(t, cacheDir, books)
	if err := calibre.CopyBrowseUIAssets(cacheDir); err != nil {
		t.Fatalf("CopyBrowseUIAssets: %v", err)
	}
	if err := os.WriteFile(filepath.Join(cacheDir, "static", "data1.js"),
		[]byte("CALIBRE_BOOKS1={portable:false,books:[]};"), 0644); err != nil {
		t.Fatal(err)
	}

	session := newRealSession(t, cacheDir, indexPath)

	l := launcher.New().Headless(true)
	u, err := l.Launch()
	if err != nil {
		t.Fatalf("launcher: %v", err)
	}
	defer l.Cleanup()
	browser := rod.New().ControlURL(u)
	if err := browser.Connect(); err != nil {
		t.Fatalf("rod.Connect: %v", err)
	}
	defer browser.Close()
	session.browser = browser
	page := browser.MustPage("about:blank")
	defer page.Close()
	page.MustExpose("backend_rpc", func(arg gson.JSON) (interface{}, error) {
		return session.handleRPC(arg.Str())
	})
	watchConsole(t, page)

	if err := page.Navigate("file://" + filepath.Join(cacheDir, "BROWSE_LIBRARY.html") + "#/?"); err != nil {
		t.Fatalf("navigate: %v", err)
	}
	page.Timeout(15 * time.Second).MustWait(`() => ((document.body && document.body.innerText) || "").includes('No Fingerprint Book')`)
	page.Timeout(10 * time.Second).MustWait(`() => document.querySelectorAll('.cover').length > 0`)

	// No fingerprint ⇒ the grid must render the real cover <img> (cover_url).
	src := page.MustEval(`() => { const im = document.querySelector('.cover img'); return im ? (im.getAttribute('src') || '') : ''; }`).Str()
	if !strings.Contains(src, "Ada Lovelace/Notes (1)/cover.jpg") {
		dumpBody(t, page)
		t.Fatalf("no-fingerprint book: expected real cover <img> with cover_url, got src=%q", src)
	}
	t.Log("OK: no-fingerprint book renders the real cover <img> (cover_url)")
}
