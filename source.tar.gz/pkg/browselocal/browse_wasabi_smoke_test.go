//go:build integration && wasabi_e2e

package browselocal

import (
	"accorder/pkg/calibre"
	"accorder/pkg/rclonexfer"
	"context"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/launcher"
	"github.com/go-rod/rod/lib/proto"
	"github.com/ysmood/gson"
)

// TestBrowse_E2E_WasabiSmoke is the LIVE (non-hermetic) tier of the browse e2e
// harness: tier D. It drives the headless-Chromium browse client against the
// REAL aggregate served by `accorder motw serve` over plain HTTP, with the
// serve's file plane backed by the REAL Wasabi S3 bucket.
//
// This automates the manual deployment run:
//
//	accorder motw serve aggtest --listen 127.0.0.1:PORT
//	accorder calibre browse --http-endpoint http://127.0.0.1:PORT/ --label smoke
//
// Shared cred resolution + serve subprocess live in browse_wasabi_shared_test.go.
//
// Asserts against REAL data: the BROWSE table renders real books, a search
// returns hits, and a QUEUE for a book whose blob is CONFIRMED
// present on S3 reaches statusDone. MY LIBRARY import/build runs only when
// calibredb is on PATH. watchConsole stays on: a live front-page CORS/fetch
// failure fails the test.
//
// Skips cleanly (t.Skip) unless BOTH Wasabi creds and a local aggregate index
// resolve. Secret keys are NEVER hardcoded and are masked in any log output.
//
// For the heavy full-pipeline run (search a 113-book tag, select-all, download
// ALL, import-and-build to a fresh library), see TestBrowse_E2E_WasabiBulk
// (//go:build wasabi_bulk_e2e) — kept on a separate tag so this cheap smoke
// never pulls a large corpus.
func TestBrowse_E2E_WasabiSmoke(t *testing.T) {
	creds, ok := resolveWasabiCreds(t)
	if !ok {
		t.Skip("wasabi smoke: S3 creds not found (env S3_* or aggtest alias) — skipping live test")
	}
	aggPath := resolveAggregatePath()
	if aggPath == "" {
		t.Skip("wasabi smoke: local aggregate index not found (env ACCORDER_AGG_PATH or ~/CalibreLibraries/aggregate-build/library_index.zst) — skipping live test")
	}
	t.Logf("wasabi smoke: creds resolved from %s (access-key %s); aggregate index at %s",
		creds.source, maskKey(creds.accessKey), aggPath)

	// --- 1+2. Build the real binary + start serve against Wasabi. ---
	serveURL := startServeOnAgg(t, creds)
	t.Logf("wasabi smoke: serve answering at %s", serveURL)

	// --- 3. Drive the headless browse client (clearnet aggregator path). ---
	cacheDir := t.TempDir()
	staticDir := filepath.Join(cacheDir, "static")
	if err := os.MkdirAll(staticDir, 0755); err != nil {
		t.Fatal(err)
	}

	rclonexfer.Initialize()
	defer rclonexfer.Finalize()

	if err := rclonexfer.ConfigHTTPRemote("librarian-cat", serveURL); err != nil {
		t.Fatalf("ConfigHTTPRemote: %v", err)
	}
	if err := rclonexfer.ConfigWebDAVRemote("librarian", serveURL); err != nil {
		t.Fatalf("ConfigWebDAVRemote: %v", err)
	}

	if err := rclonexfer.CopyFile("librarian-cat:", "static/library_index.zst", staticDir, "library_index.zst"); err != nil {
		t.Fatalf("sync library_index.zst: %v", err)
	}
	if err := rclonexfer.CopyFile("librarian-cat:", "static/data1.js", staticDir, "data1.js"); err != nil {
		t.Fatalf("sync data1.js: %v", err)
	}
	zstInfo, err := os.Stat(filepath.Join(staticDir, "library_index.zst"))
	if err != nil {
		t.Fatalf("synced index missing: %v", err)
	}
	t.Logf("wasabi smoke: synced library_index.zst (%d bytes) + data1.js from serve", zstInfo.Size())

	if err := calibre.CopyBrowseUIAssets(cacheDir); err != nil {
		t.Fatalf("CopyBrowseUIAssets: %v", err)
	}
	for i := 2; i <= 8; i++ {
		stub := fmt.Sprintf("CALIBRE_BOOKS%d={books:[]}", i)
		if err := os.WriteFile(filepath.Join(staticDir, fmt.Sprintf("data%d.js", i)), []byte(stub), 0644); err != nil {
			t.Fatalf("write data%d.js stub: %v", i, err)
		}
	}

	// --- Open the synced index + build a real session. ---
	indexPath := filepath.Join(staticDir, "library_index")
	opened, err := (&calibre.MotwSearch{IndexPath: indexPath}).Open()
	if err != nil {
		t.Fatalf("open synced index: %v", err)
	}
	t.Cleanup(func() { opened.Close() })

	mf := opened.Manifest()
	t.Logf("wasabi smoke: opened aggregate index — %d books, %d segments, %d regions",
		mf.NumBooks, mf.NumSegments, len(mf.Regions))
	if mf.NumBooks == 0 {
		t.Fatal("aggregate index reports 0 books")
	}

	libDir := t.TempDir()
	dlDir := t.TempDir()
	session := &librarySession{
		opened:         opened,
		cacheDir:       cacheDir,
		opts:           Options{DownloadDir: dlDir},
		selection:      make(map[string]bool),
		selectionBooks: make(map[string]*calibre.Book),
		downloadCh:     make(chan *queueItem, 256),
		stagedPages:    make(map[proto.TargetTargetID]bool),
		libraryPath:    libDir,
		librarianName:  "smoke",
	}

	// --- rod headless. ---
	l := launcher.New().Headless(true)
	u, err := l.Launch()
	if err != nil {
		t.Fatalf("launcher: %v", err)
	}
	defer l.Cleanup()

	browser := rod.New().ControlURL(u)
	if err := browser.Connect(); err != nil {
		t.Fatalf("rod.Connect: %v", err)
	}
	defer browser.Close()
	session.browser = browser

	page := browser.MustPage("about:blank")
	defer page.Close()

	page.MustExpose("backend_rpc", func(arg gson.JSON) (interface{}, error) {
		return session.handleRPC(arg.Str())
	})
	watchConsole(t, page)

	fileURL := "file://" + filepath.Join(cacheDir, "BROWSE_LIBRARY.html") + "#/?t=l"
	if err := page.Navigate(fileURL); err != nil {
		t.Fatalf("navigate: %v", err)
	}

	clickTab := func(label string) {
		t.Helper()
		ok := page.MustEval(`(label) => {
			const btns = [...document.querySelectorAll('nav button')];
			const hit = btns.find(b => b.textContent.includes('[' + label + ']'));
			if (!hit) return false;
			hit.click();
			return true;
		}`, label).Bool()
		if !ok {
			dumpBody(t, page)
			t.Fatalf("could not find TabHeader button %q", label)
		}
	}

	// --- 4a. BROWSE: real books render. ---
	page.Timeout(30 * time.Second).MustWait(`() => document.querySelectorAll('table tbody tr').length >= 5`)
	rows := page.MustEval(`() => document.querySelectorAll('table tbody tr').length`).Int()
	t.Logf("OK: BROWSE table rendered %d real rows from live aggregate", rows)

	// Catalog render against the live aggregate is now validated. Pick a
	// confirmed-present book for the download leg; if none is reachable, the
	// catalog check above still stands — return without failing.
	target := discoverPresentBook(t, serveURL, opened)
	if target == nil {
		t.Logf("wasabi smoke: catalog validated; skipping download leg (no present book — pin WASABI_SMOKE_BOOK_ID)")
		return
	}
	t.Logf("wasabi smoke: download target = %q (id=%s)", target.Title, target.Id)

	// --- 4b. SEARCH returns hits (in-process search over the synced index). ---
	searchQ := firstTitleToken(target.Title)
	hits, _, err := opened.Search(context.Background(),
		calibre.SearchQuery{Field: calibre.FieldTitle, Text: searchQ, Mode: calibre.ModePrefix},
		calibre.SearchOptions{Limit: 10, SortMode: calibre.SortRelevance})
	if err != nil {
		t.Fatalf("live search %q: %v", searchQ, err)
	}
	if len(hits) == 0 {
		t.Fatalf("live search for %q returned 0 hits (expected >= 1)", searchQ)
	}
	t.Logf("OK: live search %q returned %d hit(s)", searchQ, len(hits))

	// --- 4c. Select the confirmed-present book → QUEUE → real fetch
	// from Wasabi through the serve file plane. ---
	session.mu.Lock()
	session.selection[target.Id] = true
	session.selectionBooks[target.Id] = target
	session.mu.Unlock()

	if _, err := session.handleSelectionEnqueue(); err != nil {
		t.Fatalf("enqueue target: %v", err)
	}
	session.ensureWorker()
	if _, err := session.handleFetchBatch(); err != nil {
		t.Fatalf("fetchBatch: %v", err)
	}

	deadline := time.Now().Add(90 * time.Second)
	var finalStatus, finalErr string
	for time.Now().Before(deadline) {
		session.mu.Lock()
		if len(session.queue) > 0 {
			finalStatus = session.queue[0].Status
			finalErr = session.queue[0].Error
		}
		session.mu.Unlock()
		if finalStatus == statusDone || finalStatus == statusFailed {
			break
		}
		time.Sleep(250 * time.Millisecond)
	}
	if finalStatus != statusDone {
		t.Fatalf("download of %q (id=%s) did not reach 'done': status=%q err=%q (real Wasabi fetch through serve failed)",
			target.Title, target.Id, finalStatus, finalErr)
	}
	t.Logf("OK: real Wasabi download through serve file plane completed for %q (id=%s)", target.Title, target.Id)

	// Verify bytes actually landed on disk.
	session.mu.Lock()
	item := session.queue[0]
	session.mu.Unlock()
	dlPath := item.localPath(dlDir)
	var downloaded int64
	_ = filepath.Walk(dlPath, func(_ string, info os.FileInfo, err error) error {
		if err == nil && info != nil && !info.IsDir() {
			downloaded += info.Size()
		}
		return nil
	})
	if downloaded == 0 {
		t.Fatalf("download reported done but no bytes on disk under %s", dlPath)
	}
	t.Logf("OK: %d bytes landed on disk under %s", downloaded, dlPath)

	// --- 4d. MY LIBRARY: real import + build (only if calibredb present). ---
	if _, lookErr := exec.LookPath("calibredb"); lookErr != nil {
		t.Logf("calibredb not on PATH — skipping MY LIBRARY import/build assertions")
		t.Logf("wasabi smoke: PASS (browse + search + live Wasabi download verified)")
		return
	}

	clickTab("MY LIBRARY")
	page.Timeout(120 * time.Second).MustWait(`() => {
		const f = document.querySelector('iframe');
		return f && f.getAttribute('src') && f.getAttribute('src').includes('BROWSE_LIBRARY.html');
	}`)
	src := page.MustEval(`() => document.querySelector('iframe').getAttribute('src')`).Str()
	if !strings.HasPrefix(src, "file://") || !strings.Contains(src, "BROWSE_LIBRARY.html") {
		t.Fatalf("DOM assert FAIL: MY LIBRARY iframe src does not point at built library: %q", src)
	}
	t.Logf("OK (DOM): MY LIBRARY iframe src = %q", src)

	libPath := session.libraryPath
	for _, rel := range []string{"BROWSE_LIBRARY.html", "static", "metadata.db"} {
		if _, err := os.Stat(filepath.Join(libPath, rel)); err != nil {
			t.Errorf("FS assert FAIL: expected %s in library root: %v", rel, err)
		}
	}
	for _, rel := range []string{".motw-browse", ".motw-downloads"} {
		if _, err := os.Stat(filepath.Join(libPath, rel)); err == nil {
			t.Errorf("FS assert FAIL: %s must NOT exist in library_path (wrong-dir bug)", rel)
		}
	}
	if t.Failed() {
		entries, _ := os.ReadDir(libPath)
		var names []string
		for _, e := range entries {
			names = append(names, e.Name())
		}
		t.Logf("library_path (%s) contents: %v", libPath, names)
		return
	}
	t.Logf("OK (FS): library_path %s has BROWSE_LIBRARY.html + static/ + metadata.db at root, no dotdirs", libPath)
	t.Logf("wasabi smoke: PASS (browse + search + live Wasabi download + import/build verified)")
}

// --- smoke-specific helpers ------------------------------------------------

// defaultPinnedBookID is a small (~129 KB) book in the vishmidt library whose
// blob was confirmed present on S3 (2026-05). Used as the download target when
// WASABI_SMOKE_BOOK_ID is unset, so the smoke reliably exercises a real
// download instead of blind-sampling a sparse, mostly-blobless aggregate.
// Override via WASABI_SMOKE_BOOK_ID; if this id ever leaves the aggregate the
// test falls back to discovery.
const defaultPinnedBookID = "960169e0-9d11-5cc8-a990-45fc82296787"

// discoverPresentBook finds a book whose blob is confirmed present on S3 by
// probing the serve file plane (GET /files/<prefix>/<dir>/<file> == 200). It
// honors a pinned WASABI_SMOKE_BOOK_ID, otherwise pages through the live
// aggregate and probes candidates until one downloads. Returns nil if none of
// the probed candidates have a present blob (the index↔blob mismatch).
func discoverPresentBook(t *testing.T, serveURL string, opened *calibre.OpenedSearch) *calibre.Book {
	t.Helper()
	client := &http.Client{Timeout: 4 * time.Second}

	blobURL := func(bk *calibre.Book) (string, bool) {
		if len(bk.Formats) == 0 {
			return "", false
		}
		prefix := strings.TrimPrefix(bk.BaseURL, "/")
		if prefix == "" || !strings.HasPrefix(prefix, "files/") {
			return "", false
		}
		f := bk.Formats[0]
		if f.DirectoryPath == "" || f.Name == "" {
			return "", false
		}
		// Mirror the download worker / serve file-plane path:
		//   /files/<prefix-after-files>/<dir>/<file>
		// bk.BaseURL is already "/files/<lib>", so prefix = "files/<lib>".
		return serveURL + prefix + "/" + f.DirectoryPath + "/" + f.Name, true
	}

	probe := func(bk *calibre.Book) bool {
		u, ok := blobURL(bk)
		if !ok {
			return false
		}
		// HEAD may not be supported by the file plane; use GET with a tiny
		// range and accept 200/206.
		req, err := http.NewRequest(http.MethodGet, u, nil)
		if err != nil {
			return false
		}
		req.Header.Set("Range", "bytes=0-0")
		resp, err := client.Do(req)
		if err != nil {
			return false
		}
		io.Copy(io.Discard, resp.Body)
		resp.Body.Close()
		return resp.StatusCode == http.StatusOK || resp.StatusCode == http.StatusPartialContent
	}

	// Pinned id (env override, else a known-present default) — resolve and
	// return it directly. No probe: the download itself verifies the blob.
	pinned := os.Getenv("WASABI_SMOKE_BOOK_ID")
	usingDefault := pinned == ""
	if usingDefault {
		pinned = defaultPinnedBookID
	}
	if pinned != "" {
		bk, err := opened.LookupByID(context.Background(), pinned)
		if err == nil && bk != nil {
			return bk
		}
		if !usingDefault {
			t.Fatalf("WASABI_SMOKE_BOOK_ID=%s did not resolve in the aggregate index: %v", pinned, err)
		}
		t.Logf("wasabi smoke: default pin %s not in this aggregate — falling back to discovery", pinned)
	}

	// Spread sample across the whole index, oldest-first (recently-added books
	// often lack S3 blobs — the index↔blob mismatch). Each probe is a real
	// Wasabi round-trip through the serve VFS, so keep it bounded.
	_, total, err := opened.PageBooks(context.Background(), 0, 1)
	if err != nil {
		t.Fatalf("PageBooks(total probe): %v", err)
	}
	if total == 0 {
		return nil
	}
	const maxProbes = 80
	step := total / maxProbes
	if step < 1 {
		step = 1
	}
	const maxBookBytes = 20 << 20 // 20 MiB cap so a run never pulls a large file
	probed := 0
	for offset := total - 1; offset >= 0 && probed < maxProbes; offset -= step {
		books, _, err := opened.PageBooks(context.Background(), offset, 1)
		if err != nil || len(books) == 0 {
			continue
		}
		bk := books[0]
		if len(bk.Formats) == 0 || bk.Formats[0].Size <= 0 || bk.Formats[0].Size > maxBookBytes {
			continue
		}
		probed++
		if probe(bk) {
			return bk
		}
	}
	t.Logf("probed %d candidate books spread across %d index entries (oldest-first); none had a present S3 blob", probed, total)
	return nil
}

// firstTitleToken returns a lowercased first word of the title, suitable as a
// prefix search query that should match the book itself.
func firstTitleToken(title string) string {
	fields := strings.Fields(title)
	if len(fields) == 0 {
		return title
	}
	tok := strings.ToLower(fields[0])
	tok = strings.TrimRight(tok, ".,:;!?\"'")
	if tok == "" {
		return strings.ToLower(title)
	}
	return tok
}
