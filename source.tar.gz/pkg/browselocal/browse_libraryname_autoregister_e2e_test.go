//go:build integration && calibre_e2e

package browselocal

import (
	"context"
	"encoding/json"
	"os"
	"os/exec"
	"path/filepath"
	"testing"
	"time"
)

// TestBrowse_E2E_LibraryNameAutoRegister exercises the one wire seam of the
// named-source-indices feature: a library built with `--library-name`, served over
// clearnet, then browsed — asserting that `lib browse`'s auto-registration writes
// the slugified handle (+ raw display name + UUID) into the client's indices.json.
//
// Auto-registration fires during the online SYNC, before browselocal.Run launches
// chromium — so we run `lib browse`, neuter the browser launch (ROD_BROWSER_BIN to a
// non-browser so it fails fast and no window appears), poll for the registry entry,
// then stop. No rod/browser driving, no GCE.
//
// It also empirically settles the design choice: the pointer carries the RAW human
// name (`"Test Library"` / librarian `"Marcell Mars"`) while the registry KEY is the
// slug (`test-library`).
func TestBrowse_E2E_LibraryNameAutoRegister(t *testing.T) {
	if _, err := exec.LookPath("calibredb"); err != nil {
		t.Skip("calibredb not on PATH")
	}
	if _, err := os.Stat(filepath.Join(fooBarLib, "metadata.db")); err != nil {
		t.Skipf("needs a real Calibre library at %s", fooBarLib)
	}
	bin := buildAccorderBinary(t)

	// --- publisher side: build with --library-name, serve over clearnet. ---
	serveEnv := append(os.Environ(), "XDG_CONFIG_HOME="+t.TempDir())
	tmpLib := filepath.Join(t.TempDir(), "lib")
	if out, err := exec.Command("cp", "-r", fooBarLib, tmpLib).CombinedOutput(); err != nil {
		t.Fatalf("copy library: %v\n%s", err, out)
	}
	idxBase := filepath.Join(tmpLib, "static", "library_index")
	build := exec.Command(bin, "lib", "build", "--calibrepath", tmpLib,
		"--index", "--index-path", idxBase, "--compact",
		"--librarian", "Marcell Mars", "--libraryID", fooBarUUID,
		"--library-name", "Test Library")
	build.Env = serveEnv
	if out, err := build.CombinedOutput(); err != nil {
		t.Fatalf("lib build --library-name: %v\n%s", err, out)
	}

	addr := freeLoopbackAddr(t)
	sctx, scancel := context.WithCancel(context.Background())
	defer scancel()
	srv := exec.CommandContext(sctx, bin, "lib", "share", "live", "serveit",
		"--calibrepath", tmpLib, "--index-path", idxBase,
		"--librarian", "Marcell Mars", "--libraryID", fooBarUUID,
		"--only-http", "--mode", "public", "--listen", addr)
	srv.Env = serveEnv
	if err := srv.Start(); err != nil {
		t.Fatalf("start lib share live: %v", err)
	}
	defer func() { scancel(); _ = srv.Wait() }()
	base := "http://" + addr + "/"
	waitHTTP(t, base, 30*time.Second)

	// --- client side: browse, which auto-registers the source during sync. ---
	browseCfg := t.TempDir()
	bctx, bcancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer bcancel()
	browse := exec.CommandContext(bctx, bin, "lib", "browse", "myreading",
		"--http-endpoint", base, "--calibrepath", t.TempDir())
	browse.Env = append(os.Environ(),
		"XDG_CONFIG_HOME="+browseCfg,
		"ROD_BROWSER_BIN=/bin/false", // fail the browser launch fast (after sync+register)
	)
	if err := browse.Start(); err != nil {
		t.Fatalf("start lib browse: %v", err)
	}
	defer func() { bcancel(); _ = browse.Wait() }()

	// Poll for indices.json to capture the source (written atomically during sync).
	regPath := filepath.Join(browseCfg, "accorder", "indices.json")
	type entry struct {
		UUID        string `json:"uuid"`
		Endpoint    string `json:"endpoint"`
		LibraryName string `json:"libraryName"`
		Librarian   string `json:"librarian"`
	}
	var reg map[string]entry
	deadline := time.Now().Add(40 * time.Second)
	for time.Now().Before(deadline) {
		if data, err := os.ReadFile(regPath); err == nil {
			if json.Unmarshal(data, &reg) == nil && len(reg) > 0 {
				break
			}
		}
		time.Sleep(500 * time.Millisecond)
	}
	bcancel()

	e, ok := reg["test-library"]
	if !ok {
		t.Fatalf("indices.json missing slug key 'test-library' — auto-register did not capture the --library-name; got %+v", reg)
	}
	if e.UUID != fooBarUUID {
		t.Errorf("registry uuid = %q, want %q", e.UUID, fooBarUUID)
	}
	// Design assertion: the handle is the slug; the display fields stay raw.
	if e.LibraryName != "Test Library" {
		t.Errorf("registry libraryName = %q, want raw %q", e.LibraryName, "Test Library")
	}
	if e.Librarian != "Marcell Mars" {
		t.Errorf("registry librarian = %q, want raw %q", e.Librarian, "Marcell Mars")
	}
	t.Logf("OK: auto-registered handle 'test-library' → uuid %s (display name %q, librarian %q)",
		e.UUID, e.LibraryName, e.Librarian)
}
