//go:build integration && calibre_e2e

package browselocal

import (
	"context"
	"os"
	"os/exec"
	"path/filepath"
	"testing"
	"time"
)

// TestBrowse_E2E_ClearnetFedlibRender drives the lib-browse CLIENT end to end over
// plain HTTP against a real single-library `lib share live` — the reader→librarian
// render leg (doc steps 1 + 5): sync the served catalog, browse, queue a book that
// carries a real format, download its files over HTTP /files/, then import + build
// into a fresh local Calibre library, asserted with calibredb.
//
// This is the local de-risk for the GCE in-wild variant, which reuses the same
// session + rod chain (newClearnetRenderSession + browseRenderAndImport) pointed at
// the live operator. Skips cleanly without calibredb or the local library.
const fooBarLib = "/home/w/CalibreLibraries/FooBar"
const fooBarUUID = "d00a1023-feca-46fd-9b20-d9264568a542"

func TestBrowse_E2E_ClearnetFedlibRender(t *testing.T) {
	if _, err := exec.LookPath("calibredb"); err != nil {
		t.Skip("calibredb not on PATH; render leg requires Calibre")
	}
	if _, err := os.Stat(filepath.Join(fooBarLib, "metadata.db")); err != nil {
		t.Skipf("render leg needs a real Calibre library at %s", fooBarLib)
	}
	bin := buildAccorderBinary(t)
	hermetic := append(os.Environ(), "XDG_CONFIG_HOME="+t.TempDir())

	// Work on a COPY so the real library is never mutated (lib share live writes a
	// _GENERATION sentinel + index into the calibre dir). Rebuild the index with this
	// binary so it is current MWSC (the checked-in index may be a stale format).
	tmpLib := filepath.Join(t.TempDir(), "lib")
	if out, err := exec.Command("cp", "-r", fooBarLib, tmpLib).CombinedOutput(); err != nil {
		t.Fatalf("copy library: %v\n%s", err, out)
	}
	idxBase := filepath.Join(tmpLib, "static", "library_index")
	rebuild := exec.Command(bin, "lib", "build", "--calibrepath", tmpLib,
		"--index", "--index-path", idxBase, "--compact",
		"--librarian", "foolib", "--libraryID", fooBarUUID)
	rebuild.Env = hermetic
	if out, err := rebuild.CombinedOutput(); err != nil {
		t.Fatalf("rebuild index: %v\n%s", err, out)
	}

	// Serve the single library over clearnet HTTP (public).
	addr := freeLoopbackAddr(t)
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	srv := exec.CommandContext(ctx, bin, "lib", "share", "live", "renderfoo",
		"--calibrepath", tmpLib, "--index-path", idxBase,
		"--librarian", "foolib", "--libraryID", fooBarUUID,
		"--only-http", "--mode", "public", "--listen", addr)
	srv.Env = hermetic
	if err := srv.Start(); err != nil {
		t.Fatalf("start lib share live: %v", err)
	}
	defer func() { cancel(); _ = srv.Wait() }()
	base := "http://" + addr + "/"
	waitHTTP(t, base, 30*time.Second)

	session := newClearnetRenderSession(t, base)
	browseRenderAndImport(t, session, firstDownloadableTitle(t, session))
}
