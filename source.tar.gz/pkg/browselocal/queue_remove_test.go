//go:build integration

package browselocal

import (
	"encoding/json"
	"testing"
)

// TestQueueRemoveAndClear exercises the two new queue handlers directly against
// a real librarySession: the per-row [X] (queue/remove) and the QUEUE header [X]
// (queue/clearNotDownloading, which keeps only in-flight downloads).
func TestQueueRemoveAndClear(t *testing.T) {
	s := &librarySession{
		opts:  Options{DownloadDir: t.TempDir()},
		queue: nil,
	}
	s.queue = []*queueItem{
		{BookID: "a", Status: statusQueued},
		{BookID: "b", Status: statusDownloading},
		{BookID: "c", Status: statusDone},
		{BookID: "d", Status: statusQueued},
	}

	ids := func() []string {
		out := []string{}
		for _, it := range s.queue {
			out = append(out, it.BookID)
		}
		return out
	}

	// per-row [X]: remove just "a".
	args, _ := json.Marshal(map[string]string{"book_id": "a"})
	if _, err := s.handleQueueRemove(args); err != nil {
		t.Fatalf("handleQueueRemove: %v", err)
	}
	if got := ids(); len(got) != 3 || got[0] != "b" {
		t.Fatalf("after remove(a): queue = %v, want [b c d]", got)
	}
	t.Logf("OK: queue/remove dropped one book → %v", ids())

	// header [X]: clear all NOT downloading → only "b" (downloading) survives.
	if _, err := s.handleQueueClearNotDownloading(); err != nil {
		t.Fatalf("handleQueueClearNotDownloading: %v", err)
	}
	if got := ids(); len(got) != 1 || got[0] != "b" {
		t.Fatalf("after clearNotDownloading: queue = %v, want [b]", got)
	}
	t.Logf("OK: queue/clearNotDownloading kept only the downloading book → %v", ids())
}
