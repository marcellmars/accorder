//go:build integration

package browselocal

import (
	"encoding/json"
	"path/filepath"
	"sync"
	"testing"
	"time"

	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/launcher"
	"github.com/ysmood/gson"
)

// TestBrowse_E2E_LibrariansDropdown reproduces the bug where, in a live browse
// (SELECT) session, the LIBRARIANS dropdown stayed empty: MotwHeader.fetchLibrarians
// derived librarians from the local portable shard (mock) instead of the backend
// index, and its raw fetch("/librarians/on") fallback has no server on a file://
// page. It now prefers the backend (library/librarians). This test opens the
// dropdown and asserts it (a) populates from the backend and (b) renders ON TOP
// of the page chrome (a stacking-order regression guard for the menu's z-index).
func TestBrowse_E2E_LibrariansDropdown(t *testing.T) {
	dir := writeFixture(t)

	l := launcher.New().Headless(true)
	u, err := l.Launch()
	if err != nil {
		t.Fatalf("launcher: %v", err)
	}
	defer l.Cleanup()
	browser := rod.New().ControlURL(u)
	if err := browser.Connect(); err != nil {
		t.Fatalf("rod.Connect: %v", err)
	}
	defer browser.Close()
	page := browser.MustPage("about:blank")
	defer page.Close()

	var mu sync.Mutex
	var librariansCalls int
	page.MustExpose("backend_rpc", func(arg gson.JSON) (interface{}, error) {
		var c rpcCall
		if err := json.Unmarshal([]byte(arg.Str()), &c); err != nil {
			return nil, err
		}
		switch c.Service + "/" + c.Method {
		case "session/mode":
			return "browse", nil
		case "library/settings/get":
			return map[string]any{"library_path": "/tmp/lib", "librarian": "test"}, nil
		case "library/books":
			return map[string]any{
				"_items": []map[string]any{{"_id": "b1", "title": "Book b1", "authors": []string{"A"}, "librarian": "alice", "library_url": "", "cover_url": "", "tags": []string{}, "formats": []map[string]any{}, "last_modified": "2024-01-01"}},
				"_meta":  map[string]any{"total": 1, "page": 1, "max_results": 48},
				"_links": map[string]any{"self": map[string]any{"href": "/books"}},
			}, nil
		case "library/librarians":
			mu.Lock()
			librariansCalls++
			mu.Unlock()
			return map[string]any{"_items": []string{"alice", "bob", "carol"}}, nil
		}
		return map[string]any{"_items": []any{}}, nil
	})

	watchConsole(t, page)

	if err := page.Navigate("file://" + filepath.Join(dir, "BROWSE_LIBRARY.html") + "#/?t=l"); err != nil {
		t.Fatalf("navigate: %v", err)
	}

	// Wait for the LIBRARIANS dropdown button to render.
	page.Timeout(15 * time.Second).MustWait(`() => [...document.querySelectorAll('button')].some(b => b.textContent.trim().toUpperCase().includes('LIBRARIANS'))`)

	// Open the dropdown (fires fetchLibrarians → library/librarians).
	page.MustEval(`() => {
		const b = [...document.querySelectorAll('button')].find(x => x.textContent.trim().toUpperCase().includes('LIBRARIANS'));
		if (!b) throw new Error("no LIBRARIANS button");
		b.click();
	}`)

	// The list populates with the backend-provided librarians (rendered uppercased).
	page.Timeout(5 * time.Second).MustWait(`() => {
		const items = [...document.querySelectorAll('li.dropdown-li')].map(e => e.textContent.trim());
		return items.includes("ALICE") && items.includes("BOB") && items.includes("CAROL");
	}`)

	mu.Lock()
	got := librariansCalls
	mu.Unlock()
	if got < 1 {
		t.Fatalf("library/librarians was not called (got %d); dropdown did not route through the backend", got)
	}

	// Stacking guard: each rendered librarian row must be the TOPMOST element at
	// its own center (i.e. the menu overlays the search bar / page chrome, not the
	// other way around).
	buried := page.MustEval(`() => {
		const rows = [...document.querySelectorAll('li.dropdown-li')].filter(e => ["ALICE","BOB","CAROL"].includes(e.textContent.trim()));
		return rows.filter(li => {
			const r = li.getBoundingClientRect();
			const top = document.elementFromPoint(r.left + r.width/2, r.top + r.height/2);
			return top !== li && !li.contains(top);
		}).map(li => li.textContent.trim());
	}`).Arr()
	if len(buried) != 0 {
		t.Fatalf("LIBRARIANS dropdown rows are hidden behind other elements: %v", buried)
	}

	t.Logf("OK: LIBRARIANS dropdown populated via backend (called %d×) and renders on top", got)
}
