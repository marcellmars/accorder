//go:build integration

package browselocal

import (
	"net/url"
	"testing"

	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/launcher"
	"github.com/ysmood/gson"
)

// TestRodSmoke proves the go-rod toolchain works in this codebase: launches
// a headless Chromium, evals a JS expression, asserts the round-trip.
// If this fails, every browse-session test downstream of it will also fail.
func TestRodSmoke(t *testing.T) {
	l := launcher.New().Headless(true)
	u, err := l.Launch()
	if err != nil {
		t.Fatalf("launcher: %v", err)
	}
	defer l.Cleanup()

	browser := rod.New().ControlURL(u)
	if err := browser.Connect(); err != nil {
		t.Fatalf("rod.Connect: %v", err)
	}
	defer browser.Close()

	page := browser.MustPage("about:blank")
	defer page.Close()

	got := page.MustEval("() => 6 * 7").Int()
	if got != 42 {
		t.Fatalf("page.Eval(6*7) = %d, want 42", got)
	}
}

// TestRodMustExposeRoundTrip proves the same MustExpose("backend_rpc",...)
// pattern that browselocal uses works end-to-end: Go function exposed,
// JS calls it, return value flows back. Documented quirk: the exposed
// callback receives a single gson.JSON arg (NOT proto.RuntimeBindingCalled
// as the proposal originally assumed — captured in propose.md [PATTERN]).
func TestRodMustExposeRoundTrip(t *testing.T) {
	l := launcher.New().Headless(true)
	u, err := l.Launch()
	if err != nil {
		t.Fatalf("launcher: %v", err)
	}
	defer l.Cleanup()

	browser := rod.New().ControlURL(u)
	if err := browser.Connect(); err != nil {
		t.Fatalf("rod.Connect: %v", err)
	}
	defer browser.Close()

	// Minimal HTML so the page has a document for MustExpose to bind to.
	page := browser.MustPage("data:text/html," + url.PathEscape("<!doctype html><title>smoke</title>"))
	defer page.Close()

	page.MustExpose("backend_rpc", func(arg gson.JSON) (interface{}, error) {
		return map[string]any{"echo": arg.Str()}, nil
	})

	got := page.MustEval(`async () => {
		const r = await window.backend_rpc("hello-from-test");
		return r.echo;
	}`).Str()
	if got != "hello-from-test" {
		t.Fatalf("backend_rpc round-trip = %q, want %q", got, "hello-from-test")
	}
}
