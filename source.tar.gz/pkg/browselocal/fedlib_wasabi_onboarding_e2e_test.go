//go:build integration && wasabi_e2e

package browselocal

import (
	"accorder/pkg/calibre"
	"accorder/pkg/fedlibinvite"
	"accorder/pkg/torshare"
	"bytes"
	"context"
	"encoding/json"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"slices"
	"strings"
	"testing"
	"time"
)

// TestFedlib_E2E_WasabiOnboarding exercises the full member-onboarding AND ongoing
// maintenance story end to end against REAL Wasabi S3, on throwaway prefixes
// (purged before+after):
//
//	Onboard:     fedlib members invite biopolitics → lib join → lib upload (G1)
//	Bootstrap:   fedlib build (invited-only → empty aggregate, #3) → fedlib share live
//	First pub:   poller reconciles invited→ready (G4) + in-process rebuild (G2) → 2 books live
//	Maintenance: librarian re-publishes a FULL rebuild (new lineage, gen resets to 0) with a
//	             3rd book → fedlib auto-updates with NO manual build (#2: full base+gen compare)
//	2nd member:  operator invites a second librarian WHILE serving → poller picks it up with
//	             no restart (#5 refresh + #6 atomic registry) → its book goes live too
//

// The member index + _GENERATION are seeded in Go to model both normal and
// lineage-reset maintenance builds. Each publication then runs the real
// `lib build` checkpoint followed by the real `lib upload` (G1 credential
// resolution + bucket-prefix fix); the fedlib serve/poll/reconcile/rebuild is
// all real product code.
//

// Run: go test -tags 'integration wasabi_e2e' -run TestFedlib_E2E_WasabiOnboarding ./pkg/browselocal/
func TestFedlib_E2E_WasabiOnboarding(t *testing.T) {
	c, ok := resolveWasabiFullKeys(t)
	if !ok {
		t.Skip("onboarding e2e: wasabi_full.keys not found at repo root — skipping live test")
	}

	// Member identities are no longer test constants: the operator mints
	// them at invite time (operator-minted-member-uuid), so bioID / secID /
	// thiID are derived from the invite blobs below and every publish runs
	// under the minted identity — reconcile is a same-key confirm, not a
	// rekey.
	const (
		bioPfx = "zz-e2e-onboard-biop"
		bioAl  = "biop-onb"
		secPfx = "zz-e2e-onboard-second"
		secAl  = "second-onb"
		thiPfx = "zz-e2e-onboard-third"
		aggPfx = "zz-e2e-onboard-agg"
		fedID  = "zz-e2e-fedlib"
		pass   = "e2e-onboard-pass"
	)

	bin := buildAccorderBinary(t)
	cfgDir := t.TempDir()
	work := t.TempDir()
	env := append(os.Environ(),
		"XDG_CONFIG_HOME="+cfgDir,
		"ACCORDER_SECRETS_PASSPHRASE="+pass,
	)
	s3 := []string{
		"--bucket", "motw",
		"--s3-access-key", c.accessKey, "--s3-secret-key", c.secretKey,
		"--s3-provider", "Wasabi", "--s3-endpoint", "s3.wasabisys.com",
	}

	purge := func() {
		_ = rclonePurge(c, "motw/"+bioPfx)
		_ = rclonePurge(c, "motw/"+secPfx)
		_ = rclonePurge(c, "motw/"+thiPfx)
		_ = rclonePurge(c, "motw/"+aggPfx)
	}
	purge()
	t.Cleanup(purge)

	runAcc := func(args ...string) string {
		t.Helper()
		cmd := exec.Command(bin, args...)
		cmd.Env = env
		out, err := cmd.CombinedOutput()
		if err != nil {
			t.Fatalf("accorder %s failed: %v\n%s", strings.Join(args, " "), err, out)
		}
		return string(out)
	}

	// runAccJoin drives a credentials-only `lib join` — every join in this
	// test seeds and publishes separately, so none passes -c. Since the
	// incomplete-join contract (join-adopts-local-profile) that shape exits
	// non-zero with a "published nothing" report; that ending is expected
	// here, while any other failure still fails the test.
	runAccJoin := func(env []string, args ...string) string {
		t.Helper()
		cmd := exec.Command(bin, args...)
		cmd.Env = env
		out, err := cmd.CombinedOutput()
		if err != nil && !strings.Contains(string(out), "published nothing") {
			t.Fatalf("accorder %s failed: %v\n%s", strings.Join(args, " "), err, out)
		}
		return string(out)
	}
	// publishMember runs the required build checkpoint before the REAL
	// `lib upload` (G1 path: secrets-store credential resolution + bucket-prefix
	// scoping). A full-reupload authorization is valid only after this build has
	// established exactly which local catalogue and files it describes.
	publishMember := func(libDir, al, librarian, libID, pfx string, allowFullReupload bool) {
		t.Helper()
		runAcc("lib", "build", al,
			"--calibrepath", libDir,
			"--librarian", librarian,
			"--libraryID", libID,
			"--jsonl-path", filepath.Join(libDir, "books.jsonl"),
			"--index-path", filepath.Join(libDir, "static", "library_index"),
			"--index")
		args := []string{"lib", "upload", al, "--passphrase", pass, "--calibrepath", libDir,
			"--librarian", librarian, "--libraryID", libID}
		if allowFullReupload {
			// seedMemberLibrary deliberately replaces the index with a new full
			// lineage. The build above records that fact before this explicit
			// authorization permits its potentially complete transfer.
			args = append(args, "--allow-full-reupload")
		}
		runAcc(args...)
		if !wasabiPathExists(t, c, "motw/"+pfx+"/static/library_index.zst") ||
			!wasabiPathExists(t, c, "motw/"+pfx+"/_GENERATION") {
			t.Fatalf("lib upload for %s did not land index + _GENERATION at motw/%s/", pfx, pfx)
		}
	}

	// --- Phase 1+2: invite biopolitics, join, publish 2 books ---
	inviteOut := runAcc("fedlib", "members", "invite", fedID, "biopolitics",
		"--prefix", bioPfx,
		"--bucket", "motw", "--s3-access-key", c.accessKey, "--s3-secret-key", c.secretKey,
		"--s3-provider", "Wasabi", "--s3-endpoint", "s3.wasabisys.com", "--fedlib-path", work)
	blob := reInvite.FindString(inviteOut)
	if blob == "" {
		t.Fatalf("invite did not print a blob:\n%s", inviteOut)
	}

	// Operator-minted identity: the blob carries the minted UUID and the
	// registry is keyed by it from day one — no invited:<prefix> placeholder.
	inv1, err := fedlibinvite.DecodeWriteInvite(blob)
	if err != nil {
		t.Fatalf("decode invite blob: %v", err)
	}
	bioID := inv1.LibraryID
	if bioID == "" {
		t.Fatalf("invite blob carries no minted library_id:\n%s", inviteOut)
	}
	assertMemberState(t, filepath.Join(work, "members.json"), bioID, "invited")
	if _, ok := readMembers(t, filepath.Join(work, "members.json"))["invited:"+bioPfx]; ok {
		t.Fatalf("new binary wrote a legacy invited:%s placeholder", bioPfx)
	}
	runAccJoin(env, "lib", "join", bioAl, "-I", blob, "--passphrase", pass)

	bioDir := t.TempDir()
	seedMemberLibrary(t, bioDir, inv1.DictID, []*calibre.Book{
		fpBook("bp-1", "Discipline and Punish", "Michel Foucault", "biopolitics", bioID, ""),
		fpBook("bp-2", "The History of Sexuality", "Michel Foucault", "biopolitics", bioID, ""),
	})
	publishMember(bioDir, bioAl, "biopolitics", bioID, bioPfx, false)

	if wasabiPathExists(t, c, "motw/static/library_index.zst") {
		t.Fatalf("DANGER: index landed at the shared motw ROOT — bucket-prefix fix regressed")
	}
	t.Logf("OK: G1 — biopolitics published to motw/%s/ via secrets-store creds, bucket root untouched", bioPfx)

	// --- Phase 3: bootstrap from an INVITED-ONLY roster (#3) + serve ---
	runAcc(append([]string{"fedlib", "build", "--output-path", work, "--upload-prefix", aggPfx}, s3...)...)
	if _, err := os.Stat(filepath.Join(work, "library_index.zst")); err != nil {
		t.Fatalf("initial (empty) aggregate not produced: %v", err)
	}

	// Seed the federation descriptor: the serve reads storage-identity facts
	// from it via its positional (one name); only the S3 access/secret keys
	// stay as serve flags. (members invite already wrote
	// bucket/provider/endpoint through; this completes upload-prefix.)
	runAcc("fedlib", "config", "set", fedID,
		"--bucket", "motw", "--s3-provider", "Wasabi", "--s3-endpoint", "s3.wasabisys.com",
		"--upload-prefix", aggPfx)

	addr := freeLoopbackAddr(t)
	serveCtx, cancel := context.WithCancel(context.Background())
	defer cancel()
	var serveLog bytes.Buffer
	serveArgs := []string{"fedlib", "share", "live", fedID, "--aggregate-path", work,
		"--s3-access-key", c.accessKey, "--s3-secret-key", c.secretKey,
		"--only-http", "--mode", "public", "--poll-interval", "3", "--listen", addr}
	srv := exec.CommandContext(serveCtx, bin, serveArgs...)
	srv.Env = env
	srv.Stdout = &serveLog
	srv.Stderr = &serveLog
	if err := srv.Start(); err != nil {
		t.Fatalf("start fedlib share live: %v", err)
	}
	defer func() { cancel(); _ = srv.Wait() }()

	base := "http://" + addr + "/"
	waitHTTP(t, base, 90*time.Second)

	// --- G4: invited→ready — same-key state flip (the registry was keyed by
	// the minted UUID at invite time, so reconcile confirms rather than rekeys) ---
	if !waitFor(60*time.Second, func() bool {
		reg := readMembers(t, filepath.Join(work, "members.json"))
		bio, real := reg[bioID]
		return real && bio.State == "ready"
	}) {
		t.Fatalf("biopolitics not flipped invited→ready in 60s\n%s\nserve:\n%s",
			mustRead(filepath.Join(work, "members.json")), serveLog.String())
	}
	if !strings.Contains(serveLog.String(), "confirmed: invited→ready") {
		t.Fatalf("reconcile took the rekey path instead of the same-key confirm\nserve:\n%s", serveLog.String())
	}
	t.Logf("OK: G4 — biopolitics confirmed invited→ready under the minted key (UUID %s)", bioID)

	// --- G2: first publish's 2 books live ---
	if !waitFor(30*time.Second, func() bool {
		b := httpGetBody(t, base+"books")
		return strings.Contains(b, "Discipline and Punish") && strings.Contains(b, "The History of Sexuality")
	}) {
		t.Fatalf("biopolitics' 2 books not served after reconcile+hot-swap\nserve:\n%s", serveLog.String())
	}
	t.Log("OK: G2 — biopolitics' 2 books live after reconcile + in-process rebuild + hot-swap")

	// --- Maintenance (#2): librarian re-publishes a FULL rebuild (new lineage, gen→0) + a 3rd book ---
	seedMemberLibrary(t, bioDir, inv1.DictID, []*calibre.Book{
		fpBook("bp-1", "Discipline and Punish", "Michel Foucault", "biopolitics", bioID, ""),
		fpBook("bp-2", "The History of Sexuality", "Michel Foucault", "biopolitics", bioID, ""),
		fpBook("bp-3", "Society Must Be Defended", "Michel Foucault", "biopolitics", bioID, ""),
	})

	// Re-publish via the REAL lib upload (headless).
	publishMember(bioDir, bioAl, "biopolitics", bioID, bioPfx, true)
	if !waitFor(40*time.Second, func() bool {
		return strings.Contains(httpGetBody(t, base+"books"), "Society Must Be Defended")
	}) {
		t.Fatalf("maintenance re-publish (full rebuild) did NOT propagate — #2 regression\nserve:\n%s", serveLog.String())
	}
	t.Log("OK: #2 — a full re-publish (new BaseGeneration, gen=0) auto-propagated to the live aggregate")

	// --- Second member (#5): invite + publish WHILE serving, no restart ---
	inviteOut2 := runAcc("fedlib", "members", "invite", fedID, "secondlib",
		"--prefix", secPfx,
		"--bucket", "motw", "--s3-access-key", c.accessKey, "--s3-secret-key", c.secretKey,
		"--s3-provider", "Wasabi", "--s3-endpoint", "s3.wasabisys.com", "--fedlib-path", work)
	blob2 := reInvite.FindString(inviteOut2)
	if blob2 == "" {
		t.Fatalf("second invite did not print a blob:\n%s", inviteOut2)
	}
	inv2, err := fedlibinvite.DecodeWriteInvite(blob2)
	if err != nil || inv2.LibraryID == "" {
		t.Fatalf("second invite blob has no minted library_id (err %v):\n%s", err, inviteOut2)
	}
	secID := inv2.LibraryID
	runAccJoin(env, "lib", "join", secAl, "-I", blob2, "--passphrase", pass)
	secDir := t.TempDir()
	seedMemberLibrary(t, secDir, inv2.DictID, []*calibre.Book{
		fpBook("se-1", "Second Member Title", "Other Author", "secondlib", secID, ""),
	})
	publishMember(secDir, secAl, "secondlib", secID, secPfx, false)
	if !waitFor(60*time.Second, func() bool {
		return strings.Contains(httpGetBody(t, base+"books"), "Second Member Title")
	}) {
		t.Fatalf("second member invited mid-serve was NOT picked up without restart — #5 regression\n%s\nserve:\n%s",
			mustRead(filepath.Join(work, "members.json")), serveLog.String())
	}
	t.Log("OK: #5 — a second member invited WHILE serving was reconciled + served with no restart")

	// --- #6: remove a book, then add the SAME book back — everything else stays live ---
	bp1 := fpBook("bp-1", "Discipline and Punish", "Michel Foucault", "biopolitics", bioID, "")
	bp2 := fpBook("bp-2", "The History of Sexuality", "Michel Foucault", "biopolitics", bioID, "")
	bp3 := func() *calibre.Book {
		return fpBook("bp-3", "Society Must Be Defended", "Michel Foucault", "biopolitics", bioID, "")
	}
	otherStillThere := func(body string) bool {

		// the other biopolitics book AND the second member must remain throughout
		return strings.Contains(body, "Discipline and Punish") && strings.Contains(body, "Second Member Title")
	}

	// 6a. remove bp-3 (re-publish biopolitics with 2 books)
	seedMemberLibrary(t, bioDir, inv1.DictID, []*calibre.Book{bp1, bp2})
	publishMember(bioDir, bioAl, "biopolitics", bioID, bioPfx, true)
	if !waitFor(40*time.Second, func() bool {
		b := httpGetBody(t, base+"books")
		return !strings.Contains(b, "Society Must Be Defended") && otherStillThere(b)
	}) {
		t.Fatalf("book removal did not propagate to the live aggregate (or other content was lost)\nserve:\n%s", serveLog.String())
	}
	t.Log("OK: #6a — removed book dropped from the live aggregate; other book + 2nd member intact")

	// 6b. add the SAME book back (re-publish biopolitics with 3 books)
	seedMemberLibrary(t, bioDir, inv1.DictID, []*calibre.Book{bp1, bp2, bp3()})
	publishMember(bioDir, bioAl, "biopolitics", bioID, bioPfx, true)
	if !waitFor(40*time.Second, func() bool {
		b := httpGetBody(t, base+"books")
		return strings.Contains(b, "Society Must Be Defended") && otherStillThere(b)
	}) {
		t.Fatalf("re-added book did not reappear in the live aggregate\nserve:\n%s", serveLog.String())
	}
	t.Log("OK: #6b — re-added book reappeared; everything else still working")

	// --- Re-invite (fedlib-reinvite-identity): re-invite the SAME ready prefix,
	// join from a FRESH config dir (new seat), publish a 4th book with the
	// ADOPTED identity (no --libraryID/--librarian flags) → the live aggregate
	// swaps under the existing UUID with no restart, registry untouched. ---
	regBefore := readMembers(t, filepath.Join(work, "members.json"))

	// Label omitted: must default to the registry librarian ("biopolitics").
	reinviteOut := runAcc("fedlib", "members", "invite", fedID,
		"--prefix", bioPfx,
		"--bucket", "motw", "--s3-access-key", c.accessKey, "--s3-secret-key", c.secretKey,
		"--s3-provider", "Wasabi", "--s3-endpoint", "s3.wasabisys.com", "--fedlib-path", work)
	if !strings.Contains(reinviteOut, "re-inviting existing member") {
		t.Fatalf("re-invite did not log the re-invite branch:\n%s", reinviteOut)
	}
	blob3 := reInvite.FindString(reinviteOut)
	if blob3 == "" {
		t.Fatalf("re-invite did not print a blob:\n%s", reinviteOut)
	}
	inv3, err := fedlibinvite.DecodeWriteInvite(blob3)
	if err != nil {
		t.Fatalf("decode re-invite blob: %v", err)
	}
	if inv3.LibraryID != bioID {
		t.Fatalf("re-invite blob library_id = %q, want existing member UUID %q", inv3.LibraryID, bioID)
	}
	if inv3.Label != "biopolitics" {
		t.Fatalf("re-invite blob label = %q, want defaulted registry librarian", inv3.Label)
	}

	// Re-invite of a ready member must not touch the registry.
	regAfter := readMembers(t, filepath.Join(work, "members.json"))
	if len(regAfter) != len(regBefore) {
		t.Fatalf("re-invite changed the registry: before %v, after %v", regBefore, regAfter)
	}
	if _, ok := regAfter["invited:"+bioPfx]; ok {
		t.Fatalf("re-invite resurrected the invited:%s placeholder", bioPfx)
	}

	// The emitted member CLI lines embed the same blob + the prefix as alias.
	if !strings.Contains(reinviteOut, "accorder lib join "+bioPfx+" --invite '"+blob3+"'") {
		t.Fatalf("re-invite output missing the copy-pasteable join line:\n%s", reinviteOut)
	}

	// Fresh seat: brand-new config dir simulating the member's replacement machine.
	cfgDir2 := t.TempDir()
	env2 := append(os.Environ(),
		"XDG_CONFIG_HOME="+cfgDir2,
		"ACCORDER_SECRETS_PASSPHRASE="+pass,
	)
	runAcc2 := func(args ...string) string {
		t.Helper()
		cmd := exec.Command(bin, args...)
		cmd.Env = env2
		out, err := cmd.CombinedOutput()
		if err != nil {
			t.Fatalf("accorder (fresh seat) %s failed: %v\n%s", strings.Join(args, " "), err, out)
		}
		return string(out)
	}

	// The remote is COMMITTED by now. Headless (stdin is not a terminal) the
	// pull prompt in the committed branch never fires — its guard is
	// term.IsTerminal && !prompt — so the join pulls the published library
	// into the default destination and activates the invite identity itself.
	joinOut := runAccJoin(env2, "lib", "join", bioPfx, "-I", blob3)
	if !strings.Contains(joinOut, "adopted federation libraryID "+bioID) {
		t.Fatalf("fresh-seat join did not adopt the invite identity:\n%s", joinOut)
	}
	// Re-inviting transfers credentials and identity, not the active writer
	// lease. Model the operator's explicit replacement-machine takeover rather
	// than teaching the join path to steal a healthy publisher seat.
	runAcc2("lib", "seat", "claim", bioPfx, "--force")

	// Publish a 4th book from the fresh seat — identity resolves from the
	// adopted alias (no --libraryID/--librarian flags).
	bioDir2 := t.TempDir()
	seedMemberLibrary(t, bioDir2, inv3.DictID, []*calibre.Book{
		bp1, bp2, bp3(),
		fpBook("bp-4", "The Birth of Biopolitics", "Michel Foucault", "biopolitics", bioID, ""),
	})
	runAcc2("lib", "build", bioPfx,
		"--calibrepath", bioDir2,
		"--jsonl-path", filepath.Join(bioDir2, "books.jsonl"),
		"--index-path", filepath.Join(bioDir2, "static", "library_index"),
		"--index")
	runAcc2("lib", "upload", bioPfx, "--passphrase", pass, "--calibrepath", bioDir2,
		"--allow-full-reupload")
	if !waitFor(60*time.Second, func() bool {
		b := httpGetBody(t, base+"books")
		return strings.Contains(b, "The Birth of Biopolitics") && otherStillThere(b)
	}) {
		t.Fatalf("re-invited member's republish did not propagate under the existing UUID\nserve:\n%s", serveLog.String())
	}

	// Same UUID, no new registry entry, no invited: key — identity survived the seat swap.
	regFinal := readMembers(t, filepath.Join(work, "members.json"))
	if len(regFinal) != len(regBefore) {
		t.Fatalf("registry grew after re-invited republish: %v", regFinal)
	}
	if meta, ok := regFinal[bioID]; !ok || meta.State != "ready" {
		t.Fatalf("registry entry for %s missing or not ready: %v", bioID, regFinal)
	}
	t.Log("OK: re-invite — fresh seat adopted the existing UUID, republished, and the aggregate swapped in-process with no restart and no registry churn")

	// --- Offer leg (fedlib-invite-url): third member onboards via a claim-once
	// capability URL + B4 passphrase-free secrets, all mid-serve. The claim
	// POST goes over loopback HTTP (the local serve has no TLS); the
	// https-only client enforcement of `lib join <url>` is unit-tested
	// (TestJoinClaim_PlainHTTPRefused) and smoke-tested on the live nginx
	// deploy. ---
	offerOut := runAcc("fedlib", "members", "invite", fedID, "thirdlib",
		"--prefix", thiPfx,
		"--bucket", "motw", "--s3-access-key", c.accessKey, "--s3-secret-key", c.secretKey,
		"--s3-provider", "Wasabi", "--s3-endpoint", "s3.wasabisys.com", "--fedlib-path", work,
		"--offer", "--endpoint", "https://lib.example.org")
	if strings.Contains(offerOut, "accorder-fedlib-invite:") {
		t.Fatalf("offer mode leaked the invite blob:\n%s", offerOut)
	}
	if strings.Contains(offerOut, "export ACCORDER_SECRETS_PASSPHRASE=") {
		t.Fatalf("offer-mode hint still requires a passphrase export:\n%s", offerOut)
	}
	mURL := regexp.MustCompile(`https://lib\.example\.org/invite/([a-z2-7]{26})`).FindStringSubmatch(offerOut)
	if mURL == nil {
		t.Fatalf("offer did not print a claim URL:\n%s", offerOut)
	}
	token := mURL[1]

	// Operator-side visibility: the offer shows up in `fedlib invites list`.
	listOut := runAcc("fedlib", "invites", "list", fedID)
	if !strings.Contains(listOut, thiPfx) || !strings.Contains(listOut, "thirdlib") {
		t.Fatalf("invites list missing the sealed offer:\n%s", listOut)
	}

	// GET info is burn-free; POST claim is single-use (against the LIVE serve).
	infoResp, err := http.Get(base + "invite/" + token)
	if err != nil || infoResp.StatusCode != 200 {
		t.Fatalf("GET invite info: %v (status %v)\nserve:\n%s", err, infoResp, serveLog.String())
	}
	infoResp.Body.Close()
	claimResp, err := http.Post(base+"invite/"+token+"/claim", "application/json", nil)
	if err != nil {
		t.Fatalf("POST claim: %v", err)
	}
	var claimEnv struct {
		Version int    `json:"version"`
		Invite  string `json:"invite"`
	}
	if err := json.NewDecoder(claimResp.Body).Decode(&claimEnv); err != nil || claimEnv.Invite == "" {
		t.Fatalf("claim envelope: %v (status %d)", err, claimResp.StatusCode)
	}
	claimResp.Body.Close()
	again, err := http.Post(base+"invite/"+token+"/claim", "application/json", nil)
	if err != nil {
		t.Fatalf("second POST claim: %v", err)
	}
	again.Body.Close()
	if again.StatusCode != http.StatusNotFound {
		t.Fatalf("second claim: status %d, want 404 (single-use)", again.StatusCode)
	}

	// B4: fresh seat, NO passphrase anywhere in the environment.
	cfgDir3 := t.TempDir()
	env3 := append(os.Environ(), "XDG_CONFIG_HOME="+cfgDir3)
	env3 = slices.DeleteFunc(env3, func(s string) bool {
		return strings.HasPrefix(s, "ACCORDER_SECRETS_PASSPHRASE=")
	})
	runAcc3 := func(args ...string) string {
		t.Helper()
		cmd := exec.Command(bin, args...)
		cmd.Env = env3
		out, err := cmd.CombinedOutput()
		if err != nil {
			t.Fatalf("accorder (B4 seat) %s failed: %v\n%s", strings.Join(args, " "), err, out)
		}
		return string(out)
	}
	// Nothing is published under this prefix yet and no -c is given, so the
	// join ends in the incomplete-join report (non-zero by design); the leg's
	// subject is the generated key file and stored credentials.
	runAccJoin(env3, "lib", "join", thiPfx, "-I", claimEnv.Invite)
	if _, err := os.Stat(filepath.Join(cfgDir3, "accorder", "secrets.key")); err != nil {
		t.Fatalf("B4: passphrase-less join did not generate secrets.key: %v", err)
	}

	// The claimed offer rode the same minted-identity blob (study C3).
	invThi, err := fedlibinvite.DecodeWriteInvite(claimEnv.Invite)
	if err != nil || invThi.LibraryID == "" {
		t.Fatalf("claimed offer blob has no minted library_id (err %v)", err)
	}
	thiID := invThi.LibraryID

	thirdDir := t.TempDir()
	seedMemberLibrary(t, thirdDir, invThi.DictID, []*calibre.Book{
		fpBook("th-1", "Third Member Title", "Offer Author", "thirdlib", thiID, ""),
	})

	// Bare publish path: creds resolve from the key-file store, no env var.
	runAcc3("lib", "upload", thiPfx, "--calibrepath", thirdDir,
		"--librarian", "thirdlib", "--libraryID", thiID)
	if !waitFor(60*time.Second, func() bool {
		return strings.Contains(httpGetBody(t, base+"books"), "Third Member Title")
	}) {
		t.Fatalf("offer-onboarded member's publish did not propagate\nserve:\n%s", serveLog.String())
	}
	t.Log("OK: offer leg — claim-once URL minted mid-serve, single-use claim, B4 passphrase-free join + publish, book live")
}

var reInvite = regexp.MustCompile(`accorder-fedlib-invite:[A-Za-z0-9_\-+/=.]+`)

// waitFor polls cond until true or the deadline; returns whether it became true.
func waitFor(d time.Duration, cond func() bool) bool {
	for deadline := time.Now().Add(d); time.Now().Before(deadline); {
		if cond() {
			return true
		}
		time.Sleep(time.Second)
	}
	return cond()
}

// seedMemberLibrary builds a member's published library dir on disk exactly as a
// fixed `lib publish` would: static/library_index.zst (fresh random BaseGeneration
// each call), cover files, and a 24-byte _GENERATION sentinel from the manifest.
func seedMemberLibrary(t *testing.T, dir string, dictID uint32, books []*calibre.Book) {
	t.Helper()
	// lib upload fingerprints metadata.db by content. A real Calibre library
	// always has this file; keep the synthetic fixture faithful enough for the
	// publication integrity check without requiring Calibre in this E2E test.
	if err := os.WriteFile(filepath.Join(dir, "metadata.db"), []byte("e2e calibre metadata fixture\n"), 0o644); err != nil {
		t.Fatal(err)
	}
	buildFixtureIndex(t, dir, books, dictID)
	for _, b := range books {
		if b.CoverUrl == "" {
			continue
		}
		p := filepath.Join(dir, filepath.FromSlash(b.CoverUrl))
		if err := os.MkdirAll(filepath.Dir(p), 0o755); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(p, []byte{0xFF, 0xD8, 0xFF, 0xD9}, 0o644); err != nil {
			t.Fatal(err)
		}
	}
	mf, err := calibre.ReadExistingManifest(filepath.Join(dir, "static", "library_index"))
	if err != nil {
		t.Fatalf("read member manifest: %v", err)
	}
	if len(books) == 0 {
		t.Fatal("seed member library requires at least one book")
	}
	lib := calibre.PointerFileLibrary{
		UUID:      books[0].LibraryUUID,
		Librarian: books[0].Librarian,
	}
	if err := calibre.WritePointerFile(filepath.Join(dir, "static", "library_index"), mf, lib, false); err != nil {
		t.Fatalf("write member pointer: %v", err)
	}
	gen := torshare.EncodeGeneration(mf.BaseGeneration, mf.Generation)
	if err := os.WriteFile(filepath.Join(dir, "_GENERATION"), gen, 0o644); err != nil {
		t.Fatalf("write member _GENERATION: %v", err)
	}
}

func readMembers(t *testing.T, path string) map[string]calibre.LibraryMeta {
	t.Helper()
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("read members.json: %v", err)
	}
	var reg map[string]calibre.LibraryMeta
	if err := json.Unmarshal(data, &reg); err != nil {
		t.Fatalf("parse members.json: %v", err)
	}
	return reg
}

func assertMemberState(t *testing.T, path, key, wantState string) {
	t.Helper()
	reg := readMembers(t, path)
	meta, ok := reg[key]
	if !ok {
		t.Fatalf("members.json missing key %q; have: %v", key, reg)
	}
	if meta.State != wantState {
		t.Fatalf("members.json[%q].State = %q, want %q", key, meta.State, wantState)
	}
}

func mustRead(path string) string {
	b, _ := os.ReadFile(path)
	return string(b)
}

// httpGetBody GETs url and returns the response body as a string ("" on non-200).
func httpGetBody(t *testing.T, url string) string {
	t.Helper()
	resp, err := http.Get(url)
	if err != nil {
		return ""
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return ""
	}
	var sb strings.Builder
	buf := make([]byte, 32*1024)
	for {
		n, err := resp.Body.Read(buf)
		sb.Write(buf[:n])
		if err != nil {
			break
		}
	}
	return sb.String()
}
