//go:build gce_e2e || (integration && calibre_e2e)

package browselocal

import (
	"accorder/pkg/calibre"
	"accorder/pkg/rclonexfer"
	"context"
	"fmt"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/launcher"
	"github.com/go-rod/rod/lib/proto"
	"github.com/ysmood/gson"
)

// Shared headless-browse render harness, used by both the local clearnet render
// test (integration && calibre_e2e) and the GCE in-wild render leg (gce_e2e). It
// drives the real lib-browse CLIENT path: sync the served catalog over HTTP, build
// a session, then queue → download → import a downloadable book into a fresh
// Calibre library — all against whatever clearnet serve `base` points at (a local
// `lib share live` or the live federated operator).

// newClearnetRenderSession syncs a clearnet-served catalog over HTTP and builds a
// real browse session over it, with an HTTP file-download remote pointing at the
// same serve (so /files/<prefix>/ downloads — including peer-proxied ones — flow
// through the real client path, exactly as `lib browse` configures it).
func newClearnetRenderSession(t *testing.T, base string) *librarySession {
	t.Helper()
	cacheDir := t.TempDir()
	staticDir := filepath.Join(cacheDir, "static")
	if err := os.MkdirAll(staticDir, 0755); err != nil {
		t.Fatal(err)
	}
	rclonexfer.Initialize()
	t.Cleanup(rclonexfer.Finalize)

	if err := rclonexfer.ConfigHTTPRemote("librarian-cat", base); err != nil {
		t.Fatalf("ConfigHTTPRemote (catalog): %v", err)
	}
	if err := rclonexfer.ConfigHTTPRemote("librarian", base); err != nil {
		t.Fatalf("ConfigHTTPRemote (files): %v", err)
	}
	if err := rclonexfer.CopyFile("librarian-cat:", "static/library_index.zst", staticDir, "library_index.zst"); err != nil {
		t.Fatalf("sync library_index.zst: %v", err)
	}
	_ = rclonexfer.CopyFile("librarian-cat:", "static/data1.js", staticDir, "data1.js")
	if err := calibre.CopyBrowseUIAssets(cacheDir); err != nil {
		t.Fatalf("CopyBrowseUIAssets: %v", err)
	}
	for i := 2; i <= 8; i++ {
		_ = os.WriteFile(filepath.Join(staticDir, fmt.Sprintf("data%d.js", i)),
			[]byte(fmt.Sprintf("CALIBRE_BOOKS%d={books:[]}", i)), 0644)
	}

	indexPath := filepath.Join(staticDir, "library_index")
	opened, err := (&calibre.MotwSearch{IndexPath: indexPath}).Open()
	if err != nil {
		t.Fatalf("open synced index: %v", err)
	}
	t.Cleanup(func() { opened.Close() })
	if mf := opened.Manifest(); mf.NumBooks == 0 {
		t.Fatal("synced catalog index reports 0 books")
	}

	return &librarySession{
		opened:   opened,
		cacheDir: cacheDir,
		opts: Options{
			DownloadDir: t.TempDir(),
			// Clearnet HTTP download path: files are fetched from BaseURL + the
			// book's relative dir over HTTP (the operator serves /files/, proxying
			// peer members), not via an rclone remote.
			HTTPClient:        &http.Client{Timeout: 60 * time.Second},
			BaseURL:           base,
			RemoteFilesPrefix: "files", // fallback when a book carries no /files/<prefix>
		},
		selection:      make(map[string]bool),
		selectionBooks: make(map[string]*calibre.Book),
		downloadCh:     make(chan *queueItem, 256),
		stagedPages:    make(map[proto.TargetTargetID]bool),
		libraryPath:    t.TempDir(),
		librarianName:  "clearnetrender",
	}
}

// firstDownloadableTitle returns the title of the first book on the first browse
// page that carries a real format with a directory path. Real libraries (and the
// GCE metadata-only seeds) contain entries with no downloadable format; the render
// chain must queue one that actually has files to fetch.
func firstDownloadableTitle(t *testing.T, s *librarySession) string {
	t.Helper()
	books, _, err := s.opened.PageBooks(context.Background(), 0, 48)
	if err != nil {
		t.Fatalf("PageBooks: %v", err)
	}
	for _, b := range books {
		if len(b.Formats) > 0 && b.Formats[0].DirectoryPath != "" {
			return b.Title
		}
	}
	t.Skip("no book with a downloadable format on the first browse page")
	return ""
}

// browseRenderAndImport drives the headless browse client end to end: render →
// queue the given title → download over HTTP /files/ → import + build into the
// session's fresh Calibre library, asserting the result with calibredb.
func browseRenderAndImport(t *testing.T, session *librarySession, queueTitle string) {
	t.Helper()
	l := launcher.New().Headless(true)
	u, err := l.Launch()
	if err != nil {
		t.Skipf("rod launcher unavailable (%v); skipping render", err)
	}
	defer l.Cleanup()
	browser := rod.New().ControlURL(u)
	if err := browser.Connect(); err != nil {
		t.Fatalf("rod.Connect: %v", err)
	}
	defer browser.Close()
	session.browser = browser
	page := browser.MustPage("about:blank")
	defer page.Close()
	page.MustExpose("backend_rpc", func(arg gson.JSON) (interface{}, error) {
		return session.handleRPC(arg.Str())
	})

	fileURL := "file://" + filepath.Join(session.cacheDir, "BROWSE_LIBRARY.html") + "#/?t=l"
	if err := page.Navigate(fileURL); err != nil {
		t.Fatalf("navigate: %v", err)
	}
	dump := func() { t.Logf("page body:\n%s", page.MustEval(`() => document.body.innerText`).Str()) }
	clickTab := func(label string) {
		ok := page.MustEval(`(label) => {
			const b = [...document.querySelectorAll('nav button')].find(b => b.textContent.includes('[' + label + ']'));
			if (!b) return false; b.click(); return true;
		}`, label).Bool()
		if !ok {
			dump()
			t.Fatalf("tab %q not found", label)
		}
	}
	clickByText := func(txt string) {
		ok := page.MustEval(`(txt) => {
			const els = [...document.querySelectorAll('div,span,a,button')];
			let h = els.find(e => e.children.length === 0 && e.textContent.trim() === txt) || els.find(e => e.textContent.includes(txt));
			if (!h) return false; h.click(); return true;
		}`, txt).Bool()
		if !ok {
			dump()
			t.Fatalf("text %q not clickable", txt)
		}
	}

	// browse renders + queue the specific downloadable book (find its row by title).
	page.Timeout(20 * time.Second).MustWait(`() => document.querySelectorAll('table tbody tr').length >= 1`)
	queued := page.Timeout(15*time.Second).MustEval(`(title) => {
		const tr = [...document.querySelectorAll('table tbody tr')].find(r => r.textContent.includes(title));
		if (!tr) return false;
		const q = [...tr.querySelectorAll('span')].find(e => e.textContent.trim() === '[ADD TO QUEUE]');
		if (!q) return false;
		q.click();
		return true;
	}`, queueTitle).Bool()
	if !queued {
		dump()
		t.Fatalf("could not queue book %q (row or [ADD TO QUEUE] not found)", queueTitle)
	}
	page.Timeout(10 * time.Second).MustWait(`() => {
		const b = [...document.querySelectorAll('nav button')].find(x => x.textContent.includes('[QUEUE]'));
		return b && b.textContent.includes('(1)');
	}`)
	t.Logf("OK: clearnet browse rendered + queued %q", queueTitle)

	// download the queued book over HTTP /files/.
	clickTab("QUEUE")
	page.Timeout(10 * time.Second).MustWait(`() => document.body.innerText.includes('[DOWNLOAD ALL]')`)
	clickByText("[DOWNLOAD ALL]")
	page.Timeout(60 * time.Second).MustWait(`() => document.querySelector('tr.row-done') !== null`)
	t.Log("OK: clearnet HTTP download completed (real file fetch through the serve)")

	// import + build into a fresh Calibre library.
	clickTab("MY LIBRARY")
	page.Timeout(90 * time.Second).MustWait(`() => {
		const f = document.querySelector('iframe');
		return f && (f.getAttribute('src') || '').includes('BROWSE_LIBRARY.html');
	}`)
	libDir := session.libraryPath
	for _, rel := range []string{"BROWSE_LIBRARY.html", "static", "metadata.db"} {
		if _, err := os.Stat(filepath.Join(libDir, rel)); err != nil {
			t.Errorf("rendered library missing %s: %v", rel, err)
		}
	}
	out, err := exec.Command("calibredb", "list", "--with-library="+libDir, "--for-machine", "-f", "title").Output()
	if err != nil {
		t.Fatalf("calibredb list rendered library: %v", err)
	}
	if !strings.Contains(string(out), `"title"`) {
		t.Fatalf("rendered Calibre library has no books:\n%s", out)
	}
	t.Log("OK: reader→librarian render — clearnet catalog browsed, downloaded, and imported into a fresh Calibre library")
}
