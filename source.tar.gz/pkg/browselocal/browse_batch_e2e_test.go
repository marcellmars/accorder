//go:build integration

package browselocal

import (
	"encoding/json"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/launcher"
	"github.com/ysmood/gson"
)

// batchResponder is a stateful backend_rpc stub for the SELECT/QUEUE/MY LIBRARY
// state-machine E2E test. It mirrors the real librarySession return shapes and
// models a selection set + an ordered queue with per-row download state, so the
// test can drive the whole pipeline against the real embedded svelte bundle.
//
// The 4-step TabHeader pipeline is: 0 SETTINGS · 1 SELECT · 2 QUEUE · 3 MY LIBRARY
// All flow steps are gated until `configured` (library_path && librarian).
type qrow struct {
	id     string
	status string // queued, downloading, done
	tick   int
}

type batchResponder struct {
	mu              sync.Mutex
	calls           []rpcCall
	sel             map[string]bool
	queue           []qrow
	buildTriggered  bool
	pollsAfterBuild int
	libraryHTMLPath string
}

func newBatchResponder() *batchResponder { return &batchResponder{sel: map[string]bool{}} }

func (r *batchResponder) seen(method string) int {
	r.mu.Lock()
	defer r.mu.Unlock()
	n := 0
	for _, c := range r.calls {
		if c.Method == method {
			n++
		}
	}
	return n
}

func (r *batchResponder) dump(t *testing.T) {
	t.Helper()
	r.mu.Lock()
	defer r.mu.Unlock()
	var lines []string
	for _, c := range r.calls {
		args, _ := json.Marshal(c.Args)
		lines = append(lines, "  "+c.Service+"/"+c.Method+" "+string(args))
	}
	t.Logf("backend_rpc calls (%d):\n%s", len(r.calls), strings.Join(lines, "\n"))
}

func (r *batchResponder) selIDsLocked() []string {
	ids := make([]string, 0, len(r.sel))
	for id := range r.sel {
		ids = append(ids, id)
	}
	return ids
}

// queueItemsLocked renders the queue as the {items:[...]} shape handleBatchStatus
// returns, advancing each downloading row toward done across polls.
func (r *batchResponder) queueItemsLocked(advance bool) []map[string]any {
	items := []map[string]any{}
	for i := range r.queue {
		row := &r.queue[i]
		if advance && row.status == "downloading" {
			row.tick++
			if row.tick >= 2 {
				row.status = "done"
			}
		}
		progress := 0
		switch row.status {
		case "downloading":
			progress = 50
		case "done":
			progress = 100
		}
		items = append(items, map[string]any{
			"_id": row.id, "book_id": row.id, "title": "Book " + row.id,
			"authors": []string{"Auth"}, "formats": []map[string]any{},
			"status": row.status, "progress": progress,
		})
	}
	return items
}

func (r *batchResponder) handle(arg gson.JSON) (interface{}, error) {
	var c rpcCall
	if err := json.Unmarshal([]byte(arg.Str()), &c); err != nil {
		return nil, err
	}
	r.mu.Lock()
	r.calls = append(r.calls, c)
	r.mu.Unlock()

	switch c.Service + "/" + c.Method {
	case "session/mode":
		return "browse", nil
	case "session/reachability":
		return map[string]string{"status": "connected"}, nil
	case "library/autocomplete":
		return map[string]any{"_items": []string{}}, nil
	case "library/search":
		return map[string]any{"_items": []any{}}, nil
	case "library/settings/get":
		return map[string]any{"library_path": "/tmp/lib", "librarian": "test"}, nil
	case "library/settings/set":
		return map[string]any{"saved": true}, nil

	case "library/selection/toggle":
		id, _ := c.Args["book_id"].(string)
		r.mu.Lock()
		defer r.mu.Unlock()
		if r.sel[id] {
			delete(r.sel, id)
		} else {
			r.sel[id] = true
		}
		return map[string]any{"selected": r.sel[id], "count": len(r.sel), "selected_ids": r.selIDsLocked()}, nil

	case "library/selection/selectAll":
		r.mu.Lock()
		defer r.mu.Unlock()
		for _, id := range []string{"front-1", "front-2", "front-3"} {
			r.sel[id] = true
		}
		return map[string]any{"count": len(r.sel), "toggled_on": true, "selected_ids": r.selIDsLocked()}, nil

	case "library/selection/clear":
		r.mu.Lock()
		defer r.mu.Unlock()
		r.sel = map[string]bool{}
		return map[string]any{"cleared": true}, nil

	case "library/selection/count":
		r.mu.Lock()
		defer r.mu.Unlock()
		return map[string]any{"count": len(r.sel)}, nil

	// Click [QUEUE]: commit the staged selection into the queue (additive,
	// dedup) and clear the selection fully.
	case "library/selection/enqueue":
		r.mu.Lock()
		defer r.mu.Unlock()
		have := map[string]bool{}
		for _, q := range r.queue {
			have[q.id] = true
		}
		for _, id := range r.selIDsLocked() {
			if !have[id] {
				r.queue = append(r.queue, qrow{id: id, status: "queued"})
			}
		}
		r.sel = map[string]bool{}
		return map[string]any{"count": len(r.queue), "items": r.queueItemsLocked(false), "selected_ids": []string{}}, nil

	// [DOWNLOAD ALL]: start every queued row.
	case "library/fetchBatch":
		r.mu.Lock()
		defer r.mu.Unlock()
		for i := range r.queue {
			if r.queue[i].status == "queued" {
				r.queue[i].status = "downloading"
			}
		}
		return map[string]any{"started": true}, nil

	// per-row [download]
	case "library/download/item":
		id, _ := c.Args["book_id"].(string)
		r.mu.Lock()
		defer r.mu.Unlock()
		for i := range r.queue {
			if r.queue[i].id == id && r.queue[i].status == "queued" {
				r.queue[i].status = "downloading"
			}
		}
		return map[string]any{"started": true, "book_id": id}, nil

	// per-row [X]
	case "library/queue/remove":
		id, _ := c.Args["book_id"].(string)
		r.mu.Lock()
		defer r.mu.Unlock()
		kept := r.queue[:0]
		for _, q := range r.queue {
			if q.id != id {
				kept = append(kept, q)
			}
		}
		r.queue = kept
		return map[string]any{"removed": true, "queue_size": len(r.queue)}, nil

	// header [X]: clear everything not downloading
	case "library/queue/clearNotDownloading":
		r.mu.Lock()
		defer r.mu.Unlock()
		kept := r.queue[:0]
		cleared := 0
		for _, q := range r.queue {
			if q.status == "downloading" {
				kept = append(kept, q)
			} else {
				cleared++
			}
		}
		r.queue = kept
		return map[string]any{"cleared": cleared, "queue_size": len(r.queue)}, nil

	case "library/batchStatus":
		r.mu.Lock()
		defer r.mu.Unlock()
		items := r.queueItemsLocked(true)
		done := 0
		for _, q := range r.queue {
			if q.status == "done" {
				done++
			}
		}
		return map[string]any{"items": items, "downloading": 0, "done": done, "failed": 0, "total": len(items), "build_status": ""}, nil

	// MY LIBRARY: import the done rows but LEAVE the queue intact (done rows
	// stay, in-flight downloads keep going). Re-import is idempotent.
	case "library/openMyLibrary", "library/build":
		r.mu.Lock()
		r.buildTriggered = true
		r.mu.Unlock()
		return map[string]any{"building": true}, nil

	case "library/buildStatus":
		r.mu.Lock()
		defer r.mu.Unlock()
		st, htmlPath := "", ""
		if r.buildTriggered {
			r.pollsAfterBuild++
			if r.pollsAfterBuild <= 1 {
				st = "building"
			} else {
				st, htmlPath = "built", r.libraryHTMLPath
			}
		}
		return map[string]any{"build_status": st, "build_error": "", "library_html_path": htmlPath}, nil

	case "library/openBuilt":
		return map[string]any{"opened": true}, nil
	}
	return map[string]any{"_items": []any{}}, nil
}

// TestBrowse_E2E_BatchFlow drives the full SELECT -> QUEUE -> MY LIBRARY state
// machine against the real embedded svelte bundle (backend_rpc stubbed). It
// exercises: per-row [ADD TO QUEUE]/[ADDED] toggle, [ADD ALL]/[CLEAR ALL], the
// QUEUE-tab commit (enqueue + clear SELECT), free back-and-forth navigation, the
// QUEUE per-row [download]/[X] and header [DOWNLOAD ALL]/[X], and MY LIBRARY
// importing only done books.
func TestBrowse_E2E_BatchFlow(t *testing.T) {
	dir := writeFixture(t)

	l := launcher.New().Headless(true)
	u, err := l.Launch()
	if err != nil {
		t.Fatalf("launcher: %v", err)
	}
	defer l.Cleanup()
	browser := rod.New().ControlURL(u)
	if err := browser.Connect(); err != nil {
		t.Fatalf("rod.Connect: %v", err)
	}
	defer browser.Close()
	page := browser.MustPage("about:blank")
	defer page.Close()

	resp := newBatchResponder()
	resp.libraryHTMLPath = filepath.Join(dir, "BROWSE_LIBRARY.html")
	page.MustExpose("backend_rpc", resp.handle)
	watchConsole(t, page)

	fileURL := "file://" + filepath.Join(dir, "BROWSE_LIBRARY.html") + "#/?t=l"
	if err := page.Navigate(fileURL); err != nil {
		t.Fatalf("navigate: %v", err)
	}

	clickByText := func(txt string) {
		t.Helper()
		ok := page.MustEval(`(txt) => {
			const els = [...document.querySelectorAll('div,span,a,button')];
			let hit = els.find(e => e.children.length === 0 && e.textContent.trim() === txt);
			if (!hit) hit = els.find(e => e.textContent.includes(txt));
			if (!hit) return false;
			hit.click();
			return true;
		}`, txt).Bool()
		if !ok {
			resp.dump(t)
			t.Fatalf("could not find clickable element with text %q", txt)
		}
	}
	// clickNthRowAction clicks the n-th (0-based) occurrence of an exact button
	// text inside the table body (e.g. the first row's "[ADD TO QUEUE]").
	clickNthRowAction := func(txt string, n int) {
		t.Helper()
		ok := page.MustEval(`(txt, n) => {
			const els = [...document.querySelectorAll('table tbody span')].filter(e => e.textContent.trim() === txt);
			if (els.length <= n) return false;
			els[n].click();
			return true;
		}`, txt, n).Bool()
		if !ok {
			resp.dump(t)
			t.Fatalf("could not click occurrence %d of row action %q", n, txt)
		}
	}
	clickTab := func(label string) {
		t.Helper()
		ok := page.MustEval(`(label) => {
			const b = [...document.querySelectorAll('nav button')].find(x => x.textContent.includes('[' + label + ']'));
			if (!b) return false;
			b.click();
			return true;
		}`, label).Bool()
		if !ok {
			resp.dump(t)
			t.Fatalf("could not find TabHeader button %q", label)
		}
	}
	countText := func(txt string) int {
		return page.MustEval(`(txt) => [...document.querySelectorAll('table tbody span')].filter(e => e.textContent.trim() === txt).length`, txt).Int()
	}
	bodyHas := func(s string) bool {
		return page.MustEval(`(s) => document.body.innerText.includes(s)`, s).Bool()
	}
	queueBadge := func(want string) bool {
		return page.MustEval(`(w) => {
			const b = [...document.querySelectorAll('nav button')].find(x => x.textContent.includes('[QUEUE]'));
			return b && b.textContent.includes(w);
		}`, want).Bool()
	}
	waitSeen := func(method string, d time.Duration) {
		t.Helper()
		deadline := time.Now().Add(d)
		for time.Now().Before(deadline) {
			if resp.seen(method) > 0 {
				return
			}
			time.Sleep(50 * time.Millisecond)
		}
		resp.dump(t)
		t.Fatalf("no library/%s RPC within %s", method, d)
	}

	// --- Gate open + tabs ---
	page.Timeout(15 * time.Second).MustWait(`() => document.querySelectorAll('table tbody tr').length >= 3`)
	if !page.MustEval(`() => {
		const t = document.body.innerText;
		return t.includes('[SETTINGS]') && t.includes('[SELECT]') && t.includes('[QUEUE]') && t.includes('[MY LIBRARY]');
	}`).Bool() {
		resp.dump(t)
		t.Fatal("FAIL: TabHeader pipeline (SETTINGS/SELECT/QUEUE/MY LIBRARY) not rendered")
	}
	t.Log("OK: gate open, 4-step pipeline (SETTINGS/SELECT/QUEUE/MY LIBRARY) rendered")

	// --- SELECT: [ADD ALL] header + per-row [ADD TO QUEUE], no checkboxes ---
	if !bodyHas("[ADD ALL]") || countText("[ADD TO QUEUE]") < 3 {
		resp.dump(t)
		t.Fatalf("FAIL: SELECT should show [ADD ALL] + 3x [ADD TO QUEUE]; got addAll=%v rows=%d", bodyHas("[ADD ALL]"), countText("[ADD TO QUEUE]"))
	}
	if page.MustEval(`() => document.querySelectorAll('table tbody input[type=checkbox]').length`).Int() != 0 {
		t.Fatal("FAIL: SELECT must have no checkboxes (replaced by [ADD TO QUEUE])")
	}
	t.Logf("OK: SELECT shows [ADD ALL] + %d [ADD TO QUEUE], no checkboxes", countText("[ADD TO QUEUE]"))

	// --- per-row [ADD TO QUEUE] -> [ADDED] toggle, QUEUE badge tracks it ---
	clickNthRowAction("[ADD TO QUEUE]", 0)
	waitSeen("selection/toggle", 5*time.Second)
	page.Timeout(5 * time.Second).MustWait(`() => [...document.querySelectorAll('table tbody span')].some(e => e.textContent.trim() === '[ADDED]')`)
	if !queueBadge("(1)") {
		t.Fatal("FAIL: QUEUE badge should be (1) after one [ADD TO QUEUE]")
	}
	t.Log("OK: [ADD TO QUEUE] -> [ADDED], QUEUE badge (1)")

	// toggle the same row back off
	clickNthRowAction("[ADDED]", 0)
	page.Timeout(5 * time.Second).MustWait(`() => ![...document.querySelectorAll('table tbody span')].some(e => e.textContent.trim() === '[ADDED]')`)
	t.Log("OK: [ADDED] toggles back to [ADD TO QUEUE] (badge cleared)")

	// --- [ADD ALL] -> [CLEAR ALL], all rows [ADDED] ---
	clickByText("[ADD ALL]")
	waitSeen("selection/selectAll", 5*time.Second)
	page.Timeout(5 * time.Second).MustWait(`() => document.body.innerText.includes('[CLEAR ALL]')`)
	if countText("[ADDED]") < 3 {
		t.Fatalf("FAIL: after [ADD ALL] expected 3x [ADDED], got %d", countText("[ADDED]"))
	}
	if !queueBadge("(3)") {
		t.Fatal("FAIL: QUEUE badge should be (3) after [ADD ALL]")
	}
	t.Logf("OK: [ADD ALL] -> [CLEAR ALL] header + %d [ADDED], badge (3)", countText("[ADDED]"))

	// --- click [QUEUE]: commit selection -> queue, clear SELECT ---
	clickTab("QUEUE")
	waitSeen("selection/enqueue", 5*time.Second)
	page.Timeout(5 * time.Second).MustWait(`() => document.body.innerText.includes('[DOWNLOAD ALL]')`)
	if !bodyHas("[DOWNLOAD ALL]") {
		t.Fatal("FAIL: QUEUE header should show [DOWNLOAD ALL]")
	}
	dlRows := countText("[download]")
	if dlRows != 3 {
		t.Fatalf("FAIL: QUEUE should show 3 rows with [download], got %d", dlRows)
	}
	t.Logf("OK: [QUEUE] committed selection -> %d queued rows, header [DOWNLOAD ALL] [X]", dlRows)

	// --- navigation: back to SELECT shows a cleared selection ---
	clickTab("SELECT")
	page.Timeout(5 * time.Second).MustWait(`() => document.body.innerText.includes('[ADD ALL]')`)
	if countText("[ADDED]") != 0 {
		t.Fatalf("FAIL: SELECT should be cleared after QUEUE commit; found %d [ADDED]", countText("[ADDED]"))
	}
	t.Log("OK: nav back to SELECT — selection cleared ([ADD ALL], no [ADDED])")

	// --- nav to QUEUE again: queue persists ---
	clickTab("QUEUE")
	page.Timeout(5 * time.Second).MustWait(`() => [...document.querySelectorAll('table tbody span')].filter(e => e.textContent.trim() === '[download]').length === 3`)
	t.Log("OK: nav back to QUEUE — 3 queued rows persisted")

	// --- per-row [X] removes one book ---
	clickNthRowAction("[X]", 1) // skip the header [X] (index 0); first ROW [X]
	waitSeen("queue/remove", 5*time.Second)
	page.Timeout(5 * time.Second).MustWait(`() => [...document.querySelectorAll('table tbody span')].filter(e => e.textContent.trim() === '[download]').length === 2`)
	t.Log("OK: per-row [X] -> queue/remove, 2 rows remain")

	// --- [DOWNLOAD ALL] -> downloading (50%) -> done ---
	clickByText("[DOWNLOAD ALL]")
	waitSeen("fetchBatch", 5*time.Second)
	page.Timeout(10 * time.Second).MustWait(`() => document.body.innerText.includes('50%')`)
	t.Log("OK: [DOWNLOAD ALL] -> fetchBatch, rows show 50%")
	page.Timeout(10 * time.Second).MustWait(`() => document.querySelector('tr.row-done') !== null`)
	t.Log("OK: downloads complete — rows marked done")

	// --- MY LIBRARY: imports done books but LEAVES the queue intact ---
	clickTab("MY LIBRARY")
	waitSeen("openMyLibrary", 5*time.Second)
	page.Timeout(15 * time.Second).MustWait(`() => {
		const f = document.querySelector('iframe');
		return f && f.getAttribute('src') && f.getAttribute('src').includes('BROWSE_LIBRARY.html');
	}`)
	src := page.MustEval(`() => document.querySelector('iframe').getAttribute('src')`).Str()
	if !strings.HasPrefix(src, "file://") || !strings.Contains(src, "BROWSE_LIBRARY.html") {
		t.Fatalf("FAIL: MY LIBRARY iframe src not the built library: %q", src)
	}
	resp.mu.Lock()
	remaining := len(resp.queue)
	resp.mu.Unlock()
	if remaining != 2 {
		t.Fatalf("FAIL: MY LIBRARY must NOT prune the queue; want 2 rows kept, got %d", remaining)
	}
	t.Logf("OK: MY LIBRARY imported done books + rendered iframe; queue left intact (%d rows)", remaining)

	// --- regression: switching MY LIBRARY -> QUEUE (empty selection) must NOT
	// get stuck or clear the queue; it re-opens the live queue with its rows. ---
	clickTab("QUEUE")
	page.Timeout(8 * time.Second).MustWait(`() => document.body.innerText.includes('[DOWNLOAD ALL]') && document.querySelectorAll('table tbody tr').length === 2`)
	rows := page.MustEval(`() => document.querySelectorAll('table tbody tr').length`).Int()
	if rows != 2 {
		t.Fatalf("FAIL: MY LIBRARY -> QUEUE should re-open the live queue (2 rows), got %d", rows)
	}
	t.Logf("OK: MY LIBRARY -> QUEUE re-opens the live queue (%d rows), not stuck/cleared", rows)
}
