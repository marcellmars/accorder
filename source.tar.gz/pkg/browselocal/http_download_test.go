package browselocal

import (
	"fmt"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"path/filepath"
	"sync/atomic"
	"testing"
)

func TestHttpDownloadFile(t *testing.T) {
	content := "hello world test content"
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte(content))
	}))
	defer srv.Close()

	dir := t.TempDir()
	dst := filepath.Join(dir, "out.bin")

	n, err := httpDownloadFile(srv.Client(), srv.URL+"/file.bin", dst)
	if err != nil {
		t.Fatalf("httpDownloadFile: %v", err)
	}
	if n != int64(len(content)) {
		t.Errorf("byte count: got %d, want %d", n, len(content))
	}

	got, err := os.ReadFile(dst)
	if err != nil {
		t.Fatalf("read result: %v", err)
	}
	if string(got) != content {
		t.Errorf("content mismatch: got %q, want %q", got, content)
	}
}

func TestHttpDownloadFileAtomicOnError(t *testing.T) {

	// Server that sends partial data then closes.
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Length", "1000")
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("partial"))

		// Connection closes here without sending all data.
	}))
	defer srv.Close()

	dir := t.TempDir()
	dst := filepath.Join(dir, "out.bin")

	_, err := httpDownloadFile(srv.Client(), srv.URL+"/file.bin", dst)
	if err == nil {
		t.Fatal("expected error for partial response, got nil")
	}

	// The destination file should NOT exist (atomic write — temp file cleaned up).
	if _, serr := os.Stat(dst); !os.IsNotExist(serr) {
		t.Errorf("partial file should not exist at %s after error", dst)
	}
}

func TestHttpDownloadFile404(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		http.NotFound(w, r)
	}))
	defer srv.Close()

	dir := t.TempDir()
	dst := filepath.Join(dir, "out.bin")

	_, err := httpDownloadFile(srv.Client(), srv.URL+"/missing", dst)
	if err == nil {
		t.Fatal("expected error for 404, got nil")
	}
}

func TestHttpDownloadFileRetryNoRetryOn404(t *testing.T) {

	// A permanent 404 must not be retried — otherwise a book missing a format
	// (or cover/metadata) burns ~70s of backoff per file.
	var calls atomic.Int32
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls.Add(1)
		http.NotFound(w, r)
	}))
	defer srv.Close()

	dir := t.TempDir()
	dst := filepath.Join(dir, "out.bin")

	if _, err := httpDownloadFileRetry(srv.Client(), srv.URL+"/missing", dst); err == nil {
		t.Fatal("expected error for 404, got nil")
	}
	if c := calls.Load(); c != 1 {
		t.Errorf("404 must not be retried: expected 1 attempt, got %d", c)
	}
}

func TestHttpDownloadFileRetry(t *testing.T) {
	var calls atomic.Int32
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		n := calls.Add(1)
		if n < 3 {

			// First two attempts fail.
			http.Error(w, "server error", http.StatusInternalServerError)
			return
		}
		w.Write([]byte("success"))
	}))
	defer srv.Close()

	dir := t.TempDir()
	dst := filepath.Join(dir, "out.bin")

	if _, err := httpDownloadFileRetry(srv.Client(), srv.URL+"/file.bin", dst); err != nil {
		t.Fatalf("httpDownloadFileRetry: %v", err)
	}

	got, err := os.ReadFile(dst)
	if err != nil {
		t.Fatalf("read result: %v", err)
	}
	if string(got) != "success" {
		t.Errorf("content mismatch: got %q, want %q", got, "success")
	}
	if c := calls.Load(); c != 3 {
		t.Errorf("expected 3 attempts, got %d", c)
	}
}

func TestHttpDownloadFileURLEscaping(t *testing.T) {

	// Verify that URL-encoded paths (spaces, #) reach the server correctly.
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("path=" + r.URL.Path))
	}))
	defer srv.Close()

	tests := []struct {
		name     string
		relDir   string
		file     string
		wantPath string
	}{
		{"spaces", "Author Name/Book Title (123)", "file.epub", "/files/Author Name/Book Title (123)/file.epub"},
		{"hash", "Author #1/My Book", "doc.pdf", "/files/Author #1/My Book/doc.pdf"},
		{"question", "Author/What?", "a.txt", "/files/Author/What?/a.txt"},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			dir := t.TempDir()
			dst := filepath.Join(dir, tt.file)

			baseURL := srv.URL + "/"
			fileURL, err := joinURL(baseURL, "files/"+tt.relDir, tt.file)
			if err != nil {
				t.Fatalf("joinURL: %v", err)
			}

			if _, err := httpDownloadFile(srv.Client(), fileURL, dst); err != nil {
				t.Fatalf("httpDownloadFile: %v", err)
			}

			got, err := os.ReadFile(dst)
			if err != nil {
				t.Fatalf("read: %v", err)
			}
			want := fmt.Sprintf("path=%s", tt.wantPath)
			if string(got) != want {
				t.Errorf("got %q, want %q", got, want)
			}
		})
	}
}

// joinURL is a test helper mirroring the url.JoinPath call in downloadRemoteFiles.
func joinURL(base, dir, file string) (string, error) {
	return url.JoinPath(base, dir, file)
}
