//go:build integration

package browselocal

import (
	"encoding/json"
	"fmt"
	"net/url"
	"os"
	"reflect"
	"sort"
	"strings"
	"sync"
	"testing"

	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/launcher"
	"github.com/ysmood/gson"
)

// bridgeTestFixture inlines accorderBridge.js as a non-module <script>
// after stripping `export` keywords. ES modules from file:// hit browser
// security restrictions (relative imports blocked in newer Chromium), so
// we trade module isolation for test reliability.
//

// The canonical source lives at frontend/src/accorderBridge.js (in-tree).
const bridgeHarnessTemplate = `<!doctype html>
<title>bridge harness</title>
<script>
__BRIDGE_SOURCE__
window.bridge = {fetchVia: fetchVia, hasAccorderBackend: hasAccorderBackend};
window.bridgeReady = true;
</script>
`

// rpcCall captures one window.backend_rpc invocation.
type rpcCall struct {
	Service string         `json:"service"`
	Method  string         `json:"method"`
	Args    map[string]any `json:"args"`
}

// bridgeRecorder receives MustExpose callbacks and stores parsed payloads.
type bridgeRecorder struct {
	mu       sync.Mutex
	calls    []rpcCall
	response any // what to return to JS
}

func (r *bridgeRecorder) record(arg gson.JSON) (interface{}, error) {
	var call rpcCall
	if err := json.Unmarshal([]byte(arg.Str()), &call); err != nil {
		return nil, err
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	r.calls = append(r.calls, call)
	resp := r.response
	if resp == nil {
		resp = map[string]any{"_items": []any{}, "_meta": map[string]any{"total": 0}, "_links": map[string]any{}}
	}

	// Return as JSON string — fetchVia's backendCall handles both string and object.
	b, _ := json.Marshal(resp)
	return string(b), nil
}

func (r *bridgeRecorder) lastCall(t *testing.T) rpcCall {
	t.Helper()
	r.mu.Lock()
	defer r.mu.Unlock()
	if len(r.calls) == 0 {
		t.Fatalf("bridge recorder captured zero backend_rpc calls")
	}
	return r.calls[len(r.calls)-1]
}

// setupBridgePage launches headless Chromium, loads the bridge inline via
// a data: URL (matches the working TestRodMustExposeRoundTrip pattern —
// avoids navigation-context-loss issues with MustExpose + Navigate). After
// the page is loaded, exposes window.backend_rpc → recorder, then primes
// the bridge with one no-op call that resolves immediately so that the
// production callbacks have a known initial state.
func setupBridgePage(t *testing.T) (*rod.Page, *bridgeRecorder, func()) {
	t.Helper()
	src, err := os.ReadFile("../../frontend/src/accorderBridge.js")
	if err != nil {
		t.Fatalf("read testdata bridge: %v", err)
	}

	// Strip every leading `export ` (including `export async function`,
	// `export const`, `export default`) — the inlined script is not a module.
	stripped := strings.ReplaceAll(string(src), "export default ", "")
	stripped = strings.ReplaceAll(stripped, "export ", "")
	html := strings.Replace(bridgeHarnessTemplate, "__BRIDGE_SOURCE__", stripped, 1)

	l := launcher.New().Headless(true)
	u, err := l.Launch()
	if err != nil {
		t.Fatalf("launcher: %v", err)
	}
	browser := rod.New().ControlURL(u)
	if err := browser.Connect(); err != nil {
		l.Cleanup()
		t.Fatalf("rod.Connect: %v", err)
	}

	dataURL := "data:text/html;charset=utf-8," + url.PathEscape(html)
	page := browser.MustPage(dataURL)
	rec := &bridgeRecorder{}
	page.MustExpose("backend_rpc", rec.record)
	watchConsole(t, page)

	// Sanity: the bridge globals are defined.
	if !page.MustEval("() => typeof window.bridge === 'object'").Bool() {
		browser.Close()
		l.Cleanup()
		t.Fatalf("bridge harness did not set window.bridge — check the inline script")
	}

	cleanup := func() {
		page.Close()
		browser.Close()
		l.Cleanup()
	}
	return page, rec, cleanup
}

func TestBridge_HasAccorderBackend(t *testing.T) {
	page, _, cleanup := setupBridgePage(t)
	defer cleanup()
	got := page.MustEval("() => window.bridge.hasAccorderBackend()").Bool()
	if !got {
		t.Fatalf("hasAccorderBackend() = false; MustExpose should have set window.backend_rpc")
	}
}

func TestBridge_URLRouting(t *testing.T) {
	cases := []struct {
		name    string
		url     string
		service string
		method  string
		args    map[string]any
	}{
		{
			name:    "autocomplete titles",
			url:     "https://books.memoryoftheworld.org/autocomplete/titles/his",
			service: "library",
			method:  "autocomplete",
			args:    map[string]any{"field": "title", "prefix": "his", "limit": float64(12)},
		},
		{
			name:    "autocomplete authors",
			url:     "https://books.memoryoftheworld.org/autocomplete/authors/foucault",
			service: "library",
			method:  "autocomplete",
			args:    map[string]any{"field": "author", "prefix": "foucault", "limit": float64(12)},
		},
		{
			name:    "autocomplete tags",
			url:     "https://books.memoryoftheworld.org/autocomplete/tags/anarch",
			service: "library",
			method:  "autocomplete",
			args:    map[string]any{"field": "tag", "prefix": "anarch", "limit": float64(12)},
		},
		{
			name:    "search title page 1",
			url:     "https://books.memoryoftheworld.org/search/titles/foucault",
			service: "library",
			method:  "search",
			args:    map[string]any{"field": "title", "query": "foucault", "offset": float64(0), "limit": float64(48)},
		},
		{
			name:    "search author page 3",
			url:     "https://books.memoryoftheworld.org/search/authors/marx/page/3",
			service: "library",
			method:  "search",
			args:    map[string]any{"field": "author", "query": "marx", "offset": float64(96), "limit": float64(48)},
		},
		{
			name:    "search with spaces encoded",
			url:     "https://books.memoryoftheworld.org/search/titles/" + url.PathEscape("simians cyborgs"),
			service: "library",
			method:  "search",
			args:    map[string]any{"field": "title", "query": "simians cyborgs", "offset": float64(0), "limit": float64(48)},
		},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			page, rec, cleanup := setupBridgePage(t)
			defer cleanup()
			page.MustEval(fmt.Sprintf("async () => { await window.bridge.fetchVia(%q); }", tc.url))
			got := rec.lastCall(t)
			if got.Service != tc.service {
				t.Errorf("service = %q, want %q", got.Service, tc.service)
			}
			if got.Method != tc.method {
				t.Errorf("method = %q, want %q", got.Method, tc.method)
			}
			if !reflect.DeepEqual(got.Args, tc.args) {
				want, _ := json.Marshal(tc.args)
				gotJSON, _ := json.Marshal(got.Args)
				t.Errorf("args mismatch\n got:  %s\n want: %s", gotJSON, want)
			}
		})
	}
}

func TestBridge_ResponseEnvelopeWrap(t *testing.T) {
	page, rec, cleanup := setupBridgePage(t)
	defer cleanup()

	// Backend returns the {_items, _meta, _links} envelope shape that
	// handleSearch produces in browselocal.go.
	rec.response = map[string]any{
		"_items": []map[string]any{{"_id": "x"}, {"_id": "y"}},
		"_meta":  map[string]any{"total": 2},
		"_links": map[string]any{},
	}
	out := page.MustEval(`async () => {
		const r = await window.bridge.fetchVia("/search/titles/anything");
		return JSON.stringify(r);
	}`).Str()
	var parsed map[string]any
	if err := json.Unmarshal([]byte(out), &parsed); err != nil {
		t.Fatalf("parse response: %v", err)
	}
	items, ok := parsed["_items"].([]any)
	if !ok || len(items) != 2 {
		t.Fatalf("_items wrong shape: %v", parsed["_items"])
	}
	_ = rec.lastCall(t) // sanity: call recorded
}

func TestBridge_BareArrayWrapping(t *testing.T) {
	page, rec, cleanup := setupBridgePage(t)
	defer cleanup()

	// Backend returns a bare array — fetchVia should wrap it.
	rec.response = []map[string]any{{"x": 1}, {"x": 2}, {"x": 3}}
	out := page.MustEval(`async () => {
		const r = await window.bridge.fetchVia("/search/tags/anything");
		return JSON.stringify(r);
	}`).Str()
	var parsed map[string]any
	if err := json.Unmarshal([]byte(out), &parsed); err != nil {
		t.Fatalf("parse response: %v", err)
	}
	items, ok := parsed["_items"].([]any)
	if !ok || len(items) != 3 {
		t.Fatalf("_items wrong shape: %v", parsed["_items"])
	}
	meta, ok := parsed["_meta"].(map[string]any)
	if !ok {
		t.Fatalf("_meta missing")
	}
	if total, ok := meta["total"].(float64); !ok || total != 3 {
		t.Errorf("_meta.total = %v, want 3", meta["total"])
	}
}

// TestBridge_RoutesFrontPageAndBook verifies that the bridge routes the
// front page, its pagination, and per-book detail to the backend
// (handleBooks / handleBook). In a live browse session mock=false, so
// fetchBooks("/books") flows through urlToBackendCall — these MUST route,
// otherwise the caller falls back to fetch("/books") which fails CORS on a
// file:// page and renders zero books. (Genuinely unrecognized URLs falling
// back to fetch is covered by TestBridge_UnrecognizedURLFallsBackToFetch.)
func TestBridge_RoutesFrontPageAndBook(t *testing.T) {
	page, rec, cleanup := setupBridgePage(t)
	defer cleanup()
	for _, url := range []string{
		"https://books.memoryoftheworld.org/books",
		"https://books.memoryoftheworld.org/books/page/1",
		"https://books.memoryoftheworld.org/books/page/3",
		"https://books.memoryoftheworld.org/book/some-id",
	} {

		// Call fetchVia and observe that exactly one backend_rpc fires.
		before := len(rec.calls)
		_, _ = page.Eval(fmt.Sprintf(`async () => {
			try { await window.bridge.fetchVia(%q); } catch (e) {}
		}`, url))
		if got := len(rec.calls) - before; got != 1 {
			t.Errorf("url %q triggered %d backend_rpc call(s); want 1 (bridge should route to backend)", url, got)
		}
	}
}

func TestBridge_UnrecognizedURLFallsBackToFetch(t *testing.T) {

	// fetchVia should fall back to native fetch() for URLs it doesn't
	// recognize. Native fetch against a file:// URL of a real file
	// in the same dir as the harness will succeed; we test that no
	// backend_rpc call was made.
	page, rec, cleanup := setupBridgePage(t)
	defer cleanup()
	_, err := page.Eval(`async () => {
		try { await window.bridge.fetchVia("/totally-unrecognized/path"); }
		catch (e) { return "fetch-tried"; }
	}`)
	if err != nil {

		// expected — native fetch of /totally-unrecognized fails — but no backend_rpc call should be in the recorder.
	}
	rec.mu.Lock()
	defer rec.mu.Unlock()
	if len(rec.calls) != 0 {
		var paths []string
		for _, c := range rec.calls {
			paths = append(paths, c.Service+"/"+c.Method)
		}
		sort.Strings(paths)
		t.Fatalf("expected no backend_rpc call for unknown URL; got: %v", paths)
	}
}
