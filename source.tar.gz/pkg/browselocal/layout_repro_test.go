//go:build integration

package browselocal

import (
	"os"
	"testing"
	"time"

	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/launcher"
	"github.com/go-rod/rod/lib/launcher/flags"
	"github.com/go-rod/rod/lib/proto"
)

// TestRepro_LayoutClearViewportOverride verifies that
// Page.SetViewport(empty) clears rod's default device-metrics override,
// letting the page see real window dimensions. Without this rod pins
// the viewport to 1280x800 regardless of the launcher's window flags.
func TestRepro_LayoutClearViewportOverride(t *testing.T) {
	if os.Getenv("DISPLAY") == "" && os.Getenv("WAYLAND_DISPLAY") == "" {
		t.Skip("no display")
	}
	l := launcher.New().Headless(false).Set(flags.Flag("start-maximized"))
	u, err := l.Launch()
	if err != nil {
		t.Fatalf("launch: %v", err)
	}
	defer l.Cleanup()
	browser := rod.New().ControlURL(u)
	if err := browser.Connect(); err != nil {
		t.Fatalf("connect: %v", err)
	}
	defer browser.Close()

	page := browser.MustPage("about:blank")
	defer page.Close()
	time.Sleep(300 * time.Millisecond)

	beforeW := page.MustEval("() => window.innerWidth").Int()
	beforeH := page.MustEval("() => window.innerHeight").Int()
	t.Logf("before clear: inner=%dx%d", beforeW, beforeH)

	// Clear the device-metrics override that rod installs by default.
	clearErr := (proto.EmulationClearDeviceMetricsOverride{}).Call(page)
	if clearErr != nil {
		t.Logf("ClearDeviceMetricsOverride err: %v", clearErr)
	}
	time.Sleep(300 * time.Millisecond)

	afterW := page.MustEval("() => window.innerWidth").Int()
	afterH := page.MustEval("() => window.innerHeight").Int()
	outerW := page.MustEval("() => window.outerWidth").Int()
	outerH := page.MustEval("() => window.outerHeight").Int()
	screenW := page.MustEval("() => screen.width").Int()
	screenH := page.MustEval("() => screen.height").Int()
	t.Logf("after clear:  inner=%dx%d  outer=%dx%d  screen=%dx%d", afterW, afterH, outerW, outerH, screenW, screenH)

	if afterW <= beforeW && afterH <= beforeH {
		t.Errorf("ClearDeviceMetricsOverride did not change inner viewport (still %dx%d)", afterW, afterH)
	}
	if afterW < 1024 {
		t.Errorf("viewport still narrow after clear: %dx%d", afterW, afterH)
	}
}

// TestRepro_LayoutMaximized verifies that the --start-maximized launcher
// flag actually produces a window that fills (or close to fills) the
// host's screen. If this fails, the user's "layout artificially fixed"
// complaint is reproduced — rod's launched Chromium ignores or fails
// to honor the maximize flag in headed mode.
//

// Skips automatically when there's no display (DISPLAY/WAYLAND_DISPLAY
// unset) — typical CI environment.
func TestRepro_LayoutMaximized(t *testing.T) {
	if os.Getenv("DISPLAY") == "" && os.Getenv("WAYLAND_DISPLAY") == "" {
		t.Skip("no DISPLAY/WAYLAND_DISPLAY — headed-mode layout test only runs interactively")
	}

	cases := []struct {
		name string
		set  func(*launcher.Launcher) *launcher.Launcher
	}{
		{
			name: "start-maximized only",
			set: func(l *launcher.Launcher) *launcher.Launcher {
				return l.Set(flags.Flag("start-maximized"))
			},
		},
		{
			name: "window-size=1920,1080",
			set: func(l *launcher.Launcher) *launcher.Launcher {
				return l.Set(flags.Flag("window-size"), "1920,1080")
			},
		},
		{
			name: "both start-maximized and window-size",
			set: func(l *launcher.Launcher) *launcher.Launcher {
				return l.Set(flags.Flag("start-maximized")).Set(flags.Flag("window-size"), "1920,1080")
			},
		},
		{
			name: "start-maximized + force-device-scale-factor=1",
			set: func(l *launcher.Launcher) *launcher.Launcher {
				return l.Set(flags.Flag("start-maximized")).Set(flags.Flag("force-device-scale-factor"), "1")
			},
		},
		{
			name: "start-maximized + high-dpi-support=0",
			set: func(l *launcher.Launcher) *launcher.Launcher {
				return l.Set(flags.Flag("start-maximized")).Set(flags.Flag("high-dpi-support"), "0")
			},
		},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			l := tc.set(launcher.New().Headless(false))
			u, err := l.Launch()
			if err != nil {
				t.Fatalf("launch: %v", err)
			}
			defer l.Cleanup()
			browser := rod.New().ControlURL(u)
			if err := browser.Connect(); err != nil {
				t.Fatalf("connect: %v", err)
			}
			defer browser.Close()
			page := browser.MustPage("about:blank")
			defer page.Close()

			// Give the window manager time to apply the requested geometry.
			time.Sleep(500 * time.Millisecond)

			w := page.MustEval("() => window.innerWidth").Int()
			h := page.MustEval("() => window.innerHeight").Int()
			outerW := page.MustEval("() => window.outerWidth").Int()
			outerH := page.MustEval("() => window.outerHeight").Int()
			screenW := page.MustEval("() => screen.width").Int()
			screenH := page.MustEval("() => screen.height").Int()
			t.Logf("inner=%dx%d  outer=%dx%d  screen=%dx%d", w, h, outerW, outerH, screenW, screenH)

			if w < 1024 || h < 600 {
				t.Errorf("window too small: inner=%dx%d (want >=1024x600)", w, h)
			}
		})
	}
}
