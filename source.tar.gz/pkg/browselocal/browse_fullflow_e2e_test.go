//go:build calibre_e2e

package browselocal

import (
	"accorder/pkg/calibre"
	"accorder/pkg/rclonexfer"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/launcher"
	"github.com/ysmood/gson"
	"golang.org/x/net/webdav"
)

// TestBrowse_E2E_FullFlow drives the full friend-side chain end-to-end with a
// REAL backend session, REAL calibredb import, and a REAL webdav download:
//
//	browse (real handleBooks over the fixture index)
//	  → select (real handleSelectionToggle)
//	  → QUEUE (real handleSelectionEnqueue)
//	  → [DOWNLOAD ALL] (real handleFetchBatch → downloadWorker → rclone webdav copy)
//	  → MY LIBRARY (real handleOpenMyLibrary → calibredb import + RenderBooksBundle)
//
// Download is REAL: a golang.org/x/net/webdav server (httptest) serves a
// fixture aggregate dir, and the session's "librarian:" rclone remote points at
// it. (x/net is already a module dependency, so no go.mod change.)
//
// Asserts BOTH:
//   - DOM: the MY LIBRARY iframe src points at the built BROWSE_LIBRARY.html.
//   - Filesystem: library_path has BROWSE_LIBRARY.html + static/ in its ROOT
//     and a metadata.db, and has NO .motw-browse / .motw-downloads dirs (the
//     wrong-build-dir bug).
//
// Skips cleanly (t.Skip) if calibredb is not on PATH.
func TestBrowse_E2E_FullFlow(t *testing.T) {
	if _, err := exec.LookPath("calibredb"); err != nil {
		t.Skip("calibredb not on PATH; full-flow import/build chain requires Calibre")
	}

	cacheDir := t.TempDir()
	books := fixtureBooks()
	indexPath := buildFixtureIndex(t, cacheDir, books)

	if err := calibre.CopyBrowseUIAssets(cacheDir); err != nil {
		t.Fatalf("CopyBrowseUIAssets: %v", err)
	}
	if err := os.WriteFile(filepath.Join(cacheDir, "static", "data1.js"),
		[]byte("CALIBRE_BOOKS1={portable:false,books:[]};"), 0644); err != nil {
		t.Fatal(err)
	}

	// --- REAL webdav fixture: serve the aggregate dir over httptest. ---
	// downloadWorker builds srcFs = "librarian:" + prefix + "/" + DirPath, where
	// prefix = "files/aggregate-a" (from BaseURL "/files/aggregate-a"). So the
	// webdav tree must contain files/aggregate-a/<DirPath>/<book files>.
	aggRoot := t.TempDir()
	for _, bk := range books {
		fmtFile := bk.Formats[0]
		bookDir := filepath.Join(aggRoot, "files", "aggregate-a", fmtFile.DirectoryPath)
		if err := os.MkdirAll(bookDir, 0755); err != nil {
			t.Fatal(err)
		}
		// A real (tiny) format file so calibredb add has something to import.
		if err := os.WriteFile(filepath.Join(bookDir, fmtFile.Name),
			[]byte("%PDF-1.4\n% fixture content for "+bk.Title+"\n%%EOF\n"), 0644); err != nil {
			t.Fatal(err)
		}
	}

	dav := &webdav.Handler{
		FileSystem: webdav.Dir(aggRoot),
		LockSystem: webdav.NewMemLS(),
	}
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		dav.ServeHTTP(w, r)
	}))
	defer srv.Close()

	if err := rclonexfer.ConfigWebDAVRemote("librarian", srv.URL); err != nil {
		t.Fatalf("ConfigWebDAVRemote: %v", err)
	}

	session := newRealSession(t, cacheDir, indexPath)
	// Stage downloads OUTSIDE the library so library_path stays clean.
	dlDir := t.TempDir()
	session.opts.DownloadDir = dlDir

	l := launcher.New().Headless(true)
	u, err := l.Launch()
	if err != nil {
		t.Fatalf("launcher: %v", err)
	}
	defer l.Cleanup()

	browser := rod.New().ControlURL(u)
	if err := browser.Connect(); err != nil {
		t.Fatalf("rod.Connect: %v", err)
	}
	defer browser.Close()
	session.browser = browser

	page := browser.MustPage("about:blank")
	defer page.Close()

	page.MustExpose("backend_rpc", func(arg gson.JSON) (interface{}, error) {
		return session.handleRPC(arg.Str())
	})
	watchConsole(t, page)

	fileURL := "file://" + filepath.Join(cacheDir, "BROWSE_LIBRARY.html") + "#/?t=l"
	if err := page.Navigate(fileURL); err != nil {
		t.Fatalf("navigate: %v", err)
	}

	clickTab := func(label string) {
		t.Helper()
		ok := page.MustEval(`(label) => {
			const btns = [...document.querySelectorAll('nav button')];
			const hit = btns.find(b => b.textContent.includes('[' + label + ']'));
			if (!hit) return false;
			hit.click();
			return true;
		}`, label).Bool()
		if !ok {
			dumpBody(t, page)
			t.Fatalf("could not find TabHeader button %q", label)
		}
	}
	clickByText := func(txt string) {
		t.Helper()
		ok := page.MustEval(`(txt) => {
			const els = [...document.querySelectorAll('div,span,a,button')];
			let hit = els.find(e => e.children.length === 0 && e.textContent.trim() === txt);
			if (!hit) hit = els.find(e => e.textContent.includes(txt));
			if (!hit) return false;
			hit.click();
			return true;
		}`, txt).Bool()
		if !ok {
			dumpBody(t, page)
			t.Fatalf("could not click element with text %q", txt)
		}
	}

	// --- browse → select ---
	page.Timeout(15 * time.Second).MustWait(`() => document.querySelectorAll('table tbody tr').length >= 3`)
	page.MustEval(`() => [...document.querySelectorAll('table tbody span')].find(e => e.textContent.trim() === '[ADD TO QUEUE]').click()`)
	page.Timeout(5 * time.Second).MustWait(`() => {
		const btns = [...document.querySelectorAll('nav button')];
		const b = btns.find(x => x.textContent.includes('[QUEUE]'));
		return b && b.textContent.includes('(1)');
	}`)
	t.Log("OK: browse rendered + first book selected (real toggle)")

	// --- QUEUE tab → enqueue → [DOWNLOAD ALL] → real webdav download ---
	clickTab("QUEUE")
	page.Timeout(5 * time.Second).MustWait(`() => document.body.innerText.includes('[DOWNLOAD ALL]')`)
	clickByText("[DOWNLOAD ALL]")

	// Wait for the real download to finish (row marked done by batchStatus poll).
	page.Timeout(30 * time.Second).MustWait(`() => document.querySelector('tr.row-done') !== null`)
	session.mu.Lock()
	var doneTitle string
	if len(session.queue) > 0 && session.queue[0].Status == statusDone {
		doneTitle = session.queue[0].Title
	}
	session.mu.Unlock()
	if doneTitle == "" {
		t.Fatal("download did not reach 'done' for the queued book (real webdav copy failed)")
	}
	t.Logf("OK: real webdav download completed for %q", doneTitle)

	// --- MY LIBRARY tab → real import + build ---
	clickTab("MY LIBRARY")
	// Build completes → iframe renders pointing at the built BROWSE_LIBRARY.html.
	page.Timeout(60 * time.Second).MustWait(`() => {
		const f = document.querySelector('iframe');
		return f && f.getAttribute('src') && f.getAttribute('src').includes('BROWSE_LIBRARY.html');
	}`)
	src := page.MustEval(`() => document.querySelector('iframe').getAttribute('src')`).Str()
	if !strings.HasPrefix(src, "file://") || !strings.Contains(src, "BROWSE_LIBRARY.html") {
		t.Fatalf("DOM assert FAIL: iframe src does not point at built library: %q", src)
	}
	t.Logf("OK (DOM): MY LIBRARY iframe src = %q", src)

	// --- Filesystem assertions on library_path ---
	libPath := session.libraryPath

	mustExist := func(rel string) {
		t.Helper()
		if _, err := os.Stat(filepath.Join(libPath, rel)); err != nil {
			t.Errorf("FS assert FAIL: expected %s in library root: %v", rel, err)
		}
	}
	mustNotExist := func(rel string) {
		t.Helper()
		if _, err := os.Stat(filepath.Join(libPath, rel)); err == nil {
			t.Errorf("FS assert FAIL: %s must NOT exist in library_path (wrong-dir bug)", rel)
		}
	}

	mustExist("BROWSE_LIBRARY.html")
	mustExist("static")
	mustExist("metadata.db")
	mustNotExist(".motw-browse")
	mustNotExist(".motw-downloads")

	// static/ must be a directory at the ROOT (not nested under a dotdir).
	if fi, err := os.Stat(filepath.Join(libPath, "static")); err == nil && !fi.IsDir() {
		t.Errorf("FS assert FAIL: library_path/static is not a directory")
	}

	if t.Failed() {
		entries, _ := os.ReadDir(libPath)
		var names []string
		for _, e := range entries {
			names = append(names, e.Name())
		}
		t.Logf("library_path (%s) contents: %v", libPath, names)
		return
	}
	t.Logf("OK (FS): library_path %s has BROWSE_LIBRARY.html + static/ + metadata.db at root, no dotdirs", libPath)
}
