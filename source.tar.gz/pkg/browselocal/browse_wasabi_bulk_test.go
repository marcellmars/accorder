//go:build integration && wasabi_bulk_e2e

package browselocal

import (
	"accorder/pkg/calibre"
	"accorder/pkg/rclonexfer"
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/launcher"
	"github.com/go-rod/rod/lib/proto"
	"github.com/ysmood/gson"
)

// TestBrowse_E2E_WasabiBulk is the HEAVY full-pipeline tier of the browse e2e
// harness. It drives the headless-Chromium browse client through the entire
// friend flow against the REAL aggregate + Wasabi S3, exactly as a user would:
//
//  1. Search the tag "rulingclassstudies" → assert the catalog reports 113 books.
//  2. Pagination: page 1 offers a "next" link and no active "prev"; clicking
//     next lands on page 2, which offers an active "prev" link.
//  3. [ADD ALL] → assert the selection is 113 (under the 120 select-all gate).
//  4. [QUEUE] tab → the 113 selected collapse to 105 UNIQUE books:
//     enqueue dedups by title+author, dropping the 8 cross-library duplicates
//     before download. Assert the batch holds 105.
//  5. [DOWNLOAD ALL] (download all) → wait until all 105 reach "done"
//     (real fetches from Wasabi through the serve file plane).
//  6. [MY LIBRARY] tab → library_path points at a NON-EXISTING Calibre library,
//     so it is created, all 105 unique books are imported, the library is built,
//     and the rendered library contains exactly 105 books.
//
// COST: downloading the 105 unique blobs pulls ~390 MiB from Wasabi on the FIRST
// run. To avoid re-paying that egress, two persistent caches are reused:
//   - the serve VFS blob cache (alias "smoketest", CacheMode full, 10Gi, no age
//     eviction) under <accorderConfigDir>/cache — survives serve restarts;
//   - the client download/staging dir (ACCORDER_BULK_DL_CACHE, default
//     <UserCacheDir>/accorder/wasabi-bulk-downloads). The download worker uses
//     rclone size-only compare (book blobs are immutable; the served modtime is
//     unstable across serve restarts), so a book already on disk is skipped and
//     0 bytes are re-fetched. The test logs session.bytesTransferred and asserts
//     a warm-cache run stays under 50 MiB (verified: warm re-run = 0.0 MiB).
//
// The MY LIBRARY target is a fresh dir each run (the test asserts a from-scratch
// 105-book library), but its books are imported from the persistent staging dir,
// so a re-run rebuilds without re-downloading.
//
// Gated behind its OWN build tag (wasabi_bulk_e2e) so the cheap
// TestBrowse_E2E_WasabiSmoke (wasabi_e2e) never pulls this corpus. Run with:
//
//	go test -tags "integration wasabi_bulk_e2e" -run TestBrowse_E2E_WasabiBulk \
//	    -timeout 40m -v ./pkg/browselocal
//
// Skips cleanly unless Wasabi creds + a local aggregate index resolve, and
// requires calibredb on PATH for the MY LIBRARY leg.
func TestBrowse_E2E_WasabiBulk(t *testing.T) {
	const (
		tag = "rulingclassstudies"
		// The tag matches 113 catalog entries, but 8 are the same title+author
		// in more than one source library. Those collapse to a single download +
		// library entry: enqueue dedups before download, so the batch, the
		// downloads, and the built library all hold 105 unique books.
		wantCatalog = 113 // search count + select-all selection
		wantUnique  = 105 // queued + downloaded + imported (after title+author dedup)
		wantDedup   = wantCatalog - wantUnique
		pageSize    = 48
	)

	creds, ok := resolveWasabiCreds(t)
	if !ok {
		t.Skip("wasabi bulk: S3 creds not found (env S3_* or aggtest alias) — skipping")
	}
	aggPath := resolveAggregatePath()
	if aggPath == "" {
		t.Skip("wasabi bulk: local aggregate index not found — skipping")
	}
	if _, err := exec.LookPath("calibredb"); err != nil {
		t.Skip("wasabi bulk: calibredb not on PATH — MY LIBRARY leg requires it; skipping")
	}
	t.Logf("wasabi bulk: creds from %s (access-key %s); aggregate at %s",
		creds.source, maskKey(creds.accessKey), aggPath)

	// --- Build binary + start serve against the real aggregate + Wasabi. ---
	serveURL := startServeOnAgg(t, creds)
	t.Logf("wasabi bulk: serve answering at %s", serveURL)

	// Self-managed temp dirs with error-tolerant cleanup. cacheDir (browse UI +
	// rendered library) and libDir are written/read by background goroutines —
	// the build/import worker and Chromium rendering the file:// library — which
	// can still touch them as the test returns. t.TempDir's strict RemoveAll
	// would then fail the (already-passed) test with "directory not empty", so
	// we own the cleanup and ignore that race.
	mkDir := func(name string) string {
		d, err := os.MkdirTemp("", "wasabi-bulk-"+name+"-")
		if err != nil {
			t.Fatal(err)
		}
		t.Cleanup(func() { _ = os.RemoveAll(d) })
		return d
	}

	// --- Drive the headless browse client (clearnet aggregator path). ---
	cacheDir := mkDir("cache")
	staticDir := filepath.Join(cacheDir, "static")
	if err := os.MkdirAll(staticDir, 0755); err != nil {
		t.Fatal(err)
	}

	rclonexfer.Initialize()
	defer rclonexfer.Finalize()
	if err := rclonexfer.ConfigHTTPRemote("librarian-cat", serveURL); err != nil {
		t.Fatalf("ConfigHTTPRemote: %v", err)
	}
	if err := rclonexfer.ConfigWebDAVRemote("librarian", serveURL); err != nil {
		t.Fatalf("ConfigWebDAVRemote: %v", err)
	}
	if err := rclonexfer.CopyFile("librarian-cat:", "static/library_index.zst", staticDir, "library_index.zst"); err != nil {
		t.Fatalf("sync library_index.zst: %v", err)
	}
	if err := rclonexfer.CopyFile("librarian-cat:", "static/data1.js", staticDir, "data1.js"); err != nil {
		t.Fatalf("sync data1.js: %v", err)
	}
	if err := calibre.CopyBrowseUIAssets(cacheDir); err != nil {
		t.Fatalf("CopyBrowseUIAssets: %v", err)
	}
	for i := 2; i <= 8; i++ {
		stub := fmt.Sprintf("CALIBRE_BOOKS%d={books:[]}", i)
		if err := os.WriteFile(filepath.Join(staticDir, fmt.Sprintf("data%d.js", i)), []byte(stub), 0644); err != nil {
			t.Fatalf("write data%d.js stub: %v", i, err)
		}
	}

	// --- Open the synced index + build a real session. ---
	indexPath := filepath.Join(staticDir, "library_index")
	opened, err := (&calibre.MotwSearch{IndexPath: indexPath}).Open()
	if err != nil {
		t.Fatalf("open synced index: %v", err)
	}
	t.Cleanup(func() { opened.Close() })

	// Fresh, NON-EXISTING Calibre library (empty dir, no metadata.db) — the
	// MY LIBRARY step must create it and import the unique books from scratch.
	libDir := filepath.Join(mkDir("lib"), "mylib")
	if err := os.MkdirAll(libDir, 0755); err != nil {
		t.Fatal(err)
	}

	// PERSISTENT download/staging dir so re-runs skip already-downloaded blobs
	// (rclone sync/copy skips matching files → no repeat Wasabi egress).
	dlDir := os.Getenv("ACCORDER_BULK_DL_CACHE")
	if dlDir == "" {
		base, derr := os.UserCacheDir()
		if derr != nil || base == "" {
			base = os.TempDir()
		}
		dlDir = filepath.Join(base, "accorder", "wasabi-bulk-downloads")
	}
	if err := os.MkdirAll(dlDir, 0755); err != nil {
		t.Fatalf("mkdir bulk download cache: %v", err)
	}
	cachedBefore := countSubdirs(dlDir)
	t.Logf("wasabi bulk: download/staging cache = %s (%d book folders already present → will be reused)", dlDir, cachedBefore)

	session := &librarySession{
		opened:         opened,
		cacheDir:       cacheDir,
		opts:           Options{DownloadDir: dlDir},
		selection:      make(map[string]bool),
		selectionBooks: make(map[string]*calibre.Book),
		downloadCh:     make(chan *queueItem, 256),
		stagedPages:    make(map[proto.TargetTargetID]bool),
		libraryPath:    libDir,
		librarianName:  "bulk",
	}

	// --- rod headless. ---
	l := launcher.New().Headless(true)
	u, err := l.Launch()
	if err != nil {
		t.Fatalf("launcher: %v", err)
	}
	defer l.Cleanup()
	browser := rod.New().ControlURL(u)
	if err := browser.Connect(); err != nil {
		t.Fatalf("rod.Connect: %v", err)
	}
	defer browser.Close()
	session.browser = browser

	page := browser.MustPage("about:blank")
	defer page.Close()
	page.MustExpose("backend_rpc", func(arg gson.JSON) (interface{}, error) {
		return session.handleRPC(arg.Str())
	})
	watchConsole(t, page)

	fileURL := "file://" + filepath.Join(cacheDir, "BROWSE_LIBRARY.html") + "#/?t=l"
	if err := page.Navigate(fileURL); err != nil {
		t.Fatalf("navigate: %v", err)
	}
	page.Timeout(30 * time.Second).MustWait(`() => document.querySelectorAll('table tbody tr').length >= 5`)

	// --- Step 1: search the tag → 113 catalog books. ---
	page.MustEval(fmt.Sprintf(`() => { location.hash = '#/search/tags/%s'; }`, tag))
	page.Timeout(30 * time.Second).MustWait(fmt.Sprintf(`() => document.body.innerText.includes('of %d')`, wantCatalog))
	status := navStatus(page)
	if !strings.Contains(status, fmt.Sprintf("of %d", wantCatalog)) {
		t.Fatalf("search status %q does not report 'of %d'", status, wantCatalog)
	}
	// The status line renders the search FIELD ("search: tag"), not the query
	// string — assert it indicates a tag search.
	if !strings.Contains(strings.ToLower(status), "tag") {
		t.Fatalf("search status %q does not indicate a tag search", status)
	}
	t.Logf("OK: search tag=%q → catalog reports %d books (status=%q)", tag, wantCatalog, status)

	// --- Step 2: pagination — page 1 has next, no active prev; page 2 has prev. ---
	links1 := pageLinks(page)
	if !links1.next {
		t.Fatalf("page 1: expected an active 'next' link (113 books / %d per page = multiple pages), got none", pageSize)
	}
	if links1.prev {
		t.Fatalf("page 1: expected NO active 'prev' link, but one is present")
	}
	t.Logf("OK: page 1 — next link present, prev disabled (status=%q)", links1.status)

	clickLinkText(t, page, "next")
	page.Timeout(20 * time.Second).MustWait(fmt.Sprintf(`() => document.body.innerText.includes('%d-')`, pageSize))
	links2 := pageLinks(page)
	if !links2.prev {
		t.Fatalf("page 2: expected an active 'prev' link, got none (status=%q)", links2.status)
	}
	t.Logf("OK: page 2 — prev link present (status=%q)", links2.status)

	// --- Step 3: select all → 113 selected (under the 120 gate). ---
	// select-all operates on the active search (tag=rulingclassstudies),
	// independent of the current page, and selects all 113 catalog matches.
	clickSpanText(t, page, "[ADD ALL]")
	page.Timeout(20 * time.Second).MustWait(fmt.Sprintf(`() => {
		const b = [...document.querySelectorAll('nav button')].find(x => x.textContent.includes('QUEUE'));
		return b && b.textContent.includes('(%d)');
	}`, wantCatalog))
	session.mu.Lock()
	selCount := len(session.selection)
	session.mu.Unlock()
	if selCount != wantCatalog {
		t.Fatalf("select all: backend selection = %d, want %d", selCount, wantCatalog)
	}
	t.Logf("OK: [ADD ALL] → %d books selected (QUEUE badge shows (%d))", selCount, wantCatalog)

	// --- Step 4: QUEUE tab → 113 selected collapse to 105 unique. ---
	// Enqueue dedups by title+author, so the 8 cross-library duplicates are
	// dropped before download and the batch holds 105 books.
	clickTabButton(t, page, "QUEUE")
	page.Timeout(30 * time.Second).MustWait(fmt.Sprintf(`() => document.querySelectorAll('table tbody tr').length === %d`, wantUnique))
	batchRows := page.MustEval(`() => document.querySelectorAll('table tbody tr').length`).Int()
	if batchRows != wantUnique {
		t.Fatalf("QUEUE: table shows %d rows, want %d (after title+author dedup)", batchRows, wantUnique)
	}
	session.mu.Lock()
	queued := len(session.queue)
	session.mu.Unlock()
	if queued != wantUnique {
		t.Fatalf("QUEUE: queue has %d items, want %d (after dedup of %d duplicates)", queued, wantUnique, wantDedup)
	}
	t.Logf("OK: QUEUE — %d selected → %d unique queued (%d title+author duplicates dropped before download)", wantCatalog, wantUnique, wantDedup)

	// --- Step 5: download all → wait until all 105 reach 'done'. ---
	clickSpanText(t, page, "[DOWNLOAD ALL]")
	dlDeadline := time.Now().Add(35 * time.Minute)
	var done, failed int
	lastLog := time.Now()
	for time.Now().Before(dlDeadline) {
		done, failed = 0, 0
		var firstErr string
		session.mu.Lock()
		for _, it := range session.queue {
			switch it.Status {
			case statusDone:
				done++
			case statusFailed:
				failed++
				if firstErr == "" {
					firstErr = it.Title + ": " + it.Error
				}
			}
		}
		session.mu.Unlock()
		if failed > 0 {
			t.Fatalf("download all: %d book(s) failed (first: %s) — index↔blob mismatch or transfer error", failed, firstErr)
		}
		if done == wantUnique {
			break
		}
		if time.Since(lastLog) > 15*time.Second {
			t.Logf("wasabi bulk: downloading… %d/%d done", done, wantUnique)
			lastLog = time.Now()
		}
		time.Sleep(500 * time.Millisecond)
	}
	if done != wantUnique {
		t.Fatalf("download all: only %d/%d reached 'done' before timeout", done, wantUnique)
	}
	session.mu.Lock()
	xfer := session.bytesTransferred
	session.mu.Unlock()
	t.Logf("OK: download all — %d/%d books done; bytes pulled over the network this run = %.1f MiB",
		done, wantUnique, float64(xfer)/(1<<20))
	if cachedBefore > 0 && xfer > 50<<20 {
		// Warm cache (a prior run populated the persistent dir) but we still
		// transferred a lot → size-only skip regressed.
		t.Errorf("warm cache but %.1f MiB transferred — size-only skip should make re-runs ~free", float64(xfer)/(1<<20))
	}

	// --- Step 6: MY LIBRARY → fresh library, import 105, build, render 105. ---
	clickTabButton(t, page, "MY LIBRARY")
	page.Timeout(20 * time.Minute).MustWait(`() => {
		const f = document.querySelector('iframe');
		return f && f.getAttribute('src') && f.getAttribute('src').includes('BROWSE_LIBRARY.html');
	}`)
	src := page.MustEval(`() => document.querySelector('iframe').getAttribute('src')`).Str()
	if !strings.HasPrefix(src, "file://") || !strings.Contains(src, "BROWSE_LIBRARY.html") {
		t.Fatalf("MY LIBRARY: iframe src does not point at built library: %q", src)
	}
	t.Logf("OK (DOM): MY LIBRARY iframe src = %q", src)

	// Ground truth: the freshly-created Calibre library at libDir holds 105
	// unique books — and since dedup happened before download, calibredb add
	// rejected ZERO as duplicates (no redundant blobs were ever fetched).
	for _, rel := range []string{"BROWSE_LIBRARY.html", "static", "metadata.db"} {
		if _, err := os.Stat(filepath.Join(libDir, rel)); err != nil {
			t.Errorf("MY LIBRARY: expected %s in library root: %v", rel, err)
		}
	}
	exe := &calibre.CalibreExe{LibraryPath: libDir}
	libBooks, err := exe.Books(context.Background())
	if err != nil {
		t.Fatalf("MY LIBRARY: calibredb list of built library: %v", err)
	}
	if len(libBooks) != wantUnique {
		t.Fatalf("MY LIBRARY: built library has %d books, want %d", len(libBooks), wantUnique)
	}
	t.Logf("OK: MY LIBRARY — fresh Calibre library at %s holds exactly %d unique books", libDir, len(libBooks))
	t.Logf("wasabi bulk: PASS (search %d + pagination + select-all %d + dedup→%d + download-all + import/build %d verified)",
		wantCatalog, wantCatalog, wantUnique, wantUnique)
}

// --- bulk-specific DOM helpers --------------------------------------------

type navLinks struct {
	prev, next bool
	status     string
}

// navStatus returns the NavBar search-status string ("48-96 of 113 (tags: …)").
func navStatus(page *rod.Page) string {
	return page.MustEval(`() => {
		const m = document.body.innerText.match(/\d+-\d+ of \d+ \([^)]*\)/);
		return m ? m[0] : '';
	}`).Str()
}

// pageLinks reports whether active (anchor, not disabled span) prev/next
// pagination links are present. The NavBar renders enabled controls as <a> and
// disabled ones as <span>, so we only count anchors carrying an href.
func pageLinks(page *rod.Page) navLinks {
	out := page.MustEval(`() => {
		const as = [...document.querySelectorAll('a[href]')];
		const has = (w) => as.some(a => a.textContent.toLowerCase().includes(w) && a.getAttribute('href').startsWith('#'));
		const m = document.body.innerText.match(/\d+-\d+ of \d+ \([^)]*\)/);
		return JSON.stringify({prev: has('prev'), next: has('next'), status: m ? m[0] : ''});
	}`).Str()
	var nl navLinks
	// minimal hand-parse to avoid importing encoding/json here
	nl.prev = strings.Contains(out, `"prev":true`)
	nl.next = strings.Contains(out, `"next":true`)
	if i := strings.Index(out, `"status":"`); i >= 0 {
		rest := out[i+len(`"status":"`):]
		if j := strings.Index(rest, `"`); j >= 0 {
			nl.status = rest[:j]
		}
	}
	return nl
}

// clickLinkText clicks the first <a> whose text contains the given word.
func clickLinkText(t *testing.T, page *rod.Page, word string) {
	t.Helper()
	ok := page.MustEval(`(w) => {
		const a = [...document.querySelectorAll('a[href]')].find(x => x.textContent.toLowerCase().includes(w));
		if (!a) return false;
		a.click();
		return true;
	}`, strings.ToLower(word)).Bool()
	if !ok {
		t.Fatalf("could not find/click <a> containing %q", word)
	}
}

// clickSpanText clicks the first element whose text equals/contains the label
// (used for [ADD ALL] / [DOWNLOAD ALL] spans).
func clickSpanText(t *testing.T, page *rod.Page, label string) {
	t.Helper()
	ok := page.MustEval(`(label) => {
		const el = [...document.querySelectorAll('span')].find(x => x.textContent.includes(label));
		if (!el) return false;
		el.click();
		return true;
	}`, label).Bool()
	if !ok {
		dumpBody(t, page)
		t.Fatalf("could not find/click span %q", label)
	}
}

// clickTabButton clicks a TabHeader pipeline button by its label.
func clickTabButton(t *testing.T, page *rod.Page, label string) {
	t.Helper()
	ok := page.MustEval(`(label) => {
		const b = [...document.querySelectorAll('nav button')].find(x => x.textContent.includes('[' + label + ']'));
		if (!b) return false;
		b.click();
		return true;
	}`, label).Bool()
	if !ok {
		dumpBody(t, page)
		t.Fatalf("could not find/click TabHeader button %q", label)
	}
}

// countSubdirs returns the number of immediate subdirectories of dir (used to
// report download-cache reuse).
func countSubdirs(dir string) int {
	entries, err := os.ReadDir(dir)
	if err != nil {
		return 0
	}
	n := 0
	for _, e := range entries {
		if e.IsDir() {
			n++
		}
	}
	return n
}
