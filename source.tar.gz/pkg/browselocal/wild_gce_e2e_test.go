//go:build gce_e2e

package browselocal

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/launcher"
)

// TestWild_GCE_MixedFederation is the in-the-wild, real-corpus, multi-host E2E
// test for mixed federation (2 operator-hosted + 3 peer-autonomous members).
//

// It provisions 2 throwaway GCE VMs, seeds them with bounded samples of 5 real
// production libraries, exercises both federation models in a single aggregate,
// proves that per-library metadata mutations propagate through the live operator
// daemon, and tears everything down.
//

// Gated behind the gce_e2e build tag. Requires gcloud, rclone, and Wasabi creds.
//

// Run:
//
//	go test -tags gce_e2e -run TestWild_GCE_MixedFederation ./pkg/browselocal/ -v -timeout 30m
func TestWild_GCE_MixedFederation(t *testing.T) {

	// --- preflight ---
	if _, err := exec.LookPath("gcloud"); err != nil {
		t.Skip("gce_e2e: gcloud not found — skipping")
	}
	if _, err := exec.LookPath("rclone"); err != nil {
		t.Skip("gce_e2e: rclone not found — skipping")
	}
	project := envOr("WILD_GCP_PROJECT", "portdistrict")
	zone := envOr("WILD_ZONE", "europe-west3-b")
	c, ok := resolveWasabiFullKeysGCE(t)
	if !ok {
		t.Skip("gce_e2e: wasabi_full.keys not found — skipping")
	}
	bin := buildAccorderBinaryLinux(t)

	// Per-run ID for isolation. The bucket is a FLAT top-level per-run bucket
	// (accorder-test-<runID>) — matching production's flat-bucket model. A NESTED
	// bucket path (accorder-test/<runID>) tripped a librclone/S3 fs-resolution quirk
	// that spuriously 404'd member _GENERATION probes and health-retired members.
	runID := fmt.Sprintf("e2e-%d", time.Now().UnixMilli())
	bucket := "accorder-test-" + runID

	// env for all scripts
	scriptEnv := append(os.Environ(),
		"WILD_GCP_PROJECT="+project,
		"WILD_ZONE="+zone,
		"WILD_BINARY="+bin,
		"WILD_SAMPLE_BOOKS="+envOr("WILD_SAMPLE_BOOKS", "10"),
		"WILD_RUN_ID="+runID,
		"WILD_BUCKET="+bucket,
	)
	scriptEnv = append(scriptEnv, rcloneEnvGCE(c)...)

	// always teardown
	t.Cleanup(func() { runScript(t, "scripts/wild-e2e/teardown.sh", scriptEnv) })

	// --- phases ---
	phases := []string{
		"provision.sh", "deploy.sh", "seed.sh",
		"onboard-op.sh", "onboard-peer.sh",
		"aggregate-serve.sh", "mutate-assert.sh",
	}
	for _, script := range phases {
		t.Run(strings.TrimSuffix(script, ".sh"), func(t *testing.T) {
			runScript(t, "scripts/wild-e2e/"+script, scriptEnv)
		})
	}

	// --- web browse (reader, doc step 0): a real headless browser drives the
	// operator's served SPA against the live federated aggregate. Skips cleanly if
	// no Chrome is available (set WILD_BROWSER_CHECK=0 to force-skip). ---
	if os.Getenv("WILD_BROWSER_CHECK") != "0" {
		t.Run("web-browse", func(t *testing.T) {
			opIP := getVMIP(t, "wild-op", project, zone)
			browseAssert(t, "http://"+opIP+":8800")
		})

		// --- browse render (reader→librarian, doc steps 1+5): drive the lib-browse
		// CLIENT against the live federated operator — sync the catalog, queue a
		// downloadable book, fetch it over HTTP /files/, and import + build into a
		// fresh local Calibre library. The standard seeds are metadata-only, so seed
		// one real-format book first. Needs calibredb on this host. ---
		t.Run("browse-render", func(t *testing.T) {
			if _, err := exec.LookPath("calibredb"); err != nil {
				t.Skip("browse-render: calibredb not on this host (laptop import requires Calibre)")
			}
			runScript(t, "scripts/wild-e2e/browse-render-seed.sh", scriptEnv)
			opIP := getVMIP(t, "wild-op", project, zone)
			session := newClearnetRenderSession(t, "http://"+opIP+":8800/")
			browseRenderAndImport(t, session, "RenderBook")
		})
	}
}

// --- helpers (duplicated from wasabi_e2e-tagged files to keep gce_e2e standalone) ---

// envOr returns the env var value or the default.
func envOr(key, def string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return def
}

// gceCreds holds Wasabi S3 credentials for the GCE E2E test.
type gceCreds struct {
	accessKey, secretKey string
}

// resolveWasabiFullKeysGCE reads wasabi_full.keys from the repo root.
func resolveWasabiFullKeysGCE(t *testing.T) (gceCreds, bool) {
	t.Helper()
	root, err := filepath.Abs("../..")
	if err != nil {
		return gceCreds{}, false
	}
	data, err := os.ReadFile(filepath.Join(root, "wasabi_full.keys"))
	if err != nil {
		return gceCreds{}, false
	}
	var ak, sk string
	for _, line := range strings.Split(string(data), "\n") {
		line = strings.TrimSpace(line)
		if v, found := strings.CutPrefix(line, "access-key="); found {
			ak = strings.TrimSpace(v)
		}
		if v, found := strings.CutPrefix(line, "secret-key="); found {
			sk = strings.TrimSpace(v)
		}
	}
	if ak == "" || sk == "" {
		return gceCreds{}, false
	}
	return gceCreds{accessKey: ak, secretKey: sk}, true
}

// rcloneEnvGCE builds rclone env vars for an inline "was:" S3 remote.
func rcloneEnvGCE(c gceCreds) []string {
	return []string{
		"RCLONE_CONFIG_WAS_TYPE=s3",
		"RCLONE_CONFIG_WAS_PROVIDER=Wasabi",
		"RCLONE_CONFIG_WAS_ENDPOINT=s3.wasabisys.com",
		"RCLONE_CONFIG_WAS_ACCESS_KEY_ID=" + c.accessKey,
		"RCLONE_CONFIG_WAS_SECRET_ACCESS_KEY=" + c.secretKey,
	}
}

// buildAccorderBinaryLinux cross-compiles for linux/amd64 (GCE targets).
func buildAccorderBinaryLinux(t *testing.T) string {
	t.Helper()
	bin := filepath.Join(t.TempDir(), "accorder")
	cmd := exec.Command("go", "build", "-o", bin, "accorder")
	cmd.Env = append(os.Environ(), "CGO_ENABLED=0", "GOOS=linux", "GOARCH=amd64")
	if out, err := cmd.CombinedOutput(); err != nil {
		t.Fatalf("cross-compile accorder: %v\n%s", err, out)
	}
	return bin
}

// runScript executes a shell script and fails the test on non-zero exit.
func runScript(t *testing.T, scriptPath string, env []string) {
	t.Helper()
	repoRoot, err := filepath.Abs("../..")
	if err != nil {
		t.Fatalf("resolve repo root: %v", err)
	}
	absScript := filepath.Join(repoRoot, scriptPath)
	cmd := exec.Command("bash", absScript)
	cmd.Dir = repoRoot
	cmd.Env = env
	out, err := cmd.CombinedOutput()
	t.Logf("=== %s ===\n%s", scriptPath, out)
	if err != nil {
		t.Fatalf("%s failed: %v", scriptPath, err)
	}
}

// getVMIP returns the external IP of a GCE VM.
func getVMIP(t *testing.T, vmName, project, zone string) string {
	t.Helper()
	out, err := exec.Command("gcloud", "compute", "instances", "describe", vmName,
		"--zone="+zone, "--project="+project,
		"--format=get(networkInterfaces[0].accessConfigs[0].natIP)").Output()
	if err != nil {
		t.Fatalf("get IP for %s: %v", vmName, err)
	}
	return strings.TrimSpace(string(out))
}

// browseAssert drives a headless Chrome against the operator's served SPA to prove
// the reader (doc step 0) browses the live federated aggregate end to end: the SPA
// loads and renders covers, and a browser-origin fetch of /books returns the full
// federated catalog (operator-hosted + peer members). This exercises the served
// browse UI + the catalog API from a real browser, not just curl.
func browseAssert(t *testing.T, base string) {
	t.Helper()
	l := launcher.New().Headless(true)
	u, err := l.Launch()
	if err != nil {
		t.Skipf("rod launcher unavailable (%v); skipping web-browse", err)
	}
	defer l.Cleanup()
	browser := rod.New().ControlURL(u)
	if err := browser.Connect(); err != nil {
		t.Fatalf("rod.Connect: %v", err)
	}
	defer browser.Close()
	page := browser.MustPage("about:blank")
	defer page.Close()

	if err := page.Navigate(base + "/#/?"); err != nil {
		t.Fatalf("navigate: %v", err)
	}
	page.Timeout(30 * time.Second).MustWait(
		`() => document.querySelectorAll('.cover').length > 0`)
	t.Log("OK: SPA renders covers from the live federated aggregate")

	// Browser-origin fetch of the catalog API: proves the reader sees the FULL
	// federated aggregate (op-hosted + peer members), served to a real browser.
	total := page.Timeout(20*time.Second).MustEval(`
		async (base) => {
			const r = await fetch(base + '/books?limit=5000');
			if (!r.ok) return -1;
			const j = await r.json();
			return (j && j._meta && typeof j._meta.total === 'number')
				? j._meta.total
				: (j && j._items ? j._items.length : -1);
		}`, base).Int()
	if total < 50 {
		t.Fatalf("aggregate /books total via browser = %d, want >= 50 (federated catalog)", total)
	}
	t.Logf("OK: browser sees %d books in the live federated aggregate", total)
}
