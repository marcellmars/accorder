//go:build integration

package browselocal

import (
	"encoding/json"
	"path/filepath"
	"sync"
	"testing"
	"time"

	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/launcher"
	"github.com/ysmood/gson"
)

// TestBrowse_E2E_CoversQueueButton drives the real built bundle through the rod
// harness to prove that, in browse+backend mode:
//
//   - the [show covers] grid (BookCard) shows [ADD TO QUEUE] in place of the
//     per-format download links, clicking it fires library/selection/toggle and
//     flips the button to [ADDED];
//   - opening the book card (BookModal) shows the SAME button in the red motw
//     stripe, already reflecting the [ADDED] state for the staged book.
//
// Only backend_rpc is stubbed — file:// navigation, the embedded bundle, and the
// real Svelte runtime are exercised exactly as in production.
func TestBrowse_E2E_CoversQueueButton(t *testing.T) {
	dir := writeFixture(t)

	l := launcher.New().Headless(true)
	u, err := l.Launch()
	if err != nil {
		t.Fatalf("launcher: %v", err)
	}
	defer l.Cleanup()
	browser := rod.New().ControlURL(u)
	if err := browser.Connect(); err != nil {
		t.Fatalf("rod.Connect: %v", err)
	}
	defer browser.Close()

	page := browser.MustPage("about:blank")
	defer page.Close()

	// Stateful selection set so selection/toggle returns a realistic
	// {count, selected_ids} the frontend can render [ADDED] from.
	var mu sync.Mutex
	selected := map[string]bool{}
	var toggleCalls int

	page.MustExpose("backend_rpc", func(arg gson.JSON) (interface{}, error) {
		var c rpcCall
		if err := json.Unmarshal([]byte(arg.Str()), &c); err != nil {
			return nil, err
		}
		switch c.Service + "/" + c.Method {
		case "session/mode":
			return "browse", nil
		case "library/settings/get":
			return map[string]any{"library_path": "/tmp/lib", "librarian": "test"}, nil
		case "library/search":
			return map[string]any{
				"_items": []map[string]any{
					{
						"_id": "queue-book-1", "title": "Queueable Title",
						"authors":       []string{"Test Author"},
						"library_url":   "",
						"cover_url":     "",
						"tags":          []string{},
						"formats":       []map[string]any{{"format": "pdf", "size": 123, "url": "x.pdf"}},
						"pubdate":       "2024-01-01",
						"abstract":      "Detail abstract.",
						"last_modified": "2024-12-01",
						"librarian":     "test",
					},
				},
				"_meta":  map[string]any{"total": 1, "page": 1, "max_results": 48},
				"_links": map[string]any{"self": map[string]any{"href": "search/tags/x"}},
			}, nil
		case "library/selection/toggle":
			mu.Lock()
			toggleCalls++
			id, _ := c.Args["book_id"].(string)
			if selected[id] {
				delete(selected, id)
			} else {
				selected[id] = true
			}
			ids := []string{}
			for k := range selected {
				ids = append(ids, k)
			}
			n := len(ids)
			mu.Unlock()
			return map[string]any{"count": n, "selected_ids": ids}, nil
		}
		return map[string]any{"_items": []any{}}, nil
	})

	watchConsole(t, page)

	// No "?t=l" → the default [show covers] grid renders.
	fileURL := "file://" + filepath.Join(dir, "BROWSE_LIBRARY.html") + "#/search/tags/x"
	if err := page.Navigate(fileURL); err != nil {
		t.Fatalf("navigate: %v", err)
	}

	// The cover card shows [ADD TO QUEUE] — not the PDF download link.
	page.Timeout(15 * time.Second).MustWait(`() => {
		const body = (document.body && document.body.textContent) || "";
		return body.includes("Queueable Title") && body.includes("[ADD TO QUEUE]");
	}`)
	if hasPDFLink(page) {
		t.Fatalf("covers card still shows a format download link; expected [ADD TO QUEUE] to replace it")
	}

	// Click [ADD TO QUEUE] in the grid.
	page.MustEval(`() => {
		const spans = document.querySelectorAll('span');
		for (const s of spans) {
			if (s.textContent.trim() === "[ADD TO QUEUE]") { s.click(); return; }
		}
		throw new Error("no [ADD TO QUEUE] span in covers grid");
	}`)

	// Button flips to [ADDED].
	page.Timeout(5 * time.Second).MustWait(`() => ((document.body && document.body.textContent) || "").includes("[ADDED]")`)

	mu.Lock()
	if toggleCalls != 1 {
		mu.Unlock()
		t.Fatalf("selection/toggle fired %d times, want 1", toggleCalls)
	}
	mu.Unlock()

	// Open the book card (modal) for the staged book.
	page.MustEval(`() => {
		const a = document.querySelector('a[href="#/book/queue-book-1"]');
		if (!a) throw new Error("no book link in covers grid");
		a.click();
	}`)

	// Modal renders and shows [ADDED] in the red motw stripe before the << >> nav.
	page.Timeout(5 * time.Second).MustWait(`() => {
		const modal = document.querySelector('.modal');
		if (!modal) return false;
		const stripe = [...modal.querySelectorAll('div')].find(d =>
			d.className.includes('bg-motw-red') && d.textContent.includes('<<'));
		return !!stripe && stripe.textContent.includes("[ADDED]");
	}`)

	t.Logf("OK: covers [ADD TO QUEUE]→[ADDED] toggle + modal stripe reflects staged state")
}

// hasPDFLink reports whether any anchor in the page links to a .pdf format file
// (the old per-format download link the queue button replaces in browse mode).
func hasPDFLink(page *rod.Page) bool {
	return page.MustEval(`() => {
		const as = document.querySelectorAll('a[href$=".pdf"]');
		return as.length > 0;
	}`).Bool()
}
