//go:build integration

package browselocal

import (
	"encoding/json"
	"path/filepath"
	"sync"
	"testing"
	"time"

	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/launcher"
	"github.com/ysmood/gson"
)

// TestBrowse_E2E_QueuePollSurvivesBuilt reproduces the bug where, after MY
// LIBRARY has built once (so backend batchStatus reports a STICKY
// build_status:"built"), returning to QUEUE and downloading a still-queued book
// appeared to do nothing: the QUEUE poll used to stop itself on
// build_status=="built", freezing the table so the second book's
// downloading→done transition never showed.
//
// The mock simulates an already-built session (build_status:"built" always) with
// two queued books. After entering QUEUE and waiting past the first poll tick,
// clicking the second row's [download] must drive that row to "done" — which only
// happens if the poll is still alive.
func TestBrowse_E2E_QueuePollSurvivesBuilt(t *testing.T) {
	dir := writeFixture(t)

	l := launcher.New().Headless(true)
	u, err := l.Launch()
	if err != nil {
		t.Fatalf("launcher: %v", err)
	}
	defer l.Cleanup()
	browser := rod.New().ControlURL(u)
	if err := browser.Connect(); err != nil {
		t.Fatalf("rod.Connect: %v", err)
	}
	defer browser.Close()
	page := browser.MustPage("about:blank")
	defer page.Close()

	// queue state: b1 already done (the "first one"), b2 still queued.
	var mu sync.Mutex
	status := map[string]string{"b1": "done", "b2": "queued"}

	itemsLocked := func() []map[string]any {
		order := []string{"b1", "b2"}
		out := make([]map[string]any, 0, len(order))
		for _, id := range order {
			out = append(out, map[string]any{
				"_id": id, "book_id": id, "title": "Book " + id,
				"status": status[id], "progress": 0, "library_url": "",
				"authors": []string{"A"}, "formats": []map[string]any{},
			})
		}
		return out
	}

	page.MustExpose("backend_rpc", func(arg gson.JSON) (interface{}, error) {
		var c rpcCall
		if err := json.Unmarshal([]byte(arg.Str()), &c); err != nil {
			return nil, err
		}
		switch c.Service + "/" + c.Method {
		case "session/mode":
			return "browse", nil
		case "library/settings/get":
			return map[string]any{"library_path": "/tmp/lib", "librarian": "test"}, nil
		case "library/books":
			return map[string]any{
				"_items": []map[string]any{{"_id": "b1", "title": "Book b1", "authors": []string{"A"}, "librarian": "test", "library_url": "", "cover_url": "", "tags": []string{}, "formats": []map[string]any{}, "last_modified": "2024-01-01"}},
				"_meta":  map[string]any{"total": 1, "page": 1, "max_results": 48},
				"_links": map[string]any{"self": map[string]any{"href": "/books"}},
			}, nil
		case "library/selection/enqueue":
			mu.Lock()
			defer mu.Unlock()
			return map[string]any{"count": 2, "items": itemsLocked(), "selected_ids": []string{}}, nil
		case "library/batchStatus":
			mu.Lock()
			defer mu.Unlock()
			// STICKY built — the post-MY-LIBRARY reality the old code choked on.
			return map[string]any{"items": itemsLocked(), "downloading": 0, "done": 1, "failed": 0, "total": 2, "build_status": "built"}, nil
		case "library/download/item":
			id, _ := c.Args["book_id"].(string)
			mu.Lock()
			if status[id] == "queued" {
				status[id] = "done" // simulate an instant successful download
			}
			mu.Unlock()
			return map[string]any{"started": true, "book_id": id}, nil
		}
		return map[string]any{"_items": []any{}}, nil
	})

	watchConsole(t, page)

	fileURL := "file://" + filepath.Join(dir, "BROWSE_LIBRARY.html") + "#/?t=l"
	if err := page.Navigate(fileURL); err != nil {
		t.Fatalf("navigate: %v", err)
	}

	page.Timeout(15 * time.Second).MustWait(`() => !!document.body && document.body.innerText.includes('[QUEUE]')`)

	// Enter QUEUE.
	page.MustEval(`() => {
		const b = [...document.querySelectorAll('nav button')].find(x => x.textContent.includes('[QUEUE]'));
		if (!b) throw new Error("no QUEUE tab");
		b.click();
	}`)

	// QUEUE shows b1 done + b2 [download].
	page.Timeout(8 * time.Second).MustWait(`() => {
		const spans = [...document.querySelectorAll('table tbody span')];
		const dl = spans.filter(e => e.textContent.trim() === '[download]').length;
		const done = spans.filter(e => e.textContent.trim() === 'done').length;
		return dl === 1 && done === 1;
	}`)

	// Wait past the first 2s poll tick — the window in which the old code stopped
	// the poll on build_status=="built".
	time.Sleep(2600 * time.Millisecond)

	// Click the remaining [download] (book b2).
	page.MustEval(`() => {
		const s = [...document.querySelectorAll('table tbody span')].find(e => e.textContent.trim() === '[download]');
		if (!s) throw new Error("no [download] to click");
		s.click();
	}`)

	// The poll must still be alive to flip b2's row to "done". Old code: frozen at
	// [download] forever → this times out.
	page.Timeout(8 * time.Second).MustWait(`() => {
		const spans = [...document.querySelectorAll('table tbody span')];
		return spans.filter(e => e.textContent.trim() === 'done').length === 2
			&& spans.filter(e => e.textContent.trim() === '[download]').length === 0;
	}`)

	t.Logf("OK: QUEUE poll survives sticky build_status:built — second [download] reaches done")
}
