//go:build integration && calibre_e2e

package browselocal

import (
	"accorder/pkg/calibre"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"testing"
)

// TestLibBuild_AppendRemoveReadd exercises the simplest real maintenance action
// with REAL calibredb + `lib build --append`:
//
//	add A,B,C → full index → remove C (calibredb) → --append (tombstone hides C)
//	                       → add C back (calibredb, NEW uuid) → --append (C reappears)
//
// The re-added book is a fresh Calibre book (new uuid / new index _id), so the old
// one stays harmlessly tombstoned while the new one is live — which is exactly how
// remove-then-re-add works in practice. Asserts the live book set at the .zst level
// (AllBooksFromIndex honors tombstones), and that A,B are untouched throughout.
//
// Run: go test -tags 'integration calibre_e2e' -run TestLibBuild_AppendRemoveReadd ./pkg/browselocal/
func TestLibBuild_AppendRemoveReadd(t *testing.T) {
	if _, err := exec.LookPath("calibredb"); err != nil {
		t.Skip("calibredb not on PATH — skipping append remove/re-add test")
	}
	bin := buildAccorderBinary(t)
	env := append(os.Environ(), "XDG_CONFIG_HOME="+t.TempDir())
	lib := filepath.Join(t.TempDir(), "lib")
	const libID = "aaaaaaaa-0000-4000-8000-000000000001"
	indexPath := filepath.Join(lib, "static", "library_index")
	jsonlPath := lib + ".jsonl"

	addBookIDRe := regexp.MustCompile(`Added book ids:\s*(\d+)`)
	// add returns the calibredb book id (so we can remove it later).
	add := func(title string) string {
		t.Helper()
		f := filepath.Join(t.TempDir(), title+".txt")
		if err := os.WriteFile(f, []byte("body of "+title), 0o644); err != nil {
			t.Fatal(err)
		}
		out, err := exec.Command("calibredb", "add", f, "--library-path", lib).CombinedOutput()
		if err != nil {
			t.Fatalf("calibredb add %s: %v\n%s", title, err, out)
		}
		m := addBookIDRe.FindSubmatch(out)
		if m == nil {
			t.Fatalf("calibredb add %s: no book id in output:\n%s", title, out)
		}
		return string(m[1])
	}
	calibredb := func(args ...string) {
		t.Helper()
		out, err := exec.Command("calibredb", append(args, "--library-path", lib)...).CombinedOutput()
		if err != nil {
			t.Fatalf("calibredb %v: %v\n%s", args, err, out)
		}
	}
	runAcc := func(args ...string) {
		t.Helper()
		cmd := exec.Command(bin, args...)
		cmd.Env = env
		if out, err := cmd.CombinedOutput(); err != nil {
			t.Fatalf("accorder %v: %v\n%s", args, err, out)
		}
	}
	// build re-exports the catalog from calibredb, then (re)builds the index.
	build := func(appendMode bool) {
		t.Helper()
		runAcc("lib", "build", "--calibrepath", lib, "--librarian", "tester", "--libraryID", libID,
			"--jsonl-export", "--jsonl-path", jsonlPath)
		args := []string{"lib", "build", "--calibrepath", lib, "--librarian", "tester", "--libraryID", libID,
			"--index", "--index-path", indexPath, "--jsonl-path", jsonlPath}
		if appendMode {
			args = append(args, "--append")
		}
		runAcc(args...)
	}
	liveTitles := func() map[string]bool {
		t.Helper()
		books, err := calibre.AllBooksFromIndex(indexPath)
		if err != nil {
			t.Fatalf("AllBooksFromIndex: %v", err)
		}
		m := map[string]bool{}
		for _, b := range books {
			m[b.Title] = true
		}
		return m
	}

	// --- A,B,C → full index ---
	add("Alpha")
	add("Beta")
	idGamma := add("Gamma")
	build(false)
	if g := liveTitles(); !(g["Alpha"] && g["Beta"] && g["Gamma"]) {
		t.Fatalf("full build missing books: %v", g)
	}
	t.Log("OK: full index has Alpha, Beta, Gamma")

	// --- remove Gamma → --append (tombstone hides it; A,B intact) ---
	calibredb("remove", idGamma)
	build(true)
	if g := liveTitles(); g["Gamma"] {
		t.Fatalf("removed book still live after --append (tombstone not applied): %v", g)
	} else if !(g["Alpha"] && g["Beta"]) {
		t.Fatalf("--append removal lost other books: %v", g)
	}
	t.Log("OK: removed book is gone after --append; Alpha, Beta intact")

	// --- add Gamma back as a NEW book (new uuid) → --append (it reappears) ---
	add("Gamma")
	build(true)
	if g := liveTitles(); !(g["Alpha"] && g["Beta"] && g["Gamma"]) {
		t.Fatalf("re-added (new-uuid) book or others missing after --append: %v", g)
	}
	t.Log("OK: re-added book (new uuid) is live again; everything else working")
}
