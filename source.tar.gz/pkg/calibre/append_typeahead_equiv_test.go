package calibre

import (
	"fmt"
	"path/filepath"
	"strings"
	"testing"
)

func normalizeSuggestions(s []Suggestion) map[string]uint64 {
	m := make(map[string]uint64, len(s))
	for _, x := range s {
		m[string(x.Field)+"|"+x.Term+"|"+x.Entity] = x.Weight
	}
	return m
}

func equivBook(id, title, author, tag string) *Book {
	return &Book{Id: id, UUID: "u-" + id, Title: title, Authors: []string{author}, Tags: []string{tag},
		LastModified: "2024-02-01T00:00:00+00:00", LibraryUUID: "L"}
}

func buildAppendedIndex(t *testing.T, dir string, base, delta []*Book) string {
	t.Helper()
	gen := [16]byte{0x5a, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16}
	idxPath := filepath.Join(dir, "appended")
	baseJSONL := filepath.Join(dir, "base.jsonl")
	writeBooks(t, baseJSONL, base)
	ms := &MotwSearch{JsonlPath: baseJSONL, IndexPath: idxPath, BaseGeneration: &gen}
	bidx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(bidx); err != nil {
		t.Fatal(err)
	}
	deltaJSONL := filepath.Join(dir, "delta.jsonl")
	writeBooks(t, deltaJSONL, delta)
	dms := &MotwSearch{JsonlPath: deltaJSONL, IndexPath: idxPath, BaseGeneration: &gen}
	didx, err := dms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := dms.AppendToFile(didx, nil); err != nil {
		t.Fatal(err)
	}
	return idxPath
}

func buildFullIndex(t *testing.T, dir string, books []*Book) string {
	t.Helper()
	gen := [16]byte{0x5a, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16}
	idxPath := filepath.Join(dir, "full")
	jsonl := filepath.Join(dir, "full.jsonl")
	writeBooks(t, jsonl, books)
	ms := &MotwSearch{JsonlPath: jsonl, IndexPath: idxPath, BaseGeneration: &gen}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}
	return idxPath
}

func suggestMap(t *testing.T, idxPath string, field SearchField, prefix string) map[string]uint64 {
	t.Helper()
	ms := &MotwSearch{IndexPath: idxPath}
	ta, err := ms.LoadTypeaheadCached(t.TempDir())
	if err != nil {
		t.Fatalf("LoadTypeaheadCached(%s): %v", idxPath, err)
	}
	defer ta.Close()
	s, err := ta.Suggest(field, prefix, 0)
	if err != nil {
		t.Fatal(err)
	}
	return normalizeSuggestions(s)
}

func fuzzyMap(t *testing.T, idxPath string, field SearchField, tok string, d uint8) map[string]uint64 {
	t.Helper()
	ms := &MotwSearch{IndexPath: idxPath}
	ta, err := ms.LoadTypeaheadCached(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	defer ta.Close()
	s, err := ta.SuggestFuzzy(field, tok, d, 0)
	if err != nil {
		t.Fatal(err)
	}
	return normalizeSuggestions(s)
}

func mapsEqual(a, b map[string]uint64) (string, bool) {
	if len(a) != len(b) {
		return fmt.Sprintf("count %d vs %d", len(a), len(b)), false
	}
	for k, av := range a {
		if bv, ok := b[k]; !ok || bv != av {
			return fmt.Sprintf("key %q: %d vs %d(ok=%v)", k, av, bv, ok), false
		}
	}
	return "", true
}

func TestAppendTypeaheadEquiv(t *testing.T) {

	var base, delta []*Book
	for i := 0; i < 40; i++ {
		base = append(base, equivBook(fmt.Sprintf("b%d", i), fmt.Sprintf("Book %d", i), "Karl Marx", "marxism"))
	}
	base = append(base, equivBook("bk", "Kritik", "Karl Kautsky", "theory"))
	for i := 0; i < 20; i++ {
		delta = append(delta, equivBook(fmt.Sprintf("d%d", i), fmt.Sprintf("New %d", i), "Karl Marx", "marxism"))
	}
	delta = append(delta, equivBook("dp", "Logik", "Karl Popper", "philosophy"))

	all := append(append([]*Book{}, base...), delta...)

	dirA := t.TempDir()
	appended := buildAppendedIndex(t, dirA, base, delta)
	dirF := t.TempDir()
	full := buildFullIndex(t, dirF, all)

	cases := []struct {
		field  SearchField
		prefix string
	}{
		{FieldAuthor, "ka"}, {FieldAuthor, "marx"}, {FieldAuthor, "popp"},
		{FieldTag, "marx"}, {FieldTag, "phil"}, {FieldAuthor, "zzz"},
	}
	for _, tc := range cases {
		got := suggestMap(t, appended, tc.field, tc.prefix)
		want := suggestMap(t, full, tc.field, tc.prefix)
		if diff, ok := mapsEqual(got, want); !ok {
			t.Fatalf("Suggest %s/%q: appended != full: %s", tc.field, tc.prefix, diff)
		}
	}

	if w := suggestMap(t, appended, FieldAuthor, "marx")["author|marx|Karl Marx"]; w != 60 {
		t.Fatalf("Karl Marx DF = %d, want 60 (40 base + 20 delta)", w)
	}

	if diff, ok := mapsEqual(fuzzyMap(t, appended, FieldAuthor, "karl", 1), fuzzyMap(t, full, FieldAuthor, "karl", 1)); !ok {
		t.Fatalf("SuggestFuzzy appended != full: %s", diff)
	}
}

func TestAppendTypeaheadEquiv_RedCheck(t *testing.T) {
	dir := t.TempDir()
	appended := buildAppendedIndex(t, dir,
		[]*Book{equivBook("b0", "A", "Karl Marx", "t")},
		[]*Book{equivBook("d0", "B", "Karl Popper", "t")})

	got := suggestMap(t, appended, FieldAuthor, "popp")
	found := false
	for k := range got {
		if strings.HasSuffix(k, "|Karl Popper") {
			found = true
		}
	}
	if !found {
		t.Fatalf("delta-only entity 'Karl Popper' missing from appended index — per-region typeahead not queried; got keys %v", got)
	}
}
