package calibre

import (
	"fmt"
	"os/exec"
	"strings"
	"testing"
)

// ═══════════════════════════════════════════════════════════════════
// fakeCalibre — a CalibreExe driver that needs no Calibre installed.
//
// CalibreExe.CalibreCLI (calibreExec.go:20) is consulted by both call paths
// — RunWithArgs (:288) and calibredbCapturingStderr (:313) — so every
// calibredb invocation the sync engine makes can be answered here.
//
// Validated by the Phase 0 spike (workflow 2026-08-24_zotero-import-sync-coverage,
// commit 714ecdc): one closure serves a multi-call sequence, dispatching on
// cmd.Args.
//
// Two things this records that ImportStats alone cannot: WHICH calibredb
// subcommands the engine chose to run, and in what order. For a convergence
// engine that is the behavior under test — "no set_metadata was issued" is
// the assertion, not "the counter said unchanged".
//
// CAUTION (study F10): only Add/AddBatch go through calibredbCapturingStderr,
// whose cmd.Stderr is an io.MultiWriter the production code later inspects.
// RunWithArgs sets cmd.Stderr to a plain os.Stderr. So writing to cmd.Stderr
// influences behavior ONLY on the add path; every other handler signals
// failure by returning an error.
// ═══════════════════════════════════════════════════════════════════

// calibreCall is one recorded invocation.
type calibreCall struct {
	Sub  string
	Args []string
}

// handler answers one calibredb subcommand. nth is 0 for the first call to
// that subcommand, 1 for the second, and so on — the sync engine lists more
// than once (buildTrackedMap, then findBookIDByTitle or StampDefaultCovers),
// and the answers differ.
type handler func(cmd *exec.Cmd, nth int) ([]byte, error)

type fakeCalibre struct {
	t        *testing.T
	handlers map[string]handler
	calls    []calibreCall
}

func newFakeCalibre(t *testing.T) *fakeCalibre {
	t.Helper()
	return &fakeCalibre{t: t, handlers: map[string]handler{}}
}

// on registers a dynamic handler for a subcommand.
func (f *fakeCalibre) on(sub string, h handler) *fakeCalibre {
	f.handlers[sub] = h
	return f
}

// reply registers a fixed response for a subcommand.
func (f *fakeCalibre) reply(sub, out string) *fakeCalibre {
	return f.on(sub, func(*exec.Cmd, int) ([]byte, error) { return []byte(out), nil })
}

// replySeq registers responses consumed one per call, in order. The last entry
// answers any further calls.
func (f *fakeCalibre) replySeq(sub string, outs ...string) *fakeCalibre {
	return f.on(sub, func(_ *exec.Cmd, nth int) ([]byte, error) {
		if nth >= len(outs) {
			nth = len(outs) - 1
		}
		return []byte(outs[nth]), nil
	})
}

// exe returns a CalibreExe wired to this fake.
func (f *fakeCalibre) exe() *CalibreExe {
	return &CalibreExe{
		LibraryPath: "/fake/library",
		CalibreCLI: func(cmd *exec.Cmd) ([]byte, error) {
			sub := findSubcommand(cmd.Args)
			nth := f.count(sub)
			f.calls = append(f.calls, calibreCall{Sub: sub, Args: append([]string(nil), cmd.Args...)})

			h, ok := f.handlers[sub]
			if !ok {
				f.t.Errorf("fakeCalibre: unhandled subcommand %q (args: %v)", sub, cmd.Args)
				return nil, fmt.Errorf("unhandled subcommand %q", sub)
			}
			return h(cmd, nth)
		},
	}
}

// subs returns the subcommand sequence in call order.
func (f *fakeCalibre) subs() []string {
	out := make([]string, 0, len(f.calls))
	for _, c := range f.calls {
		out = append(out, c.Sub)
	}
	return out
}

// count reports how many times a subcommand was invoked.
func (f *fakeCalibre) count(sub string) int {
	n := 0
	for _, c := range f.calls {
		if c.Sub == sub {
			n++
		}
	}
	return n
}

// argsOf returns the recorded argv of the nth call to a subcommand.
func (f *fakeCalibre) argsOf(sub string, nth int) []string {
	seen := 0
	for _, c := range f.calls {
		if c.Sub != sub {
			continue
		}
		if seen == nth {
			return c.Args
		}
		seen++
	}
	f.t.Fatalf("fakeCalibre: no call %d to %q; recorded %v", nth, sub, f.subs())
	return nil
}

// flagValue extracts the value following `-f <name>:` in a recorded set_metadata
// argv — calibredb takes metadata fields as `-f key:value` pairs
// (calibreExec.go:249-256).
func flagValue(args []string, field string) (string, bool) {
	for i := 0; i < len(args)-1; i++ {
		if args[i] != "-f" {
			continue
		}
		if v, ok := strings.CutPrefix(args[i+1], field+":"); ok {
			return v, true
		}
	}
	return "", false
}

// assertSubs fails unless the recorded call sequence matches exactly.
func (f *fakeCalibre) assertSubs(want ...string) {
	f.t.Helper()
	got := f.subs()
	if len(got) != len(want) {
		f.t.Fatalf("calibredb call sequence = %v, want %v", got, want)
	}
	for i := range want {
		if got[i] != want[i] {
			f.t.Fatalf("calibredb call sequence = %v, want %v", got, want)
		}
	}
}

// findSubcommand extracts the calibredb subcommand from cmd.Args, skipping the
// binary name and any --library-path flag. Stable because both production
// constructors shape Args as [calibredb, --library-path=..., <sub>, ...]
// (calibreExec.go:25-30, :303-308).
func findSubcommand(args []string) string {
	for _, a := range args[1:] { // skip args[0], the binary
		if strings.HasPrefix(a, "--") {
			continue
		}
		return a
	}
	return "unknown"
}
