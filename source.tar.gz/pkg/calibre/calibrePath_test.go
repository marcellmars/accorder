package calibre

import (
	"os"
	"path/filepath"
	"runtime"
	"slices"
	"testing"
)

func TestCalibreInstallDirsFor(t *testing.T) {
	mac := calibreInstallDirsFor("darwin", "/Users/foo")
	if len(mac) == 0 || mac[0] != "/Applications/calibre.app/Contents/MacOS" {
		t.Fatalf("darwin: want system bundle path first, got %v", mac)
	}
	if !slices.Contains(mac, "/Users/foo/Applications/calibre.app/Contents/MacOS") {
		t.Fatalf("darwin: want per-user bundle path, got %v", mac)
	}
	if win := calibreInstallDirsFor("windows", ""); win[0] != `C:\Program Files\Calibre2` {
		t.Fatalf("windows: want Calibre2 default first, got %v", win)
	}
	if lin := calibreInstallDirsFor("linux", "/home/x"); len(lin) == 0 {
		t.Fatalf("linux: want fallback dirs, got %v", lin)
	}
}

func TestFindCalibreTool_EnvOverrideBeatsPath(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("fixture relies on the unix executable bit")
	}
	dir := t.TempDir()
	fake := filepath.Join(dir, "calibredb")
	if err := os.WriteFile(fake, []byte("#!/bin/sh\n"), 0o755); err != nil {
		t.Fatal(err)
	}
	t.Setenv(calibreBinDirEnv, dir)
	got, ok := findCalibreTool("calibredb")
	if !ok || got != fake {
		t.Fatalf("env override: got (%q, %v), want (%q, true)", got, ok, fake)
	}
}

func TestCalibreToolPath_FallbackBareName(t *testing.T) {
	t.Setenv(calibreBinDirEnv, "")
	const bogus = "definitely-not-a-real-calibre-tool-xyz"
	if got := calibreToolPath(bogus); got != bogus {
		t.Fatalf("fallback: got %q, want bare name %q", got, bogus)
	}
}
