package calibre

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// TestWriteBrowseDataJS_CarriesFingerprint guards the washed-out-mosaic fix:
// data*.js must carry each book's CoverFingerprint so the browse grid paints
// the bright cover mosaic instead of the muted JS fallback.
func TestWriteBrowseDataJS_CarriesFingerprint(t *testing.T) {
	dir := t.TempDir()
	static := filepath.Join(dir, "static")
	if err := os.MkdirAll(static, 0o755); err != nil {
		t.Fatal(err)
	}
	books := []*Book{
		{Id: "b1", Title: "With Cover", CoverFingerprint: "2rZtk3QJ"},
		{Id: "b2", Title: "No Cover"},
	}
	WriteBrowseDataJS(static, books)

	data1, err := os.ReadFile(filepath.Join(static, "data1.js"))
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(string(data1), `"cover_fingerprint":"2rZtk3QJ"`) {
		t.Fatalf("data1.js must carry the cover_fingerprint; got:\n%s", data1)
	}
}
