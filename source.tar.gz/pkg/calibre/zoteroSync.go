package calibre

import (
	"context"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"slices"
	"strings"

	"github.com/tidwall/gjson"
)

// Calibre identifier schemes used to track Zotero-imported books.
const (
	idZotero       = "zotero"        // value: Zotero item key (stable identity)
	idZoteroRev    = "zotero_rev"    // value: "<effMtime>+<fileHash>" (change detection)
	idZoteroSrc    = "zotero_src"    // value: action alias (prune scope)
	idZoteroExport = "zotero_export" // value: BBT export config id (prune scope)
)

type trackedBook struct {
	bookID  int
	title   string
	rev     string
	src     string
	export  string
	formats []string
}

func extractExts(formats []gjson.Result) []string {
	exts := make([]string, 0, len(formats))
	for _, f := range formats {
		if ext := strings.ToLower(filepath.Ext(f.String())); ext != "" {
			exts = append(exts, ext)
		}
	}
	return sortedUnique(exts)
}

func buildTrackedMap(ctx context.Context, exe *CalibreExe) (map[string]trackedBook, error) {
	out, err := exe.ListWithFilter(ctx, "identifiers:"+idZotero+":", "id,title,identifiers,formats")
	if err != nil {
		return nil, fmt.Errorf("list tracked books: %w", err)
	}

	tracked := make(map[string]trackedBook)
	gjson.ParseBytes(out).ForEach(func(_, row gjson.Result) bool {
		itemKey := row.Get("identifiers." + idZotero).String()
		if itemKey == "" {
			return true
		}
		tracked[itemKey] = trackedBook{
			bookID:  int(row.Get("id").Int()),
			title:   row.Get("title").String(),
			rev:     row.Get("identifiers." + idZoteroRev).String(),
			src:     row.Get("identifiers." + idZoteroSrc).String(),
			export:  row.Get("identifiers." + idZoteroExport).String(),
			formats: extractExts(row.Get("formats").Array()),
		}
		return true
	})
	return tracked, nil
}

func PreflightCalibre(ctx context.Context, confirm func(string) bool) error {
	calibrePath, ok := findCalibreTool("calibre")
	if !ok {
		return nil
	}

	if !confirm("Calibre may be running and holds the library lock. Shut it down and continue?") {
		return fmt.Errorf("aborted: user declined to shut down Calibre")
	}

	cmd := exec.CommandContext(ctx, calibrePath, "-s")
	if err := cmd.Run(); err != nil {
		fmt.Printf("Note: calibre -s exited with: %v (Calibre may not be running)\n", err)
	}
	return nil
}

type syncAction int

const (
	actionAdd syncAction = iota
	actionUpdate
	actionUnchanged
)

// classify decides what to do with an entry. It computes the entry's revision
// (which reads attachment files) only when the cheap mtime+format gate doesn't
// already settle it — so a no-change re-import touches no files. The returned
// rev is non-empty only for actionUpdate.
func classify(entry ImportEntry, existing trackedBook, found bool) (syncAction, string) {
	if !found {
		return actionAdd, ""
	}
	if entry.EffMtime == revMtime(existing.rev) && slices.Equal(entry.Exts(), existing.formats) {
		return actionUnchanged, ""
	}
	rev := entry.Rev()
	if rev == existing.rev {
		return actionUnchanged, ""
	}
	return actionUpdate, rev
}

// revMtime / revHash split a "<effMtime>+<fileHash>" revision string.
func revMtime(rev string) string { m, _, _ := strings.Cut(rev, "+"); return m }
func revHash(rev string) string  { _, h, _ := strings.Cut(rev, "+"); return h }

func SyncEntries(ctx context.Context, exe *CalibreExe, entries []ImportEntry, bundle Bundle, prune bool, confirm func(string) bool) (ImportStats, error) {
	stats := ImportStats{Total: len(entries)}

	tracked, err := buildTrackedMap(ctx, exe)
	if err != nil {
		return stats, err
	}

	for i, entry := range entries {
		existing, found := tracked[entry.ItemKey]
		prefix := fmt.Sprintf("%d/%d", i+1, len(entries))

		switch action, rev := classify(entry, existing, found); action {
		case actionAdd:
			if err := addEntry(ctx, exe, entry, bundle, prefix); err != nil {
				return stats, fmt.Errorf("add %s: %w", entry.ItemKey, err)
			}
			stats.Added++
		case actionUpdate:
			if err := updateEntry(ctx, exe, entry, bundle, existing, rev, prefix); err != nil {
				return stats, fmt.Errorf("update %s: %w", entry.ItemKey, err)
			}
			stats.Updated++
		case actionUnchanged:
			fmt.Printf("%s UNCHANGED: %s\n", prefix, entry.Title)
			stats.Unchanged++
		}
	}

	if prune {
		removed, err := pruneEntries(ctx, exe, entries, tracked, bundle, confirm)
		if err != nil {
			return stats, fmt.Errorf("prune: %w", err)
		}
		stats.Removed = removed
	} else {
		stats.Orphaned = len(pruneCandidates(entries, tracked, bundle))
	}

	return stats, nil
}

func addEntry(ctx context.Context, exe *CalibreExe, entry ImportEntry, bundle Bundle, prefix string) error {
	fmt.Printf("%s ADD: %s by %s\n", prefix, entry.Title, strings.Join(entry.Authors, ", "))

	bookID, err := exe.Add(ctx, entry.Title, entry.Files[0].AbsPath)
	if err != nil {
		if strings.Contains(err.Error(), "duplicate detected") {
			fmt.Printf("  skipped: %q already exists in this Calibre library (by file content)\n", entry.Title)
			return nil
		}
		return err
	}

	if err := setEntryMetadata(ctx, exe, bookID, entry, bundle, entry.Rev()); err != nil {
		return err
	}

	for _, f := range entry.Files[1:] {
		if err := exe.AddFormat(ctx, bookID, f.AbsPath); err != nil {
			return fmt.Errorf("add_format %s: %w", f.AbsPath, err)
		}
	}

	return nil
}

// updateEntry updates an existing book's metadata and, when the attachment files
// actually changed, re-syncs its formats. rev is the already-computed revision
// string; when its hash part matches what's stored, only metadata moved and the
// (potentially large) format files are left in place.
func updateEntry(ctx context.Context, exe *CalibreExe, entry ImportEntry, bundle Bundle, existing trackedBook, rev, prefix string) error {
	filesChanged := revHash(rev) != revHash(existing.rev)
	if filesChanged {
		fmt.Printf("%s UPDATE: %s\n", prefix, entry.Title)
	} else {
		fmt.Printf("%s UPDATE (metadata only): %s\n", prefix, entry.Title)
	}

	if err := setEntryMetadata(ctx, exe, existing.bookID, entry, bundle, rev); err != nil {
		return err
	}
	if !filesChanged {
		return nil
	}

	vanished := make(map[string]bool)
	for _, ext := range existing.formats {
		vanished[ext] = true
	}
	for _, f := range entry.Files {
		if err := exe.AddFormat(ctx, existing.bookID, f.AbsPath); err != nil {
			return fmt.Errorf("add_format %s: %w", f.AbsPath, err)
		}
		delete(vanished, f.Ext)
	}
	for ext := range vanished {
		if err := exe.RemoveFormat(ctx, existing.bookID, strings.ToUpper(strings.TrimPrefix(ext, "."))); err != nil {
			fmt.Printf("  Warning: remove_format %s failed: %v\n", ext, err)
		}
	}

	return nil
}

func setEntryMetadata(ctx context.Context, exe *CalibreExe, bookID int, entry ImportEntry, bundle Bundle, rev string) error {
	idParts := []string{
		idZotero + ":" + entry.ItemKey,
		idZoteroRev + ":" + rev,
		idZoteroSrc + ":" + bundle.Alias,
	}
	if bundle.ExportID != "" {
		idParts = append(idParts, idZoteroExport+":"+bundle.ExportID)
	}
	for k, v := range entry.Identifiers {
		idParts = append(idParts, k+":"+v)
	}

	fields := map[string]string{
		"authors":     strings.Join(entry.Authors, " & "),
		"author_sort": entry.AuthorSort,
		"identifiers": strings.Join(idParts, ","),
	}
	for k, v := range map[string]string{
		"tags":         strings.Join(entry.Tags, ","),
		"languages":    entry.Language,
		"comments":     entry.Comments,
		"publisher":    entry.Publisher,
		"series":       entry.Series,
		"series_index": entry.SeriesIndex,
		"pubdate":      entry.PubDate,
	} {
		if v != "" {
			fields[k] = v
		}
	}

	return exe.SetMetadata(ctx, bookID, fields)
}

// pruneCandidates returns tracked books imported under this bundle (same alias,
// and same export id when both sides carry one) that are absent from the current
// export — i.e. exactly what `--prune` would offer to remove.
func pruneCandidates(entries []ImportEntry, tracked map[string]trackedBook, bundle Bundle) []trackedBook {
	currentKeys := make(map[string]bool, len(entries))
	for _, e := range entries {
		currentKeys[e.ItemKey] = true
	}
	var candidates []trackedBook
	for itemKey, tb := range tracked {
		if tb.src != bundle.Alias {
			continue
		}
		if bundle.ExportID != "" && tb.export != "" && tb.export != bundle.ExportID {
			continue
		}
		if currentKeys[itemKey] {
			continue
		}
		candidates = append(candidates, tb)
	}
	return candidates
}

func pruneEntries(ctx context.Context, exe *CalibreExe, entries []ImportEntry, tracked map[string]trackedBook, bundle Bundle, confirm func(string) bool) (int, error) {
	candidates := pruneCandidates(entries, tracked, bundle)
	if len(candidates) == 0 {
		return 0, nil
	}

	fmt.Printf("\nPrune candidates (%d books imported by alias %q no longer in export):\n", len(candidates), bundle.Alias)
	for _, c := range candidates {
		fmt.Printf("  - [%d] %s\n", c.bookID, c.title)
	}

	if !confirm(fmt.Sprintf("Remove %d book(s)?", len(candidates))) {
		fmt.Println("Prune skipped.")
		return 0, nil
	}

	removed := 0
	for _, c := range candidates {
		if err := exe.Remove(ctx, c.bookID); err != nil {
			return removed, fmt.Errorf("remove book %d: %w", c.bookID, err)
		}
		fmt.Printf("  REMOVED: [%d] %s\n", c.bookID, c.title)
		removed++
	}
	return removed, nil
}

func StampDefaultCovers(ctx context.Context, exe *CalibreExe) error {
	out, err := exe.ListWithFilter(ctx, "", "id,cover")
	if err != nil {
		return fmt.Errorf("list covers: %w", err)
	}

	var coverless []int
	gjson.ParseBytes(out).ForEach(func(_, row gjson.Result) bool {
		if row.Get("cover").String() == "" {
			coverless = append(coverless, int(row.Get("id").Int()))
		}
		return true
	})
	if len(coverless) == 0 {
		return nil
	}

	coverData := DefaultCoverJPEG()
	if coverData == nil {
		return nil
	}
	tmpFile, err := writeTempCover(coverData)
	if err != nil {
		return err
	}
	defer func() {
		_ = tmpFile.Close()
		_ = os.Remove(tmpFile.Name())
	}()

	for _, id := range coverless {
		if err := exe.SetMetadata(ctx, id, map[string]string{"cover": tmpFile.Name()}); err != nil {
			fmt.Printf("Warning: failed to set cover for book %d: %v\n", id, err)
		}
	}

	return nil
}
