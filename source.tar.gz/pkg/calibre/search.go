package calibre

import (
	"bufio"
	"bytes"
	"container/heap"
	"context"
	"crypto/rand"
	"encoding/binary"
	"errors"
	"fmt"
	"html"
	"io"
	"math"
	"os"
	"path/filepath"
	"regexp"
	"runtime"
	"slices"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
	"unicode"

	"github.com/RoaringBitmap/roaring/v2"
	mmap "github.com/blevesearch/mmap-go"
	"github.com/blevesearch/vellum/levenshtein"
	"github.com/cespare/xxhash/v2"
	"github.com/goccy/go-json"
	"github.com/google/uuid"
	"github.com/klauspost/compress/zstd"
	"github.com/kljensen/snowball"
	"golang.org/x/text/runes"
	"golang.org/x/text/transform"
	"golang.org/x/text/unicode/norm"
)

const (
	containerMagic          = "MWSC"
	containerVersion        = byte(2)
	containerVersionV1      = byte(1)
	CurrentContainerVersion = containerVersion
	containerHdrSize        = 13
	manifestMagic           = uint32(0x4D465354)

	manifestFormatTag = uint32(6)
	manifestFooter    = 8

	defaultChunkSize = 256 << 10

	skippableFrameMagic    = uint32(0x184D2A50)
	seekableTag            = uint32(0xE)
	seekableMagicNumber    = uint32(0x8F92EAB1)
	seekTableFooterSize    = 9
	seekTableEntrySize8    = 8
	seekTableEntrySizeCksm = 12
)

type SearchField string

const (
	FieldTitle    SearchField = "title"
	FieldAuthor   SearchField = "author"
	FieldTag      SearchField = "tag"
	FieldAbstract SearchField = "abstract"

	FieldAll SearchField = "all"

	FieldID          SearchField = "_id"
	FieldLibraryUUID SearchField = "library_uuid"
)

type QueryMode int

const (
	ModeExact QueryMode = iota
	ModePrefix
	ModeFuzzy
)

type SortMode int

const (
	SortDefault SortMode = iota
	SortRelevance
	SortNewest
	SortOldest
	SortNone
)

func (s SortMode) String() string {
	switch s {
	case SortDefault:
		return "default"
	case SortRelevance:
		return "relevance"
	case SortNewest:
		return "newest"
	case SortOldest:
		return "oldest"
	case SortNone:
		return "none"
	default:
		return fmt.Sprintf("SortMode(%d)", int(s))
	}
}

func ParseSortMode(s string) (SortMode, error) {
	switch strings.ToLower(strings.TrimSpace(s)) {
	case "relevance":
		return SortRelevance, nil
	case "newest":
		return SortNewest, nil
	case "oldest":
		return SortOldest, nil
	case "none":
		return SortNone, nil
	case "":
		return SortDefault, nil
	default:
		return SortDefault, fmt.Errorf("unknown sort mode %q (valid: relevance, newest, oldest, none)", s)
	}
}

func ParseSearchField(s string) (SearchField, error) {
	sf := SearchField(strings.ToLower(strings.TrimSpace(s)))
	switch sf {
	case FieldTitle, FieldAuthor, FieldTag, FieldAbstract:
		return sf, nil
	case "description":
		return FieldAbstract, nil
	case FieldAll:
		return FieldAll, nil
	default:
		return "", fmt.Errorf("unknown search field %q (valid: title, author, tag, abstract, description, all)", s)
	}
}

type SearchQuery struct {
	Field         SearchField
	Text          string
	Mode          QueryMode
	FuzzyDistance int
}

type SearchOptions struct {
	Limit    int
	Offset   int
	SortMode SortMode
}

func (o SearchOptions) ResolvedSortMode() SortMode {
	if o.SortMode != SortDefault {
		return o.SortMode
	}
	return SortOldest
}

type SearchStats struct {
	SegmentsTotal     int
	SegmentsCandidate int
	ClustersRead      int
	BooksScanned      int
	BooksMatched      int
	BytesDecompressed int64
	PostingsNarrowed  int
}

type MotwSearch struct {
	JsonlPath            string
	IndexPath            string
	ChunkSize            int
	BaseGeneration       *[16]byte
	IndexAggregateFields bool
	IndexDescription     bool
	StartGeneration      uint64
	DictID               uint32
}

type Suggestion struct {
	Term   string
	Field  SearchField
	Entity string
	Weight uint64
}

type TypeaheadIndex interface {
	Suggest(field SearchField, prefix string, limit int) ([]Suggestion, error)
	SuggestAny(prefix string, limit int) ([]Suggestion, error)
	SuggestFuzzy(field SearchField, token string, distance uint8, limit int) ([]Suggestion, error)
	Close() error
}

type vellumTypeaheadIndex struct {
	dicts []*sortedTermDict

	mm mmap.MMap
	f  *os.File
}

func SuggestEntities(ta TypeaheadIndex, field SearchField, prefix string, limit int) (entities []string, err error) {
	if ta == nil || limit <= 0 {
		return nil, nil
	}
	qToks := normalizeNoStem(prefix)
	if len(qToks) == 0 {
		return nil, nil
	}
	lastPrefix := qToks[len(qToks)-1]
	mustHave := qToks[:len(qToks)-1]

	anchor := lastPrefix
	for _, t := range mustHave {
		if len(t) > len(anchor) {
			anchor = t
		}
	}
	fetch := limit * 12
	if len(mustHave) > 0 {
		fetch = limit*100 + 2000
	}
	var suggs []Suggestion
	if field == "" {
		suggs, err = ta.SuggestAny(anchor, fetch)
	} else {
		suggs, err = ta.Suggest(field, anchor, fetch)
	}
	if err != nil {
		return nil, err
	}
	seen := make(map[string]bool, limit)
	for _, sg := range suggs {
		if sg.Entity == "" || seen[sg.Entity] {
			continue
		}
		if len(mustHave) > 0 && !entityMatchesQuery(sg.Entity, mustHave, lastPrefix) {
			continue
		}
		seen[sg.Entity] = true
		entities = append(entities, sg.Entity)
		if len(entities) >= limit {
			break
		}
	}
	if len(entities) >= limit {
		return entities, nil
	}
	dfas := buildQueryDFAs(qToks)
	if dfas == nil {
		return entities, nil
	}
	if len(suggs) > 0 {
		if len(mustHave) > 0 {
			for _, sg := range suggs {
				if sg.Entity == "" || seen[sg.Entity] {
					continue
				}
				if !entityMatchesQueryFuzzy(sg.Entity, mustHave, lastPrefix, dfas) {
					continue
				}
				seen[sg.Entity] = true
				entities = append(entities, sg.Entity)
				if len(entities) >= limit {
					break
				}
			}
		}
		if len(entities) > 0 {
			return entities, nil
		}

	}
	if len(anchor) < minFuzzTokenLen {
		return entities, nil
	}
	fsuggs, err := ta.SuggestFuzzy(field, anchor, 1, fetch)
	if err != nil {
		return nil, err
	}
	for _, sg := range fsuggs {
		if sg.Entity == "" || seen[sg.Entity] {
			continue
		}
		if !entityMatchesQueryFuzzy(sg.Entity, mustHave, lastPrefix, dfas) {
			continue
		}
		seen[sg.Entity] = true
		entities = append(entities, sg.Entity)
		if len(entities) >= limit {
			break
		}
	}
	return entities, nil
}

func entityMatchesQuery(entity string, mustHave []string, lastPrefix string) bool {
	have := make(map[string]struct{})
	prefixed := false
	for _, t := range normalizeNoStem(entity) {
		have[t] = struct{}{}
		if strings.HasPrefix(t, lastPrefix) {
			prefixed = true
		}
	}
	if !prefixed {
		return false
	}
	for _, m := range mustHave {
		if _, ok := have[m]; !ok {
			return false
		}
	}
	return true
}

const minFuzzTokenLen = 4

func buildQueryDFAs(tokens []string) map[string]*levenshtein.DFA {
	var dfas map[string]*levenshtein.DFA
	var lab *levenshtein.LevenshteinAutomatonBuilder
	for _, t := range tokens {
		if len(t) < minFuzzTokenLen {
			continue
		}
		if lab == nil {
			var err error
			if lab, err = levenshtein.NewLevenshteinAutomatonBuilder(1, true); err != nil {
				return nil
			}
			dfas = make(map[string]*levenshtein.DFA, len(tokens))
		}
		dfa, err := lab.BuildDfa(t, 1)
		if err != nil {
			continue
		}
		dfas[t] = dfa
	}
	return dfas
}

func entityMatchesQueryFuzzy(entity string, mustHave []string, lastPrefix string, dfas map[string]*levenshtein.DFA) bool {
	toks := normalizeNoStem(entity)
	have := make(map[string]struct{}, len(toks))
	prefixed := false
	for _, t := range toks {
		have[t] = struct{}{}
		if strings.HasPrefix(t, lastPrefix) {
			prefixed = true
		}
	}
	if !prefixed {
		if dfa := dfas[lastPrefix]; dfa == nil || !containsAnyFuzzy(toks, dfa) {
			return false
		}
	}
	for _, m := range mustHave {
		if _, ok := have[m]; ok {
			continue
		}
		if dfa := dfas[m]; dfa == nil || !containsAnyFuzzy(toks, dfa) {
			return false
		}
	}
	return true
}

func (v *vellumTypeaheadIndex) Suggest(field SearchField, prefix string, limit int) ([]Suggestion, error) {
	start, end := fieldPrefixRange(field, prefix)
	raw, err := v.collect(start, end, nil)
	if err != nil {
		return nil, err
	}
	return mergeSuggestions(raw, limit), nil
}

func (v *vellumTypeaheadIndex) SuggestAny(prefix string, limit int) ([]Suggestion, error) {
	var raw []Suggestion
	for _, f := range fieldsInOrder {
		start, end := fieldPrefixRange(f, prefix)
		part, err := v.collect(start, end, nil)
		if err != nil {
			return nil, err
		}
		raw = append(raw, part...)
	}
	return mergeSuggestions(raw, limit), nil
}

func (v *vellumTypeaheadIndex) SuggestFuzzy(field SearchField, token string, distance uint8, limit int) ([]Suggestion, error) {
	lab, err := levenshtein.NewLevenshteinAutomatonBuilder(distance, true)
	if err != nil {
		return nil, fmt.Errorf("TypeaheadIndex: levenshtein builder: %w", err)
	}
	dfa, err := lab.BuildDfa(token, distance)
	if err != nil {
		return nil, fmt.Errorf("TypeaheadIndex: build DFA: %w", err)
	}
	accept := func(term string) bool {
		match, _ := dfa.MatchAndDistance(term)
		return match
	}
	fields := []SearchField{field}
	if field == "" {
		fields = fieldsInOrder
	}
	var raw []Suggestion
	for _, f := range fields {
		start, end := fieldRange(f)
		part, err := v.collect(start, end, accept)
		if err != nil {
			return nil, err
		}
		raw = append(raw, part...)
	}
	return mergeSuggestions(raw, limit), nil
}

func (v *vellumTypeaheadIndex) collect(start, end []byte, accept func(term string) bool) ([]Suggestion, error) {
	var out []Suggestion
	for _, d := range v.dicts {
		out = append(out, iterateOneDict(d, start, end, accept)...)
	}
	return out, nil
}

func iterateOneDict(d *sortedTermDict, start, end []byte, accept func(term string) bool) []Suggestion {
	var suggestions []Suggestion
	d.rangeScan(start, end, func(key []byte, val uint64) {
		keyStr := string(key)
		if first := strings.IndexByte(keyStr, '\x00'); first >= 0 {
			field := keyStr[:first]
			rest := keyStr[first+1:]
			if e := strings.IndexByte(rest, '\x00'); e >= 0 {
				term := rest[:e]
				if accept == nil || accept(term) {
					suggestions = append(suggestions, Suggestion{
						Term:   term,
						Field:  SearchField(field),
						Entity: rest[e+1:],
						Weight: val,
					})
				}
			}
		}
	})
	return suggestions
}

func mergeSuggestions(raw []Suggestion, limit int) []Suggestion {
	type key struct {
		term   string
		field  SearchField
		entity string
	}
	sums := make(map[key]uint64, len(raw))
	order := make([]key, 0, len(raw))
	for _, s := range raw {
		k := key{s.Term, s.Field, s.Entity}
		if _, ok := sums[k]; !ok {
			order = append(order, k)
		}
		sums[k] += s.Weight
	}
	out := make([]Suggestion, 0, len(order))
	for _, k := range order {
		out = append(out, Suggestion{Term: k.term, Field: k.field, Entity: k.entity, Weight: sums[k]})
	}
	sort.Slice(out, func(i, j int) bool { return out[i].Weight > out[j].Weight })
	if limit > 0 && len(out) > limit {
		out = out[:limit]
	}
	return out
}

func (v *vellumTypeaheadIndex) Close() error {
	var err error
	if v.mm != nil {
		err = v.mm.Unmap()
		v.mm = nil
	}
	if v.f != nil {
		if cerr := v.f.Close(); err == nil {
			err = cerr
		}
		v.f = nil
	}
	return err
}

type indexData struct {
	Postings     []byte
	PostingsMeta []byte
	DocLengths   []byte
	FSTBytes     []byte
	EntityFST    []byte
	Fingerprints []byte
	NumSegments  uint32
	NumBooks     uint32

	Searchable []byte

	SearchSegLens []uint32

	Recency []RecencyEntry

	DisplaySegLens []uint32

	DisplaySamples [][]byte
}

type fieldTerm struct {
	field SearchField
	term  string
}

type segFieldKey struct {
	segment int
	field   SearchField
}

type ContainerHeader struct {
	DictSize uint64
}

type DictCatalogEntry struct {
	DictID    uint32
	DictBytes []byte
}

func writeDictCatalog(w io.Writer, entries []DictCatalogEntry) error {
	for _, e := range entries {
		if err := binary.Write(w, binary.LittleEndian, e.DictID); err != nil {
			return fmt.Errorf("writeDictCatalog: dictID: %w", err)
		}
		if err := binary.Write(w, binary.LittleEndian, uint64(len(e.DictBytes))); err != nil {
			return fmt.Errorf("writeDictCatalog: dictLen: %w", err)
		}
		if _, err := w.Write(e.DictBytes); err != nil {
			return fmt.Errorf("writeDictCatalog: dictBytes: %w", err)
		}
	}
	return nil
}

func readDictCatalog(r io.Reader, catalogSize uint64) ([]DictCatalogEntry, error) {
	var entries []DictCatalogEntry
	var bytesRead uint64
	for bytesRead < catalogSize {
		var e DictCatalogEntry
		if err := binary.Read(r, binary.LittleEndian, &e.DictID); err != nil {
			return nil, fmt.Errorf("readDictCatalog: dictID: %w", err)
		}
		var dictLen uint64
		if err := binary.Read(r, binary.LittleEndian, &dictLen); err != nil {
			return nil, fmt.Errorf("readDictCatalog: dictLen: %w", err)
		}
		remaining := catalogSize - bytesRead
		if remaining < 12 || dictLen > remaining-12 {
			return nil, fmt.Errorf("readDictCatalog: dictLen %d exceeds remaining catalog %d", dictLen, remaining)
		}
		e.DictBytes = make([]byte, dictLen)
		if _, err := io.ReadFull(r, e.DictBytes); err != nil {
			return nil, fmt.Errorf("readDictCatalog: dictBytes: %w", err)
		}
		entries = append(entries, e)
		bytesRead += 4 + 8 + dictLen
	}
	return entries, nil
}

func dictCatalogSize(entries []DictCatalogEntry) uint64 {
	var size uint64
	for _, e := range entries {
		size += 4 + 8 + uint64(len(e.DictBytes))
	}
	return size
}

type ManifestRegion struct {
	SearchIndexOff  uint64
	SearchIndexLen  uint64
	DisplayIndexOff uint64
	DisplayIndexLen uint64
	PostingsOff     uint64
	PostingsLen     uint64
	PostingsMetaOff uint64
	PostingsMetaLen uint64
	DocLengthsOff   uint64
	DocLengthsLen   uint64
	SearchableOff   uint64
	SearchableLen   uint64
	DisplayOff      uint64
	DisplayLen      uint64
	FSTOff          uint64
	FSTLen          uint64
	FingerprintsOff uint64
	FingerprintsLen uint64

	TypeaheadOff uint64
	TypeaheadLen uint64
	DictID       uint32
}

type Manifest struct {
	FormatTag      uint32
	ChunkSize      uint32
	NumSegments    uint32
	NumBooks       uint32
	BaseGeneration [16]byte
	Generation     uint64
	TypeaheadOff   uint64
	TypeaheadLen   uint64
	Regions        []ManifestRegion
	Tombstones     [][16]byte

	EntityProvenance [][2]uint64

	RecencyIndex []RecencyEntry

	IndexedFieldCount uint32
}

type RecencyEntry struct {
	LastModified string
	Id           string
	AbsOff       int64
	Length       int32
}

type ComposeOpts struct {
	PriorAggregatePath string
}

type PostingsEntry struct {
	Field  SearchField
	Term   string
	Offset uint64
	Length uint32
	DF     uint32
}

const (
	bm25K1 = 1.2
	bm25B  = 0.75
)

var FieldBoosts = map[SearchField]float64{
	FieldTitle:    3.0,
	FieldAuthor:   1.5,
	FieldTag:      2.0,
	FieldAbstract: 0.75,
}

var fieldsInOrder = []SearchField{FieldTitle, FieldAuthor, FieldTag, FieldAbstract}

func bm25(idf, tf, dl, avgdl, k1, b float64) float64 {
	num := tf * (k1 + 1)
	denom := tf + k1*(1-b+b*(dl/avgdl))
	return idf * (num / denom)
}

func bm25IDF(N, df float64) float64 {
	return math.Log((N-df+0.5)/(df+0.5) + 1)
}

func writeLenPrefixedBytes(buf *bytes.Buffer, b []byte) error {
	if err := binary.Write(buf, binary.LittleEndian, uint16(len(b))); err != nil {
		return err
	}
	buf.Write(b)
	return nil
}

func readLenPrefixedBytes(r *bytes.Reader) ([]byte, error) {
	var length uint16
	if err := binary.Read(r, binary.LittleEndian, &length); err != nil {
		return nil, err
	}
	buf := make([]byte, length)
	if _, err := io.ReadFull(r, buf); err != nil {
		return nil, err
	}
	return buf, nil
}

func encodePostingsMeta(entries []PostingsEntry) ([]byte, error) {
	var buf bytes.Buffer
	if err := binary.Write(&buf, binary.LittleEndian, uint32(len(entries))); err != nil {
		return nil, err
	}
	for _, e := range entries {
		if err := writeLenPrefixedBytes(&buf, []byte(e.Field)); err != nil {
			return nil, err
		}
		if err := writeLenPrefixedBytes(&buf, []byte(e.Term)); err != nil {
			return nil, err
		}
		if err := binary.Write(&buf, binary.LittleEndian, e.Offset); err != nil {
			return nil, err
		}
		if err := binary.Write(&buf, binary.LittleEndian, e.Length); err != nil {
			return nil, err
		}
		if err := binary.Write(&buf, binary.LittleEndian, e.DF); err != nil {
			return nil, err
		}
	}
	return buf.Bytes(), nil
}

func decodePostingsMeta(data []byte) ([]PostingsEntry, error) {
	if len(data) == 0 {
		return nil, nil
	}
	r := bytes.NewReader(data)
	var count uint32
	if err := binary.Read(r, binary.LittleEndian, &count); err != nil {
		return nil, err
	}
	entries := make([]PostingsEntry, count)
	for i := uint32(0); i < count; i++ {
		fieldBuf, err := readLenPrefixedBytes(r)
		if err != nil {
			return nil, err
		}
		termBuf, err := readLenPrefixedBytes(r)
		if err != nil {
			return nil, err
		}
		if err := binary.Read(r, binary.LittleEndian, &entries[i].Offset); err != nil {
			return nil, err
		}
		if err := binary.Read(r, binary.LittleEndian, &entries[i].Length); err != nil {
			return nil, err
		}
		if err := binary.Read(r, binary.LittleEndian, &entries[i].DF); err != nil {
			return nil, err
		}
		entries[i].Field = SearchField(fieldBuf)
		entries[i].Term = string(termBuf)
	}
	return entries, nil
}

func postingsMetaKey(field SearchField, term string) string {
	return string(field) + "\x00" + term
}

func encodeManifest(m Manifest) ([]byte, error) {
	var buf bytes.Buffer
	if err := binary.Write(&buf, binary.LittleEndian, m.FormatTag); err != nil {
		return nil, err
	}
	if err := binary.Write(&buf, binary.LittleEndian, m.ChunkSize); err != nil {
		return nil, err
	}
	if err := binary.Write(&buf, binary.LittleEndian, m.NumSegments); err != nil {
		return nil, err
	}
	if err := binary.Write(&buf, binary.LittleEndian, m.NumBooks); err != nil {
		return nil, err
	}
	if _, err := buf.Write(m.BaseGeneration[:]); err != nil {
		return nil, err
	}
	if err := binary.Write(&buf, binary.LittleEndian, m.Generation); err != nil {
		return nil, err
	}
	if err := binary.Write(&buf, binary.LittleEndian, m.TypeaheadOff); err != nil {
		return nil, err
	}
	if err := binary.Write(&buf, binary.LittleEndian, m.TypeaheadLen); err != nil {
		return nil, err
	}
	if err := binary.Write(&buf, binary.LittleEndian, uint32(len(m.Regions))); err != nil {
		return nil, err
	}
	for _, r := range m.Regions {
		if err := binary.Write(&buf, binary.LittleEndian, r); err != nil {
			return nil, err
		}
	}
	if err := binary.Write(&buf, binary.LittleEndian, uint32(len(m.Tombstones))); err != nil {
		return nil, err
	}
	for _, ts := range m.Tombstones {
		if _, err := buf.Write(ts[:]); err != nil {
			return nil, err
		}
	}

	if err := binary.Write(&buf, binary.LittleEndian, uint32(len(m.EntityProvenance))); err != nil {
		return nil, err
	}
	for _, ep := range m.EntityProvenance {
		if err := binary.Write(&buf, binary.LittleEndian, ep[0]); err != nil {
			return nil, err
		}
		if err := binary.Write(&buf, binary.LittleEndian, ep[1]); err != nil {
			return nil, err
		}
	}

	if err := binary.Write(&buf, binary.LittleEndian, uint32(len(m.RecencyIndex))); err != nil {
		return nil, err
	}
	for i, ref := range m.RecencyIndex {
		if len(ref.LastModified) > 1024 {
			return nil, fmt.Errorf("encodeManifest: recencyEntry %d lastModified too long (%d bytes)", i, len(ref.LastModified))
		}
		if err := binary.Write(&buf, binary.LittleEndian, uint16(len(ref.LastModified))); err != nil {
			return nil, err
		}
		if _, err := buf.WriteString(ref.LastModified); err != nil {
			return nil, err
		}
		if len(ref.Id) > 1024 {
			return nil, fmt.Errorf("encodeManifest: recencyEntry %d id too long (%d bytes)", i, len(ref.Id))
		}
		if err := binary.Write(&buf, binary.LittleEndian, uint16(len(ref.Id))); err != nil {
			return nil, err
		}
		if _, err := buf.WriteString(ref.Id); err != nil {
			return nil, err
		}
		if err := binary.Write(&buf, binary.LittleEndian, ref.AbsOff); err != nil {
			return nil, err
		}
		if err := binary.Write(&buf, binary.LittleEndian, ref.Length); err != nil {
			return nil, err
		}
	}

	if m.IndexedFieldCount > 3 {
		if err := binary.Write(&buf, binary.LittleEndian, m.IndexedFieldCount); err != nil {
			return nil, err
		}
	}

	return buf.Bytes(), nil
}

func decodeManifest(data []byte) (Manifest, error) {
	r := bytes.NewReader(data)
	var m Manifest
	if err := binary.Read(r, binary.LittleEndian, &m.FormatTag); err != nil {
		return m, fmt.Errorf("decodeManifest: format tag: %w", err)
	}
	if m.FormatTag != manifestFormatTag {
		return m, fmt.Errorf("decodeManifest: index format mismatch (built for tag %d, this binary uses %d); rebuild with: accorder lib build --index --compact", m.FormatTag, manifestFormatTag)
	}
	if err := binary.Read(r, binary.LittleEndian, &m.ChunkSize); err != nil {
		return m, fmt.Errorf("decodeManifest: chunkSize: %w", err)
	}
	if err := binary.Read(r, binary.LittleEndian, &m.NumSegments); err != nil {
		return m, fmt.Errorf("decodeManifest: numSegments: %w", err)
	}
	if err := binary.Read(r, binary.LittleEndian, &m.NumBooks); err != nil {
		return m, fmt.Errorf("decodeManifest: numBooks: %w", err)
	}
	if _, err := io.ReadFull(r, m.BaseGeneration[:]); err != nil {
		return m, fmt.Errorf("decodeManifest: baseGeneration: %w", err)
	}
	if err := binary.Read(r, binary.LittleEndian, &m.Generation); err != nil {
		return m, fmt.Errorf("decodeManifest: generation: %w", err)
	}
	if err := binary.Read(r, binary.LittleEndian, &m.TypeaheadOff); err != nil {
		return m, fmt.Errorf("decodeManifest: typeaheadOff: %w", err)
	}
	if err := binary.Read(r, binary.LittleEndian, &m.TypeaheadLen); err != nil {
		return m, fmt.Errorf("decodeManifest: typeaheadLen: %w", err)
	}
	var regionCount uint32
	if err := binary.Read(r, binary.LittleEndian, &regionCount); err != nil {
		return m, fmt.Errorf("decodeManifest: regionCount: %w", err)
	}
	if regionCount > 1024 {
		return m, fmt.Errorf("decodeManifest: regionCount %d exceeds limit", regionCount)
	}
	m.Regions = make([]ManifestRegion, regionCount)
	for i := uint32(0); i < regionCount; i++ {
		if err := binary.Read(r, binary.LittleEndian, &m.Regions[i]); err != nil {
			return m, fmt.Errorf("decodeManifest: region %d: %w", i, err)
		}
	}
	var tombstoneCount uint32
	if err := binary.Read(r, binary.LittleEndian, &tombstoneCount); err != nil {
		return m, fmt.Errorf("decodeManifest: tombstoneCount: %w", err)
	}
	if tombstoneCount > 1<<20 {
		return m, fmt.Errorf("decodeManifest: tombstoneCount %d exceeds limit", tombstoneCount)
	}
	m.Tombstones = make([][16]byte, tombstoneCount)
	for i := uint32(0); i < tombstoneCount; i++ {
		if _, err := io.ReadFull(r, m.Tombstones[i][:]); err != nil {
			return m, fmt.Errorf("decodeManifest: tombstone %d: %w", i, err)
		}
	}

	var entityCount uint32
	if err := binary.Read(r, binary.LittleEndian, &entityCount); err != nil {
		if errors.Is(err, io.EOF) || errors.Is(err, io.ErrUnexpectedEOF) {
			return m, nil
		}
		return m, fmt.Errorf("decodeManifest: entityCount: %w", err)
	}
	if entityCount > 1024 {
		return m, fmt.Errorf("decodeManifest: entityCount %d exceeds limit", entityCount)
	}
	m.EntityProvenance = make([][2]uint64, entityCount)
	for i := uint32(0); i < entityCount; i++ {
		if err := binary.Read(r, binary.LittleEndian, &m.EntityProvenance[i][0]); err != nil {
			return m, fmt.Errorf("decodeManifest: entityProvenance %d hash: %w", i, err)
		}
		if err := binary.Read(r, binary.LittleEndian, &m.EntityProvenance[i][1]); err != nil {
			return m, fmt.Errorf("decodeManifest: entityProvenance %d length: %w", i, err)
		}
	}

	var recencyCount uint32
	if err := binary.Read(r, binary.LittleEndian, &recencyCount); err != nil {
		if errors.Is(err, io.EOF) || errors.Is(err, io.ErrUnexpectedEOF) {
			return m, nil
		}
		return m, fmt.Errorf("decodeManifest: recencyCount: %w", err)
	}
	if recencyCount > 1<<20 {
		fmt.Fprintf(os.Stderr, "decodeManifest: recencyCount %d exceeds limit — skipping recency index (serve falls back to scan)\n", recencyCount)
		return m, nil
	}
	m.RecencyIndex = make([]RecencyEntry, recencyCount)
	for i := uint32(0); i < recencyCount; i++ {
		var lmLen uint16
		if err := binary.Read(r, binary.LittleEndian, &lmLen); err != nil {
			return m, fmt.Errorf("decodeManifest: recencyEntry %d lmLen: %w", i, err)
		}
		if lmLen > 1024 {
			return m, fmt.Errorf("decodeManifest: recencyEntry %d lastModified length %d exceeds limit", i, lmLen)
		}
		lm := make([]byte, lmLen)
		if _, err := io.ReadFull(r, lm); err != nil {
			return m, fmt.Errorf("decodeManifest: recencyEntry %d lastModified: %w", i, err)
		}
		m.RecencyIndex[i].LastModified = string(lm)
		var idLen uint16
		if err := binary.Read(r, binary.LittleEndian, &idLen); err != nil {
			return m, fmt.Errorf("decodeManifest: recencyEntry %d idLen: %w", i, err)
		}
		if idLen > 1024 {
			return m, fmt.Errorf("decodeManifest: recencyEntry %d id length %d exceeds limit", i, idLen)
		}
		idBuf := make([]byte, idLen)
		if _, err := io.ReadFull(r, idBuf); err != nil {
			return m, fmt.Errorf("decodeManifest: recencyEntry %d id: %w", i, err)
		}
		m.RecencyIndex[i].Id = string(idBuf)
		if err := binary.Read(r, binary.LittleEndian, &m.RecencyIndex[i].AbsOff); err != nil {
			return m, fmt.Errorf("decodeManifest: recencyEntry %d absOff: %w", i, err)
		}
		if err := binary.Read(r, binary.LittleEndian, &m.RecencyIndex[i].Length); err != nil {
			return m, fmt.Errorf("decodeManifest: recencyEntry %d length: %w", i, err)
		}
	}

	if err := binary.Read(r, binary.LittleEndian, &m.IndexedFieldCount); err != nil {
		if errors.Is(err, io.EOF) || errors.Is(err, io.ErrUnexpectedEOF) {
			return m, nil
		}
		return m, fmt.Errorf("decodeManifest: indexedFieldCount: %w", err)
	}

	return m, nil
}

func readContainerHeader(f *os.File) (dictCatalog []DictCatalogEntry, seekableOffset int64, err error) {
	hdrBuf := make([]byte, containerHdrSize)
	if _, err := f.ReadAt(hdrBuf, 0); err != nil {
		return nil, 0, fmt.Errorf("readContainerHeader: read: %w", err)
	}
	if string(hdrBuf[:4]) != containerMagic {
		return nil, 0, fmt.Errorf("readContainerHeader: not an MWSC container (magic=%q)", string(hdrBuf[:4]))
	}
	version := hdrBuf[4]

	var prefixSize uint64
	if err := binary.Read(bytes.NewReader(hdrBuf[5:]), binary.LittleEndian, &prefixSize); err != nil {
		return nil, 0, fmt.Errorf("readContainerHeader: decode: %w", err)
	}
	seekableOffset = containerHdrSize + int64(prefixSize)

	switch version {
	case containerVersionV1:
		if prefixSize > 0 {
			dictBytes := make([]byte, prefixSize)
			if _, err := f.ReadAt(dictBytes, containerHdrSize); err != nil {
				return nil, 0, fmt.Errorf("readContainerHeader: read dict: %w", err)
			}
			dictCatalog = []DictCatalogEntry{{DictID: 1, DictBytes: dictBytes}}
		}
		return dictCatalog, seekableOffset, nil

	case containerVersion:
		if prefixSize > 0 {
			catalogBytes := make([]byte, prefixSize)
			if _, err := f.ReadAt(catalogBytes, containerHdrSize); err != nil {
				return nil, 0, fmt.Errorf("readContainerHeader: read dict catalog: %w", err)
			}
			dictCatalog, err = readDictCatalog(bytes.NewReader(catalogBytes), prefixSize)
			if err != nil {
				return nil, 0, fmt.Errorf("readContainerHeader: %w", err)
			}
		}
		return dictCatalog, seekableOffset, nil

	default:
		return nil, 0, fmt.Errorf("readContainerHeader: unsupported container version %d (expected %d or %d)", version, containerVersionV1, containerVersion)
	}
}

func readManifestFromDecoder(rdr interface {
	ReadAt(p []byte, off int64) (int, error)
	Size() int64
}) (Manifest, error) {
	totalSize := rdr.Size()
	if totalSize < int64(manifestFooter) {
		return Manifest{}, fmt.Errorf("readManifest: stream too small (%d bytes)", totalSize)
	}

	footerBuf := make([]byte, manifestFooter)
	if _, err := rdr.ReadAt(footerBuf, totalSize-int64(manifestFooter)); err != nil {
		return Manifest{}, fmt.Errorf("readManifest: read footer: %w", err)
	}
	mfLen := binary.LittleEndian.Uint32(footerBuf[:4])
	mfMagic := binary.LittleEndian.Uint32(footerBuf[4:])

	if mfMagic != manifestMagic {
		return Manifest{}, fmt.Errorf("readManifest: bad manifest magic %08x (expected %08x)", mfMagic, manifestMagic)
	}
	if int64(mfLen) > totalSize-int64(manifestFooter) {
		return Manifest{}, fmt.Errorf("readManifest: manifest length %d exceeds stream size", mfLen)
	}

	manifestBuf := make([]byte, mfLen)
	manifestOffset := totalSize - int64(manifestFooter) - int64(mfLen)
	if _, err := rdr.ReadAt(manifestBuf, manifestOffset); err != nil {
		return Manifest{}, fmt.Errorf("readManifest: read manifest: %w", err)
	}

	m, err := decodeManifest(manifestBuf)
	if err != nil {
		return Manifest{}, fmt.Errorf("readManifest: %w", err)
	}

	if m.FormatTag != manifestFormatTag {
		return Manifest{}, fmt.Errorf("readManifest: index format mismatch (built for tag %d, this binary uses %d); rebuild with: accorder lib build --index --compact", m.FormatTag, manifestFormatTag)
	}
	if m.ChunkSize == 0 {
		return Manifest{}, fmt.Errorf("readManifest: corrupt manifest (ChunkSize=0)")
	}
	if len(m.Regions) == 0 {
		return Manifest{}, fmt.Errorf("readManifest: no regions in manifest")
	}

	return m, nil
}

func manifestSpanStart(rdr interface {
	ReadAt(p []byte, off int64) (int, error)
	Size() int64
}) (uint64, error) {
	totalSize := rdr.Size()
	footerBuf := make([]byte, manifestFooter)
	if _, err := rdr.ReadAt(footerBuf, totalSize-int64(manifestFooter)); err != nil {
		return 0, fmt.Errorf("manifestSpanStart: read footer: %w", err)
	}
	mfLen := binary.LittleEndian.Uint32(footerBuf[:4])
	return uint64(totalSize) - uint64(manifestFooter) - uint64(mfLen), nil
}

type Segments struct {
	List []Segment
}

type Segment struct {
	Length   int
	Offset   int64
	Segments []int
}

func (s *Segments) ClusterByFrames(dataOffset int64, chunkSize uint32, foundSegments []int, jsonlIndex []uint32) {
	if len(foundSegments) == 0 {
		return
	}

	cs := int64(chunkSize)
	totalUncompressed := dataOffset + int64(jsonlIndex[len(jsonlIndex)-1])

	type frameRange struct {
		startFrame int64
		endFrame   int64
	}
	segFrames := make([]frameRange, len(foundSegments))
	frameSet := make(map[int64]struct{})
	for i, seg := range foundSegments {
		var segStart int64
		if seg > 0 {
			segStart = int64(jsonlIndex[seg-1])
		}
		segEnd := int64(jsonlIndex[seg]) - 1

		sf := (dataOffset + segStart) / cs
		ef := (dataOffset + segEnd) / cs
		segFrames[i] = frameRange{sf, ef}
		for f := sf; f <= ef; f++ {
			frameSet[f] = struct{}{}
		}
	}

	frames := make([]int64, 0, len(frameSet))
	for f := range frameSet {
		frames = append(frames, f)
	}
	sort.Slice(frames, func(i, j int) bool { return frames[i] < frames[j] })

	type cluster struct {
		startFrame int64
		endFrame   int64
	}
	var clusters []cluster
	clusterStart := frames[0]
	clusterEnd := frames[0]
	for i := 1; i < len(frames); i++ {
		if frames[i] == clusterEnd+1 {
			clusterEnd = frames[i]
		} else {
			clusters = append(clusters, cluster{clusterStart, clusterEnd})
			clusterStart = frames[i]
			clusterEnd = frames[i]
		}
	}
	clusters = append(clusters, cluster{clusterStart, clusterEnd})

	for _, cl := range clusters {
		var segs []int
		for i, seg := range foundSegments {
			if segFrames[i].startFrame <= cl.endFrame && segFrames[i].endFrame >= cl.startFrame {
				segs = append(segs, seg)
			}
		}
		offset := cl.startFrame * cs
		end := (cl.endFrame + 1) * cs
		if end > totalUncompressed {
			end = totalUncompressed
		}
		s.List = append(s.List, Segment{
			Offset:   offset,
			Length:   int(end - offset),
			Segments: segs,
		})
	}
}

var htmlTagRe = regexp.MustCompile(`</?[a-zA-Z!][^>]*>`)

func stripHTML(s string) string {
	s = htmlTagRe.ReplaceAllString(s, " ")
	return html.UnescapeString(s)
}

const stemLanguage = "english"

func newDiacriticStripper() transform.Transformer {
	return transform.Chain(norm.NFD, runes.Remove(runes.In(unicode.Mn)), norm.NFC)
}

func normalizeAndTokenize(s string) []string { return normalizeTokens(s, true) }

func normalizeNoStem(s string) []string { return normalizeTokens(s, false) }

func normalizeTokens(s string, stem bool) []string {
	s = norm.NFKC.String(s)

	stripped, _, err := transform.String(newDiacriticStripper(), s)
	if err == nil {
		s = stripped
	}

	var out []string
	var b strings.Builder
	flush := func() {
		if b.Len() == 0 {
			return
		}
		word := strings.ToLower(b.String())
		b.Reset()
		if stem {
			if stemmed, stemErr := snowball.Stem(word, stemLanguage, true); stemErr == nil && stemmed != "" {
				out = append(out, stemmed)
				return
			}
		}
		out = append(out, word)
	}
	for _, r := range s {
		if unicode.IsLetter(r) || unicode.IsDigit(r) {
			b.WriteRune(r)
		} else {
			flush()
		}
	}
	flush()
	return out
}

type searchableLine struct {
	Title        string   `json:"title"`
	Authors      []string `json:"authors"`
	Tags         []string `json:"tags"`
	Abstract     string   `json:"abstract,omitempty"`
	LastModified int64    `json:"lm"`
}

func buildSearchableLine(book Book, indexDescription bool) searchableLine {
	title := strings.Join(normalizeAndTokenize(book.Title), " ")
	var authors []string
	for _, author := range book.Authors {
		authors = append(authors, strings.Join(normalizeAndTokenize(author), " "))
	}
	var tags []string
	for _, tag := range book.Tags {
		tags = append(tags, strings.Join(normalizeAndTokenize(tag), " "))
	}
	var abstract string
	if indexDescription && book.Abstract != "" {
		abstract = strings.Join(normalizeAndTokenize(stripHTML(book.Abstract)), " ")
	}
	return assembleSearchableLine(title, authors, tags, abstract, book.LastModified)
}

func assembleSearchableLine(title string, authors, tags []string, abstract, lastModified string) searchableLine {
	sl := searchableLine{Title: title, Authors: authors, Tags: tags, Abstract: abstract}
	if t, err := time.Parse(time.RFC3339Nano, lastModified); err == nil {
		sl.LastModified = t.UnixMilli()
	}
	return sl
}

func (sl searchableLine) matchAndScore(field SearchField, queryTokens []string, idfPerToken []float64, avgDLPerField []float64, ranked bool) (matched bool, score float64) {
	titleToks := strings.Fields(sl.Title)
	authorToks := make([][]string, len(sl.Authors))
	for i, a := range sl.Authors {
		authorToks[i] = strings.Fields(a)
	}
	tagToks := make([][]string, len(sl.Tags))
	for i, t := range sl.Tags {
		tagToks[i] = strings.Fields(t)
	}
	abstractToks := strings.Fields(sl.Abstract)

	switch field {
	case FieldTitle:
		matched = containsAll(titleToks, queryTokens)
	case FieldAuthor:
		for _, a := range authorToks {
			if containsAll(a, queryTokens) {
				matched = true
				break
			}
		}
	case FieldTag:
		for _, t := range tagToks {
			if containsAll(t, queryTokens) {
				matched = true
				break
			}
		}
	case FieldAbstract:
		matched = containsAll(abstractToks, queryTokens)
	}
	if !matched || !ranked {
		return matched, 0
	}

	fieldGroups := [][][]string{{titleToks}, authorToks, tagToks, {abstractToks}}
	numFields := len(avgDLPerField)
	if numFields > len(fieldGroups) {
		numFields = len(fieldGroups)
	}
	for fi := 0; fi < numFields; fi++ {
		boost := FieldBoosts[fieldsInOrder[fi]]
		groups := fieldGroups[fi]
		dl := 0
		for _, g := range groups {
			dl += len(g)
		}
		adl := avgDLPerField[fi]
		if adl == 0 {
			adl = 1
		}
		for qi, token := range queryTokens {
			tf := 0
			for _, g := range groups {
				for _, t := range g {
					if t == token {
						tf++
					}
				}
			}
			score += boost * bm25(idfPerToken[qi], float64(tf), float64(dl), adl, bm25K1, bm25B)
		}
	}
	return true, score
}

func (sl searchableLine) matchAnyAndScore(queryTokens []string, idfPerField [][]float64, avgDLPerField []float64, ranked bool, numFields int) (matched bool, score float64) {
	titleToks := strings.Fields(sl.Title)
	authorToks := make([][]string, len(sl.Authors))
	for i, a := range sl.Authors {
		authorToks[i] = strings.Fields(a)
	}
	tagToks := make([][]string, len(sl.Tags))
	for i, t := range sl.Tags {
		tagToks[i] = strings.Fields(t)
	}
	abstractToks := strings.Fields(sl.Abstract)

	fieldGroups := [][][]string{{titleToks}, authorToks, tagToks, {abstractToks}}
	if numFields > len(fieldGroups) {
		numFields = len(fieldGroups)
	}

	fieldMatched := make([]bool, numFields)
	for fi := 0; fi < numFields; fi++ {
		switch fieldsInOrder[fi] {
		case FieldTitle:
			fieldMatched[fi] = containsAll(titleToks, queryTokens)
		case FieldAuthor:
			for _, a := range authorToks {
				if containsAll(a, queryTokens) {
					fieldMatched[fi] = true
					break
				}
			}
		case FieldTag:
			for _, t := range tagToks {
				if containsAll(t, queryTokens) {
					fieldMatched[fi] = true
					break
				}
			}
		case FieldAbstract:
			fieldMatched[fi] = containsAll(abstractToks, queryTokens)
		}
		if fieldMatched[fi] {
			matched = true
		}
	}
	if !matched || !ranked {
		return matched, 0
	}

	for fi := 0; fi < numFields; fi++ {
		if !fieldMatched[fi] {
			continue
		}
		idfPerToken := idfPerField[fi]
		var fieldScore float64
		for fj := 0; fj < numFields; fj++ {
			boost := FieldBoosts[fieldsInOrder[fj]]
			groups := fieldGroups[fj]
			dl := 0
			for _, g := range groups {
				dl += len(g)
			}
			adl := avgDLPerField[fj]
			if adl == 0 {
				adl = 1
			}
			for qi, token := range queryTokens {
				tf := 0
				for _, g := range groups {
					for _, t := range g {
						if t == token {
							tf++
						}
					}
				}
				fieldScore += boost * bm25(idfPerToken[qi], float64(tf), float64(dl), adl, bm25K1, bm25B)
			}
		}
		if fieldScore > score {
			score = fieldScore
		}
	}
	return true, score
}

func (sl searchableLine) matchPrefix(field SearchField, prefix string) bool {
	titleToks := strings.Fields(sl.Title)
	authorTokGroups := make([][]string, len(sl.Authors))
	for i, a := range sl.Authors {
		authorTokGroups[i] = strings.Fields(a)
	}
	tagTokGroups := make([][]string, len(sl.Tags))
	for i, t := range sl.Tags {
		tagTokGroups[i] = strings.Fields(t)
	}

	switch field {
	case FieldTitle:
		return containsAnyPrefix(titleToks, prefix)
	case FieldAuthor:
		for _, a := range authorTokGroups {
			if containsAnyPrefix(a, prefix) {
				return true
			}
		}
	case FieldTag:
		for _, t := range tagTokGroups {
			if containsAnyPrefix(t, prefix) {
				return true
			}
		}
	case FieldAbstract:
		return containsAnyPrefix(strings.Fields(sl.Abstract), prefix)
	}
	return false
}

func (sl searchableLine) matchFuzzy(field SearchField, dfa *levenshtein.DFA) bool {
	titleToks := strings.Fields(sl.Title)
	authorTokGroups := make([][]string, len(sl.Authors))
	for i, a := range sl.Authors {
		authorTokGroups[i] = strings.Fields(a)
	}
	tagTokGroups := make([][]string, len(sl.Tags))
	for i, t := range sl.Tags {
		tagTokGroups[i] = strings.Fields(t)
	}

	switch field {
	case FieldTitle:
		return containsAnyFuzzy(titleToks, dfa)
	case FieldAuthor:
		for _, a := range authorTokGroups {
			if containsAnyFuzzy(a, dfa) {
				return true
			}
		}
	case FieldTag:
		for _, t := range tagTokGroups {
			if containsAnyFuzzy(t, dfa) {
				return true
			}
		}
	case FieldAbstract:
		return containsAnyFuzzy(strings.Fields(sl.Abstract), dfa)
	}
	return false
}

func (sl searchableLine) scoreExpanded(field SearchField, tokenMatch func(string) bool, idf float64, avgDLPerField []float64) float64 {
	titleToks := strings.Fields(sl.Title)
	authorTokGroups := make([][]string, len(sl.Authors))
	for i, a := range sl.Authors {
		authorTokGroups[i] = strings.Fields(a)
	}
	tagTokGroups := make([][]string, len(sl.Tags))
	for i, t := range sl.Tags {
		tagTokGroups[i] = strings.Fields(t)
	}
	abstractToks := strings.Fields(sl.Abstract)

	var score float64
	fieldGroups := [][][]string{{titleToks}, authorTokGroups, tagTokGroups, {abstractToks}}
	numFields := len(avgDLPerField)
	if numFields > len(fieldGroups) {
		numFields = len(fieldGroups)
	}
	for fi := 0; fi < numFields; fi++ {
		boost := FieldBoosts[fieldsInOrder[fi]]
		groups := fieldGroups[fi]
		dl := 0
		for _, g := range groups {
			dl += len(g)
		}
		adl := avgDLPerField[fi]
		if adl == 0 {
			adl = 1
		}
		tf := 0
		for _, g := range groups {
			for _, t := range g {
				if tokenMatch(t) {
					tf++
				}
			}
		}
		score += boost * bm25(idf, float64(tf), float64(dl), adl, bm25K1, bm25B)
	}
	return score
}

func (motw *MotwSearch) GetBooksJSONL(motwLibraries map[string]MotwLibrary) ([]*Book, error) {
	jsonlFile, err := os.Open(motw.JsonlPath)
	if err != nil {
		return nil, fmt.Errorf("GetBooksJSONL: open: %w", err)
	}
	defer jsonlFile.Close()

	reader := bufio.NewReader(jsonlFile)

	var books []*Book
	for {
		var book *Book
		line, err := reader.ReadString('\n')
		if err != nil {
			if err == io.EOF {
				break
			}
			return nil, fmt.Errorf("GetBooksJSONL: read line: %w", err)
		}
		if err := json.Unmarshal([]byte(line), &book); err != nil {
			return nil, fmt.Errorf("GetBooksJSONL: unmarshal: %w", err)
		}
		motwLibrary, ok := motwLibraries[book.LibraryUUID]
		if !ok {
			return nil, fmt.Errorf("GetBooksJSONL: unknown library UUID %q", book.LibraryUUID)
		}
		app := &MotwStandaloneApp{
			Librarian:   book.Librarian,
			LibraryUUID: book.LibraryUUID,
			BaseURL:     motwLibrary.URL,
		}
		book.MemoryOfTheWorldify(app)
		books = append(books, book)
	}
	sort.Sort(CalibreBooksByLastModified(books))
	if err := assertBookIDsUnique(books); err != nil {
		return nil, fmt.Errorf("GetBooksJSONL: %w", err)
	}
	return books, nil
}

const dictSampleLines = 50

const defaultDictID = uint32(1)

func (motwSearch *MotwSearch) resolveDictID() uint32 {
	if motwSearch.DictID != 0 {
		return motwSearch.DictID
	}
	return defaultDictID
}

func (motwSearch *MotwSearch) CompressToFile(idx indexData) error {
	chunkSize := motwSearch.ChunkSize
	if chunkSize == 0 {
		chunkSize = defaultChunkSize
	}

	jsonlFile, err := os.Open(motwSearch.JsonlPath)
	if err != nil {
		return fmt.Errorf("CompressToFile: open JSONL: %w", err)
	}
	defer jsonlFile.Close()

	var searchIndex, displayIndex []uint32
	var displaySamples [][]byte
	var recency []RecencyEntry
	var searchableBytes []byte
	displaySegLen := 0

	if idx.Searchable != nil {

		searchableBytes = idx.Searchable
		var acc uint32
		for _, segLen := range idx.SearchSegLens {
			acc += segLen
			searchIndex = append(searchIndex, acc)
		}
		for _, segLen := range idx.DisplaySegLens {
			displaySegLen += int(segLen)
			displayIndex = append(displayIndex, uint32(displaySegLen))
		}
		displaySamples = idx.DisplaySamples

		recency = make([]RecencyEntry, len(idx.Recency))
		copy(recency, idx.Recency)
		if len(idx.DisplaySegLens) != len(idx.SearchSegLens) {
			return fmt.Errorf("CompressToFile: display/search segment count mismatch (%d vs %d)", len(idx.DisplaySegLens), len(idx.SearchSegLens))
		}
	} else {

		var searchBuf bytes.Buffer
		numBooks := 0
		searchSegLen := 0
		var displayPos int64
		reader := bufio.NewReader(jsonlFile)
		for {
			line, err := reader.ReadString('\n')
			if err != nil {
				if err == io.EOF {
					if searchSegLen > 0 && numBooks%16 != 0 {
						searchIndex = append(searchIndex, uint32(searchSegLen))
						displayIndex = append(displayIndex, uint32(displaySegLen))
					}
					break
				}
				return fmt.Errorf("CompressToFile: read line: %w", err)
			}
			var book Book
			if err := json.Unmarshal([]byte(line), &book); err != nil {
				return fmt.Errorf("CompressToFile: unmarshal book: %w", err)
			}
			numBooks++

			if len(displaySamples) < dictSampleLines {
				cp := make([]byte, len(line))
				copy(cp, []byte(line))
				displaySamples = append(displaySamples, cp)
			}

			sData, _ := json.Marshal(buildSearchableLine(book, motwSearch.IndexDescription))
			sData = append(sData, '\n')
			searchBuf.Write(sData)
			searchSegLen += len(sData)

			lineLen := len(line)
			if lineLen > 0 && line[lineLen-1] == '\n' {
				lineLen--
			}
			recency = append(recency, RecencyEntry{
				LastModified: book.LastModified,
				Id:           book.Id,
				AbsOff:       displayPos,
				Length:       int32(lineLen),
			})
			displayPos += int64(len(line))
			displaySegLen += len(line)

			if numBooks%16 == 0 {
				searchIndex = append(searchIndex, uint32(searchSegLen))
				displayIndex = append(displayIndex, uint32(displaySegLen))
			}
		}
		searchableBytes = searchBuf.Bytes()
	}

	searchIdxBuf := new(bytes.Buffer)
	if err := binary.Write(searchIdxBuf, binary.LittleEndian, searchIndex); err != nil {
		return fmt.Errorf("CompressToFile: write search index: %w", err)
	}
	displayIdxBuf := new(bytes.Buffer)
	if err := binary.Write(displayIdxBuf, binary.LittleEndian, displayIndex); err != nil {
		return fmt.Errorf("CompressToFile: write display index: %w", err)
	}

	var displayDictBytes []byte
	if len(displaySamples) > 0 {
		var dictBuf bytes.Buffer
		for _, s := range displaySamples {
			dictBuf.Write(s)
		}
		displayDictBytes = dictBuf.Bytes()
	}

	searchIdxBytes := searchIdxBuf.Bytes()
	displayIdxBytes := displayIdxBuf.Bytes()

	typeaheadBytes := idx.EntityFST

	memberDictID := motwSearch.resolveDictID()

	var cursor uint64
	region := ManifestRegion{
		SearchIndexOff: cursor, SearchIndexLen: uint64(len(searchIdxBytes)),
		DictID: memberDictID,
	}
	cursor += uint64(len(searchIdxBytes))
	region.DisplayIndexOff = cursor
	region.DisplayIndexLen = uint64(len(displayIdxBytes))
	cursor += uint64(len(displayIdxBytes))
	region.PostingsOff = cursor
	region.PostingsLen = uint64(len(idx.Postings))
	cursor += uint64(len(idx.Postings))
	region.PostingsMetaOff = cursor
	region.PostingsMetaLen = uint64(len(idx.PostingsMeta))
	cursor += uint64(len(idx.PostingsMeta))
	region.DocLengthsOff = cursor
	region.DocLengthsLen = uint64(len(idx.DocLengths))
	cursor += uint64(len(idx.DocLengths))
	region.SearchableOff = cursor
	region.SearchableLen = uint64(len(searchableBytes))
	cursor += uint64(len(searchableBytes))
	region.DisplayOff = cursor
	region.DisplayLen = uint64(displaySegLen)
	cursor += uint64(displaySegLen)
	region.FSTOff = cursor
	region.FSTLen = uint64(len(idx.FSTBytes))
	cursor += uint64(len(idx.FSTBytes))
	region.FingerprintsOff = cursor
	region.FingerprintsLen = uint64(len(idx.Fingerprints))
	cursor += uint64(len(idx.Fingerprints))

	typeaheadOff := cursor

	for i := range recency {
		recency[i].AbsOff += int64(region.DisplayOff)
	}
	sort.Slice(recency, func(i, j int) bool {
		if recency[i].LastModified != recency[j].LastModified {
			return recency[i].LastModified > recency[j].LastModified
		}
		return recency[i].Id < recency[j].Id
	})

	var baseGen [16]byte
	if motwSearch.BaseGeneration != nil {
		baseGen = *motwSearch.BaseGeneration
	} else if _, err := rand.Read(baseGen[:]); err != nil {
		return fmt.Errorf("CompressToFile: read random for BaseGeneration: %w", err)
	}

	var indexedFieldCount uint32
	if motwSearch.IndexDescription {
		indexedFieldCount = 4
	}
	mf := Manifest{
		FormatTag:         manifestFormatTag,
		ChunkSize:         uint32(chunkSize),
		NumSegments:       idx.NumSegments,
		NumBooks:          idx.NumBooks,
		BaseGeneration:    baseGen,
		Generation:        motwSearch.StartGeneration,
		TypeaheadOff:      typeaheadOff,
		TypeaheadLen:      uint64(len(typeaheadBytes)),
		Regions:           []ManifestRegion{region},
		RecencyIndex:      recency,
		IndexedFieldCount: indexedFieldCount,
	}
	manifestPayload, err := encodeManifest(mf)
	if err != nil {
		return fmt.Errorf("CompressToFile: encode manifest: %w", err)
	}

	var manifestWithFooter bytes.Buffer
	manifestWithFooter.Write(manifestPayload)
	if err := binary.Write(&manifestWithFooter, binary.LittleEndian, uint32(len(manifestPayload))); err != nil {
		return fmt.Errorf("CompressToFile: write manifest footer len: %w", err)
	}
	if err := binary.Write(&manifestWithFooter, binary.LittleEndian, manifestMagic); err != nil {
		return fmt.Errorf("CompressToFile: write manifest footer magic: %w", err)
	}

	prefix := new(bytes.Buffer)
	prefix.Write(searchIdxBytes)
	prefix.Write(displayIdxBytes)
	prefix.Write(idx.Postings)
	prefix.Write(idx.PostingsMeta)
	prefix.Write(idx.DocLengths)

	if _, err := jsonlFile.Seek(0, io.SeekStart); err != nil {
		return fmt.Errorf("CompressToFile: rewind JSONL: %w", err)
	}

	combinedKept := io.MultiReader(
		prefix,
		bytes.NewReader(searchableBytes),
		io.LimitReader(jsonlFile, int64(displaySegLen)),
		bytes.NewReader(idx.FSTBytes),
		bytes.NewReader(idx.Fingerprints),
	)

	fw, err := os.Create(motwSearch.IndexPath + ".zst")
	if err != nil {
		return fmt.Errorf("CompressToFile: create output: %w", err)
	}
	compressOK := false
	defer func() {
		fw.Close()
		if !compressOK {
			os.Remove(motwSearch.IndexPath + ".zst")
		}
	}()

	var catalog []DictCatalogEntry
	if len(displayDictBytes) > 0 {
		catalog = []DictCatalogEntry{{DictID: memberDictID, DictBytes: displayDictBytes}}
	}
	catSize := dictCatalogSize(catalog)

	if _, err := fw.Write([]byte(containerMagic)); err != nil {
		return fmt.Errorf("CompressToFile: write container magic: %w", err)
	}
	if _, err := fw.Write([]byte{containerVersion}); err != nil {
		return fmt.Errorf("CompressToFile: write container version: %w", err)
	}
	if err := binary.Write(fw, binary.LittleEndian, catSize); err != nil {
		return fmt.Errorf("CompressToFile: write dict catalog size: %w", err)
	}
	if err := writeDictCatalog(fw, catalog); err != nil {
		return fmt.Errorf("CompressToFile: %w", err)
	}

	var encOpts []zstd.EOption

	encOpts = append(encOpts, zstd.WithEncoderLevel(resolveZstdLevel()))
	if len(displayDictBytes) > 0 {
		encOpts = append(encOpts, zstd.WithEncoderDictRaw(memberDictID, displayDictBytes))
	}
	numWorkers := buildWorkerCount(runtime.GOMAXPROCS(0))
	entries, err := writeFramesParallel(fw, encOpts,
		[]io.Reader{combinedKept, bytes.NewReader(typeaheadBytes), &manifestWithFooter}, chunkSize, numWorkers)
	if err != nil {
		return fmt.Errorf("CompressToFile: write frames: %w", err)
	}
	if err := writeSeekTable(fw, entries, seekTableEntrySizeCksm); err != nil {
		return fmt.Errorf("CompressToFile: write seek table: %w", err)
	}

	compressOK = true
	return nil
}

func resolveZstdLevel() zstd.EncoderLevel {
	switch os.Getenv("ACCORDER_ZSTD_LEVEL") {
	case "best":
		return zstd.SpeedBestCompression
	case "better":
		return zstd.SpeedBetterCompression
	case "fastest":
		return zstd.SpeedFastest
	default:
		return zstd.SpeedDefault
	}
}

func buildWorkerCount(requested int) int {
	if requested < 1 {
		return 1
	}
	if v := os.Getenv("ACCORDER_MAX_BUILD_WORKERS"); v != "" {
		if n, err := strconv.Atoi(v); err == nil && n >= 1 && n < requested {
			return n
		}
	}
	const perWorkerBytes = 80 << 20
	avail := MemAvailable()
	if avail == 0 {
		return requested
	}
	maxByMem := int((avail / 2) / perWorkerBytes)
	if maxByMem < 1 {
		maxByMem = 1
	}
	if requested > maxByMem {
		return maxByMem
	}
	return requested
}

func writeFramesParallel(w io.Writer, encOpts []zstd.EOption, readers []io.Reader, chunkSize, numWorkers int) ([]byte, error) {
	if numWorkers < 1 {
		numWorkers = 1
	}
	frameOpts := append(append([]zstd.EOption(nil), encOpts...), zstd.WithEncoderConcurrency(1))
	encs := make([]*zstd.Encoder, numWorkers)
	defer func() {
		for _, e := range encs {
			if e != nil {
				e.Close()
			}
		}
	}()
	getEnc := func(j int) (*zstd.Encoder, error) {
		if encs[j] == nil {
			e, err := zstd.NewWriter(nil, frameOpts...)
			if err != nil {
				return nil, err
			}
			encs[j] = e
		}
		return encs[j], nil
	}

	ri := 0
	nextChunk := func() ([]byte, error) {
		for ri < len(readers) {
			buf := make([]byte, chunkSize)
			n, err := io.ReadFull(readers[ri], buf)
			if n > 0 {
				if err != nil && !errors.Is(err, io.EOF) && !errors.Is(err, io.ErrUnexpectedEOF) {
					return nil, err
				}
				return buf[:n], nil
			}
			if errors.Is(err, io.EOF) || errors.Is(err, io.ErrUnexpectedEOF) {
				ri++
				continue
			}
			if err != nil {
				return nil, err
			}
		}
		return nil, nil
	}

	type result struct {
		frame     []byte
		uncompLen int
		cksum     uint32
	}
	var entries []byte
	for {
		chunks := make([][]byte, 0, numWorkers)
		for len(chunks) < numWorkers {
			c, err := nextChunk()
			if err != nil {
				return nil, err
			}
			if c == nil {
				break
			}
			chunks = append(chunks, c)
		}
		if len(chunks) == 0 {
			break
		}
		for j := range chunks {
			if _, err := getEnc(j); err != nil {
				return nil, err
			}
		}
		results := make([]result, len(chunks))
		var wg sync.WaitGroup
		for j := range chunks {
			wg.Add(1)
			go func(j int) {
				defer wg.Done()
				frame := encs[j].EncodeAll(chunks[j], nil)
				results[j] = result{frame, len(chunks[j]), uint32((xxhash.Sum64(chunks[j]) << 32) >> 32)}
			}(j)
		}
		wg.Wait()
		for j := range results {
			if _, err := w.Write(results[j].frame); err != nil {
				return nil, err
			}
			var e [seekTableEntrySizeCksm]byte
			binary.LittleEndian.PutUint32(e[0:4], uint32(len(results[j].frame)))
			binary.LittleEndian.PutUint32(e[4:8], uint32(results[j].uncompLen))
			binary.LittleEndian.PutUint32(e[8:12], results[j].cksum)
			entries = append(entries, e[:]...)
		}
	}
	return entries, nil
}

func (motwSearch *MotwSearch) AppendToFile(idx indexData, tombstones [][16]byte) error {
	chunkSize := motwSearch.ChunkSize
	if chunkSize == 0 {
		chunkSize = defaultChunkSize
	}

	zstPath := motwSearch.IndexPath + ".zst"

	if _, err := os.Stat(zstPath); os.IsNotExist(err) {
		return motwSearch.CompressToFile(idx)
	}

	f, err := os.OpenFile(zstPath, os.O_RDWR, 0)
	if err != nil {
		return fmt.Errorf("AppendToFile: open: %w", err)
	}
	defer f.Close()

	dictCatalog, seekableOffset, err := readContainerHeader(f)
	if err != nil {
		return fmt.Errorf("AppendToFile: %w", err)
	}

	fileSize, err := f.Seek(0, io.SeekEnd)
	if err != nil {
		return fmt.Errorf("AppendToFile: seek end: %w", err)
	}

	seekableLen := fileSize - seekableOffset
	seekableBytes := make([]byte, seekableLen)
	if _, err := f.ReadAt(seekableBytes, seekableOffset); err != nil {
		return fmt.Errorf("AppendToFile: read seekable: %w", err)
	}

	baseEntries, entrySize, tableStart, err := readSeekTableEntries(seekableBytes)
	if err != nil {
		return fmt.Errorf("AppendToFile: %w", err)
	}

	var decOpts []zstd.DOption
	for _, entry := range dictCatalog {
		decOpts = append(decOpts, zstd.WithDecoderDictRaw(entry.DictID, entry.DictBytes))
	}
	// Cap per-DecodeAll memory: a hostile zstd frame header's declared
	// content size must not drive allocations past the reader's frame cap.
	decOpts = append(decOpts, zstd.WithDecoderMaxMemory(maxDecoderFrameSize))
	dec, err := zstd.NewReader(nil, decOpts...)
	if err != nil {
		return fmt.Errorf("AppendToFile: zstd reader: %w", err)
	}
	defer dec.Close()

	rdr, err := newMWSCReaderAt(bytes.NewReader(seekableBytes), int64(len(seekableBytes)), dec)
	if err != nil {
		return fmt.Errorf("AppendToFile: seekable decoder: %w", err)
	}
	existingMf, err := readManifestFromDecoder(rdr)
	if err != nil {
		rdr.Close()
		return fmt.Errorf("AppendToFile: read manifest: %w", err)
	}

	baseHasDescriptions := existingMf.IndexedFieldCount >= 4
	if motwSearch.IndexDescription != baseHasDescriptions {
		rdr.Close()
		return fmt.Errorf("AppendToFile: IndexDescription=%v does not match base index field count %d — appending a delta with a different field width would corrupt BM25 ranking; rebuild with --compact instead",
			motwSearch.IndexDescription, existingMf.IndexedFieldCount)
	}

	keptEntries := baseEntries
	keptTableStart := tableStart
	if prevManifestStart, msErr := manifestSpanStart(rdr); msErr == nil {
		if keptComp, keptOff, aligned := keptFrameSpan(baseEntries, entrySize, prevManifestStart); aligned {
			keptEntries = baseEntries[:keptOff]
			keptTableStart = keptComp
		}
	}

	allTombstoneSet := make(map[[16]byte]struct{}, len(existingMf.Tombstones)+len(tombstones))
	for _, ts := range existingMf.Tombstones {
		allTombstoneSet[ts] = struct{}{}
	}
	for _, ts := range tombstones {
		allTombstoneSet[ts] = struct{}{}
	}
	var existingRecency []RecencyEntry
	if len(existingMf.RecencyIndex) > 0 {
		existingRecency = make([]RecencyEntry, 0, len(existingMf.RecencyIndex))
		for _, e := range existingMf.RecencyIndex {
			if e.Id != "" && len(allTombstoneSet) > 0 {
				if ts, perr := bookIDToTombstone(e.Id); perr == nil {
					if _, dead := allTombstoneSet[ts]; dead {
						continue
					}
				}
			}
			existingRecency = append(existingRecency, e)
		}
		rdr.Close()
	} else {
		for _, reg := range existingMf.Regions {
			if reg.DisplayIndexLen == 0 || reg.DisplayLen == 0 {
				continue
			}
			displayIdxBytes := make([]byte, reg.DisplayIndexLen)
			if _, err := rdr.ReadAt(displayIdxBytes, int64(reg.DisplayIndexOff)); err != nil {
				rdr.Close()
				return fmt.Errorf("AppendToFile: read display index for recency: %w", err)
			}
			displayIdx := make([]uint32, len(displayIdxBytes)/4)
			if err := binary.Read(bytes.NewReader(displayIdxBytes), binary.LittleEndian, &displayIdx); err != nil {
				rdr.Close()
				return fmt.Errorf("AppendToFile: decode display index for recency: %w", err)
			}
			for seg := 0; seg < len(displayIdx); seg++ {
				var segStart int64
				if seg > 0 {
					segStart = int64(displayIdx[seg-1])
				}
				segEnd := int64(displayIdx[seg])
				segBytes := make([]byte, segEnd-segStart)
				if _, err := rdr.ReadAt(segBytes, int64(reg.DisplayOff)+segStart); err != nil && !errors.Is(err, io.EOF) {
					rdr.Close()
					return fmt.Errorf("AppendToFile: read display segment for recency: %w", err)
				}
				var pos int64
				for pos < int64(len(segBytes)) {
					nl := bytes.IndexByte(segBytes[pos:], '\n')
					var line []byte
					if nl < 0 {
						line = segBytes[pos:]
					} else {
						line = segBytes[pos : pos+int64(nl)]
					}
					lineOff := int64(reg.DisplayOff) + segStart + pos
					if nl < 0 {
						pos = int64(len(segBytes))
					} else {
						pos += int64(nl) + 1
					}
					if len(line) == 0 {
						continue
					}
					var meta struct {
						Id           string `json:"_id"`
						LastModified string `json:"last_modified"`
					}
					if err := json.Unmarshal(line, &meta); err != nil {
						continue
					}
					if meta.Id != "" && len(allTombstoneSet) > 0 {
						if ts, perr := bookIDToTombstone(meta.Id); perr == nil {
							if _, dead := allTombstoneSet[ts]; dead {
								continue
							}
						}
					}
					existingRecency = append(existingRecency, RecencyEntry{
						LastModified: meta.LastModified,
						Id:           meta.Id,
						AbsOff:       lineOff,
						Length:       int32(len(line)),
					})
				}
			}
		}
		rdr.Close()
	}

	jsonlFile, err := os.Open(motwSearch.JsonlPath)
	if err != nil {
		return fmt.Errorf("AppendToFile: open delta JSONL: %w", err)
	}
	defer jsonlFile.Close()

	var searchBuf bytes.Buffer
	var displayBuf bytes.Buffer
	var searchIndex, displayIndex []uint32
	numBooks := 0
	searchSegLen := 0
	displaySegLen := 0

	reader := bufio.NewReader(jsonlFile)
	for {
		line, err := reader.ReadString('\n')
		if err != nil {
			if err == io.EOF {
				if searchSegLen > 0 && numBooks%16 != 0 {
					searchIndex = append(searchIndex, uint32(searchSegLen))
					displayIndex = append(displayIndex, uint32(displaySegLen))
				}
				break
			}
			return fmt.Errorf("AppendToFile: read line: %w", err)
		}
		var book Book
		if err := json.Unmarshal([]byte(line), &book); err != nil {
			return fmt.Errorf("AppendToFile: unmarshal book: %w", err)
		}
		numBooks++

		sData, _ := json.Marshal(buildSearchableLine(book, motwSearch.IndexDescription))
		sData = append(sData, '\n')
		searchBuf.Write(sData)
		searchSegLen += len(sData)

		displayBuf.WriteString(line)
		displaySegLen += len(line)

		if numBooks%16 == 0 {
			searchIndex = append(searchIndex, uint32(searchSegLen))
			displayIndex = append(displayIndex, uint32(displaySegLen))
		}
	}

	searchIdxBuf := new(bytes.Buffer)
	if err := binary.Write(searchIdxBuf, binary.LittleEndian, searchIndex); err != nil {
		return fmt.Errorf("AppendToFile: write search index: %w", err)
	}
	displayIdxBuf := new(bytes.Buffer)
	if err := binary.Write(displayIdxBuf, binary.LittleEndian, displayIndex); err != nil {
		return fmt.Errorf("AppendToFile: write display index: %w", err)
	}

	searchIdxBytes := searchIdxBuf.Bytes()
	displayIdxBytes := displayIdxBuf.Bytes()
	searchableBytes := searchBuf.Bytes()
	displayBytes := displayBuf.Bytes()

	typeaheadBytes := idx.EntityFST

	var deltaBaseOffset uint64
	for off := 0; off+entrySize <= len(keptEntries); off += entrySize {
		deltaBaseOffset += uint64(binary.LittleEndian.Uint32(keptEntries[off+4 : off+8]))
	}

	var cursor uint64
	deltaRegion := ManifestRegion{
		SearchIndexOff: deltaBaseOffset + cursor, SearchIndexLen: uint64(len(searchIdxBytes)),
	}
	if len(dictCatalog) > 0 {
		deltaRegion.DictID = dictCatalog[0].DictID
	}
	cursor += uint64(len(searchIdxBytes))
	deltaRegion.DisplayIndexOff = deltaBaseOffset + cursor
	deltaRegion.DisplayIndexLen = uint64(len(displayIdxBytes))
	cursor += uint64(len(displayIdxBytes))
	deltaRegion.PostingsOff = deltaBaseOffset + cursor
	deltaRegion.PostingsLen = uint64(len(idx.Postings))
	cursor += uint64(len(idx.Postings))
	deltaRegion.PostingsMetaOff = deltaBaseOffset + cursor
	deltaRegion.PostingsMetaLen = uint64(len(idx.PostingsMeta))
	cursor += uint64(len(idx.PostingsMeta))
	deltaRegion.DocLengthsOff = deltaBaseOffset + cursor
	deltaRegion.DocLengthsLen = uint64(len(idx.DocLengths))
	cursor += uint64(len(idx.DocLengths))
	deltaRegion.SearchableOff = deltaBaseOffset + cursor
	deltaRegion.SearchableLen = uint64(len(searchableBytes))
	cursor += uint64(len(searchableBytes))
	deltaRegion.DisplayOff = deltaBaseOffset + cursor
	deltaRegion.DisplayLen = uint64(len(displayBytes))
	cursor += uint64(len(displayBytes))
	deltaRegion.FSTOff = deltaBaseOffset + cursor
	deltaRegion.FSTLen = uint64(len(idx.FSTBytes))
	cursor += uint64(len(idx.FSTBytes))
	deltaRegion.FingerprintsOff = deltaBaseOffset + cursor
	deltaRegion.FingerprintsLen = uint64(len(idx.Fingerprints))
	cursor += uint64(len(idx.Fingerprints))

	typeaheadOff := deltaBaseOffset + cursor

	deltaRegion.TypeaheadOff = typeaheadOff
	deltaRegion.TypeaheadLen = uint64(len(typeaheadBytes))

	var deltaRecency []RecencyEntry
	{
		deltaDisplayOff := int64(deltaRegion.DisplayOff)
		var pos int64
		for pos < int64(len(displayBytes)) {
			nl := bytes.IndexByte(displayBytes[pos:], '\n')
			var line []byte
			if nl < 0 {
				line = displayBytes[pos:]
			} else {
				line = displayBytes[pos : pos+int64(nl)]
			}
			lineOff := deltaDisplayOff + pos
			if nl < 0 {
				pos = int64(len(displayBytes))
			} else {
				pos += int64(nl) + 1
			}
			if len(line) == 0 {
				continue
			}
			var meta struct {
				Id           string `json:"_id"`
				LastModified string `json:"last_modified"`
			}
			if err := json.Unmarshal(line, &meta); err != nil {
				continue
			}
			deltaRecency = append(deltaRecency, RecencyEntry{
				LastModified: meta.LastModified,
				Id:           meta.Id,
				AbsOff:       lineOff,
				Length:       int32(len(line)),
			})
		}
	}

	allRecency := append(existingRecency, deltaRecency...)
	sort.Slice(allRecency, func(i, j int) bool {
		if allRecency[i].LastModified != allRecency[j].LastModified {
			return allRecency[i].LastModified > allRecency[j].LastModified
		}
		return allRecency[i].Id < allRecency[j].Id
	})

	newMf := Manifest{
		FormatTag:      existingMf.FormatTag,
		ChunkSize:      existingMf.ChunkSize,
		NumSegments:    existingMf.NumSegments + idx.NumSegments,
		NumBooks:       existingMf.NumBooks + idx.NumBooks,
		BaseGeneration: existingMf.BaseGeneration,
		Generation:     existingMf.Generation + 1,

		TypeaheadOff:      existingMf.TypeaheadOff,
		TypeaheadLen:      existingMf.TypeaheadLen,
		Regions:           append(existingMf.Regions, deltaRegion),
		Tombstones:        append(existingMf.Tombstones, tombstones...),
		EntityProvenance:  existingMf.EntityProvenance,
		RecencyIndex:      allRecency,
		IndexedFieldCount: existingMf.IndexedFieldCount,
	}
	manifestPayload, err := encodeManifest(newMf)
	if err != nil {
		return fmt.Errorf("AppendToFile: encode manifest: %w", err)
	}

	var manifestWithFooter bytes.Buffer
	manifestWithFooter.Write(manifestPayload)
	if err := binary.Write(&manifestWithFooter, binary.LittleEndian, uint32(len(manifestPayload))); err != nil {
		return fmt.Errorf("AppendToFile: write manifest footer len: %w", err)
	}
	if err := binary.Write(&manifestWithFooter, binary.LittleEndian, manifestMagic); err != nil {
		return fmt.Errorf("AppendToFile: write manifest footer magic: %w", err)
	}

	var sections bytes.Buffer
	sections.Write(searchIdxBytes)
	sections.Write(displayIdxBytes)
	sections.Write(idx.Postings)
	sections.Write(idx.PostingsMeta)
	sections.Write(idx.DocLengths)
	sections.Write(searchableBytes)
	sections.Write(displayBytes)
	sections.Write(idx.FSTBytes)
	sections.Write(idx.Fingerprints)

	var encOpts []zstd.EOption
	encOpts = append(encOpts, zstd.WithEncoderLevel(resolveZstdLevel()))
	if len(dictCatalog) > 0 {
		encOpts = append(encOpts, zstd.WithEncoderDictRaw(dictCatalog[0].DictID, dictCatalog[0].DictBytes))
	}
	enc, err := zstd.NewWriter(nil, encOpts...)
	if err != nil {
		return fmt.Errorf("AppendToFile: zstd encoder: %w", err)
	}
	defer enc.Close()

	var newFrames [][]byte
	var newEntries []byte
	for _, group := range [][]byte{sections.Bytes(), typeaheadBytes, manifestWithFooter.Bytes()} {
		for off := 0; off < len(group); off += chunkSize {
			end := min(off+chunkSize, len(group))
			chunk := group[off:end]
			compressed := enc.EncodeAll(chunk, nil)
			newFrames = append(newFrames, compressed)

			// New entries must match the BASE table's entry width: the merged
			// table is written with the base entrySize, and mixing 12-byte
			// entries into an 8-byte table would corrupt it (frameCount and
			// entry boundaries are derived from entrySize).
			var entry [seekTableEntrySizeCksm]byte
			binary.LittleEndian.PutUint32(entry[0:4], uint32(len(compressed)))
			binary.LittleEndian.PutUint32(entry[4:8], uint32(len(chunk)))
			if entrySize == seekTableEntrySizeCksm {
				ck := uint32((xxhash.Sum64(chunk) << 32) >> 32)
				binary.LittleEndian.PutUint32(entry[8:12], ck)
			}
			newEntries = append(newEntries, entry[:entrySize]...)
		}
	}

	truncateAt := seekableOffset + keptTableStart
	if err := f.Truncate(truncateAt); err != nil {
		return fmt.Errorf("AppendToFile: truncate: %w", err)
	}
	if _, err := f.Seek(truncateAt, io.SeekStart); err != nil {
		return fmt.Errorf("AppendToFile: seek to truncate point: %w", err)
	}

	for _, frame := range newFrames {
		if _, err := f.Write(frame); err != nil {
			return fmt.Errorf("AppendToFile: write frame: %w", err)
		}
	}

	mergedEntries := make([]byte, len(keptEntries)+len(newEntries))
	copy(mergedEntries, keptEntries)
	copy(mergedEntries[len(keptEntries):], newEntries)

	if err := writeSeekTable(f, mergedEntries, entrySize); err != nil {
		return fmt.Errorf("AppendToFile: write seek table: %w", err)
	}

	return nil
}

type entityCollector map[SearchField]map[string]uint32

func (c entityCollector) add(field SearchField, value string) {
	v := strings.TrimSpace(value)
	if v == "" {
		return
	}
	m := c[field]
	if m == nil {
		m = make(map[string]uint32)
		c[field] = m
	}
	m[v]++
}

type sortedTermDict struct {
	keys [][]byte
	vals []uint64
}

func marshalSortedDict(keys []string, vals []uint64) []byte {
	if len(keys) == 0 {
		return nil
	}
	var buf bytes.Buffer
	var u [8]byte
	binary.LittleEndian.PutUint32(u[:4], uint32(len(keys)))
	buf.Write(u[:4])
	for i, k := range keys {
		binary.LittleEndian.PutUint32(u[:4], uint32(len(k)))
		buf.Write(u[:4])
		buf.WriteString(k)
		binary.LittleEndian.PutUint64(u[:8], vals[i])
		buf.Write(u[:8])
	}
	return buf.Bytes()
}

func parseSortedDict(blob []byte) (*sortedTermDict, error) {
	if len(blob) < 4 {
		return &sortedTermDict{}, nil
	}
	count := binary.LittleEndian.Uint32(blob[:4])

	const minEntrySize = 12
	if uint64(count) > uint64(len(blob)-4)/minEntrySize {
		return nil, fmt.Errorf("parseSortedDict: count %d exceeds blob size %d", count, len(blob))
	}
	pos := 4
	d := &sortedTermDict{keys: make([][]byte, 0, count), vals: make([]uint64, 0, count)}
	for i := uint32(0); i < count; i++ {
		if pos+4 > len(blob) {
			return nil, fmt.Errorf("parseSortedDict: truncated keyLen at %d", i)
		}
		kl := int(binary.LittleEndian.Uint32(blob[pos : pos+4]))
		pos += 4
		if pos+kl+8 > len(blob) {
			return nil, fmt.Errorf("parseSortedDict: truncated key/val at %d", i)
		}
		d.keys = append(d.keys, blob[pos:pos+kl])
		pos += kl
		d.vals = append(d.vals, binary.LittleEndian.Uint64(blob[pos:pos+8]))
		pos += 8
	}
	return d, nil
}

func (d *sortedTermDict) rangeScan(start, end []byte, fn func(key []byte, val uint64)) {
	i := sort.Search(len(d.keys), func(i int) bool { return bytes.Compare(d.keys[i], start) >= 0 })
	for ; i < len(d.keys) && (end == nil || bytes.Compare(d.keys[i], end) < 0); i++ {
		fn(d.keys[i], d.vals[i])
	}
}

func buildEntityFST(c entityCollector) ([]byte, error) {
	keyDF := make(map[string]uint32)
	for field, ents := range c {
		fp := string(field) + "\x00"
		for entity, df := range ents {
			for _, tok := range normalizeNoStem(entity) {
				key := fp + tok + "\x00" + entity
				if df > keyDF[key] {
					keyDF[key] = df
				}
			}
		}
	}
	if len(keyDF) == 0 {
		return nil, nil
	}
	keys := make([]string, 0, len(keyDF))
	for k := range keyDF {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	vals := make([]uint64, len(keys))
	for i, k := range keys {
		vals[i] = uint64(keyDF[k])
	}
	return marshalSortedDict(keys, vals), nil
}

func buildTypeaheadFSTBytes(blobs [][]byte) ([]byte, error) {
	var buf bytes.Buffer
	if err := buildTypeaheadFSTTo(&buf, blobs); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

func buildTypeaheadFSTTo(w io.Writer, blobs [][]byte) error {
	dicts := make([]*sortedTermDict, 0, len(blobs))
	for _, b := range blobs {
		if len(b) == 0 {
			continue
		}
		d, err := parseSortedDict(b)
		if err != nil {
			return fmt.Errorf("buildTypeaheadFST: %w", err)
		}
		dicts = append(dicts, d)
	}
	pos := make([]int, len(dicts))
	var keys []string
	var vals []uint64
	for {
		var minKey []byte
		for i, d := range dicts {
			if pos[i] >= len(d.keys) {
				continue
			}
			if minKey == nil || bytes.Compare(d.keys[pos[i]], minKey) < 0 {
				minKey = d.keys[pos[i]]
			}
		}
		if minKey == nil {
			break
		}
		var sum uint64
		for i, d := range dicts {
			if pos[i] < len(d.keys) && bytes.Equal(d.keys[pos[i]], minKey) {
				sum += d.vals[pos[i]]
				pos[i]++
			}
		}
		keys = append(keys, string(minKey))
		vals = append(vals, sum)
	}
	if _, err := w.Write(marshalSortedDict(keys, vals)); err != nil {
		return fmt.Errorf("buildTypeaheadFST: write: %w", err)
	}
	return nil
}

func (motwSearch *MotwSearch) LoadTypeaheadCached(cacheDir string) (TypeaheadIndex, error) {
	opened, err := motwSearch.Open()
	if err != nil {
		return nil, err
	}
	defer opened.Close()
	return opened.Typeahead(cacheDir)
}

// Typeahead keeps the original signature; all existing callers are
// unaffected. TypeaheadDetailed additionally reports which on-disk dict
// cache file was used and whether it was created by this call or adopted
// (reused) — the aggregate-serve path needs that to register the file in
// the cache identity ledger (ca-120).
func (opened *OpenedSearch) Typeahead(cacheDir string) (TypeaheadIndex, error) {
	ta, _, err := opened.TypeaheadDetailed(cacheDir)
	return ta, err
}

// TypeaheadCacheName is the single definition of the on-disk typeahead
// dict cache filename for a given index generation — the serve-side lease
// publication derives the expected name from the same function the writer
// uses, so the two can never drift.
func TypeaheadCacheName(baseGeneration [16]byte, generation uint64) string {
	return fmt.Sprintf("%x-%d.dict", baseGeneration, generation)
}

// TypeaheadCacheInfo describes the dict cache file TypeaheadDetailed used.
// Path is empty when no on-disk cache was involved (cacheDir == "" or the
// index carries no typeahead blobs).
type TypeaheadCacheInfo struct {
	Path    string
	Created bool // true: written by this call; false: adopted a pre-existing file
}

func (opened *OpenedSearch) TypeaheadDetailed(cacheDir string) (TypeaheadIndex, TypeaheadCacheInfo, error) {

	type src struct{ off, length uint64 }
	var srcs []src
	if opened.mf.TypeaheadLen > 0 {
		srcs = append(srcs, src{opened.mf.TypeaheadOff, opened.mf.TypeaheadLen})
	}
	for i := range opened.mf.Regions {
		if opened.mf.Regions[i].TypeaheadLen > 0 {
			srcs = append(srcs, src{opened.mf.Regions[i].TypeaheadOff, opened.mf.Regions[i].TypeaheadLen})
		}
	}

	if len(srcs) == 0 {
		return &vellumTypeaheadIndex{}, TypeaheadCacheInfo{}, nil
	}

	var cachePath string
	if cacheDir != "" {
		cacheName := TypeaheadCacheName(opened.mf.BaseGeneration, opened.mf.Generation)
		cachePath = filepath.Join(cacheDir, cacheName)
		if ta, err := openTypeaheadCache(cachePath); err == nil {
			return ta, TypeaheadCacheInfo{Path: cachePath, Created: false}, nil
		} else if !errors.Is(err, os.ErrNotExist) {

			os.Remove(cachePath)
		}
	}

	blobs := make([][]byte, 0, len(srcs))
	for _, s := range srcs {
		blob := make([]byte, s.length)
		if _, err := opened.rdr.ReadAt(blob, int64(s.off)); err != nil {
			return nil, TypeaheadCacheInfo{}, fmt.Errorf("Typeahead: read typeahead: %w", err)
		}
		blobs = append(blobs, blob)
	}

	if cachePath == "" {
		dicts := make([]*sortedTermDict, 0, len(blobs))
		for _, blob := range blobs {
			d, err := parseSortedDict(blob)
			if err != nil {
				return nil, TypeaheadCacheInfo{}, fmt.Errorf("Typeahead: %w", err)
			}
			dicts = append(dicts, d)
		}
		return &vellumTypeaheadIndex{dicts: dicts}, TypeaheadCacheInfo{}, nil
	}

	merged, err := buildTypeaheadFSTBytes(blobs)
	if err != nil {
		return nil, TypeaheadCacheInfo{}, fmt.Errorf("Typeahead: %w", err)
	}
	if len(merged) == 0 {
		return &vellumTypeaheadIndex{}, TypeaheadCacheInfo{}, nil
	}
	if err := os.MkdirAll(cacheDir, 0o755); err != nil {
		return nil, TypeaheadCacheInfo{}, fmt.Errorf("Typeahead: mkdir: %w", err)
	}
	tmp, err := os.CreateTemp(cacheDir, "typeahead-*.dict.tmp")
	if err != nil {
		return nil, TypeaheadCacheInfo{}, fmt.Errorf("Typeahead: create temp: %w", err)
	}
	tmpPath := tmp.Name()
	if _, err := tmp.Write(merged); err != nil {
		tmp.Close()
		os.Remove(tmpPath)
		return nil, TypeaheadCacheInfo{}, fmt.Errorf("Typeahead: write temp: %w", err)
	}
	if err := tmp.Close(); err != nil {
		os.Remove(tmpPath)
		return nil, TypeaheadCacheInfo{}, fmt.Errorf("Typeahead: close temp: %w", err)
	}
	if err := os.Rename(tmpPath, cachePath); err != nil {
		os.Remove(tmpPath)
		return nil, TypeaheadCacheInfo{}, fmt.Errorf("Typeahead: rename: %w", err)
	}
	ta, err := openTypeaheadCache(cachePath)
	return ta, TypeaheadCacheInfo{Path: cachePath, Created: true}, err
}

func openTypeaheadCache(path string) (*vellumTypeaheadIndex, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	mm, err := mmap.Map(f, mmap.RDONLY, 0)
	if err != nil {
		f.Close()
		return nil, fmt.Errorf("Typeahead: mmap cache: %w", err)
	}
	d, err := parseSortedDict(mm)
	if err != nil {
		mm.Unmap()
		f.Close()
		return nil, fmt.Errorf("Typeahead: parse cache: %w", err)
	}
	return &vellumTypeaheadIndex{dicts: []*sortedTermDict{d}, mm: mm, f: f}, nil
}

func containsAll(haystack, needles []string) bool {
	for _, n := range needles {
		found := false
		for _, h := range haystack {
			if h == n {
				found = true
				break
			}
		}
		if !found {
			return false
		}
	}
	return true
}

func AinB(a []string, b []string) bool {
	setB := make(map[string]struct{})
	for _, k := range b {
		setB[k] = struct{}{}
	}

	for _, e := range a {
		if _, found := setB[e]; !found {
			return false
		}
	}

	return true
}

func findBook(q SearchQuery, book Book) bool {
	queryTokens := normalizeAndTokenize(q.Text)
	switch q.Field {
	case FieldTag:
		for _, tag := range book.Tags {
			if AinB(queryTokens, normalizeAndTokenize(tag)) {
				return true
			}
		}
	case FieldAuthor:
		for _, author := range book.Authors {
			if AinB(queryTokens, normalizeAndTokenize(author)) {
				return true
			}
		}
	case FieldTitle:
		if AinB(queryTokens, normalizeAndTokenize(book.Title)) {
			return true
		}
	}
	return false
}

type seekableReader interface {
	ReadAt(p []byte, off int64) (int, error)
	Size() int64
	Close() error
}

type OpenedSearch struct {
	file          *os.File
	rdr           seekableReader
	dec           *zstd.Decoder
	mf            Manifest
	parent        *MotwSearch
	postingsCache []regionPostings

	pageOrderMu    sync.Mutex
	pageOrder      []displayRef
	pageOrderBuilt bool
}

type displayRef struct {
	lastModified string
	id           string
	absOff       int64
	length       int
}

type regionPostings struct {
	bytes   []byte
	entries []PostingsEntry
}

type bookMatch struct {
	regionIdx    int
	segment      int
	posInSeg     int
	score        float64
	lastModified int64
}

type bookMatchMinHeap struct {
	items    []bookMatch
	sortMode SortMode
}

func (h bookMatchMinHeap) Len() int      { return len(h.items) }
func (h bookMatchMinHeap) Swap(i, j int) { h.items[i], h.items[j] = h.items[j], h.items[i] }
func (h *bookMatchMinHeap) Push(x any)   { h.items = append(h.items, x.(bookMatch)) }
func (h *bookMatchMinHeap) Pop() any {
	old := h.items
	n := len(old)
	v := old[n-1]
	h.items = old[:n-1]
	return v
}

func rankBefore(a, b bookMatch, mode SortMode) bool {
	switch mode {
	case SortNewest:
		if a.lastModified != b.lastModified {
			return a.lastModified > b.lastModified
		}
	case SortOldest:
		if a.lastModified != b.lastModified {
			return a.lastModified < b.lastModified
		}
	default:
		if a.score != b.score {
			return a.score > b.score
		}
		if a.lastModified != b.lastModified {
			return a.lastModified > b.lastModified
		}
	}
	if a.regionIdx != b.regionIdx {
		return a.regionIdx < b.regionIdx
	}
	if a.segment != b.segment {
		return a.segment < b.segment
	}
	return a.posInSeg < b.posInSeg
}

func (h bookMatchMinHeap) Less(i, j int) bool {
	return rankBefore(h.items[j], h.items[i], h.sortMode)
}

func (h bookMatchMinHeap) beats(bm bookMatch) bool {
	return rankBefore(bm, h.items[0], h.sortMode)
}

func (ms *MotwSearch) Open() (*OpenedSearch, error) {
	f, err := os.Open(ms.IndexPath + ".zst")
	if err != nil {
		return nil, fmt.Errorf("Open: %w", err)
	}

	rdr, dec, mf, err := openMWSC(f)
	if err != nil {
		f.Close()
		return nil, fmt.Errorf("Open: %w", err)
	}

	postingsCache, err := loadPostingsCache(rdr, mf)
	if err != nil {
		_ = rdr.Close()
		_ = f.Close()
		dec.Close()
		return nil, fmt.Errorf("Open: %w", err)
	}

	return &OpenedSearch{
		file:          f,
		rdr:           rdr,
		dec:           dec,
		mf:            mf,
		parent:        ms,
		postingsCache: postingsCache,
	}, nil
}

func loadPostingsCache(rdr seekableReader, mf Manifest) ([]regionPostings, error) {
	cache := make([]regionPostings, len(mf.Regions))
	for regIdx, reg := range mf.Regions {
		if reg.PostingsLen == 0 || reg.PostingsMetaLen == 0 {
			continue
		}
		postingsBytes := make([]byte, reg.PostingsLen)
		if _, err := rdr.ReadAt(postingsBytes, int64(reg.PostingsOff)); err != nil {
			return nil, fmt.Errorf("loadPostingsCache: read postings (region %d): %w", regIdx, err)
		}
		postingsMetaBytes := make([]byte, reg.PostingsMetaLen)
		if _, err := rdr.ReadAt(postingsMetaBytes, int64(reg.PostingsMetaOff)); err != nil {
			return nil, fmt.Errorf("loadPostingsCache: read postings meta (region %d): %w", regIdx, err)
		}
		entries, err := decodePostingsMeta(postingsMetaBytes)
		if err != nil {
			return nil, fmt.Errorf("loadPostingsCache: decode postings meta (region %d): %w", regIdx, err)
		}
		cache[regIdx] = regionPostings{bytes: postingsBytes, entries: entries}
	}
	return cache, nil
}

func (opened *OpenedSearch) Close() error {
	var firstErr error
	opened.dec.Close()
	if err := opened.rdr.Close(); err != nil && firstErr == nil {
		firstErr = err
	}
	if err := opened.file.Close(); err != nil && firstErr == nil {
		firstErr = err
	}
	return firstErr
}

func seekTableStart(footer []byte, seekableLen int64) (tableStart int64, entrySize int, err error) {
	if len(footer) < seekTableFooterSize {
		return 0, 0, fmt.Errorf("seekTableStart: footer too short: %d", len(footer))
	}
	frameCount := binary.LittleEndian.Uint32(footer[0:4])
	flags := footer[4]
	magic := binary.LittleEndian.Uint32(footer[5:9])
	if magic != seekableMagicNumber {
		return 0, 0, fmt.Errorf("seekTableStart: magic mismatch: %#x", magic)
	}
	if flags&0b01111100 != 0 {
		return 0, 0, fmt.Errorf("seekTableStart: reserved footer flag bits set: %#x", flags)
	}
	entrySize = seekTableEntrySize8
	if flags&0x80 != 0 {
		entrySize = seekTableEntrySizeCksm
	}
	tableBodyLen := int64(frameCount) * int64(entrySize)
	skippableTotal := int64(4 + 4 + tableBodyLen + seekTableFooterSize)
	tableStart = seekableLen - skippableTotal
	if tableStart < 0 {
		return 0, 0, fmt.Errorf("seekTableStart: negative table start: %d", tableStart)
	}
	return tableStart, entrySize, nil
}

// readSeekTableEntries is a convenience wrapper over readSeekTableTail (the
// single seek-table parser) for callers holding the whole stream in memory.
func readSeekTableEntries(seekableBytes []byte) (entries []byte, entrySize int, tableStart int64, err error) {
	return readSeekTableTail(bytes.NewReader(seekableBytes), int64(len(seekableBytes)))
}

func writeSeekTable(w io.Writer, entries []byte, entrySize int) error {
	if int64(len(entries))+seekTableFooterSize > math.MaxUint32 {
		return fmt.Errorf("writeSeekTable: seek table too large (%d bytes)", len(entries))
	}
	frameCount := uint32(len(entries) / entrySize)
	skippableFrameSize := uint32(len(entries) + seekTableFooterSize)
	var hdr [8]byte
	binary.LittleEndian.PutUint32(hdr[0:4], skippableFrameMagic+seekableTag)
	binary.LittleEndian.PutUint32(hdr[4:8], skippableFrameSize)
	if _, err := w.Write(hdr[:]); err != nil {
		return err
	}
	if _, err := w.Write(entries); err != nil {
		return err
	}
	var footer [seekTableFooterSize]byte
	binary.LittleEndian.PutUint32(footer[0:4], frameCount)
	if entrySize == seekTableEntrySizeCksm {
		footer[4] = 0x80
	}
	binary.LittleEndian.PutUint32(footer[5:9], seekableMagicNumber)
	_, err := w.Write(footer[:])
	return err
}

type MemberContainerData struct {
	DictEntry   DictCatalogEntry
	SeekEntries []byte
	EntrySize   int
	Regions     []ManifestRegion
	Manifest    Manifest
	Typeahead   []byte

	FrameSrc string
	FrameOff int64
	FrameLen int64
}

func ExtractMemberContainer(path string) (*MemberContainerData, error) {
	f, err := os.Open(path + ".zst")
	if err != nil {
		return nil, fmt.Errorf("ExtractMemberContainer: open: %w", err)
	}
	defer f.Close()

	dictCatalog, seekableOffset, err := readContainerHeader(f)
	if err != nil {
		return nil, fmt.Errorf("ExtractMemberContainer: %w", err)
	}

	fileSize, err := f.Seek(0, io.SeekEnd)
	if err != nil {
		return nil, fmt.Errorf("ExtractMemberContainer: seek: %w", err)
	}
	seekableLen := fileSize - seekableOffset
	seekableBytes := make([]byte, seekableLen)
	if _, err := f.ReadAt(seekableBytes, seekableOffset); err != nil {
		return nil, fmt.Errorf("ExtractMemberContainer: read seekable: %w", err)
	}

	entries, entrySize, tableStart, err := readSeekTableEntries(seekableBytes)
	if err != nil {
		return nil, fmt.Errorf("ExtractMemberContainer: %w", err)
	}

	var decOpts []zstd.DOption
	for _, entry := range dictCatalog {
		decOpts = append(decOpts, zstd.WithDecoderDictRaw(entry.DictID, entry.DictBytes))
	}
	// Cap per-DecodeAll memory: a hostile zstd frame header's declared
	// content size must not drive allocations past the reader's frame cap.
	decOpts = append(decOpts, zstd.WithDecoderMaxMemory(maxDecoderFrameSize))
	dec, err := zstd.NewReader(nil, decOpts...)
	if err != nil {
		return nil, fmt.Errorf("ExtractMemberContainer: zstd reader: %w", err)
	}
	defer dec.Close()

	rdr, err := newMWSCReaderAt(bytes.NewReader(seekableBytes), int64(len(seekableBytes)), dec)
	if err != nil {
		return nil, fmt.Errorf("ExtractMemberContainer: seekable decoder: %w", err)
	}
	mf, err := readManifestFromDecoder(rdr)
	if err != nil {
		rdr.Close()
		return nil, fmt.Errorf("ExtractMemberContainer: %w", err)
	}

	cutSafe := true
	for i := range mf.Regions {
		if mf.Regions[i].sectionsEnd() > mf.TypeaheadOff {
			cutSafe = false
			break
		}
	}
	var typeaheadBlobs [][]byte
	if mf.TypeaheadLen > 0 {
		blob := make([]byte, mf.TypeaheadLen)
		if _, err := rdr.ReadAt(blob, int64(mf.TypeaheadOff)); err != nil {
			rdr.Close()
			return nil, fmt.Errorf("ExtractMemberContainer: read typeahead: %w", err)
		}
		typeaheadBlobs = append(typeaheadBlobs, blob)
	}
	for i := range mf.Regions {
		if mf.Regions[i].TypeaheadLen == 0 {
			continue
		}
		blob := make([]byte, mf.Regions[i].TypeaheadLen)
		if _, err := rdr.ReadAt(blob, int64(mf.Regions[i].TypeaheadOff)); err != nil {
			rdr.Close()
			return nil, fmt.Errorf("ExtractMemberContainer: read region %d typeahead: %w", i, err)
		}
		typeaheadBlobs = append(typeaheadBlobs, blob)

		mf.Regions[i].TypeaheadOff = 0
		mf.Regions[i].TypeaheadLen = 0
	}

	cutAt := mf.TypeaheadOff
	if !cutSafe {
		cutAt = 0
		if ms, msErr := manifestSpanStart(rdr); msErr == nil {
			cutAt = ms
		}
	}
	rdr.Close()

	var typeahead []byte
	if len(typeaheadBlobs) == 1 {
		typeahead = typeaheadBlobs[0]
	} else if len(typeaheadBlobs) > 1 {
		typeahead, err = buildTypeaheadFSTBytes(typeaheadBlobs)
		if err != nil {
			return nil, fmt.Errorf("ExtractMemberContainer: merge typeaheads: %w", err)
		}
	}

	var dictEntry DictCatalogEntry
	if len(dictCatalog) > 0 {
		dictEntry = dictCatalog[0]
	}

	frameLen := tableStart
	keptEntries := entries
	if cutAt > 0 {
		if keptComp, keptLen, aligned := keptFrameSpan(entries, entrySize, cutAt); aligned {
			frameLen = keptComp
			keptEntries = entries[:keptLen]
		}
	}

	return &MemberContainerData{
		DictEntry:   dictEntry,
		SeekEntries: keptEntries,
		EntrySize:   entrySize,
		Regions:     mf.Regions,
		Manifest:    mf,
		Typeahead:   typeahead,
		FrameSrc:    path + ".zst",
		FrameOff:    seekableOffset,
		FrameLen:    frameLen,
	}, nil
}

func (r *ManifestRegion) sectionsEnd() uint64 {
	var end uint64
	for _, s := range [][2]uint64{
		{r.SearchIndexOff, r.SearchIndexLen},
		{r.DisplayIndexOff, r.DisplayIndexLen},
		{r.PostingsOff, r.PostingsLen},
		{r.PostingsMetaOff, r.PostingsMetaLen},
		{r.DocLengthsOff, r.DocLengthsLen},
		{r.SearchableOff, r.SearchableLen},
		{r.DisplayOff, r.DisplayLen},
		{r.FSTOff, r.FSTLen},
		{r.FingerprintsOff, r.FingerprintsLen},
		{r.TypeaheadOff, r.TypeaheadLen},
	} {
		if s[1] > 0 && s[0]+s[1] > end {
			end = s[0] + s[1]
		}
	}
	return end
}

func keptFrameSpan(entries []byte, entrySize int, typeaheadOff uint64) (keptCompLen int64, keptEntriesLen int, aligned bool) {
	if typeaheadOff == 0 || entrySize < 8 {
		return 0, 0, false
	}
	var cumComp, cumUncomp uint64
	for off := 0; off+entrySize <= len(entries); off += entrySize {
		if cumUncomp == typeaheadOff {
			return int64(cumComp), off, true
		}
		cumComp += uint64(binary.LittleEndian.Uint32(entries[off : off+4]))
		cumUncomp += uint64(binary.LittleEndian.Uint32(entries[off+4 : off+8]))
	}
	return 0, 0, false
}

func FilesBaseURL(prefix string) (baseURL, libURL string) {
	baseURL = "/files/" + prefix
	return baseURL, baseURL + "/"
}

func PrefixFromBaseURL(baseURL string) string {
	return strings.TrimSuffix(strings.TrimPrefix(baseURL, "/files/"), "/")
}

type memberRecencyHandle struct {
	f   *os.File
	rdr seekableReader
	dec *zstd.Decoder
}

func (h *memberRecencyHandle) close() {
	if h.rdr != nil {
		h.rdr.Close()
	}
	if h.dec != nil {
		h.dec.Close()
	}
	if h.f != nil {
		h.f.Close()
	}
}

func openMemberForRecency(m *MemberContainerData) (*memberRecencyHandle, error) {
	f, err := os.Open(m.FrameSrc)
	if err != nil {
		return nil, err
	}
	rdr, dec, _, err := openMWSC(f)
	if err != nil {
		f.Close()
		return nil, err
	}
	return &memberRecencyHandle{f: f, rdr: rdr, dec: dec}, nil
}

func buildAggregateRecency(members []*MemberContainerData, memberBases []uint64, allTombstones [][16]byte) []RecencyEntry {
	tombstoneSet := make(map[[16]byte]struct{}, len(allTombstones))
	for _, ts := range allTombstones {
		tombstoneSet[ts] = struct{}{}
	}
	var recencyRefs []RecencyEntry
	for mi, m := range members {
		base := memberBases[mi]

		if len(m.Manifest.RecencyIndex) > 0 {
			for _, e := range m.Manifest.RecencyIndex {
				if e.Id != "" && len(tombstoneSet) > 0 {
					if ts, perr := bookIDToTombstone(e.Id); perr == nil {
						if _, dead := tombstoneSet[ts]; dead {
							continue
						}
					}
				}
				recencyRefs = append(recencyRefs, RecencyEntry{
					LastModified: e.LastModified,
					Id:           e.Id,
					AbsOff:       int64(base) + e.AbsOff,
					Length:       e.Length,
				})
			}
			continue
		}

		mf, err := openMemberForRecency(m)
		if err != nil {
			fmt.Fprintf(os.Stderr, "aggregate-build: recency index abandoned — open member %d: %v (front page falls back to serve-time scan)\n", mi, err)
			return nil
		}
		abort := func() []RecencyEntry {
			mf.close()
			fmt.Fprintf(os.Stderr, "aggregate-build: recency index abandoned — read member %d (front page falls back to serve-time scan)\n", mi)
			return nil
		}
		for _, reg := range m.Regions {
			if reg.DisplayIndexLen == 0 || reg.DisplayLen == 0 {
				continue
			}
			displayIdxBytes := make([]byte, reg.DisplayIndexLen)
			if _, err := mf.rdr.ReadAt(displayIdxBytes, int64(reg.DisplayIndexOff)); err != nil {
				return abort()
			}
			displayIdx := make([]uint32, len(displayIdxBytes)/4)
			if err := binary.Read(bytes.NewReader(displayIdxBytes), binary.LittleEndian, &displayIdx); err != nil {
				return abort()
			}
			for seg := 0; seg < len(displayIdx); seg++ {
				var segStart int64
				if seg > 0 {
					segStart = int64(displayIdx[seg-1])
				}
				segEnd := int64(displayIdx[seg])
				segBytes := make([]byte, segEnd-segStart)
				if _, err := mf.rdr.ReadAt(segBytes, int64(reg.DisplayOff)+segStart); err != nil && !errors.Is(err, io.EOF) {
					return abort()
				}
				var pos int64
				for pos < int64(len(segBytes)) {
					nl := bytes.IndexByte(segBytes[pos:], '\n')
					var line []byte
					if nl < 0 {
						line = segBytes[pos:]
					} else {
						line = segBytes[pos : pos+int64(nl)]
					}
					lineOff := int64(reg.DisplayOff) + segStart + pos
					if nl < 0 {
						pos = int64(len(segBytes))
					} else {
						pos += int64(nl) + 1
					}
					if len(line) == 0 {
						continue
					}
					var meta struct {
						Id           string `json:"_id"`
						LastModified string `json:"last_modified"`
					}
					if err := json.Unmarshal(line, &meta); err != nil {
						continue
					}
					if meta.Id != "" && len(tombstoneSet) > 0 {
						if ts, perr := bookIDToTombstone(meta.Id); perr == nil {
							if _, dead := tombstoneSet[ts]; dead {
								continue
							}
						}
					}

					recencyRefs = append(recencyRefs, RecencyEntry{
						LastModified: meta.LastModified,
						Id:           meta.Id,
						AbsOff:       int64(base) + lineOff,
						Length:       int32(len(line)),
					})
				}
			}
		}
		mf.close()
	}
	sort.Slice(recencyRefs, func(i, j int) bool {
		if recencyRefs[i].LastModified != recencyRefs[j].LastModified {
			return recencyRefs[i].LastModified > recencyRefs[j].LastModified
		}
		return recencyRefs[i].Id < recencyRefs[j].Id
	})
	return recencyRefs
}

func streamMemberFrames(w io.Writer, m *MemberContainerData) error {
	f, err := os.Open(m.FrameSrc)
	if err != nil {
		return fmt.Errorf("streamMemberFrames: open %s: %w", m.FrameSrc, err)
	}
	defer f.Close()
	n, err := io.Copy(w, io.NewSectionReader(f, m.FrameOff, m.FrameLen))
	if err != nil {
		return fmt.Errorf("streamMemberFrames: copy %s: %w", m.FrameSrc, err)
	}
	if n != m.FrameLen {
		return fmt.Errorf("streamMemberFrames: short copy %s: wrote %d of %d", m.FrameSrc, n, m.FrameLen)
	}
	return nil
}

func (r *ManifestRegion) shiftOffsets(delta uint64) {
	r.SearchIndexOff += delta
	r.DisplayIndexOff += delta
	r.PostingsOff += delta
	r.PostingsMetaOff += delta
	r.DocLengthsOff += delta
	r.SearchableOff += delta
	r.DisplayOff += delta
	r.FSTOff += delta
	r.FingerprintsOff += delta

	if r.TypeaheadLen > 0 {
		r.TypeaheadOff += delta
	}
}

func ComposeAggregate(outputPath string, members []*MemberContainerData, baseGen [16]byte, generation uint64, opts ComposeOpts) error {
	if len(members) == 0 {
		return fmt.Errorf("ComposeAggregate: no members to compose")
	}
	var (
		allDicts      []DictCatalogEntry
		allEntries    []byte
		allRegions    []ManifestRegion
		allTombstones [][16]byte
		allTypeaheads [][]byte
		entrySize     int
		totalBooks    uint32
		totalSegs     uint32
		uncompOffset  uint64
	)

	dictSeen := make(map[uint32]bool)
	memberBases := make([]uint64, len(members))

	for mi, m := range members {
		if m.DictEntry.DictID != 0 {
			if dictSeen[m.DictEntry.DictID] {
				return fmt.Errorf("ComposeAggregate: DictID %d collision — members share the same DictID; rebuild with unique per-member DictIDs", m.DictEntry.DictID)
			}
			allDicts = append(allDicts, m.DictEntry)
			dictSeen[m.DictEntry.DictID] = true
		}
		if entrySize == 0 {
			entrySize = m.EntrySize
		} else if m.EntrySize != entrySize {
			return fmt.Errorf("ComposeAggregate: seek-table entry size mismatch: %d vs %d", entrySize, m.EntrySize)
		}

		memberUncompSize := memberUncompressedSize(m)
		memberBases[mi] = uncompOffset

		for _, r := range m.Regions {
			adjusted := r
			adjusted.shiftOffsets(uncompOffset)
			if adjusted.DictID == 0 {
				adjusted.DictID = m.DictEntry.DictID
			}
			allRegions = append(allRegions, adjusted)
		}
		uncompOffset += memberUncompSize

		allEntries = append(allEntries, m.SeekEntries...)
		totalBooks += m.Manifest.NumBooks
		totalSegs += m.Manifest.NumSegments
		allTombstones = append(allTombstones, m.Manifest.Tombstones...)

		if len(m.Typeahead) > 0 {
			allTypeaheads = append(allTypeaheads, m.Typeahead)
		}
	}

	if entrySize == 0 {
		entrySize = seekTableEntrySizeCksm
	}

	var entityProvenance [][2]uint64
	var priorTypeaheadBytes []byte
	if len(allTypeaheads) > 0 {
		entityProvenance = make([][2]uint64, 0, len(allTypeaheads))
		for _, ta := range allTypeaheads {
			entityProvenance = append(entityProvenance, [2]uint64{xxhash.Sum64(ta), uint64(len(ta))})
		}
		sort.Slice(entityProvenance, func(i, j int) bool {
			if entityProvenance[i][0] != entityProvenance[j][0] {
				return entityProvenance[i][0] < entityProvenance[j][0]
			}
			return entityProvenance[i][1] < entityProvenance[j][1]
		})

		if opts.PriorAggregatePath != "" {
			priorMf, priorErr := ReadExistingManifest(opts.PriorAggregatePath)
			if priorErr == nil && priorMf.TypeaheadLen > 0 && len(priorMf.EntityProvenance) > 0 && slices.Equal(entityProvenance, priorMf.EntityProvenance) {
				priorF, err := os.Open(opts.PriorAggregatePath + ".zst")
				if err == nil {
					priorRdr, priorDec, _, rErr := openMWSC(priorF)
					if rErr == nil {
						priorTA := make([]byte, priorMf.TypeaheadLen)
						if _, err := priorRdr.ReadAt(priorTA, int64(priorMf.TypeaheadOff)); err == nil {
							priorTypeaheadBytes = priorTA
						}
						priorRdr.Close()
						priorDec.Close()
					}
					priorF.Close()
				}
			}
		}
	}

	catSize := dictCatalogSize(allDicts)
	outPath := outputPath + ".zst"
	fw, err := os.Create(outPath)
	if err != nil {
		return fmt.Errorf("ComposeAggregate: create: %w", err)
	}
	defer fw.Close()
	success := false
	defer func() {
		if !success {
			os.Remove(outPath)
		}
	}()

	if _, err := fw.Write([]byte(containerMagic)); err != nil {
		return fmt.Errorf("ComposeAggregate: write magic: %w", err)
	}
	if _, err := fw.Write([]byte{containerVersion}); err != nil {
		return fmt.Errorf("ComposeAggregate: write version: %w", err)
	}
	if err := binary.Write(fw, binary.LittleEndian, catSize); err != nil {
		return fmt.Errorf("ComposeAggregate: write catalog size: %w", err)
	}
	if err := writeDictCatalog(fw, allDicts); err != nil {
		return fmt.Errorf("ComposeAggregate: %w", err)
	}

	for _, m := range members {
		if err := streamMemberFrames(fw, m); err != nil {
			return fmt.Errorf("ComposeAggregate: %w", err)
		}
	}

	recencyRefs := buildAggregateRecency(members, memberBases, allTombstones)

	var encOpts []zstd.EOption
	encOpts = append(encOpts, zstd.WithEncoderLevel(zstd.SpeedBestCompression))
	if len(allDicts) > 0 {
		encOpts = append(encOpts, zstd.WithEncoderDictRaw(allDicts[0].DictID, allDicts[0].DictBytes))
	}
	enc, err := zstd.NewWriter(nil, encOpts...)
	if err != nil {
		return fmt.Errorf("ComposeAggregate: zstd encoder: %w", err)
	}
	defer enc.Close()

	writeAggFrame := func(payload []byte) (uint64, error) {
		// These sections are written as single unchunked frames; the reader
		// rejects frames over maxDecoderFrameSize, so fail loudly at build
		// time instead of producing an index the same binary cannot open.
		if len(payload) > maxDecoderFrameSize {
			return 0, fmt.Errorf("aggregate frame of %d bytes exceeds the %d-byte reader frame cap; this section must be chunked", len(payload), maxDecoderFrameSize)
		}
		comp := enc.EncodeAll(payload, nil)
		if _, err := fw.Write(comp); err != nil {
			return 0, err
		}
		var e [seekTableEntrySizeCksm]byte
		binary.LittleEndian.PutUint32(e[0:4], uint32(len(comp)))
		binary.LittleEndian.PutUint32(e[4:8], uint32(len(payload)))
		if entrySize == seekTableEntrySizeCksm {
			binary.LittleEndian.PutUint32(e[8:12], uint32((xxhash.Sum64(payload)<<32)>>32))
		}
		allEntries = append(allEntries, e[:entrySize]...)
		return uint64(len(payload)), nil
	}

	var typeaheadOff, typeaheadLen uint64
	if len(allTypeaheads) > 0 {
		if len(priorTypeaheadBytes) > 0 {
			typeaheadOff = uncompOffset
			n, wErr := writeAggFrame(priorTypeaheadBytes)
			if wErr != nil {
				return fmt.Errorf("ComposeAggregate: write reused typeahead frame: %w", wErr)
			}
			typeaheadLen = n
			uncompOffset += n
			fmt.Fprintf(os.Stderr, "aggregate-build: typeahead unchanged — reusing prior merge\n")
		} else {
			taFile, err := os.CreateTemp(filepath.Dir(outputPath), "agg-typeahead-*.fst")
			if err != nil {
				return fmt.Errorf("ComposeAggregate: typeahead temp: %w", err)
			}
			taPath := taFile.Name()
			defer os.Remove(taPath)
			if err := buildTypeaheadFSTTo(taFile, allTypeaheads); err != nil {
				taFile.Close()
				return fmt.Errorf("ComposeAggregate: merge typeahead: %w", err)
			}
			taFile.Close()

			allTypeaheads = nil
			for _, m := range members {
				m.Typeahead = nil
			}

			mergedTA, err := os.ReadFile(taPath)
			if err != nil {
				return fmt.Errorf("ComposeAggregate: read typeahead: %w", err)
			}
			typeaheadOff = uncompOffset
			n, err := writeAggFrame(mergedTA)
			if err != nil {
				return fmt.Errorf("ComposeAggregate: write typeahead frame: %w", err)
			}
			typeaheadLen = n
			uncompOffset += n
		}
	}

	mf := Manifest{
		FormatTag:        manifestFormatTag,
		ChunkSize:        members[0].Manifest.ChunkSize,
		NumSegments:      totalSegs,
		NumBooks:         totalBooks,
		BaseGeneration:   baseGen,
		Generation:       generation,
		TypeaheadOff:     typeaheadOff,
		TypeaheadLen:     typeaheadLen,
		Regions:          allRegions,
		Tombstones:       allTombstones,
		EntityProvenance: entityProvenance,
		RecencyIndex:     recencyRefs,
	}
	manifestPayload, err := encodeManifest(mf)
	if err != nil {
		return fmt.Errorf("ComposeAggregate: encode manifest: %w", err)
	}
	var manifestWithFooter bytes.Buffer
	manifestWithFooter.Write(manifestPayload)
	binary.Write(&manifestWithFooter, binary.LittleEndian, uint32(len(manifestPayload)))
	binary.Write(&manifestWithFooter, binary.LittleEndian, manifestMagic)
	if _, err := writeAggFrame(manifestWithFooter.Bytes()); err != nil {
		return fmt.Errorf("ComposeAggregate: write manifest frame: %w", err)
	}

	if err := writeSeekTable(fw, allEntries, entrySize); err != nil {
		return fmt.Errorf("ComposeAggregate: write seek table: %w", err)
	}

	success = true
	return nil
}

func memberUncompressedSize(m *MemberContainerData) uint64 {
	var total uint64
	for off := 0; off < len(m.SeekEntries); off += m.EntrySize {
		decompSize := binary.LittleEndian.Uint32(m.SeekEntries[off+4 : off+8])
		total += uint64(decompSize)
	}
	return total
}

func bookIDToTombstone(bookID string) ([16]byte, error) {
	u, err := uuid.Parse(bookID)
	if err != nil {
		return [16]byte{}, fmt.Errorf("bookIDToTombstone: %w", err)
	}
	return [16]byte(u), nil
}

func BookIDToTombstone(bookID string) ([16]byte, error) {
	return bookIDToTombstone(bookID)
}

func DiffBooks(currentBooks []*Book, existingDisplayJSONL io.Reader) (delta []*Book, tombstones [][16]byte, err error) {
	currentByID := make(map[string]*Book, len(currentBooks))
	for _, b := range currentBooks {
		if b.Id == "" {
			continue
		}
		currentByID[b.Id] = b
	}

	existingIDs := make(map[string]struct{})
	scanner := bufio.NewScanner(existingDisplayJSONL)
	scanner.Buffer(make([]byte, 1<<20), 1<<20)
	for scanner.Scan() {
		line := scanner.Bytes()
		if len(line) == 0 {
			continue
		}
		var stub struct {
			Id string `json:"_id"`
		}
		if err := json.Unmarshal(line, &stub); err != nil {
			return nil, nil, fmt.Errorf("diffBooks: unmarshal existing: %w", err)
		}
		if stub.Id == "" {
			continue
		}
		existingIDs[stub.Id] = struct{}{}
	}
	if err := scanner.Err(); err != nil {
		return nil, nil, fmt.Errorf("diffBooks: scan existing: %w", err)
	}

	for id, book := range currentByID {
		if _, exists := existingIDs[id]; !exists {
			delta = append(delta, book)
		}
	}

	for id := range existingIDs {
		if _, exists := currentByID[id]; !exists {
			ts, err := bookIDToTombstone(id)
			if err != nil {
				return nil, nil, fmt.Errorf("diffBooks: tombstone for deleted %s: %w", id, err)
			}
			tombstones = append(tombstones, ts)
		}
	}

	return delta, tombstones, nil
}

func ReadDisplayJSONL(indexPath string) ([]byte, error) {
	zstPath := indexPath + ".zst"
	f, err := os.Open(zstPath)
	if err != nil {
		return nil, fmt.Errorf("ReadDisplayJSONL: open: %w", err)
	}
	defer f.Close()

	rdr, dec, mf, err := openMWSC(f)
	if err != nil {
		return nil, fmt.Errorf("ReadDisplayJSONL: %w", err)
	}
	defer rdr.Close()
	defer dec.Close()

	var buf bytes.Buffer
	for i, reg := range mf.Regions {
		data := make([]byte, reg.DisplayLen)
		if _, err := rdr.ReadAt(data, int64(reg.DisplayOff)); err != nil && err != io.EOF {
			return nil, fmt.Errorf("ReadDisplayJSONL: read region %d display: %w", i, err)
		}
		buf.Write(data)
	}
	return buf.Bytes(), nil
}

func AllBooksFromIndex(indexPath string) ([]*Book, error) {
	ms := &MotwSearch{IndexPath: indexPath}
	opened, err := ms.Open()
	if err != nil {
		return nil, fmt.Errorf("AllBooksFromIndex: open: %w", err)
	}
	tombstoneSet := make(map[[16]byte]struct{}, len(opened.mf.Tombstones))
	for _, ts := range opened.mf.Tombstones {
		tombstoneSet[ts] = struct{}{}
	}
	_ = opened.Close()

	raw, err := ReadDisplayJSONL(indexPath)
	if err != nil {
		return nil, err
	}
	byID := make(map[string]*Book)
	var order []string
	scanner := bufio.NewScanner(bytes.NewReader(raw))
	scanner.Buffer(make([]byte, 1<<20), 1<<24)
	for scanner.Scan() {
		line := bytes.TrimSpace(scanner.Bytes())
		if len(line) == 0 {
			continue
		}
		var b Book
		if err := json.Unmarshal(line, &b); err != nil {
			return nil, fmt.Errorf("AllBooksFromIndex: unmarshal: %w", err)
		}
		if b.Id == "" {
			continue
		}
		if len(tombstoneSet) > 0 {
			if ts, perr := bookIDToTombstone(b.Id); perr == nil {
				if _, dead := tombstoneSet[ts]; dead {
					continue
				}
			}
		}
		if _, seen := byID[b.Id]; !seen {
			order = append(order, b.Id)
		}
		bc := b
		byID[b.Id] = &bc
	}
	if err := scanner.Err(); err != nil {
		return nil, fmt.Errorf("AllBooksFromIndex: scan: %w", err)
	}
	books := make([]*Book, 0, len(order))
	for _, id := range order {
		books = append(books, byID[id])
	}
	return books, nil
}

func FilteredDisplayJSONL(indexPath string) ([]byte, Manifest, error) {
	zstPath := indexPath + ".zst"
	f, err := os.Open(zstPath)
	if err != nil {
		return nil, Manifest{}, fmt.Errorf("FilteredDisplayJSONL: open: %w", err)
	}
	defer f.Close()

	rdr, dec, mf, err := openMWSC(f)
	if err != nil {
		return nil, Manifest{}, fmt.Errorf("FilteredDisplayJSONL: %w", err)
	}
	defer rdr.Close()
	defer dec.Close()

	var raw bytes.Buffer
	for i, reg := range mf.Regions {
		data := make([]byte, reg.DisplayLen)
		if _, err := rdr.ReadAt(data, int64(reg.DisplayOff)); err != nil && err != io.EOF {
			return nil, Manifest{}, fmt.Errorf("FilteredDisplayJSONL: read region %d display: %w", i, err)
		}
		raw.Write(data)
	}

	tombstoneSet := make(map[[16]byte]struct{}, len(mf.Tombstones))
	for _, ts := range mf.Tombstones {
		tombstoneSet[ts] = struct{}{}
	}

	lineByID := make(map[string][]byte)
	var order []string
	scanner := bufio.NewScanner(bytes.NewReader(raw.Bytes()))
	scanner.Buffer(make([]byte, 1<<20), 1<<24)
	for scanner.Scan() {
		line := bytes.TrimSpace(scanner.Bytes())
		if len(line) == 0 {
			continue
		}
		var b Book
		if err := json.Unmarshal(line, &b); err != nil {
			return nil, Manifest{}, fmt.Errorf("FilteredDisplayJSONL: unmarshal: %w", err)
		}
		if b.Id == "" {
			continue
		}
		if len(tombstoneSet) > 0 {
			if ts, perr := bookIDToTombstone(b.Id); perr == nil {
				if _, dead := tombstoneSet[ts]; dead {
					continue
				}
			}
		}
		if _, seen := lineByID[b.Id]; !seen {
			order = append(order, b.Id)
		}
		cp := make([]byte, len(line))
		copy(cp, line)
		lineByID[b.Id] = cp
	}
	if err := scanner.Err(); err != nil {
		return nil, Manifest{}, fmt.Errorf("FilteredDisplayJSONL: scan: %w", err)
	}

	var out bytes.Buffer
	for _, id := range order {
		out.Write(lineByID[id])
		out.WriteByte('\n')
	}
	return out.Bytes(), mf, nil
}

func ReadContainerVersion(indexPath string) (byte, error) {
	f, err := os.Open(indexPath + ".zst")
	if err != nil {
		return 0, fmt.Errorf("ReadContainerVersion: open: %w", err)
	}
	defer f.Close()

	var hdr [5]byte
	if _, err := io.ReadFull(f, hdr[:]); err != nil {
		return 0, fmt.Errorf("ReadContainerVersion: read header: %w", err)
	}
	if string(hdr[:4]) != containerMagic {
		return 0, fmt.Errorf("ReadContainerVersion: bad magic %q", string(hdr[:4]))
	}
	return hdr[4], nil
}

func ReadExistingManifest(indexPath string) (Manifest, error) {
	return ReadManifestFromZst(indexPath + ".zst")
}

func ReadManifestFromZst(zstPath string) (Manifest, error) {
	f, err := os.Open(zstPath)
	if err != nil {
		return Manifest{}, fmt.Errorf("ReadManifestFromZst: open: %w", err)
	}
	defer f.Close()

	rdr, dec, mf, err := openMWSC(f)
	if err != nil {
		return Manifest{}, fmt.Errorf("ReadManifestFromZst: %w", err)
	}
	rdr.Close()
	dec.Close()
	return mf, nil
}

func openMWSC(f *os.File) (seekableReader, *zstd.Decoder, Manifest, error) {
	dictCatalog, seekableOffset, err := readContainerHeader(f)
	if err != nil {
		return nil, nil, Manifest{}, err
	}

	var decOpts []zstd.DOption
	for _, entry := range dictCatalog {
		decOpts = append(decOpts, zstd.WithDecoderDictRaw(entry.DictID, entry.DictBytes))
	}
	// Cap per-DecodeAll memory: a hostile zstd frame header's declared
	// content size must not drive allocations past the reader's frame cap.
	decOpts = append(decOpts, zstd.WithDecoderMaxMemory(maxDecoderFrameSize))
	dec, err := zstd.NewReader(nil, decOpts...)
	if err != nil {
		return nil, nil, Manifest{}, fmt.Errorf("openMWSC: zstd reader: %w", err)
	}

	fileSize, err := f.Seek(0, io.SeekEnd)
	if err != nil {
		dec.Close()
		return nil, nil, Manifest{}, fmt.Errorf("openMWSC: seek: %w", err)
	}
	seekableStreamSize := fileSize - seekableOffset
	sr := io.NewSectionReader(f, seekableOffset, seekableStreamSize)

	rdr, err := newMWSCReaderAt(sr, seekableStreamSize, dec)
	if err != nil {
		dec.Close()
		return nil, nil, Manifest{}, fmt.Errorf("openMWSC: seekable decoder: %w", err)
	}

	mf, err := readManifestFromDecoder(rdr)
	if err != nil {
		rdr.Close()
		dec.Close()
		return nil, nil, Manifest{}, err
	}

	return rdr, dec, mf, nil
}

func fieldPrefixRange(field SearchField, prefix string) (start, end []byte) {
	key := postingsMetaKey(field, prefix)
	return []byte(key), append([]byte(key), 0xff)
}

func fieldRange(field SearchField) (start, end []byte) {
	return []byte(string(field) + "\x00"), []byte(string(field) + "\x01")
}

func comparePostingsMetaKey(field SearchField, term, key string) int {
	f := string(field)
	n := min(len(f), len(key))
	if c := strings.Compare(f[:n], key[:n]); c != 0 {
		return c
	}
	if len(f) > len(key) {
		return 1
	}
	rest := key[len(f):]
	if len(rest) == 0 {
		return 1
	}
	if rest[0] != 0 {
		return -1
	}
	return strings.Compare(term, rest[1:])
}

func expandPostingsRange(postingsBytes []byte, entries []PostingsEntry,
	startKey, endKey []byte, accept func(term string) bool) (*roaring.Bitmap, uint32, error) {

	startStr := string(startKey)
	endStr := string(endKey)
	lo := sort.Search(len(entries), func(j int) bool {
		return comparePostingsMetaKey(entries[j].Field, entries[j].Term, startStr) >= 0
	})
	result := roaring.New()
	for j := lo; j < len(entries); j++ {
		if endKey != nil && comparePostingsMetaKey(entries[j].Field, entries[j].Term, endStr) >= 0 {
			break
		}
		if accept == nil || accept(entries[j].Term) {
			bm := roaring.New()
			if _, err := bm.ReadFrom(bytes.NewReader(
				postingsBytes[entries[j].Offset : entries[j].Offset+uint64(entries[j].Length)])); err != nil {
				return nil, 0, fmt.Errorf("expandPostingsRange: read bitmap: %w", err)
			}
			result.Or(bm)
		}
	}
	return result, uint32(result.GetCardinality()), nil
}

func containsAnyPrefix(haystack []string, prefix string) bool {
	for _, h := range haystack {
		if strings.HasPrefix(h, prefix) {
			return true
		}
	}
	return false
}

func containsAnyFuzzy(haystack []string, dfa *levenshtein.DFA) bool {
	for _, h := range haystack {
		if match, _ := dfa.MatchAndDistance(h); match {
			return true
		}
	}
	return false
}

func intersectPostings(postingsBytes []byte, entries []PostingsEntry, field SearchField, queryTokens []string) ([]int, []uint32, error) {
	dfPerToken := make([]uint32, len(queryTokens))

	var resultBitmap *roaring.Bitmap
	for i, token := range queryTokens {
		targetKey := postingsMetaKey(field, token)
		idx := sort.Search(len(entries), func(j int) bool {
			return postingsMetaKey(entries[j].Field, entries[j].Term) >= targetKey
		})
		if idx >= len(entries) || postingsMetaKey(entries[idx].Field, entries[idx].Term) != targetKey {
			resultBitmap = roaring.New()
			break
		}
		entry := entries[idx]
		dfPerToken[i] = entry.DF
		bm := roaring.New()
		if _, err := bm.ReadFrom(bytes.NewReader(postingsBytes[entry.Offset : entry.Offset+uint64(entry.Length)])); err != nil {
			return nil, nil, fmt.Errorf("intersectPostings: read bitmap for %s:%s: %w", entry.Field, entry.Term, err)
		}
		if resultBitmap == nil {
			resultBitmap = bm
		} else {
			resultBitmap = roaring.And(resultBitmap, bm)
		}
	}

	var segments []int
	if resultBitmap != nil {
		it := resultBitmap.Iterator()
		for it.HasNext() {
			segments = append(segments, int(it.Next()))
		}
	}
	return segments, dfPerToken, nil
}

func (motwSearch *MotwSearch) Search(ctx context.Context, q SearchQuery, opts SearchOptions) ([]*Book, SearchStats, error) {
	opened, err := motwSearch.Open()
	if err != nil {
		return nil, SearchStats{}, err
	}
	defer opened.Close()
	return opened.Search(ctx, q, opts)
}

func (opened *OpenedSearch) Search(ctx context.Context, q SearchQuery, opts SearchOptions) ([]*Book, SearchStats, error) {
	if q.Field == FieldAll {
		return opened.searchAll(ctx, q, opts)
	}

	var stats SearchStats
	mf := opened.mf
	rdr := opened.rdr

	queryTokens := normalizeAndTokenize(q.Text)
	stats.SegmentsTotal = int(mf.NumSegments)

	if len(queryTokens) == 0 {
		return nil, stats, nil
	}

	sortMode := opts.ResolvedSortMode()

	tombstoneSet := make(map[[16]byte]struct{}, len(mf.Tombstones))
	for _, ts := range mf.Tombstones {
		tombstoneSet[ts] = struct{}{}
	}

	numFields := 3
	if mf.IndexedFieldCount >= 4 {
		numFields = int(mf.IndexedFieldCount)
	}

	var (
		avgDL       []float64
		idfPerToken []float64
	)
	if sortMode == SortRelevance {
		avgDL = make([]float64, numFields)
		for _, reg := range mf.Regions {
			if reg.DocLengthsLen == 0 {
				continue
			}
			dlBytes := make([]byte, reg.DocLengthsLen)
			if _, err := rdr.ReadAt(dlBytes, int64(reg.DocLengthsOff)); err != nil {
				return nil, stats, fmt.Errorf("Search: read doc lengths: %w", err)
			}
			dlCount := int(reg.DocLengthsLen / 4)
			dl := make([]uint32, dlCount)
			if err := binary.Read(bytes.NewReader(dlBytes), binary.LittleEndian, &dl); err != nil {
				return nil, stats, fmt.Errorf("Search: decode doc lengths: %w", err)
			}
			numSegs := dlCount / numFields
			for seg := 0; seg < numSegs; seg++ {
				for i := 0; i < numFields; i++ {
					avgDL[i] += float64(dl[seg*numFields+i])
				}
			}
		}
		N := float64(mf.NumBooks)
		if N > 0 {
			for i := range avgDL {
				avgDL[i] /= N
			}
		}
	}

	var fuzzyDFA *levenshtein.DFA
	if q.Mode == ModeFuzzy && q.FuzzyDistance > 0 && len(queryTokens) > 0 {
		lab, err := levenshtein.NewLevenshteinAutomatonBuilder(uint8(q.FuzzyDistance), true)
		if err != nil {
			return nil, stats, fmt.Errorf("Search: levenshtein builder: %w", err)
		}
		fuzzyDFA, err = lab.BuildDfa(queryTokens[0], uint8(q.FuzzyDistance))
		if err != nil {
			return nil, stats, fmt.Errorf("Search: build DFA: %w", err)
		}
	}

	capK := opts.Offset + opts.Limit
	useTopK := capK > 0 && (sortMode == SortRelevance || sortMode == SortNewest || sortMode == SortOldest)
	var matches []bookMatch
	var rankedHeap bookMatchMinHeap
	if useTopK {
		rankedHeap = bookMatchMinHeap{sortMode: sortMode}
	}

	for regIdx, reg := range mf.Regions {
		if err := ctx.Err(); err != nil {
			return nil, stats, err
		}
		searchIdxBytes := make([]byte, reg.SearchIndexLen)
		if _, err := rdr.ReadAt(searchIdxBytes, int64(reg.SearchIndexOff)); err != nil {
			return nil, stats, fmt.Errorf("Search: read search index (region %d): %w", regIdx, err)
		}
		searchIdx := make([]uint32, len(searchIdxBytes)/4)
		if err := binary.Read(bytes.NewReader(searchIdxBytes), binary.LittleEndian, &searchIdx); err != nil {
			return nil, stats, fmt.Errorf("Search: decode search index (region %d): %w", regIdx, err)
		}

		postingsBytes := opened.postingsCache[regIdx].bytes
		postingsEntries := opened.postingsCache[regIdx].entries

		var foundSegments []int
		var dfPerToken []uint32
		var virtualDF uint32

		switch q.Mode {
		case ModePrefix, ModeFuzzy:

			var startKey, endKey []byte
			var accept func(term string) bool
			if q.Mode == ModePrefix {
				startKey, endKey = fieldPrefixRange(q.Field, queryTokens[0])
			} else {
				startKey, endKey = fieldRange(q.Field)
				dfa := fuzzyDFA
				accept = func(term string) bool {
					match, _ := dfa.MatchAndDistance(term)
					return match
				}
			}

			bitmap, vDF, err := expandPostingsRange(postingsBytes, postingsEntries, startKey, endKey, accept)
			if err != nil {
				return nil, stats, fmt.Errorf("Search: expand postings (region %d): %w", regIdx, err)
			}
			virtualDF = vDF
			if bitmap.GetCardinality() == 0 {
				continue
			}
			it := bitmap.Iterator()
			for it.HasNext() {
				seg := int(it.Next())
				if seg < len(searchIdx) {
					foundSegments = append(foundSegments, seg)
				}
			}
			if sortMode == SortRelevance && idfPerToken == nil {
				idfPerToken = []float64{bm25IDF(float64(mf.NumSegments), float64(virtualDF))}
			}

		default:
			var err error
			foundSegments, dfPerToken, err = intersectPostings(postingsBytes, postingsEntries, q.Field, queryTokens)
			if err != nil {
				return nil, stats, err
			}
			filtered := foundSegments[:0]
			for _, seg := range foundSegments {
				if seg < len(searchIdx) {
					filtered = append(filtered, seg)
				}
			}
			foundSegments = filtered
			if sortMode == SortRelevance && idfPerToken == nil {
				idfPerToken = make([]float64, len(queryTokens))
				for i := range queryTokens {
					idfPerToken[i] = bm25IDF(float64(mf.NumSegments), float64(dfPerToken[i]))
				}
			}
		}

		stats.PostingsNarrowed += len(foundSegments)
		stats.SegmentsCandidate += len(foundSegments)

		searchDataOffset := int64(reg.SearchableOff)

		segments := Segments{}
		segments.ClusterByFrames(searchDataOffset, mf.ChunkSize, foundSegments, searchIdx)
		stats.ClustersRead += len(segments.List)

		for _, cl := range segments.List {
			clusterBytes := make([]byte, cl.Length)
			n, err := rdr.ReadAt(clusterBytes, cl.Offset)
			if err != nil && !errors.Is(err, io.EOF) {
				return nil, stats, fmt.Errorf("Search: read search cluster (region %d): %w", regIdx, err)
			}
			stats.BytesDecompressed += int64(n)

			for _, seg := range cl.Segments {
				var segStart int64
				if seg > 0 {
					segStart = int64(searchIdx[seg-1])
				}
				segEnd := int64(searchIdx[seg])

				localStart := (searchDataOffset + segStart) - cl.Offset
				localEnd := (searchDataOffset + segEnd) - cl.Offset
				if localStart < 0 {
					localStart = 0
				}
				if localEnd > int64(n) {
					localEnd = int64(n)
				}
				if localStart >= localEnd {
					continue
				}

				lineReader := bufio.NewReader(bytes.NewReader(clusterBytes[localStart:localEnd]))
				posInSeg := 0
				for {
					line, err := lineReader.ReadBytes('\n')
					if err != nil {
						if err == io.EOF {
							break
						}
						return nil, stats, fmt.Errorf("Search: read search line (region %d): %w", regIdx, err)
					}
					if len(line) == 0 {
						continue
					}

					var doc searchableLine
					if err := json.Unmarshal(line, &doc); err != nil {
						return nil, stats, fmt.Errorf("Search: unmarshal search doc (region %d): %w", regIdx, err)
					}
					stats.BooksScanned++

					var matched bool
					var score float64
					switch q.Mode {
					case ModePrefix:
						prefix := queryTokens[0]
						tokenMatch := func(t string) bool { return strings.HasPrefix(t, prefix) }
						matched = doc.matchPrefix(q.Field, prefix)
						if matched && sortMode == SortRelevance && idfPerToken != nil {
							score = doc.scoreExpanded(q.Field, tokenMatch, idfPerToken[0], avgDL)
						}
					case ModeFuzzy:
						if fuzzyDFA != nil {
							matched = doc.matchFuzzy(q.Field, fuzzyDFA)
						}
						if matched && sortMode == SortRelevance && idfPerToken != nil {
							tokenMatch := func(t string) bool {
								m, _ := fuzzyDFA.MatchAndDistance(t)
								return m
							}
							score = doc.scoreExpanded(q.Field, tokenMatch, idfPerToken[0], avgDL)
						}
					default:
						matched, score = doc.matchAndScore(q.Field, queryTokens, idfPerToken, avgDL, sortMode == SortRelevance && idfPerToken != nil)
					}

					if matched {
						stats.BooksMatched++
						bm := bookMatch{regionIdx: regIdx, segment: seg, posInSeg: posInSeg, score: score, lastModified: doc.LastModified}
						if useTopK {
							if rankedHeap.Len() < capK {
								heap.Push(&rankedHeap, bm)
							} else if rankedHeap.beats(bm) {
								rankedHeap.items[0] = bm
								heap.Fix(&rankedHeap, 0)
							}
						} else {
							matches = append(matches, bm)
						}
					}
					posInSeg++
				}
			}
		}
	}

	if useTopK && rankedHeap.Len() > 0 {
		matches = make([]bookMatch, rankedHeap.Len())
		for i := len(matches) - 1; i >= 0; i-- {
			matches[i] = heap.Pop(&rankedHeap).(bookMatch)
		}
	}

	var books []*Book
	for _, m := range matches {
		if err := ctx.Err(); err != nil {
			return nil, stats, err
		}
		reg := mf.Regions[m.regionIdx]

		displayIdxBytes := make([]byte, reg.DisplayIndexLen)
		if _, err := rdr.ReadAt(displayIdxBytes, int64(reg.DisplayIndexOff)); err != nil {
			return nil, stats, fmt.Errorf("Search: read display index (region %d): %w", m.regionIdx, err)
		}
		displayIdx := make([]uint32, len(displayIdxBytes)/4)
		if err := binary.Read(bytes.NewReader(displayIdxBytes), binary.LittleEndian, &displayIdx); err != nil {
			return nil, stats, fmt.Errorf("Search: decode display index (region %d): %w", m.regionIdx, err)
		}

		displayDataOffset := int64(reg.DisplayOff)
		var segStart int64
		if m.segment > 0 {
			segStart = int64(displayIdx[m.segment-1])
		}
		segEnd := int64(displayIdx[m.segment])

		segBytes := make([]byte, segEnd-segStart)
		if _, err := rdr.ReadAt(segBytes, displayDataOffset+segStart); err != nil && !errors.Is(err, io.EOF) {
			return nil, stats, fmt.Errorf("Search: read display segment (region %d): %w", m.regionIdx, err)
		}
		stats.BytesDecompressed += int64(len(segBytes))

		lineReader := bufio.NewReader(bytes.NewReader(segBytes))
		lineNum := 0
		for {
			line, err := lineReader.ReadBytes('\n')
			if err != nil {
				if err == io.EOF {
					break
				}
				return nil, stats, fmt.Errorf("Search: read display line (region %d): %w", m.regionIdx, err)
			}
			if lineNum == m.posInSeg {
				var book Book
				if err := json.Unmarshal(line, &book); err != nil {
					return nil, stats, fmt.Errorf("Search: unmarshal display book (region %d): %w", m.regionIdx, err)
				}

				if book.Id != "" && len(tombstoneSet) > 0 {
					ts, parseErr := bookIDToTombstone(book.Id)
					if parseErr == nil {
						if _, tombstoned := tombstoneSet[ts]; tombstoned {
							break
						}
					}
				}

				book.SearchScore = m.score
				books = append(books, &book)
				break
			}
			lineNum++
		}
	}

	switch sortMode {
	case SortRelevance:
		sort.SliceStable(books, func(i, j int) bool {
			if books[i].SearchScore != books[j].SearchScore {
				return books[i].SearchScore > books[j].SearchScore
			}
			return books[i].LastModified > books[j].LastModified
		})
	case SortNewest:
		sort.SliceStable(books, func(i, j int) bool {
			return books[i].LastModified > books[j].LastModified
		})
	case SortOldest:
		sort.Sort(CalibreBooksByLastModified(books))
	case SortNone:
	}
	return books, stats, nil
}

func (opened *OpenedSearch) searchAllSinglePass(ctx context.Context, q SearchQuery, opts SearchOptions) ([]*Book, SearchStats, error) {
	var stats SearchStats
	mf := opened.mf
	rdr := opened.rdr

	queryTokens := normalizeAndTokenize(q.Text)
	stats.SegmentsTotal = int(mf.NumSegments)
	if len(queryTokens) == 0 {
		return nil, stats, nil
	}

	sortMode := opts.ResolvedSortMode()

	tombstoneSet := make(map[[16]byte]struct{}, len(mf.Tombstones))
	for _, ts := range mf.Tombstones {
		tombstoneSet[ts] = struct{}{}
	}

	numFields := 3
	if mf.IndexedFieldCount >= 4 {
		numFields = int(mf.IndexedFieldCount)
	}

	var avgDL []float64
	if sortMode == SortRelevance {
		avgDL = make([]float64, numFields)
		for _, reg := range mf.Regions {
			if reg.DocLengthsLen == 0 {
				continue
			}
			dlBytes := make([]byte, reg.DocLengthsLen)
			if _, err := rdr.ReadAt(dlBytes, int64(reg.DocLengthsOff)); err != nil {
				return nil, stats, fmt.Errorf("searchAllSinglePass: read doc lengths: %w", err)
			}
			dlCount := int(reg.DocLengthsLen / 4)
			dl := make([]uint32, dlCount)
			if err := binary.Read(bytes.NewReader(dlBytes), binary.LittleEndian, &dl); err != nil {
				return nil, stats, fmt.Errorf("searchAllSinglePass: decode doc lengths: %w", err)
			}
			numSegs := dlCount / numFields
			for seg := 0; seg < numSegs; seg++ {
				for i := 0; i < numFields; i++ {
					avgDL[i] += float64(dl[seg*numFields+i])
				}
			}
		}
		N := float64(mf.NumBooks)
		if N > 0 {
			for i := range avgDL {
				avgDL[i] /= N
			}
		}
	}

	capLimit := 0
	if opts.Limit > 0 {
		capLimit = opts.Offset + opts.Limit
	}
	scanCap := 0
	if capLimit > 0 {
		scanCap = capLimit + len(mf.Tombstones)
	}
	useTopK := scanCap > 0 && (sortMode == SortRelevance || sortMode == SortNewest || sortMode == SortOldest)

	idfPerField := make([][]float64, numFields)

	searchFields := fieldsInOrder[:numFields]
	var matches []bookMatch
	var rankedHeap bookMatchMinHeap
	if useTopK {
		rankedHeap = bookMatchMinHeap{sortMode: sortMode}
	}

	for regIdx, reg := range mf.Regions {
		if err := ctx.Err(); err != nil {
			return nil, stats, err
		}

		searchIdxBytes := make([]byte, reg.SearchIndexLen)
		if _, err := rdr.ReadAt(searchIdxBytes, int64(reg.SearchIndexOff)); err != nil {
			return nil, stats, fmt.Errorf("searchAllSinglePass: read search index (region %d): %w", regIdx, err)
		}
		searchIdx := make([]uint32, len(searchIdxBytes)/4)
		if err := binary.Read(bytes.NewReader(searchIdxBytes), binary.LittleEndian, &searchIdx); err != nil {
			return nil, stats, fmt.Errorf("searchAllSinglePass: decode search index (region %d): %w", regIdx, err)
		}

		postingsBytes := opened.postingsCache[regIdx].bytes
		postingsEntries := opened.postingsCache[regIdx].entries

		var unionBitmap *roaring.Bitmap

		for fi, field := range searchFields {
			fieldSegs, dfPerToken, err := intersectPostings(postingsBytes, postingsEntries, field, queryTokens)
			if err != nil {
				return nil, stats, err
			}
			if len(fieldSegs) == 0 {
				continue
			}
			fieldBitmap := roaring.New()
			for _, seg := range fieldSegs {
				if seg < len(searchIdx) {
					fieldBitmap.Add(uint32(seg))
				}
			}
			if unionBitmap == nil {
				unionBitmap = fieldBitmap
			} else {
				unionBitmap.Or(fieldBitmap)
			}
			if sortMode == SortRelevance && idfPerField[fi] == nil {
				idfPerField[fi] = make([]float64, len(queryTokens))
				for i := range queryTokens {
					idfPerField[fi][i] = bm25IDF(float64(mf.NumSegments), float64(dfPerToken[i]))
				}
			}
		}

		if unionBitmap == nil || unionBitmap.GetCardinality() == 0 {
			continue
		}

		var foundSegments []int
		it := unionBitmap.Iterator()
		for it.HasNext() {
			foundSegments = append(foundSegments, int(it.Next()))
		}

		stats.PostingsNarrowed += len(foundSegments)
		stats.SegmentsCandidate += len(foundSegments)

		searchDataOffset := int64(reg.SearchableOff)
		segments := Segments{}
		segments.ClusterByFrames(searchDataOffset, mf.ChunkSize, foundSegments, searchIdx)
		stats.ClustersRead += len(segments.List)

		for _, cl := range segments.List {
			clusterBytes := make([]byte, cl.Length)
			n, err := rdr.ReadAt(clusterBytes, cl.Offset)
			if err != nil && !errors.Is(err, io.EOF) {
				return nil, stats, fmt.Errorf("searchAllSinglePass: read search cluster (region %d): %w", regIdx, err)
			}
			stats.BytesDecompressed += int64(n)

			for _, seg := range cl.Segments {
				var segStart int64
				if seg > 0 {
					segStart = int64(searchIdx[seg-1])
				}
				segEnd := int64(searchIdx[seg])

				localStart := (searchDataOffset + segStart) - cl.Offset
				localEnd := (searchDataOffset + segEnd) - cl.Offset
				if localStart < 0 {
					localStart = 0
				}
				if localEnd > int64(n) {
					localEnd = int64(n)
				}
				if localStart >= localEnd {
					continue
				}

				lineReader := bufio.NewReader(bytes.NewReader(clusterBytes[localStart:localEnd]))
				posInSeg := 0
				for {
					line, err := lineReader.ReadBytes('\n')
					if err != nil {
						if err == io.EOF {
							break
						}
						return nil, stats, fmt.Errorf("searchAllSinglePass: read search line (region %d): %w", regIdx, err)
					}
					if len(line) == 0 {
						continue
					}

					var doc searchableLine
					if err := json.Unmarshal(line, &doc); err != nil {
						return nil, stats, fmt.Errorf("searchAllSinglePass: unmarshal search doc (region %d): %w", regIdx, err)
					}
					stats.BooksScanned++

					matched, score := doc.matchAnyAndScore(queryTokens, idfPerField, avgDL, sortMode == SortRelevance && avgDL != nil, numFields)
					if matched {
						stats.BooksMatched++
						bm := bookMatch{regionIdx: regIdx, segment: seg, posInSeg: posInSeg, score: score, lastModified: doc.LastModified}
						if useTopK {
							if rankedHeap.Len() < scanCap {
								heap.Push(&rankedHeap, bm)
							} else if rankedHeap.beats(bm) {
								rankedHeap.items[0] = bm
								heap.Fix(&rankedHeap, 0)
							}
						} else {
							matches = append(matches, bm)
						}
					}
					posInSeg++
				}
			}
		}
	}

	if useTopK && rankedHeap.Len() > 0 {
		matches = make([]bookMatch, rankedHeap.Len())
		for i := len(matches) - 1; i >= 0; i-- {
			matches[i] = heap.Pop(&rankedHeap).(bookMatch)
		}
	}

	bestMatch := make(map[string]bookMatch)
	bestBook := make(map[string]*Book)
	for _, m := range matches {
		if err := ctx.Err(); err != nil {
			return nil, stats, err
		}
		reg := mf.Regions[m.regionIdx]

		displayIdxBytes := make([]byte, reg.DisplayIndexLen)
		if _, err := rdr.ReadAt(displayIdxBytes, int64(reg.DisplayIndexOff)); err != nil {
			return nil, stats, fmt.Errorf("searchAllSinglePass: read display index (region %d): %w", m.regionIdx, err)
		}
		displayIdx := make([]uint32, len(displayIdxBytes)/4)
		if err := binary.Read(bytes.NewReader(displayIdxBytes), binary.LittleEndian, &displayIdx); err != nil {
			return nil, stats, fmt.Errorf("searchAllSinglePass: decode display index (region %d): %w", m.regionIdx, err)
		}

		displayDataOffset := int64(reg.DisplayOff)
		var segStart int64
		if m.segment > 0 {
			segStart = int64(displayIdx[m.segment-1])
		}
		segEnd := int64(displayIdx[m.segment])

		segBytes := make([]byte, segEnd-segStart)
		if _, err := rdr.ReadAt(segBytes, displayDataOffset+segStart); err != nil && !errors.Is(err, io.EOF) {
			return nil, stats, fmt.Errorf("searchAllSinglePass: read display segment (region %d): %w", m.regionIdx, err)
		}
		stats.BytesDecompressed += int64(len(segBytes))

		lineReader := bufio.NewReader(bytes.NewReader(segBytes))
		lineNum := 0
		for {
			line, err := lineReader.ReadBytes('\n')
			if err != nil {
				if err == io.EOF {
					break
				}
				return nil, stats, fmt.Errorf("searchAllSinglePass: read display line (region %d): %w", m.regionIdx, err)
			}
			if lineNum != m.posInSeg {
				lineNum++
				continue
			}
			var book Book
			if err := json.Unmarshal(line, &book); err != nil {
				return nil, stats, fmt.Errorf("searchAllSinglePass: unmarshal display book (region %d): %w", m.regionIdx, err)
			}
			if book.Id != "" && len(tombstoneSet) > 0 {
				if ts, parseErr := bookIDToTombstone(book.Id); parseErr == nil {
					if _, tombstoned := tombstoneSet[ts]; tombstoned {
						break
					}
				}
			}
			book.SearchScore = m.score
			key := book.Id
			if key == "" {
				key = book.Title + "|" + book.LibraryUUID
			}
			if prev, seen := bestMatch[key]; !seen || rankBefore(m, prev, sortMode) {
				bestMatch[key] = m
				bestBook[key] = &book
			}
			break
		}
	}

	keys := make([]string, 0, len(bestBook))
	for k := range bestBook {
		keys = append(keys, k)
	}
	sort.Slice(keys, func(i, j int) bool {
		return rankBefore(bestMatch[keys[i]], bestMatch[keys[j]], sortMode)
	})
	books := make([]*Book, 0, len(keys))
	for _, k := range keys {
		books = append(books, bestBook[k])
	}
	if capLimit > 0 && len(books) > capLimit {
		books = books[:capLimit]
	}

	return books, stats, nil
}

func (opened *OpenedSearch) searchAll(ctx context.Context, q SearchQuery, opts SearchOptions) ([]*Book, SearchStats, error) {
	if q.Mode == ModeExact {
		return opened.searchAllSinglePass(ctx, q, opts)
	}

	numFields := 3
	if opened.mf.IndexedFieldCount >= 4 {
		numFields = int(opened.mf.IndexedFieldCount)
	}

	merged := map[string]*Book{}
	var combinedStats SearchStats
	combinedStats.SegmentsTotal = int(opened.mf.NumSegments)

	searchFields := fieldsInOrder[:numFields]

	capLimit := 0
	if opts.Limit > 0 {
		capLimit = opts.Offset + opts.Limit
	}

	for _, field := range searchFields {
		fq := SearchQuery{Field: field, Text: q.Text, Mode: q.Mode, FuzzyDistance: q.FuzzyDistance}
		fOpts := SearchOptions{Limit: 0, Offset: 0, SortMode: SortRelevance}
		books, fStats, err := opened.Search(ctx, fq, fOpts)
		if err != nil {
			return nil, combinedStats, err
		}
		combinedStats.BooksScanned += fStats.BooksScanned
		combinedStats.SegmentsCandidate += fStats.SegmentsCandidate
		combinedStats.BytesDecompressed += fStats.BytesDecompressed

		for _, bk := range books {
			key := bk.Id
			if key == "" {
				key = bk.Title + "|" + bk.LibraryUUID
			}
			if existing, ok := merged[key]; ok {
				if bk.SearchScore > existing.SearchScore {
					existing.SearchScore = bk.SearchScore
				}
			} else {
				merged[key] = bk
			}
		}
	}

	result := make([]*Book, 0, len(merged))
	for _, bk := range merged {
		result = append(result, bk)
	}
	combinedStats.BooksMatched = len(result)

	switch opts.SortMode {
	case SortNewest:
		sort.SliceStable(result, func(i, j int) bool {
			return result[i].LastModified > result[j].LastModified
		})
	case SortOldest:
		sort.Sort(CalibreBooksByLastModified(result))
	case SortNone:
	default:
		sort.SliceStable(result, func(i, j int) bool {
			if result[i].SearchScore != result[j].SearchScore {
				return result[i].SearchScore > result[j].SearchScore
			}
			return result[i].LastModified > result[j].LastModified
		})
	}

	if capLimit > 0 && len(result) > capLimit {
		result = result[:capLimit]
	}

	return result, combinedStats, nil
}

type partialBuildResult struct {
	postingsBitmaps map[fieldTerm]*roaring.Bitmap
	docLengthsMap   map[segFieldKey]uint32
	entities        entityCollector
	fpBuf           []byte
	searchableBuf   []byte
	searchSegLens   []uint32
	displaySegLens  []uint32
	recency         []RecencyEntry
	numBooks        int
	numSegments     int
	err             error
}

func buildPartialIndex(r io.Reader, startBook, numBooksInRange, segmentBase int, startByte int64, indexDescription, indexAggregateFields bool) partialBuildResult {
	postingsBitmaps := make(map[fieldTerm]*roaring.Bitmap)
	docLengthsMap := make(map[segFieldKey]uint32)
	entities := entityCollector{}
	var fpBuf []byte
	var searchableBuf []byte
	var searchSegLens []uint32
	var displaySegLens []uint32
	var recency []RecencyEntry
	segSearchLen := 0
	segDisplayLen := 0
	runningByte := startByte

	addPosting := func(field SearchField, term string, segID uint32) {
		key := fieldTerm{field, term}
		bm := postingsBitmaps[key]
		if bm == nil {
			bm = roaring.New()
			postingsBitmaps[key] = bm
		}
		bm.Add(segID)
	}

	localCount := 0
	segment := segmentBase

	br := bufio.NewReader(r)
	for {
		line, err := br.ReadBytes('\n')
		if err != nil {
			if err == io.EOF {
				break
			}
			return partialBuildResult{err: fmt.Errorf("buildPartialIndex: read book at line %d: %w", startBook+localCount, err)}
		}
		fullLen := len(line)
		line = bytes.TrimRight(line, "\n")
		trimmedLen := len(line)
		bookByteOff := runningByte
		runningByte += int64(fullLen)
		segDisplayLen += fullLen
		var book Book
		if err := json.Unmarshal(line, &book); err != nil {
			return partialBuildResult{err: fmt.Errorf("buildPartialIndex: unmarshal book at line %d: %w", startBook+localCount, err)}
		}

		localCount++
		segID := uint32(segment)

		fp := DecodeFingerprintBase64(book.CoverFingerprint)
		fpBuf = append(fpBuf, fp[:]...)

		titleTokens := normalizeAndTokenize(book.Title)
		for _, token := range titleTokens {
			addPosting(FieldTitle, token, segID)
		}
		docLengthsMap[segFieldKey{segment, FieldTitle}] += uint32(len(titleTokens))
		entities.add(FieldTitle, book.Title)
		searchTitle := strings.Join(titleTokens, " ")

		var searchAuthors []string
		for _, author := range book.Authors {
			tokens := normalizeAndTokenize(author)
			for _, token := range tokens {
				addPosting(FieldAuthor, token, segID)
			}
			docLengthsMap[segFieldKey{segment, FieldAuthor}] += uint32(len(tokens))
			entities.add(FieldAuthor, author)
			searchAuthors = append(searchAuthors, strings.Join(tokens, " "))
		}

		var searchTags []string
		for _, tag := range book.Tags {
			entities.add(FieldTag, tag)
			tokens := normalizeAndTokenize(tag)
			for _, token := range tokens {
				addPosting(FieldTag, token, segID)
			}
			docLengthsMap[segFieldKey{segment, FieldTag}] += uint32(len(tokens))
			searchTags = append(searchTags, strings.Join(tokens, " "))
		}

		var searchAbstract string
		if indexDescription && book.Abstract != "" {
			abstractText := stripHTML(book.Abstract)
			abstractTokens := normalizeAndTokenize(abstractText)
			for _, token := range abstractTokens {
				addPosting(FieldAbstract, token, segID)
			}
			docLengthsMap[segFieldKey{segment, FieldAbstract}] += uint32(len(abstractTokens))
			searchAbstract = strings.Join(abstractTokens, " ")
		}

		sData, _ := json.Marshal(assembleSearchableLine(searchTitle, searchAuthors, searchTags, searchAbstract, book.LastModified))
		sData = append(sData, '\n')
		searchableBuf = append(searchableBuf, sData...)
		segSearchLen += len(sData)

		recency = append(recency, RecencyEntry{LastModified: book.LastModified, Id: book.Id, AbsOff: bookByteOff, Length: int32(trimmedLen)})

		if indexAggregateFields {
			if book.Id != "" {
				addPosting(FieldID, book.Id, segID)
			}
			if book.LibraryUUID != "" {
				addPosting(FieldLibraryUUID, book.LibraryUUID, segID)
			}
		}

		if localCount%16 == 0 {
			searchSegLens = append(searchSegLens, uint32(segSearchLen))
			displaySegLens = append(displaySegLens, uint32(segDisplayLen))
			segSearchLen = 0
			segDisplayLen = 0
			segment++
		}
	}

	if segSearchLen > 0 {
		searchSegLens = append(searchSegLens, uint32(segSearchLen))
	}
	if segDisplayLen > 0 {
		displaySegLens = append(displaySegLens, uint32(segDisplayLen))
	}

	if localCount != numBooksInRange {
		return partialBuildResult{err: fmt.Errorf("buildPartialIndex: range [%d,+%d) yielded %d books", startBook, numBooksInRange, localCount)}
	}

	numSegments := (localCount + 15) / 16

	return partialBuildResult{
		postingsBitmaps: postingsBitmaps,
		docLengthsMap:   docLengthsMap,
		entities:        entities,
		fpBuf:           fpBuf,
		searchableBuf:   searchableBuf,
		searchSegLens:   searchSegLens,
		displaySegLens:  displaySegLens,
		recency:         recency,
		numBooks:        localCount,
		numSegments:     numSegments,
	}
}

func (motwSearch *MotwSearch) BuildIndex() (indexData, error) {
	var idx indexData

	jsonlFile, err := os.Open(motwSearch.JsonlPath)
	if err != nil {
		return indexData{}, fmt.Errorf("BuildIndex: open JSONL: %w", err)
	}
	defer jsonlFile.Close()

	var segOffsets []int64
	var bytePos int64
	numBooks := 0
	var displaySamples [][]byte
	reader := bufio.NewReader(jsonlFile)
	for {
		if numBooks%16 == 0 {
			segOffsets = append(segOffsets, bytePos)
		}
		var lineLen int64
		sawNewline := false
		capture := numBooks < dictSampleLines
		var sample []byte
		for {
			frag, err := reader.ReadSlice('\n')
			lineLen += int64(len(frag))
			if capture {
				sample = append(sample, frag...)
			}
			if err == nil {
				sawNewline = true
				break
			}
			if err == bufio.ErrBufferFull {
				continue
			}
			if err == io.EOF {
				break
			}
			return indexData{}, fmt.Errorf("BuildIndex: scan line: %w", err)
		}
		if !sawNewline {
			break
		}
		if capture {
			displaySamples = append(displaySamples, sample)
		}
		bytePos += lineLen
		numBooks++
	}
	segOffsets = append(segOffsets, bytePos)
	idx.DisplaySamples = displaySamples

	if numBooks == 0 {
		return idx, nil
	}

	numWorkers := min(runtime.GOMAXPROCS(0), max(1, numBooks/16))
	numWorkers = buildWorkerCount(numWorkers)
	if numWorkers < 1 {
		numWorkers = 1
	}

	totalSegs := (numBooks + 15) / 16
	if numWorkers > totalSegs {
		numWorkers = totalSegs
	}
	baseSegs := totalSegs / numWorkers
	extraSegs := totalSegs % numWorkers

	partials := make([]partialBuildResult, numWorkers)
	var wg sync.WaitGroup
	segCursor := 0
	for w := 0; w < numWorkers; w++ {
		segs := baseSegs
		if w < extraSegs {
			segs++
		}
		start := segCursor * 16
		end := min((segCursor+segs)*16, numBooks)
		segBase := segCursor
		startByte := segOffsets[segCursor]
		lenBytes := segOffsets[segCursor+segs] - startByte
		segCursor += segs
		sr := io.NewSectionReader(jsonlFile, startByte, lenBytes)
		wg.Add(1)
		go func(w, start, end, segBase int, startByte int64, sr *io.SectionReader) {
			defer wg.Done()
			partials[w] = buildPartialIndex(sr, start, end-start, segBase, startByte,
				motwSearch.IndexDescription, motwSearch.IndexAggregateFields)
		}(w, start, end, segBase, startByte, sr)
	}
	wg.Wait()

	for w := 0; w < numWorkers; w++ {
		if partials[w].err != nil {
			return indexData{}, partials[w].err
		}
	}

	mergedPostings := make(map[fieldTerm]*roaring.Bitmap)
	mergedDocLengths := make(map[segFieldKey]uint32)
	mergedEntities := entityCollector{}
	var mergedFP []byte
	totalBooks := 0
	totalSegments := 0

	var totalSearchable, totalFP int
	for w := 0; w < numWorkers; w++ {
		totalSearchable += len(partials[w].searchableBuf)
		totalFP += len(partials[w].fpBuf)
	}
	idx.Searchable = make([]byte, 0, totalSearchable)
	mergedFP = make([]byte, 0, totalFP)
	idx.Recency = make([]RecencyEntry, 0, numBooks)
	idx.SearchSegLens = make([]uint32, 0, totalSegs)
	idx.DisplaySegLens = make([]uint32, 0, totalSegs)

	for w := 0; w < numWorkers; w++ {
		p := &partials[w]
		totalBooks += p.numBooks
		totalSegments += p.numSegments

		for key, bm := range p.postingsBitmaps {
			if existing, ok := mergedPostings[key]; ok {
				existing.Or(bm)
			} else {
				mergedPostings[key] = bm
			}
		}

		for key, val := range p.docLengthsMap {
			mergedDocLengths[key] = val
		}

		for field, ents := range p.entities {
			if mergedEntities[field] == nil {
				mergedEntities[field] = make(map[string]uint32)
			}
			for entity, count := range ents {
				mergedEntities[field][entity] += count
			}
		}

		mergedFP = append(mergedFP, p.fpBuf...)

		idx.Searchable = append(idx.Searchable, p.searchableBuf...)
		idx.SearchSegLens = append(idx.SearchSegLens, p.searchSegLens...)
		idx.DisplaySegLens = append(idx.DisplaySegLens, p.displaySegLens...)
		idx.Recency = append(idx.Recency, p.recency...)
	}

	idx.NumBooks = uint32(totalBooks)
	idx.NumSegments = uint32(totalSegments)
	idx.Fingerprints = mergedFP

	postingsBitmaps := mergedPostings
	docLengthsMap := mergedDocLengths
	entities := mergedEntities

	type ftEntry struct {
		field SearchField
		term  string
		bm    *roaring.Bitmap
	}
	sorted := make([]ftEntry, 0, len(postingsBitmaps))
	for k, bm := range postingsBitmaps {
		sorted = append(sorted, ftEntry{k.field, k.term, bm})
	}
	sort.Slice(sorted, func(i, j int) bool {
		ki := postingsMetaKey(sorted[i].field, sorted[i].term)
		kj := postingsMetaKey(sorted[j].field, sorted[j].term)
		return ki < kj
	})

	var bitmapBuf bytes.Buffer
	entries := make([]PostingsEntry, 0, len(sorted))
	for _, fte := range sorted {
		offset := uint64(bitmapBuf.Len())
		n, err := fte.bm.WriteTo(&bitmapBuf)
		if err != nil {
			return indexData{}, fmt.Errorf("BuildIndex: write bitmap: %w", err)
		}
		entries = append(entries, PostingsEntry{
			Field:  fte.field,
			Term:   fte.term,
			Offset: offset,
			Length: uint32(n),
			DF:     uint32(fte.bm.GetCardinality()),
		})
	}
	idx.Postings = bitmapBuf.Bytes()

	metaBytes, err := encodePostingsMeta(entries)
	if err != nil {
		return indexData{}, fmt.Errorf("BuildIndex: encode postings meta: %w", err)
	}
	idx.PostingsMeta = metaBytes

	numSegs := int(idx.NumSegments)
	numFields := 3
	if motwSearch.IndexDescription {
		numFields = 4
	}
	dlArray := make([]uint32, numSegs*numFields)
	for seg := 0; seg < numSegs; seg++ {
		for i := 0; i < numFields; i++ {
			dlArray[seg*numFields+i] = docLengthsMap[segFieldKey{seg, fieldsInOrder[i]}]
		}
	}
	dlBuf := new(bytes.Buffer)
	if err := binary.Write(dlBuf, binary.LittleEndian, dlArray); err != nil {
		return indexData{}, fmt.Errorf("BuildIndex: write doc lengths: %w", err)
	}
	idx.DocLengths = dlBuf.Bytes()

	entityFST, eerr := buildEntityFST(entities)
	if eerr != nil {
		return indexData{}, fmt.Errorf("BuildIndex: build entity FST: %w", eerr)
	}
	idx.EntityFST = entityFST

	return idx, nil
}

func (opened *OpenedSearch) LookupByID(ctx context.Context, id string) (*Book, error) {
	if id == "" {
		return nil, nil
	}
	mf := opened.mf
	rdr := opened.rdr

	tombstoneSet := make(map[[16]byte]struct{}, len(mf.Tombstones))
	for _, ts := range mf.Tombstones {
		tombstoneSet[ts] = struct{}{}
	}
	if len(tombstoneSet) > 0 {
		if ts, perr := bookIDToTombstone(id); perr == nil {
			if _, t := tombstoneSet[ts]; t {
				return nil, nil
			}
		}
	}

	for regIdx := len(mf.Regions) - 1; regIdx >= 0; regIdx-- {
		reg := mf.Regions[regIdx]
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		if reg.PostingsLen == 0 || reg.PostingsMetaLen == 0 {
			continue
		}
		postingsBytes := opened.postingsCache[regIdx].bytes
		entries := opened.postingsCache[regIdx].entries

		segments, _, err := intersectPostings(postingsBytes, entries, FieldID, []string{id})
		if err != nil {
			return nil, fmt.Errorf("LookupByID: intersect (region %d): %w", regIdx, err)
		}
		if len(segments) == 0 {
			continue
		}

		displayIdxBytes := make([]byte, reg.DisplayIndexLen)
		if _, err := rdr.ReadAt(displayIdxBytes, int64(reg.DisplayIndexOff)); err != nil {
			return nil, fmt.Errorf("LookupByID: read display index (region %d): %w", regIdx, err)
		}
		displayIdx := make([]uint32, len(displayIdxBytes)/4)
		if err := binary.Read(bytes.NewReader(displayIdxBytes), binary.LittleEndian, &displayIdx); err != nil {
			return nil, fmt.Errorf("LookupByID: decode display index (region %d): %w", regIdx, err)
		}

		idBytes := []byte(id)
		for _, seg := range segments {
			if seg >= len(displayIdx) {
				continue
			}
			var segStart int64
			if seg > 0 {
				segStart = int64(displayIdx[seg-1])
			}
			segEnd := int64(displayIdx[seg])
			segBytes := make([]byte, segEnd-segStart)
			if _, err := rdr.ReadAt(segBytes, int64(reg.DisplayOff)+segStart); err != nil && !errors.Is(err, io.EOF) {
				return nil, fmt.Errorf("LookupByID: read display segment (region %d, seg %d): %w", regIdx, seg, err)
			}

			lineReader := bufio.NewReader(bytes.NewReader(segBytes))
			for {
				line, err := lineReader.ReadBytes('\n')
				if err != nil {
					if err == io.EOF {
						break
					}
					return nil, fmt.Errorf("LookupByID: read display line (region %d): %w", regIdx, err)
				}
				if len(line) == 0 {
					continue
				}
				if !bytes.Contains(line, idBytes) {
					continue
				}
				var book Book
				if err := json.Unmarshal(line, &book); err != nil {
					return nil, fmt.Errorf("LookupByID: unmarshal display book (region %d): %w", regIdx, err)
				}
				if book.Id == id {
					return &book, nil
				}
			}
		}
	}
	return nil, nil
}

func (opened *OpenedSearch) Manifest() Manifest {
	mf := opened.mf
	if len(mf.Regions) > 0 {
		mf.Regions = append([]ManifestRegion(nil), opened.mf.Regions...)
	}
	if len(mf.Tombstones) > 0 {
		mf.Tombstones = append([][16]byte(nil), opened.mf.Tombstones...)
	}
	return mf
}

func (opened *OpenedSearch) PageBooks(ctx context.Context, offset, limit int) ([]*Book, int, error) {
	mf := opened.mf
	rdr := opened.rdr
	total := int(mf.NumBooks) - len(mf.Tombstones)
	if total < 0 {
		total = 0
	}
	if offset < 0 {
		offset = 0
	}
	if limit <= 0 {
		return nil, total, nil
	}
	if offset >= total {
		return nil, total, nil
	}
	end := offset + limit

	tombstoneSet := make(map[[16]byte]struct{}, len(mf.Tombstones))
	for _, ts := range mf.Tombstones {
		tombstoneSet[ts] = struct{}{}
	}

	order, err := opened.pageOrderRefs(ctx, tombstoneSet)
	if err != nil {
		return nil, total, err
	}
	total = len(order)
	if offset >= total {
		return nil, total, nil
	}
	if end > total {
		end = total
	}

	books := make([]*Book, 0, end-offset)
	for _, ref := range order[offset:end] {
		if err := ctx.Err(); err != nil {
			return nil, total, err
		}
		lineBytes := make([]byte, ref.length)
		if _, err := rdr.ReadAt(lineBytes, ref.absOff); err != nil && !errors.Is(err, io.EOF) {
			return nil, total, fmt.Errorf("PageBooks: re-read book: %w", err)
		}
		var book Book
		if err := json.Unmarshal(bytes.TrimRight(lineBytes, "\n"), &book); err != nil {
			return nil, total, fmt.Errorf("PageBooks: unmarshal: %w", err)
		}
		books = append(books, &book)
	}
	return books, total, nil
}

func (opened *OpenedSearch) pageOrderRefs(ctx context.Context, tombstoneSet map[[16]byte]struct{}) ([]displayRef, error) {
	opened.pageOrderMu.Lock()
	defer opened.pageOrderMu.Unlock()
	if opened.pageOrderBuilt {
		return opened.pageOrder, nil
	}

	mf := opened.mf

	if len(mf.RecencyIndex) > 0 {
		refs := make([]displayRef, 0, len(mf.RecencyIndex))
		for _, re := range mf.RecencyIndex {
			if re.Id != "" && len(tombstoneSet) > 0 {
				if ts, perr := bookIDToTombstone(re.Id); perr == nil {
					if _, dead := tombstoneSet[ts]; dead {
						continue
					}
				}
			}
			refs = append(refs, displayRef{
				lastModified: re.LastModified,
				id:           re.Id,
				absOff:       re.AbsOff,
				length:       int(re.Length),
			})
		}
		opened.pageOrder = refs
		opened.pageOrderBuilt = true
		return refs, nil
	}

	rdr := opened.rdr
	refs := make([]displayRef, 0, mf.NumBooks)

	for regIdx, reg := range mf.Regions {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		if reg.DisplayIndexLen == 0 || reg.DisplayLen == 0 {
			continue
		}
		displayIdxBytes := make([]byte, reg.DisplayIndexLen)
		if _, err := rdr.ReadAt(displayIdxBytes, int64(reg.DisplayIndexOff)); err != nil {
			return nil, fmt.Errorf("pageOrder: read display index (region %d): %w", regIdx, err)
		}
		displayIdx := make([]uint32, len(displayIdxBytes)/4)
		if err := binary.Read(bytes.NewReader(displayIdxBytes), binary.LittleEndian, &displayIdx); err != nil {
			return nil, fmt.Errorf("pageOrder: decode display index (region %d): %w", regIdx, err)
		}

		for seg := 0; seg < len(displayIdx); seg++ {
			var segStart int64
			if seg > 0 {
				segStart = int64(displayIdx[seg-1])
			}
			segEnd := int64(displayIdx[seg])
			segBytes := make([]byte, segEnd-segStart)
			if _, err := rdr.ReadAt(segBytes, int64(reg.DisplayOff)+segStart); err != nil && !errors.Is(err, io.EOF) {
				return nil, fmt.Errorf("pageOrder: read segment (region %d, seg %d): %w", regIdx, seg, err)
			}

			var pos int64
			for pos < int64(len(segBytes)) {
				nl := bytes.IndexByte(segBytes[pos:], '\n')
				var line []byte
				if nl < 0 {
					line = segBytes[pos:]
				} else {
					line = segBytes[pos : pos+int64(nl)]
				}
				lineOff := int64(reg.DisplayOff) + segStart + pos
				if nl < 0 {
					pos = int64(len(segBytes))
				} else {
					pos += int64(nl) + 1
				}
				if len(line) == 0 {
					continue
				}

				var meta struct {
					Id           string `json:"_id"`
					LastModified string `json:"last_modified"`
				}
				if err := json.Unmarshal(line, &meta); err != nil {
					return nil, fmt.Errorf("pageOrder: unmarshal meta: %w", err)
				}
				if meta.Id != "" && len(tombstoneSet) > 0 {
					if ts, perr := bookIDToTombstone(meta.Id); perr == nil {
						if _, dead := tombstoneSet[ts]; dead {
							continue
						}
					}
				}
				refs = append(refs, displayRef{
					lastModified: meta.LastModified,
					id:           meta.Id,
					absOff:       lineOff,
					length:       len(line),
				})
			}
		}
	}

	sort.Slice(refs, func(i, j int) bool {
		if refs[i].lastModified != refs[j].lastModified {
			return refs[i].lastModified > refs[j].lastModified
		}
		return refs[i].id < refs[j].id
	})

	opened.pageOrder = refs
	opened.pageOrderBuilt = true
	return refs, nil
}

func (opened *OpenedSearch) LibrarianForUUID(ctx context.Context, uuid string) (string, error) {
	if uuid == "" {
		return "", nil
	}
	mf := opened.mf
	rdr := opened.rdr
	uuidBytes := []byte(uuid)

	for regIdx := len(mf.Regions) - 1; regIdx >= 0; regIdx-- {
		reg := mf.Regions[regIdx]
		if err := ctx.Err(); err != nil {
			return "", err
		}
		if reg.PostingsLen == 0 || reg.PostingsMetaLen == 0 {
			continue
		}
		postingsBytes := opened.postingsCache[regIdx].bytes
		entries := opened.postingsCache[regIdx].entries

		segments, _, err := intersectPostings(postingsBytes, entries, FieldLibraryUUID, []string{uuid})
		if err != nil {
			return "", fmt.Errorf("LibrarianForUUID: intersect (region %d): %w", regIdx, err)
		}
		if len(segments) == 0 {
			continue
		}

		displayIdxBytes := make([]byte, reg.DisplayIndexLen)
		if _, err := rdr.ReadAt(displayIdxBytes, int64(reg.DisplayIndexOff)); err != nil {
			return "", fmt.Errorf("LibrarianForUUID: read display index (region %d): %w", regIdx, err)
		}
		displayIdx := make([]uint32, len(displayIdxBytes)/4)
		if err := binary.Read(bytes.NewReader(displayIdxBytes), binary.LittleEndian, &displayIdx); err != nil {
			return "", fmt.Errorf("LibrarianForUUID: decode display index (region %d): %w", regIdx, err)
		}

		for _, seg := range segments {
			if seg >= len(displayIdx) {
				continue
			}
			var segStart int64
			if seg > 0 {
				segStart = int64(displayIdx[seg-1])
			}
			segEnd := int64(displayIdx[seg])
			segBytes := make([]byte, segEnd-segStart)
			if _, err := rdr.ReadAt(segBytes, int64(reg.DisplayOff)+segStart); err != nil && !errors.Is(err, io.EOF) {
				return "", fmt.Errorf("LibrarianForUUID: read segment (region %d, seg %d): %w", regIdx, seg, err)
			}

			lineReader := bufio.NewReader(bytes.NewReader(segBytes))
			for {
				line, err := lineReader.ReadBytes('\n')
				if err != nil {
					if err == io.EOF {
						break
					}
					return "", fmt.Errorf("LibrarianForUUID: read display line (region %d): %w", regIdx, err)
				}
				if len(line) == 0 || !bytes.Contains(line, uuidBytes) {
					continue
				}
				var book Book
				if err := json.Unmarshal(line, &book); err != nil {
					return "", fmt.Errorf("LibrarianForUUID: unmarshal display book (region %d): %w", regIdx, err)
				}
				if book.LibraryUUID != uuid {
					continue
				}
				return book.Librarian, nil
			}
		}
	}
	return "", nil
}

func (opened *OpenedSearch) LibraryMetadata(ctx context.Context) (map[string]LibraryMeta, error) {
	uuids := make(map[string]struct{})
	for regIdx := range opened.postingsCache {
		for _, e := range opened.postingsCache[regIdx].entries {
			if e.Field == FieldLibraryUUID && e.Term != "" {
				uuids[e.Term] = struct{}{}
			}
		}
	}
	if len(uuids) == 0 {
		return nil, nil
	}

	result := make(map[string]LibraryMeta, len(uuids))
	for uuid := range uuids {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		librarian, err := opened.LibrarianForUUID(ctx, uuid)
		if err != nil {
			return nil, fmt.Errorf("LibraryMetadata: librarian for %s: %w", uuid, err)
		}
		prefix := opened.prefixForUUID(ctx, uuid)
		result[uuid] = LibraryMeta{
			Librarian: librarian,
			Prefix:    prefix,
		}
	}
	return result, nil
}

func (opened *OpenedSearch) prefixForUUID(ctx context.Context, uuid string) string {
	mf := opened.mf
	rdr := opened.rdr
	uuidBytes := []byte(uuid)

	for regIdx := len(mf.Regions) - 1; regIdx >= 0; regIdx-- {
		reg := mf.Regions[regIdx]
		if ctx.Err() != nil {
			return ""
		}
		if reg.PostingsLen == 0 || reg.PostingsMetaLen == 0 {
			continue
		}
		postingsBytes := opened.postingsCache[regIdx].bytes
		entries := opened.postingsCache[regIdx].entries

		segments, _, err := intersectPostings(postingsBytes, entries, FieldLibraryUUID, []string{uuid})
		if err != nil || len(segments) == 0 {
			continue
		}

		displayIdxBytes := make([]byte, reg.DisplayIndexLen)
		if _, err := rdr.ReadAt(displayIdxBytes, int64(reg.DisplayIndexOff)); err != nil {
			continue
		}
		displayIdx := make([]uint32, len(displayIdxBytes)/4)
		if err := binary.Read(bytes.NewReader(displayIdxBytes), binary.LittleEndian, &displayIdx); err != nil {
			continue
		}

		for _, seg := range segments {
			if seg >= len(displayIdx) {
				continue
			}
			var segStart int64
			if seg > 0 {
				segStart = int64(displayIdx[seg-1])
			}
			segEnd := int64(displayIdx[seg])
			segBytes := make([]byte, segEnd-segStart)
			if _, err := rdr.ReadAt(segBytes, int64(reg.DisplayOff)+segStart); err != nil && !errors.Is(err, io.EOF) {
				continue
			}

			lineReader := bufio.NewReader(bytes.NewReader(segBytes))
			for {
				line, err := lineReader.ReadBytes('\n')
				if err != nil {
					break
				}
				if len(line) == 0 || !bytes.Contains(line, uuidBytes) {
					continue
				}
				var book Book
				if err := json.Unmarshal(line, &book); err != nil {
					continue
				}
				if book.LibraryUUID != uuid {
					continue
				}
				if book.BaseURL == "" {
					continue
				}
				return PrefixFromBaseURL(book.BaseURL)
			}
		}
	}
	return ""
}

func (opened *OpenedSearch) Librarians(ctx context.Context) ([]string, error) {
	uuids := make(map[string]struct{})
	for regIdx := range opened.postingsCache {
		for _, e := range opened.postingsCache[regIdx].entries {
			if e.Field == FieldLibraryUUID && e.Term != "" {
				uuids[e.Term] = struct{}{}
			}
		}
	}

	seen := make(map[string]struct{}, len(uuids))
	out := []string{}
	addLib := func(lib string) {
		if lib == "" {
			return
		}
		if _, dup := seen[lib]; dup {
			return
		}
		seen[lib] = struct{}{}
		out = append(out, lib)
	}

	for uuid := range uuids {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		lib, err := opened.LibrarianForUUID(ctx, uuid)
		if err != nil {
			return nil, err
		}
		addLib(lib)
	}

	if len(out) == 0 {
		const pageSize = 500
		for off := 0; ; off += pageSize {
			if err := ctx.Err(); err != nil {
				return nil, err
			}
			books, total, err := opened.PageBooks(ctx, off, pageSize)
			if err != nil {
				return nil, err
			}
			for _, b := range books {
				addLib(b.Librarian)
			}
			if len(books) == 0 || off+pageSize >= total {
				break
			}
		}
	}

	sort.Strings(out)
	return out, nil
}

func (opened *OpenedSearch) BooksByLibrarian(ctx context.Context, name string) ([]*Book, error) {
	name = strings.TrimSpace(name)
	if name == "" {
		return nil, nil
	}
	uuids := make(map[string]struct{})
	for regIdx := range opened.postingsCache {
		for _, e := range opened.postingsCache[regIdx].entries {
			if e.Field == FieldLibraryUUID && e.Term != "" {
				uuids[e.Term] = struct{}{}
			}
		}
	}
	var out []*Book
	for uuid := range uuids {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		lib, err := opened.LibrarianForUUID(ctx, uuid)
		if err != nil {
			return nil, err
		}
		if !strings.EqualFold(strings.TrimSpace(lib), name) {
			continue
		}
		bs, err := opened.BooksByLibraryUUID(ctx, uuid)
		if err != nil {
			return nil, err
		}
		out = append(out, bs...)
	}
	return out, nil
}

func (opened *OpenedSearch) BooksByLibraryUUID(ctx context.Context, uuid string) ([]*Book, error) {
	if uuid == "" {
		return nil, nil
	}
	mf := opened.mf
	rdr := opened.rdr

	tombstoneSet := make(map[[16]byte]struct{}, len(mf.Tombstones))
	for _, ts := range mf.Tombstones {
		tombstoneSet[ts] = struct{}{}
	}

	uuidBytes := []byte(uuid)
	byID := make(map[string]*Book)

	for regIdx := len(mf.Regions) - 1; regIdx >= 0; regIdx-- {
		reg := mf.Regions[regIdx]
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		if reg.PostingsLen == 0 || reg.PostingsMetaLen == 0 {
			continue
		}
		postingsBytes := opened.postingsCache[regIdx].bytes
		entries := opened.postingsCache[regIdx].entries

		segments, _, err := intersectPostings(postingsBytes, entries, FieldLibraryUUID, []string{uuid})
		if err != nil {
			return nil, fmt.Errorf("BooksByLibraryUUID: intersect (region %d): %w", regIdx, err)
		}
		if len(segments) == 0 {
			continue
		}

		displayIdxBytes := make([]byte, reg.DisplayIndexLen)
		if _, err := rdr.ReadAt(displayIdxBytes, int64(reg.DisplayIndexOff)); err != nil {
			return nil, fmt.Errorf("BooksByLibraryUUID: read display index (region %d): %w", regIdx, err)
		}
		displayIdx := make([]uint32, len(displayIdxBytes)/4)
		if err := binary.Read(bytes.NewReader(displayIdxBytes), binary.LittleEndian, &displayIdx); err != nil {
			return nil, fmt.Errorf("BooksByLibraryUUID: decode display index (region %d): %w", regIdx, err)
		}

		for _, seg := range segments {
			if seg >= len(displayIdx) {
				continue
			}
			var segStart int64
			if seg > 0 {
				segStart = int64(displayIdx[seg-1])
			}
			segEnd := int64(displayIdx[seg])
			segBytes := make([]byte, segEnd-segStart)
			if _, err := rdr.ReadAt(segBytes, int64(reg.DisplayOff)+segStart); err != nil && !errors.Is(err, io.EOF) {
				return nil, fmt.Errorf("BooksByLibraryUUID: read segment (region %d, seg %d): %w", regIdx, seg, err)
			}

			lineReader := bufio.NewReader(bytes.NewReader(segBytes))
			for {
				line, err := lineReader.ReadBytes('\n')
				if err != nil {
					if err == io.EOF {
						break
					}
					return nil, fmt.Errorf("BooksByLibraryUUID: read display line (region %d): %w", regIdx, err)
				}
				if len(line) == 0 || !bytes.Contains(line, uuidBytes) {
					continue
				}
				var book Book
				if err := json.Unmarshal(line, &book); err != nil {
					return nil, fmt.Errorf("BooksByLibraryUUID: unmarshal display book (region %d): %w", regIdx, err)
				}
				if book.LibraryUUID != uuid {
					continue
				}
				if book.Id != "" && len(tombstoneSet) > 0 {
					if ts, perr := bookIDToTombstone(book.Id); perr == nil {
						if _, dead := tombstoneSet[ts]; dead {
							continue
						}
					}
				}
				if _, seen := byID[book.Id]; seen {
					continue
				}
				bc := book
				byID[book.Id] = &bc
			}
		}
	}

	books := make([]*Book, 0, len(byID))
	for _, b := range byID {
		books = append(books, b)
	}
	sort.Sort(sort.Reverse(CalibreBooksByLastModified(books)))
	return books, nil
}
