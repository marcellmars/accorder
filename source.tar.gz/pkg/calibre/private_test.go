package calibre

import (
	"reflect"
	"testing"
)

func TestBook_HasPrivateTag(t *testing.T) {
	cases := []struct {
		tags []string
		want bool
	}{
		{[]string{"private"}, true},
		{[]string{"Private"}, true},
		{[]string{"PRIVATE"}, true},
		{[]string{"history", " private "}, true},
		{[]string{"privateer"}, false},
		{[]string{"not-private"}, false},
		{nil, false},
		{[]string{"public"}, false},
	}
	for _, c := range cases {
		b := &Book{Tags: c.tags}
		if got := b.HasPrivateTag(); got != c.want {
			t.Errorf("HasPrivateTag(%v) = %v, want %v", c.tags, got, c.want)
		}
	}
}

func TestBook_PrivateExcludeGlobs(t *testing.T) {
	b := &Book{Formats: []*File{
		{DirectoryPath: "Michel Foucault/Secret (1)"},
		{DirectoryPath: "Michel Foucault/Secret (1)"}, // dup → collapsed
		{DirectoryPath: "/Other Author/Thing (2)/"},
		{DirectoryPath: ""}, // skipped
	}}
	got := b.PrivateExcludeGlobs()
	want := []string{"/Michel Foucault/Secret (1)/**", "/Other Author/Thing (2)/**"}
	if !reflect.DeepEqual(got, want) {
		t.Errorf("PrivateExcludeGlobs() = %v, want %v", got, want)
	}
}
