package calibre

import "strings"

// HasPrivateTag reports whether the book carries a (case-insensitive) "private"
// tag, marking it as not-for-publication. Such books are excluded from the
// published index and their files are excluded from upload.
func (b *Book) HasPrivateTag() bool {
	for _, t := range b.Tags {
		if strings.EqualFold(strings.TrimSpace(t), "private") {
			return true
		}
	}
	return false
}

// PartitionPrivateBooks splits books into the ones to publish (kept) and the
// rclone exclude globs for the dirs of books tagged "private" (so their files
// are not uploaded). Used by both the index build and the standalone Render/OPF
// SPA build so a "private" book never appears in any rendered catalog.
func PartitionPrivateBooks(books []*Book) (kept []*Book, excludeGlobs []string) {
	seen := map[string]bool{}
	for _, b := range books {
		if b.HasPrivateTag() {
			for _, g := range b.PrivateExcludeGlobs() {
				if !seen[g] {
					seen[g] = true
					excludeGlobs = append(excludeGlobs, g)
				}
			}
			continue
		}
		kept = append(kept, b)
	}
	return kept, excludeGlobs
}

// PrivateExcludeGlobs returns rclone exclude patterns for a private book's
// on-disk directories, so `lib upload`'s mirror skips the book's files (and
// cover/OPF) entirely. Derived from each format's DirectoryPath, de-duplicated.
func (b *Book) PrivateExcludeGlobs() []string {
	seen := map[string]bool{}
	var globs []string
	add := func(dir string) {
		dir = strings.Trim(dir, "/")
		if dir == "" || seen[dir] {
			return
		}
		seen[dir] = true
		globs = append(globs, "/"+dir+"/**")
	}
	for _, f := range b.Formats {
		add(f.DirectoryPath)
	}
	return globs
}
