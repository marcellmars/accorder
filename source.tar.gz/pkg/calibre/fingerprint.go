package calibre

import (
	"encoding/base64"
	"image"
	"image/jpeg"
	"io"
	"os"
	"path/filepath"
)

const FingerprintSize = 6

// LocalCoverFingerprint computes the base64 cover fingerprint for a book whose
// cover lives on disk at dir/<coverURL> (the local cover.jpg). coverURL is the
// per-book relative path; an absolute coverURL is used as-is rather than joined
// (filepath.Join would otherwise treat it as relative to dir and yield a wrong
// path). Returns ("", false) when coverURL is empty, the cover is missing or
// undecodable, or the fingerprint is zero — callers leave CoverFingerprint unset
// in that case.
func LocalCoverFingerprint(dir, coverURL string) (string, bool) {
	if coverURL == "" {
		return "", false
	}
	path := coverURL
	if !filepath.IsAbs(path) {
		path = filepath.Join(dir, coverURL)
	}
	fp := CoverFingerprint(path)
	if IsZeroFingerprint(fp) {
		return "", false
	}
	return EncodeFingerprintBase64(fp), true
}

func CoverFingerprintFromReader(r io.Reader) [FingerprintSize]byte {
	var fp [FingerprintSize]byte
	img, err := jpeg.Decode(r)
	if err != nil {
		return fp
	}
	return fingerprintFromImage(img)
}

func CoverFingerprint(coverPath string) [FingerprintSize]byte {
	f, err := os.Open(coverPath)
	if err != nil {
		return [FingerprintSize]byte{}
	}
	defer f.Close()
	return CoverFingerprintFromReader(f)
}

func fingerprintFromImage(img image.Image) [FingerprintSize]byte {
	if yc, ok := img.(*image.YCbCr); ok {
		return fingerprintFromYCbCr(yc)
	}
	return fingerprintFromGeneric(img)
}

func fingerprintFromYCbCr(yc *image.YCbCr) [FingerprintSize]byte {
	var fp [FingerprintSize]byte

	b := yc.Rect
	w, h := b.Dx(), b.Dy()
	if w == 0 || h == 0 {
		return fp
	}

	cellW := float64(w) / 3.0
	cellH := float64(h) / 4.0

	var lumas [12]uint8
	var sumCb, sumCr, nPx float64

	for row := 0; row < 4; row++ {
		for col := 0; col < 3; col++ {
			x0 := int(float64(col) * cellW)
			y0 := int(float64(row) * cellH)
			x1 := int(float64(col+1) * cellW)
			y1 := int(float64(row+1) * cellH)

			var sumY, count float64
			for y := y0; y < y1; y++ {
				for x := x0; x < x1; x++ {
					ax, ay := b.Min.X+x, b.Min.Y+y
					sumY += float64(yc.Y[yc.YOffset(ax, ay)])
					ci := yc.COffset(ax, ay)
					sumCb += float64(yc.Cb[ci])
					sumCr += float64(yc.Cr[ci])
					nPx++
					count++
				}
			}
			avgY := sumY / count / 255.0
			level := int(avgY * 7.999)
			if level > 7 {
				level = 7
			}
			lumas[row*3+col] = uint8(level)
		}
	}

	var bits uint64
	for i := 0; i < 12; i++ {
		bits |= uint64(lumas[i]) << (uint(i) * 3)
	}

	avgCb := sumCb / nPx / 255.0
	avgCr := sumCr / nPx / 255.0
	cbQ := int(avgCb * 15.999)
	crQ := int(avgCr * 15.999)
	if cbQ < 0 {
		cbQ = 0
	}
	if cbQ > 15 {
		cbQ = 15
	}
	if crQ < 0 {
		crQ = 0
	}
	if crQ > 15 {
		crQ = 15
	}

	bits |= uint64(cbQ) << 36
	bits |= uint64(crQ) << 40

	for i := 0; i < 6; i++ {
		fp[i] = byte(bits >> (uint(i) * 8))
	}
	return fp
}

func fingerprintFromGeneric(img image.Image) [FingerprintSize]byte {
	var fp [FingerprintSize]byte

	bounds := img.Bounds()
	w, h := bounds.Dx(), bounds.Dy()
	if w == 0 || h == 0 {
		return fp
	}

	cellW := float64(w) / 3.0
	cellH := float64(h) / 4.0

	var lumas [12]uint8
	var sumCb, sumCr, nPx float64

	for row := 0; row < 4; row++ {
		for col := 0; col < 3; col++ {
			x0 := int(float64(col) * cellW)
			y0 := int(float64(row) * cellH)
			x1 := int(float64(col+1) * cellW)
			y1 := int(float64(row+1) * cellH)

			var sumY float64
			var count float64
			for y := y0; y < y1; y++ {
				for x := x0; x < x1; x++ {
					r, g, b, _ := img.At(bounds.Min.X+x, bounds.Min.Y+y).RGBA()
					yy := 0.299*float64(r) + 0.587*float64(g) + 0.114*float64(b)
					sumY += yy
					cb := -0.169*float64(r) - 0.331*float64(g) + 0.500*float64(b)
					cr := 0.500*float64(r) - 0.419*float64(g) - 0.081*float64(b)
					sumCb += cb
					sumCr += cr
					nPx++
					count++
				}
			}
			avgY := sumY / count / 65535.0
			level := int(avgY * 7.999)
			if level > 7 {
				level = 7
			}
			lumas[row*3+col] = uint8(level)
		}
	}

	var bits uint64
	for i := 0; i < 12; i++ {
		bits |= uint64(lumas[i]) << (uint(i) * 3)
	}

	avgCb := sumCb/nPx/65535.0 + 0.5
	avgCr := sumCr/nPx/65535.0 + 0.5
	cbQ := int(avgCb * 15.999)
	crQ := int(avgCr * 15.999)
	if cbQ < 0 {
		cbQ = 0
	}
	if cbQ > 15 {
		cbQ = 15
	}
	if crQ < 0 {
		crQ = 0
	}
	if crQ > 15 {
		crQ = 15
	}

	bits |= uint64(cbQ) << 36
	bits |= uint64(crQ) << 40

	for i := 0; i < 6; i++ {
		fp[i] = byte(bits >> (uint(i) * 8))
	}
	return fp
}

func EncodeFingerprintBase64(fp [FingerprintSize]byte) string {
	return base64.StdEncoding.EncodeToString(fp[:])
}

func DecodeFingerprintBase64(s string) [FingerprintSize]byte {
	var fp [FingerprintSize]byte
	if s == "" {
		return fp
	}
	b, err := base64.StdEncoding.DecodeString(s)
	if err != nil || len(b) < FingerprintSize {
		return fp
	}
	copy(fp[:], b)
	return fp
}

func IsZeroFingerprint(fp [FingerprintSize]byte) bool {
	return fp == [FingerprintSize]byte{}
}
