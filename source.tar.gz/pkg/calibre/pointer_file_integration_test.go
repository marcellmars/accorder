package calibre

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

// writeDeltaJSONL writes a small set of "new" books for delta-append testing.
func writeDeltaJSONL(tb testing.TB, path string) {
	tb.Helper()
	f, err := os.Create(path)
	if err != nil {
		tb.Fatal(err)
	}
	defer f.Close()
	books := []*Book{
		{Id: "delta-001", Title: "Delta Book One", Authors: []string{"Delta Author"}, Tags: []string{"test"}, LastModified: "2026-01-01"},
		{Id: "delta-002", Title: "Delta Book Two", Authors: []string{"Delta Author"}, Tags: []string{"test"}, LastModified: "2026-01-02"},
	}
	for _, b := range books {
		line, err := json.Marshal(b)
		if err != nil {
			tb.Fatal(err)
		}
		f.Write(line)
		f.Write([]byte("\n"))
	}
}

// TestBuildAppendWritesPointerFile builds an index, then appends delta books,
// and verifies the pointer file is written with an incremented pointerGeneration.
func TestBuildAppendWritesPointerFile(t *testing.T) {
	jsonlPath := seedJSONL(t, 8)
	dir := filepath.Dir(jsonlPath)
	indexPath := filepath.Join(dir, "pf-append")
	lib := PointerFileLibrary{UUID: "test-uuid", Librarian: "tester"}

	// Initial build (CompressToFile).
	ms := &MotwSearch{JsonlPath: jsonlPath, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex: %v", err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatalf("CompressToFile: %v", err)
	}
	mf, err := ReadExistingManifest(indexPath)
	if err != nil {
		t.Fatalf("ReadExistingManifest: %v", err)
	}
	if err := WritePointerFile(indexPath, mf, lib, false); err != nil {
		t.Fatalf("WritePointerFile (initial): %v", err)
	}

	pf1, err := ReadPointerFile(indexPath + ".manifest.json")
	if err != nil {
		t.Fatalf("ReadPointerFile (initial): %v", err)
	}
	if pf1.Index.PointerGeneration != 1 {
		t.Fatalf("initial pointerGeneration: got %d, want 1", pf1.Index.PointerGeneration)
	}

	// Build a small delta and append it.
	deltaPath := filepath.Join(dir, "delta.jsonl")
	writeDeltaJSONL(t, deltaPath)
	ms2 := &MotwSearch{JsonlPath: deltaPath, IndexPath: indexPath}
	deltaIdx, err := ms2.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex (delta): %v", err)
	}
	if err := ms2.AppendToFile(deltaIdx, nil); err != nil {
		t.Fatalf("AppendToFile: %v", err)
	}

	// Write pointer file after append.
	mf2, err := ReadExistingManifest(indexPath)
	if err != nil {
		t.Fatalf("ReadExistingManifest (after append): %v", err)
	}
	if err := WritePointerFile(indexPath, mf2, lib, false); err != nil {
		t.Fatalf("WritePointerFile (append): %v", err)
	}

	pf2, err := ReadPointerFile(indexPath + ".manifest.json")
	if err != nil {
		t.Fatalf("ReadPointerFile (append): %v", err)
	}
	if pf2.Index.PointerGeneration != 2 {
		t.Fatalf("append pointerGeneration: got %d, want 2", pf2.Index.PointerGeneration)
	}
	if pf2.Index.Regions != len(mf2.Regions) {
		t.Errorf("regions mismatch: pointer=%d, manifest=%d", pf2.Index.Regions, len(mf2.Regions))
	}
}

// TestBuildCompactPreservesPointerGeneration verifies that compaction after append
// does not reset pointerGeneration (the pointer file uses its own monotonic counter).
func TestBuildCompactPreservesPointerGeneration(t *testing.T) {
	jsonlPath := seedJSONL(t, 8)
	dir := filepath.Dir(jsonlPath)
	indexPath := filepath.Join(dir, "pf-compact")
	lib := PointerFileLibrary{UUID: "test-uuid-2", Librarian: "tester"}

	// Initial build.
	ms := &MotwSearch{JsonlPath: jsonlPath, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex: %v", err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatalf("CompressToFile: %v", err)
	}
	mf, err := ReadExistingManifest(indexPath)
	if err != nil {
		t.Fatalf("ReadExistingManifest: %v", err)
	}

	// Write as append (ptrGen=1).
	if err := WritePointerFile(indexPath, mf, lib, false); err != nil {
		t.Fatalf("WritePointerFile (initial): %v", err)
	}

	// Now compact (ptrGen should be 2, not reset to 1).
	ms2 := &MotwSearch{JsonlPath: jsonlPath, IndexPath: indexPath}
	ms2.BaseGeneration = &mf.BaseGeneration
	idx2, err := ms2.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex (compact): %v", err)
	}
	if err := ms2.CompressToFile(idx2); err != nil {
		t.Fatalf("CompressToFile (compact): %v", err)
	}
	mf2, err := ReadExistingManifest(indexPath)
	if err != nil {
		t.Fatalf("ReadExistingManifest (compact): %v", err)
	}
	if err := WritePointerFile(indexPath, mf2, lib, true); err != nil {
		t.Fatalf("WritePointerFile (compact): %v", err)
	}

	pf, err := ReadPointerFile(indexPath + ".manifest.json")
	if err != nil {
		t.Fatalf("ReadPointerFile: %v", err)
	}
	if pf.Index.PointerGeneration != 2 {
		t.Fatalf("compact pointerGeneration: got %d, want 2 (not reset)", pf.Index.PointerGeneration)
	}
	if !pf.Index.IsCompacted {
		t.Error("expected IsCompacted=true after compact")
	}
	if pf.LastCompact == nil {
		t.Fatal("expected LastCompact non-nil after compact")
	}
	if pf.LastCompact.PointerGeneration != 2 {
		t.Errorf("LastCompact.PointerGeneration: got %d, want 2", pf.LastCompact.PointerGeneration)
	}
}

// TestBuildAppendNoChangeEnsuresPointerFile verifies that --append with no changes
// creates the pointer file if missing, but does not advance pointerGeneration.
func TestBuildAppendNoChangeEnsuresPointerFile(t *testing.T) {
	jsonlPath := seedJSONL(t, 8)
	dir := filepath.Dir(jsonlPath)
	indexPath := filepath.Join(dir, "pf-nochange")
	lib := PointerFileLibrary{UUID: "test-uuid-3", Librarian: "tester"}

	// Initial build (no pointer file written — simulates pre-pointer-file index).
	ms := &MotwSearch{JsonlPath: jsonlPath, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex: %v", err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatalf("CompressToFile: %v", err)
	}

	// Verify pointer file does NOT exist yet.
	pfPath := indexPath + ".manifest.json"
	if _, err := os.Stat(pfPath); err == nil {
		t.Fatal("pointer file should not exist before EnsurePointerFile")
	}

	// EnsurePointerFile (backfill).
	mf, err := ReadExistingManifest(indexPath)
	if err != nil {
		t.Fatalf("ReadExistingManifest: %v", err)
	}
	if err := EnsurePointerFile(indexPath, mf, lib); err != nil {
		t.Fatalf("EnsurePointerFile: %v", err)
	}

	pf, err := ReadPointerFile(pfPath)
	if err != nil {
		t.Fatalf("ReadPointerFile: %v", err)
	}
	if pf.Index.PointerGeneration != 1 {
		t.Fatalf("backfill pointerGeneration: got %d, want 1", pf.Index.PointerGeneration)
	}

	// Call EnsurePointerFile again — should NOT overwrite.
	if err := EnsurePointerFile(indexPath, mf, lib); err != nil {
		t.Fatalf("EnsurePointerFile (second): %v", err)
	}
	pf2, err := ReadPointerFile(pfPath)
	if err != nil {
		t.Fatalf("ReadPointerFile (second): %v", err)
	}
	if pf2.Index.PointerGeneration != 1 {
		t.Fatalf("second call pointerGeneration: got %d, want 1 (should not advance)", pf2.Index.PointerGeneration)
	}
}
