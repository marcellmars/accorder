package calibre

import (
	"encoding/xml"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"

	"github.com/karrick/godirwalk"
)

func (motw *MotwStandaloneApp) RenderWithOPF() error {
	// The OPF path builds purely from per-book metadata.opf files and never reads
	// metadata.db, so the DB's presence is irrelevant here — OPF is one render
	// option, not authoritative over metadata.db, and must not require deleting it.
	motw.getBooksOPFSafe()
	before := len(motw.Books)
	motw.Books, motw.PrivateExcludes = PartitionPrivateBooks(motw.Books)
	if dropped := before - len(motw.Books); dropped > 0 {
		log.Printf("RenderWithOPF: excluded %d book(s) tagged \"private\" from the browse site", dropped)
	}

	if err := motw.AssertBookIDsUnique(); err != nil {
		return fmt.Errorf("RenderWithOPF: %w", err)
	}

	if err := RenderBooksBundle(motw.CalibreDirectory, motw.Books); err != nil {
		return fmt.Errorf("RenderWithOPF: %w", err)
	}

	log.Printf("RenderWithOPF: built %d books at %s", len(motw.Books), filepath.Join(motw.CalibreDirectory, "BROWSE_LIBRARY.html"))
	return nil
}

func (motw *MotwStandaloneApp) getBooksOPFSafe() {
	var outputs sync.Map
	var wg sync.WaitGroup
	var counter atomic.Uint64
	count := 0
	err := godirwalk.Walk(motw.CalibreDirectory, &godirwalk.Options{
		Callback: func(path string, info *godirwalk.Dirent) error {
			if info.Name() == "metadata.opf" {
				bookOpf := &BookOPF{}
				count++
				wg.Add(1)
				go func(bookOpf *BookOPF) {
					defer wg.Done()
					relativeDirPath := strings.NewReplacer(motw.CalibreDirectory, "", "metadata.opf", "").Replace(path)
					f, err := os.ReadFile(path)
					if err != nil {
						log.Printf("getBooksOPFSafe: skip %s: %v", path, err)
						return
					}
					if err := xml.Unmarshal(f, bookOpf); err != nil {
						log.Printf("getBooksOPFSafe: skip %s: xml parse: %v", path, err)
						return
					}

					book := &Book{
						Title:        bookOpf.Metadata.Title,
						TitleSort:    bookOpf.TitleSort(),
						Authors:      bookOpf.Authors(),
						Pubdate:      bookOpf.Metadata.Published,
						LastModified: bookOpf.LastModified(),
						Tags:         bookOpf.Tags(),
						Publisher:    bookOpf.Metadata.Publisher,
						Abstract:     bookOpf.Metadata.Description,
						Languages:    bookOpf.Languages(),
						Identifiers:  bookOpf.Identifiers(),
						Formats:      FormatsSafe(motw.CalibreDirectory, relativeDirPath),
						CoverUrl:     filepath.Join(relativeDirPath, "cover.jpg"),
						UUID:         bookOpf.UUID(),
					}
					book.MemoryOfTheWorldify(motw)
					outputs.Store(counter.Add(1), book)
				}(bookOpf)
			}
			if count > 100 {
				wg.Wait()
				count = 0
			}
			return nil
		},
		ErrorCallback: func(path string, err error) godirwalk.ErrorAction {
			log.Printf("getBooksOPFSafe: walk error %s: %v", path, err)
			return godirwalk.SkipNode
		},
		Unsorted: true,
	})
	wg.Wait()

	if err != nil {
		log.Printf("getBooksOPFSafe: walk root error: %v", err)
	}

	outputs.Range(func(key, value interface{}) bool {
		book, ok := value.(*Book)
		if ok {
			motw.Books = append(motw.Books, book)
		}
		return true
	})
}

func FormatsSafe(calibrePath, relativeDirPath string) []*File {
	path := filepath.Join(calibrePath, relativeDirPath)
	if !strings.HasSuffix(path, "/") {
		path = path + "/"
	}
	formats := []*File{}
	files, err := os.ReadDir(path)
	if err != nil {
		log.Printf("FormatsSafe: skip %s: %v", path, err)
		return formats
	}

	for _, f := range files {
		if f.Name() == "metadata.opf" || f.Name() == "cover.jpg" {
			continue
		}
		if f.IsDir() {
			continue
		}
		fi, err := f.Info()
		if err != nil {
			log.Printf("FormatsSafe: skip %s/%s: %v", path, f.Name(), err)
			continue
		}
		formats = append(formats, &File{
			Format:        strings.ReplaceAll(filepath.Ext(f.Name()), ".", ""),
			DirectoryPath: relativeDirPath,
			Name:          f.Name(),
			Size:          fi.Size(),
		})
	}
	return formats
}
