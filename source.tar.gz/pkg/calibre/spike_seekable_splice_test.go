package calibre

// Phase-0 spike for WF3 (fedlib-operations): seekable-frame splice.
//

// Validates the HARDEST unproven assumption: N members' pre-compressed seekable
// streams (each under a DISTINCT raw dict / Dictionary_ID) can be spliced into
// ONE seekable-zstd stream with a VALID seek table, WITHOUT recompressing.
//

// The test builds 2 small seekable streams (each hand-rolled under a
// different dict), extracts their compressed frames + seek-table entries,
// merges them into a single seekable stream with a combined seek table, then
// opens it with the owned reader (newMWSCReaderAt) + a multi-dict
// zstd.Decoder and asserts every region round-trips byte-identically.
//

// If this fails, the WF3 "compose ≡ splice" design is invalid — the aggregate
// must recompile (decompress + re-encode) rather than concatenate frames.

import (
	"bytes"
	"testing"

	"github.com/klauspost/compress/zstd"
)

// buildSeekableStream creates a seekable-zstd stream from the payload using
// the given dictID + raw dict via the hand-rolled writer path (per-chunk
// EncodeAll + writeSeekTable). Chunked to yield multiple frames per stream.
func buildSeekableStream(t *testing.T, id uint32, dict, payload []byte) []byte {
	t.Helper()
	mid := len(payload) / 2
	if mid == 0 {
		mid = len(payload)
	}
	encOpts := []zstd.EOption{
		zstd.WithEncoderLevel(zstd.SpeedBestCompression),
		zstd.WithEncoderDictRaw(id, dict),
	}
	return handRolledSeekableStream(t, encOpts, mid, seekTableEntrySizeCksm, payload)
}

// TestSpike_SeekableSplice_MultiDictFrames splices two seekable streams (each
// under a different dict/dictID) into one stream, then reads back each region.
func TestSpike_SeekableSplice_MultiDictFrames(t *testing.T) {
	dictA := rawDict("alpha")
	dictB := rawDict("bravo")
	payloadA := dictBackedPayload(dictA, "\n{\"_id\":\"a1\",\"title\":\"Cybernetics\"}\n")
	payloadB := dictBackedPayload(dictB, "\n{\"_id\":\"b1\",\"title\":\"Spectacle\"}\n")

	streamA := buildSeekableStream(t, 10, dictA, payloadA)
	streamB := buildSeekableStream(t, 20, dictB, payloadB)

	// Parse seek tables from each stream.
	entriesA, entrySzA, tableStartA := readSeekTableEntriesTB(t, streamA)
	entriesB, entrySzB, tableStartB := readSeekTableEntriesTB(t, streamB)
	if entrySzA != entrySzB {
		t.Fatalf("entry size mismatch: A=%d B=%d", entrySzA, entrySzB)
	}
	entrySize := entrySzA
	framesA := streamA[:tableStartA] // compressed frames only (no seek table)
	framesB := streamB[:tableStartB]

	// Splice: concatenate frames, then merge seek-table entries.
	// Stream B's entries need NO offset adjustment — the seek table stores
	// per-frame (compressed-size, decompressed-size[, checksum]), NOT absolute
	// offsets. The reader reconstructs absolute offsets by prefix-summing.
	var spliced bytes.Buffer
	spliced.Write(framesA)
	spliced.Write(framesB)
	mergedEntries := make([]byte, len(entriesA)+len(entriesB))
	copy(mergedEntries, entriesA)
	copy(mergedEntries[len(entriesA):], entriesB)
	writeSeekTableBuf(t, &spliced, mergedEntries, entrySize)

	// Open the spliced stream with a multi-dict decoder.
	dec, err := zstd.NewReader(nil,
		zstd.WithDecoderDictRaw(10, dictA),
		zstd.WithDecoderDictRaw(20, dictB),
	)
	if err != nil {
		t.Fatalf("multi-dict decoder: %v", err)
	}
	defer dec.Close()

	sb := spliced.Bytes()
	rdr, err := newMWSCReaderAt(bytes.NewReader(sb), int64(len(sb)), dec)
	if err != nil {
		t.Fatalf("spliced seekable reader: %v", err)
	}
	defer rdr.Close()

	totalExpected := int64(len(payloadA) + len(payloadB))
	if rdr.Size() != totalExpected {
		t.Fatalf("spliced Size=%d want %d", rdr.Size(), totalExpected)
	}

	// Read region A at offset 0.
	gotA := make([]byte, len(payloadA))
	if _, err := rdr.ReadAt(gotA, 0); err != nil {
		t.Fatalf("ReadAt region A: %v", err)
	}
	if !bytes.Equal(gotA, payloadA) {
		t.Fatalf("region A mismatch: got %d bytes, want %d", len(gotA), len(payloadA))
	}

	// Read region B at offset len(payloadA).
	gotB := make([]byte, len(payloadB))
	if _, err := rdr.ReadAt(gotB, int64(len(payloadA))); err != nil {
		t.Fatalf("ReadAt region B: %v", err)
	}
	if !bytes.Equal(gotB, payloadB) {
		t.Fatalf("region B mismatch: got %d bytes, want %d", len(gotB), len(payloadB))
	}

	t.Logf("VALIDATED: seekable-frame splice works — %d frames from 2 streams under "+
		"different dicts, spliced size=%d, both regions round-trip byte-identical",
		rdr.numFrames(), len(sb))
}

// TestSpike_SeekableSplice_ThreeMembers extends the splice to 3 members,
// validating that the approach scales beyond 2.
func TestSpike_SeekableSplice_ThreeMembers(t *testing.T) {
	type member struct {
		id      uint32
		dict    []byte
		payload []byte
	}
	members := []member{
		{1, rawDict("alice"), dictBackedPayload(rawDict("alice"), "\nalice-books\n")},
		{2, rawDict("bob"), dictBackedPayload(rawDict("bob"), "\nbob-books\n")},
		{3, rawDict("carol"), dictBackedPayload(rawDict("carol"), "\ncarol-books\n")},
	}

	// Build per-member seekable streams, extract frames + entries.
	type parsed struct {
		frames  []byte
		entries []byte
	}
	var entrySize int
	parts := make([]parsed, len(members))
	for i, m := range members {
		stream := buildSeekableStream(t, m.id, m.dict, m.payload)
		entries, esz, tableStart := readSeekTableEntriesTB(t, stream)
		if i == 0 {
			entrySize = esz
		} else if esz != entrySize {
			t.Fatalf("entry size mismatch member %d: %d vs %d", i, esz, entrySize)
		}
		parts[i] = parsed{frames: stream[:tableStart], entries: entries}
	}

	// Splice all frames + merge all seek-table entries.
	var spliced bytes.Buffer
	var mergedEntries []byte
	for _, p := range parts {
		spliced.Write(p.frames)
		mergedEntries = append(mergedEntries, p.entries...)
	}
	writeSeekTableBuf(t, &spliced, mergedEntries, entrySize)

	// Multi-dict decoder with all 3 dicts.
	opts := make([]zstd.DOption, len(members))
	for i, m := range members {
		opts[i] = zstd.WithDecoderDictRaw(m.id, m.dict)
	}
	dec, err := zstd.NewReader(nil, opts...)
	if err != nil {
		t.Fatalf("decoder: %v", err)
	}
	defer dec.Close()

	sb := spliced.Bytes()
	rdr, err := newMWSCReaderAt(bytes.NewReader(sb), int64(len(sb)), dec)
	if err != nil {
		t.Fatalf("spliced reader: %v", err)
	}
	defer rdr.Close()

	// Verify each member's payload at the correct offset.
	off := int64(0)
	for i, m := range members {
		got := make([]byte, len(m.payload))
		if _, err := rdr.ReadAt(got, off); err != nil {
			t.Fatalf("member %d ReadAt: %v", i, err)
		}
		if !bytes.Equal(got, m.payload) {
			t.Fatalf("member %d payload mismatch at offset %d", i, off)
		}
		off += int64(len(m.payload))
	}
	t.Logf("VALIDATED: 3-member splice — %d total frames, all regions byte-identical", rdr.numFrames())
}
