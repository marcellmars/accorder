package calibre

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"testing"

	"github.com/goccy/go-json"
)

// TestOpenedSearchLibrarians verifies OpenedSearch.Librarians enumerates the
// DISTINCT librarian names across all libraries in an aggregate index — the data
// behind the SELECT LIBRARIANS dropdown. It builds an index with three library
// UUIDs spanning two librarians (alice in two libraries, bob in one) and asserts
// the result is deduped and sorted. Requires IndexAggregateFields (the aggregate
// builder's setting), which is what writes the FieldLibraryUUID postings.
func TestOpenedSearchLibrarians(t *testing.T) {
	dir := t.TempDir()
	jsonlPath := filepath.Join(dir, "books.jsonl")

	type seed struct{ uuid, librarian, title string }
	seeds := []seed{
		{"uuid-a", "alice", "A1"},
		{"uuid-a", "alice", "A2"},
		{"uuid-b", "bob", "B1"},
		{"uuid-c", "alice", "C1"},
	}
	books := make([]Book, 0, 40)
	for i, s := range seeds {
		books = append(books, Book{
			Id:           fmt.Sprintf("id-%d", i),
			Title:        s.title,
			Authors:      []string{"X"},
			LibraryUUID:  s.uuid,
			Librarian:    s.librarian,
			LastModified: fmt.Sprintf("2024-01-%02dT00:00:00+00:00", i+1),
		})
	}
	// Pad past the 16-book segment boundary so postings span multiple segments.
	for i := len(seeds); i < 40; i++ {
		books = append(books, Book{
			Id:           fmt.Sprintf("pad-%d", i),
			Title:        fmt.Sprintf("P%d", i),
			Authors:      []string{"X"},
			LibraryUUID:  "uuid-b",
			Librarian:    "bob",
			LastModified: fmt.Sprintf("2024-03-%02dT00:00:00+00:00", (i%28)+1),
		})
	}

	f, err := os.Create(jsonlPath)
	if err != nil {
		t.Fatal(err)
	}
	for _, b := range books {
		data, err := json.Marshal(b)
		if err != nil {
			t.Fatal(err)
		}
		if _, err := f.Write(append(data, '\n')); err != nil {
			t.Fatal(err)
		}
	}
	f.Close()

	indexPath := filepath.Join(dir, "agg-index")
	ms := &MotwSearch{JsonlPath: jsonlPath, IndexPath: indexPath, IndexAggregateFields: true}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex: %v", err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatalf("CompressToFile: %v", err)
	}

	opened, err := (&MotwSearch{IndexPath: indexPath}).Open()
	if err != nil {
		t.Fatalf("Open: %v", err)
	}
	defer opened.Close()

	libs, err := opened.Librarians(context.Background())
	if err != nil {
		t.Fatalf("Librarians: %v", err)
	}
	want := []string{"alice", "bob"}
	if !reflect.DeepEqual(libs, want) {
		t.Fatalf("Librarians = %v, want %v (distinct, sorted)", libs, want)
	}
}

// TestOpenedSearchLibrariansPerLibraryFallback covers the per-library index path:
// a plain `calibre build --index` (IndexAggregateFields=false) writes NO
// FieldLibraryUUID postings, so the fast path finds nothing. Librarians must then
// fall back to scanning the display records' librarian field. (Regression: the
// first cut only read postings and returned an empty dropdown for single-library
// indexes like a librarian's own shared catalog.)
func TestOpenedSearchLibrariansPerLibraryFallback(t *testing.T) {
	dir := t.TempDir()
	jsonlPath := filepath.Join(dir, "books.jsonl")

	books := make([]Book, 0, 40)
	for i := 0; i < 40; i++ {
		books = append(books, Book{
			Id:           fmt.Sprintf("id-%d", i),
			Title:        fmt.Sprintf("T%d", i),
			Authors:      []string{"X"},
			Librarian:    "marcellmars",
			LastModified: fmt.Sprintf("2024-01-%02dT00:00:00+00:00", (i%28)+1),
		})
	}

	f, err := os.Create(jsonlPath)
	if err != nil {
		t.Fatal(err)
	}
	for _, b := range books {
		data, err := json.Marshal(b)
		if err != nil {
			t.Fatal(err)
		}
		if _, err := f.Write(append(data, '\n')); err != nil {
			t.Fatal(err)
		}
	}
	f.Close()

	indexPath := filepath.Join(dir, "perlib-index")
	// IndexAggregateFields left false — the per-library build path.
	ms := &MotwSearch{JsonlPath: jsonlPath, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex: %v", err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatalf("CompressToFile: %v", err)
	}

	opened, err := (&MotwSearch{IndexPath: indexPath}).Open()
	if err != nil {
		t.Fatalf("Open: %v", err)
	}
	defer opened.Close()

	libs, err := opened.Librarians(context.Background())
	if err != nil {
		t.Fatalf("Librarians: %v", err)
	}
	want := []string{"marcellmars"}
	if !reflect.DeepEqual(libs, want) {
		t.Fatalf("Librarians (per-library fallback) = %v, want %v", libs, want)
	}
}
