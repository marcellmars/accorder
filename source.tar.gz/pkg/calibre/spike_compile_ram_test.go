//go:build linux

package calibre

// Spike: peak RAM of the client-side compile (BuildIndex + CompressToFile),
// measured at several corpus sizes on the REAL aggregate JSONL, so the Tor
// `lib browse` path can PREDICT compile RAM from the manifest (numBooks /
// jsonlBytes) and refuse the JSONL path when it wouldn't fit.
//

//   REPORT=/tmp/ram.txt AGG_INDEX=/tmp/agg/library_index \
//     go test ./pkg/calibre/ -run TestSpikeCompileRAM -v -timeout 40m
//

// Reports, per size: peak Go heap (HeapInuse), peak runtime Sys, and process
// peak RSS (getrusage Maxrss, monotonic — so it reflects the largest run).

import (
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"runtime/debug"
	"strings"
	"sync"
	"syscall"
	"testing"
	"time"
)

type peakSampler struct {
	stop      chan struct{}
	wg        sync.WaitGroup
	mu        sync.Mutex
	heapInuse uint64
	sysMem    uint64
}

func startPeakSampler() *peakSampler {
	p := &peakSampler{stop: make(chan struct{})}
	p.wg.Add(1)
	go func() {
		defer p.wg.Done()
		t := time.NewTicker(15 * time.Millisecond)
		defer t.Stop()
		var m runtime.MemStats
		for {
			select {
			case <-p.stop:
				return
			case <-t.C:
				runtime.ReadMemStats(&m)
				p.mu.Lock()
				if m.HeapInuse > p.heapInuse {
					p.heapInuse = m.HeapInuse
				}
				if m.Sys > p.sysMem {
					p.sysMem = m.Sys
				}
				p.mu.Unlock()
			}
		}
	}()
	return p
}

func (p *peakSampler) finish() (heapInuse, sysMem uint64) {
	close(p.stop)
	p.wg.Wait()
	return p.heapInuse, p.sysMem
}

func maxRSSBytes() uint64 {
	var ru syscall.Rusage
	_ = syscall.Getrusage(syscall.RUSAGE_SELF, &ru)
	return uint64(ru.Maxrss) * 1024 // Linux reports KB
}

func TestSpikeCompileRAM(t *testing.T) {
	orig := os.Getenv("AGG_INDEX")
	if orig == "" {
		t.Skip("set AGG_INDEX=/path/to/library_index (no .zst) to run")
	}
	var rep strings.Builder
	logf := func(format string, a ...any) {
		line := fmt.Sprintf(format, a...)
		t.Log(line)
		rep.WriteString(line + "\n")
	}
	defer func() {
		if p := os.Getenv("REPORT"); p != "" {
			_ = os.WriteFile(p, []byte(rep.String()), 0o644)
		}
	}()

	mf, err := ReadExistingManifest(orig)
	if err != nil {
		t.Fatalf("manifest: %v", err)
	}

	// Extract the full display-JSONL once, slice it into line-count fractions,
	// write each subsample to its own file, then free the big buffer so the
	// per-run heap measurements aren't polluted by the 471 MB extract.
	full, err := ReadDisplayJSONL(orig)
	if err != nil {
		t.Fatalf("ReadDisplayJSONL: %v", err)
	}

	// line offsets
	var lineEnds []int
	for i, b := range full {
		if b == '\n' {
			lineEnds = append(lineEnds, i+1)
		}
	}
	totalLines := len(lineEnds)
	dir := t.TempDir()
	type sample struct {
		path  string
		books int
		bytes int
	}
	fracs := []float64{0.25, 0.50, 1.00}
	var samples []sample
	for _, fr := range fracs {
		n := int(float64(totalLines) * fr)
		if n < 1 {
			n = 1
		}
		end := lineEnds[n-1]
		p := filepath.Join(dir, fmt.Sprintf("books_%d.jsonl", n))
		if err := os.WriteFile(p, full[:end], 0o644); err != nil {
			t.Fatalf("write subsample: %v", err)
		}
		samples = append(samples, sample{p, n, end})
	}
	full = nil
	lineEnds = nil
	runtime.GC()
	debug.FreeOSMemory()

	logf("RAM spike — compile = BuildIndex + CompressToFile (manifest numBooks=%d)", mf.NumBooks)
	logf("%-8s %10s %12s %12s %12s %14s %14s",
		"books", "jsonlMB", "heapPeakMB", "sysPeakMB", "rssPeakMB", "heapB/book", "heapB/jsonlB")

	baseGen := mf.BaseGeneration
	dictID := uint32(0)
	if len(mf.Regions) > 0 {
		dictID = mf.Regions[0].DictID
	}

	for _, s := range samples {
		runtime.GC()
		debug.FreeOSMemory()
		rebuild := filepath.Join(dir, fmt.Sprintf("idx_%d", s.books))
		ms := &MotwSearch{
			JsonlPath: s.path, IndexPath: rebuild,
			BaseGeneration: &baseGen, StartGeneration: mf.Generation,
			IndexAggregateFields: true, DictID: dictID, ChunkSize: int(mf.ChunkSize),
		}
		sampler := startPeakSampler()
		idx, err := ms.BuildIndex()
		if err != nil {
			t.Fatalf("BuildIndex(%d): %v", s.books, err)
		}
		if err := ms.CompressToFile(idx); err != nil {
			t.Fatalf("CompressToFile(%d): %v", s.books, err)
		}
		heapPeak, sysPeak := sampler.finish()
		rss := maxRSSBytes()
		logf("%-8d %10.1f %12.1f %12.1f %12.1f %14.0f %14.2f",
			s.books, float64(s.bytes)/1e6,
			float64(heapPeak)/1e6, float64(sysPeak)/1e6, float64(rss)/1e6,
			float64(heapPeak)/float64(s.books), float64(heapPeak)/float64(s.bytes))

		// drop idx before next run
		idx = indexData{}
		_ = idx
	}

	logf("NOTE: rssPeakMB is monotonic (process high-water) — compare only the largest run's RSS.")
	fmt.Fprintln(os.Stdout, "spike-compile-ram: done")
}
