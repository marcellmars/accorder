package calibre

import (
	"bytes"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"strings"
	"testing"

	"accorder/pkg/torshare"
)

func TestSpikeGenerationChangeCatalogOracle(t *testing.T) {
	deleted := generationChangeTestBook("00000000-0000-4000-8000-000000000001", "Deleted")
	editedOld := generationChangeTestBook("00000000-0000-4000-8000-000000000002", "Old title")
	editedNew := generationChangeTestBook(editedOld.Id, "New title")
	added := generationChangeTestBook("00000000-0000-4000-8000-000000000003", "Added")

	previous := generationChangeJSONL(t, deleted, editedOld)
	diff, err := CompileCatalogDiff([]*Book{editedNew, added}, bytes.NewReader(previous))
	if err != nil {
		t.Fatal(err)
	}
	if len(diff.Changes) != 3 {
		t.Fatalf("changes=%d, want 3: %+v", len(diff.Changes), diff.Changes)
	}
	wantKinds := []string{"deleted", "edited", "added"}
	for i, want := range wantKinds {
		if diff.Changes[i].Kind != want {
			t.Fatalf("change[%d].kind=%q, want %q", i, diff.Changes[i].Kind, want)
		}
	}

	for i := range diff.Changes {
		omitted := append([]GenerationChange(nil), diff.Changes...)
		omitted = append(omitted[:i], omitted[i+1:]...)
		if err := ValidateCatalogTransition(diff.FromChecksum, diff.ToChecksum, diff.FromCount, diff.ToCount, omitted); err == nil {
			t.Fatalf("omitting change %d unexpectedly preserved the transition proof", i)
		}
	}

	corrupt := append([]GenerationChange(nil), diff.Changes...)
	corrupt[1].NewRecordDigest = strings.Repeat("f", 64)
	if err := ValidateCatalogTransition(diff.FromChecksum, diff.ToChecksum, diff.FromCount, diff.ToCount, corrupt); err == nil {
		t.Fatal("corrupt edited digest unexpectedly validated")
	}

	canonical, err := CanonicalRecordBytes(editedNew)
	if err != nil {
		t.Fatal(err)
	}
	var reordered map[string]any
	if err := json.Unmarshal(canonical, &reordered); err != nil {
		t.Fatal(err)
	}
	reorderedBytes, err := json.Marshal(reordered)
	if err != nil {
		t.Fatal(err)
	}
	normalized, err := CanonicalRecordBytesFromJSON(reorderedBytes, editedNew.Id)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(canonical, normalized) {
		t.Fatalf("canonical bytes depend on input key order:\n%s\n%s", canonical, normalized)
	}

	unknown := append(append([]byte(nil), canonical[:len(canonical)-1]...), []byte(`,"future":true}`)...)
	if _, err := CanonicalRecordBytesFromJSON(unknown, editedNew.Id); err == nil {
		t.Fatal("unknown record field unexpectedly accepted")
	}
	missingNested := bytes.Replace(canonical, []byte(`"file_name":"book.epub",`), nil, 1)
	if _, err := CanonicalRecordBytesFromJSON(missingNested, editedNew.Id); err == nil {
		t.Fatal("missing required nested field unexpectedly accepted")
	}
	nullScalar := bytes.Replace(canonical, []byte(`"title":"New title"`), []byte(`"title":null`), 1)
	if _, err := CanonicalRecordBytesFromJSON(nullScalar, editedNew.Id); err == nil {
		t.Fatal("null scalar field unexpectedly accepted")
	}
	legacyNullArrays := canonical
	for _, field := range []string{"authors", "formats", "identifiers", "languages", "tags"} {
		var decoded map[string]json.RawMessage
		if err := json.Unmarshal(legacyNullArrays, &decoded); err != nil {
			t.Fatal(err)
		}
		decoded[field] = json.RawMessage("null")
		legacyNullArrays, err = json.Marshal(decoded)
		if err != nil {
			t.Fatal(err)
		}
	}
	normalizedLegacy, err := CanonicalRecordBytesFromJSON(legacyNullArrays, editedNew.Id)
	if err != nil {
		t.Fatalf("legacy null arrays: %v", err)
	}
	legacyBook := *editedNew
	legacyBook.Authors = nil
	legacyBook.Formats = nil
	legacyBook.Identifiers = nil
	legacyBook.Languages = nil
	legacyBook.Tags = nil
	wantLegacy, err := CanonicalRecordBytes(&legacyBook)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(normalizedLegacy, wantLegacy) {
		t.Fatalf("legacy null arrays did not normalize to empty collections:\n%s\n%s", normalizedLegacy, wantLegacy)
	}

	// A payload-only assertion has identical record digests, so the two XOR
	// terms cancel. This pins the contract that catalog checksum cannot prove
	// payload-only completeness; the independent inventory/ledger must.
	digestBytes := RecordDigest(editedNew.Id, canonical)
	digest := hex.EncodeToString(digestBytes[:])
	zero := strings.Repeat("0", 64)
	payloadOnly := []GenerationChange{{
		Kind: "edited", ID: editedNew.Id, OldRecordDigest: digest,
		NewRecordDigest: digest, PayloadChanged: true,
	}}
	if err := ValidateCatalogTransition(zero, zero, 1, 1, payloadOnly); err != nil {
		t.Fatalf("payload-only cancellation contract changed: %v", err)
	}
}

func TestGenerationChangeManifestGoldenForms(t *testing.T) {
	base := [16]byte{1, 2, 3}
	fromToken := hex.EncodeToString(torshare.EncodeGeneration(base, 1))
	toToken := hex.EncodeToString(torshare.EncodeGeneration(base, 2))
	zero := strings.Repeat("0", 64)
	one := strings.Repeat("1", 64)
	count := uint32(1)

	exact := GenerationChangeManifest{
		Version: GenerationChangeManifestVersion, Scope: GenerationChangeScopeExact,
		LibraryUUID:    "00000000-0000-4000-8000-000000000010",
		FromGeneration: fromToken, ToGeneration: toToken,
		TargetSourceFingerprint: strings.Repeat("a", 64),
		FromLiveCount:           &count, ToLiveCount: 1,
		FromCatalogChecksum: zero, ToCatalogChecksum: zero,
		Changes: []GenerationChange{},
	}
	data, err := EncodeGenerationChangeManifest(exact)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.HasSuffix(data, []byte("[]}"+"\n")) || bytes.Count(data, []byte("\n")) != 1 {
		t.Fatalf("exact-empty manifest is not compact deterministic JSON with one LF: %q", data)
	}
	decoded, err := DecodeGenerationChangeManifest(data, GenerationChangeLimits{})
	if err != nil {
		t.Fatal(err)
	}
	if decoded.Scope != GenerationChangeScopeExact || decoded.Changes == nil || len(decoded.Changes) != 0 {
		t.Fatalf("decoded exact-empty manifest=%+v", decoded)
	}
	payloadOnlyWithoutMarker := exact
	payloadOnlyWithoutMarker.Changes = []GenerationChange{{
		Kind: "edited", ID: "00000000-0000-4000-8000-000000000011",
		OldRecordDigest: one, NewRecordDigest: one,
	}}
	if _, err := EncodeGenerationChangeManifest(payloadOnlyWithoutMarker); err == nil {
		t.Fatal("equal record digests without payload_changed were accepted")
	}

	firstChecksum := GenerationChangeManifest{
		Version: GenerationChangeManifestVersion, Scope: GenerationChangeScopeCoarse,
		LibraryUUID: exact.LibraryUUID, FromGeneration: fromToken, ToGeneration: toToken,
		TargetSourceFingerprint: exact.TargetSourceFingerprint,
		FromLiveCount:           &count, ToLiveCount: 1, ToCatalogChecksum: one,
	}
	data, err = EncodeGenerationChangeManifest(firstChecksum)
	if err != nil {
		t.Fatal(err)
	}
	if bytes.Contains(data, []byte("from_catalog_checksum")) || bytes.Contains(data, []byte("changes")) {
		t.Fatalf("first-checksum coarse form has forbidden fields: %s", data)
	}
	if _, err := DecodeGenerationChangeManifest(data, GenerationChangeLimits{}); err != nil {
		t.Fatal(err)
	}

	firstPublication := GenerationChangeManifest{
		Version: GenerationChangeManifestVersion, Scope: GenerationChangeScopeCoarse,
		LibraryUUID: exact.LibraryUUID, ToGeneration: toToken,
		TargetSourceFingerprint: exact.TargetSourceFingerprint,
		ToLiveCount:             1, ToCatalogChecksum: one,
	}
	data, err = EncodeGenerationChangeManifest(firstPublication)
	if err != nil {
		t.Fatal(err)
	}
	if bytes.Contains(data, []byte("from_")) || bytes.Contains(data, []byte("changes")) {
		t.Fatalf("first-publication form has forbidden fields: %s", data)
	}

	duplicate := bytes.Replace(data, []byte(`"version":1`), []byte(`"version":1,"version":1`), 1)
	if _, err := DecodeGenerationChangeManifest(duplicate, GenerationChangeLimits{}); err == nil {
		t.Fatal("duplicate manifest field unexpectedly accepted")
	}
	spaced := append([]byte(" "), data...)
	if _, err := DecodeGenerationChangeManifest(spaced, GenerationChangeLimits{}); err == nil {
		t.Fatal("non-canonical whitespace unexpectedly accepted")
	}
}

func BenchmarkGenerationChangeCatalog(b *testing.B) {
	const bookCount = 56341
	books := make([]*Book, 0, bookCount)
	var previous bytes.Buffer
	for i := 0; i < bookCount; i++ {
		id := fmt.Sprintf("00000000-0000-4000-8000-%012d", i)
		book := generationChangeTestBook(id, fmt.Sprintf("Book %d", i))
		books = append(books, book)
		canonical, err := CanonicalRecordBytes(book)
		if err != nil {
			b.Fatal(err)
		}
		previous.Write(canonical)
		previous.WriteByte('\n')
	}
	previousBytes := previous.Bytes()
	b.ReportMetric(float64(len(previousBytes)), "catalog_bytes")
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		if _, err := CompileCatalogDiff(books, bytes.NewReader(previousBytes)); err != nil {
			b.Fatal(err)
		}
	}
}

// TestCatalogRecordInfoNormalizesFormatDirectories guards the one production
// consumer of FormatDirectories: cmd/memberChangeResult.go's
// addEndpointDirectory requires libraryflow.NormalizePath(directory) ==
// directory, which strips a trailing path separator. Every real book loader
// (pkg/calibre/calibre.go's SQLite and JSON-unmarshal paths alike) writes
// File.DirectoryPath WITH a trailing separator, so FormatDirectories must
// normalize it away rather than echo the raw form — otherwise every touched
// book with a format file downgrades the aggregate's exact-scope VFS
// invalidation to coarse.
func TestCatalogRecordInfoNormalizesFormatDirectories(t *testing.T) {
	book := generationChangeTestBook("00000000-0000-4000-8000-000000000010", "Title")
	if !strings.HasSuffix(book.Formats[0].DirectoryPath, "/") {
		t.Fatal("test fixture no longer matches the real loaders' trailing-separator shape")
	}
	info, err := CatalogRecordInfoForBook(book)
	if err != nil {
		t.Fatal(err)
	}
	if len(info.FormatDirectories) != 1 || info.FormatDirectories[0] != "Author/Book (1)" {
		t.Fatalf("FormatDirectories = %v, want [\"Author/Book (1)\"] (normalized, no trailing separator)", info.FormatDirectories)
	}
}

func generationChangeTestBook(id, title string) *Book {
	return &Book{
		Abstract: "", Authors: []string{"Author"}, LibraryUrl: "library",
		CoverUrl: "Author/Book (1)/cover.jpg", Formats: []*File{{
			Format: "epub", DirectoryPath: "Author/Book (1)/", Name: "book.epub", Size: 42,
		}},
		Id: id, Identifiers: []*Identifier{}, Languages: []string{"eng"},
		LastModified: "2026-09-03T00:00:00Z", Librarian: "librarian",
		LibraryUUID: "00000000-0000-4000-8000-000000000099",
		Pubdate:     "", Publisher: "", Series: "", Tags: []string{}, Title: title,
		TitleSort: title,
	}
}

func generationChangeJSONL(t *testing.T, books ...*Book) []byte {
	t.Helper()
	var out bytes.Buffer
	for _, book := range books {
		canonical, err := CanonicalRecordBytes(book)
		if err != nil {
			t.Fatal(err)
		}
		out.Write(canonical)
		out.WriteByte('\n')
	}
	return out.Bytes()
}
