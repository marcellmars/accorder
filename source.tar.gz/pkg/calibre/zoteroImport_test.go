package calibre

import (
	"accorder/pkg/bibtexjson"
	"os"
	"path/filepath"
	"testing"
)

// loadTestExport reads the test fixture BBT JSON export.
func loadTestExport(t *testing.T) (bibtexjson.BetterBibTex, string) {
	t.Helper()

	// The test fixture is at cmd/testdata/export/ relative to project root.
	// Since tests run in pkg/calibre/, we need to navigate up.
	exportDir := filepath.Join("..", "..", "cmd", "testdata", "export")
	jsonPath := filepath.Join(exportDir, "aa.json")
	data, err := os.ReadFile(jsonPath)
	if err != nil {
		t.Skipf("test fixture not available: %v", err)
	}
	bbt, err := bibtexjson.UnmarshalBetterBibTex(data)
	if err != nil {
		t.Fatalf("unmarshal fixture: %v", err)
	}
	return bbt, exportDir
}

// ═══════════════════════════════════════════════════════════════════
// Test: EntriesFromBetterBibTex entry count and field mapping
// ═══════════════════════════════════════════════════════════════════

func TestEntriesFromBetterBibTex_EntryCount(t *testing.T) {
	bbt, baseDir := loadTestExport(t)

	entries := EntriesFromBetterBibTex(bbt, baseDir)

	if len(entries) != 2 {
		t.Fatalf("expected 2 entries, got %d", len(entries))
	}

	// Check first entry (Red Skin, White Masks).
	e0 := entries[0]
	if e0.ItemKey != "GPLH5D4S" {
		t.Errorf("entry[0].ItemKey = %q, want GPLH5D4S", e0.ItemKey)
	}
	if e0.Title != "Red Skin, White Masks: Rejecting the Colonial Politics of Recognition" {
		t.Errorf("entry[0].Title = %q", e0.Title)
	}
	if len(e0.Authors) == 0 {
		t.Error("entry[0].Authors is empty")
	}
	if len(e0.Files) != 3 {
		t.Errorf("entry[0].Files count = %d, want 3", len(e0.Files))
	}

	// PDF should be first due to sort order.
	if e0.Files[0].Ext != ".pdf" {
		t.Errorf("entry[0].Files[0].Ext = %q, want .pdf (should be sorted first)", e0.Files[0].Ext)
	}

	// Check second entry (Extrastatecraft).
	e1 := entries[1]
	if e1.ItemKey != "KCBU772W" {
		t.Errorf("entry[1].ItemKey = %q, want KCBU772W", e1.ItemKey)
	}
	if len(e1.Files) != 3 {
		t.Errorf("entry[1].Files count = %d, want 3", len(e1.Files))
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test: EffMtime is max of item and attachment dateModified
// ═══════════════════════════════════════════════════════════════════

func TestEntriesFromBetterBibTex_EffMtime(t *testing.T) {
	bbt, baseDir := loadTestExport(t)

	entries := EntriesFromBetterBibTex(bbt, baseDir)
	if len(entries) < 1 {
		t.Fatal("no entries")
	}

	// Item 0: item.dateModified = "2025-05-08T11:59:39Z"
	// Attachments dateModified: "2025-05-08T11:59:41Z", "2025-05-08T11:59:41Z", "2025-05-08T11:59:41Z"
	// EffMtime should be max = "2025-05-08T11:59:41Z"
	e0 := entries[0]
	if e0.EffMtime != "2025-05-08T11:59:41Z" {
		t.Errorf("entry[0].EffMtime = %q, want 2025-05-08T11:59:41Z", e0.EffMtime)
	}

	// Item 1: item.dateModified = "2025-05-08T11:59:37Z"
	// Attachments: "2025-05-08T11:59:37Z", "2025-05-08T11:59:39Z", "2025-05-08T11:59:37Z"
	// EffMtime should be max = "2025-05-08T11:59:39Z"
	e1 := entries[1]
	if e1.EffMtime != "2025-05-08T11:59:39Z" {
		t.Errorf("entry[1].EffMtime = %q, want 2025-05-08T11:59:39Z", e1.EffMtime)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test: FileHash and Rev are deterministic
// ═══════════════════════════════════════════════════════════════════

func TestImportEntry_FileHashDeterminism(t *testing.T) {
	bbt, baseDir := loadTestExport(t)

	entries := EntriesFromBetterBibTex(bbt, baseDir)
	if len(entries) < 1 {
		t.Fatal("no entries")
	}

	e := entries[0]
	hash1 := e.FileHash()
	hash2 := e.FileHash()
	if hash1 != hash2 {
		t.Errorf("FileHash is not deterministic: %q != %q", hash1, hash2)
	}
	if len(hash1) != 16 {
		t.Errorf("FileHash length = %d, want 16", len(hash1))
	}

	rev1 := e.Rev()
	rev2 := e.Rev()
	if rev1 != rev2 {
		t.Errorf("Rev is not deterministic: %q != %q", rev1, rev2)
	}

	// Rev format: <mtime>+<hash16>
	if !contains(rev1, "+") {
		t.Errorf("Rev should contain '+': %q", rev1)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test: Tags comma-to-dash replacement
// ═══════════════════════════════════════════════════════════════════

func TestEntriesFromBetterBibTex_TagCommaReplacement(t *testing.T) {
	bbt, baseDir := loadTestExport(t)

	entries := EntriesFromBetterBibTex(bbt, baseDir)
	if len(entries) < 1 {
		t.Fatal("no entries")
	}

	// Check that no tag contains a comma.
	for _, entry := range entries {
		for _, tag := range entry.Tags {
			if contains(tag, ",") {
				t.Errorf("tag %q still contains comma (entry %s)", tag, entry.ItemKey)
			}
		}
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test: Exts returns sorted unique extensions
// ═══════════════════════════════════════════════════════════════════

func TestImportEntry_Exts(t *testing.T) {
	bbt, baseDir := loadTestExport(t)

	entries := EntriesFromBetterBibTex(bbt, baseDir)
	if len(entries) < 1 {
		t.Fatal("no entries")
	}

	// Entry 0 has .azw3, .epub, .pdf → sorted: .azw3, .epub, .pdf
	exts := entries[0].Exts()
	if len(exts) != 3 {
		t.Fatalf("entry[0].Exts() = %v, want 3 extensions", exts)
	}
	expected := []string{".azw3", ".epub", ".pdf"}
	for i, ext := range exts {
		if ext != expected[i] {
			t.Errorf("exts[%d] = %q, want %q", i, ext, expected[i])
		}
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test: LocateBetterBibTexExport
// ═══════════════════════════════════════════════════════════════════

func TestLocateBetterBibTexExport(t *testing.T) {
	exportDir := filepath.Join("..", "..", "cmd", "testdata", "export")
	jsonPath, baseDir, err := LocateBetterBibTexExport(exportDir)
	if err != nil {
		t.Fatalf("LocateBetterBibTexExport: %v", err)
	}
	if !filepath.IsAbs(jsonPath) && jsonPath == "" {
		t.Error("jsonPath is empty")
	}
	if baseDir != exportDir {
		t.Errorf("baseDir = %q, want %q", baseDir, exportDir)
	}
	if filepath.Ext(jsonPath) != ".json" {
		t.Errorf("jsonPath extension = %q, want .json", filepath.Ext(jsonPath))
	}
}

func TestLocateBetterBibTexExport_EmptyDir(t *testing.T) {
	emptyDir := t.TempDir()
	_, _, err := LocateBetterBibTexExport(emptyDir)
	if err == nil {
		t.Fatal("expected error for empty directory, got nil")
	}
}

func TestLocateBetterBibTexExport_MultipleJSON(t *testing.T) {
	dir := t.TempDir()
	_ = os.WriteFile(filepath.Join(dir, "a.json"), []byte("{}"), 0644)
	_ = os.WriteFile(filepath.Join(dir, "b.json"), []byte("{}"), 0644)
	_, _, err := LocateBetterBibTexExport(dir)
	if err == nil {
		t.Fatal("expected error for multiple JSON files, got nil")
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test: Items with no qualifying creators are skipped
// ═══════════════════════════════════════════════════════════════════

func TestEntriesFromBetterBibTex_SkipsNoCreators(t *testing.T) {
	itemKey := "TESTKEY"
	title := "No Authors"
	path := "files/test.pdf"

	// Create a temp dir with a fake PDF.
	dir := t.TempDir()
	filesDir := filepath.Join(dir, "files")
	_ = os.MkdirAll(filesDir, 0755)
	_ = os.WriteFile(filepath.Join(filesDir, "test.pdf"), []byte("fake pdf"), 0644)

	translator := bibtexjson.CreatorType("translator")
	bbt := bibtexjson.BetterBibTex{
		Items: []bibtexjson.Item{
			{
				ItemKey: &itemKey,
				Title:   &title,
				Creators: []bibtexjson.Creator{
					{CreatorType: &translator, FirstName: strPtr("John"), LastName: strPtr("Doe")},
				},
				Attachments: []bibtexjson.Attachment{
					{Path: &path},
				},
			},
		},
	}

	entries := EntriesFromBetterBibTex(bbt, dir)
	if len(entries) != 0 {
		t.Errorf("expected 0 entries (translator-only item should be skipped), got %d", len(entries))
	}
}

func contains(s, substr string) bool {
	return len(s) >= len(substr) && (s == substr || len(s) > 0 && containsCheck(s, substr))
}

func containsCheck(s, substr string) bool {
	for i := 0; i <= len(s)-len(substr); i++ {
		if s[i:i+len(substr)] == substr {
			return true
		}
	}
	return false
}

func strPtr(s string) *string {
	return &s
}

// ═══════════════════════════════════════════════════════════════════
// Test: coerceSeriesIndex — Roman-numeral coercion for Calibre's
// float-typed series_index column.
// ═══════════════════════════════════════════════════════════════════

func TestCoerceSeriesIndex(t *testing.T) {
	cases := []struct {
		in, want string
	}{
		{"", ""},
		{"   ", ""},
		{"1", "1"},
		{"1.5", "1.5"},
		{"0", "0"},
		{"-3", "-3"},
		{"XII", "12"},
		{"xii", "12"},
		{"IV", "4"},
		{"MMXXVI", "2026"},
		{"abc", ""},
		{"12 bis", ""},
		{"II.5", ""},
		{"Vol. II", ""},
	}
	for _, c := range cases {
		got := coerceSeriesIndex(c.in)
		if got != c.want {
			t.Errorf("coerceSeriesIndex(%q) = %q, want %q", c.in, got, c.want)
		}
	}
}
