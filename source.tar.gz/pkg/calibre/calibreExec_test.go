package calibre

import (
	"context"
	"os/exec"
	"strings"
	"testing"
)

// ═══════════════════════════════════════════════════════════════════
// Test: parseAddedIDs — stdout shapes from calibredb add (single + batch).
// Duplicate-marker handling now lives in Add (stderr/stdout check), not the
// parser, so it is exercised at the Add level rather than here.
// ═══════════════════════════════════════════════════════════════════

func TestParseAddedIDs(t *testing.T) {
	cases := []struct {
		name      string
		stdout    string
		wantIDs   []int
		wantErrIn string // substring of expected err; "" means no error
	}{
		{
			name:    "fresh add (single)",
			stdout:  "Added book ids: 42\n",
			wantIDs: []int{42},
		},
		{
			name:    "batch add (multiple, input order)",
			stdout:  "Added book ids: 1, 2, 3\n",
			wantIDs: []int{1, 2, 3},
		},
		{
			name:      "duplicate-only output (no ids)",
			stdout:    "The following books were not added as they already exist in the database\n",
			wantErrIn: "could not parse book IDs",
		},
		{
			name:      "garbage",
			stdout:    "    /tmp/something.pdf\n",
			wantErrIn: "could not parse book IDs",
		},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			ids, err := parseAddedIDs([]byte(c.stdout))
			if c.wantErrIn == "" {
				if err != nil {
					t.Fatalf("unexpected error: %v", err)
				}
				if len(ids) != len(c.wantIDs) {
					t.Fatalf("ids = %v, want %v", ids, c.wantIDs)
				}
				for i := range ids {
					if ids[i] != c.wantIDs[i] {
						t.Errorf("ids[%d] = %d, want %d", i, ids[i], c.wantIDs[i])
					}
				}
				return
			}
			if err == nil {
				t.Fatalf("expected error containing %q, got nil", c.wantErrIn)
			}
			if !strings.Contains(err.Error(), c.wantErrIn) {
				t.Errorf("err = %q, want substring %q", err.Error(), c.wantErrIn)
			}
		})
	}
}

// ═══════════════════════════════════════════════════════════════════
// Test: findBookIDByTitle — exact-title lookup over `calibredb list`
// ═══════════════════════════════════════════════════════════════════

func TestFindBookIDByTitle(t *testing.T) {
	const target = "Quando il prendersi cura ha bisogno della pirateria"

	cases := []struct {
		name      string
		listJSON  string
		wantID    int
		wantErrIn string
	}{
		{
			name:     "exact single match",
			listJSON: `[{"id":1,"title":"Other"},{"id":7,"title":"Quando il prendersi cura ha bisogno della pirateria"}]`,
			wantID:   7,
		},
		{
			name:     "multiple matches: highest ID wins",
			listJSON: `[{"id":3,"title":"Quando il prendersi cura ha bisogno della pirateria"},{"id":11,"title":"Quando il prendersi cura ha bisogno della pirateria"}]`,
			wantID:   11,
		},
		{
			name:      "no match",
			listJSON:  `[{"id":1,"title":"Other"}]`,
			wantErrIn: "no book matches exact title",
		},
		{
			name:      "partial substring is not a match",
			listJSON:  `[{"id":1,"title":"Quando il prendersi cura ha bisogno della pirateria, extended"}]`,
			wantErrIn: "no book matches exact title",
		},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			exe := &CalibreExe{
				CalibreCLI: func(_ *exec.Cmd) ([]byte, error) {
					return []byte(c.listJSON), nil
				},
			}
			id, err := exe.findBookIDByTitle(context.Background(), target)
			if c.wantErrIn == "" {
				if err != nil {
					t.Fatalf("unexpected error: %v", err)
				}
				if id != c.wantID {
					t.Errorf("id = %d, want %d", id, c.wantID)
				}
				return
			}
			if err == nil {
				t.Fatalf("expected error containing %q, got nil", c.wantErrIn)
			}
			if !strings.Contains(err.Error(), c.wantErrIn) {
				t.Errorf("err = %q, want substring %q", err.Error(), c.wantErrIn)
			}
		})
	}
}
