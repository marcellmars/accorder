package calibre

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"
)

// buildMultiSegmentIndex creates a multi-segment index (>16 books → ≥2 segments)
// with controlled term distribution for oracle testing:
//   - "method" is rare in titles (2 books: 5 and 7) but common in abstracts (~30 books)
//     → title-IDF >> abstract-IDF, exercising per-field-IDF + take-max.
//   - Book 5 matches "method" in BOTH title and abstract (the take-max case).
//   - Books 20 and 21 share identical LastModified; both match "method" in abstract only
//     with the same BM25 score → exercises rankBefore tail (regionIdx/segment/posInSeg).
//   - Book 35 has empty Abstract (matches nothing in abstract field).
func buildMultiSegmentIndex(t *testing.T) *MotwSearch {
	t.Helper()
	dir := t.TempDir()
	jsonlPath := filepath.Join(dir, "books.jsonl")
	f, err := os.Create(jsonlPath)
	if err != nil {
		t.Fatal(err)
	}
	w := bufio.NewWriter(f)

	var books []Book
	for i := 0; i < 40; i++ {
		b := Book{
			Id:           fmt.Sprintf("%d", i),
			UUID:         fmt.Sprintf("u%d", i),
			Title:        fmt.Sprintf("Book number %d about things", i),
			Authors:      []string{"Auth"},
			Tags:         []string{"misc"},
			Abstract:     "filler text",
			LastModified: fmt.Sprintf("2024-01-%02dT00:00:00+00:00", (i%27)+1),
			LibraryUUID:  "L",
		}
		// ~30 books get "method" in abstract → high abstract-DF.
		if i < 30 {
			b.Abstract = "a discussion of method and technique"
		}
		// Book 5: matches "method" in BOTH title and abstract.
		if i == 5 {
			b.Title = "The method explained"
		}
		// Book 7: matches "method" in title only (abstract has no "method" since i<30 overrides above).
		if i == 7 {
			b.Title = "Another method primer"
		}
		// Books 20 and 21: deliberate score+lastModified collision.
		// Same LastModified, same abstract text (same BM25 score from abstract).
		// They differ only in (regionIdx, segment, posInSeg) — the rankBefore tail.
		if i == 20 || i == 21 {
			b.LastModified = "2024-01-15T00:00:00+00:00"
			b.Abstract = "a discussion of method and technique"
		}
		// Book 35: empty Abstract (should not false-match in abstract field).
		if i == 35 {
			b.Abstract = ""
		}
		books = append(books, b)
	}

	for _, b := range books {
		line, _ := json.Marshal(b)
		w.Write(line)
		w.WriteByte('\n')
	}
	w.Flush()
	f.Close()

	idxPath := filepath.Join(dir, "idx")
	ms := &MotwSearch{JsonlPath: jsonlPath, IndexPath: idxPath, IndexDescription: true}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}
	return &MotwSearch{IndexPath: idxPath}
}

// searchAllOld runs the old N-per-field searchAll implementation.
// It is a copy of the pre-single-pass code for oracle comparison.
func searchAllOld(t *testing.T, s *MotwSearch, query string, opts SearchOptions) []*Book {
	t.Helper()
	opened, err := s.Open()
	if err != nil {
		t.Fatal(err)
	}
	defer opened.Close()

	mf := opened.mf
	numFields := 3
	if mf.IndexedFieldCount >= 4 {
		numFields = int(mf.IndexedFieldCount)
	}

	ctx := context.Background()
	merged := map[string]*Book{}
	searchFields := fieldsInOrder[:numFields]

	for _, field := range searchFields {
		fq := SearchQuery{Field: field, Text: query, Mode: ModeExact}
		fOpts := SearchOptions{Limit: 0, Offset: 0, SortMode: SortRelevance}
		books, _, err := opened.Search(ctx, fq, fOpts)
		if err != nil {
			t.Fatal(err)
		}
		for _, bk := range books {
			key := bk.Id
			if key == "" {
				key = bk.Title + "|" + bk.LibraryUUID
			}
			if existing, ok := merged[key]; ok {
				if bk.SearchScore > existing.SearchScore {
					existing.SearchScore = bk.SearchScore
				}
			} else {
				merged[key] = bk
			}
		}
	}

	result := make([]*Book, 0, len(merged))
	for _, bk := range merged {
		result = append(result, bk)
	}

	switch opts.SortMode {
	case SortNewest:
		sortBooksByNewest(result)
	case SortOldest:
		sortBooksByOldest(result)
	default:
		sortBooksByRelevance(result)
	}

	capLimit := 0
	if opts.Limit > 0 {
		capLimit = opts.Offset + opts.Limit
	}
	if capLimit > 0 && len(result) > capLimit {
		result = result[:capLimit]
	}
	return result
}

func sortBooksByRelevance(books []*Book) {
	for i := 0; i < len(books); i++ {
		for j := i + 1; j < len(books); j++ {
			if books[j].SearchScore > books[i].SearchScore ||
				(books[j].SearchScore == books[i].SearchScore && books[j].LastModified > books[i].LastModified) {
				books[i], books[j] = books[j], books[i]
			}
		}
	}
}

func sortBooksByNewest(books []*Book) {
	for i := 0; i < len(books); i++ {
		for j := i + 1; j < len(books); j++ {
			if books[j].LastModified > books[i].LastModified {
				books[i], books[j] = books[j], books[i]
			}
		}
	}
}

func sortBooksByOldest(books []*Book) {
	for i := 0; i < len(books); i++ {
		for j := i + 1; j < len(books); j++ {
			if books[j].LastModified < books[i].LastModified {
				books[i], books[j] = books[j], books[i]
			}
		}
	}
}

// TestSearchAllSinglePassOracle verifies the new single-pass scorer produces
// the same book set and scores as the old N-per-field searchAll.
// The order may differ at exact score+lastModified ties because the new scorer
// uses rankBefore (deterministic) while the old used sort.SliceStable over
// map-iteration order (nondeterministic). The oracle asserts:
//   - Same book set (same Ids)
//   - Same scores per book
//   - Deterministic order across repeated runs (new scorer)
func TestSearchAllSinglePassOracle(t *testing.T) {
	s := buildMultiSegmentIndex(t)
	ctx := context.Background()

	// --- Sub-test 1: book set and score equivalence ---
	t.Run("BookSetAndScoreEquivalence", func(t *testing.T) {
		oldBooks := searchAllOld(t, s, "method", SearchOptions{SortMode: SortRelevance})
		newBooks, _, err := s.Search(ctx, SearchQuery{Field: FieldAll, Text: "method"}, SearchOptions{SortMode: SortRelevance})
		if err != nil {
			t.Fatal(err)
		}

		if len(oldBooks) != len(newBooks) {
			t.Fatalf("book count mismatch: old=%d new=%d", len(oldBooks), len(newBooks))
		}

		oldByID := map[string]float64{}
		for _, b := range oldBooks {
			oldByID[b.Id] = b.SearchScore
		}
		newByID := map[string]float64{}
		for _, b := range newBooks {
			newByID[b.Id] = b.SearchScore
		}

		for id, oldScore := range oldByID {
			newScore, ok := newByID[id]
			if !ok {
				t.Errorf("book %s in old but missing from new", id)
				continue
			}
			if diff := oldScore - newScore; diff > 1e-9 || diff < -1e-9 {
				t.Errorf("book %s score mismatch: old=%.9f new=%.9f", id, oldScore, newScore)
			}
		}
		for id := range newByID {
			if _, ok := oldByID[id]; !ok {
				t.Errorf("book %s in new but missing from old", id)
			}
		}
		t.Logf("Oracle: %d books, all scores match", len(newBooks))
	})

	// --- Sub-test 2: per-field IDF take-max ---
	t.Run("PerFieldIDFTakeMax", func(t *testing.T) {
		// Book 5 matches title+abstract. Its FieldAll score should equal
		// the max of its single-field scores (title-IDF > abstract-IDF).
		titleBooks, _, err := s.Search(ctx, SearchQuery{Field: FieldTitle, Text: "method"}, SearchOptions{SortMode: SortRelevance})
		if err != nil {
			t.Fatal(err)
		}
		allBooks, _, err := s.Search(ctx, SearchQuery{Field: FieldAll, Text: "method"}, SearchOptions{SortMode: SortRelevance})
		if err != nil {
			t.Fatal(err)
		}

		var titleScore5 float64
		for _, b := range titleBooks {
			if b.Id == "5" {
				titleScore5 = b.SearchScore
			}
		}
		var allScore5 float64
		for _, b := range allBooks {
			if b.Id == "5" {
				allScore5 = b.SearchScore
			}
		}
		if titleScore5 == 0 {
			t.Fatal("book 5 not found in title search")
		}
		if diff := titleScore5 - allScore5; diff > 1e-9 || diff < -1e-9 {
			t.Errorf("book 5 FieldAll score (%.9f) != title-field score (%.9f); expected take-max", allScore5, titleScore5)
		}
		t.Logf("Book 5: title=%.6f all=%.6f (take-max correct)", titleScore5, allScore5)
	})

	// --- Sub-test 3: determinism across runs ---
	t.Run("Determinism", func(t *testing.T) {
		run := func() []string {
			books, _, err := s.Search(ctx, SearchQuery{Field: FieldAll, Text: "method"}, SearchOptions{SortMode: SortRelevance})
			if err != nil {
				t.Fatal(err)
			}
			ids := make([]string, len(books))
			for i, b := range books {
				ids[i] = b.Id
			}
			return ids
		}
		first := run()
		for i := 0; i < 9; i++ {
			got := run()
			if len(first) != len(got) {
				t.Fatalf("run %d: length mismatch %d vs %d", i, len(first), len(got))
			}
			for j := range first {
				if first[j] != got[j] {
					t.Fatalf("run %d: order differs at position %d: %v vs %v", i, j, first, got)
				}
			}
		}
		t.Logf("Deterministic across 10 runs: %v", first)
	})

	// --- Sub-test 4: score+lastModified collision (rankBefore tail) ---
	t.Run("ScoreCollisionRankBeforeTail", func(t *testing.T) {
		books, _, err := s.Search(ctx, SearchQuery{Field: FieldAll, Text: "method"}, SearchOptions{SortMode: SortRelevance})
		if err != nil {
			t.Fatal(err)
		}
		var pos20, pos21 int
		var score20, score21 float64
		found20, found21 := false, false
		for i, b := range books {
			if b.Id == "20" {
				pos20 = i
				score20 = b.SearchScore
				found20 = true
			}
			if b.Id == "21" {
				pos21 = i
				score21 = b.SearchScore
				found21 = true
			}
		}
		if !found20 || !found21 {
			t.Fatalf("collision books not found: 20=%v 21=%v", found20, found21)
		}
		if diff := score20 - score21; diff > 1e-9 || diff < -1e-9 {
			t.Fatalf("collision books should have equal scores: 20=%.9f 21=%.9f", score20, score21)
		}
		// rankBefore breaks ties by (regionIdx, segment, posInSeg) — book 20 comes before 21.
		if pos20 >= pos21 {
			t.Errorf("rankBefore tail: book 20 (pos %d) should rank before book 21 (pos %d)", pos20, pos21)
		}
		t.Logf("Collision: book 20 at pos %d, book 21 at pos %d (score=%.6f)", pos20, pos21, score20)
	})

	// --- Sub-test 5: empty Abstract book ---
	t.Run("EmptyAbstract", func(t *testing.T) {
		books, _, err := s.Search(ctx, SearchQuery{Field: FieldAll, Text: "method"}, SearchOptions{SortMode: SortRelevance})
		if err != nil {
			t.Fatal(err)
		}
		for _, b := range books {
			if b.Id == "35" {
				t.Fatal("book 35 (empty abstract, no 'method' in title) should NOT match")
			}
		}
		t.Log("Book 35 correctly excluded")
	})
}

// TestSearchAllSinglePassPagination verifies the pagination contract:
// searchAll returns the rank-0 prefix bounded to offset+limit (the caller
// windows the offset). This matches the existing contract tested by
// TestSearchAllPaginationAndSort.
func TestSearchAllSinglePassPagination(t *testing.T) {
	s := buildMultiSegmentIndex(t)
	ctx := context.Background()
	q := SearchQuery{Field: FieldAll, Text: "method"}

	// Full unbounded result.
	full, _, err := s.Search(ctx, q, SearchOptions{SortMode: SortRelevance})
	if err != nil {
		t.Fatal(err)
	}
	total := len(full)
	if total < 10 {
		t.Fatalf("expected >=10 books matching 'method', got %d", total)
	}

	// With offset=5, limit=10 → capLimit = 15.
	// searchAll returns the top-15 from rank 0 (the caller windows offset).
	win, _, err := s.Search(ctx, q, SearchOptions{SortMode: SortRelevance, Offset: 5, Limit: 10})
	if err != nil {
		t.Fatal(err)
	}
	capLimit := 15
	if capLimit > total {
		capLimit = total
	}
	want := full[:capLimit]
	if len(win) != len(want) {
		t.Fatalf("expected %d results (top offset+limit), got %d", len(want), len(win))
	}
	for i := range want {
		if win[i].Id != want[i].Id {
			t.Fatalf("rank %d: got %q, want %q — searchAll did not return rank-0 prefix", i, win[i].Id, want[i].Id)
		}
	}

	// SortNewest should be honoured.
	newest, _, err := s.Search(ctx, q, SearchOptions{SortMode: SortNewest})
	if err != nil {
		t.Fatal(err)
	}
	if len(newest) == 0 {
		t.Fatal("SortNewest returned 0 books")
	}
	for i := 1; i < len(newest); i++ {
		if newest[i-1].LastModified < newest[i].LastModified {
			t.Fatalf("SortNewest not honoured: %s before %s", newest[i-1].LastModified, newest[i].LastModified)
		}
	}

	t.Logf("Pagination: total=%d, offset=5+limit=10 → top %d returned correctly. SortNewest OK.", total, capLimit)
}
