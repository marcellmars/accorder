package calibre

import (
	"bytes"
	"image"
	"image/color"
	"image/jpeg"
	"os"
	"path/filepath"
	"testing"
)

// writeTestJPEG creates a JPEG file from a uniform color and returns the path.
func writeTestJPEG(tb testing.TB, dir string, name string, c color.Color, w, h int) string {
	tb.Helper()
	img := image.NewRGBA(image.Rect(0, 0, w, h))
	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			img.Set(x, y, c)
		}
	}
	path := filepath.Join(dir, name)
	f, err := os.Create(path)
	if err != nil {
		tb.Fatal(err)
	}
	defer f.Close()
	if err := jpeg.Encode(f, img, &jpeg.Options{Quality: 90}); err != nil {
		tb.Fatal(err)
	}
	return path
}

func TestCoverFingerprintRoundTrip(t *testing.T) {
	dir := t.TempDir()

	// Create a synthetic multi-colored cover
	img := image.NewRGBA(image.Rect(0, 0, 120, 160))
	for y := 0; y < 160; y++ {
		for x := 0; x < 120; x++ {
			img.Set(x, y, color.RGBA{
				R: uint8(x * 2),
				G: uint8(y),
				B: uint8((x + y) % 256),
				A: 255,
			})
		}
	}
	path := filepath.Join(dir, "cover.jpg")
	f, err := os.Create(path)
	if err != nil {
		t.Fatal(err)
	}
	if err := jpeg.Encode(f, img, &jpeg.Options{Quality: 90}); err != nil {
		f.Close()
		t.Fatal(err)
	}
	f.Close()

	fp := CoverFingerprint(path)

	if IsZeroFingerprint(fp) {
		t.Fatal("fingerprint of valid multi-colored image should be non-zero")
	}

	// Round-trip through base64
	encoded := EncodeFingerprintBase64(fp)
	decoded := DecodeFingerprintBase64(encoded)
	if fp != decoded {
		t.Fatalf("round-trip mismatch: got %v, want %v", decoded, fp)
	}

	// Determinism: re-encode the same file
	fp2 := CoverFingerprint(path)
	if fp != fp2 {
		t.Fatalf("non-deterministic: first=%v second=%v", fp, fp2)
	}
}

func TestCoverFingerprintMissing(t *testing.T) {
	fp := CoverFingerprint("/nonexistent/path/cover.jpg")
	if !IsZeroFingerprint(fp) {
		t.Fatalf("missing file should produce zero sentinel, got %v", fp)
	}
}

func TestCoverFingerprintBlack(t *testing.T) {
	dir := t.TempDir()
	path := writeTestJPEG(t, dir, "black.jpg", color.RGBA{R: 0, G: 0, B: 0, A: 255}, 120, 160)
	fp := CoverFingerprint(path)
	if IsZeroFingerprint(fp) {
		t.Fatal("solid black cover must NOT produce zero sentinel (chroma bits should be non-zero)")
	}
}

func TestCoverFingerprintWhite(t *testing.T) {
	dir := t.TempDir()
	path := writeTestJPEG(t, dir, "white.jpg", color.RGBA{R: 255, G: 255, B: 255, A: 255}, 120, 160)
	fp := CoverFingerprint(path)
	if IsZeroFingerprint(fp) {
		t.Fatal("solid white cover must NOT produce zero sentinel")
	}
}

func TestCoverFingerprintInvalidFile(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "notjpeg.jpg")
	if err := os.WriteFile(path, []byte("this is not a jpeg"), 0644); err != nil {
		t.Fatal(err)
	}
	fp := CoverFingerprint(path)
	if !IsZeroFingerprint(fp) {
		t.Fatalf("invalid JPEG should produce zero sentinel, got %v", fp)
	}
}

func TestDecodeFingerprintBase64Empty(t *testing.T) {
	fp := DecodeFingerprintBase64("")
	if !IsZeroFingerprint(fp) {
		t.Fatalf("empty string should produce zero sentinel, got %v", fp)
	}
}

func TestDecodeFingerprintBase64Invalid(t *testing.T) {
	fp := DecodeFingerprintBase64("not-valid-base64!!!")
	if !IsZeroFingerprint(fp) {
		t.Fatalf("invalid base64 should produce zero sentinel, got %v", fp)
	}
}

func TestFingerprintFromImage(t *testing.T) {

	// Test via the internal fingerprintFromImage to validate bit packing
	img := image.NewRGBA(image.Rect(0, 0, 3, 4))

	// Fill each cell (1 pixel each) with different grays
	grays := []uint8{0, 36, 73, 109, 146, 182, 219, 255, 128, 64, 192, 160}
	for row := 0; row < 4; row++ {
		for col := 0; col < 3; col++ {
			g := grays[row*3+col]
			img.Set(col, row, color.RGBA{R: g, G: g, B: g, A: 255})
		}
	}

	fp := fingerprintFromImage(img)
	if IsZeroFingerprint(fp) {
		t.Fatal("fingerprint of varied gray image should be non-zero")
	}

	// Verify it round-trips
	encoded := EncodeFingerprintBase64(fp)
	decoded := DecodeFingerprintBase64(encoded)
	if fp != decoded {
		t.Fatalf("round-trip mismatch: got %v, want %v", decoded, fp)
	}
}

func TestCoverFingerprintFromReader(t *testing.T) {

	// Create a multi-colored JPEG in memory
	img := image.NewRGBA(image.Rect(0, 0, 120, 160))
	for y := 0; y < 160; y++ {
		for x := 0; x < 120; x++ {
			img.Set(x, y, color.RGBA{
				R: uint8(x * 2),
				G: uint8(y),
				B: uint8((x + y) % 256),
				A: 255,
			})
		}
	}
	var buf bytes.Buffer
	if err := jpeg.Encode(&buf, img, &jpeg.Options{Quality: 90}); err != nil {
		t.Fatal(err)
	}

	// Fingerprint via reader
	fpReader := CoverFingerprintFromReader(bytes.NewReader(buf.Bytes()))
	if IsZeroFingerprint(fpReader) {
		t.Fatal("CoverFingerprintFromReader should produce a non-zero fingerprint for a valid JPEG")
	}

	// Fingerprint via file (write to disk, then use CoverFingerprint)
	dir := t.TempDir()
	path := filepath.Join(dir, "cover.jpg")
	if err := os.WriteFile(path, buf.Bytes(), 0644); err != nil {
		t.Fatal(err)
	}
	fpFile := CoverFingerprint(path)

	// Both paths must produce identical fingerprints
	if fpReader != fpFile {
		t.Fatalf("CoverFingerprintFromReader and CoverFingerprint disagree: reader=%v file=%v", fpReader, fpFile)
	}
}

func TestCoverFingerprintFromReaderInvalid(t *testing.T) {
	fp := CoverFingerprintFromReader(bytes.NewReader([]byte("not a jpeg")))
	if !IsZeroFingerprint(fp) {
		t.Fatalf("invalid JPEG reader should produce zero sentinel, got %v", fp)
	}
}

func TestCoverFingerprintFromJPEGBytes(t *testing.T) {

	// Verify that fingerprintFromImage works with jpeg.Decode output
	img := image.NewRGBA(image.Rect(0, 0, 120, 160))
	for y := 0; y < 160; y++ {
		for x := 0; x < 120; x++ {
			img.Set(x, y, color.RGBA{R: 200, G: 100, B: 50, A: 255})
		}
	}
	var buf bytes.Buffer
	if err := jpeg.Encode(&buf, img, &jpeg.Options{Quality: 90}); err != nil {
		t.Fatal(err)
	}
	decoded, err := jpeg.Decode(bytes.NewReader(buf.Bytes()))
	if err != nil {
		t.Fatal(err)
	}
	fp := fingerprintFromImage(decoded)
	if IsZeroFingerprint(fp) {
		t.Fatal("fingerprint of uniform warm-toned image should be non-zero")
	}
}
