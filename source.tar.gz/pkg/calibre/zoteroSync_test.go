package calibre

import (
	"os"
	"path/filepath"
	"slices"
	"testing"

	"github.com/tidwall/gjson"
)

// ═══════════════════════════════════════════════════════════════════
// Helpers
// ═══════════════════════════════════════════════════════════════════

// tempFiles writes each name→content pair into a fresh temp dir and returns
// the ImportFile set in the order given. Ext is the lowercase dotted form the
// import path uses throughout (see the allow-list in zoteroImport.go).
func tempFiles(t *testing.T, order []string, content map[string]string) []ImportFile {
	t.Helper()
	dir := t.TempDir()
	files := make([]ImportFile, 0, len(order))
	for _, name := range order {
		p := filepath.Join(dir, name)
		if err := os.WriteFile(p, []byte(content[name]), 0o600); err != nil {
			t.Fatalf("write %s: %v", name, err)
		}
		files = append(files, ImportFile{AbsPath: p, Ext: filepath.Ext(name)})
	}
	return files
}

func entryWith(t *testing.T, itemKey, effMtime string, order []string, content map[string]string) ImportEntry {
	t.Helper()
	return ImportEntry{
		ItemKey:  itemKey,
		EffMtime: effMtime,
		Title:    "Title " + itemKey,
		Authors:  []string{"An Author"},
		Files:    tempFiles(t, order, content),
	}
}

// ═══════════════════════════════════════════════════════════════════
// classify — the two-tier cheap/full change gate (zoteroSync.go:96-108)
//
// The gate is the headline pattern of the zotero-calibre-import workflow
// (2026-05-11) and shipped with no test behind it. Each case below names
// which tier it exercises.
// ═══════════════════════════════════════════════════════════════════

func TestClassify_NotTracked_Adds(t *testing.T) {
	e := entryWith(t, "ZK1", "2026-01-01T00:00:00Z", []string{"a.pdf"}, map[string]string{"a.pdf": "body"})

	action, rev := classify(e, trackedBook{}, false)

	if action != actionAdd {
		t.Errorf("action = %v, want actionAdd", action)
	}
	if rev != "" {
		t.Errorf("rev = %q, want empty (classify returns a rev only for actionUpdate)", rev)
	}
}

// TestClassify_CheapGateShortCircuits is the proof that the cheap tier exists.
//
// The entry's stored rev carries a hash that does NOT match the bytes on disk.
// classify only reaches entry.Rev() — and therefore only reads the files — when
// the guard at zoteroSync.go:100 fails. So a returned actionUnchanged here can
// ONLY mean the guard short-circuited: had it fallen through, the full check
// would have compared the real hash against "deadbeefdeadbeef" and returned
// actionUpdate. The assertion is on the decision, not on a read counter.
func TestClassify_CheapGateShortCircuits(t *testing.T) {
	e := entryWith(t, "ZK1", "2026-01-01T00:00:00Z", []string{"a.pdf"}, map[string]string{"a.pdf": "body"})
	existing := trackedBook{
		bookID:  7,
		rev:     "2026-01-01T00:00:00Z+deadbeefdeadbeef",
		formats: []string{".pdf"},
	}

	if got := e.FileHash(); got == "deadbeefdeadbeef" {
		t.Fatalf("test is vacuous: real hash collided with the sentinel")
	}

	action, rev := classify(e, existing, true)

	if action != actionUnchanged {
		t.Errorf("action = %v, want actionUnchanged — the cheap gate at zoteroSync.go:100 did not short-circuit", action)
	}
	if rev != "" {
		t.Errorf("rev = %q, want empty", rev)
	}
}

// TestClassify_CheapMissFullHit covers the second tier: the cheap gate fails
// (Calibre's format list drifted from the export — e.g. a librarian added an
// EPUB by hand) but the export's own bytes are unchanged, so the full check
// settles it as unchanged.
func TestClassify_CheapMissFullHit(t *testing.T) {
	e := entryWith(t, "ZK1", "2026-01-01T00:00:00Z", []string{"a.pdf"}, map[string]string{"a.pdf": "body"})
	existing := trackedBook{
		bookID:  7,
		rev:     e.Rev(),                   // hash matches the bytes on disk
		formats: []string{".epub", ".pdf"}, // but Calibre holds an extra format
	}

	action, rev := classify(e, existing, true)

	if action != actionUnchanged {
		t.Errorf("action = %v, want actionUnchanged — the full check should settle a format-only drift", action)
	}
	if rev != "" {
		t.Errorf("rev = %q, want empty", rev)
	}
}

// TestClassify_MtimeChangedSameBytes documents a consequence of Rev() embedding
// the mtime (zoteroImport.go:269): a touched-but-unmodified file can NEVER come
// back unchanged, because rev = "<mtime>+<hash>" differs in its mtime half. It
// is reported as an update whose hash half is unchanged — which is exactly what
// updateEntry reads to take its metadata-only branch (zoteroSync.go:186,196).
func TestClassify_MtimeChangedSameBytes_UpdatesMetadataOnly(t *testing.T) {
	e := entryWith(t, "ZK1", "2026-02-02T00:00:00Z", []string{"a.pdf"}, map[string]string{"a.pdf": "body"})
	existing := trackedBook{
		bookID:  7,
		rev:     "2026-01-01T00:00:00Z+" + e.FileHash(),
		formats: []string{".pdf"},
	}

	action, rev := classify(e, existing, true)

	if action != actionUpdate {
		t.Fatalf("action = %v, want actionUpdate", action)
	}
	if rev != e.Rev() {
		t.Errorf("rev = %q, want %q", rev, e.Rev())
	}
	if revHash(rev) != revHash(existing.rev) {
		t.Errorf("hash half changed (%q → %q); this case must stay metadata-only",
			revHash(existing.rev), revHash(rev))
	}
}

// TestClassify_ContentChanged_Updates is the both-tiers-miss case. Note that the
// mtime moves with the bytes: EffMtime derives from Zotero's dateModified, so a
// real edit changes both. Bytes alone cannot drive this — see the next test.
func TestClassify_ContentChanged_Updates(t *testing.T) {
	e := entryWith(t, "ZK1", "2026-02-02T00:00:00Z", []string{"a.pdf"}, map[string]string{"a.pdf": "new body"})
	existing := trackedBook{
		bookID:  7,
		rev:     "2026-01-01T00:00:00Z+0123456789abcdef",
		formats: []string{".pdf"},
	}

	action, rev := classify(e, existing, true)

	if action != actionUpdate {
		t.Fatalf("action = %v, want actionUpdate", action)
	}
	if revHash(rev) == revHash(existing.rev) {
		t.Error("hash half unchanged; the files-changed branch of updateEntry would not fire")
	}
}

// TestClassify_SameMtimeContentChange_IsInvisible pins the cheap gate's
// deliberate blind spot: a file mutated outside Zotero, leaving dateModified
// untouched, is never re-hashed and so reads as unchanged. This is the
// trade-off that buys the O(1) no-op re-import, and it is what ROADMAP `ca-24`
// (`--rehash`/`--force`) exists to let an operator override.
func TestClassify_SameMtimeContentChange_IsInvisible(t *testing.T) {
	e := entryWith(t, "ZK1", "2026-01-01T00:00:00Z", []string{"a.pdf"}, map[string]string{"a.pdf": "mutated outside zotero"})
	existing := trackedBook{
		bookID:  7,
		rev:     "2026-01-01T00:00:00Z+0123456789abcdef", // stale hash, matching mtime
		formats: []string{".pdf"},
	}

	if action, _ := classify(e, existing, true); action != actionUnchanged {
		t.Errorf("action = %v, want actionUnchanged (observed trade-off; see ROADMAP ca-24)", action)
	}
}

func TestClassify_FormatAdded_Updates(t *testing.T) {
	e := entryWith(t, "ZK1", "2026-01-01T00:00:00Z",
		[]string{"a.pdf", "a.epub"},
		map[string]string{"a.pdf": "body", "a.epub": "other"})
	existing := trackedBook{
		bookID:  7,
		rev:     "2026-01-01T00:00:00Z+0123456789abcdef",
		formats: []string{".pdf"},
	}

	action, _ := classify(e, existing, true)

	if action != actionUpdate {
		t.Errorf("action = %v, want actionUpdate", action)
	}
}

// TestClassify_VanishedFileReadsAsUnchanged pins OBSERVED, NOT ENDORSED
// behavior. FileHash (zoteroImport.go:251-268) `continue`s past os.Open and
// io.Copy failures, so an attachment that disappeared from disk contributes
// nothing to the digest and hashes identically to one that never existed.
// A file vanishing between exports therefore reads as unchanged.
//
// Filed as defect D2 of workflow 2026-08-24_zotero-import-sync-coverage.
// Do not "fix" this test — changing it means changing convergence semantics,
// which is a product decision, not a test decision.
func TestClassify_VanishedFileReadsAsUnchanged(t *testing.T) {
	e := entryWith(t, "ZK1", "2026-01-01T00:00:00Z", []string{"a.pdf"}, map[string]string{"a.pdf": "body"})
	revWithFile := e.Rev()

	if err := os.Remove(e.Files[0].AbsPath); err != nil {
		t.Fatalf("remove: %v", err)
	}

	if e.Rev() == revWithFile {
		t.Fatal("test is vacuous: hash did not change when the file was removed")
	}

	// The gate never notices, because mtime and the extension set both still match.
	action, _ := classify(e, trackedBook{rev: revWithFile, formats: []string{".pdf"}}, true)
	if action != actionUnchanged {
		t.Errorf("action = %v, want actionUnchanged (observed behavior; defect D2)", action)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Format-representation invariant (study F3)
//
// classify compares entry.Exts() against trackedBook.formats with
// slices.Equal (zoteroSync.go:100). Exts() yields lowercase dotted
// extensions; extractExts (zoteroSync.go:32) must yield the same shape.
// The sibling helper FormatExts (calibreExec.go:104) yields UPPERCASE
// UNDOTTED names — swapping the two would silently mark every book changed.
// ═══════════════════════════════════════════════════════════════════

func TestExtractExtsMatchesEntryExts(t *testing.T) {
	paths := `["/lib/Author/Book (7)/Book.PDF","/lib/Author/Book (7)/Book.epub"]`

	fromCalibre := extractExts(gjson.Parse(paths).Array())
	fromExport := ImportEntry{Files: []ImportFile{{Ext: ".epub"}, {Ext: ".pdf"}}}.Exts()

	if !slices.Equal(fromCalibre, fromExport) {
		t.Errorf("extractExts = %v, Exts = %v — classify compares these directly; they must agree",
			fromCalibre, fromExport)
	}
	if got := FormatExts([]string{"/lib/Book.PDF", "/lib/Book.epub"}); slices.Equal(got, fromCalibre) {
		t.Error("FormatExts now agrees with extractExts; this guard assumed they differ in shape")
	}
}

// ═══════════════════════════════════════════════════════════════════
// pruneCandidates — bundle scoping (zoteroSync.go:257-276)
// ═══════════════════════════════════════════════════════════════════

func TestPruneCandidates(t *testing.T) {
	bundle := Bundle{Alias: "mine", ExportID: "EXP1"}
	entries := []ImportEntry{{ItemKey: "PRESENT"}}

	tracked := map[string]trackedBook{
		"PRESENT":    {bookID: 1, title: "Still exported", src: "mine", export: "EXP1"},
		"ORPHAN":     {bookID: 2, title: "Gone from export", src: "mine", export: "EXP1"},
		"OTHERALIAS": {bookID: 3, title: "Another alias", src: "theirs", export: "EXP1"},
		"OTHEREXP":   {bookID: 4, title: "Another export", src: "mine", export: "EXP2"},
		"NOEXP":      {bookID: 5, title: "Pre-export-id import", src: "mine", export: ""},
	}

	got := pruneCandidates(entries, tracked, bundle)

	ids := map[int]bool{}
	for _, c := range got {
		ids[c.bookID] = true
	}

	// 2: orphan under this bundle. 5: legacy row with no export id — the guard at
	// zoteroSync.go:267 skips only when BOTH sides carry one, so it stays a candidate.
	want := map[int]bool{2: true, 5: true}
	for id := range want {
		if !ids[id] {
			t.Errorf("book %d missing from prune candidates %v", id, ids)
		}
	}
	for _, id := range []int{1, 3, 4} {
		if ids[id] {
			t.Errorf("book %d should not be a prune candidate", id)
		}
	}
	if len(got) != 2 {
		t.Errorf("got %d candidates, want 2: %v", len(got), ids)
	}
}

func TestPruneCandidates_NoExportIDOnBundleIgnoresExportScope(t *testing.T) {
	bundle := Bundle{Alias: "mine"} // no ExportID
	tracked := map[string]trackedBook{
		"ORPHAN": {bookID: 2, src: "mine", export: "ANY"},
	}

	if got := pruneCandidates(nil, tracked, bundle); len(got) != 1 {
		t.Errorf("got %d candidates, want 1 — an empty bundle export id must not scope out tracked rows", len(got))
	}
}
