package calibre

// Phase 0 spike for WF-B.5 (search-incremental-sync).
//

// Originally validated append behavior against gitlab.com/rackn/seekable-zstd.
// Ported to the owned reader (own-seekable-reader): the historical
// TestSpikeSeekableLibraryNoAppendAPI — which documented that rackn's
// NewWriter drops prior seek-table entries on a second session — was removed
// with the dep; production append never used NewWriter (Path A shipped).
//

// The remaining tests exercise the EXACT production topology (the MWSC
// container layout produced by CompressToFile), not synthetic blob
// round-trips, per .sit/howto/spike_embedding_topology.md.

import (
	"bytes"
	"encoding/binary"
	"io"
	"os"
	"path/filepath"
	"testing"

	"github.com/cespare/xxhash/v2"
	"github.com/klauspost/compress/zstd"
)

// readSeekTableEntriesTB is the test wrapper around the production readSeekTableEntries.
func readSeekTableEntriesTB(tb testing.TB, seekableBytes []byte) (entries []byte, entrySize int, tableStart int64) {
	tb.Helper()
	entries, entrySize, tableStart, err := readSeekTableEntries(seekableBytes)
	if err != nil {
		tb.Fatal(err)
	}
	return entries, entrySize, tableStart
}

// writeSeekTableBuf is the test wrapper around the production writeSeekTable.
func writeSeekTableBuf(tb testing.TB, buf *bytes.Buffer, entries []byte, entrySize int) {
	tb.Helper()
	if err := writeSeekTable(buf, entries, entrySize); err != nil {
		tb.Fatal(err)
	}
}

// buildBaseIndex builds a real MWSC file via the production CompressToFile path
// and returns its on-disk bytes, the container-header prefix length, and the
// raw seekable stream bytes (everything after the header+dict).
func buildBaseIndex(tb testing.TB, jsonlPath, indexPath string) (filePath string, dictCatalog []DictCatalogEntry, seekableBytes []byte) {
	tb.Helper()
	ms := &MotwSearch{JsonlPath: jsonlPath, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		tb.Fatalf("BuildIndex: %v", err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		tb.Fatalf("CompressToFile: %v", err)
	}
	filePath = indexPath + ".zst"
	f, err := os.Open(filePath)
	if err != nil {
		tb.Fatal(err)
	}
	defer f.Close()
	dictCatalog, seekableOff, err := readContainerHeader(f)
	if err != nil {
		tb.Fatalf("readContainerHeader: %v", err)
	}
	raw, err := os.ReadFile(filePath)
	if err != nil {
		tb.Fatal(err)
	}
	seekableBytes = make([]byte, int64(len(raw))-seekableOff)
	copy(seekableBytes, raw[seekableOff:])
	return filePath, dictCatalog, seekableBytes
}

func catalogDecoderOpts(catalog []DictCatalogEntry) []zstd.DOption {
	var opts []zstd.DOption
	for _, e := range catalog {
		opts = append(opts, zstd.WithDecoderDictRaw(e.DictID, e.DictBytes))
	}
	return opts
}

func catalogEncoderOpts(catalog []DictCatalogEntry) []zstd.EOption {
	var opts []zstd.EOption
	for _, e := range catalog {
		opts = append(opts, zstd.WithEncoderDictRaw(e.DictID, e.DictBytes))
	}
	return opts
}

// TestSpikeSeekableAppendPathAManualMerge validates Path A: manually merge the seek table.
// Steps: (1) read the base's seek table entries; (2) truncate the base's seek table;
// (3) write a new compressed frame directly via enc.EncodeAll;
// (4) write a NEW seek table covering base entries + new entry. The owned reader
// must read both old and new uncompressed data at the correct offsets.
func TestSpikeSeekableAppendPathAManualMerge(t *testing.T) {
	path := seedJSONL(t, 32)
	dir := filepath.Dir(path)
	indexPath := filepath.Join(dir, "spike-patha")
	filePath, catalog, baseSeekable := buildBaseIndex(t, path, indexPath)

	dec, err := zstd.NewReader(nil, catalogDecoderOpts(catalog)...)
	if err != nil {
		t.Fatal(err)
	}
	defer dec.Close()

	// Read base seek table entries.
	baseEntries, entrySize, baseTableStart := readSeekTableEntriesTB(t, baseSeekable)

	// Pick a known uncompressed byte from base so we can verify it's still reachable
	// AT THE SAME UNCOMPRESSED OFFSET after the merge.
	baseRdr, err := newMWSCReaderAt(bytes.NewReader(baseSeekable), int64(len(baseSeekable)), dec)
	if err != nil {
		t.Fatal(err)
	}
	baseSize := baseRdr.Size()
	probeOff := int64(0)
	probe := make([]byte, 32)
	if _, err := baseRdr.ReadAt(probe, probeOff); err != nil {
		t.Fatal(err)
	}
	baseRdr.Close()

	// Build the appended uncompressed payload + encode it as one frame.
	payload := []byte("APPENDED-REGION-payload-payload-payload-payload\n")
	eOpts := append([]zstd.EOption{zstd.WithEncoderLevel(zstd.SpeedBestCompression)}, catalogEncoderOpts(catalog)...)
	enc, err := zstd.NewWriter(nil, eOpts...)
	if err != nil {
		t.Fatal(err)
	}
	defer enc.Close()
	compressedFrame := enc.EncodeAll(payload, nil)

	// Compose the new seekable stream: base compressed frames + new compressed frame + merged seek table.
	var merged bytes.Buffer
	merged.Write(baseSeekable[:baseTableStart])
	merged.Write(compressedFrame)
	mergedEntries := make([]byte, len(baseEntries)+entrySize)
	copy(mergedEntries, baseEntries)

	binary.LittleEndian.PutUint32(mergedEntries[len(baseEntries):len(baseEntries)+4], uint32(len(compressedFrame)))
	binary.LittleEndian.PutUint32(mergedEntries[len(baseEntries)+4:len(baseEntries)+8], uint32(len(payload)))
	if entrySize == seekTableEntrySizeCksm {

		// When the base footer has the checksum flag set, the reader verifies every
		// frame's checksum on read. Match the production formula — the lower 32 bits
		// of xxhash64 of the UNCOMPRESSED data.
		ck := uint32(xxhash.Sum64(payload))
		binary.LittleEndian.PutUint32(mergedEntries[len(baseEntries)+8:len(baseEntries)+12], ck)
	}
	writeSeekTableBuf(t, &merged, mergedEntries, entrySize)

	// Verify the merged stream is readable.
	mb := merged.Bytes()
	rdr, err := newMWSCReaderAt(bytes.NewReader(mb), int64(len(mb)), dec)
	if err != nil {
		t.Fatalf("merged reader: %v", err)
	}
	defer rdr.Close()
	mergedSize := rdr.Size()
	mergedFrames := rdr.numFrames()
	t.Logf("path-A merged stream: size=%d frames=%d (base size=%d, payload=%d, baseEntries=%d)", mergedSize, mergedFrames, baseSize, len(payload), len(baseEntries)/entrySize)

	if mergedSize != baseSize+int64(len(payload)) {
		t.Fatalf("merged Size mismatch: got %d want %d", mergedSize, baseSize+int64(len(payload)))
	}
	if mergedFrames != len(baseEntries)/entrySize+1 {
		t.Fatalf("merged numFrames mismatch: got %d want %d", mergedFrames, len(baseEntries)/entrySize+1)
	}

	// Probe base offset 0 — must return identical bytes.
	probe2 := make([]byte, len(probe))
	if _, err := rdr.ReadAt(probe2, probeOff); err != nil {
		t.Fatalf("ReadAt base offset on merged: %v", err)
	}
	if !bytes.Equal(probe, probe2) {
		t.Fatalf("base bytes at offset %d changed after Path A merge", probeOff)
	}

	// Probe the appended region — must return the new payload.
	got := make([]byte, len(payload))
	if _, err := rdr.ReadAt(got, baseSize); err != nil {
		t.Fatalf("ReadAt appended payload: %v", err)
	}
	if !bytes.Equal(got, payload) {
		t.Fatalf("appended payload mismatch: got %q want %q", got, payload)
	}

	// Bonus: confirm the merged file format remains valid by writing to disk and re-opening.
	mergedPath := filepath.Join(dir, "spike-patha-merged.zst")
	out, err := os.Create(mergedPath)
	if err != nil {
		t.Fatal(err)
	}

	// Copy container header+dict from base file, then the merged seekable stream.
	baseBytes, _ := os.ReadFile(filePath)
	prefix := int64(len(baseBytes)) - int64(len(baseSeekable))
	_, _ = out.Write(baseBytes[:prefix])
	_, _ = out.Write(mb)
	out.Close()

	f2, _ := os.Open(mergedPath)
	defer f2.Close()
	_, off2, _ := readContainerHeader(f2)
	end2, _ := f2.Seek(0, io.SeekEnd)
	sr2 := io.NewSectionReader(f2, off2, end2-off2)
	rdr2, err := newMWSCReaderAt(sr2, end2-off2, dec)
	if err != nil {
		t.Fatalf("on-disk merged reader: %v", err)
	}
	if rdr2.numFrames() != mergedFrames {
		t.Fatalf("on-disk frame-count drift: got %d want %d", rdr2.numFrames(), mergedFrames)
	}
	rdr2.Close()
}

// TestSpikeSeekableAppendPathBReencode validates Path B: re-encode all bytes into a
// fresh seekable stream (the topology TestSearchRejectsMultiRegion uses).
// Faster to implement but rewrites the entire .zst seekable stream — fails the
// HTTP Range:-economy promise from the design draft. Documented as the fallback.
func TestSpikeSeekableAppendPathBReencode(t *testing.T) {
	path := seedJSONL(t, 32)
	dir := filepath.Dir(path)
	indexPath := filepath.Join(dir, "spike-pathb")
	filePath, catalog, baseSeekable := buildBaseIndex(t, path, indexPath)

	dec, err := zstd.NewReader(nil, catalogDecoderOpts(catalog)...)
	if err != nil {
		t.Fatal(err)
	}
	defer dec.Close()

	// Read all base uncompressed bytes.
	baseRdr, err := newMWSCReaderAt(bytes.NewReader(baseSeekable), int64(len(baseSeekable)), dec)
	if err != nil {
		t.Fatal(err)
	}
	baseUncompressedSize := baseRdr.Size()
	all := make([]byte, baseUncompressedSize)
	if _, err := baseRdr.ReadAt(all, 0); err != nil && err != io.EOF {
		t.Fatal(err)
	}
	baseRdr.Close()

	// Re-encode all + appended payload through the hand-rolled writer path.
	payload := []byte("APPENDED-REGION-payload-payload-payload\n")
	eOpts := append([]zstd.EOption{zstd.WithEncoderLevel(zstd.SpeedBestCompression)}, catalogEncoderOpts(catalog)...)
	combined := append(all, payload...)
	rebuilt := handRolledSeekableStream(t, eOpts, 256<<10, seekTableEntrySizeCksm, combined)

	rdr, err := newMWSCReaderAt(bytes.NewReader(rebuilt), int64(len(rebuilt)), dec)
	if err != nil {
		t.Fatalf("path-B reader: %v", err)
	}
	defer rdr.Close()
	if rdr.Size() != baseUncompressedSize+int64(len(payload)) {
		t.Fatalf("path-B Size mismatch: got %d want %d", rdr.Size(), baseUncompressedSize+int64(len(payload)))
	}

	// Probe appended region.
	got := make([]byte, len(payload))
	if _, err := rdr.ReadAt(got, baseUncompressedSize); err != nil {
		t.Fatalf("path-B ReadAt appended: %v", err)
	}
	if !bytes.Equal(got, payload) {
		t.Fatalf("path-B appended payload mismatch: got %q want %q", got, payload)
	}

	t.Logf("path-B rebuilt stream: compressed=%d frames=%d (rewrites the whole .zst seekable stream — fails Range: economy)", len(rebuilt), rdr.numFrames())
	t.Logf("compare: base compressed=%d ; path-B compressed=%d ; path-B is NOT byte-incremental over the base", len(baseSeekable), len(rebuilt))
	_ = filePath
}
