package calibre

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestPointerFileRoundTrip(t *testing.T) {
	dir := t.TempDir()
	indexPath := filepath.Join(dir, "testlib")

	mf := Manifest{
		NumBooks:   42,
		Generation: 5,
		Regions:    []ManifestRegion{{}},
		Tombstones: [][16]byte{{1}, {2}},
	}
	copy(mf.BaseGeneration[:], []byte("0123456789abcdef"))

	lib := PointerFileLibrary{
		UUID:      "550e8400-e29b-41d4-a716-446655440000",
		Librarian: "alice",
	}

	// First write (append): pointerGeneration should be 1.
	if err := WritePointerFile(indexPath, mf, lib, false); err != nil {
		t.Fatalf("WritePointerFile (first): %v", err)
	}
	pf, err := ReadPointerFile(indexPath + ".manifest.json")
	if err != nil {
		t.Fatalf("ReadPointerFile (first): %v", err)
	}
	if pf.Version != 1 {
		t.Errorf("Version: got %d, want 1", pf.Version)
	}
	if pf.Index.PointerGeneration != 1 {
		t.Errorf("PointerGeneration: got %d, want 1", pf.Index.PointerGeneration)
	}
	if pf.Index.NumBooks != 42 {
		t.Errorf("NumBooks: got %d, want 42", pf.Index.NumBooks)
	}
	if pf.Index.Regions != 1 {
		t.Errorf("Regions: got %d, want 1", pf.Index.Regions)
	}
	if pf.Index.Tombstones != 2 {
		t.Errorf("Tombstones: got %d, want 2", pf.Index.Tombstones)
	}
	if pf.Index.IsCompacted {
		t.Error("IsCompacted: expected false for append")
	}
	if pf.LastCompact != nil {
		t.Error("LastCompact: expected nil for first append")
	}
	if pf.Library.UUID != lib.UUID {
		t.Errorf("UUID: got %q, want %q", pf.Library.UUID, lib.UUID)
	}
	if pf.Library.Librarian != lib.Librarian {
		t.Errorf("Librarian: got %q, want %q", pf.Library.Librarian, lib.Librarian)
	}
	if pf.Index.URL != "testlib.zst" {
		t.Errorf("URL: got %q, want %q", pf.Index.URL, "testlib.zst")
	}

	// Second write (compact): pointerGeneration should be 2, lastCompact set.
	mf.NumBooks = 50
	if err := WritePointerFile(indexPath, mf, lib, true); err != nil {
		t.Fatalf("WritePointerFile (compact): %v", err)
	}
	pf2, err := ReadPointerFile(indexPath + ".manifest.json")
	if err != nil {
		t.Fatalf("ReadPointerFile (compact): %v", err)
	}
	if pf2.Index.PointerGeneration != 2 {
		t.Errorf("PointerGeneration: got %d, want 2", pf2.Index.PointerGeneration)
	}
	if !pf2.Index.IsCompacted {
		t.Error("IsCompacted: expected true for compact")
	}
	if pf2.LastCompact == nil {
		t.Fatal("LastCompact: expected non-nil after compact")
	}
	if pf2.LastCompact.PointerGeneration != 2 {
		t.Errorf("LastCompact.PointerGeneration: got %d, want 2", pf2.LastCompact.PointerGeneration)
	}
	if pf2.LastCompact.NumBooks != 50 {
		t.Errorf("LastCompact.NumBooks: got %d, want 50", pf2.LastCompact.NumBooks)
	}
	if pf2.LastCompact.BuiltAt == "" {
		t.Error("LastCompact.BuiltAt: expected non-empty")
	}

	// Third write (append again): pointerGeneration should be 3, lastCompact carried forward.
	mf.NumBooks = 55
	if err := WritePointerFile(indexPath, mf, lib, false); err != nil {
		t.Fatalf("WritePointerFile (append after compact): %v", err)
	}
	pf3, err := ReadPointerFile(indexPath + ".manifest.json")
	if err != nil {
		t.Fatalf("ReadPointerFile (append after compact): %v", err)
	}
	if pf3.Index.PointerGeneration != 3 {
		t.Errorf("PointerGeneration: got %d, want 3", pf3.Index.PointerGeneration)
	}
	if pf3.Index.IsCompacted {
		t.Error("IsCompacted: expected false for append after compact")
	}
	if pf3.LastCompact == nil {
		t.Fatal("LastCompact: expected carried forward from compact")
	}
	if pf3.LastCompact.PointerGeneration != 2 {
		t.Errorf("LastCompact.PointerGeneration: got %d, want 2 (carried forward)", pf3.LastCompact.PointerGeneration)
	}
}

func TestWritePointerFileCorruptPrevious(t *testing.T) {
	dir := t.TempDir()
	indexPath := filepath.Join(dir, "testlib")
	pfPath := indexPath + ".manifest.json"

	// Write corrupt data to the pointer file path.
	if err := os.WriteFile(pfPath, []byte("not valid json{{{"), 0644); err != nil {
		t.Fatal(err)
	}

	mf := Manifest{NumBooks: 10}
	lib := PointerFileLibrary{UUID: "test-uuid", Librarian: "bob"}

	err := WritePointerFile(indexPath, mf, lib, false)
	if err == nil {
		t.Fatal("expected error for corrupt previous pointer file, got nil")
	}
	t.Logf("correctly returned error: %v", err)
}

func TestEnsurePointerFileCreatesIfMissing(t *testing.T) {
	dir := t.TempDir()
	indexPath := filepath.Join(dir, "testlib")

	mf := Manifest{
		NumBooks: 30,
		Regions:  []ManifestRegion{{}},
	}
	copy(mf.BaseGeneration[:], []byte("abcdefgh12345678"))

	lib := PointerFileLibrary{UUID: "test-uuid", Librarian: "carol"}

	// First call: should create.
	if err := EnsurePointerFile(indexPath, mf, lib); err != nil {
		t.Fatalf("EnsurePointerFile (create): %v", err)
	}

	pf, err := ReadPointerFile(indexPath + ".manifest.json")
	if err != nil {
		t.Fatalf("ReadPointerFile: %v", err)
	}
	if pf.Index.PointerGeneration != 1 {
		t.Errorf("PointerGeneration: got %d, want 1", pf.Index.PointerGeneration)
	}
	if pf.Index.NumBooks != 30 {
		t.Errorf("NumBooks: got %d, want 30", pf.Index.NumBooks)
	}

	// Second call: should not overwrite.
	mf.NumBooks = 99 // change something
	if err := EnsurePointerFile(indexPath, mf, lib); err != nil {
		t.Fatalf("EnsurePointerFile (noop): %v", err)
	}

	pf2, err := ReadPointerFile(indexPath + ".manifest.json")
	if err != nil {
		t.Fatalf("ReadPointerFile (after noop): %v", err)
	}
	if pf2.Index.NumBooks != 30 {
		t.Errorf("NumBooks after noop: got %d, want 30 (should not have overwritten)", pf2.Index.NumBooks)
	}
}

func TestReadPointerFileNotExist(t *testing.T) {
	_, err := ReadPointerFile("/nonexistent/path/foo.manifest.json")
	if err == nil {
		t.Fatal("expected error for nonexistent path, got nil")
	}
	if !os.IsNotExist(err) {

		// ReadPointerFile wraps the error; check via Unwrap chain
		t.Logf("error (expected to wrap os.ErrNotExist): %v", err)
	}
}

// --- JSONL lineage backward-compat tests ---

func TestPointerFileBackwardCompat(t *testing.T) {

	// An old pointer file without JSONL lineage fields should decode with
	// Go zero-values, ensuring graceful fallback to .zst download.
	oldJSON := `{
		"version": 1,
		"library": {"uuid": "abc123", "librarian": "test"},
		"index": {
			"url": "library_index.zst",
			"pointerGeneration": 5,
			"baseGeneration": "deadbeef00000000deadbeef00000000",
			"regions": 1,
			"numBooks": 2000,
			"tombstones": 0,
			"isCompacted": true
		}
	}`

	pf, err := DecodePointerFile(strings.NewReader(oldJSON))
	if err != nil {
		t.Fatalf("DecodePointerFile: %v", err)
	}

	// JSONL lineage fields must be zero-valued.
	if pf.Index.JsonlURL != "" {
		t.Errorf("JsonlURL = %q, want empty", pf.Index.JsonlURL)
	}
	if pf.Index.JsonlBytes != 0 {
		t.Errorf("JsonlBytes = %d, want 0", pf.Index.JsonlBytes)
	}
	if pf.Index.JsonlRawBytes != 0 {
		t.Errorf("JsonlRawBytes = %d, want 0", pf.Index.JsonlRawBytes)
	}
	if pf.Index.DictID != 0 {
		t.Errorf("DictID = %d, want 0", pf.Index.DictID)
	}
	if pf.Index.ChunkSize != 0 {
		t.Errorf("ChunkSize = %d, want 0", pf.Index.ChunkSize)
	}
	if pf.Index.IndexAggregateFields {
		t.Error("IndexAggregateFields = true, want false")
	}

	// Existing fields must decode correctly.
	if pf.Index.NumBooks != 2000 {
		t.Errorf("NumBooks = %d, want 2000", pf.Index.NumBooks)
	}
	if pf.Index.PointerGeneration != 5 {
		t.Errorf("PointerGeneration = %d, want 5", pf.Index.PointerGeneration)
	}
}

func TestPointerFileWithJSONLFields(t *testing.T) {

	// A new pointer file with JSONL lineage fields should decode fully.
	newJSON := `{
		"version": 1,
		"library": {"uuid": "abc123", "librarian": "aggregate"},
		"index": {
			"url": "library_index.zst",
			"pointerGeneration": 10,
			"baseGeneration": "deadbeef00000000deadbeef00000000",
			"regions": 1,
			"numBooks": 50000,
			"tombstones": 0,
			"isCompacted": true,
			"jsonlURL": "library_index.jsonl.zst",
			"jsonlBytes": 104000000,
			"jsonlRawBytes": 471000000,
			"dictID": 1,
			"chunkSize": 262144,
			"indexAggregateFields": true
		}
	}`

	pf, err := DecodePointerFile(strings.NewReader(newJSON))
	if err != nil {
		t.Fatalf("DecodePointerFile: %v", err)
	}

	if pf.Index.JsonlURL != "library_index.jsonl.zst" {
		t.Errorf("JsonlURL = %q, want %q", pf.Index.JsonlURL, "library_index.jsonl.zst")
	}
	if pf.Index.JsonlBytes != 104000000 {
		t.Errorf("JsonlBytes = %d, want 104000000", pf.Index.JsonlBytes)
	}
	if pf.Index.JsonlRawBytes != 471000000 {
		t.Errorf("JsonlRawBytes = %d, want 471000000", pf.Index.JsonlRawBytes)
	}
	if pf.Index.DictID != 1 {
		t.Errorf("DictID = %d, want 1", pf.Index.DictID)
	}
	if pf.Index.ChunkSize != 262144 {
		t.Errorf("ChunkSize = %d, want 262144", pf.Index.ChunkSize)
	}
	if !pf.Index.IndexAggregateFields {
		t.Error("IndexAggregateFields = false, want true")
	}
}

func TestPointerFileOmitempty(t *testing.T) {

	// JSONL fields should be omitted from JSON when zero-valued.
	pf := PointerFile{
		Version: 1,
		Library: PointerFileLibrary{UUID: "test", Librarian: "test"},
		Index: PointerFileIndex{
			URL:               "library_index.zst",
			PointerGeneration: 1,
			NumBooks:          100,
		},
	}
	data, err := json.Marshal(pf)
	if err != nil {
		t.Fatalf("Marshal: %v", err)
	}
	s := string(data)
	for _, field := range []string{"jsonlURL", "jsonlBytes", "jsonlRawBytes", "dictID", "chunkSize", "indexAggregateFields"} {
		if strings.Contains(s, field) {
			t.Errorf("zero-valued field %q should be omitted, but found in JSON: %s", field, s)
		}
	}
}

func TestPointerCommitBinding(t *testing.T) {
	base := PointerFile{
		Version: 1,
		Library: PointerFileLibrary{UUID: "550e8400-e29b-41d4-a716-446655440000", Librarian: "Alice"},
	}
	bound, err := BindPointerCommit(base, "sha256-source", 47)
	if err != nil {
		t.Fatal(err)
	}
	if bound.Version != 2 || bound.SourceFingerprint != "sha256-source" || bound.Generation != 47 {
		t.Fatalf("bound pointer = %+v", bound)
	}
	if err := ValidatePointerCommit(bound, "sha256-source", 47); err != nil {
		t.Fatal(err)
	}
	if err := ValidatePointerCommit(bound, "different", 47); err == nil {
		t.Fatal("source mismatch accepted")
	}
	if err := ValidatePointerCommit(bound, "sha256-source", 48); err == nil {
		t.Fatal("generation mismatch accepted")
	}
	if err := ValidatePointerCommit(base, "sha256-source", 47); err == nil {
		t.Fatal("legacy pointer accepted as committed")
	}
}
