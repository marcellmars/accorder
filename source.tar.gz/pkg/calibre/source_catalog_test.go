package calibre

import (
	"database/sql"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
)

func TestSourceCatalogReadsDatabaseWithoutBookDirectories(t *testing.T) {
	root := seedCalibreDB(t, 3)
	before, err := ReadSourceCatalog(root)
	if err != nil {
		t.Fatal(err)
	}
	if len(before) != 9 { // Two formats and an optional legacy cover per book; no OPF.
		t.Fatalf("files=%d", len(before))
	}
	entries, err := os.ReadDir(root)
	if err != nil || len(entries) != 1 || entries[0].Name() != "metadata.db" {
		t.Fatalf("test requires database-only source: %v %v", entries, err)
	}
	db, err := sql.Open("sqlite", filepath.Join(root, "metadata.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	if _, err := db.Exec("UPDATE books SET last_modified='2026-09-07T19:00:00+00:00' WHERE id=2"); err != nil {
		t.Fatal(err)
	}
	after, err := ReadSourceCatalog(root)
	if err != nil {
		t.Fatal(err)
	}
	for i, old := range before {
		changed := strings.HasPrefix(old.Path, "Author 2/")
		if (old.Stamp != after[i].Stamp) != changed || old.Path != after[i].Path || old.Size != after[i].Size {
			t.Fatalf("book-level replacement not isolated: old=%+v new=%+v", old, after[i])
		}
	}
	if _, err := db.Exec("ALTER TABLE books ADD COLUMN has_cover INTEGER DEFAULT 0"); err != nil {
		t.Fatal(err)
	}
	noCovers, err := ReadSourceCatalog(root)
	if err != nil || len(noCovers) != 6 {
		t.Fatalf("explicit absence: %d %v", len(noCovers), err)
	}
	for _, entry := range noCovers {
		if strings.HasSuffix(entry.Path, "/cover.jpg") || strings.HasSuffix(entry.Path, "/metadata.opf") {
			t.Fatal("invented a cover or OPF contrary to database-only contract")
		}
	}
	if _, err := db.Exec("UPDATE books SET has_cover=1 WHERE id=2"); err != nil {
		t.Fatal(err)
	}
	knownCover, err := ReadSourceCatalog(root)
	if err != nil {
		t.Fatal(err)
	}
	for _, entry := range knownCover {
		if strings.HasSuffix(entry.Path, "/cover.jpg") && entry.Optional {
			t.Fatal("a cover explicitly present in Calibre cannot be silently omitted")
		}
	}
}

func TestSourceCatalogIgnoresOutOfCalibreFilesAndRejectsUnsafePaths(t *testing.T) {
	root := seedCalibreDB(t, 1)
	before, err := ReadSourceCatalog(root)
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(root, "unmanaged.epub"), []byte("outside contract"), 0600); err != nil {
		t.Fatal(err)
	}
	opfDir := filepath.Join(root, filepath.Dir(before[0].Path))
	if err := os.MkdirAll(opfDir, 0700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(opfDir, "metadata.opf"), []byte("not parsed; metadata.db is authoritative"), 0600); err != nil {
		t.Fatal(err)
	}
	after, err := ReadSourceCatalog(root)
	if err != nil || !reflect.DeepEqual(before, after) {
		t.Fatalf("unmanaged payload changed database inventory: %v", err)
	}
	db, err := sql.Open("sqlite", filepath.Join(root, "metadata.db"))
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()
	for _, path := range []string{".", ".accorder/changes", ".caltrash/book", "../escape", "/absolute", "A/../escape", `C:\escape`} {
		if _, err := db.Exec("UPDATE books SET path=?", path); err != nil {
			t.Fatal(err)
		}
		if _, err := ReadSourceCatalog(root); err == nil {
			t.Fatalf("accepted unsafe path %q", path)
		}
	}
}
