package calibre

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"testing"
)

func TestSearchSyncCompactMode(t *testing.T) {

	jsonlPath := seedJSONL(t, 8)
	dir := filepath.Dir(jsonlPath)
	indexPath := filepath.Join(dir, "sync-test")
	ms := &MotwSearch{JsonlPath: jsonlPath, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex: %v", err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatalf("CompressToFile: %v", err)
	}

	mf, err := ReadExistingManifest(indexPath)
	if err != nil {
		t.Fatalf("ReadExistingManifest: %v", err)
	}
	lib := PointerFileLibrary{UUID: "sync-test-uuid", Librarian: "tester"}
	if err := WritePointerFile(indexPath, mf, lib, false); err != nil {
		t.Fatalf("WritePointerFile: %v", err)
	}

	zstPath := indexPath + ".zst"
	pfPath := indexPath + ".manifest.json"

	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/sync-test.manifest.json":
			http.ServeFile(w, r, pfPath)
		case "/sync-test.zst":
			http.ServeFile(w, r, zstPath)
		default:
			http.NotFound(w, r)
		}
	}))
	defer srv.Close()

	cacheDir := t.TempDir()

	pf := fetchPointerFileTest(t, srv.URL+"/sync-test.manifest.json")

	cached, err := LoadSyncState(cacheDir, pf.Library.UUID)
	if err != nil && !os.IsNotExist(err) {
		t.Fatalf("LoadSyncState: %v", err)
	}

	action := DetermineSyncAction(cached, pf, "compact", false)
	if action.Kind != SyncFullDownload {
		t.Fatalf("first sync: expected FullDownload, got %d (%s)", action.Kind, action.Reason)
	}

	localPath := filepath.Join(cacheDir, pf.Library.UUID+".zst")
	indexURL := srv.URL + "/" + pf.Index.URL
	downloadFullTest(t, indexURL, localPath)

	localMf, err := ReadExistingManifestFromPath(localPath)
	if err != nil {
		t.Fatalf("ReadExistingManifestFromPath: %v", err)
	}
	if localMf.NumBooks != mf.NumBooks {
		t.Errorf("NumBooks mismatch: local=%d, original=%d", localMf.NumBooks, mf.NumBooks)
	}

	if err := SaveSyncState(cacheDir, pf.Library.UUID, pf); err != nil {
		t.Fatalf("SaveSyncState: %v", err)
	}

	cached2, err := LoadSyncState(cacheDir, pf.Library.UUID)
	if err != nil {
		t.Fatalf("LoadSyncState (second): %v", err)
	}
	action2 := DetermineSyncAction(cached2, pf, "compact", false)
	if action2.Kind != SyncNoOp {
		t.Fatalf("second sync: expected NoOp, got %d (%s)", action2.Kind, action2.Reason)
	}
}

func ReadExistingManifestFromPath(zstPath string) (Manifest, error) {
	f, err := os.Open(zstPath)
	if err != nil {
		return Manifest{}, err
	}
	defer f.Close()
	rdr, dec, mf, err := openMWSC(f)
	if err != nil {
		return Manifest{}, err
	}
	rdr.Close()
	dec.Close()
	return mf, nil
}

func fetchPointerFileTest(tb testing.TB, pointerURL string) PointerFile {
	tb.Helper()
	resp, err := http.Get(pointerURL)
	if err != nil {
		tb.Fatalf("fetch pointer file: %v", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		tb.Fatalf("fetch pointer file: status %d", resp.StatusCode)
	}
	data, err := io.ReadAll(resp.Body)
	if err != nil {
		tb.Fatalf("read pointer file body: %v", err)
	}
	var pf PointerFile
	if err := json.Unmarshal(data, &pf); err != nil {
		tb.Fatalf("unmarshal pointer file: %v", err)
	}
	return pf
}

func TestRangeFetchTailAlgorithm(t *testing.T) {

	jsonlPath := seedJSONL(t, 8)
	dir := filepath.Dir(jsonlPath)
	indexPath := filepath.Join(dir, "range-test")

	ms := &MotwSearch{JsonlPath: jsonlPath, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex: %v", err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatalf("CompressToFile: %v", err)
	}
	zstPath := indexPath + ".zst"

	cacheDir := t.TempDir()
	cachedPath := filepath.Join(cacheDir, "cached.zst")
	copyFile(t, zstPath, cachedPath)

	truncateAt, err := ComputeRangeFetchOffset(cachedPath)
	if err != nil {
		t.Fatalf("ComputeRangeFetchOffset: %v", err)
	}
	t.Logf("Initial range-fetch offset: %d", truncateAt)

	deltaPath := filepath.Join(dir, "range-delta.jsonl")
	writeDeltaJSONL(t, deltaPath)
	ms2 := &MotwSearch{JsonlPath: deltaPath, IndexPath: indexPath}
	deltaIdx, err := ms2.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex (delta): %v", err)
	}
	if err := ms2.AppendToFile(deltaIdx, nil); err != nil {
		t.Fatalf("AppendToFile: %v", err)
	}

	postAppendMf, err := ReadExistingManifest(indexPath)
	if err != nil {
		t.Fatalf("ReadExistingManifest (post-append): %v", err)
	}
	if len(postAppendMf.Regions) < 2 {
		t.Fatalf("expected >= 2 regions after append, got %d", len(postAppendMf.Regions))
	}

	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		http.ServeFile(w, r, zstPath)
	}))
	defer srv.Close()

	headResp, err := http.Head(srv.URL + "/index.zst")
	if err != nil {
		t.Fatalf("HEAD: %v", err)
	}
	headResp.Body.Close()
	remoteSize := headResp.ContentLength
	t.Logf("Remote size: %d, truncateAt: %d", remoteSize, truncateAt)

	if remoteSize <= truncateAt {
		t.Fatalf("remote size %d <= truncateAt %d — cannot range-fetch", remoteSize, truncateAt)
	}

	req, _ := http.NewRequest("GET", srv.URL+"/index.zst", nil)
	req.Header.Set("Range", fmt.Sprintf("bytes=%d-", truncateAt))
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatalf("range-fetch: %v", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusPartialContent {
		t.Fatalf("expected 206, got %d", resp.StatusCode)
	}
	tailBytes, err := io.ReadAll(resp.Body)
	if err != nil {
		t.Fatalf("read tail: %v", err)
	}
	t.Logf("Fetched %d tail bytes", len(tailBytes))

	f, err := os.OpenFile(cachedPath, os.O_RDWR, 0)
	if err != nil {
		t.Fatalf("open cached: %v", err)
	}
	if err := f.Truncate(truncateAt); err != nil {
		t.Fatalf("truncate: %v", err)
	}
	if _, err := f.Seek(truncateAt, io.SeekStart); err != nil {
		t.Fatalf("seek: %v", err)
	}
	if _, err := f.Write(tailBytes); err != nil {
		t.Fatalf("write tail: %v", err)
	}
	f.Close()

	mergedMf, err := ReadExistingManifestFromPath(cachedPath)
	if err != nil {
		t.Fatalf("ReadExistingManifestFromPath (merged): %v", err)
	}
	if len(mergedMf.Regions) != len(postAppendMf.Regions) {
		t.Fatalf("merged regions=%d, post-append regions=%d — mismatch",
			len(mergedMf.Regions), len(postAppendMf.Regions))
	}
	if mergedMf.NumBooks != postAppendMf.NumBooks {
		t.Fatalf("merged NumBooks=%d, post-append NumBooks=%d — mismatch",
			mergedMf.NumBooks, postAppendMf.NumBooks)
	}

	msSearch := &MotwSearch{IndexPath: filepath.Join(cacheDir, "cached")}

	copyFile(t, cachedPath, filepath.Join(cacheDir, "cached.zst"))
	query := SearchQuery{Field: FieldTitle, Text: "delta"}
	books, _, err := msSearch.Search(context.Background(), query, SearchOptions{})
	if err != nil {
		t.Fatalf("Search on merged index: %v", err)
	}
	if len(books) == 0 {
		t.Fatal("expected to find 'delta' books in merged index, got 0")
	}
	t.Logf("VALIDATED: range-fetch produced valid searchable index (regions=%d, books=%d, found=%d 'delta' results)",
		len(mergedMf.Regions), mergedMf.NumBooks, len(books))
}

func TestSearchSyncAppendMode(t *testing.T) {

	jsonlPath := seedJSONL(t, 8)
	dir := filepath.Dir(jsonlPath)
	indexPath := filepath.Join(dir, "append-sync")
	lib := PointerFileLibrary{UUID: "append-sync-uuid", Librarian: "tester"}

	ms := &MotwSearch{JsonlPath: jsonlPath, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex: %v", err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatalf("CompressToFile: %v", err)
	}
	mf, err := ReadExistingManifest(indexPath)
	if err != nil {
		t.Fatalf("ReadExistingManifest: %v", err)
	}
	if err := WritePointerFile(indexPath, mf, lib, false); err != nil {
		t.Fatalf("WritePointerFile: %v", err)
	}

	zstPath := indexPath + ".zst"
	pfPath := indexPath + ".manifest.json"

	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/append-sync.manifest.json":
			http.ServeFile(w, r, pfPath)
		case "/append-sync.zst":
			http.ServeFile(w, r, zstPath)
		default:
			http.NotFound(w, r)
		}
	}))
	defer srv.Close()

	cacheDir := t.TempDir()
	pf := fetchPointerFileTest(t, srv.URL+"/append-sync.manifest.json")
	action := DetermineSyncAction(nil, pf, "append", false)
	if action.Kind != SyncFullDownload {
		t.Fatalf("first sync: expected FullDownload, got %d", action.Kind)
	}
	localPath := filepath.Join(cacheDir, pf.Library.UUID+".zst")
	downloadFullTest(t, srv.URL+"/append-sync.zst", localPath)
	if err := SaveSyncState(cacheDir, pf.Library.UUID, pf); err != nil {
		t.Fatalf("SaveSyncState: %v", err)
	}

	deltaPath := filepath.Join(dir, "append-sync-delta.jsonl")
	writeDeltaJSONL(t, deltaPath)
	ms2 := &MotwSearch{JsonlPath: deltaPath, IndexPath: indexPath}
	deltaIdx, err := ms2.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex (delta): %v", err)
	}
	if err := ms2.AppendToFile(deltaIdx, nil); err != nil {
		t.Fatalf("AppendToFile: %v", err)
	}
	mf2, err := ReadExistingManifest(indexPath)
	if err != nil {
		t.Fatalf("ReadExistingManifest: %v", err)
	}
	if err := WritePointerFile(indexPath, mf2, lib, false); err != nil {
		t.Fatalf("WritePointerFile (append): %v", err)
	}

	pf2 := fetchPointerFileTest(t, srv.URL+"/append-sync.manifest.json")
	cached, err := LoadSyncState(cacheDir, pf2.Library.UUID)
	if err != nil {
		t.Fatalf("LoadSyncState: %v", err)
	}
	action2 := DetermineSyncAction(cached, pf2, "append", false)
	if action2.Kind != SyncRangeFetch {
		t.Fatalf("second sync: expected RangeFetch, got %d (%s)", action2.Kind, action2.Reason)
	}
	t.Logf("append mode second sync: %s", action2.Reason)
}

func TestSearchSyncHybridMode(t *testing.T) {

	jsonlPath := seedJSONL(t, 8)
	dir := filepath.Dir(jsonlPath)
	indexPath := filepath.Join(dir, "hybrid-sync")
	lib := PointerFileLibrary{UUID: "hybrid-sync-uuid", Librarian: "tester"}

	ms := &MotwSearch{JsonlPath: jsonlPath, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex: %v", err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatalf("CompressToFile: %v", err)
	}
	mf, err := ReadExistingManifest(indexPath)
	if err != nil {
		t.Fatalf("ReadExistingManifest: %v", err)
	}

	if err := WritePointerFile(indexPath, mf, lib, false); err != nil {
		t.Fatalf("WritePointerFile: %v", err)
	}

	cached := &CachedSyncState{
		BaseGeneration:    (&PointerFile{}).Index.BaseGeneration,
		PointerGeneration: 1,
		LastCompactGen:    0,
	}

	pfData, err := ReadPointerFile(indexPath + ".manifest.json")
	if err != nil {
		t.Fatalf("ReadPointerFile: %v", err)
	}
	cached.BaseGeneration = pfData.Index.BaseGeneration

	ms2 := &MotwSearch{JsonlPath: jsonlPath, IndexPath: indexPath}
	ms2.BaseGeneration = &mf.BaseGeneration
	idx2, err := ms2.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex (compact): %v", err)
	}
	if err := ms2.CompressToFile(idx2); err != nil {
		t.Fatalf("CompressToFile (compact): %v", err)
	}
	mf2, err := ReadExistingManifest(indexPath)
	if err != nil {
		t.Fatalf("ReadExistingManifest: %v", err)
	}
	if err := WritePointerFile(indexPath, mf2, lib, true); err != nil {
		t.Fatalf("WritePointerFile (compact): %v", err)
	}

	pf2, err := ReadPointerFile(indexPath + ".manifest.json")
	if err != nil {
		t.Fatalf("ReadPointerFile: %v", err)
	}

	action := DetermineSyncAction(cached, pf2, "hybrid", false)
	if action.Kind != SyncFullDownload {
		t.Fatalf("hybrid + compaction: expected FullDownload, got %d (%s)", action.Kind, action.Reason)
	}
	t.Logf("hybrid mode compaction detection: %s", action.Reason)
}

func copyFile(tb testing.TB, src, dst string) {
	tb.Helper()
	data, err := os.ReadFile(src)
	if err != nil {
		tb.Fatalf("copy read: %v", err)
	}
	if err := os.WriteFile(dst, data, 0644); err != nil {
		tb.Fatalf("copy write: %v", err)
	}
}

func downloadFullTest(tb testing.TB, indexURL, localPath string) {
	tb.Helper()
	resp, err := http.Get(indexURL)
	if err != nil {
		tb.Fatalf("download: %v", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		tb.Fatalf("download: status %d", resp.StatusCode)
	}
	f, err := os.Create(localPath)
	if err != nil {
		tb.Fatalf("create local: %v", err)
	}
	defer f.Close()
	if _, err := io.Copy(f, resp.Body); err != nil {
		tb.Fatalf("write local: %v", err)
	}
}
