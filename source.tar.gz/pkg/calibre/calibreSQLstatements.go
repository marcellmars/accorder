package calibre

var (
	main_query = `
SELECT
  books.id as book_id,
  books.title as title,
  books.sort as title_sort,
  books.pubdate as pubdate,
  books.last_modified as last_modified,
  books.uuid as uuid,
  books.path as cover_url
FROM
  books`

	sub_query = map[string]string{
		"formats": `
SELECT
  books.id as book_id,
  data.format as file_format,
  data.uncompressed_size as file_size,
  data.name as file_name,
  books.path as path
FROM
  books
  JOIN data ON data.book = books.id`,

		"tags": `
SELECT
  books.id as book_id,
  tags.name as tag
FROM
  books
  JOIN books_tags_link ON books.id = books_tags_link.book
  JOIN tags ON tags.id = books_tags_link.tag`,
		"abstract": `
SELECT
  books.id as book_id,
  comments.text as abstract
FROM
  books
  JOIN comments ON books.id = comments.book`,

		"publisher": `
SELECT
  books.id as book_id,
  publishers.name as publisher
FROM
  books
  JOIN books_publishers_link ON books.id = books_publishers_link.book
  JOIN publishers ON publishers.id = books_publishers_link.publisher`,

		"authors": `
SELECT
  books.id as book_id,
  authors.name as author
FROM
  books
  JOIN books_authors_link ON books.id = books_authors_link.book
  JOIN authors ON authors.id = books_authors_link.author`,

		"series": `
SELECT
  books.id as book_id,
  series.name
FROM
  books
  JOIN books_series_link ON books.id = books_series_link.book
  JOIN series ON series.id = books_series_link.series`,

		"languages": `
SELECT
  books.id as book_id,
  languages.lang_code as lang_code
FROM
  books
  JOIN books_languages_link ON books.id = books_languages_link.book
  JOIN languages ON languages.id = books_languages_link.lang_code`,

		"identifiers": `
SELECT
  books.id as book_id,
  identifiers.type as id_type,
  identifiers.val as id_val
FROM
  books
  JOIN identifiers ON identifiers.book = books.id`,
	}

	all_books_SQL = `SELECT
	  json_object(
	    'abstract',
	    (
	      SELECT
	        IIF(count(c.id)=0, '', c.text)
	      FROM
	        comments c
	      WHERE
	        c.book=books.id
	      LIMIT
	        1
	    ),
	    'authors',
	    (
	      SELECT
	        json_group_array(authors.name)
	      FROM
	        books_authors_link bal
	        JOIN authors ON bal.author=authors.id
	      WHERE
	        bal.book=books.id
	    ),
	    'cover_url',
	    books.path||"/cover.jpg",
	    'identifiers',
	    (
	      SELECT
	        json_group_array(json_object('scheme', i.type, 'code', i.val))
	      FROM
	        identifiers i
	      WHERE
	        i.book=books.id
	    ),
	        'formats',
    json_group_array(
      json_object(
        'dir_path',
        books.path||"/",
        'file_name',
        data.name||"."||lower(data.format),
        'format',
        lower(data.format),
        'size',
        data.uncompressed_size
      )
    ) FILTER (WHERE data.id IS NOT NULL),
    'last_modified',
	    books.last_modified,
	    'languages',
	    (
	      SELECT
	        json_group_array(languages.lang_code)
	      FROM
	        books_languages_link bll
	        JOIN languages ON bll.lang_code=languages.id
	      WHERE
	        bll.book=books.id
	    ),
	        'pubdate',
    books.pubdate,
    'publisher',
    (
      SELECT
        IIF(count(publishers.id)=0, '', publishers.name)
      FROM
        books_publishers_link bpl
        JOIN publishers ON bpl.publisher=publishers.id
      WHERE
        bpl.book=books.id
    ),
    'series',
	    (
	      SELECT
	        IIF(count(series.id)=0, '', series.name)
	      FROM
	        books_series_link bsl
	        JOIN series ON bsl.series=series.id
	      WHERE
	        bsl.book=books.id
	    ),
	    'title',
	    books.title,
	    'title_sort',
	    books.sort,
	    'tags',
	    (
	      SELECT
	        json_group_array(tags.name)
	      FROM
	        books_tags_link btl
	        JOIN tags ON btl.tag=tags.id
	      WHERE
	        btl.book=books.id
	    ),
	    'uuid',
	    books.uuid,
	    'id',
	    books.id
	  )
	FROM
	  books
	  LEFT JOIN DATA ON data.book=books.id
	GROUP BY
	  books.id
	ORDER BY
	  books.last_modified;`

	//nolint:unused // alternative Zotero-hash SQL retained for reference
	zotero_hash_SQL = `SELECT json_object(
        'id', books.id,
		'identifiers',
	   	(SELECT
	       json_group_array(
	         json_object('scheme', i.type, 'code', i.val)
	       )
	     FROM
	       identifiers i
	     WHERE
	       i.book = books.id AND i.type == 'zoteroHash'
	   	))
		FROM books
	 	  LEFT JOIN DATA ON data.book = books.id
		GROUP BY books.id
    	HAVING json_array_length(
        (SELECT
           json_group_array(
             json_object('scheme', i.type, 'code', i.val)
           )
         FROM
           identifiers i
         WHERE
           i.book = books.id AND i.type = 'zoteroHash'
        )) > 0`
)
