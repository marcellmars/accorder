package calibre

import (
	"bytes"
	"context"
	"fmt"
	"hash/fnv"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"

	"github.com/goccy/go-json"
)

type CalibreExe struct {
	LibraryPath string
	CalibreCLI  func(cmd *exec.Cmd) ([]byte, error)
}

func (exe *CalibreExe) calibredb(ctx context.Context, args ...string) ([]byte, error) {
	if exe.LibraryPath != "" {
		args = append([]string{fmt.Sprintf("--library-path=%s", exe.LibraryPath)}, args...)
	}
	return exe.RunWithArgs(ctx, "calibredb", args...)
}

func (exe *CalibreExe) Books(ctx context.Context) ([]*Book, error) {
	data, err := exe.calibredb(ctx, "list", "--for-machine", "--fields=all", "--sort-by=last_modified")
	if err != nil {
		return nil, err
	}
	var books []*Book
	if err := json.Unmarshal(data, &books); err != nil {
		return nil, fmt.Errorf("Books: unmarshal: %w", err)
	}
	return books, nil
}

func (exe *CalibreExe) ListWithFilter(ctx context.Context, search, fields string) ([]byte, error) {
	args := []string{"list", "--for-machine"}
	if search != "" {
		args = append(args, "-s", search)
	}
	if fields != "" {
		args = append(args, "-f", fields)
	}
	return exe.calibredb(ctx, args...)
}

// ImportedBook is the change-tracking state of a previously-imported book.
type ImportedBook struct {
	CalibreID int      // Calibre's numeric book id
	Rev       string   // accorder_rev change token (empty for pre-revision imports)
	Formats   []string // uppercase format names, sorted
}

// ImportedAccorderBooks indexes books already imported by accorder (those
// carrying an "accorder" identifier), keyed by the accorder uuid. It lets a
// re-import decide add / update / unchanged by identity and revision rather
// than calibredb's unreliable title/author matching.
func (exe *CalibreExe) ImportedAccorderBooks(ctx context.Context) (map[string]ImportedBook, error) {
	out, err := exe.ListWithFilter(ctx, "identifiers:accorder:", "id,identifiers,formats")
	if err != nil {
		return nil, err
	}
	var rows []struct {
		ID          int               `json:"id"`
		Identifiers map[string]string `json:"identifiers"`
		Formats     []string          `json:"formats"`
	}
	if err := json.Unmarshal(out, &rows); err != nil {
		return nil, fmt.Errorf("parse list: %w", err)
	}
	books := make(map[string]ImportedBook)
	for _, r := range rows {
		uuid := r.Identifiers["accorder"]
		if uuid == "" {
			continue
		}
		books[uuid] = ImportedBook{
			CalibreID: r.ID,
			Rev:       r.Identifiers["accorder_rev"],
			Formats:   FormatExts(r.Formats),
		}
	}
	return books, nil
}

// FormatExts maps file paths to their sorted, uppercased extensions
// (e.g. ["EPUB","PDF"]) — Calibre's format-name convention.
func FormatExts(paths []string) []string {
	exts := make([]string, 0, len(paths))
	for _, p := range paths {
		if e := strings.ToUpper(strings.TrimPrefix(filepath.Ext(p), ".")); e != "" {
			exts = append(exts, e)
		}
	}
	sort.Strings(exts)
	return exts
}

// ImportRevision is a change-detection token for a downloaded book:
// "<metaHash>+<formatHash>". metaHash tracks the librarian's last_modified
// (metadata edits); formatHash tracks the set of format files by name+size
// (additions, removals, content changes).
func ImportRevision(lastModified string, formatFiles []string) string {
	lines := make([]string, 0, len(formatFiles))
	for _, f := range formatFiles {
		size := int64(-1)
		if fi, err := os.Stat(f); err == nil {
			size = fi.Size()
		}
		lines = append(lines, fmt.Sprintf("%s:%d", filepath.Base(f), size))
	}
	sort.Strings(lines)
	return importHash(lastModified) + "+" + importHash(strings.Join(lines, "\n"))
}

// RevisionChanged compares two ImportRevision tokens, reporting whether the
// metadata part and/or the format part differ.
func RevisionChanged(oldRev, newRev string) (metaChanged, formatChanged bool) {
	om, of, _ := strings.Cut(oldRev, "+")
	nm, nf, _ := strings.Cut(newRev, "+")
	return om != nm, of != nf
}

func importHash(s string) string {
	h := fnv.New64a()
	_, _ = h.Write([]byte(s))
	return fmt.Sprintf("%x", h.Sum64())
}

var addedIDsRe = regexp.MustCompile(`Added book ids:\s*([\d,\s]+)`)
var duplicateMarker = []byte("not added as they already exist")

// AddBatch adds multiple book files in a SINGLE calibredb invocation (one book
// per file) and returns the created book ids in input order. This is far
// cheaper than N separate Add calls — one process + one sqlite session instead
// of N — which dominates large imports. If calibredb skips a file as a
// duplicate, fewer ids come back than files were given; callers must detect the
// length mismatch and fall back to per-file Add to keep ids mapped to sources.
func (exe *CalibreExe) AddBatch(ctx context.Context, filePaths []string) ([]int, error) {
	if len(filePaths) == 0 {
		return nil, nil
	}
	stdout, stderr, err := exe.calibredbCapturingStderr(ctx, append([]string{"add"}, filePaths...)...)
	if err != nil {
		if msg := strings.TrimSpace(string(stderr)); msg != "" {
			return nil, fmt.Errorf("calibredb add (batch): %w: %s", err, msg)
		}
		return nil, fmt.Errorf("calibredb add (batch): %w", err)
	}
	return parseAddedIDs(stdout)
}

func parseAddedIDs(stdout []byte) ([]int, error) {
	m := addedIDsRe.FindSubmatch(stdout)
	if m == nil {
		return nil, fmt.Errorf("could not parse book IDs from calibredb add output: %s", stdout)
	}
	var ids []int
	for _, tok := range strings.FieldsFunc(string(m[1]), func(r rune) bool {
		return r == ',' || r == ' ' || r == '\n' || r == '\t' || r == '\r'
	}) {
		n, err := strconv.Atoi(tok)
		if err != nil {
			continue
		}
		ids = append(ids, n)
	}
	if len(ids) == 0 {
		return nil, fmt.Errorf("no book IDs in calibredb add output: %s", stdout)
	}
	return ids, nil
}

// SetMetadataWithOPF applies a book's metadata.opf AND optional -f field
// overrides in ONE set_metadata call (calibredb accepts both an OPF path and
// -f fields), halving the per-book metadata invocations. opfPath may be empty.
func (exe *CalibreExe) SetMetadataWithOPF(ctx context.Context, bookID int, opfPath string, fields map[string]string) error {
	args := []string{"set_metadata", strconv.Itoa(bookID)}
	if opfPath != "" {
		args = append(args, opfPath)
	}
	for k, v := range fields {
		args = append(args, "-f", k+":"+v)
	}
	_, err := exe.calibredb(ctx, args...)
	return err
}

func (exe *CalibreExe) Add(ctx context.Context, title, filePath string) (int, error) {
	stdout, stderr, err := exe.calibredbCapturingStderr(ctx, "add", "-t", title, filePath)
	if err != nil {
		if msg := strings.TrimSpace(string(stderr)); msg != "" {
			return 0, fmt.Errorf("calibredb add: %w: %s", err, msg)
		}
		return 0, fmt.Errorf("calibredb add: %w", err)
	}
	if ids, perr := parseAddedIDs(stdout); perr == nil && len(ids) > 0 {
		return ids[0], nil
	}
	// No id parsed — calibredb skipped the file as a duplicate (warning printed
	// to stderr, sometimes stdout). Resolve the existing record by title.
	if bytes.Contains(stderr, duplicateMarker) || bytes.Contains(stdout, duplicateMarker) {
		id, lerr := exe.findBookIDByTitle(ctx, title)
		if lerr != nil {
			return 0, fmt.Errorf("calibredb add for %q reported duplicate; lookup failed: %w", title, lerr)
		}
		return id, nil
	}
	return 0, fmt.Errorf("could not parse book ID from calibredb add output: %s", stdout)
}

// findBookIDByTitle resolves a book by exact title match. Used when calibredb
// add reports a duplicate (partial-state recovery): the previous run added the
// book but set_metadata aborted before the zotero: identifier was written, so
// accorder cannot find it via its identifier index. Multiple matches return
// the highest book ID — the most-recently-added record.
func (exe *CalibreExe) findBookIDByTitle(ctx context.Context, title string) (int, error) {
	out, err := exe.calibredb(ctx, "list", "-f", "id,title", "--for-machine", "--limit", "999999")
	if err != nil {
		return 0, fmt.Errorf("list: %w", err)
	}
	var rows []struct {
		ID    int    `json:"id"`
		Title string `json:"title"`
	}
	if err := json.Unmarshal(out, &rows); err != nil {
		return 0, fmt.Errorf("parse list: %w", err)
	}
	maxID := 0
	for _, r := range rows {
		if r.Title == title && r.ID > maxID {
			maxID = r.ID
		}
	}
	if maxID == 0 {
		return 0, fmt.Errorf("no book matches exact title %q", title)
	}
	return maxID, nil
}

func (exe *CalibreExe) SetMetadata(ctx context.Context, bookID int, fields map[string]string) error {
	args := []string{"set_metadata", strconv.Itoa(bookID)}
	for k, v := range fields {
		args = append(args, "-f", k+":"+v)
	}
	_, err := exe.calibredb(ctx, args...)
	return err
}

// SetMetadataFromOPF applies a book's full metadata (authors, tags,
// publisher, dates, identifiers, cover) to an existing record by feeding
// calibredb the book's metadata.opf — Calibre ingests its own OPF natively.
func (exe *CalibreExe) SetMetadataFromOPF(ctx context.Context, bookID int, opfPath string) error {
	_, err := exe.calibredb(ctx, "set_metadata", strconv.Itoa(bookID), opfPath)
	return err
}

func (exe *CalibreExe) AddFormat(ctx context.Context, bookID int, filePath string) error {
	_, err := exe.calibredb(ctx, "add_format", strconv.Itoa(bookID), filePath)
	return err
}

func (exe *CalibreExe) RemoveFormat(ctx context.Context, bookID int, format string) error {
	_, err := exe.calibredb(ctx, "remove_format", strconv.Itoa(bookID), format)
	return err
}

func (exe *CalibreExe) Remove(ctx context.Context, bookID int) error {
	_, err := exe.calibredb(ctx, "remove", strconv.Itoa(bookID))
	return err
}

func (exe *CalibreExe) RunWithArgs(ctx context.Context, command string, args ...string) ([]byte, error) {
	cmd := exec.CommandContext(ctx, calibreToolPath(command))
	cmd.Args = append(cmd.Args, args...)
	cmd.Stderr = os.Stderr

	var buf []byte
	var err error
	if exe.CalibreCLI != nil {
		buf, err = exe.CalibreCLI(cmd)
	} else {
		buf, err = cmd.Output()
	}
	if err != nil {
		return []byte("CALIBRE ERROR:"), err
	}
	return buf, nil
}

// calibredbCapturingStderr runs calibredb the same way calibredb() does (with
// --library-path prepended when set), but tees stderr to a buffer in addition
// to os.Stderr so the caller can inspect it. Used by Add to detect the
// "not added as they already exist" duplicate warning.
func (exe *CalibreExe) calibredbCapturingStderr(ctx context.Context, args ...string) (stdout, stderr []byte, err error) {
	if exe.LibraryPath != "" {
		args = append([]string{fmt.Sprintf("--library-path=%s", exe.LibraryPath)}, args...)
	}
	cmd := exec.CommandContext(ctx, calibreToolPath("calibredb"))
	cmd.Args = append(cmd.Args, args...)

	var stderrBuf bytes.Buffer
	cmd.Stderr = io.MultiWriter(&stderrBuf, os.Stderr)

	if exe.CalibreCLI != nil {
		stdout, err = exe.CalibreCLI(cmd)
	} else {
		stdout, err = cmd.Output()
	}
	if err != nil {
		return []byte("CALIBRE ERROR:"), stderrBuf.Bytes(), err
	}
	return stdout, stderrBuf.Bytes(), nil
}
