package calibre

import (
	"bufio"
	"context"
	"database/sql"
	"embed"
	"fmt"
	"io"
	"io/fs"
	"log"
	"math"
	"os"
	"path/filepath"
	"sort"
	"strings"

	_ "github.com/glebarez/go-sqlite"
	"github.com/goccy/go-json"
	uuid "github.com/satori/go.uuid"
)

var (
	//go:embed embResources
	embResources embed.FS
)

type HugoCatalogItem struct {
	Key  string
	Book *Book
}

type DataJS struct {
	Portable bool    `json:"portable"`
	Total    int     `json:"total,omitempty"`
	Books    []*Book `json:"books"`
}

type Identifier struct {
	Scheme string `json:"scheme"`
	Code   string `json:"code"`
}

type File struct {
	Format        string `json:"format"`
	DirectoryPath string `json:"dir_path"`
	Name          string `json:"file_name"`
	Size          int64  `json:"size"`
	XXHash        uint64 `json:"xxhash,omitempty"`
}

type MotwStandaloneApp struct {
	CalibreDirectory string
	BaseURL          string
	Librarian        string
	LibraryUUID      string
	Books            []*Book
	PrivateExcludes  []string
}

// MotwLibrary is one entry of motw_libraries.json (keyed by library UUID).
// The json tags are explicit and lowercase to match what is on disk: without
// them these fields load only via encoding/json's case-insensitive fallback,
// and any future marshal would silently rewrite the file with capitalised
// keys.
type MotwLibrary struct {
	State     string `json:"state"`
	URL       string `json:"url"`
	Librarian string `json:"librarian"`
}

type Book struct {
	Abstract         string        `json:"abstract"`
	Authors          []string      `json:"authors"`
	BaseURL          string        `json:"baseurl,omitempty"`
	LibraryUrl       string        `json:"library_url"`
	CalibreID        int64         `json:"id,omitempty"`
	CoverUrl         string        `json:"cover_url"`
	Formats          []*File       `json:"formats"`
	Id               string        `json:"_id"`
	Identifiers      []*Identifier `json:"identifiers"`
	Languages        []string      `json:"languages"`
	LastModified     string        `json:"last_modified"`
	Librarian        string        `json:"librarian"`
	LibraryUUID      string        `json:"library_uuid"`
	Pubdate          string        `json:"pubdate"`
	Publisher        string        `json:"publisher"`
	Series           string        `json:"series"`
	Tags             []string      `json:"tags"`
	Title            string        `json:"title"`
	TitleSort        string        `json:"title_sort"`
	UUID             string        `json:"uuid,omitempty"`
	CoverFingerprint string        `json:"cover_fingerprint,omitempty"`
	SearchScore      float64       `json:"-"`
}

func relativePath(path string) string {
	cleanPath := filepath.Clean(path)
	parts := strings.Split(cleanPath, string(filepath.Separator))
	if len(parts) < 3 {
		return ""
	}
	relativeDirs := parts[len(parts)-3 : len(parts)-1]
	relativeDirsPath := filepath.Join(relativeDirs...)
	if !strings.HasSuffix(relativeDirsPath, string(filepath.Separator)) {
		relativeDirsPath += string(filepath.Separator)
	}

	return relativeDirsPath
}

func (book *Book) UnmarshalJSON(data []byte) error {
	type Alias Book

	aux := &struct {
		Authors     json.RawMessage `json:"authors"`
		Comments    string          `json:"comments"`
		Cover       *string         `json:"cover,omitempty"`
		Formats     json.RawMessage `json:"formats"`
		Identifiers json.RawMessage `json:"identifiers"`
		*Alias
	}{
		Alias: (*Alias)(book),
	}

	if err := json.Unmarshal(data, &aux); err != nil {
		return err
	}

	if len(aux.Comments) > 0 {
		aux.Abstract = aux.Comments
	}

	if aux.Cover != nil {
		book.CoverUrl = relativePath(*aux.Cover) + "cover.jpg"
	}

	var sliceAuthors []string
	if err := json.Unmarshal(aux.Authors, &sliceAuthors); err != nil {
		var stringAuthors string
		if err := json.Unmarshal(aux.Authors, &stringAuthors); err != nil {
			return err
		}
		book.Authors = strings.Split(stringAuthors, " & ")
	} else {
		book.Authors = sliceAuthors
	}

	if err := json.Unmarshal(aux.Identifiers, &book.Identifiers); err != nil {
		var identifiers map[string]string
		if err := json.Unmarshal(aux.Identifiers, &identifiers); err == nil {
			for key, value := range identifiers {
				book.Identifiers = append(book.Identifiers, &Identifier{
					Scheme: key,
					Code:   value,
				})
			}
		} else {
			fmt.Println("No identifiers")
		}
	}

	if err := json.Unmarshal(aux.Formats, &book.Formats); err != nil {
		var formats []string
		if err := json.Unmarshal(aux.Formats, &formats); err == nil {
			book.Formats = []*File{}
			for _, format := range formats {
				var size int64
				if fileInfo, err := os.Stat(format); err == nil {
					size = fileInfo.Size()
				}

				book.Formats = append(book.Formats, &File{
					Format:        strings.ReplaceAll(filepath.Ext(format), ".", ""),
					DirectoryPath: relativePath(format),
					Name:          filepath.Base(format),
					Size:          size,
				})
			}
		} else {
			fmt.Println("No formats")
		}
	}
	return nil
}

type CalibreBooksByLastModified []*Book

func (books CalibreBooksByLastModified) Len() int {
	return len(books)
}

func (books CalibreBooksByLastModified) Swap(i, j int) {
	books[i], books[j] = books[j], books[i]
}

func (books CalibreBooksByLastModified) Less(i, j int) bool {
	if books[i].LastModified != books[j].LastModified {
		return books[i].LastModified < books[j].LastModified
	}
	return books[i].Id < books[j].Id
}

func (book *Book) ValuesForField(field SearchField) []string {
	switch field {
	case FieldTitle:
		return []string{book.Title}
	case FieldAuthor:
		return book.Authors
	case FieldTag:
		return book.Tags
	case FieldAbstract:
		if book.Abstract != "" {
			return []string{book.Abstract}
		}
		return nil
	}
	return nil
}

func (book *Book) MemoryOfTheWorldify(motw *MotwStandaloneApp) {
	book.Librarian = motw.Librarian
	book.LibraryUUID = motw.LibraryUUID

	if len(motw.BaseURL) > 0 {
		if !strings.HasSuffix(motw.BaseURL, "/") {
			motw.BaseURL += "/"
		}
		book.BaseURL = motw.BaseURL
	}

	if book.Id != "" {
		book.UUID = ""
		book.CalibreID = 0
		return
	}

	seed := book.UUID
	if seed == "" {
		seed = fmt.Sprintf("nouuid\x00%d\x00%s\x00%s\x00%s",
			book.CalibreID, book.Title, book.LastModified, book.CoverUrl)
		log.Printf("MemoryOfTheWorldify: book %q has no source UUID; deriving fallback _id", book.Title)
	}

	ns, err := uuid.FromString(motw.LibraryUUID)
	if err != nil {
		log.Fatalf("MemoryOfTheWorldify: invalid library UUID %q: %v", motw.LibraryUUID, err)
	}

	book.Id = uuid.NewV5(ns, seed).String()
	book.UUID = ""
	book.CalibreID = 0
}

func (motw *MotwStandaloneApp) JsonL(filePath string) {
	if err := motw.JsonLE(filePath); err != nil {
		log.Fatal(err)
	}
}

func (motw *MotwStandaloneApp) SandpointsCatalog(filePath string) {
	file, err := os.Create(filePath)
	if err != nil {
		log.Fatal(err)
	}
	defer file.Close()

	writer := bufio.NewWriter(file)
	defer writer.Flush()

	for _, book := range motw.Books {
		bookLine := make(map[string]*Book)
		bookLine[book.Id] = book
		data, err := json.Marshal(bookLine)
		if err != nil {
			log.Fatal(err)
		}
		_, err = writer.Write(data)
		if err != nil {
			log.Fatal(err)
		}
		_, err = writer.WriteString("\n")
		if err != nil {
			log.Fatal(err)
		}
	}
}

func (motw *MotwStandaloneApp) copyEmbResources() {
	_ = fs.WalkDir(embResources, ".", func(fsPath string, fsEntry fs.DirEntry, walkErr error) error {
		if walkErr != nil {
			return walkErr
		}
		if fsPath == "." || fsPath == "embResources" {
			return nil
		}
		destFsPath := strings.ReplaceAll(fsPath, "embResources/", "")
		if fsEntry.IsDir() {
			if err := os.MkdirAll(filepath.Join(motw.CalibreDirectory, destFsPath), 0755); err != nil {
				log.Fatalln(err, "make embedded resources directory")
			}
			return nil
		}

		embFile, err := embResources.Open(fsPath)
		if err != nil {
			log.Fatalln(err, "open embedded resource")
		}
		defer embFile.Close()

		newFile, err := os.Create(filepath.Join(motw.CalibreDirectory, destFsPath))
		if err != nil {
			log.Fatalln(err, "create files in embedded resources directory")
		}
		defer newFile.Close()

		if _, err := io.Copy(newFile, embFile); err != nil {
			log.Fatalln(err, "copy embResources/ file into the new file at the destination...")
		}
		return nil
	})
}

func WriteBrowseDataJS(staticDir string, books []*Book) {
	dataJsFirst, err := os.Create(filepath.Join(staticDir, "data1.js"))
	if err != nil {
		log.Fatalln(err, "create dataJsFirst file...")
	}
	defer dataJsFirst.Close()
	endB := 24
	if endB >= len(books) {
		endB = len(books)
	}
	j1, _ := json.Marshal(&DataJS{
		Portable: true,
		Total:    len(books),
		Books:    books[0:endB],
	})
	calibreBooks1 := []byte("CALIBRE_BOOKS1=")
	_, _ = dataJsFirst.Write(append(calibreBooks1, j1...))

	// [24:120], [120:216], [216:3288], [3288:6360], [6360:9432], [9432:12504]
	block := endB
	counter := 2
	for i := range [2]int{} {
		ii := make([]int, int(math.Pow(2, float64(i+1))))
		for j := range ii {
			_ = j

			var jsn []byte

			endBlock := block + int(math.Pow(32, float64(i+1)))*3

			if endBlock > len(books) {
				endBlock = len(books)
			}

			dataJs, err := os.Create(filepath.Join(staticDir, fmt.Sprintf("data%d.js", counter)))
			if err != nil {
				log.Fatalln(err, "create dataJs file...")
			}
			defer dataJs.Close()

			if endBlock <= len(books) {
				jsn, _ = json.Marshal(&DataJS{
					Portable: true,
					Books:    books[block:endBlock],
				})
			} else {
				jsn, _ = json.Marshal(&DataJS{
					Portable: true,
					Books:    []*Book{},
				})
			}
			calibreBooks := []byte(fmt.Sprintf("CALIBRE_BOOKS%d=", counter))
			_, _ = dataJs.Write(append(calibreBooks, jsn...))
			block = endBlock
			counter++
		}
	}
	dataJsLast, err := os.Create(filepath.Join(staticDir, "data8.js"))
	if err != nil {
		log.Fatalln(err, "create dataJsLast file...")
	}
	defer dataJsLast.Close()
	j8, _ := json.Marshal(&DataJS{
		Portable: true,
		Total:    len(books),
		Books:    books[block:],
	})
	calibreBooks8 := []byte("CALIBRE_BOOKS8=")
	_, _ = dataJsLast.Write(append(calibreBooks8, j8...))
}

func (motw *MotwStandaloneApp) openCalibreDB() *sql.DB {
	db, err := motw.openCalibreDBE()
	if err != nil {
		log.Fatalln(err)
	}
	return db
}

func (motw *MotwStandaloneApp) getBooksSQLiteSingleQuery() {
	db := motw.openCalibreDB()
	defer db.Close()

	rows, err := db.Query(all_books_SQL)
	if err != nil {
		log.Fatalln(err)
	}
	defer rows.Close()

	for rows.Next() {
		var raw []byte
		if err := rows.Scan(&raw); err != nil {
			log.Fatalln(err)
		}
		var book Book
		if err := json.Unmarshal(raw, &book); err != nil {
			log.Fatalln(err)
		}
		book.MemoryOfTheWorldify(motw)
		motw.Books = append(motw.Books, &book)
	}
	if err := rows.Err(); err != nil {
		log.Fatalln(err)
	}
}

func (motw *MotwStandaloneApp) getBooksSQLite() {
	if err := motw.getBooksSQLiteE(); err != nil {
		log.Fatalln(err)
	}
}

func (motw *MotwStandaloneApp) openCalibreDBE() (*sql.DB, error) {
	dbPath := filepath.Join(motw.CalibreDirectory, "metadata.db")
	if _, err := os.Stat(dbPath); err != nil {
		return nil, fmt.Errorf("calibre metadata.db not found at %s: %w", dbPath, err)
	}
	db, err := sql.Open("sqlite", "file:"+dbPath+"?mode=ro")
	if err != nil {
		return nil, fmt.Errorf("open metadata.db: %w", err)
	}
	return db, nil
}

func (motw *MotwStandaloneApp) getBooksSQLiteE() error {
	db, err := motw.openCalibreDBE()
	if err != nil {
		return err
	}
	defer db.Close()

	rows, err := db.Query(main_query)
	if err != nil {
		return fmt.Errorf("main query: %w", err)
	}
	defer rows.Close()

	booksMap := make(map[int64]*Book)

	var bookID int64
	for rows.Next() {
		var title, titleSort, pubdate, lastModified, bookUUID, bookPath string
		if err := rows.Scan(&bookID, &title, &titleSort, &pubdate, &lastModified, &bookUUID, &bookPath); err != nil {
			return fmt.Errorf("scan main row: %w", err)
		}
		book := Book{
			CalibreID:    bookID,
			Title:        title,
			TitleSort:    titleSort,
			CoverUrl:     filepath.Join(bookPath, "cover.jpg"),
			Pubdate:      pubdate,
			LastModified: lastModified,
			UUID:         bookUUID,
		}
		booksMap[bookID] = &book
		book.MemoryOfTheWorldify(motw)
	}
	if err := rows.Err(); err != nil {
		return fmt.Errorf("main rows: %w", err)
	}

	for queryType, query := range sub_query {
		subRows, err := db.Query(query)
		if err != nil {
			return fmt.Errorf("sub query %s: %w", queryType, err)
		}

		switch queryType {
		case "formats":
			for subRows.Next() {
				var fileFormat, fileName, fpath string
				var fileSize int64
				if err = subRows.Scan(&bookID, &fileFormat, &fileSize, &fileName, &fpath); err != nil {
					subRows.Close()
					return fmt.Errorf("scan formats row: %w", err)
				}
				fileFormat = strings.ToLower(fileFormat)
				if !strings.HasSuffix(fpath, string(filepath.Separator)) {
					fpath += string(filepath.Separator)
				}
				if book, ok := booksMap[bookID]; ok {
					book.Formats = append(book.Formats, &File{
						Format:        fileFormat,
						DirectoryPath: fpath,
						Name:          fileName + "." + fileFormat,
						Size:          fileSize,
					})
				}
			}
		case "tags":
			for subRows.Next() {
				var tag string
				if err = subRows.Scan(&bookID, &tag); err != nil {
					subRows.Close()
					return fmt.Errorf("scan tags row: %w", err)
				}
				if book, ok := booksMap[bookID]; ok {
					book.Tags = append(book.Tags, tag)
				}
			}
		case "abstract":
			for subRows.Next() {
				var abstract string
				if err = subRows.Scan(&bookID, &abstract); err != nil {
					subRows.Close()
					return fmt.Errorf("scan abstract row: %w", err)
				}
				if book, ok := booksMap[bookID]; ok {
					book.Abstract = abstract
				}
			}
		case "publisher":
			for subRows.Next() {
				var publisher string
				if err = subRows.Scan(&bookID, &publisher); err != nil {
					subRows.Close()
					return fmt.Errorf("scan publisher row: %w", err)
				}
				if book, ok := booksMap[bookID]; ok {
					book.Publisher = publisher
				}
			}
		case "authors":
			for subRows.Next() {
				var author string
				if err = subRows.Scan(&bookID, &author); err != nil {
					subRows.Close()
					return fmt.Errorf("scan authors row: %w", err)
				}
				if book, ok := booksMap[bookID]; ok {
					book.Authors = append(book.Authors, author)
				}
			}
		case "series":
			for subRows.Next() {
				var series string
				if err = subRows.Scan(&bookID, &series); err != nil {
					subRows.Close()
					return fmt.Errorf("scan series row: %w", err)
				}
				if book, ok := booksMap[bookID]; ok {
					book.Series = series
				}
			}
		case "languages":
			for subRows.Next() {
				var lang string
				if err = subRows.Scan(&bookID, &lang); err != nil {
					subRows.Close()
					return fmt.Errorf("scan languages row: %w", err)
				}
				if book, ok := booksMap[bookID]; ok {
					book.Languages = append(book.Languages, lang)
				}
			}
		case "identifiers":
			for subRows.Next() {
				var idType, idVal string
				if err = subRows.Scan(&bookID, &idType, &idVal); err != nil {
					subRows.Close()
					return fmt.Errorf("scan identifiers row: %w", err)
				}
				if book, ok := booksMap[bookID]; ok {
					book.Identifiers = append(book.Identifiers, &Identifier{
						Scheme: idType,
						Code:   idVal,
					})
				}
			}
		}
		subRows.Close()
	}
	for _, book := range booksMap {
		motw.Books = append(motw.Books, book)
	}
	return nil
}

func (motw *MotwStandaloneApp) LoadBooksE() error {
	if err := motw.getBooksSQLiteE(); err != nil {
		return fmt.Errorf("load books: %w", err)
	}
	sort.Sort(sort.Reverse(CalibreBooksByLastModified(motw.Books)))
	if err := motw.AssertBookIDsUnique(); err != nil {
		return fmt.Errorf("load books: %w", err)
	}
	return nil
}

func (motw *MotwStandaloneApp) AssertBookIDsUnique() error {
	return assertBookIDsUnique(motw.Books)
}

func assertBookIDsUnique(books []*Book) error {
	seen := make(map[string]string, len(books))
	empty := 0
	for _, b := range books {
		if b.Id == "" {
			empty++
			continue
		}
		if prev, dup := seen[b.Id]; dup {
			return fmt.Errorf("duplicate book _id %q shared by %q and %q", b.Id, prev, b.Title)
		}
		seen[b.Id] = b.Title
	}
	if empty > 0 {
		return fmt.Errorf("%d book(s) have an empty _id after MemoryOfTheWorldify", empty)
	}
	return nil
}

func (motw *MotwStandaloneApp) JsonLE(filePath string) error {
	file, err := os.Create(filePath)
	if err != nil {
		return fmt.Errorf("create JSONL file: %w", err)
	}
	defer file.Close()
	writer := bufio.NewWriter(file)
	defer writer.Flush()
	for _, book := range motw.Books {
		data, err := json.Marshal(book)
		if err != nil {
			return fmt.Errorf("marshal book: %w", err)
		}
		if _, err := writer.Write(data); err != nil {
			return fmt.Errorf("write book: %w", err)
		}
		if _, err := writer.WriteString("\n"); err != nil {
			return fmt.Errorf("write newline: %w", err)
		}
	}
	return nil
}

//nolint:unused // alternative book-loading path retained for reference
func (motw *MotwStandaloneApp) getBooksCalibreDB() {
	ce := CalibreExe{
		LibraryPath: motw.CalibreDirectory,
	}

	motw.Books, _ = ce.Books(context.Background())
	for _, book := range motw.Books {
		book.MemoryOfTheWorldify(motw)
	}
}

func (motw *MotwStandaloneApp) Render() string {
	motw.copyEmbResources()
	motw.getBooksSQLite()
	before := len(motw.Books)
	motw.Books, motw.PrivateExcludes = PartitionPrivateBooks(motw.Books)
	if dropped := before - len(motw.Books); dropped > 0 {
		log.Printf("Render: excluded %d book(s) tagged \"private\" from the browse site", dropped)
	}
	sort.Sort(sort.Reverse(CalibreBooksByLastModified(motw.Books)))
	if err := motw.AssertBookIDsUnique(); err != nil {
		log.Fatalf("Render: %v", err)
	}
	return fmt.Sprintf("Website: %s (%d books)\n", filepath.Join(motw.CalibreDirectory, "BROWSE_LIBRARY.html"), len(motw.Books))
}
