package calibre

import (
	"bufio"
	"bytes"
	"container/heap"
	"context"
	"encoding/binary"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"testing"

	"github.com/goccy/go-json"
	"github.com/klauspost/compress/zstd"
)

func seedJSONL(tb testing.TB, n int) string {
	tb.Helper()
	dir := tb.TempDir()
	path := filepath.Join(dir, "books.jsonl")
	f, err := os.Create(path)
	if err != nil {
		tb.Fatal(err)
	}
	defer f.Close()

	w := bufio.NewWriter(f)
	defer w.Flush()

	titles := []string{
		"The Art of Programming",
		"Discourse Networks, 1800/1900",
		"A Brief History of Time",
		"Capital in the Twenty-First Century",
		"Critique of Pure Reason",
		"Being and Nothingness",
		"The Structure of Scientific Revolutions",
		"Phenomenology of Spirit",
		"One-Dimensional Man",
		"The Wretched of the Earth",
	}
	authors := [][]string{
		{"Donald Knuth"},
		{"Friedrich Kittler"},
		{"Stephen Hawking"},
		{"Thomas Piketty"},
		{"Immanuel Kant"},
		{"Jean-Paul Sartre"},
		{"Thomas Kuhn"},
		{"Georg Wilhelm Friedrich Hegel"},
		{"Herbert Marcuse"},
		{"Frantz Fanon"},
	}
	tags := [][]string{
		{"computer science", "algorithms"},
		{"media theory", "german literature"},
		{"physics", "cosmology"},
		{"economics", "inequality"},
		{"philosophy", "epistemology"},
		{"philosophy", "existentialism"},
		{"philosophy", "science"},
		{"philosophy", "idealism"},
		{"philosophy", "critical theory"},
		{"politics", "decolonization"},
	}

	for i := 0; i < n; i++ {
		idx := i % len(titles)
		book := Book{
			Title:        titles[idx],
			Authors:      authors[idx],
			Tags:         tags[idx],
			LastModified: fmt.Sprintf("2024-01-%02dT00:00:00+00:00", (i%28)+1),
			LibraryUUID:  "test-lib-uuid",
			Librarian:    "testlib",
			UUID:         fmt.Sprintf("book-uuid-%d", i),
		}
		data, err := json.Marshal(book)
		if err != nil {
			tb.Fatal(err)
		}
		_, _ = w.Write(data)
		_ = w.WriteByte('\n')
	}
	return path
}

func bruteForce(tb testing.TB, jsonlPath string, q SearchQuery) []*Book {
	tb.Helper()
	f, err := os.Open(jsonlPath)
	if err != nil {
		tb.Fatal(err)
	}
	defer f.Close()

	var books []*Book
	scanner := bufio.NewScanner(f)
	scanner.Buffer(make([]byte, 1<<20), 1<<20)
	for scanner.Scan() {
		var book Book
		if err := json.Unmarshal(scanner.Bytes(), &book); err != nil {
			tb.Fatal(err)
		}
		if findBook(q, book) {
			books = append(books, &book)
		}
	}
	if err := scanner.Err(); err != nil {
		tb.Fatal(err)
	}
	sort.Sort(CalibreBooksByLastModified(books))
	return books
}

func TestTokenizeBaseline(t *testing.T) {
	tests := []struct {
		input string
		want  []string
	}{
		{"Discourse Networks, 1800/1900", []string{"discours", "network", "1800", "1900"}},
		{"  Foo,,Bar ", []string{"foo", "bar"}},
		{"café", []string{"cafe"}},
		{"", nil},
		{"hello", []string{"hello"}},
		{"a-b_c", []string{"a", "b", "c"}},
		{"123", []string{"123"}},
		{"  ", nil},
		{"one two  three", []string{"one", "two", "three"}},

		{"café", []string{"cafe"}},
		{"Running", []string{"run"}},
		{"Über die Ästhetik", []string{"uber", "die", "asthetik"}},
		{"thomas", []string{"thoma"}},
		{"programming", []string{"program"}},
	}
	for _, tt := range tests {
		t.Run(tt.input, func(t *testing.T) {
			got := normalizeAndTokenize(tt.input)
			if len(got) == 0 && len(tt.want) == 0 {
				return
			}
			if len(got) != len(tt.want) {
				t.Fatalf("normalizeAndTokenize(%q) = %v, want %v", tt.input, got, tt.want)
			}
			for i := range got {
				if got[i] != tt.want[i] {
					t.Fatalf("normalizeAndTokenize(%q)[%d] = %q, want %q", tt.input, i, got[i], tt.want[i])
				}
			}

			for i, tok := range got {
				if tok == "" {
					t.Fatalf("normalizeAndTokenize(%q)[%d] is empty", tt.input, i)
				}
			}
		})
	}
}

func TestBuildIndexSegmentBoundaries(t *testing.T) {
	for _, n := range []int{15, 16, 17, 32, 33, 48} {
		t.Run(fmt.Sprintf("n=%d", n), func(t *testing.T) {
			path := seedJSONL(t, n)
			ms := &MotwSearch{JsonlPath: path}
			idx, err := ms.BuildIndex()
			if err != nil {
				t.Fatal(err)
			}

			wantSegments := n / 16
			if n%16 != 0 {
				wantSegments++
			}
			if int(idx.NumSegments) != wantSegments {
				t.Fatalf("n=%d: got %d segments, want %d", n, idx.NumSegments, wantSegments)
			}

		})
	}
}

func TestSearchRoundTrip(t *testing.T) {
	path := seedJSONL(t, 500)
	dir := filepath.Dir(path)
	indexPath := filepath.Join(dir, "test-index")

	ms := &MotwSearch{
		JsonlPath: path,
		IndexPath: indexPath,
	}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}

	queries := []SearchQuery{
		{Field: FieldTitle, Text: "the"},
		{Field: FieldAuthor, Text: "Thomas"},
		{Field: FieldTag, Text: "philosophy"},
		{Field: FieldTitle, Text: "art programming"},
		{Field: FieldAuthor, Text: "Donald Knuth"},
		{Field: FieldTitle, Text: "xyznonexistent"},
	}

	searcher := &MotwSearch{IndexPath: indexPath}

	for _, q := range queries {
		t.Run(fmt.Sprintf("%s:%s", q.Field, q.Text), func(t *testing.T) {
			expected := bruteForce(t, path, q)
			got, stats, err := searcher.Search(context.Background(), q, SearchOptions{})
			if err != nil {
				t.Fatal(err)
			}

			if len(got) != len(expected) {
				t.Fatalf("Search(%v): got %d books, bruteForce got %d",
					q, len(got), len(expected))
			}

			for i := range got {
				if got[i].Title != expected[i].Title {
					t.Fatalf("Search(%v)[%d]: got title %q, want %q",
						q, i, got[i].Title, expected[i].Title)
				}
			}

			if stats.BooksMatched != len(expected) {
				t.Fatalf("Search(%v): stats.BooksMatched=%d, want %d",
					q, stats.BooksMatched, len(expected))
			}
		})
	}
}

func TestSearchEarlyTermination(t *testing.T) {
	path := seedJSONL(t, 500)
	dir := filepath.Dir(path)
	indexPath := filepath.Join(dir, "early-term-index")

	ms := &MotwSearch{JsonlPath: path, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}

	searcher := &MotwSearch{IndexPath: indexPath}
	broadQuery := SearchQuery{Field: FieldTitle, Text: "the"}

	allBooks, allStats, err := searcher.Search(context.Background(), broadQuery, SearchOptions{})
	if err != nil {
		t.Fatal(err)
	}
	if len(allBooks) < 10 {
		t.Fatalf("expected at least 10 matches for broad query, got %d", len(allBooks))
	}

	oracle := bruteForce(t, path, broadQuery)
	sort.Sort(CalibreBooksByLastModified(oracle))

	t.Run("Limit5", func(t *testing.T) {
		books, stats, err := searcher.Search(context.Background(), broadQuery, SearchOptions{Limit: 5})
		if err != nil {
			t.Fatal(err)
		}

		if len(books) < 5 {
			t.Fatalf("got %d books, want at least 5", len(books))
		}

		if stats.ClustersRead > allStats.ClustersRead {
			t.Fatalf("early termination read more clusters (%d) than full scan (%d)",
				stats.ClustersRead, allStats.ClustersRead)
		}

		sort.Sort(CalibreBooksByLastModified(books))
		for i := 0; i < 5 && i < len(books); i++ {
			if books[i].LastModified != oracle[i].LastModified {
				t.Fatalf("book[%d]: last_modified %q, want %q (got title %q, oracle title %q)",
					i, books[i].LastModified, oracle[i].LastModified, books[i].Title, oracle[i].Title)
			}
		}
	})

	t.Run("Limit5_Offset10", func(t *testing.T) {
		books, _, err := searcher.Search(context.Background(), broadQuery, SearchOptions{Limit: 5, Offset: 10})
		if err != nil {
			t.Fatal(err)
		}
		if len(books) < 15 {
			t.Fatalf("got %d books, want at least 15 (limit+offset)", len(books))
		}

		sort.Sort(CalibreBooksByLastModified(books))
		sliced := books[10:]
		if len(sliced) > 5 {
			sliced = sliced[:5]
		}

		for i := range sliced {
			if sliced[i].LastModified != oracle[10+i].LastModified {
				t.Fatalf("offset book[%d]: got LastModified %q, want %q", i, sliced[i].LastModified, oracle[10+i].LastModified)
			}
		}
	})
}

func TestSearchPostingsEquivalence(t *testing.T) {

	path := seedJSONL(t, 500)
	dir := filepath.Dir(path)
	indexPath := filepath.Join(dir, "postings-equiv-index")

	ms := &MotwSearch{JsonlPath: path, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}

	if idx.NumSegments == 0 {
		t.Fatal("NumSegments is 0")
	}
	if idx.NumBooks != 500 {
		t.Fatalf("NumBooks=%d, want 500", idx.NumBooks)
	}
	if len(idx.Postings) == 0 {
		t.Fatal("Postings is empty")
	}
	if len(idx.PostingsMeta) == 0 {
		t.Fatal("PostingsMeta is empty")
	}
	if len(idx.DocLengths) == 0 {
		t.Fatal("DocLengths is empty")
	}

	searcher := &MotwSearch{IndexPath: indexPath}

	queries := []SearchQuery{
		{Field: FieldTitle, Text: "the"},
		{Field: FieldAuthor, Text: "Thomas"},
		{Field: FieldTag, Text: "philosophy"},
		{Field: FieldTitle, Text: "art programming"},
		{Field: FieldAuthor, Text: "Donald Knuth"},
		{Field: FieldTitle, Text: "xyznonexistent"},
	}

	for _, q := range queries {
		t.Run(fmt.Sprintf("%s:%s", q.Field, q.Text), func(t *testing.T) {
			expected := bruteForce(t, path, q)
			got, stats, err := searcher.Search(context.Background(), q, SearchOptions{})
			if err != nil {
				t.Fatal(err)
			}

			if len(got) != len(expected) {
				t.Fatalf("Search(%v): got %d books, bruteForce got %d",
					q, len(got), len(expected))
			}

			if stats.PostingsNarrowed == 0 && len(expected) > 0 {
				t.Errorf("Search(%v): PostingsNarrowed is 0 but there are %d matches", q, len(expected))
			}

			gotUUIDs := make(map[string]bool, len(got))
			for _, b := range got {
				gotUUIDs[b.UUID] = true
			}
			for _, b := range expected {
				if !gotUUIDs[b.UUID] {
					t.Fatalf("Search(%v): missing book UUID %s (title=%q)", q, b.UUID, b.Title)
				}
			}
		})
	}
}

func TestSearchRanking(t *testing.T) {

	dir := t.TempDir()
	jsonlPath := filepath.Join(dir, "ranking.jsonl")
	f, err := os.Create(jsonlPath)
	if err != nil {
		t.Fatal(err)
	}

	books := []Book{
		{
			Title:        "Discourse Networks Analysis",
			Authors:      []string{"Friedrich Kittler"},
			Tags:         []string{"media theory", "german literature"},
			LastModified: "2024-06-01T00:00:00+00:00",
			LibraryUUID:  "test-lib-uuid",
			Librarian:    "testlib",
			UUID:         "book-title-recent",
		},
		{
			Title:        "The Art of Programming",
			Authors:      []string{"Donald Knuth"},
			Tags:         []string{"network science", "algorithms"},
			LastModified: "2024-06-01T00:00:00+00:00",
			LibraryUUID:  "test-lib-uuid",
			Librarian:    "testlib",
			UUID:         "book-tag-only",
		},
		{
			Title:        "Advanced Network Theory",
			Authors:      []string{"Jane Doe"},
			Tags:         []string{"physics", "cosmology"},
			LastModified: "2020-01-15T00:00:00+00:00",
			LibraryUUID:  "test-lib-uuid",
			Librarian:    "testlib",
			UUID:         "book-title-old",
		},
	}

	for i := 0; i < 20; i++ {
		books = append(books, Book{
			Title:        fmt.Sprintf("Filler Book Number %d", i),
			Authors:      []string{"Nobody"},
			Tags:         []string{"filler"},
			LastModified: "2022-01-01T00:00:00+00:00",
			LibraryUUID:  "test-lib-uuid",
			Librarian:    "testlib",
			UUID:         fmt.Sprintf("filler-%d", i),
		})
	}

	w := bufio.NewWriter(f)
	for _, b := range books {
		data, _ := json.Marshal(b)
		_, _ = w.Write(data)
		_ = w.WriteByte('\n')
	}
	w.Flush()
	f.Close()

	indexPath := filepath.Join(dir, "ranking-index")
	ms := &MotwSearch{JsonlPath: jsonlPath, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}

	searcher := &MotwSearch{IndexPath: indexPath}

	t.Run("TitleOutranksTagOnly", func(t *testing.T) {
		q := SearchQuery{Field: FieldTitle, Text: "network"}
		got, _, err := searcher.Search(context.Background(), q, SearchOptions{SortMode: SortRelevance})
		if err != nil {
			t.Fatal(err)
		}

		for _, b := range got {
			t.Logf("  %s (score=%.4f, lastMod=%s)", b.Title, b.SearchScore, b.LastModified)
		}
		if len(got) < 2 {
			t.Fatalf("expected at least 2 matches, got %d", len(got))
		}
	})

	t.Run("RankedPlusLimit", func(t *testing.T) {
		q := SearchQuery{Field: FieldTitle, Text: "network"}
		all, _, err := searcher.Search(context.Background(), q, SearchOptions{SortMode: SortRelevance})
		if err != nil {
			t.Fatal(err)
		}
		limited, _, err := searcher.Search(context.Background(), q, SearchOptions{SortMode: SortRelevance, Limit: 1})
		if err != nil {
			t.Fatal(err)
		}

		if len(limited) < 1 {
			t.Fatalf("ranked+limit=1: got %d results", len(limited))
		}

		if len(all) > 0 && len(limited) > 0 {
			if all[0].UUID != limited[0].UUID {
				t.Fatalf("ranked+limit: first result differs: %s vs %s", all[0].UUID, limited[0].UUID)
			}
		}
	})

	t.Run("UnrankedReturnsByLastModified", func(t *testing.T) {
		q := SearchQuery{Field: FieldTitle, Text: "network"}
		got, _, err := searcher.Search(context.Background(), q, SearchOptions{})
		if err != nil {
			t.Fatal(err)
		}

		for i := 1; i < len(got); i++ {
			if got[i].LastModified < got[i-1].LastModified {
				t.Fatalf("unranked results not in LastModified order at index %d: %s < %s",
					i, got[i].LastModified, got[i-1].LastModified)
			}
		}
	})
}

func TestSearchCorruptIndex(t *testing.T) {
	dir := t.TempDir()
	indexPath := filepath.Join(dir, "corrupt-index")

	t.Run("truncated", func(t *testing.T) {

		if err := os.WriteFile(indexPath+".zst", []byte("MWSC\x01"), 0o644); err != nil {
			t.Fatal(err)
		}
		ms := &MotwSearch{IndexPath: indexPath}
		_, _, err := ms.Search(context.Background(), SearchQuery{Field: FieldTitle, Text: "test"}, SearchOptions{})
		if err == nil {
			t.Fatal("expected error for truncated index, got nil")
		}
	})

	t.Run("bad_magic", func(t *testing.T) {

		if err := os.WriteFile(indexPath+".zst", []byte("BAAD\x01"+strings.Repeat("\x00", 40)), 0o644); err != nil {
			t.Fatal(err)
		}
		ms := &MotwSearch{IndexPath: indexPath}
		_, _, err := ms.Search(context.Background(), SearchQuery{Field: FieldTitle, Text: "test"}, SearchOptions{})
		if err == nil {
			t.Fatal("expected error for bad magic, got nil")
		}
		if !strings.Contains(err.Error(), "not an MWSC container") {
			t.Fatalf("expected 'not an MWSC container' error, got: %v", err)
		}
	})
}

func TestContainerAndManifestValidation(t *testing.T) {
	t.Run("bad_container_magic", func(t *testing.T) {
		dir := t.TempDir()
		fpath := filepath.Join(dir, "bad-magic.zst")
		if err := os.WriteFile(fpath, []byte("XXXX\x01"+strings.Repeat("\x00", 20)), 0o644); err != nil {
			t.Fatal(err)
		}
		f, _ := os.Open(fpath)
		defer f.Close()
		_, _, err := readContainerHeader(f)
		if err == nil {
			t.Fatal("expected error for bad magic")
		}
		if !strings.Contains(err.Error(), "not an MWSC container") {
			t.Fatalf("expected 'not an MWSC container' error, got: %v", err)
		}
	})

	t.Run("bad_container_version", func(t *testing.T) {
		dir := t.TempDir()
		fpath := filepath.Join(dir, "bad-version.zst")
		if err := os.WriteFile(fpath, []byte("MWSC\x99"+strings.Repeat("\x00", 20)), 0o644); err != nil {
			t.Fatal(err)
		}
		f, _ := os.Open(fpath)
		defer f.Close()
		_, _, err := readContainerHeader(f)
		if err == nil {
			t.Fatal("expected error for bad version")
		}
		if !strings.Contains(err.Error(), "unsupported container version") {
			t.Fatalf("expected 'unsupported container version' error, got: %v", err)
		}
	})

	t.Run("bad_manifest_magic", func(t *testing.T) {

		mr := &mockReader{
			data: []byte{0x00, 0x00, 0x00, 0x00, 0xDE, 0xAD, 0xBE, 0xEF},
		}
		_, err := readManifestFromDecoder(mr)
		if err == nil {
			t.Fatal("expected error for bad manifest magic")
		}
		if !strings.Contains(err.Error(), "bad manifest magic") {
			t.Fatalf("expected 'bad manifest magic' error, got: %v", err)
		}
	})

	t.Run("manifest_chunksize_zero", func(t *testing.T) {

		mf := Manifest{
			FormatTag:   manifestFormatTag,
			ChunkSize:   0,
			NumSegments: 1,
			NumBooks:    1,
			Regions:     []ManifestRegion{{}},
		}
		payload, _ := encodeManifest(mf)
		var buf bytes.Buffer
		buf.Write(payload)
		_ = binary.Write(&buf, binary.LittleEndian, uint32(len(payload)))
		_ = binary.Write(&buf, binary.LittleEndian, manifestMagic)

		mr := &mockReader{data: buf.Bytes()}
		_, err := readManifestFromDecoder(mr)
		if err == nil {
			t.Fatal("expected error for ChunkSize=0")
		}
		if !strings.Contains(err.Error(), "ChunkSize=0") {
			t.Fatalf("expected 'ChunkSize=0' error, got: %v", err)
		}
	})

	t.Run("manifest_no_regions", func(t *testing.T) {
		mf := Manifest{
			FormatTag: manifestFormatTag,
			ChunkSize: 262144,
		}
		payload, _ := encodeManifest(mf)
		var buf bytes.Buffer
		buf.Write(payload)
		_ = binary.Write(&buf, binary.LittleEndian, uint32(len(payload)))
		_ = binary.Write(&buf, binary.LittleEndian, manifestMagic)

		mr := &mockReader{data: buf.Bytes()}
		_, err := readManifestFromDecoder(mr)
		if err == nil {
			t.Fatal("expected error for no regions")
		}
		if !strings.Contains(err.Error(), "no regions") {
			t.Fatalf("expected 'no regions' error, got: %v", err)
		}
	})
}

func TestSearchColumnarSizeReduction(t *testing.T) {

	for _, n := range []int{50, 200, 500} {
		t.Run(fmt.Sprintf("n=%d", n), func(t *testing.T) {
			path := seedJSONL(t, n)
			f, err := os.Open(path)
			if err != nil {
				t.Fatal(err)
			}
			defer f.Close()

			var searchTotal, displayTotal int
			scanner := bufio.NewScanner(f)
			scanner.Buffer(make([]byte, 1<<20), 1<<20)
			for scanner.Scan() {
				var book Book
				if err := json.Unmarshal(scanner.Bytes(), &book); err != nil {
					t.Fatal(err)
				}

				sData, _ := json.Marshal(buildSearchableLine(book, false))
				searchTotal += len(sData) + 1

				dData, _ := json.Marshal(book)
				displayTotal += len(dData) + 1
			}
			if err := scanner.Err(); err != nil {
				t.Fatal(err)
			}

			ratio := float64(searchTotal) / float64(displayTotal)
			t.Logf("n=%d: search=%d bytes, display=%d bytes, ratio=%.2f", n, searchTotal, displayTotal, ratio)

			if ratio >= 0.35 {
				t.Errorf("searchable column ratio %.2f >= 0.35 threshold (search=%d, display=%d)",
					ratio, searchTotal, displayTotal)
			}
		})
	}
}

type mockReader struct {
	data []byte
	size int64
}

func (m *mockReader) ReadAt(p []byte, off int64) (int, error) {
	if off >= int64(len(m.data)) {
		return 0, fmt.Errorf("offset %d beyond data length %d", off, len(m.data))
	}
	n := copy(p, m.data[off:])
	return n, nil
}

func (m *mockReader) Size() int64 {
	if m.size > 0 {
		return m.size
	}
	return int64(len(m.data))
}

func TestBuildIndexFST(t *testing.T) {
	path := seedJSONL(t, 50)
	ms := &MotwSearch{JsonlPath: path}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}

	if len(idx.FSTBytes) != 0 {
		t.Fatalf("expected no postings FST (ca-113), got %d bytes", len(idx.FSTBytes))
	}

	entries, err := decodePostingsMeta(idx.PostingsMeta)
	if err != nil {
		t.Fatalf("decodePostingsMeta: %v", err)
	}
	key := postingsMetaKey(FieldTitle, "art")
	i := sort.Search(len(entries), func(j int) bool {
		return postingsMetaKey(entries[j].Field, entries[j].Term) >= key
	})
	if i >= len(entries) || postingsMetaKey(entries[i].Field, entries[i].Term) != key {
		t.Fatalf("expected key %q in postings entries", key)
	}
	t.Logf("postings entry for %q at index %d (%d entries, %d books)", key, i, len(entries), idx.NumBooks)
}

func TestSearchPrefix(t *testing.T) {
	path := seedJSONL(t, 100)
	dir := filepath.Dir(path)
	indexPath := filepath.Join(dir, "prefix-test-index")

	ms := &MotwSearch{JsonlPath: path, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}

	searcher := &MotwSearch{IndexPath: indexPath}

	q := SearchQuery{Field: FieldTitle, Text: "ar", Mode: ModePrefix}
	results, stats, err := searcher.Search(context.Background(), q, SearchOptions{})
	if err != nil {
		t.Fatalf("prefix search: %v", err)
	}
	if len(results) == 0 {
		t.Fatal("prefix search title:ar* returned 0 results, expected at least 1")
	}
	t.Logf("prefix title:ar*: %d results, %d scanned, %d postings narrowed",
		len(results), stats.BooksScanned, stats.PostingsNarrowed)

	for _, b := range results {
		toks := normalizeAndTokenize(b.Title)
		found := false
		for _, tok := range toks {
			if strings.HasPrefix(tok, "ar") {
				found = true
				break
			}
		}
		if !found {
			t.Errorf("book %q has no title token starting with 'ar' (tokens: %v)", b.Title, toks)
		}
	}
}

func TestSearchFuzzy(t *testing.T) {
	dir := t.TempDir()
	jsonlPath := filepath.Join(dir, "fuzzy.jsonl")
	f, err := os.Create(jsonlPath)
	if err != nil {
		t.Fatal(err)
	}

	books := []Book{
		{Title: "How to Edit Text", Authors: []string{"Alice"}, Tags: []string{"tech"}, LastModified: "2024-01-01T00:00:00+00:00", LibraryUUID: "test", Librarian: "test", UUID: "b1"},
		{Title: "Edith Wharton Stories", Authors: []string{"Bob"}, Tags: []string{"fiction"}, LastModified: "2024-01-02T00:00:00+00:00", LibraryUUID: "test", Librarian: "test", UUID: "b2"},
		{Title: "The Editor Manual", Authors: []string{"Carol"}, Tags: []string{"tech"}, LastModified: "2024-01-03T00:00:00+00:00", LibraryUUID: "test", Librarian: "test", UUID: "b3"},
		{Title: "Unrelated Book About Nothing", Authors: []string{"Dave"}, Tags: []string{"misc"}, LastModified: "2024-01-04T00:00:00+00:00", LibraryUUID: "test", Librarian: "test", UUID: "b4"},
	}

	for i := 0; i < 20; i++ {
		books = append(books, Book{
			Title: fmt.Sprintf("Padding Book %d", i), Authors: []string{"Nobody"}, Tags: []string{"padding"},
			LastModified: "2022-01-01T00:00:00+00:00", LibraryUUID: "test", Librarian: "test", UUID: fmt.Sprintf("pad-%d", i),
		})
	}

	w := bufio.NewWriter(f)
	for _, b := range books {
		data, _ := json.Marshal(b)
		_, _ = w.Write(data)
		_ = w.WriteByte('\n')
	}
	w.Flush()
	f.Close()

	indexPath := filepath.Join(dir, "fuzzy-index")
	ms := &MotwSearch{JsonlPath: jsonlPath, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}

	searcher := &MotwSearch{IndexPath: indexPath}

	t.Run("Distance1", func(t *testing.T) {

		q := SearchQuery{Field: FieldTitle, Text: "edit", Mode: ModeFuzzy, FuzzyDistance: 1}
		results, _, err := searcher.Search(context.Background(), q, SearchOptions{})
		if err != nil {
			t.Fatalf("fuzzy search d=1: %v", err)
		}
		titles := make([]string, len(results))
		for i, r := range results {
			titles[i] = r.Title
		}
		t.Logf("fuzzy title:edit~ (d=1): %v", titles)

		if len(results) < 1 {
			t.Fatalf("expected at least 1 result, got %d", len(results))
		}
	})

	t.Run("Distance2", func(t *testing.T) {

		q := SearchQuery{Field: FieldTitle, Text: "edit", Mode: ModeFuzzy, FuzzyDistance: 2}
		results, _, err := searcher.Search(context.Background(), q, SearchOptions{})
		if err != nil {
			t.Fatalf("fuzzy search d=2: %v", err)
		}
		titles := make([]string, len(results))
		for i, r := range results {
			titles[i] = r.Title
		}
		t.Logf("fuzzy title:edit~2 (d=2): %v", titles)

		if len(results) < 1 {
			t.Fatalf("expected at least 1 result, got %d", len(results))
		}
	})
}

func TestSearchPrefixRanked(t *testing.T) {
	path := seedJSONL(t, 100)
	dir := filepath.Dir(path)
	indexPath := filepath.Join(dir, "prefix-ranked-index")

	ms := &MotwSearch{JsonlPath: path, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}

	searcher := &MotwSearch{IndexPath: indexPath}

	q := SearchQuery{Field: FieldTitle, Text: "th", Mode: ModePrefix}
	results, _, err := searcher.Search(context.Background(), q, SearchOptions{SortMode: SortRelevance})
	if err != nil {
		t.Fatal(err)
	}
	if len(results) == 0 {
		t.Fatal("prefix ranked search returned 0 results")
	}

	for i, r := range results {
		if r.SearchScore == 0 {
			t.Errorf("result[%d] %q has zero score", i, r.Title)
		}
		if i > 0 && r.SearchScore > results[i-1].SearchScore {
			t.Errorf("results not sorted by score: [%d]=%f > [%d]=%f",
				i, r.SearchScore, i-1, results[i-1].SearchScore)
		}
	}
	t.Logf("prefix ranked title:th*: %d results, top score=%.4f", len(results), results[0].SearchScore)
}

func TestSortModeResolve(t *testing.T) {
	tests := []struct {
		name string
		opts SearchOptions
		want SortMode
	}{
		{"default_zero_value", SearchOptions{}, SortOldest},
		{"explicit_newest", SearchOptions{SortMode: SortNewest}, SortNewest},
		{"explicit_none", SearchOptions{SortMode: SortNone}, SortNone},
		{"explicit_oldest", SearchOptions{SortMode: SortOldest}, SortOldest},
		{"explicit_relevance", SearchOptions{SortMode: SortRelevance}, SortRelevance},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			got := tc.opts.ResolvedSortMode()
			if got != tc.want {
				t.Errorf("ResolvedSortMode() = %v, want %v", got, tc.want)
			}
		})
	}
}

func TestParseSortMode(t *testing.T) {
	tests := []struct {
		input   string
		want    SortMode
		wantErr bool
	}{
		{"relevance", SortRelevance, false},
		{"newest", SortNewest, false},
		{"oldest", SortOldest, false},
		{"none", SortNone, false},
		{"", SortDefault, false},
		{"RELEVANCE", SortRelevance, false},
		{" Newest ", SortNewest, false},
		{"invalid", SortDefault, true},
	}
	for _, tc := range tests {
		t.Run(tc.input, func(t *testing.T) {
			got, err := ParseSortMode(tc.input)
			if (err != nil) != tc.wantErr {
				t.Errorf("ParseSortMode(%q) error = %v, wantErr %v", tc.input, err, tc.wantErr)
			}
			if got != tc.want {
				t.Errorf("ParseSortMode(%q) = %v, want %v", tc.input, got, tc.want)
			}
		})
	}
}

func TestSearchSortNewest(t *testing.T) {
	path := seedJSONL(t, 100)
	dir := filepath.Dir(path)
	indexPath := filepath.Join(dir, "sort-newest-index")

	ms := &MotwSearch{JsonlPath: path, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}

	searcher := &MotwSearch{IndexPath: indexPath}
	q := SearchQuery{Field: FieldTitle, Text: "th", Mode: ModePrefix}
	results, _, err := searcher.Search(context.Background(), q, SearchOptions{SortMode: SortNewest})
	if err != nil {
		t.Fatal(err)
	}
	if len(results) < 2 {
		t.Fatalf("expected at least 2 results, got %d", len(results))
	}

	for i := 1; i < len(results); i++ {
		if results[i].LastModified > results[i-1].LastModified {
			t.Fatalf("results not in newest-first order at index %d: %s > %s",
				i, results[i].LastModified, results[i-1].LastModified)
		}
	}

	for i, r := range results {
		if r.SearchScore != 0 {
			t.Errorf("result[%d] has non-zero score %.4f in SortNewest mode", i, r.SearchScore)
		}
	}
	t.Logf("SortNewest title:th*: %d results", len(results))
}

func TestSearchSortOldest(t *testing.T) {
	path := seedJSONL(t, 100)
	dir := filepath.Dir(path)
	indexPath := filepath.Join(dir, "sort-oldest-index")

	ms := &MotwSearch{JsonlPath: path, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}

	searcher := &MotwSearch{IndexPath: indexPath}
	q := SearchQuery{Field: FieldTitle, Text: "th", Mode: ModePrefix}
	results, _, err := searcher.Search(context.Background(), q, SearchOptions{SortMode: SortOldest})
	if err != nil {
		t.Fatal(err)
	}
	if len(results) < 2 {
		t.Fatalf("expected at least 2 results, got %d", len(results))
	}

	for i := 1; i < len(results); i++ {
		if results[i].LastModified < results[i-1].LastModified {
			t.Fatalf("results not in oldest-first order at index %d: %s < %s",
				i, results[i].LastModified, results[i-1].LastModified)
		}
	}
	t.Logf("SortOldest title:th*: %d results", len(results))
}

func TestSearchSortNone(t *testing.T) {
	path := seedJSONL(t, 100)
	dir := filepath.Dir(path)
	indexPath := filepath.Join(dir, "sort-none-index")

	ms := &MotwSearch{JsonlPath: path, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}

	searcher := &MotwSearch{IndexPath: indexPath}
	q := SearchQuery{Field: FieldTitle, Text: "th", Mode: ModePrefix}
	noneResults, _, err := searcher.Search(context.Background(), q, SearchOptions{SortMode: SortNone})
	if err != nil {
		t.Fatal(err)
	}
	if len(noneResults) < 2 {
		t.Fatalf("SortNone returned %d results, need >=2 to test ordering", len(noneResults))
	}
	for i, r := range noneResults {
		if r.SearchScore != 0 {
			t.Errorf("result[%d] has non-zero score %.4f in SortNone mode", i, r.SearchScore)
		}
	}

	newestResults, _, err := searcher.Search(context.Background(), q, SearchOptions{SortMode: SortNewest})
	if err != nil {
		t.Fatal(err)
	}
	if len(noneResults) != len(newestResults) {
		t.Fatalf("SortNone count (%d) != SortNewest count (%d) — should match", len(noneResults), len(newestResults))
	}

	noneSet := make(map[string]struct{}, len(noneResults))
	for _, r := range noneResults {
		noneSet[r.UUID] = struct{}{}
	}
	for _, r := range newestResults {
		if _, ok := noneSet[r.UUID]; !ok {
			t.Fatalf("SortNewest has UUID %q not in SortNone set", r.UUID)
		}
	}

	differs := false
	for i := range noneResults {
		if noneResults[i].UUID != newestResults[i].UUID {
			differs = true
			break
		}
	}
	if !differs {
		t.Fatal("SortNone order matches SortNewest order — a sort appears to have been applied")
	}
	t.Logf("SortNone title:th*: %d results (set-equal to SortNewest, order differs)", len(noneResults))
}

func TestSearchMultiRegionPrefix(t *testing.T) {
	dir := t.TempDir()

	baseBooks := []*Book{
		{Title: "Walter Benjamin Essays", Authors: []string{"Walter Benjamin"}, Tags: []string{"philosophy"}, Id: "00000000-0000-4000-8000-000000000000", LastModified: "2024-01-01T00:00:00+00:00", Librarian: "test", LibraryUUID: "test"},
		{Title: "Walter Pater Studies", Authors: []string{"Walter Pater"}, Tags: []string{"criticism"}, Id: "00000000-0000-4000-8000-000000000001", LastModified: "2024-01-02T00:00:00+00:00", Librarian: "test", LibraryUUID: "test"},
	}

	for i := 0; i < 20; i++ {
		baseBooks = append(baseBooks, &Book{
			Title: fmt.Sprintf("Base Filler %d", i), Authors: []string{"Nobody"}, Tags: []string{"filler"},
			Id: fmt.Sprintf("00000000-0000-4000-8000-0000base%04d", i), LastModified: "2022-01-01T00:00:00+00:00", Librarian: "test", LibraryUUID: "test",
		})
	}

	basePath := writeBooksJSONL(t, baseBooks, dir, "base.jsonl")
	indexPath := filepath.Join(dir, "multi-prefix-idx")
	ms := &MotwSearch{JsonlPath: basePath, IndexPath: indexPath}
	baseIdx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(baseIdx); err != nil {
		t.Fatal(err)
	}

	deltaBooks := []*Book{
		{Title: "Walton Family Chronicles", Authors: []string{"Sam Walton"}, Tags: []string{"biography"}, Id: "00000000-0000-4000-8000-000delta00000", LastModified: "2024-06-01T00:00:00+00:00", Librarian: "test", LibraryUUID: "test"},
	}
	for i := 0; i < 20; i++ {
		deltaBooks = append(deltaBooks, &Book{
			Title: fmt.Sprintf("Delta Filler %d", i), Authors: []string{"Nobody"}, Tags: []string{"filler"},
			Id: fmt.Sprintf("00000000-0000-4000-8000-00delta2%04d", i), LastModified: "2022-06-01T00:00:00+00:00", Librarian: "test", LibraryUUID: "test",
		})
	}
	deltaPath := writeBooksJSONL(t, deltaBooks, dir, "delta.jsonl")
	msDelta := &MotwSearch{JsonlPath: deltaPath, IndexPath: indexPath}
	deltaIdx, err := msDelta.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := msDelta.AppendToFile(deltaIdx, nil); err != nil {
		t.Fatal(err)
	}

	searcher := &MotwSearch{IndexPath: indexPath}

	q := SearchQuery{Field: FieldTitle, Text: "walt", Mode: ModePrefix}
	results, _, err := searcher.Search(context.Background(), q, SearchOptions{})
	if err != nil {
		t.Fatal(err)
	}
	if len(results) != 3 {
		titles := make([]string, len(results))
		for i, r := range results {
			titles[i] = r.Title
		}
		t.Fatalf("prefix title:walt* across 2 regions: expected 3 results, got %d: %v", len(results), titles)
	}
	t.Logf("prefix title:walt* across 2 regions: %d results ✓", len(results))
}

func TestTypeaheadInContainer(t *testing.T) {
	path := seedJSONL(t, 50)
	dir := filepath.Dir(path)
	indexPath := filepath.Join(dir, "typeahead-container-test")

	ms := &MotwSearch{JsonlPath: path, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}

	sidecarPath := indexPath + ".typeahead.fst"
	if _, err := os.Stat(sidecarPath); !os.IsNotExist(err) {
		t.Fatalf("sidecar file should not exist, but got err=%v", err)
	}

	f, err := os.Open(indexPath + ".zst")
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()

	rdr, dec, mf, err := openMWSC(f)
	if err != nil {
		t.Fatal(err)
	}
	defer rdr.Close()
	defer dec.Close()

	if mf.TypeaheadLen == 0 {
		t.Fatal("TypeaheadLen is 0 — typeahead section missing from container")
	}
	t.Logf("TypeaheadOff=%d TypeaheadLen=%d", mf.TypeaheadOff, mf.TypeaheadLen)

	taBytes := make([]byte, mf.TypeaheadLen)
	if _, err := rdr.ReadAt(taBytes, int64(mf.TypeaheadOff)); err != nil {
		t.Fatalf("ReadAt typeahead: %v", err)
	}

	d, err := parseSortedDict(taBytes)
	if err != nil {
		t.Fatalf("parseSortedDict: %v", err)
	}

	ta := &vellumTypeaheadIndex{dicts: []*sortedTermDict{d}}
	suggs, err := ta.Suggest(FieldTitle, "art", 10)
	if err != nil {
		t.Fatalf("Suggest: %v", err)
	}
	foundEntity := false
	for _, sg := range suggs {
		if sg.Entity != "" && strings.Contains(strings.ToLower(sg.Entity), "art") {
			foundEntity = true
			if sg.Weight == 0 {
				t.Errorf("expected non-zero df for entity %q", sg.Entity)
			}
			t.Logf("entity=%q token=%q df=%d ✓", sg.Entity, sg.Term, sg.Weight)
		}
	}
	if !foundEntity {
		t.Fatalf("expected a full-entity suggestion containing 'art' for prefix 'art'; got %+v", suggs)
	}
}

func TestLoadTypeaheadCached_FreshCache(t *testing.T) {
	path := seedJSONL(t, 50)
	dir := filepath.Dir(path)
	indexPath := filepath.Join(dir, "cache-fresh-test")
	cacheDir := filepath.Join(dir, "fst-cache")

	ms := &MotwSearch{JsonlPath: path, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}

	ta, err := ms.LoadTypeaheadCached(cacheDir)
	if err != nil {
		t.Fatalf("LoadTypeaheadCached: %v", err)
	}
	defer ta.Close()

	results, err := ta.Suggest(FieldTitle, "art", 1)
	if err != nil {
		t.Fatalf("Suggest: %v", err)
	}
	if len(results) == 0 {
		t.Fatal("expected at least one suggestion for prefix 'art'")
	}
	if results[0].Term != "art" {
		t.Fatalf("expected term 'art', got %q", results[0].Term)
	}

	entries, err := os.ReadDir(cacheDir)
	if err != nil {
		t.Fatalf("read cache dir: %v", err)
	}
	if len(entries) == 0 {
		t.Fatal("expected a typeahead cache file to be written")
	}
}

func TestLoadTypeaheadCached_WarmCache(t *testing.T) {
	path := seedJSONL(t, 50)
	dir := filepath.Dir(path)
	indexPath := filepath.Join(dir, "cache-warm-test")
	cacheDir := filepath.Join(dir, "fst-cache")

	ms := &MotwSearch{JsonlPath: path, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}

	ta1, err := ms.LoadTypeaheadCached(cacheDir)
	if err != nil {
		t.Fatal(err)
	}
	ta1.Close()

	ta2, err := ms.LoadTypeaheadCached(cacheDir)
	if err != nil {
		t.Fatal(err)
	}
	defer ta2.Close()

	results, err := ta2.Suggest(FieldTitle, "art", 1)
	if err != nil {
		t.Fatalf("Suggest: %v", err)
	}
	if len(results) == 0 {
		t.Fatal("expected suggestion from the second load")
	}
}

func TestLoadTypeaheadCached_GenerationChange(t *testing.T) {
	path := seedJSONL(t, 50)
	dir := filepath.Dir(path)
	indexPath := filepath.Join(dir, "cache-gen-test")
	cacheDir := filepath.Join(dir, "fst-cache")

	ms := &MotwSearch{JsonlPath: path, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}

	ta1, err := ms.LoadTypeaheadCached(cacheDir)
	if err != nil {
		t.Fatal(err)
	}
	ta1.Close()

	idx2, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx2); err != nil {
		t.Fatal(err)
	}

	ta2, err := ms.LoadTypeaheadCached(cacheDir)
	if err != nil {
		t.Fatal(err)
	}
	defer ta2.Close()

	results, err := ta2.Suggest(FieldTitle, "art", 1)
	if err != nil {
		t.Fatalf("Suggest: %v", err)
	}
	if len(results) == 0 {
		t.Fatal("expected suggestion after rebuild")
	}
}

func TestTypeaheadIndex_SuggestAny(t *testing.T) {
	path := seedJSONL(t, 50)
	dir := filepath.Dir(path)
	indexPath := filepath.Join(dir, "suggest-any-test")
	cacheDir := filepath.Join(dir, "fst-cache")

	ms := &MotwSearch{JsonlPath: path, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}

	ta, err := ms.LoadTypeaheadCached(cacheDir)
	if err != nil {
		t.Fatal(err)
	}
	defer ta.Close()

	results, err := ta.SuggestAny("art", 10)
	if err != nil {
		t.Fatalf("SuggestAny: %v", err)
	}
	if len(results) == 0 {
		t.Fatal("expected at least one suggestion from SuggestAny")
	}

	for i := 1; i < len(results); i++ {
		if results[i].Weight > results[i-1].Weight {
			t.Fatalf("results not Weight-descending at index %d: %d > %d",
				i, results[i].Weight, results[i-1].Weight)
		}
	}

	hasField := false
	for _, r := range results {
		if r.Field != "" {
			hasField = true
			break
		}
	}
	if !hasField {
		t.Fatal("expected at least one result with a non-empty Field")
	}
	t.Logf("SuggestAny: %d results, Weight-descending ✓", len(results))
}

func TestTypeaheadIndex_EdgeCases(t *testing.T) {
	path := seedJSONL(t, 50)
	dir := filepath.Dir(path)
	indexPath := filepath.Join(dir, "edge-cases-test")
	cacheDir := filepath.Join(dir, "fst-cache")

	ms := &MotwSearch{JsonlPath: path, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}

	ta, err := ms.LoadTypeaheadCached(cacheDir)
	if err != nil {
		t.Fatal(err)
	}
	defer ta.Close()

	allResults, err := ta.Suggest(FieldTitle, "art", 0)
	if err != nil {
		t.Fatalf("Suggest(limit=0): %v", err)
	}
	if len(allResults) == 0 {
		t.Fatal("expected results with limit=0 (unlimited)")
	}
	t.Logf("Suggest(limit=0): %d results ✓", len(allResults))

	allField, err := ta.Suggest(FieldTitle, "", 5)
	if err != nil {
		t.Fatalf("Suggest(prefix=\"\"): %v", err)
	}
	if len(allField) == 0 {
		t.Fatal("expected results with empty prefix")
	}
	for _, r := range allField {
		if r.Field != FieldTitle {
			t.Fatalf("expected field %q, got %q", FieldTitle, r.Field)
		}
	}
	t.Logf("Suggest(prefix=\"\"): %d results, all FieldTitle ✓", len(allField))

	allAny, err := ta.SuggestAny("", 0)
	if err != nil {
		t.Fatalf("SuggestAny(prefix=\"\", limit=0): %v", err)
	}
	if len(allAny) == 0 {
		t.Fatal("expected results from SuggestAny with empty prefix")
	}
	t.Logf("SuggestAny(prefix=\"\", limit=0): %d results ✓", len(allAny))

	bogus, err := ta.Suggest(SearchField("bogus"), "", 5)
	if err != nil {
		t.Fatalf("Suggest(bogus field): expected nil error, got %v", err)
	}
	if len(bogus) != 0 {
		t.Fatalf("expected empty result for bogus field, got %d", len(bogus))
	}
	t.Logf("Suggest(bogus field): empty result, nil error ✓")
}

func TestOpenedSearch_ReuseHandle(t *testing.T) {
	path := seedJSONL(t, 50)
	dir := filepath.Dir(path)
	indexPath := filepath.Join(dir, "opened-reuse-test")

	ms := &MotwSearch{JsonlPath: path, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}

	opened, err := ms.Open()
	if err != nil {
		t.Fatal(err)
	}
	defer opened.Close()

	q := SearchQuery{Field: FieldTitle, Text: "art", Mode: ModeExact}
	opts := SearchOptions{}

	books1, stats1, err := opened.Search(context.Background(), q, opts)
	if err != nil {
		t.Fatalf("first Search: %v", err)
	}

	books2, stats2, err := opened.Search(context.Background(), q, opts)
	if err != nil {
		t.Fatalf("second Search: %v", err)
	}

	if len(books1) != len(books2) {
		t.Fatalf("result count mismatch: first=%d, second=%d", len(books1), len(books2))
	}
	if stats1.BooksMatched != stats2.BooksMatched {
		t.Fatalf("stats mismatch: first matched=%d, second matched=%d",
			stats1.BooksMatched, stats2.BooksMatched)
	}
	t.Logf("OpenedSearch reuse: %d results on both calls ✓", len(books1))
}

func TestSuggestEntities_DiacriticsAndMultiWord(t *testing.T) {
	dir := t.TempDir()
	jsonlPath := filepath.Join(dir, "books.jsonl")
	f, err := os.Create(jsonlPath)
	if err != nil {
		t.Fatal(err)
	}
	books := []Book{
		{Title: "Restitution", Authors: []string{"Ante Lešaja"}, Tags: []string{"history"}, LastModified: "2024-01-01T00:00:00+00:00", LibraryUUID: "L", Librarian: "lib", UUID: "u1"},
		{Title: "Participatory Culture", Authors: []string{"Antero Garcia"}, Tags: []string{"media"}, LastModified: "2024-01-02T00:00:00+00:00", LibraryUUID: "L", Librarian: "lib", UUID: "u2"},
		{Title: "Capital", Authors: []string{"Karl Marx"}, Tags: []string{"economics"}, LastModified: "2024-01-03T00:00:00+00:00", LibraryUUID: "L", Librarian: "lib", UUID: "u3"},
	}
	for i := range books {
		data, _ := json.Marshal(books[i])
		f.Write(data)
		f.Write([]byte{'\n'})
	}
	f.Close()

	indexPath := filepath.Join(dir, "idx")
	ms := &MotwSearch{JsonlPath: jsonlPath, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}
	opened, err := ms.Open()
	if err != nil {
		t.Fatal(err)
	}
	defer opened.Close()
	ta, err := opened.Typeahead(filepath.Join(dir, "cache"))
	if err != nil {
		t.Fatal(err)
	}
	defer ta.Close()

	has := func(query string) bool {
		ents, err := SuggestEntities(ta, FieldAuthor, query, 20)
		if err != nil {
			t.Fatalf("SuggestEntities(%q): %v", query, err)
		}
		for _, e := range ents {
			if e == "Ante Lešaja" {
				return true
			}
		}
		return false
	}
	for _, q := range []string{"ante l", "ante lešaja", "Ante Lešaja", "leš", "ante", "lesaj"} {
		if !has(q) {
			t.Errorf("query %q did not surface 'Ante Lešaja'", q)
		}
	}

	if has("ante xyz") {
		t.Errorf("query 'ante xyz' wrongly surfaced 'Ante Lešaja'")
	}
}

func TestSuggestEntities_UnstemmedPrefix(t *testing.T) {
	dir := t.TempDir()
	jsonlPath := filepath.Join(dir, "books.jsonl")
	f, err := os.Create(jsonlPath)
	if err != nil {
		t.Fatal(err)
	}
	books := []Book{
		{Title: "Running Commentary", Authors: []string{"Donna Programming"}, Tags: []string{"x"}, LastModified: "2024-01-01T00:00:00+00:00", LibraryUUID: "L", Librarian: "lib", UUID: "u1"},
	}
	for i := range books {
		d, _ := json.Marshal(books[i])
		f.Write(d)
		f.Write([]byte{'\n'})
	}
	f.Close()

	indexPath := filepath.Join(dir, "idx")
	ms := &MotwSearch{JsonlPath: jsonlPath, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}
	opened, err := ms.Open()
	if err != nil {
		t.Fatal(err)
	}
	defer opened.Close()
	ta, err := opened.Typeahead(filepath.Join(dir, "cache"))
	if err != nil {
		t.Fatal(err)
	}
	defer ta.Close()

	cases := []struct{ field, q, want string }{
		{"title", "runn", "Running Commentary"},
		{"title", "running", "Running Commentary"},
		{"author", "programm", "Donna Programming"},
	}
	for _, c := range cases {
		ents, err := SuggestEntities(ta, SearchField(c.field), c.q, 10)
		if err != nil {
			t.Fatalf("SuggestEntities(%q): %v", c.q, err)
		}
		found := false
		for _, e := range ents {
			if e == c.want {
				found = true
			}
		}
		if !found {
			t.Errorf("query %q did not surface %q (got %v)", c.q, c.want, ents)
		}
	}
}

type fuzzyCountingTA struct {
	TypeaheadIndex
	fuzzyCalls int
}

func (f *fuzzyCountingTA) SuggestFuzzy(field SearchField, token string, distance uint8, limit int) ([]Suggestion, error) {
	f.fuzzyCalls++
	return f.TypeaheadIndex.SuggestFuzzy(field, token, distance, limit)
}

func TestSuggestEntities_FuzzyFallback(t *testing.T) {
	dir := t.TempDir()
	jsonlPath := filepath.Join(dir, "books.jsonl")
	f, err := os.Create(jsonlPath)
	if err != nil {
		t.Fatal(err)
	}
	books := []Book{
		{Title: "Democracy and Other Neoliberal Fantasies", Authors: []string{"Jodi Dean"}, Tags: []string{"politics"}, LastModified: "2024-01-01T00:00:00+00:00", LibraryUUID: "L", Librarian: "lib", UUID: "u1"},
		{Title: "Represent and Destroy", Authors: []string{"Jodi Melamed"}, Tags: []string{"culture"}, LastModified: "2024-01-02T00:00:00+00:00", LibraryUUID: "L", Librarian: "lib", UUID: "u2"},
		{Title: "Field Notes", Authors: []string{"Jode Miller"}, Tags: []string{"notes"}, LastModified: "2024-01-03T00:00:00+00:00", LibraryUUID: "L", Librarian: "lib", UUID: "u3"},
		{Title: "Other Book", Authors: []string{"Dean Smith"}, Tags: []string{"misc"}, LastModified: "2024-01-04T00:00:00+00:00", LibraryUUID: "L", Librarian: "lib", UUID: "u4"},
	}
	for i := range books {
		d, _ := json.Marshal(books[i])
		f.Write(d)
		f.Write([]byte{'\n'})
	}
	f.Close()

	indexPath := filepath.Join(dir, "idx")
	ms := &MotwSearch{JsonlPath: jsonlPath, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}
	opened, err := ms.Open()
	if err != nil {
		t.Fatal(err)
	}
	defer opened.Close()
	ta, err := opened.Typeahead(filepath.Join(dir, "cache"))
	if err != nil {
		t.Fatal(err)
	}
	defer ta.Close()

	suggest := func(field SearchField, q string, limit int) []string {
		t.Helper()
		ents, err := SuggestEntities(ta, field, q, limit)
		if err != nil {
			t.Fatalf("SuggestEntities(%q): %v", q, err)
		}
		return ents
	}
	has := func(ents []string, want string) bool {
		for _, e := range ents {
			if e == want {
				return true
			}
		}
		return false
	}

	for _, q := range []string{
		"jody dean",
		"jody",
		"jodi deen",
		"jody deen",
	} {
		if ents := suggest(FieldAuthor, q, 10); !has(ents, "Jodi Dean") {
			t.Errorf("query %q did not surface 'Jodi Dean' (got %v)", q, ents)
		}
	}

	if ents := suggest("", "jody", 10); !has(ents, "Jodi Dean") {
		t.Errorf("field==\"\" query 'jody' did not surface 'Jodi Dean' (got %v)", ents)
	}

	if ents := suggest(FieldAuthor, "joy", 10); len(ents) != 0 {
		t.Errorf("short query 'joy' should return nothing (got %v)", ents)
	}

	if ents := suggest(FieldAuthor, "jodyx", 10); len(ents) != 0 {
		t.Errorf("distance-2 query 'jodyx' should return nothing (got %v)", ents)
	}

	ents := suggest(FieldAuthor, "jodi", 2)
	if len(ents) != 2 {
		t.Fatalf("query 'jodi' limit 2: got %d entities (%v), want 2", len(ents), ents)
	}
	for _, e := range ents {
		if e != "Jodi Dean" && e != "Jodi Melamed" {
			t.Errorf("exact pass filled the limit but returned non-exact entity %q (want only Jodi Dean / Jodi Melamed)", e)
		}
	}

	counting := &fuzzyCountingTA{TypeaheadIndex: ta}
	ents, err = SuggestEntities(counting, FieldAuthor, "xyzq dean", 10)
	if err != nil {
		t.Fatalf("SuggestEntities('xyzq dean'): %v", err)
	}
	if len(ents) != 0 {
		t.Errorf("query 'xyzq dean' should return nothing (got %v)", ents)
	}
	if counting.fuzzyCalls != 1 {
		t.Errorf("expected exactly 1 SuggestFuzzy call for 'xyzq dean' (0-hit fall-through), got %d", counting.fuzzyCalls)
	}

	counting.fuzzyCalls = 0
	ents, err = SuggestEntities(counting, FieldAuthor, "jodi deen", 10)
	if err != nil {
		t.Fatalf("SuggestEntities('jodi deen'): %v", err)
	}
	if !has(ents, "Jodi Dean") {
		t.Errorf("counting wrapper: 'jodi deen' did not surface 'Jodi Dean' (got %v)", ents)
	}
	if counting.fuzzyCalls != 1 {
		t.Errorf("expected exactly 1 SuggestFuzzy call for 'jodi deen', got %d", counting.fuzzyCalls)
	}
}

func TestSuggestEntities_FuzzyFallback_AnchorCollision(t *testing.T) {
	dir := t.TempDir()
	jsonlPath := filepath.Join(dir, "books.jsonl")
	f, err := os.Create(jsonlPath)
	if err != nil {
		t.Fatal(err)
	}
	books := []Book{
		{Title: "Democracy and Other Neoliberal Fantasies", Authors: []string{"Jodi Dean"}, Tags: []string{"politics"}, LastModified: "2024-01-01T00:00:00+00:00", LibraryUUID: "L", Librarian: "lib", UUID: "u1"},
		{Title: "North of Empire", Authors: []string{"Jody Berland"}, Tags: []string{"culture"}, LastModified: "2024-01-02T00:00:00+00:00", LibraryUUID: "L", Librarian: "lib", UUID: "u2"},
		{Title: "Deep Time", Authors: []string{"Jody Azzouni"}, Tags: []string{"philosophy"}, LastModified: "2024-01-03T00:00:00+00:00", LibraryUUID: "L", Librarian: "lib", UUID: "u3"},
	}
	for i := range books {
		d, _ := json.Marshal(books[i])
		f.Write(d)
		f.Write([]byte{'\n'})
	}
	f.Close()

	indexPath := filepath.Join(dir, "idx")
	ms := &MotwSearch{JsonlPath: jsonlPath, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}
	opened, err := ms.Open()
	if err != nil {
		t.Fatal(err)
	}
	defer opened.Close()
	ta, err := opened.Typeahead(filepath.Join(dir, "cache"))
	if err != nil {
		t.Fatal(err)
	}
	defer ta.Close()

	ents, err := SuggestEntities(ta, FieldAuthor, "jody de", 10)
	if err != nil {
		t.Fatal(err)
	}
	found := false
	for _, e := range ents {
		if e == "Jodi Dean" {
			found = true
		}
	}
	if !found {
		t.Errorf("'jody de' did not surface 'Jodi Dean' (got %v)", ents)
	}

	counting := &fuzzyCountingTA{TypeaheadIndex: ta}
	ents, err = SuggestEntities(counting, FieldAuthor, "jody", 10)
	if err != nil {
		t.Fatal(err)
	}
	if len(ents) == 0 || counting.fuzzyCalls != 0 {
		t.Errorf("'jody' exact pass: got %v (fuzzyCalls=%d), want the Jody-authors with no fuzzy call", ents, counting.fuzzyCalls)
	}
	for _, e := range ents {
		if e == "Jodi Dean" || e == "Jodi Melamed" {
			t.Errorf("'jody' exact pass polluted by fuzzy candidate %q", e)
		}
	}
}

func TestOpenedSearch_Typeahead(t *testing.T) {
	path := seedJSONL(t, 50)
	dir := filepath.Dir(path)
	indexPath := filepath.Join(dir, "opened-typeahead-test")
	cacheDir := filepath.Join(dir, "fst-cache")

	ms := &MotwSearch{JsonlPath: path, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}

	opened, err := ms.Open()
	if err != nil {
		t.Fatal(err)
	}
	defer opened.Close()

	ta, err := opened.Typeahead(cacheDir)
	if err != nil {
		t.Fatalf("Typeahead: %v", err)
	}
	defer ta.Close()

	results, err := ta.Suggest(FieldTitle, "art", 5)
	if err != nil {
		t.Fatalf("Suggest: %v", err)
	}
	if len(results) == 0 {
		t.Fatal("expected at least one suggestion")
	}
	if results[0].Term != "art" {
		t.Fatalf("expected term 'art', got %q", results[0].Term)
	}
	t.Logf("OpenedSearch.Typeahead: %d results ✓", len(results))
}

func TestV1ManifestRejected(t *testing.T) {

	mf := Manifest{
		FormatTag:   1,
		ChunkSize:   262144,
		NumSegments: 1,
		NumBooks:    1,
		Regions:     []ManifestRegion{{}},
	}

	var buf bytes.Buffer
	_ = binary.Write(&buf, binary.LittleEndian, uint32(1))
	_ = binary.Write(&buf, binary.LittleEndian, mf.ChunkSize)
	_ = binary.Write(&buf, binary.LittleEndian, mf.NumSegments)
	_ = binary.Write(&buf, binary.LittleEndian, mf.NumBooks)
	buf.Write(mf.BaseGeneration[:])
	_ = binary.Write(&buf, binary.LittleEndian, mf.Generation)
	_ = binary.Write(&buf, binary.LittleEndian, uint32(1))

	for i := 0; i < 14; i++ {
		_ = binary.Write(&buf, binary.LittleEndian, uint64(0))
	}
	_ = binary.Write(&buf, binary.LittleEndian, uint32(0))

	_, err := decodeManifest(buf.Bytes())
	if err == nil {
		t.Fatal("expected error decoding v1 manifest, got nil")
	}
	if !strings.Contains(err.Error(), "built for tag 1") {
		t.Fatalf("expected 'built for tag 1' format-mismatch error, got: %v", err)
	}
	if !strings.Contains(err.Error(), "rebuild with:") {
		t.Fatalf("expected rebuild guidance in error, got: %v", err)
	}
	t.Logf("v1 manifest rejection message: %v", err)
}

func TestV2ManifestRejected(t *testing.T) {

	var buf bytes.Buffer
	_ = binary.Write(&buf, binary.LittleEndian, uint32(2))
	_ = binary.Write(&buf, binary.LittleEndian, uint32(262144))
	_ = binary.Write(&buf, binary.LittleEndian, uint32(1))
	_ = binary.Write(&buf, binary.LittleEndian, uint32(1))
	buf.Write(make([]byte, 16))
	_ = binary.Write(&buf, binary.LittleEndian, uint64(0))
	_ = binary.Write(&buf, binary.LittleEndian, uint64(0))
	_ = binary.Write(&buf, binary.LittleEndian, uint64(0))
	_ = binary.Write(&buf, binary.LittleEndian, uint32(1))

	for i := 0; i < 16; i++ {
		_ = binary.Write(&buf, binary.LittleEndian, uint64(0))
	}
	_ = binary.Write(&buf, binary.LittleEndian, uint32(0))

	_, err := decodeManifest(buf.Bytes())
	if err == nil {
		t.Fatal("expected error decoding v2 manifest, got nil")
	}
	if !strings.Contains(err.Error(), "built for tag 2") {
		t.Fatalf("expected 'built for tag 2' format-mismatch error, got: %v", err)
	}
	if !strings.Contains(err.Error(), "rebuild with:") {
		t.Fatalf("expected rebuild guidance in error, got: %v", err)
	}
	t.Logf("v2 manifest rejection message: %v", err)
}

func TestBookMatchMinHeapSortModes(t *testing.T) {

	tests := []struct {
		name     string
		sortMode SortMode
		items    []bookMatch

		wantLastModified []int64
		wantScores       []float64
	}{
		{
			name:     "SortNewest keeps highest timestamps",
			sortMode: SortNewest,
			items: []bookMatch{
				{lastModified: 100},
				{lastModified: 300},
				{lastModified: 200},
				{lastModified: 400},
			},
			wantLastModified: []int64{400, 300},
		},
		{
			name:     "SortOldest keeps lowest timestamps",
			sortMode: SortOldest,
			items: []bookMatch{
				{lastModified: 400},
				{lastModified: 200},
				{lastModified: 300},
				{lastModified: 100},
			},
			wantLastModified: []int64{100, 200},
		},
		{
			name:     "SortRelevance keeps highest scores",
			sortMode: SortRelevance,
			items: []bookMatch{
				{score: 1.0},
				{score: 3.0},
				{score: 2.0},
				{score: 4.0},
			},
			wantScores: []float64{4.0, 3.0},
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			h := bookMatchMinHeap{sortMode: tc.sortMode}
			capK := 2
			for _, bm := range tc.items {
				if h.Len() < capK {
					heap.Push(&h, bm)
				} else if h.beats(bm) {
					h.items[0] = bm
					heap.Fix(&h, 0)
				}
			}

			result := make([]bookMatch, h.Len())
			for i := len(result) - 1; i >= 0; i-- {
				result[i] = heap.Pop(&h).(bookMatch)
			}
			if len(result) != capK {
				t.Fatalf("expected %d results, got %d", capK, len(result))
			}
			if tc.sortMode == SortRelevance {
				for i, want := range tc.wantScores {
					if result[i].score != want {
						t.Errorf("result[%d].score = %v, want %v", i, result[i].score, want)
					}
				}
			} else {
				for i, want := range tc.wantLastModified {
					if result[i].lastModified != want {
						t.Errorf("result[%d].lastModified = %v, want %v", i, result[i].lastModified, want)
					}
				}
			}
		})
	}
}

func BenchmarkSearchIndexBuild(b *testing.B) {
	path := seedJSONL(b, 20000)
	dir := filepath.Dir(path)

	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		indexPath := filepath.Join(dir, fmt.Sprintf("bench-index-%d", i))
		ms := &MotwSearch{JsonlPath: path, IndexPath: indexPath}
		idx, err := ms.BuildIndex()
		if err != nil {
			b.Fatal(err)
		}
		if err := ms.CompressToFile(idx); err != nil {
			b.Fatal(err)
		}

		if info, err := os.Stat(indexPath + ".zst"); err == nil {
			b.ReportMetric(float64(info.Size()), "zst-bytes")
		}
	}
}

func BenchmarkSearch(b *testing.B) {
	path := seedJSONL(b, 5000)
	dir := filepath.Dir(path)
	indexPath := filepath.Join(dir, "bench-search-index")

	ms := &MotwSearch{JsonlPath: path, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		b.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		b.Fatal(err)
	}

	searcher := &MotwSearch{IndexPath: indexPath}

	benchmarks := []struct {
		name  string
		query SearchQuery
	}{
		{"Broad", SearchQuery{Field: FieldTitle, Text: "the"}},
		{"Medium", SearchQuery{Field: FieldAuthor, Text: "Thomas"}},
		{"Selective", SearchQuery{Field: FieldTag, Text: "decolonization"}},
	}

	for _, bm := range benchmarks {
		b.Run(bm.name, func(b *testing.B) {
			for i := 0; i < b.N; i++ {
				_, stats, err := searcher.Search(context.Background(), bm.query, SearchOptions{})
				if err != nil {
					b.Fatal(err)
				}
				b.ReportMetric(float64(stats.ClustersRead), "clusters")
				b.ReportMetric(float64(stats.BytesDecompressed), "decompress-bytes")
				b.ReportMetric(float64(stats.BooksMatched), "matched")
			}
		})
	}
}

func BenchmarkSearchChunkSize(b *testing.B) {
	path := seedJSONL(b, 5000)
	dir := filepath.Dir(path)

	chunkSizes := []int{64 << 10, 128 << 10, 256 << 10, 512 << 10, 1024 << 10}
	query := SearchQuery{Field: FieldTitle, Text: "the"}

	for _, cs := range chunkSizes {
		b.Run(fmt.Sprintf("chunk-%dK", cs/1024), func(b *testing.B) {
			indexPath := filepath.Join(dir, fmt.Sprintf("bench-chunk-%d", cs))

			ms := &MotwSearch{JsonlPath: path, IndexPath: indexPath, ChunkSize: cs}
			idx, err := ms.BuildIndex()
			if err != nil {
				b.Fatal(err)
			}
			if err := ms.CompressToFile(idx); err != nil {
				b.Fatal(err)
			}

			searcher := &MotwSearch{IndexPath: indexPath}
			b.ResetTimer()

			for i := 0; i < b.N; i++ {
				_, stats, err := searcher.Search(context.Background(), query, SearchOptions{})
				if err != nil {
					b.Fatal(err)
				}
				b.ReportMetric(float64(stats.ClustersRead), "clusters")
				b.ReportMetric(float64(stats.BytesDecompressed), "decompress-bytes")
				b.ReportMetric(float64(stats.BooksMatched), "matched")
			}
		})
	}
}

func BenchmarkSearchIndexSize(b *testing.B) {
	path := seedJSONL(b, 5000)
	dir := filepath.Dir(path)

	for i := 0; i < b.N; i++ {
		indexPath := filepath.Join(dir, fmt.Sprintf("bench-size-%d", i))
		ms := &MotwSearch{JsonlPath: path, IndexPath: indexPath}
		idx, err := ms.BuildIndex()
		if err != nil {
			b.Fatal(err)
		}
		if err := ms.CompressToFile(idx); err != nil {
			b.Fatal(err)
		}
		if info, err := os.Stat(indexPath + ".zst"); err == nil {
			b.ReportMetric(float64(info.Size()), "zst-bytes")
			b.ReportMetric(float64(idx.NumSegments), "segments")
		}
	}
}

func TestSearchMultiRegionDuplicatedRegion(t *testing.T) {

	path := seedJSONL(t, 32)
	dir := filepath.Dir(path)
	indexPath := filepath.Join(dir, "multi-region-test")

	ms := &MotwSearch{JsonlPath: path, IndexPath: indexPath}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}

	singleResults, _, err := ms.Search(context.Background(), SearchQuery{Field: FieldTitle, Text: "programming"}, SearchOptions{})
	if err != nil {
		t.Fatalf("single-region search failed: %v", err)
	}
	t.Logf("single-region search: %d results", len(singleResults))

	zstPath := indexPath + ".zst"
	origData, err := os.ReadFile(zstPath)
	if err != nil {
		t.Fatal(err)
	}

	f, err := os.Open(zstPath)
	if err != nil {
		t.Fatal(err)
	}
	dictCatalog, seekableOff, err := readContainerHeader(f)
	f.Close()
	if err != nil {
		t.Fatal(err)
	}

	var decOpts []zstd.DOption
	for _, entry := range dictCatalog {
		decOpts = append(decOpts, zstd.WithDecoderDictRaw(entry.DictID, entry.DictBytes))
	}
	dec, err := zstd.NewReader(nil, decOpts...)
	if err != nil {
		t.Fatal(err)
	}
	defer dec.Close()

	seekableData := origData[seekableOff:]
	sr := io.NewSectionReader(bytes.NewReader(seekableData), 0, int64(len(seekableData)))
	rdr, err := newMWSCReaderAt(sr, int64(len(seekableData)), dec)
	if err != nil {
		t.Fatal(err)
	}

	origMf, err := readManifestFromDecoder(rdr)
	rdr.Close()
	if err != nil {
		t.Fatal(err)
	}
	if len(origMf.Regions) != 1 {
		t.Fatalf("expected 1 region in base, got %d", len(origMf.Regions))
	}

	multiMf := origMf
	multiMf.Generation = 1
	fakeRegion := origMf.Regions[0]
	multiMf.Regions = append(multiMf.Regions, fakeRegion)
	multiMf.NumSegments += origMf.NumSegments
	multiMf.NumBooks += origMf.NumBooks

	multiPayload, err := encodeManifest(multiMf)
	if err != nil {
		t.Fatal(err)
	}

	totalSize := rdr.Size()
	sr2 := io.NewSectionReader(bytes.NewReader(seekableData), 0, int64(len(seekableData)))
	rdr2, err := newMWSCReaderAt(sr2, int64(len(seekableData)), dec)
	if err != nil {
		t.Fatal(err)
	}

	footerBuf := make([]byte, 8)
	if _, err := rdr2.ReadAt(footerBuf, totalSize-8); err != nil {
		t.Fatal(err)
	}
	origMfLen := binary.LittleEndian.Uint32(footerBuf[:4])
	dataEnd := totalSize - 8 - int64(origMfLen)

	dataBefore := make([]byte, dataEnd)
	if _, err := rdr2.ReadAt(dataBefore, 0); err != nil && err != io.EOF {
		t.Fatal(err)
	}
	rdr2.Close()

	tmpFile, err := os.CreateTemp(t.TempDir(), "multi-region-*.zst")
	if err != nil {
		t.Fatal(err)
	}

	catSize := dictCatalogSize(dictCatalog)
	_, _ = tmpFile.Write([]byte(containerMagic))
	_, _ = tmpFile.Write([]byte{containerVersion})
	_ = binary.Write(tmpFile, binary.LittleEndian, catSize)
	_ = writeDictCatalog(tmpFile, dictCatalog)

	var encOpts []zstd.EOption
	encOpts = append(encOpts, zstd.WithEncoderLevel(zstd.SpeedBestCompression))
	for _, entry := range dictCatalog {
		encOpts = append(encOpts, zstd.WithEncoderDictRaw(entry.DictID, entry.DictBytes))
	}
	var combined bytes.Buffer
	combined.Write(dataBefore)
	combined.Write(multiPayload)
	_ = binary.Write(&combined, binary.LittleEndian, uint32(len(multiPayload)))
	_ = binary.Write(&combined, binary.LittleEndian, manifestMagic)

	stream := handRolledSeekableStream(t, encOpts, 256<<10, seekTableEntrySizeCksm, combined.Bytes())
	if _, err := tmpFile.Write(stream); err != nil {
		t.Fatal(err)
	}
	tmpFile.Close()

	tamperedData, err := os.ReadFile(tmpFile.Name())
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(zstPath, tamperedData, 0o644); err != nil {
		t.Fatal(err)
	}

	multiResults, _, err := ms.Search(context.Background(), SearchQuery{Field: FieldTitle, Text: "programming"}, SearchOptions{})
	if err != nil {
		t.Fatalf("multi-region search failed: %v", err)
	}
	if len(multiResults) != len(singleResults)*2 {
		t.Fatalf("expected %d results from 2 duplicated regions, got %d", len(singleResults)*2, len(multiResults))
	}
	t.Logf("multi-region search (duplicated): %d results (2x single=%d)", len(multiResults), len(singleResults))

	f2, _ := os.Open(zstPath)
	defer f2.Close()
	_, seekOff2, _ := readContainerHeader(f2)
	fSize2, _ := f2.Seek(0, io.SeekEnd)
	sr3 := io.NewSectionReader(f2, seekOff2, fSize2-seekOff2)
	rdr3, err := newMWSCReaderAt(sr3, fSize2-seekOff2, dec)
	if err != nil {
		t.Fatalf("reopen tampered container: %v", err)
	}
	defer rdr3.Close()
	readMf, err := readManifestFromDecoder(rdr3)
	if err != nil {
		t.Fatalf("failed to read tampered manifest: %v", err)
	}
	if len(readMf.Regions) != 2 {
		t.Fatalf("expected 2 regions, got %d", len(readMf.Regions))
	}
	if readMf.Generation != 1 {
		t.Fatalf("expected generation 1, got %d", readMf.Generation)
	}
	t.Logf("tampered manifest verified: regions=%d, generation=%d", len(readMf.Regions), readMf.Generation)
}

func seedBooksWithID(n int, prefix string) []*Book {
	titles := []string{
		"The Art of Programming",
		"Discourse Networks, 1800/1900",
		"A Brief History of Time",
		"Capital in the Twenty-First Century",
		"Critique of Pure Reason",
		"Being and Nothingness",
		"The Structure of Scientific Revolutions",
		"Phenomenology of Spirit",
		"One-Dimensional Man",
		"The Wretched of the Earth",
	}
	authors := [][]string{
		{"Donald Knuth"},
		{"Friedrich Kittler"},
		{"Stephen Hawking"},
		{"Thomas Piketty"},
		{"Immanuel Kant"},
		{"Jean-Paul Sartre"},
		{"Thomas Kuhn"},
		{"Georg Wilhelm Friedrich Hegel"},
		{"Herbert Marcuse"},
		{"Frantz Fanon"},
	}
	tags := [][]string{
		{"computer science", "algorithms"},
		{"media theory", "german literature"},
		{"physics", "cosmology"},
		{"economics", "inequality"},
		{"philosophy", "epistemology"},
		{"philosophy", "existentialism"},
		{"philosophy", "science"},
		{"philosophy", "idealism"},
		{"philosophy", "critical theory"},
		{"politics", "decolonization"},
	}

	books := make([]*Book, n)
	for i := 0; i < n; i++ {
		idx := i % len(titles)

		id := fmt.Sprintf("00000000-0000-4000-8000-%s%08d", prefix, i)
		books[i] = &Book{
			Title:        titles[idx],
			Authors:      authors[idx],
			Tags:         tags[idx],
			Id:           id,
			LastModified: fmt.Sprintf("2024-01-%02dT00:00:00+00:00", (i%28)+1),
			LibraryUUID:  "test-lib-uuid",
			Librarian:    "testlib",
		}
	}
	return books
}

func booksToJSONLReader(books []*Book) *bytes.Reader {
	var buf bytes.Buffer
	for _, b := range books {
		data, _ := json.Marshal(b)
		buf.Write(data)
		buf.WriteByte('\n')
	}
	return bytes.NewReader(buf.Bytes())
}

func TestDiffBooks(t *testing.T) {
	t.Run("no_changes", func(t *testing.T) {
		books := seedBooksWithID(10, "0000")
		existing := booksToJSONLReader(books)
		delta, tombstones, err := DiffBooks(books, existing)
		if err != nil {
			t.Fatal(err)
		}
		if len(delta) != 0 {
			t.Fatalf("expected 0 delta, got %d", len(delta))
		}
		if len(tombstones) != 0 {
			t.Fatalf("expected 0 tombstones, got %d", len(tombstones))
		}
	})

	t.Run("additions_only", func(t *testing.T) {
		existing := seedBooksWithID(10, "0000")

		current := make([]*Book, len(existing))
		copy(current, existing)
		newBooks := seedBooksWithID(5, "0001")
		current = append(current, newBooks...)

		delta, tombstones, err := DiffBooks(current, booksToJSONLReader(existing))
		if err != nil {
			t.Fatal(err)
		}
		if len(delta) != 5 {
			t.Fatalf("expected 5 delta, got %d", len(delta))
		}
		if len(tombstones) != 0 {
			t.Fatalf("expected 0 tombstones, got %d", len(tombstones))
		}
	})

	t.Run("deletions_only", func(t *testing.T) {
		existing := seedBooksWithID(10, "0000")

		current := existing[:7]

		delta, tombstones, err := DiffBooks(current, booksToJSONLReader(existing))
		if err != nil {
			t.Fatal(err)
		}
		if len(delta) != 0 {
			t.Fatalf("expected 0 delta, got %d", len(delta))
		}
		if len(tombstones) != 3 {
			t.Fatalf("expected 3 tombstones, got %d", len(tombstones))
		}
	})

	t.Run("mixed_additions_and_deletions", func(t *testing.T) {
		existing := seedBooksWithID(10, "0000")

		current := make([]*Book, 6)
		copy(current, existing[:6])
		newBooks := seedBooksWithID(4, "0002")
		current = append(current, newBooks...)

		delta, tombstones, err := DiffBooks(current, booksToJSONLReader(existing))
		if err != nil {
			t.Fatal(err)
		}
		if len(delta) != 4 {
			t.Fatalf("expected 4 delta (added), got %d", len(delta))
		}
		if len(tombstones) != 4 {
			t.Fatalf("expected 4 tombstones (deleted), got %d", len(tombstones))
		}
	})
}

func writeBooksJSONL(tb testing.TB, books []*Book, dir string, name string) string {
	tb.Helper()
	path := filepath.Join(dir, name)
	f, err := os.Create(path)
	if err != nil {
		tb.Fatal(err)
	}
	defer f.Close()
	w := bufio.NewWriter(f)
	defer w.Flush()
	for _, b := range books {
		data, err := json.Marshal(b)
		if err != nil {
			tb.Fatal(err)
		}
		_, _ = w.Write(data)
		_ = w.WriteByte('\n')
	}
	return path
}

func TestAppendToFile(t *testing.T) {
	dir := t.TempDir()

	baseBooks := seedBooksWithID(32, "0000")
	basePath := writeBooksJSONL(t, baseBooks, dir, "base.jsonl")
	indexPath := filepath.Join(dir, "testidx")
	ms := &MotwSearch{JsonlPath: basePath, IndexPath: indexPath}
	baseIdx, err := ms.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex base: %v", err)
	}
	if err := ms.CompressToFile(baseIdx); err != nil {
		t.Fatalf("CompressToFile base: %v", err)
	}

	deltaBooks := seedBooksWithID(8, "0001")
	deltaPath := writeBooksJSONL(t, deltaBooks, dir, "delta.jsonl")
	msDelta := &MotwSearch{JsonlPath: deltaPath, IndexPath: indexPath}
	deltaIdx, err := msDelta.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex delta: %v", err)
	}

	if err := msDelta.AppendToFile(deltaIdx, nil); err != nil {
		t.Fatalf("AppendToFile: %v", err)
	}

	f, err := os.Open(indexPath + ".zst")
	if err != nil {
		t.Fatal(err)
	}
	defer f.Close()

	dictCatalog, seekOff, err := readContainerHeader(f)
	if err != nil {
		t.Fatal(err)
	}
	var decOpts []zstd.DOption
	for _, entry := range dictCatalog {
		decOpts = append(decOpts, zstd.WithDecoderDictRaw(entry.DictID, entry.DictBytes))
	}
	dec, err := zstd.NewReader(nil, decOpts...)
	if err != nil {
		t.Fatal(err)
	}
	defer dec.Close()

	fileSize, _ := f.Seek(0, io.SeekEnd)
	sr := io.NewSectionReader(f, seekOff, fileSize-seekOff)
	rdr, err := newMWSCReaderAt(sr, fileSize-seekOff, dec)
	if err != nil {
		t.Fatalf("seekable reader: %v", err)
	}
	defer rdr.Close()

	mf, err := readManifestFromDecoder(rdr)
	if err != nil {
		t.Fatalf("readManifest: %v", err)
	}

	if len(mf.Regions) != 2 {
		t.Fatalf("expected 2 regions, got %d", len(mf.Regions))
	}
	if mf.Generation != 1 {
		t.Fatalf("expected generation 1, got %d", mf.Generation)
	}
	if mf.NumBooks != 40 {
		t.Fatalf("expected 40 total books, got %d", mf.NumBooks)
	}

	t.Logf("AppendToFile verified: regions=%d generation=%d numBooks=%d numSegments=%d",
		len(mf.Regions), mf.Generation, mf.NumBooks, mf.NumSegments)
}

func TestSearchMultiRegion(t *testing.T) {
	dir := t.TempDir()

	baseBooks := []*Book{
		{Title: "Quantum Mechanics", Authors: []string{"Alice"}, Tags: []string{"physics"}, Id: "00000000-0000-4000-8000-000000000000", LastModified: "2024-01-01T00:00:00+00:00", Librarian: "testlib", LibraryUUID: "test-lib"},
		{Title: "Quantum Field Theory", Authors: []string{"Alice"}, Tags: []string{"physics"}, Id: "00000000-0000-4000-8000-000000000001", LastModified: "2024-01-02T00:00:00+00:00", Librarian: "testlib", LibraryUUID: "test-lib"},
		{Title: "Quantum Computing", Authors: []string{"Alice"}, Tags: []string{"computer science"}, Id: "00000000-0000-4000-8000-000000000002", LastModified: "2024-01-03T00:00:00+00:00", Librarian: "testlib", LibraryUUID: "test-lib"},
		{Title: "Being and Time", Authors: []string{"Bob"}, Tags: []string{"philosophy"}, Id: "00000000-0000-4000-8000-000000000003", LastModified: "2024-01-04T00:00:00+00:00", Librarian: "testlib", LibraryUUID: "test-lib"},
		{Title: "Being and Nothingness", Authors: []string{"Bob"}, Tags: []string{"philosophy"}, Id: "00000000-0000-4000-8000-000000000004", LastModified: "2024-01-05T00:00:00+00:00", Librarian: "testlib", LibraryUUID: "test-lib"},
		{Title: "Being and Event", Authors: []string{"Bob"}, Tags: []string{"philosophy"}, Id: "00000000-0000-4000-8000-000000000005", LastModified: "2024-01-06T00:00:00+00:00", Librarian: "testlib", LibraryUUID: "test-lib"},
		{Title: "Capital Volume I", Authors: []string{"Carol"}, Tags: []string{"economics"}, Id: "00000000-0000-4000-8000-000000000006", LastModified: "2024-01-07T00:00:00+00:00", Librarian: "testlib", LibraryUUID: "test-lib"},
		{Title: "Capital Volume II", Authors: []string{"Carol"}, Tags: []string{"economics"}, Id: "00000000-0000-4000-8000-000000000007", LastModified: "2024-01-08T00:00:00+00:00", Librarian: "testlib", LibraryUUID: "test-lib"},
		{Title: "Capital Volume III", Authors: []string{"Carol"}, Tags: []string{"economics"}, Id: "00000000-0000-4000-8000-000000000008", LastModified: "2024-01-09T00:00:00+00:00", Librarian: "testlib", LibraryUUID: "test-lib"},
	}

	basePath := writeBooksJSONL(t, baseBooks, dir, "base.jsonl")
	indexPath := filepath.Join(dir, "testidx")
	ms := &MotwSearch{JsonlPath: basePath, IndexPath: indexPath}
	baseIdx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(baseIdx); err != nil {
		t.Fatal(err)
	}

	deltaBooks := []*Book{
		{Title: "Discipline and Punish", Authors: []string{"Dave"}, Tags: []string{"philosophy"}, Id: "00000000-0000-4000-8000-000000000009", LastModified: "2024-01-10T00:00:00+00:00", Librarian: "testlib", LibraryUUID: "test-lib"},
		{Title: "Empire of Signs", Authors: []string{"Eve"}, Tags: []string{"semiotics"}, Id: "00000000-0000-4000-8000-000000000010", LastModified: "2024-01-11T00:00:00+00:00", Librarian: "testlib", LibraryUUID: "test-lib"},
	}
	deltaPath := writeBooksJSONL(t, deltaBooks, dir, "delta.jsonl")

	msDelta := &MotwSearch{JsonlPath: deltaPath, IndexPath: indexPath}
	deltaIdx, err := msDelta.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}

	ts, err := bookIDToTombstone("00000000-0000-4000-8000-000000000003")
	if err != nil {
		t.Fatal(err)
	}
	tombstones := [][16]byte{ts}

	if err := msDelta.AppendToFile(deltaIdx, tombstones); err != nil {
		t.Fatal(err)
	}

	results, _, err := ms.Search(context.Background(), SearchQuery{Field: FieldTitle, Text: "quantum"}, SearchOptions{})
	if err != nil {
		t.Fatalf("search quantum: %v", err)
	}
	if len(results) != 3 {
		t.Fatalf("search quantum: expected 3, got %d", len(results))
	}
	t.Logf("search quantum: %d results (from region 0)", len(results))

	results, _, err = ms.Search(context.Background(), SearchQuery{Field: FieldTitle, Text: "discipline"}, SearchOptions{})
	if err != nil {
		t.Fatalf("search discipline: %v", err)
	}
	if len(results) != 1 {
		t.Fatalf("search discipline: expected 1, got %d", len(results))
	}
	t.Logf("search discipline: %d results (from region 1)", len(results))

	results, _, err = ms.Search(context.Background(), SearchQuery{Field: FieldTitle, Text: "being"}, SearchOptions{})
	if err != nil {
		t.Fatalf("search being: %v", err)
	}
	if len(results) != 2 {
		t.Fatalf("search being: expected 2 (tombstoned 1), got %d", len(results))
	}
	for _, r := range results {
		if r.Id == "00000000-0000-4000-8000-000000000003" {
			t.Fatal("tombstoned book 'Being and Time' appeared in results")
		}
	}
	t.Logf("search being: %d results (tombstone exclusion correct)", len(results))

	results, _, err = ms.Search(context.Background(), SearchQuery{Field: FieldTitle, Text: "capital"}, SearchOptions{SortMode: SortRelevance})
	if err != nil {
		t.Fatalf("ranked search capital: %v", err)
	}
	if len(results) != 3 {
		t.Fatalf("ranked search capital: expected 3, got %d", len(results))
	}
	for i := 1; i < len(results); i++ {
		if results[i].SearchScore > results[i-1].SearchScore {
			t.Fatalf("ranked results not sorted: score[%d]=%f > score[%d]=%f",
				i, results[i].SearchScore, i-1, results[i-1].SearchScore)
		}
	}
	t.Logf("ranked search capital: %d results, scores sorted correctly", len(results))
}

func TestSearchMultiRegionBruteForceEquivalence(t *testing.T) {
	dir := t.TempDir()

	baseBooks := seedBooksWithID(32, "0000")
	basePath := writeBooksJSONL(t, baseBooks, dir, "base.jsonl")
	indexPath := filepath.Join(dir, "equiv-idx")
	ms := &MotwSearch{JsonlPath: basePath, IndexPath: indexPath}
	baseIdx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(baseIdx); err != nil {
		t.Fatal(err)
	}

	deltaBooks := seedBooksWithID(8, "0001")
	deltaPath := writeBooksJSONL(t, deltaBooks, dir, "delta.jsonl")

	var tombstones [][16]byte
	for i := 0; i < 4; i++ {
		ts, err := bookIDToTombstone(baseBooks[i].Id)
		if err != nil {
			t.Fatal(err)
		}
		tombstones = append(tombstones, ts)
	}

	msDelta := &MotwSearch{JsonlPath: deltaPath, IndexPath: indexPath}
	deltaIdx, err := msDelta.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := msDelta.AppendToFile(deltaIdx, tombstones); err != nil {
		t.Fatal(err)
	}

	tombstoneIDs := make(map[string]struct{})
	for i := 0; i < 4; i++ {
		tombstoneIDs[baseBooks[i].Id] = struct{}{}
	}
	var unionBooks []*Book
	for _, b := range baseBooks {
		if _, dead := tombstoneIDs[b.Id]; !dead {
			unionBooks = append(unionBooks, b)
		}
	}
	unionBooks = append(unionBooks, deltaBooks...)
	unionPath := writeBooksJSONL(t, unionBooks, dir, "union.jsonl")

	queries := []SearchQuery{
		{Field: FieldTitle, Text: "programming"},
		{Field: FieldTitle, Text: "critique"},
		{Field: FieldAuthor, Text: "knuth"},
		{Field: FieldTag, Text: "philosophy"},
		{Field: FieldTitle, Text: "art"},
	}

	for _, q := range queries {
		searchResults, _, err := ms.Search(context.Background(), q, SearchOptions{})
		if err != nil {
			t.Fatalf("search %s:%s: %v", q.Field, q.Text, err)
		}
		bfResults := bruteForce(t, unionPath, q)

		if len(searchResults) != len(bfResults) {
			t.Fatalf("search %s:%s: Search=%d brute-force=%d",
				q.Field, q.Text, len(searchResults), len(bfResults))
		}
		t.Logf("search %s:%s: Search=%d == brute-force=%d ✓",
			q.Field, q.Text, len(searchResults), len(bfResults))
	}
}

func TestV3ManifestRejected(t *testing.T) {

	var buf bytes.Buffer
	_ = binary.Write(&buf, binary.LittleEndian, uint32(3))
	_ = binary.Write(&buf, binary.LittleEndian, uint32(262144))
	_ = binary.Write(&buf, binary.LittleEndian, uint32(1))
	_ = binary.Write(&buf, binary.LittleEndian, uint32(1))
	buf.Write(make([]byte, 16))
	_ = binary.Write(&buf, binary.LittleEndian, uint64(0))
	_ = binary.Write(&buf, binary.LittleEndian, uint64(0))
	_ = binary.Write(&buf, binary.LittleEndian, uint64(0))
	_ = binary.Write(&buf, binary.LittleEndian, uint32(1))

	for i := 0; i < 16; i++ {
		_ = binary.Write(&buf, binary.LittleEndian, uint64(0))
	}
	_ = binary.Write(&buf, binary.LittleEndian, uint32(0))

	_, err := decodeManifest(buf.Bytes())
	if err == nil {
		t.Fatal("expected error decoding v3 manifest, got nil")
	}
	if !strings.Contains(err.Error(), "built for tag 3") {
		t.Fatalf("expected 'built for tag 3' format-mismatch error, got: %v", err)
	}
}

func seedJSONLWithFingerprints(tb testing.TB, n int) string {
	tb.Helper()
	dir := tb.TempDir()
	path := filepath.Join(dir, "books.jsonl")
	f, err := os.Create(path)
	if err != nil {
		tb.Fatal(err)
	}
	defer f.Close()

	w := bufio.NewWriter(f)
	defer w.Flush()

	for i := 0; i < n; i++ {
		book := Book{
			Title:        fmt.Sprintf("Book %d", i),
			Authors:      []string{fmt.Sprintf("Author %d", i)},
			Tags:         []string{"test"},
			LastModified: fmt.Sprintf("2024-01-%02dT00:00:00+00:00", (i%28)+1),
			LibraryUUID:  "test-lib-uuid",
			Librarian:    "testlib",
			UUID:         fmt.Sprintf("book-uuid-%d", i),
			Id:           fmt.Sprintf("fp-test-book-%d", i),
		}

		if i%2 == 0 {
			var fp [FingerprintSize]byte
			fp[0] = byte(i + 1)
			fp[1] = byte(i + 2)
			fp[2] = 0x42
			fp[3] = 0x55
			fp[4] = 0x10
			fp[5] = 0x20
			book.CoverFingerprint = EncodeFingerprintBase64(fp)
		}
		data, err := json.Marshal(book)
		if err != nil {
			tb.Fatal(err)
		}
		_, _ = w.Write(data)
		_ = w.WriteByte('\n')
	}
	return path
}

func TestFingerprintSectionRoundTrip(t *testing.T) {
	n := 100
	path := seedJSONLWithFingerprints(t, n)
	dir := filepath.Dir(path)
	indexPath := filepath.Join(dir, "test-index")

	ms := &MotwSearch{
		JsonlPath: path,
		IndexPath: indexPath,
	}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}

	expectedFpLen := n * FingerprintSize
	if len(idx.Fingerprints) != expectedFpLen {
		t.Fatalf("idx.Fingerprints length: got %d, want %d", len(idx.Fingerprints), expectedFpLen)
	}

	for i := 0; i < n; i++ {
		var fp [FingerprintSize]byte
		copy(fp[:], idx.Fingerprints[i*FingerprintSize:(i+1)*FingerprintSize])
		if i%2 == 0 {
			if IsZeroFingerprint(fp) {
				t.Fatalf("book %d: expected non-zero fingerprint, got zero", i)
			}
		} else {
			if !IsZeroFingerprint(fp) {
				t.Fatalf("book %d: expected zero fingerprint, got %v", i, fp)
			}
		}
	}

	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}

	mf, err := ReadExistingManifest(indexPath)
	if err != nil {
		t.Fatal(err)
	}

	if mf.FormatTag != manifestFormatTag {
		t.Fatalf("manifest format tag: got %d, want %d", mf.FormatTag, manifestFormatTag)
	}
	if len(mf.Regions) != 1 {
		t.Fatalf("region count: got %d, want 1", len(mf.Regions))
	}

	reg := mf.Regions[0]
	if reg.FingerprintsLen != uint64(expectedFpLen) {
		t.Fatalf("region.FingerprintsLen: got %d, want %d", reg.FingerprintsLen, expectedFpLen)
	}
	if reg.FingerprintsOff == 0 && reg.FingerprintsLen > 0 {
		t.Fatal("region.FingerprintsOff should be non-zero when section has content")
	}

	books, err := AllBooksFromIndex(indexPath)
	if err != nil {
		t.Fatal(err)
	}
	if len(books) != n {
		t.Fatalf("AllBooksFromIndex: got %d books, want %d", len(books), n)
	}
	for i, book := range books {
		if i%2 == 0 {
			if book.CoverFingerprint == "" {
				t.Fatalf("book %d: expected non-empty CoverFingerprint", i)
			}
			fp := DecodeFingerprintBase64(book.CoverFingerprint)
			if IsZeroFingerprint(fp) {
				t.Fatalf("book %d: decoded fingerprint is zero", i)
			}
		} else {
			if book.CoverFingerprint != "" {
				t.Fatalf("book %d: expected empty CoverFingerprint, got %q", i, book.CoverFingerprint)
			}
		}
	}
}

func TestFingerprintSectionRoundTripAppend(t *testing.T) {

	n := 50
	path := seedJSONLWithFingerprints(t, n)
	dir := filepath.Dir(path)
	indexPath := filepath.Join(dir, "test-index")

	ms := &MotwSearch{
		JsonlPath: path,
		IndexPath: indexPath,
	}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}

	deltaPath := seedJSONLWithFingerprints(t, 20)
	ms2 := &MotwSearch{
		JsonlPath: deltaPath,
		IndexPath: indexPath,
	}
	deltaIdx, err := ms2.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms2.AppendToFile(deltaIdx, nil); err != nil {
		t.Fatal(err)
	}

	mf, err := ReadExistingManifest(indexPath)
	if err != nil {
		t.Fatal(err)
	}
	if len(mf.Regions) != 2 {
		t.Fatalf("region count: got %d, want 2", len(mf.Regions))
	}

	for i, reg := range mf.Regions {
		if reg.FingerprintsLen == 0 {
			t.Fatalf("region %d: FingerprintsLen should be non-zero", i)
		}
	}
}

func TestStripHTML(t *testing.T) {
	tests := []struct {
		name   string
		input  string
		expect string
	}{
		{
			name:   "plain text passthrough",
			input:  "hello world",
			expect: "hello world",
		},
		{
			name:   "simple paragraph tags",
			input:  "<p>hello world</p>",
			expect: " hello world ",
		},
		{
			name:   "nested tags",
			input:  "<div><p>hello <b>world</b></p></div>",
			expect: "  hello  world   ",
		},
		{
			name:   "HTML entities ampersand",
			input:  "cats &amp; dogs",
			expect: "cats & dogs",
		},
		{
			name:   "HTML entities numeric",
			input:  "it&#39;s fine",
			expect: "it's fine",
		},
		{
			name:   "nbsp entity",
			input:  "word&nbsp;gap",
			expect: "word\u00a0gap",
		},
		{
			name:   "real Calibre comments HTML",
			input:  `<div><p>This book examines the role of <b>machine learning</b> in modern &amp; applied mathematics.</p></div>`,
			expect: "  This book examines the role of  machine learning  in modern & applied mathematics.  ",
		},
		{
			name:   "empty string",
			input:  "",
			expect: "",
		},
		{
			name:   "self-closing tags",
			input:  "line1<br/>line2",
			expect: "line1 line2",
		},
		{
			name:   "prose inequalities preserved (not treated as tags)",
			input:  "prove that a < b and c > d",
			expect: "prove that a < b and c > d",
		},
		{
			name:   "tag adjacent to inequality",
			input:  "<p>if a < b then x</p>",
			expect: " if a < b then x ",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := stripHTML(tt.input)
			if got != tt.expect {
				t.Errorf("stripHTML(%q) = %q, want %q", tt.input, got, tt.expect)
			}
		})
	}
}

func TestStripHTMLTokenization(t *testing.T) {

	html := `<div><p>This book examines <b>machine learning</b> &amp; neural networks.</p></div>`
	tokens := normalizeAndTokenize(stripHTML(html))
	expected := []string{"this", "book", "examin", "machin", "learn", "neural", "network"}
	if len(tokens) != len(expected) {
		t.Fatalf("got %d tokens %v, want %d tokens %v", len(tokens), tokens, len(expected), expected)
	}
	for i, tok := range tokens {
		if tok != expected[i] {
			t.Errorf("token[%d] = %q, want %q", i, tok, expected[i])
		}
	}
}

func seedJSONLWithDescriptions(tb testing.TB, n int) string {
	tb.Helper()
	dir := tb.TempDir()
	path := filepath.Join(dir, "books.jsonl")
	f, err := os.Create(path)
	if err != nil {
		tb.Fatal(err)
	}
	defer f.Close()

	w := bufio.NewWriter(f)
	defer w.Flush()

	titles := []string{
		"The Art of Programming",
		"Discourse Networks, 1800/1900",
		"A Brief History of Time",
		"Capital in the Twenty-First Century",
		"Critique of Pure Reason",
		"Being and Nothingness",
		"The Structure of Scientific Revolutions",
		"Phenomenology of Spirit",
		"One-Dimensional Man",
		"The Wretched of the Earth",
	}
	authors := [][]string{
		{"Donald Knuth"},
		{"Friedrich Kittler"},
		{"Stephen Hawking"},
		{"Thomas Piketty"},
		{"Immanuel Kant"},
		{"Jean-Paul Sartre"},
		{"Thomas Kuhn"},
		{"Georg Wilhelm Friedrich Hegel"},
		{"Herbert Marcuse"},
		{"Frantz Fanon"},
	}
	tags := [][]string{
		{"computer science", "algorithms"},
		{"media theory", "german literature"},
		{"physics", "cosmology"},
		{"economics", "inequality"},
		{"philosophy", "epistemology"},
		{"philosophy", "existentialism"},
		{"philosophy", "science"},
		{"philosophy", "idealism"},
		{"philosophy", "critical theory"},
		{"politics", "decolonization"},
	}
	descriptions := []string{
		`<div><p>A comprehensive study of <b>algorithms</b> and their analysis in computational complexity theory.</p></div>`,
		"",
		`<div><p>Explores <b>black holes</b>, the big bang, and the nature of spacetime &amp; quantum gravity.</p></div>`,
		"",
		`<div><p>An investigation into the limits of <b>human reason</b> and the foundations of metaphysics.</p></div>`,
		"",
		`<div><p>Examines the structure of <b>paradigm shifts</b> in scientific discovery and progress.</p></div>`,
		"",
		`<div><p>A critical analysis of <b>industrial society</b> and the repression of individual freedom.</p></div>`,
		"",
	}

	for i := 0; i < n; i++ {
		idx := i % len(titles)
		book := Book{
			Title:        titles[idx],
			Authors:      authors[idx],
			Tags:         tags[idx],
			LastModified: fmt.Sprintf("2024-01-%02dT00:00:00+00:00", (i%28)+1),
			LibraryUUID:  "test-lib-uuid",
			Librarian:    "testlib",
			UUID:         fmt.Sprintf("book-uuid-%d", i),
		}
		if descriptions[idx] != "" {
			book.Abstract = descriptions[idx]
		}
		data, err := json.Marshal(book)
		if err != nil {
			tb.Fatal(err)
		}
		_, _ = w.Write(data)
		_ = w.WriteByte('\n')
	}
	return path
}

func TestBuildIndexWithDescriptions(t *testing.T) {
	n := 100
	path := seedJSONLWithDescriptions(t, n)
	dir := filepath.Dir(path)
	indexPath := filepath.Join(dir, "test-index")

	ms := &MotwSearch{
		JsonlPath:        path,
		IndexPath:        indexPath,
		IndexDescription: true,
	}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}

	entries, err := decodePostingsMeta(idx.PostingsMeta)
	if err != nil {
		t.Fatal(err)
	}
	foundAbstractPosting := false
	for _, pe := range entries {
		if pe.Field == FieldAbstract {
			foundAbstractPosting = true
			break
		}
	}
	if !foundAbstractPosting {
		t.Fatal("expected at least one FieldAbstract posting, found none")
	}

	numSegs := int(idx.NumSegments)
	expectedDLLen := numSegs * 4 * 4
	if len(idx.DocLengths) != expectedDLLen {
		t.Fatalf("doc-lengths: got %d bytes, want %d (numSegs=%d * 4 fields * 4 bytes)", len(idx.DocLengths), expectedDLLen, numSegs)
	}

	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}

	searcher := &MotwSearch{IndexPath: indexPath}
	books, _, err := searcher.Search(context.Background(), SearchQuery{Field: FieldTitle, Text: "art"}, SearchOptions{})
	if err != nil {
		t.Fatal(err)
	}
	if len(books) == 0 {
		t.Fatal("expected at least one result for title:art, got 0")
	}
}

func TestBuildIndexWithoutDescriptions(t *testing.T) {

	n := 50
	pathWithDesc := seedJSONLWithDescriptions(t, n)
	pathPlain := seedJSONL(t, n)

	dirA := filepath.Dir(pathWithDesc)
	dirB := filepath.Dir(pathPlain)

	msA := &MotwSearch{
		JsonlPath:        pathWithDesc,
		IndexPath:        filepath.Join(dirA, "idx-nodesc"),
		IndexDescription: false,
	}
	msB := &MotwSearch{
		JsonlPath: pathPlain,
		IndexPath: filepath.Join(dirB, "idx-plain"),
	}

	idxA, err := msA.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	idxB, err := msB.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}

	numSegsA := int(idxA.NumSegments)
	numSegsB := int(idxB.NumSegments)
	if numSegsA != numSegsB {
		t.Fatalf("segment counts differ: A=%d, B=%d", numSegsA, numSegsB)
	}
	if len(idxA.DocLengths) != numSegsA*3*4 {
		t.Fatalf("index A: doc-lengths %d bytes, want %d (3-field)", len(idxA.DocLengths), numSegsA*3*4)
	}
	if len(idxB.DocLengths) != numSegsB*3*4 {
		t.Fatalf("index B: doc-lengths %d bytes, want %d (3-field)", len(idxB.DocLengths), numSegsB*3*4)
	}

	entriesA, err := decodePostingsMeta(idxA.PostingsMeta)
	if err != nil {
		t.Fatal(err)
	}
	for _, pe := range entriesA {
		if pe.Field == FieldAbstract {
			t.Fatal("index A: unexpected FieldAbstract posting when IndexDescription=false")
		}
	}
}

func TestIndexedFieldCountManifestEOFTolerance(t *testing.T) {
	t.Run("4-field manifest", func(t *testing.T) {
		m := Manifest{
			FormatTag:         manifestFormatTag,
			IndexedFieldCount: 4,
		}
		data, err := encodeManifest(m)
		if err != nil {
			t.Fatal(err)
		}
		decoded, err := decodeManifest(data)
		if err != nil {
			t.Fatal(err)
		}
		if decoded.IndexedFieldCount != 4 {
			t.Fatalf("got IndexedFieldCount=%d, want 4", decoded.IndexedFieldCount)
		}
	})

	t.Run("legacy 3-field manifest (no trailing field)", func(t *testing.T) {

		m := Manifest{
			FormatTag:         manifestFormatTag,
			IndexedFieldCount: 0,
		}
		data, err := encodeManifest(m)
		if err != nil {
			t.Fatal(err)
		}
		decoded, err := decodeManifest(data)
		if err != nil {
			t.Fatal(err)
		}

		if decoded.IndexedFieldCount != 0 {
			t.Fatalf("got IndexedFieldCount=%d, want 0 (legacy default)", decoded.IndexedFieldCount)
		}
	})

	t.Run("3-field manifest is shorter than 4-field", func(t *testing.T) {
		m3 := Manifest{FormatTag: manifestFormatTag, IndexedFieldCount: 0}
		m4 := Manifest{FormatTag: manifestFormatTag, IndexedFieldCount: 4}
		data3, _ := encodeManifest(m3)
		data4, _ := encodeManifest(m4)

		if len(data4) != len(data3)+4 {
			t.Fatalf("4-field manifest len=%d, 3-field len=%d; expected diff=4, got %d",
				len(data4), len(data3), len(data4)-len(data3))
		}
	})
}

func TestSearchDescriptionField(t *testing.T) {
	n := 100
	path := seedJSONLWithDescriptions(t, n)
	dir := filepath.Dir(path)
	indexPath := filepath.Join(dir, "desc-search-index")

	ms := &MotwSearch{
		JsonlPath:        path,
		IndexPath:        indexPath,
		IndexDescription: true,
	}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}

	searcher := &MotwSearch{IndexPath: indexPath}

	t.Run("match term in abstract only", func(t *testing.T) {

		books, stats, err := searcher.Search(context.Background(), SearchQuery{
			Field: FieldAbstract,
			Text:  "spacetime",
		}, SearchOptions{})
		if err != nil {
			t.Fatal(err)
		}
		if len(books) == 0 {
			t.Fatal("expected matches for abstract:spacetime, got 0")
		}
		if stats.BooksMatched == 0 {
			t.Fatal("stats.BooksMatched should be > 0")
		}

		found := false
		for _, b := range books {
			if strings.Contains(b.Title, "Brief History") {
				found = true
				break
			}
		}
		if !found {
			t.Fatalf("expected 'A Brief History of Time' in results, got %v", books)
		}
	})

	t.Run("no match in abstract", func(t *testing.T) {

		books, _, err := searcher.Search(context.Background(), SearchQuery{
			Field: FieldAbstract,
			Text:  "xyznonexistent",
		}, SearchOptions{})
		if err != nil {
			t.Fatal(err)
		}
		if len(books) != 0 {
			t.Fatalf("expected 0 results for abstract:xyznonexistent, got %d", len(books))
		}
	})

	t.Run("abstract search ignores title-only terms", func(t *testing.T) {

		books, _, err := searcher.Search(context.Background(), SearchQuery{
			Field: FieldAbstract,
			Text:  "discourse",
		}, SearchOptions{})
		if err != nil {
			t.Fatal(err)
		}
		if len(books) != 0 {
			t.Fatalf("expected 0 results for abstract:discourse, got %d", len(books))
		}
	})
}

func TestSearchAllField(t *testing.T) {
	n := 100
	path := seedJSONLWithDescriptions(t, n)
	dir := filepath.Dir(path)
	indexPath := filepath.Join(dir, "all-search-index")

	ms := &MotwSearch{
		JsonlPath:        path,
		IndexPath:        indexPath,
		IndexDescription: true,
	}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}

	searcher := &MotwSearch{IndexPath: indexPath}

	t.Run("finds title match", func(t *testing.T) {
		books, _, err := searcher.Search(context.Background(), SearchQuery{
			Field: FieldAll,
			Text:  "programming",
		}, SearchOptions{SortMode: SortRelevance})
		if err != nil {
			t.Fatal(err)
		}
		if len(books) == 0 {
			t.Fatal("expected matches for all:programming, got 0")
		}

		found := false
		for _, b := range books {
			if strings.Contains(b.Title, "Programming") {
				found = true
				break
			}
		}
		if !found {
			t.Fatal("expected 'The Art of Programming' in all:programming results")
		}
	})

	t.Run("finds abstract-only match", func(t *testing.T) {

		books, _, err := searcher.Search(context.Background(), SearchQuery{
			Field: FieldAll,
			Text:  "spacetime",
		}, SearchOptions{SortMode: SortRelevance})
		if err != nil {
			t.Fatal(err)
		}
		if len(books) == 0 {
			t.Fatal("expected matches for all:spacetime, got 0")
		}
	})

	t.Run("merges multi-field hits", func(t *testing.T) {

		books, _, err := searcher.Search(context.Background(), SearchQuery{
			Field: FieldAll,
			Text:  "algorithms",
		}, SearchOptions{SortMode: SortRelevance})
		if err != nil {
			t.Fatal(err)
		}
		if len(books) == 0 {
			t.Fatal("expected matches for all:algorithms, got 0")
		}

		seen := map[string]bool{}
		for _, b := range books {
			if seen[b.UUID] {
				t.Fatalf("duplicate book %q in results", b.UUID)
			}
			seen[b.UUID] = true
		}
	})

	t.Run("no match returns empty", func(t *testing.T) {
		books, _, err := searcher.Search(context.Background(), SearchQuery{
			Field: FieldAll,
			Text:  "xyznonexistent",
		}, SearchOptions{SortMode: SortRelevance})
		if err != nil {
			t.Fatal(err)
		}
		if len(books) != 0 {
			t.Fatalf("expected 0 results for all:xyznonexistent, got %d", len(books))
		}
	})

	t.Run("multi-field match is not double-scored", func(t *testing.T) {
		tagBooks, _, err := searcher.Search(context.Background(), SearchQuery{Field: FieldTag, Text: "algorithms"}, SearchOptions{SortMode: SortRelevance})
		if err != nil {
			t.Fatal(err)
		}
		allBooks, _, err := searcher.Search(context.Background(), SearchQuery{Field: FieldAll, Text: "algorithms"}, SearchOptions{SortMode: SortRelevance})
		if err != nil {
			t.Fatal(err)
		}
		if len(tagBooks) == 0 || len(allBooks) == 0 {
			t.Fatal("expected matches for algorithms in both tag and all modes")
		}
		tagScore := map[string]float64{}
		for _, b := range tagBooks {
			tagScore[b.UUID] = b.SearchScore
		}
		for _, b := range allBooks {
			ts, ok := tagScore[b.UUID]
			if !ok {
				continue
			}
			if diff := b.SearchScore - ts; diff > 1e-9 || diff < -1e-9 {
				t.Fatalf("book %q: all-field score %v != single-field score %v (multi-field double-counting)", b.UUID, b.SearchScore, ts)
			}
		}
	})

}

func TestSearchAllPaginationAndSort(t *testing.T) {
	dir := t.TempDir()
	jsonlPath := filepath.Join(dir, "books.jsonl")
	f, err := os.Create(jsonlPath)
	if err != nil {
		t.Fatal(err)
	}
	w := bufio.NewWriter(f)
	const n = 8
	for i := 0; i < n; i++ {

		b := Book{
			Title:        fmt.Sprintf("Shared Topic Volume %d", i),
			Authors:      []string{"Test Author"},
			Tags:         []string{"sample"},
			LastModified: fmt.Sprintf("2024-02-%02dT00:00:00+00:00", i+1),
			LibraryUUID:  "lib",
			UUID:         fmt.Sprintf("uuid-%d", i),
			Id:           fmt.Sprintf("id-%d", i),
		}
		line, _ := json.Marshal(b)
		w.Write(line)
		w.WriteByte('\n')
	}
	w.Flush()
	f.Close()

	indexPath := filepath.Join(dir, "all-paging-index")
	ms := &MotwSearch{JsonlPath: jsonlPath, IndexPath: indexPath, IndexDescription: true}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}
	searcher := &MotwSearch{IndexPath: indexPath}
	q := SearchQuery{Field: FieldAll, Text: "shared"}

	full, _, err := searcher.Search(context.Background(), q, SearchOptions{Limit: 0, SortMode: SortRelevance})
	if err != nil {
		t.Fatal(err)
	}
	if len(full) != n {
		t.Fatalf("expected all %d distinct books, got %d (dedup collapse?)", n, len(full))
	}
	win, _, err := searcher.Search(context.Background(), q, SearchOptions{Offset: 1, Limit: 2, SortMode: SortRelevance})
	if err != nil {
		t.Fatal(err)
	}
	want := full[:3]
	if len(win) != len(want) {
		t.Fatalf("expected %d results (top offset+limit), got %d (pre-sliced offset?)", len(want), len(win))
	}
	for i := range want {
		if win[i].Id != want[i].Id {
			t.Fatalf("rank %d: got %q, want %q — searchAll did not return the rank-0 prefix", i, win[i].Id, want[i].Id)
		}
	}

	newest, _, err := searcher.Search(context.Background(), q, SearchOptions{SortMode: SortNewest})
	if err != nil {
		t.Fatal(err)
	}
	if len(newest) != n {
		t.Fatalf("expected %d books, got %d", n, len(newest))
	}
	for i := 1; i < len(newest); i++ {
		if newest[i-1].LastModified < newest[i].LastModified {
			t.Fatalf("SortNewest not honoured: %s before %s", newest[i-1].LastModified, newest[i].LastModified)
		}
	}
	if newest[0].Id != "id-7" {
		t.Fatalf("SortNewest: expected newest (id-7) first, got %q", newest[0].Id)
	}
}
