package calibre

// Stage 2 end-to-end oracle: the parallel CompressToFile must produce a BYTE-IDENTICAL .zst
// regardless of GOMAXPROCS (worker count), with and without the display dict, and the --append
// round-trip on a parallel-built base must still work. A small ChunkSize forces many frames so
// the wave parallelism is actually exercised.
//
// Run: go test ./pkg/calibre/ -run TestStage2 -count=1 -v

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"testing"
)

func stage2WriteCorpus(t *testing.T, path string, start, n int) {
	t.Helper()
	f, err := os.Create(path)
	if err != nil {
		t.Fatal(err)
	}
	w := bufio.NewWriter(f)
	for i := start; i < start+n; i++ {
		b := Book{
			Id:           methodID(i),
			UUID:         fmt.Sprintf("u%d", i),
			Title:        fmt.Sprintf("Book number %d about quantum methods and theory", i),
			Authors:      []string{fmt.Sprintf("Author %d", i%7)},
			Tags:         []string{"physics", "alpha"},
			Abstract:     fmt.Sprintf("a fairly long discussion of method number %d with assorted filler words to fill out frames across the chunk boundary cleanly", i),
			LastModified: fmt.Sprintf("2024-01-%02dT00:00:00+00:00", (i%27)+1),
			LibraryUUID:  "L",
		}
		line, _ := json.Marshal(b)
		w.Write(line)
		w.WriteByte('\n')
	}
	w.Flush()
	f.Close()
}

func stage2BuildZst(t *testing.T, jsonlPath, idxPath string, gmp int, indexDesc bool, chunkSize int) []byte {
	t.Helper()
	prev := runtime.GOMAXPROCS(gmp)
	defer runtime.GOMAXPROCS(prev)
	// Pin BaseGeneration: it is intentionally a fresh random UUID per build (search.go:1527),
	// so the manifest differs every build by design. Pin it to isolate the COMPRESSION
	// determinism — the thing Stage 2 must keep byte-identical across worker counts.
	gen := [16]byte{0x5a, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16}
	ms := &MotwSearch{JsonlPath: jsonlPath, IndexPath: idxPath, IndexDescription: indexDesc, ChunkSize: chunkSize, BaseGeneration: &gen}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}
	b, err := os.ReadFile(idxPath + ".zst")
	if err != nil {
		t.Fatal(err)
	}
	return b
}

func TestStage2_ByteIdenticalAcrossGOMAXPROCS(t *testing.T) {
	if runtime.NumCPU() < 2 {
		t.Skip("needs >1 CPU to exercise parallelism")
	}
	dir := t.TempDir()
	jp := filepath.Join(dir, "books.jsonl")
	stage2WriteCorpus(t, jp, 0, 150)
	const chunk = 1024 // tiny → many frames

	for _, desc := range []bool{false, true} {
		seq := stage2BuildZst(t, jp, filepath.Join(dir, fmt.Sprintf("seq_%v", desc)), 1, desc, chunk)
		ents, _, _, err := readSeekTableEntries(seq)
		if err != nil {
			t.Fatal(err)
		}
		nframes := len(ents) / seekTableEntrySizeCksm
		if nframes < 4 {
			t.Fatalf("desc=%v: only %d frames — corpus/chunk not exercising parallelism", desc, nframes)
		}
		for _, gmp := range []int{2, 4, runtime.NumCPU()} {
			par := stage2BuildZst(t, jp, filepath.Join(dir, fmt.Sprintf("par_%v_%d", desc, gmp)), gmp, desc, chunk)
			if len(par) != len(seq) || string(par) != string(seq) {
				t.Fatalf("desc=%v: .zst differs at GOMAXPROCS 1 vs %d (%d vs %d bytes) — parallel compress not byte-identical", desc, gmp, len(seq), len(par))
			}
		}
		t.Logf("desc=%v: byte-identical across GOMAXPROCS 1/2/4/%d (%d frames, %d bytes)", desc, runtime.NumCPU(), nframes, len(seq))
	}
}

func TestStage2_AppendRoundTripOnParallelBase(t *testing.T) {
	dir := t.TempDir()
	jp := filepath.Join(dir, "base.jsonl")
	stage2WriteCorpus(t, jp, 0, 100)
	ip := filepath.Join(dir, "idx")

	// Base built via the parallel CompressToFile (default GOMAXPROCS).
	ms := &MotwSearch{JsonlPath: jp, IndexPath: ip, IndexDescription: true, ChunkSize: 1024}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}

	// Append a delta (new ids 100..119) — AppendToFile reads the base's seek table.
	dp := filepath.Join(dir, "delta.jsonl")
	stage2WriteCorpus(t, dp, 100, 20)
	ms2 := &MotwSearch{JsonlPath: dp, IndexPath: ip, IndexDescription: true, ChunkSize: 1024}
	didx, err := ms2.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms2.AppendToFile(didx, nil); err != nil {
		t.Fatalf("append on parallel-built base: %v", err)
	}

	opened, err := ms.Open()
	if err != nil {
		t.Fatalf("open after append: %v", err)
	}
	defer opened.Close()
	books, _, err := opened.Search(context.Background(),
		SearchQuery{Field: FieldTitle, Text: "method", Mode: ModeExact}, SearchOptions{})
	if err != nil {
		t.Fatalf("search after append: %v", err)
	}
	if len(books) == 0 {
		t.Fatal("append round-trip on parallel base: search returned nothing")
	}
	t.Logf("append round-trip on parallel-built base OK: %d results", len(books))
}
