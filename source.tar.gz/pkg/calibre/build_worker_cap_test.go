package calibre

// Tests the ca-106 build worker cap: ACCORDER_MAX_BUILD_WORKERS lowers the count, never raises it,
// and the MemAvailable path keeps the result in [1, requested]. Worker count never affects output
// bytes (proven by the byte-identical oracles), so this only governs memory/parallelism.

import "testing"

func TestBuildWorkerCount(t *testing.T) {
	// Explicit override caps DOWN.
	t.Setenv("ACCORDER_MAX_BUILD_WORKERS", "4")
	if got := buildWorkerCount(20); got != 4 {
		t.Errorf("override=4, requested=20: got %d, want 4", got)
	}
	// Override above requested is ignored (cap only lowers).
	t.Setenv("ACCORDER_MAX_BUILD_WORKERS", "100")
	if got := buildWorkerCount(8); got < 1 || got > 8 {
		t.Errorf("override=100, requested=8: got %d, want 1..8", got)
	}
	// Garbage override is ignored.
	t.Setenv("ACCORDER_MAX_BUILD_WORKERS", "nope")
	if got := buildWorkerCount(4); got < 1 || got > 4 {
		t.Errorf("override=garbage, requested=4: got %d, want 1..4", got)
	}
	// Floor at 1.
	t.Setenv("ACCORDER_MAX_BUILD_WORKERS", "")
	if got := buildWorkerCount(0); got != 1 {
		t.Errorf("requested=0: got %d, want 1", got)
	}
	// MemAvailable path stays within [1, requested].
	if got := buildWorkerCount(8); got < 1 || got > 8 {
		t.Errorf("memcap, requested=8: got %d, want 1..8", got)
	}
}
