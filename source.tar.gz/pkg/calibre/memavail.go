//go:build linux

package calibre

import (
	"bufio"
	"io"
	"os"
	"strconv"
	"strings"
)

func MemAvailable() uint64 {
	f, err := os.Open("/proc/meminfo")
	if err != nil {
		return 0
	}
	defer f.Close()
	return parseMemAvailable(f)
}

func parseMemAvailable(r io.Reader) uint64 {
	var memFree, buffers, cached uint64
	scanner := bufio.NewScanner(r)
	for scanner.Scan() {
		line := scanner.Text()
		if strings.HasPrefix(line, "MemAvailable:") {
			return parseMeminfoKB(line)
		}
		switch {
		case strings.HasPrefix(line, "MemFree:"):
			memFree = parseMeminfoKB(line)
		case strings.HasPrefix(line, "Buffers:"):
			buffers = parseMeminfoKB(line)
		case strings.HasPrefix(line, "Cached:"):
			cached = parseMeminfoKB(line)
		}
	}
	return memFree + buffers + cached
}

func parseMeminfoKB(line string) uint64 {
	parts := strings.Fields(line)
	if len(parts) < 2 {
		return 0
	}
	kb, err := strconv.ParseUint(parts[1], 10, 64)
	if err != nil {
		return 0
	}
	return kb * 1024
}
