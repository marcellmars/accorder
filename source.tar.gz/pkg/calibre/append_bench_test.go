package calibre

import (
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func BenchmarkAppend100(b *testing.B) {
	jp := os.Getenv("ACCORDER_BENCH_JSONL")
	if jp == "" {
		b.Skip("set ACCORDER_BENCH_JSONL")
	}

	base := loadBooks(b, jp)
	dir := b.TempDir()

	basePath := filepath.Join(dir, "base")
	ms := &MotwSearch{JsonlPath: jp, IndexPath: basePath}
	idx, err := ms.BuildIndex()
	if err != nil {
		b.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		b.Fatal(err)
	}

	current := make([]*Book, len(base), len(base)+100)
	copy(current, base)
	for i := 0; i < 100; i++ {
		current = append(current, &Book{
			Id: fmt.Sprintf("appended-new-%d", i), UUID: fmt.Sprintf("app-uuid-%d", i),
			Title:   fmt.Sprintf("Newly added book number %d about methods", i),
			Authors: []string{fmt.Sprintf("New Author %d", i%7)}, Tags: []string{"fresh", "added"},
			LastModified: "2026-07-08T00:00:00+00:00", LibraryUUID: "L",
		})
	}

	b.ResetTimer()
	for n := 0; n < b.N; n++ {

		b.StopTimer()
		appPath := filepath.Join(dir, fmt.Sprintf("app%d", n))
		copyFileBench(b, basePath+".zst", appPath+".zst")
		b.StartTimer()

		t0 := time.Now()
		existingDisplay, err := ReadDisplayJSONL(appPath)
		if err != nil {
			b.Fatal(err)
		}
		tRead := time.Since(t0)

		t1 := time.Now()
		delta, tombstones, err := DiffBooks(current, bytes.NewReader(existingDisplay))
		if err != nil {
			b.Fatal(err)
		}
		tDiff := time.Since(t1)
		if len(delta) != 100 {
			b.Fatalf("expected 100 delta books, got %d", len(delta))
		}

		t2 := time.Now()
		deltaPath := appPath + ".delta.jsonl"
		writeBooks(b, deltaPath, delta)
		dms := &MotwSearch{JsonlPath: deltaPath, IndexPath: appPath}
		didx, err := dms.BuildIndex()
		if err != nil {
			b.Fatal(err)
		}
		tBuild := time.Since(t2)

		t3 := time.Now()
		if err := dms.AppendToFile(didx, tombstones); err != nil {
			b.Fatal(err)
		}
		tAppend := time.Since(t3)

		if n == 0 {
			b.ReportMetric(float64(tRead.Milliseconds()), "ReadDisplay-ms")
			b.ReportMetric(float64(tDiff.Milliseconds()), "DiffBooks-ms")
			b.ReportMetric(float64(tBuild.Milliseconds()), "BuildDelta-ms")
			b.ReportMetric(float64(tAppend.Milliseconds()), "AppendToFile-ms")
		}
	}
}

func loadBooks(tb testing.TB, path string) []*Book {
	tb.Helper()
	f, err := os.Open(path)
	if err != nil {
		tb.Fatal(err)
	}
	defer f.Close()
	var out []*Book
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 1<<20), 16<<20)
	for sc.Scan() {
		var b Book
		if err := json.Unmarshal(sc.Bytes(), &b); err != nil {
			tb.Fatal(err)
		}
		bb := b
		out = append(out, &bb)
	}
	if err := sc.Err(); err != nil {
		tb.Fatal(err)
	}
	return out
}

func writeBooks(tb testing.TB, path string, books []*Book) {
	tb.Helper()
	var buf bytes.Buffer
	for _, b := range books {
		line, _ := json.Marshal(b)
		buf.Write(line)
		buf.WriteByte('\n')
	}
	if err := os.WriteFile(path, buf.Bytes(), 0o644); err != nil {
		tb.Fatal(err)
	}
}

func copyFileBench(tb testing.TB, src, dst string) {
	tb.Helper()
	data, err := os.ReadFile(src)
	if err != nil {
		tb.Fatal(err)
	}
	if err := os.WriteFile(dst, data, 0o644); err != nil {
		tb.Fatal(err)
	}
}
