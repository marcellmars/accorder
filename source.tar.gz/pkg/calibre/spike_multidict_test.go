package calibre

// Phase-0 spike for WF3 (fedlib-operations F6 — composition aggregate via
// per-region dicts). This RE-COMMITS the throwaway 2026-06-02 spike that the
// fedlib-operations draft recorded as "manual/ad-hoc — no checked-in test
// artifact". It locks down the one load-bearing dependency claim WF3 rests on:
//
//   A single klauspost/compress/zstd decoder, registered with N raw dictionaries
//   under distinct Dictionary_IDs, decodes frames each compressed under a
//   DIFFERENT dict by selecting the dict from the frame's Dictionary_ID — so the
//   aggregate can SPLICE each member's already-compressed, own-dict region into
//   one container instead of recompiling the corpus.
//
// Today the container is single-dict: const dictID = uint32(1), one
// WithEncoderDictRaw / WithDecoderDictRaw registration (search.go). WF3 makes it
// multi-dict. If this test ever goes red, the WF3 design premise is invalid and
// must be revisited BEFORE building the v4 container.
//
// It mirrors the real encode/decode API exactly (WithEncoderDictRaw on a
// zstd.NewWriter, WithDecoderDictRaw on a zstd.NewReader, EncodeAll/DecodeAll) so
// it tracks the dependency the production path actually uses.

import (
	"bytes"
	"strings"
	"testing"

	"github.com/klauspost/compress/zstd"
)

// rawDict builds a distinctive raw dictionary. Raw dicts are used as the bytes of
// "initial history" preceding a frame's payload, so a payload that begins with the
// dict's content forces the encoder to emit a back-reference INTO the dict — which
// is what makes the dict content (not just its id) matter on decode.
func rawDict(marker string) []byte {
	// ~2 KiB of member-specific boilerplate, the shape a 50-line display-JSONL
	// sample dict would have (see search.go dictSampleLines).
	return []byte(strings.Repeat(`{"authors":["`+marker+`"],"tags":["`+marker+`-shelf"],"publisher":"`+marker+` Press"} `, 24))
}

// dictBackedPayload begins with the full dict content (forcing a dict back-reference)
// then appends a unique tail, modelling one member's region body.
func dictBackedPayload(dict []byte, tail string) []byte {
	out := make([]byte, 0, len(dict)+len(tail))
	out = append(out, dict...)
	out = append(out, []byte(tail)...)
	return out
}

func encodeWithDict(t *testing.T, id uint32, dict, payload []byte) []byte {
	t.Helper()
	enc, err := zstd.NewWriter(nil,
		zstd.WithEncoderLevel(zstd.SpeedBestCompression),
		zstd.WithEncoderDictRaw(id, dict),
	)
	if err != nil {
		t.Fatalf("zstd encoder (id=%d): %v", id, err)
	}
	defer enc.Close()
	return enc.EncodeAll(payload, nil)
}

// region bundles a member's id/dict/payload/frame for the table-driven cases.
type region struct {
	id      uint32
	dict    []byte
	payload []byte
	frame   []byte
}

func makeRegions(t *testing.T) []region {
	t.Helper()
	specs := []struct {
		id     uint32
		marker string
		tail   string
	}{
		{1, "alice", "\n{\"_id\":\"a1\",\"title\":\"Cybernetics\"}\n"},
		{2, "bob", "\n{\"_id\":\"b2\",\"title\":\"Spectacle\"}\n"},
		{3, "carol", "\n{\"_id\":\"c3\",\"title\":\"Simians\"}\n"},
	}
	regions := make([]region, len(specs))
	for i, s := range specs {
		d := rawDict(s.marker)
		p := dictBackedPayload(d, s.tail)
		regions[i] = region{id: s.id, dict: d, payload: p, frame: encodeWithDict(t, s.id, d, p)}
	}
	return regions
}

// multiDictReader builds one decoder registered with all the given regions' dicts.
func multiDictReader(t *testing.T, regions ...region) *zstd.Decoder {
	t.Helper()
	opts := make([]zstd.DOption, 0, len(regions))
	for _, r := range regions {
		opts = append(opts, zstd.WithDecoderDictRaw(r.id, r.dict))
	}
	dec, err := zstd.NewReader(nil, opts...)
	if err != nil {
		t.Fatalf("zstd reader: %v", err)
	}
	return dec
}

// TestSpike_MultiDict_PerFrameSelection: one decoder holding all N dicts decodes
// every region's frame correctly, selecting the dict by the frame's Dictionary_ID.
// This is the core WF3 feasibility claim.
func TestSpike_MultiDict_PerFrameSelection(t *testing.T) {
	regions := makeRegions(t)
	dec := multiDictReader(t, regions...)
	defer dec.Close()

	for _, r := range regions {
		got, err := dec.DecodeAll(r.frame, nil)
		if err != nil {
			t.Fatalf("region id=%d: decode failed: %v", r.id, err)
		}
		if !bytes.Equal(got, r.payload) {
			t.Fatalf("region id=%d: round-trip mismatch (got %d bytes, want %d)", r.id, len(got), len(r.payload))
		}
	}

	// Two members holding the SAME content under DIFFERENT dicts produce distinct
	// frames (distinct Dictionary_ID) that both decode back to that content — the
	// "splice two members' regions into one stream" shape.
	shared := []byte("shared display record across two members\n")
	fA := encodeWithDict(t, regions[0].id, regions[0].dict, shared)
	fB := encodeWithDict(t, regions[1].id, regions[1].dict, shared)
	if bytes.Equal(fA, fB) {
		t.Fatal("frames under different dicts should differ (distinct Dictionary_ID)")
	}
	for _, f := range [][]byte{fA, fB} {
		got, err := dec.DecodeAll(f, nil)
		if err != nil || !bytes.Equal(got, shared) {
			t.Fatalf("shared payload under multi-dict decode: err=%v equal=%v", err, bytes.Equal(got, shared))
		}
	}
}

// TestSpike_MultiDict_UnregisteredDictIDErrors: a frame whose Dictionary_ID the
// decoder does NOT know must FAIL LOUDLY, not decode to garbage. This is the
// guardrail behind WF3's per-member region-dictID assignment — a missing/typo'd
// dictID is a hard error, not silent corruption.
func TestSpike_MultiDict_UnregisteredDictIDErrors(t *testing.T) {
	regions := makeRegions(t)
	// Decoder knows ids 1 and 2 only.
	dec := multiDictReader(t, regions[0], regions[1])
	defer dec.Close()

	got, err := dec.DecodeAll(regions[2].frame, nil) // id=3, unregistered
	if err == nil {
		t.Fatalf("expected error decoding frame with unregistered dictID=3, got %d bytes", len(got))
	}
	if !strings.Contains(strings.ToLower(err.Error()), "dictionary") {
		t.Fatalf("expected an unknown-dictionary error, got: %v", err)
	}
}

// TestSpike_MultiDict_IDCollisionWrongContentIsNotSilentlyCorrect: registering the
// RIGHT id with the WRONG dict content must not silently yield the correct payload.
// This documents the WF3 hazard that two members must never share a dictID with
// different dict bytes — a collision corrupts decode rather than being benign.
func TestSpike_MultiDict_IDCollisionWrongContentIsNotSilentlyCorrect(t *testing.T) {
	regions := makeRegions(t)

	// id=1 mapped to region 2's dict bytes (wrong content under the right id).
	dec, err := zstd.NewReader(nil, zstd.WithDecoderDictRaw(regions[0].id, regions[1].dict))
	if err != nil {
		t.Fatalf("zstd reader: %v", err)
	}
	defer dec.Close()

	got, err := dec.DecodeAll(regions[0].frame, nil)
	if err == nil && bytes.Equal(got, regions[0].payload) {
		t.Fatal("decoding a dict-backed frame with the wrong dict content under the same id " +
			"silently produced the correct payload — dictID collisions would be undetectable")
	}
	switch {
	case err != nil:
		t.Logf("id-collision outcome: hard decode error (zstd detects it): %v", err)
	default:
		t.Logf("id-collision outcome: corrupted payload, no error (got %d bytes, want %d) — "+
			"WF3 must guarantee unique dictID-per-content at assignment time", len(got), len(regions[0].payload))
	}
	// Either a decode error or a corrupted (different) payload is the acceptable,
	// non-silent outcome; both prove the dict CONTENT is load-bearing, not just its id.
}
