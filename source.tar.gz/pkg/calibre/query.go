package calibre

import (
	"fmt"
	"strconv"
	"strings"
)

func ParseSearchQuery(s string) (SearchQuery, error) {
	parts := strings.SplitN(s, ":", 2)
	if len(parts) == 1 {
		return SearchQuery{Field: FieldTitle, Text: strings.TrimSpace(s)}, nil
	}

	field := strings.TrimSpace(strings.ToLower(parts[0]))
	text := strings.TrimSpace(parts[1])
	if text == "" {
		return SearchQuery{}, fmt.Errorf("empty search text after %q:", field)
	}

	sf, err := ParseSearchField(field)
	if err != nil {
		return SearchQuery{}, err
	}

	q := SearchQuery{Field: sf}

	if strings.HasSuffix(text, "*") {
		q.Mode = ModePrefix
		q.Text = strings.TrimSuffix(text, "*")
	} else if idx := strings.LastIndex(text, "~"); idx >= 0 {
		q.Mode = ModeFuzzy
		q.Text = text[:idx]
		distStr := text[idx+1:]
		if distStr == "" {
			q.FuzzyDistance = 1
		} else {
			d, err := strconv.Atoi(distStr)
			if err != nil || d < 1 || d > 2 {
				return SearchQuery{}, fmt.Errorf("invalid fuzzy distance %q (valid: 1, 2)", distStr)
			}
			q.FuzzyDistance = d
		}
	} else {
		q.Mode = ModeExact
		q.Text = text
	}

	if q.Text == "" {
		return SearchQuery{}, fmt.Errorf("empty search text")
	}
	return q, nil
}
