package calibre

import (
	"bufio"
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	stdjson "encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"sync"
	"unicode/utf8"

	"accorder/pkg/torshare"

	uuid "github.com/satori/go.uuid"
	"golang.org/x/sync/errgroup"
)

const (
	GenerationChangeManifestVersion = 1
	GenerationChangeScopeExact      = "exact"
	GenerationChangeScopeCoarse     = "coarse"
	DefaultGenerationChangeMaxBytes = 8 << 20
	DefaultGenerationChangeMaxItems = 5000
)

type GenerationChange struct {
	Kind            string `json:"kind"`
	ID              string `json:"id"`
	OldRecordDigest string `json:"old_record_digest,omitempty"`
	NewRecordDigest string `json:"new_record_digest,omitempty"`
	PayloadChanged  bool   `json:"payload_changed"`
}

type GenerationChangeManifest struct {
	Version                 int
	Scope                   string
	LibraryUUID             string
	FromGeneration          string
	ToGeneration            string
	TargetSourceFingerprint string
	FromLiveCount           *uint32
	ToLiveCount             uint32
	FromCatalogChecksum     string
	ToCatalogChecksum       string
	Changes                 []GenerationChange
}

type GenerationChangeLimits struct {
	MaxBytes   int
	MaxChanges int
}

func (l GenerationChangeLimits) resolved() GenerationChangeLimits {
	if l.MaxBytes <= 0 {
		l.MaxBytes = DefaultGenerationChangeMaxBytes
	}
	if l.MaxChanges <= 0 {
		l.MaxChanges = DefaultGenerationChangeMaxItems
	}
	return l
}

type generationChangeManifestWire struct {
	Version                 int                 `json:"version"`
	Scope                   string              `json:"scope"`
	LibraryUUID             string              `json:"library_uuid"`
	FromGeneration          string              `json:"from_generation,omitempty"`
	ToGeneration            string              `json:"to_generation"`
	TargetSourceFingerprint string              `json:"target_source_fingerprint"`
	FromLiveCount           *uint32             `json:"from_live_count,omitempty"`
	ToLiveCount             uint32              `json:"to_live_count"`
	FromCatalogChecksum     string              `json:"from_catalog_checksum,omitempty"`
	ToCatalogChecksum       string              `json:"to_catalog_checksum"`
	Changes                 *stdjson.RawMessage `json:"changes,omitempty"`
}

func EncodeGenerationChangeManifest(manifest GenerationChangeManifest) ([]byte, error) {
	if err := manifest.Validate(); err != nil {
		return nil, err
	}
	wire := generationChangeManifestWire{
		Version: manifest.Version, Scope: manifest.Scope, LibraryUUID: manifest.LibraryUUID,
		FromGeneration: manifest.FromGeneration, ToGeneration: manifest.ToGeneration,
		TargetSourceFingerprint: manifest.TargetSourceFingerprint,
		FromLiveCount:           manifest.FromLiveCount, ToLiveCount: manifest.ToLiveCount,
		FromCatalogChecksum: manifest.FromCatalogChecksum, ToCatalogChecksum: manifest.ToCatalogChecksum,
	}
	if manifest.Scope == GenerationChangeScopeExact {
		changes, err := stdjson.Marshal(manifest.Changes)
		if err != nil {
			return nil, fmt.Errorf("generation change manifest: marshal changes: %w", err)
		}
		raw := stdjson.RawMessage(changes)
		wire.Changes = &raw
	}
	data, err := stdjson.Marshal(wire)
	if err != nil {
		return nil, fmt.Errorf("generation change manifest: marshal: %w", err)
	}
	return append(data, '\n'), nil
}

func DecodeGenerationChangeManifest(data []byte, limits GenerationChangeLimits) (GenerationChangeManifest, error) {
	limits = limits.resolved()
	if len(data) > limits.MaxBytes {
		return GenerationChangeManifest{}, fmt.Errorf("generation change manifest: %d bytes exceeds limit %d", len(data), limits.MaxBytes)
	}
	if len(data) < 2 || data[len(data)-1] != '\n' || data[len(data)-2] == '\n' {
		return GenerationChangeManifest{}, errors.New("generation change manifest: exactly one trailing LF is required")
	}
	body := data[:len(data)-1]
	if len(bytes.TrimSpace(body)) != len(body) {
		return GenerationChangeManifest{}, errors.New("generation change manifest: non-canonical whitespace")
	}
	if err := rejectDuplicateJSONKeys(body); err != nil {
		return GenerationChangeManifest{}, fmt.Errorf("generation change manifest: %w", err)
	}
	var wire generationChangeManifestWire
	dec := stdjson.NewDecoder(bytes.NewReader(body))
	dec.DisallowUnknownFields()
	if err := dec.Decode(&wire); err != nil {
		return GenerationChangeManifest{}, fmt.Errorf("generation change manifest: decode: %w", err)
	}
	if dec.More() {
		return GenerationChangeManifest{}, errors.New("generation change manifest: trailing JSON")
	}
	manifest := GenerationChangeManifest{
		Version: wire.Version, Scope: wire.Scope, LibraryUUID: wire.LibraryUUID,
		FromGeneration: wire.FromGeneration, ToGeneration: wire.ToGeneration,
		TargetSourceFingerprint: wire.TargetSourceFingerprint,
		FromLiveCount:           wire.FromLiveCount, ToLiveCount: wire.ToLiveCount,
		FromCatalogChecksum: wire.FromCatalogChecksum, ToCatalogChecksum: wire.ToCatalogChecksum,
	}
	if wire.Changes != nil {
		if err := strictDecodeJSON(*wire.Changes, &manifest.Changes); err != nil {
			return GenerationChangeManifest{}, fmt.Errorf("generation change manifest: changes: %w", err)
		}
		if len(manifest.Changes) > limits.MaxChanges {
			return GenerationChangeManifest{}, fmt.Errorf("generation change manifest: %d changes exceeds limit %d", len(manifest.Changes), limits.MaxChanges)
		}
	}
	if err := manifest.Validate(); err != nil {
		return GenerationChangeManifest{}, err
	}
	encoded, err := EncodeGenerationChangeManifest(manifest)
	if err != nil {
		return GenerationChangeManifest{}, err
	}
	if !bytes.Equal(encoded, data) {
		return GenerationChangeManifest{}, errors.New("generation change manifest: non-canonical encoding")
	}
	return manifest, nil
}

func (manifest GenerationChangeManifest) Validate() error {
	if manifest.Version != GenerationChangeManifestVersion {
		return fmt.Errorf("generation change manifest: unsupported version %d", manifest.Version)
	}
	if err := validateCanonicalUUID("library_uuid", manifest.LibraryUUID); err != nil {
		return err
	}
	if err := validateGenerationHex("to_generation", manifest.ToGeneration); err != nil {
		return err
	}
	if err := validateLowerHex("target_source_fingerprint", manifest.TargetSourceFingerprint, sha256.Size); err != nil {
		return err
	}
	if err := validateLowerHex("to_catalog_checksum", manifest.ToCatalogChecksum, sha256.Size); err != nil {
		return err
	}
	switch manifest.Scope {
	case GenerationChangeScopeExact:
		if manifest.FromGeneration == "" || manifest.FromLiveCount == nil || manifest.FromCatalogChecksum == "" || manifest.Changes == nil {
			return errors.New("generation change manifest: exact scope requires all from fields and changes")
		}
		if manifest.FromGeneration == manifest.ToGeneration {
			return errors.New("generation change manifest: exact from_generation equals to_generation")
		}
		if err := validateGenerationHex("from_generation", manifest.FromGeneration); err != nil {
			return err
		}
		if err := validateLowerHex("from_catalog_checksum", manifest.FromCatalogChecksum, sha256.Size); err != nil {
			return err
		}
		if err := validateGenerationChanges(manifest.Changes); err != nil {
			return err
		}
		if err := ValidateCatalogTransition(manifest.FromCatalogChecksum, manifest.ToCatalogChecksum, *manifest.FromLiveCount, manifest.ToLiveCount, manifest.Changes); err != nil {
			return err
		}
	case GenerationChangeScopeCoarse:
		if manifest.Changes != nil {
			return errors.New("generation change manifest: coarse scope forbids changes")
		}
		if manifest.FromGeneration == "" {
			if manifest.FromLiveCount != nil || manifest.FromCatalogChecksum != "" {
				return errors.New("generation change manifest: first publication forbids from fields")
			}
		} else {
			if manifest.FromLiveCount == nil {
				return errors.New("generation change manifest: coarse predecessor requires from_live_count")
			}
			if err := validateGenerationHex("from_generation", manifest.FromGeneration); err != nil {
				return err
			}
			if manifest.FromGeneration == manifest.ToGeneration {
				return errors.New("generation change manifest: coarse from_generation equals to_generation")
			}
			if manifest.FromCatalogChecksum != "" {
				if err := validateLowerHex("from_catalog_checksum", manifest.FromCatalogChecksum, sha256.Size); err != nil {
					return err
				}
			}
		}
	default:
		return fmt.Errorf("generation change manifest: unsupported scope %q", manifest.Scope)
	}
	return nil
}

func validateGenerationChanges(changes []GenerationChange) error {
	previous := ""
	for i, change := range changes {
		if err := validateCanonicalUUID(fmt.Sprintf("changes[%d].id", i), change.ID); err != nil {
			return err
		}
		if previous != "" && change.ID <= previous {
			return errors.New("generation change manifest: changes must be strictly ID-sorted and unique")
		}
		previous = change.ID
		switch change.Kind {
		case "added":
			if change.OldRecordDigest != "" || change.NewRecordDigest == "" {
				return fmt.Errorf("generation change manifest: added %s has invalid digest fields", change.ID)
			}
		case "edited":
			if change.OldRecordDigest == "" || change.NewRecordDigest == "" {
				return fmt.Errorf("generation change manifest: edited %s requires both digests", change.ID)
			}
			if change.OldRecordDigest == change.NewRecordDigest && !change.PayloadChanged {
				return fmt.Errorf("generation change manifest: unchanged record %s requires payload_changed", change.ID)
			}
		case "deleted":
			if change.OldRecordDigest == "" || change.NewRecordDigest != "" || change.PayloadChanged {
				return fmt.Errorf("generation change manifest: deleted %s has invalid fields", change.ID)
			}
		default:
			return fmt.Errorf("generation change manifest: unsupported change kind %q", change.Kind)
		}
		if change.OldRecordDigest != "" {
			if err := validateLowerHex("old_record_digest", change.OldRecordDigest, sha256.Size); err != nil {
				return err
			}
		}
		if change.NewRecordDigest != "" {
			if err := validateLowerHex("new_record_digest", change.NewRecordDigest, sha256.Size); err != nil {
				return err
			}
		}
	}
	return nil
}

func ValidateCatalogTransition(fromChecksum, toChecksum string, fromCount, toCount uint32, changes []GenerationChange) error {
	if err := validateLowerHex("from_catalog_checksum", fromChecksum, sha256.Size); err != nil {
		return err
	}
	if err := validateLowerHex("to_catalog_checksum", toChecksum, sha256.Size); err != nil {
		return err
	}
	fromBytes, _ := hex.DecodeString(fromChecksum)
	result := append([]byte(nil), fromBytes...)
	count := int64(fromCount)
	for _, change := range changes {
		switch change.Kind {
		case "added":
			count++
			xorDigestHex(result, change.NewRecordDigest)
		case "edited":
			xorDigestHex(result, change.OldRecordDigest)
			xorDigestHex(result, change.NewRecordDigest)
		case "deleted":
			count--
			xorDigestHex(result, change.OldRecordDigest)
		default:
			return fmt.Errorf("generation change manifest: unsupported change kind %q", change.Kind)
		}
	}
	if count < 0 || count != int64(toCount) {
		return fmt.Errorf("generation change manifest: live-count transition yields %d, want %d", count, toCount)
	}
	if hex.EncodeToString(result) != toChecksum {
		return errors.New("generation change manifest: catalog checksum transition mismatch")
	}
	return nil
}

func xorDigestHex(target []byte, digest string) {
	decoded, _ := hex.DecodeString(digest)
	for i := range target {
		target[i] ^= decoded[i]
	}
}

func validateGenerationHex(field, value string) error {
	if err := validateLowerHex(field, value, 24); err != nil {
		return err
	}
	raw, _ := hex.DecodeString(value)
	if _, _, err := torshare.DecodeGeneration(raw); err != nil {
		return fmt.Errorf("generation change manifest: %s: %w", field, err)
	}
	return nil
}

func validateLowerHex(field, value string, byteLen int) error {
	if len(value) != byteLen*2 || strings.ToLower(value) != value {
		return fmt.Errorf("generation change manifest: %s must be %d lowercase hexadecimal characters", field, byteLen*2)
	}
	if _, err := hex.DecodeString(value); err != nil {
		return fmt.Errorf("generation change manifest: %s: %w", field, err)
	}
	return nil
}

func validateCanonicalUUID(field, value string) error {
	parsed, err := uuid.FromString(value)
	if err != nil || parsed.String() != value || strings.ToLower(value) != value {
		return fmt.Errorf("generation change manifest: %s must be a canonical lowercase UUID", field)
	}
	return nil
}

type canonicalRecord struct {
	Abstract         string                 `json:"abstract"`
	Authors          []string               `json:"authors"`
	BaseURL          string                 `json:"baseurl,omitempty"`
	LibraryURL       string                 `json:"library_url"`
	CalibreID        int64                  `json:"id,omitempty"`
	CoverURL         string                 `json:"cover_url"`
	Formats          []*canonicalFile       `json:"formats"`
	ID               string                 `json:"_id"`
	Identifiers      []*canonicalIdentifier `json:"identifiers"`
	Languages        []string               `json:"languages"`
	LastModified     string                 `json:"last_modified"`
	Librarian        string                 `json:"librarian"`
	LibraryUUID      string                 `json:"library_uuid"`
	Pubdate          string                 `json:"pubdate"`
	Publisher        string                 `json:"publisher"`
	Series           string                 `json:"series"`
	Tags             []string               `json:"tags"`
	Title            string                 `json:"title"`
	TitleSort        string                 `json:"title_sort"`
	UUID             string                 `json:"uuid,omitempty"`
	CoverFingerprint string                 `json:"cover_fingerprint,omitempty"`
}

type canonicalFile struct {
	Format        string `json:"format"`
	DirectoryPath string `json:"dir_path"`
	Name          string `json:"file_name"`
	Size          int64  `json:"size"`
	XXHash        uint64 `json:"xxhash,omitempty"`
}

type canonicalIdentifier struct {
	Scheme string `json:"scheme"`
	Code   string `json:"code"`
}

var canonicalRecordRequiredFields = []string{
	"abstract", "authors", "library_url", "cover_url", "formats", "_id", "identifiers",
	"languages", "last_modified", "librarian", "library_uuid", "pubdate", "publisher",
	"series", "tags", "title", "title_sort",
}

var canonicalFormatRequiredFields = []string{"format", "dir_path", "file_name", "size"}
var canonicalIdentifierRequiredFields = []string{"scheme", "code"}

var canonicalRecordLegacyNullableArrays = map[string]struct{}{
	"authors": {}, "formats": {}, "identifiers": {}, "languages": {}, "tags": {},
}

func CanonicalRecordBytes(book *Book) ([]byte, error) {
	record, err := canonicalRecordForBook(book)
	if err != nil {
		return nil, err
	}
	return stdjson.Marshal(record)
}

func canonicalRecordForBook(book *Book) (*canonicalRecord, error) {
	if book == nil {
		return nil, errors.New("canonical record: nil book")
	}
	authors := nonNilStrings(book.Authors)
	languages := nonNilStrings(book.Languages)
	tags := nonNilStrings(book.Tags)
	formats := book.Formats
	if formats == nil {
		formats = []*File{}
	}
	identifiers := book.Identifiers
	if identifiers == nil {
		identifiers = []*Identifier{}
	}
	record := canonicalRecord{
		Abstract: book.Abstract, Authors: authors, BaseURL: book.BaseURL,
		LibraryURL: book.LibraryUrl, CalibreID: book.CalibreID, CoverURL: book.CoverUrl,
		ID: book.Id, Languages: languages, LastModified: book.LastModified,
		Librarian: book.Librarian, LibraryUUID: book.LibraryUUID, Pubdate: book.Pubdate,
		Publisher: book.Publisher, Series: book.Series, Tags: tags, Title: book.Title,
		TitleSort: book.TitleSort, UUID: book.UUID, CoverFingerprint: book.CoverFingerprint,
	}
	if err := validateCanonicalUUID("record _id", record.ID); err != nil {
		return nil, err
	}
	record.Formats = make([]*canonicalFile, len(formats))
	for i, file := range formats {
		if file == nil {
			return nil, fmt.Errorf("canonical record: format %d is null", i)
		}
		record.Formats[i] = &canonicalFile{Format: file.Format, DirectoryPath: file.DirectoryPath, Name: file.Name, Size: file.Size, XXHash: file.XXHash}
	}
	record.Identifiers = make([]*canonicalIdentifier, len(identifiers))
	for i, identifier := range identifiers {
		if identifier == nil {
			return nil, fmt.Errorf("canonical record: identifier %d is null", i)
		}
		record.Identifiers[i] = &canonicalIdentifier{Scheme: identifier.Scheme, Code: identifier.Code}
	}
	return &record, nil
}

func nonNilStrings(values []string) []string {
	if values == nil {
		return []string{}
	}
	return values
}

func CanonicalRecordBytesFromJSON(data []byte, stableID string) ([]byte, error) {
	record, err := canonicalRecordFromJSON(data, stableID)
	if err != nil {
		return nil, err
	}
	return stdjson.Marshal(record)
}

func canonicalRecordFromJSON(data []byte, stableID string) (*canonicalRecord, error) {
	if err := rejectDuplicateJSONKeys(data); err != nil {
		return nil, fmt.Errorf("canonical record: %w", err)
	}
	var fields map[string]stdjson.RawMessage
	if err := stdjson.Unmarshal(data, &fields); err != nil {
		return nil, fmt.Errorf("canonical record: decode fields: %w", err)
	}
	legacyArrays := false
	for _, required := range canonicalRecordRequiredFields {
		raw, ok := fields[required]
		if !ok {
			return nil, fmt.Errorf("canonical record: missing required field %q", required)
		}
		if bytes.Equal(bytes.TrimSpace(raw), []byte("null")) {
			if _, legacyArray := canonicalRecordLegacyNullableArrays[required]; legacyArray {
				// Old indexes were written directly from Book and therefore used
				// null for an absent slice. The canonical projection has always
				// treated nil and empty collections alike; normalize that one
				// legacy representation while keeping scalar and nested nulls
				// invalid.
				fields[required] = stdjson.RawMessage("[]")
				legacyArrays = true
				continue
			}
			return nil, fmt.Errorf("canonical record: required field %q is null", required)
		}
	}
	for name, raw := range fields {
		// Preserve the old map-normalization precedence for case-folded
		// aliases accepted by encoding/json (e.g. TITLE beside title).
		if name != strings.ToLower(name) {
			legacyArrays = true
		}
		if bytes.Equal(bytes.TrimSpace(raw), []byte("null")) {
			return nil, fmt.Errorf("canonical record: field %q is null", name)
		}
	}
	if err := validateCanonicalNestedFields(fields["formats"], "format", canonicalFormatRequiredFields); err != nil {
		return nil, err
	}
	if err := validateCanonicalNestedFields(fields["identifiers"], "identifier", canonicalIdentifierRequiredFields); err != nil {
		return nil, err
	}
	normalized := data
	if legacyArrays {
		var err error
		normalized, err = stdjson.Marshal(fields)
		if err != nil {
			return nil, fmt.Errorf("canonical record: normalize legacy arrays: %w", err)
		}
	}
	var record canonicalRecord
	if err := strictDecodeJSON(normalized, &record); err != nil {
		return nil, fmt.Errorf("canonical record: %w", err)
	}
	if record.ID != stableID {
		return nil, fmt.Errorf("canonical record: _id %q does not match %q", record.ID, stableID)
	}
	if record.Formats == nil || record.Identifiers == nil || record.Authors == nil || record.Languages == nil || record.Tags == nil {
		return nil, errors.New("canonical record: required arrays must be non-null")
	}
	for _, file := range record.Formats {
		if file == nil {
			return nil, errors.New("canonical record: null format")
		}
	}
	for _, identifier := range record.Identifiers {
		if identifier == nil {
			return nil, errors.New("canonical record: null identifier")
		}
	}
	if err := validateCanonicalUUID("record _id", record.ID); err != nil {
		return nil, err
	}
	return &record, nil
}

func validateCanonicalNestedFields(data []byte, kind string, required []string) error {
	var objects []map[string]stdjson.RawMessage
	if err := stdjson.Unmarshal(data, &objects); err != nil {
		return fmt.Errorf("canonical record: decode %ss: %w", kind, err)
	}
	for index, object := range objects {
		if object == nil {
			return fmt.Errorf("canonical record: %s %d is null", kind, index)
		}
		for _, name := range required {
			raw, ok := object[name]
			if !ok {
				return fmt.Errorf("canonical record: %s %d missing required field %q", kind, index, name)
			}
			if bytes.Equal(bytes.TrimSpace(raw), []byte("null")) {
				return fmt.Errorf("canonical record: %s %d field %q is null", kind, index, name)
			}
		}
		for name, raw := range object {
			if bytes.Equal(bytes.TrimSpace(raw), []byte("null")) {
				return fmt.Errorf("canonical record: %s %d field %q is null", kind, index, name)
			}
		}
	}
	return nil
}

func RecordDigest(stableID string, canonical []byte) [sha256.Size]byte {
	h := sha256.New()
	h.Write([]byte("accorder-catalog-record-v1\x00"))
	var length [8]byte
	binary.BigEndian.PutUint64(length[:], uint64(len(stableID)))
	h.Write(length[:])
	h.Write([]byte(stableID))
	binary.BigEndian.PutUint64(length[:], uint64(len(canonical)))
	h.Write(length[:])
	h.Write(canonical)
	var digest [sha256.Size]byte
	copy(digest[:], h.Sum(nil))
	return digest
}

func CatalogChecksum(books []*Book) ([sha256.Size]byte, error) {
	var checksum [sha256.Size]byte
	seen := make(map[string]struct{}, len(books))
	for _, book := range books {
		if book == nil || book.Id == "" {
			return checksum, errors.New("catalog checksum: empty book ID")
		}
		if _, ok := seen[book.Id]; ok {
			return checksum, fmt.Errorf("catalog checksum: duplicate book ID %s", book.Id)
		}
		seen[book.Id] = struct{}{}
		canonical, err := CanonicalRecordBytes(book)
		if err != nil {
			return checksum, err
		}
		digest := RecordDigest(book.Id, canonical)
		for i := range checksum {
			checksum[i] ^= digest[i]
		}
	}
	return checksum, nil
}

type CatalogDiff struct {
	Changes         []GenerationChange
	FromCount       uint32
	ToCount         uint32
	FromChecksum    string
	ToChecksum      string
	PreviousRecords map[string]CatalogRecordInfo
	CurrentRecords  map[string]CatalogRecordInfo
}

// CatalogRecordInfo is the bounded endpoint state needed by the producer and
// aggregate consumer. It intentionally omits human metadata such as title and
// abstract while retaining the server-derived path inputs.
type CatalogRecordInfo struct {
	ID                string
	LibraryUUID       string
	CoverURL          string
	CoverFingerprint  string
	FormatDirectories []string
	FormatPaths       []string
	BookDirectories   []string
	RecordDigest      string
	MetadataDigest    string
}

// CatalogRecordInfoForBook exposes the exact bounded projection used by the
// generation-change compiler without exposing the canonical wire struct.
func CatalogRecordInfoForBook(book *Book) (CatalogRecordInfo, error) {
	return catalogRecordInfoFromBook(book)
}

// CompileCatalogDiffFromRecordInfos compares current books with an already
// streamed prior endpoint. It is used when build-time fingerprint decisions
// and the final catalog diff must share one prior-index read.
func CompileCatalogDiffFromRecordInfos(current []*Book, previous map[string]CatalogRecordInfo) (CatalogDiff, error) {
	return compileCatalogDiffFromRecordInfos(current, previous)
}

// CompileCatalogDiff streams the previous catalog from JSONL and retains only
// digests, so the returned CatalogDiff's PreviousRecords and CurrentRecords
// stay nil — unlike CompileCatalogDiffFromRecordInfos/CompileCatalogDiffFromIndex.
// Do not feed this diff to code that needs those maps (for example
// payloadChangedIDs / compileLocalChangeCandidate): every field lookup on a
// nil map silently returns the zero value instead of failing, so a payload
// change would be misclassified as ambiguous rather than reported.
func CompileCatalogDiff(current []*Book, previousLiveJSONL io.Reader) (CatalogDiff, error) {
	currentByID := make(map[string]string, len(current))
	for _, book := range current {
		canonical, err := CanonicalRecordBytes(book)
		if err != nil {
			return CatalogDiff{}, err
		}
		if _, exists := currentByID[book.Id]; exists {
			return CatalogDiff{}, fmt.Errorf("catalog diff: duplicate current ID %s", book.Id)
		}
		digest := RecordDigest(book.Id, canonical)
		currentByID[book.Id] = hex.EncodeToString(digest[:])
	}
	var fromChecksum [sha256.Size]byte
	seenPrevious := make(map[string]struct{})
	changes := make([]GenerationChange, 0)
	scanner := bufio.NewScanner(previousLiveJSONL)
	scanner.Buffer(make([]byte, 64<<10), 16<<20)
	for scanner.Scan() {
		line := bytes.TrimSpace(scanner.Bytes())
		if len(line) == 0 {
			continue
		}
		var idOnly struct {
			ID string `json:"_id"`
		}
		if err := stdjson.Unmarshal(line, &idOnly); err != nil {
			return CatalogDiff{}, fmt.Errorf("catalog diff: decode previous ID: %w", err)
		}
		if _, exists := seenPrevious[idOnly.ID]; exists {
			return CatalogDiff{}, fmt.Errorf("catalog diff: duplicate previous ID %s", idOnly.ID)
		}
		seenPrevious[idOnly.ID] = struct{}{}
		canonical, err := CanonicalRecordBytesFromJSON(line, idOnly.ID)
		if err != nil {
			return CatalogDiff{}, err
		}
		oldDigestBytes := RecordDigest(idOnly.ID, canonical)
		oldDigest := hex.EncodeToString(oldDigestBytes[:])
		for i := range fromChecksum {
			fromChecksum[i] ^= oldDigestBytes[i]
		}
		newDigest, exists := currentByID[idOnly.ID]
		switch {
		case !exists:
			changes = append(changes, GenerationChange{Kind: "deleted", ID: idOnly.ID, OldRecordDigest: oldDigest})
		case newDigest != oldDigest:
			changes = append(changes, GenerationChange{Kind: "edited", ID: idOnly.ID, OldRecordDigest: oldDigest, NewRecordDigest: newDigest})
		}
		delete(currentByID, idOnly.ID)
	}
	if err := scanner.Err(); err != nil {
		return CatalogDiff{}, fmt.Errorf("catalog diff: scan previous: %w", err)
	}
	for id, digest := range currentByID {
		changes = append(changes, GenerationChange{Kind: "added", ID: id, NewRecordDigest: digest})
	}
	sort.Slice(changes, func(i, j int) bool { return changes[i].ID < changes[j].ID })
	toChecksum, err := CatalogChecksum(current)
	if err != nil {
		return CatalogDiff{}, err
	}
	result := CatalogDiff{
		Changes: changes, FromCount: uint32(len(seenPrevious)), ToCount: uint32(len(current)),
		FromChecksum: hex.EncodeToString(fromChecksum[:]), ToChecksum: hex.EncodeToString(toChecksum[:]),
	}
	if err := ValidateCatalogTransition(result.FromChecksum, result.ToChecksum, result.FromCount, result.ToCount, result.Changes); err != nil {
		return CatalogDiff{}, err
	}
	return result, nil
}

// CompileCatalogDiffFromIndex streams display regions from an existing index
// and retains only one digest per live stable ID. It does not materialize the
// old JSONL or decode a second complete []*Book catalog.
func CompileCatalogDiffFromIndex(current []*Book, indexPath string) (CatalogDiff, error) {
	previousByID, err := ReadCatalogRecordInfos(indexPath)
	if err != nil {
		return CatalogDiff{}, err
	}
	return compileCatalogDiffFromRecordInfos(current, previousByID)
}

// ReadCatalogRecordInfos streams the live display records from an MWSC index.
// Newer regions win and tombstoned IDs are omitted, so callers never need to
// retain a second decoded []*Book catalog.
func ReadCatalogRecordInfos(indexPath string) (map[string]CatalogRecordInfo, error) {
	return readCatalogRecordInfos(indexPath, nil)
}

// ReadCatalogRecordInfosByID scans each display region once and retains only
// the requested live records. This is the batch endpoint lookup used by
// skipped-generation validation.
func ReadCatalogRecordInfosByID(indexPath string, ids []string) (map[string]CatalogRecordInfo, error) {
	wanted := make(map[string]struct{}, len(ids))
	for _, id := range ids {
		wanted[id] = struct{}{}
	}
	return readCatalogRecordInfos(indexPath, wanted)
}

// CatalogChecksumFromIndex recomputes the complete live-record checksum from
// an immutable index endpoint. It is used to verify a checksum-bearing pointer
// before that endpoint becomes authoritative.
func CatalogChecksumFromIndex(indexPath string) (string, uint32, error) {
	records, err := ReadCatalogRecordInfos(indexPath)
	if err != nil {
		return "", 0, err
	}
	var checksum [sha256.Size]byte
	for _, record := range records {
		digest, err := hex.DecodeString(record.RecordDigest)
		if err != nil || len(digest) != sha256.Size {
			return "", 0, errors.New("catalog checksum: invalid record digest")
		}
		for index := range checksum {
			checksum[index] ^= digest[index]
		}
	}
	return hex.EncodeToString(checksum[:]), uint32(len(records)), nil
}

func readCatalogRecordInfos(indexPath string, wanted map[string]struct{}) (map[string]CatalogRecordInfo, error) {
	f, err := os.Open(indexPath + ".zst")
	if err != nil {
		return nil, err
	}
	defer f.Close()
	rdr, dec, manifest, err := openMWSC(f)
	if err != nil {
		return nil, err
	}
	defer rdr.Close()
	defer dec.Close()
	displayEnd, err := manifestSpanStart(rdr)
	if err != nil {
		return nil, fmt.Errorf("catalog diff: locate manifest: %w", err)
	}
	if rdr.Size() < 0 || displayEnd > uint64(rdr.Size()) {
		return nil, errors.New("catalog diff: invalid manifest boundary")
	}

	tombstones := make(map[[16]byte]struct{}, len(manifest.Tombstones))
	for _, tombstone := range manifest.Tombstones {
		tombstones[tombstone] = struct{}{}
	}
	capacity := int(manifest.NumBooks)
	if wanted != nil {
		capacity = len(wanted)
	} else if capacity > 64<<10 {
		capacity = 64 << 10
	}
	previousByID := make(map[string]CatalogRecordInfo, capacity)
	// Selection remains ordered newest-first; only validation/canonicalization
	// of independent selected records runs concurrently. Own each queued line
	// because Scanner reuses its buffer. Bound parsing to four active records
	// and at most one waiting line, independently of the catalog's length.
	selected := make(map[string]struct{}, capacity)
	group, parseContext := errgroup.WithContext(context.Background())
	group.SetLimit(min(4, runtime.GOMAXPROCS(0)))
	defer group.Wait() // Drain owned buffers on scanner/manifest errors as well.
	var recordsMu sync.Mutex
	for regionIndex := len(manifest.Regions) - 1; regionIndex >= 0; regionIndex-- {
		region := manifest.Regions[regionIndex]
		if region.DisplayOff > uint64(displayEnd) || region.DisplayLen > uint64(displayEnd)-region.DisplayOff {
			return nil, fmt.Errorf("catalog diff: display region %d exceeds index data", regionIndex)
		}
		section := io.NewSectionReader(rdr, int64(region.DisplayOff), int64(region.DisplayLen))
		scanner := bufio.NewScanner(section)
		scanner.Buffer(make([]byte, 64<<10), 16<<20)
		for scanner.Scan() {
			if parseContext.Err() != nil {
				return nil, group.Wait()
			}
			line := bytes.TrimSpace(scanner.Bytes())
			if len(line) == 0 {
				continue
			}
			var idOnly struct {
				ID string `json:"_id"`
			}
			if err := stdjson.Unmarshal(line, &idOnly); err != nil {
				return nil, fmt.Errorf("catalog diff: decode previous ID: %w", err)
			}
			tombstone, err := bookIDToTombstone(idOnly.ID)
			if err != nil {
				return nil, fmt.Errorf("catalog diff: invalid previous ID %q: %w", idOnly.ID, err)
			}
			if _, deleted := tombstones[tombstone]; deleted {
				continue
			}
			if wanted != nil {
				if _, ok := wanted[idOnly.ID]; !ok {
					continue
				}
			}
			if _, newer := selected[idOnly.ID]; newer {
				continue
			}
			selected[idOnly.ID] = struct{}{}
			ownedLine, id := bytes.Clone(line), idOnly.ID
			group.Go(func() error {
				info, err := catalogRecordInfoFromJSON(ownedLine, id)
				if err != nil {
					return err
				}
				recordsMu.Lock()
				previousByID[id] = info
				recordsMu.Unlock()
				return nil
			})
		}
		if err := scanner.Err(); err != nil {
			return nil, fmt.Errorf("catalog diff: scan display region %d: %w", regionIndex, err)
		}
	}
	if err := group.Wait(); err != nil {
		return nil, err
	}
	return previousByID, nil
}

func compileCatalogDiffFromRecordInfos(current []*Book, previousByID map[string]CatalogRecordInfo) (CatalogDiff, error) {
	currentByID := make(map[string]CatalogRecordInfo, len(current))
	for _, book := range current {
		info, err := catalogRecordInfoFromBook(book)
		if err != nil {
			return CatalogDiff{}, err
		}
		if _, exists := currentByID[book.Id]; exists {
			return CatalogDiff{}, fmt.Errorf("catalog diff: duplicate current ID %s", book.Id)
		}
		currentByID[book.Id] = info
	}
	ids := make([]string, 0, len(previousByID))
	for id := range previousByID {
		ids = append(ids, id)
	}
	sort.Strings(ids)
	var fromChecksum [sha256.Size]byte
	changes := make([]GenerationChange, 0)
	for _, id := range ids {
		oldDigest := previousByID[id].RecordDigest
		xorDigestHex(fromChecksum[:], oldDigest)
		currentInfo, exists := currentByID[id]
		switch {
		case !exists:
			changes = append(changes, GenerationChange{Kind: "deleted", ID: id, OldRecordDigest: oldDigest})
		case currentInfo.RecordDigest != oldDigest:
			changes = append(changes, GenerationChange{Kind: "edited", ID: id, OldRecordDigest: oldDigest, NewRecordDigest: currentInfo.RecordDigest})
		}
	}
	for id, info := range currentByID {
		if _, existed := previousByID[id]; !existed {
			changes = append(changes, GenerationChange{Kind: "added", ID: id, NewRecordDigest: info.RecordDigest})
		}
	}
	sort.Slice(changes, func(i, j int) bool { return changes[i].ID < changes[j].ID })
	var toChecksum [sha256.Size]byte
	for _, info := range currentByID {
		xorDigestHex(toChecksum[:], info.RecordDigest)
	}
	result := CatalogDiff{
		Changes: changes, FromCount: uint32(len(previousByID)), ToCount: uint32(len(current)),
		FromChecksum: hex.EncodeToString(fromChecksum[:]), ToChecksum: hex.EncodeToString(toChecksum[:]),
		PreviousRecords: previousByID, CurrentRecords: currentByID,
	}
	if err := ValidateCatalogTransition(result.FromChecksum, result.ToChecksum, result.FromCount, result.ToCount, result.Changes); err != nil {
		return CatalogDiff{}, err
	}
	return result, nil
}

func catalogRecordInfoFromBook(book *Book) (CatalogRecordInfo, error) {
	record, err := canonicalRecordForBook(book)
	if err != nil {
		return CatalogRecordInfo{}, err
	}
	canonical, err := stdjson.Marshal(record)
	if err != nil {
		return CatalogRecordInfo{}, err
	}
	// encoding/json normalizes invalid UTF-8. Keep the former round-trip
	// behavior for returned identity/path fields on that unusual input; the
	// overwhelmingly common valid strings need no JSON decode at all.
	validPaths := utf8.ValidString(record.LibraryUUID) && utf8.ValidString(record.CoverURL) && utf8.ValidString(record.CoverFingerprint)
	for _, file := range record.Formats {
		validPaths = validPaths && utf8.ValidString(file.DirectoryPath) && utf8.ValidString(file.Name)
	}
	if !validPaths {
		if err := stdjson.Unmarshal(canonical, record); err != nil {
			return CatalogRecordInfo{}, err
		}
	}
	return catalogRecordInfo(*record, canonical), nil
}

func catalogRecordInfoFromJSON(data []byte, stableID string) (CatalogRecordInfo, error) {
	record, err := canonicalRecordFromJSON(data, stableID)
	if err != nil {
		return CatalogRecordInfo{}, err
	}
	canonical, err := stdjson.Marshal(record)
	if err != nil {
		return CatalogRecordInfo{}, err
	}
	return catalogRecordInfo(*record, canonical), nil
}

func catalogRecordInfo(record canonicalRecord, canonical []byte) CatalogRecordInfo {
	digest := RecordDigest(record.ID, canonical)
	coverFingerprint := record.CoverFingerprint
	record.CoverFingerprint = ""
	metadataCanonical, _ := stdjson.Marshal(record)
	metadataDigest := RecordDigest(record.ID, metadataCanonical)
	formats := make([]string, 0, len(record.Formats))
	formatPaths := make([]string, 0, len(record.Formats))
	directorySet := make(map[string]struct{}, len(record.Formats)+1)
	if directory := strings.Trim(filepath.ToSlash(filepath.Dir(record.CoverURL)), "/"); directory != "" && directory != "." {
		directorySet[directory] = struct{}{}
	}
	for _, file := range record.Formats {
		if file != nil {
			// Every real book loader (pkg/calibre/calibre.go's SQLite and
			// JSON-unmarshal paths alike) writes DirectoryPath with a trailing
			// path separator. FormatDirectories must carry the same normalized
			// form as BookDirectories: its one production consumer,
			// cmd/memberChangeResult.go's addEndpointDirectory, requires
			// libraryflow.NormalizePath(directory) == directory, which strips
			// that trailing separator — the raw path never satisfies it, so
			// every touched book with a format file would always downgrade
			// the aggregate's exact-scope VFS invalidation to coarse.
			directory := strings.Trim(filepath.ToSlash(filepath.Clean(file.DirectoryPath)), "/")
			if directory != "" && directory != "." {
				formats = append(formats, directory)
				directorySet[directory] = struct{}{}
			}
			if file.Name != "" {
				formatPaths = append(formatPaths, filepath.ToSlash(filepath.Join(file.DirectoryPath, file.Name)))
			}
		}
	}
	directories := make([]string, 0, len(directorySet))
	for directory := range directorySet {
		directories = append(directories, directory)
	}
	sort.Strings(directories)
	sort.Strings(formatPaths)
	return CatalogRecordInfo{
		ID: record.ID, LibraryUUID: record.LibraryUUID, CoverURL: record.CoverURL,
		CoverFingerprint: coverFingerprint, FormatDirectories: formats, FormatPaths: formatPaths,
		BookDirectories: directories, RecordDigest: hex.EncodeToString(digest[:]),
		MetadataDigest: hex.EncodeToString(metadataDigest[:]),
	}
}

func strictDecodeJSON(data []byte, target any) error {
	dec := stdjson.NewDecoder(bytes.NewReader(data))
	dec.DisallowUnknownFields()
	if err := dec.Decode(target); err != nil {
		return err
	}
	var trailing any
	if err := dec.Decode(&trailing); err != io.EOF {
		if err == nil {
			return errors.New("multiple JSON values")
		}
		return err
	}
	return nil
}

func rejectDuplicateJSONKeys(data []byte) error {
	dec := stdjson.NewDecoder(bytes.NewReader(data))
	if err := consumeJSONValue(dec); err != nil {
		return err
	}
	if token, err := dec.Token(); err != io.EOF {
		if err == nil {
			return fmt.Errorf("trailing JSON token %v", token)
		}
		return err
	}
	return nil
}

func consumeJSONValue(dec *stdjson.Decoder) error {
	token, err := dec.Token()
	if err != nil {
		return err
	}
	delim, ok := token.(stdjson.Delim)
	if !ok {
		return nil
	}
	switch delim {
	case '{':
		seen := map[string]struct{}{}
		for dec.More() {
			keyToken, err := dec.Token()
			if err != nil {
				return err
			}
			key, ok := keyToken.(string)
			if !ok {
				return errors.New("object key is not a string")
			}
			if _, exists := seen[key]; exists {
				return fmt.Errorf("duplicate JSON field %q", key)
			}
			seen[key] = struct{}{}
			if err := consumeJSONValue(dec); err != nil {
				return err
			}
		}
		_, err = dec.Token()
		return err
	case '[':
		for dec.More() {
			if err := consumeJSONValue(dec); err != nil {
				return err
			}
		}
		_, err = dec.Token()
		return err
	default:
		return fmt.Errorf("unexpected JSON delimiter %q", delim)
	}
}
