package calibre

import (
	"strings"
	"unicode"
)

const maxSourceNameLen = 48

func SlugifySourceName(name string) string {
	var b strings.Builder
	pendingDash := false
	for _, r := range strings.ToLower(name) {
		switch {
		case r >= 'a' && r <= 'z', r >= '0' && r <= '9':
			if pendingDash && b.Len() > 0 {
				b.WriteByte('-')
			}
			pendingDash = false
			b.WriteRune(r)
		case unicode.IsSpace(r), r == '-', r == '_':
			pendingDash = true
		}
	}
	s := b.String()
	if len(s) > maxSourceNameLen {
		s = s[:maxSourceNameLen]
		s = strings.TrimRight(s, "-")
	}
	return s
}
