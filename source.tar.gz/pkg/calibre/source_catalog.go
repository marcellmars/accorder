package calibre

import (
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/url"
	"path"
	"path/filepath"
	"sort"
	"strings"
)

// SourceCatalogFile describes a Calibre-managed path, not an observation of
// bytes on disk. Stamp is a digest of the owning book's database change signals,
// never a payload checksum. Optional covers in legacy catalogs need not exist.
type SourceCatalogFile struct {
	Path     string `json:"path"`
	Size     int64  `json:"size"`
	Stamp    string `json:"stamp"`
	Optional bool   `json:"optional,omitempty"`
}

// ReadSourceCatalog reads only metadata.db. In particular it does not stat book
// directories or formats. The caller must guard database coherence around it.
// File-browser edits are outside the Calibre-managed change contract.
func ReadSourceCatalog(root string) ([]SourceCatalogFile, error) {
	abs, err := filepath.Abs(filepath.Join(root, "metadata.db"))
	if err != nil {
		return nil, err
	}
	uriPath := filepath.ToSlash(abs)
	if !strings.HasPrefix(uriPath, "/") {
		// A Windows drive path must be file:///C:/..., not a URI authority.
		uriPath = "/" + uriPath
	}
	u := url.URL{Scheme: "file", Path: uriPath, RawQuery: "mode=ro"}
	db, err := sql.Open("sqlite", u.String())
	if err != nil {
		return nil, err
	}
	defer db.Close()
	db.SetMaxOpenConns(1)
	// Older test/import catalogs may omit has_cover. Treat their cover as
	// optional/unknown; real Calibre's explicit zero avoids needless cover I/O.
	columns, err := db.Query("PRAGMA table_info(books)")
	if err != nil {
		return nil, err
	}
	hasCover := false
	for columns.Next() {
		var cid, notNull, pk int
		var name, typ string
		var defaultValue any
		if err := columns.Scan(&cid, &name, &typ, &notNull, &defaultValue, &pk); err != nil {
			columns.Close()
			return nil, err
		}
		hasCover = hasCover || name == "has_cover"
	}
	if err := columns.Err(); err != nil {
		columns.Close()
		return nil, err
	}
	columns.Close()
	coverColumn := "-1"
	if hasCover {
		coverColumn = "COALESCE(b.has_cover,0)"
	}
	rows, err := db.Query(`SELECT b.id, b.uuid, b.path, b.last_modified, ` + coverColumn + `,
        d.format, d.name, d.uncompressed_size
        FROM books b LEFT JOIN data d ON d.book=b.id ORDER BY b.id, d.format, d.name`)
	if err != nil {
		return nil, fmt.Errorf("read Calibre file catalog: %w", err)
	}
	defer rows.Close()
	type book struct {
		ID       int64
		UUID     string
		Path     string
		Modified string
		Cover    int
		Formats  []SourceCatalogFile
	}
	var current *book
	var files []SourceCatalogFile
	flush := func() error {
		if current == nil {
			return nil
		}
		data, err := json.Marshal(current)
		if err != nil {
			return err
		}
		digest := sha256.Sum256(data)
		stamp := hex.EncodeToString(digest[:])
		entries := current.Formats
		if current.Cover != 0 {
			entries = append(entries, SourceCatalogFile{Path: path.Join(current.Path, "cover.jpg"), Optional: current.Cover < 0})
		}
		for _, entry := range entries {
			entry.Stamp = stamp
			files = append(files, entry)
		}
		return nil
	}
	for rows.Next() {
		var b book
		var format, name sql.NullString
		var size sql.NullInt64
		if err := rows.Scan(&b.ID, &b.UUID, &b.Path, &b.Modified, &b.Cover, &format, &name, &size); err != nil {
			return nil, err
		}
		if b.Path == "" || b.Path == "." || strings.HasPrefix(b.Path, ".accorder/") || b.Path == ".accorder" || strings.HasPrefix(b.Path, ".caltrash/") || b.Path == ".caltrash" || strings.ContainsAny(b.Path, "\\\x00") || path.IsAbs(b.Path) || path.Clean(b.Path) != b.Path || b.Path == ".." || strings.HasPrefix(b.Path, "../") || strings.Contains(b.Path, ":") {
			return nil, fmt.Errorf("unsafe Calibre book directory %q", b.Path)
		}
		if current == nil || current.ID != b.ID {
			if err := flush(); err != nil {
				return nil, err
			}
			current = &b
		}
		if format.Valid {
			if !name.Valid || name.String == "" || strings.ContainsAny(name.String+format.String, "/\\\x00:") || format.String == "" || !size.Valid || size.Int64 < 0 {
				return nil, fmt.Errorf("invalid Calibre format for book %d", b.ID)
			}
			current.Formats = append(current.Formats, SourceCatalogFile{Path: path.Join(b.Path, name.String+"."+strings.ToLower(format.String)), Size: size.Int64})
		}
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}
	if err := flush(); err != nil {
		return nil, err
	}
	sort.Slice(files, func(i, j int) bool { return files[i].Path < files[j].Path })
	for i := 1; i < len(files); i++ {
		if files[i-1].Path == files[i].Path {
			return nil, fmt.Errorf("Calibre catalog contains duplicate file path %q", files[i].Path)
		}
	}
	return files, nil
}
