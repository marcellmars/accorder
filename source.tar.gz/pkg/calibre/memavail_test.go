//go:build linux

package calibre

import (
	"strings"
	"testing"
)

func TestParseMemAvailable(t *testing.T) {
	tests := []struct {
		name      string
		input     string
		wantBytes uint64
	}{
		{
			name: "standard_memavailable",
			input: `MemTotal:       16384000 kB
MemFree:         2000000 kB
MemAvailable:    8000000 kB
Buffers:          500000 kB
Cached:          3000000 kB
`,
			wantBytes: 8000000 * 1024,
		},
		{
			name: "fallback_no_memavailable",
			input: `MemTotal:       16384000 kB
MemFree:         2000000 kB
Buffers:          500000 kB
Cached:          3000000 kB
`,
			wantBytes: (2000000 + 500000 + 3000000) * 1024,
		},
		{
			name:      "empty_input",
			input:     "",
			wantBytes: 0,
		},
		{
			name: "malformed_line",
			input: `MemAvailable: notanumber kB
`,
			wantBytes: 0,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := parseMemAvailable(strings.NewReader(tt.input))
			if got != tt.wantBytes {
				t.Errorf("parseMemAvailable() = %d, want %d", got, tt.wantBytes)
			}
		})
	}
}

func TestMemAvailable(t *testing.T) {

	// On Linux, MemAvailable should return a non-zero value (the test host has memory).
	// This is a smoke test — the exact value doesn't matter.
	avail := MemAvailable()
	if avail == 0 {
		t.Skip("MemAvailable returned 0 — may be running on a non-Linux platform or /proc/meminfo unavailable")
	}
	t.Logf("MemAvailable = %d bytes (%.1f GB)", avail, float64(avail)/1e9)
}
