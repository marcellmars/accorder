package calibre

import (
	"context"
	"os/exec"
	"strconv"
	"strings"
	"testing"
)

func ctx() context.Context { return context.Background() }

// trackedRow renders one calibredb `list --for-machine` row as buildTrackedMap
// parses it (zoteroSync.go:49-63).
func trackedRow(id int, title, itemKey, rev, src, export string, formats ...string) string {
	q := func(ss []string) string {
		out := make([]string, 0, len(ss))
		for _, s := range ss {
			out = append(out, `"`+s+`"`)
		}
		return strings.Join(out, ",")
	}
	return `{"id":` + strconv.Itoa(id) + `,"title":"` + title + `","identifiers":{"zotero":"` + itemKey +
		`","zotero_rev":"` + rev + `","zotero_src":"` + src + `","zotero_export":"` + export +
		`"},"formats":[` + q(formats) + `]}`
}

func noConfirm(string) bool  { return false }
func yesConfirm(string) bool { return true }

// ═══════════════════════════════════════════════════════════════════
// buildTrackedMap (zoteroSync.go:42-65)
// ═══════════════════════════════════════════════════════════════════

func TestBuildTrackedMap(t *testing.T) {
	f := newFakeCalibre(t).reply("list", `[`+
		trackedRow(1, "Kept", "ZK1", "T1+h1", "mine", "EXP1", "/lib/Kept.PDF", "/lib/Kept.epub", "/lib/Kept.pdf")+`,`+
		`{"id":2,"title":"Untracked","identifiers":{"isbn":"123"},"formats":["/lib/U.pdf"]}`+
		`]`)

	tracked, err := buildTrackedMap(ctx(), f.exe())
	if err != nil {
		t.Fatalf("buildTrackedMap: %v", err)
	}

	if len(tracked) != 1 {
		t.Fatalf("got %d tracked books, want 1 — a row without a zotero identifier must be skipped (zoteroSync.go:51)", len(tracked))
	}
	tb := tracked["ZK1"]
	if tb.bookID != 1 || tb.rev != "T1+h1" || tb.src != "mine" || tb.export != "EXP1" {
		t.Errorf("trackedBook = %+v", tb)
	}
	// extractExts lowercases, dedupes and sorts (zoteroSync.go:32-40).
	if got := strings.Join(tb.formats, ","); got != ".epub,.pdf" {
		t.Errorf("formats = %q, want %q", got, ".epub,.pdf")
	}
}

// ═══════════════════════════════════════════════════════════════════
// SyncEntries — the convergence engine (zoteroSync.go:114-154)
//
// Each case asserts the calibredb call SEQUENCE alongside ImportStats.
// The sequence is the behavior; the stats are a summary of it.
// ═══════════════════════════════════════════════════════════════════

func TestSyncEntries_FreshAdd(t *testing.T) {
	e := entryWith(t, "ZK1", "T1", []string{"a.pdf", "a.epub"},
		map[string]string{"a.pdf": "body", "a.epub": "other"})
	e.Tags = []string{"tag1", "tag2"}
	e.Publisher = "A Press"
	e.Identifiers = map[string]string{"doi": "10.1/x"}

	f := newFakeCalibre(t).
		reply("list", `[]`).
		reply("add", "Added book ids: 42\n").
		reply("set_metadata", "ok").
		reply("add_format", "ok")

	stats, err := SyncEntries(ctx(), f.exe(), []ImportEntry{e},
		Bundle{Alias: "mine", ExportID: "EXP1"}, false, noConfirm)
	if err != nil {
		t.Fatalf("SyncEntries: %v", err)
	}

	if stats.Added != 1 || stats.Total != 1 {
		t.Errorf("stats = %+v, want 1 added of 1", stats)
	}
	// Files[0] goes in via `add`; every remaining file via `add_format`
	// (zoteroSync.go:159,172-176).
	f.assertSubs("list", "add", "set_metadata", "add_format")

	args := f.argsOf("set_metadata", 0)
	ids, ok := flagValue(args, "identifiers")
	if !ok {
		t.Fatalf("set_metadata carried no identifiers field: %v", args)
	}
	for _, want := range []string{"zotero:ZK1", "zotero_rev:" + e.Rev(), "zotero_src:mine", "zotero_export:EXP1", "doi:10.1/x"} {
		if !strings.Contains(ids, want) {
			t.Errorf("identifiers %q missing %q", ids, want)
		}
	}
	if v, _ := flagValue(args, "tags"); v != "tag1,tag2" {
		t.Errorf("tags = %q, want %q", v, "tag1,tag2")
	}
	if _, present := flagValue(args, "series"); present {
		t.Error("empty optional field 'series' should be omitted (zoteroSync.go:246)")
	}
}

// TestSyncEntries_UnchangedReimport_IssuesNoWrites is the evidence behind the
// zotero-calibre-import retrospective's claim that a no-op re-import is O(1)
// per item: ONE calibredb list, and nothing else. Not one set_metadata, not
// one add_format, no file reads.
func TestSyncEntries_UnchangedReimport_IssuesNoWrites(t *testing.T) {
	e := entryWith(t, "ZK1", "T1", []string{"a.pdf"}, map[string]string{"a.pdf": "body"})

	f := newFakeCalibre(t).reply("list", `[`+
		trackedRow(7, "Title ZK1", "ZK1", e.Rev(), "mine", "EXP1", "/lib/a.pdf")+`]`)

	stats, err := SyncEntries(ctx(), f.exe(), []ImportEntry{e},
		Bundle{Alias: "mine", ExportID: "EXP1"}, false, noConfirm)
	if err != nil {
		t.Fatalf("SyncEntries: %v", err)
	}

	if stats.Unchanged != 1 || stats.Added != 0 || stats.Updated != 0 {
		t.Errorf("stats = %+v, want 1 unchanged", stats)
	}
	f.assertSubs("list")
}

func TestSyncEntries_MetadataOnlyUpdate_DoesNotTouchFormats(t *testing.T) {
	e := entryWith(t, "ZK1", "T2", []string{"a.pdf"}, map[string]string{"a.pdf": "body"})

	f := newFakeCalibre(t).
		reply("list", `[`+trackedRow(7, "Title ZK1", "ZK1", "T1+"+e.FileHash(), "mine", "EXP1", "/lib/a.pdf")+`]`).
		reply("set_metadata", "ok")

	stats, err := SyncEntries(ctx(), f.exe(), []ImportEntry{e},
		Bundle{Alias: "mine", ExportID: "EXP1"}, false, noConfirm)
	if err != nil {
		t.Fatalf("SyncEntries: %v", err)
	}

	if stats.Updated != 1 {
		t.Errorf("stats = %+v, want 1 updated", stats)
	}
	// The hash half is unchanged, so updateEntry takes its metadata-only branch
	// and leaves the (potentially large) format files alone (zoteroSync.go:196-198).
	f.assertSubs("list", "set_metadata")
}

func TestSyncEntries_FilesChanged_ResyncsFormats(t *testing.T) {
	e := entryWith(t, "ZK1", "T2", []string{"a.pdf"}, map[string]string{"a.pdf": "new body"})

	f := newFakeCalibre(t).
		reply("list", `[`+trackedRow(7, "Title ZK1", "ZK1", "T1+stalehash000000", "mine", "EXP1",
			"/lib/a.pdf", "/lib/a.epub")+`]`).
		reply("set_metadata", "ok").
		reply("add_format", "ok").
		reply("remove_format", "ok")

	stats, err := SyncEntries(ctx(), f.exe(), []ImportEntry{e},
		Bundle{Alias: "mine", ExportID: "EXP1"}, false, noConfirm)
	if err != nil {
		t.Fatalf("SyncEntries: %v", err)
	}

	if stats.Updated != 1 {
		t.Errorf("stats = %+v, want 1 updated", stats)
	}
	f.assertSubs("list", "set_metadata", "add_format", "remove_format")

	// The epub the export no longer carries is dropped, uppercased and undotted
	// the way calibredb names formats (zoteroSync.go:211).
	if args := f.argsOf("remove_format", 0); !contains(strings.Join(args, " "), "EPUB") {
		t.Errorf("remove_format args = %v, want the vanished EPUB", args)
	}
}

// TestSyncEntries_AddDuplicateRecovery pins the mechanism that actually keeps
// every created book tracked.
//
// addEntry has a branch (zoteroSync.go:161) testing for the string
// "duplicate detected" — which nothing in this repository ever produces. It is
// dead code (defect D1 of workflow 2026-08-24_zotero-import-sync-coverage).
// What really happens is that Add recognises
// calibredb's own marker, recovers the id via findBookIDByTitle
// (calibreExec.go:210-217), and returns it with a nil error — so
// setEntryMetadata still runs and the zotero identifiers still get written.
//
// If the dead branch ever became live it would `return nil` before writing
// identifiers while SyncEntries still incremented stats.Added — reporting a
// book as added that no later run could ever find. This test fails if that
// path is reintroduced.
func TestSyncEntries_AddDuplicateRecovery_StillWritesIdentifiers(t *testing.T) {
	e := entryWith(t, "ZK1", "T1", []string{"a.pdf"}, map[string]string{"a.pdf": "body"})

	f := newFakeCalibre(t).
		replySeq("list",
			`[]`,                              // buildTrackedMap: nothing tracked yet
			`[{"id":42,"title":"Title ZK1"}]`, // findBookIDByTitle, after the duplicate
		).
		on("add", func(cmd *exec.Cmd, _ int) ([]byte, error) {
			// calibredb writes its duplicate warning to stderr and prints no
			// "Added book ids:" line. Only this path's cmd.Stderr is inspected
			// by production code (study F10).
			if cmd.Stderr != nil {
				_, _ = cmd.Stderr.Write([]byte("The following books were not added as they already exist in the database\n"))
			}
			return []byte("    a.pdf\n"), nil
		}).
		reply("set_metadata", "ok")

	stats, err := SyncEntries(ctx(), f.exe(), []ImportEntry{e},
		Bundle{Alias: "mine", ExportID: "EXP1"}, false, noConfirm)
	if err != nil {
		t.Fatalf("SyncEntries: %v", err)
	}

	if stats.Added != 1 {
		t.Errorf("stats = %+v, want 1 added", stats)
	}
	if f.count("set_metadata") != 1 {
		t.Fatalf("set_metadata ran %d times, want 1 — a duplicate-recovered book MUST still get its zotero identifiers, or no later run can find it",
			f.count("set_metadata"))
	}
	if ids, _ := flagValue(f.argsOf("set_metadata", 0), "identifiers"); !strings.Contains(ids, "zotero:ZK1") {
		t.Errorf("identifiers %q missing zotero:ZK1", ids)
	}
	// set_metadata must target the id recovered by findBookIDByTitle, not 0.
	if args := f.argsOf("set_metadata", 0); !contains(strings.Join(args, " "), "42") {
		t.Errorf("set_metadata args = %v, want book id 42 from the title lookup", args)
	}
}

// ═══════════════════════════════════════════════════════════════════
// Prune (zoteroSync.go:278-303)
// ═══════════════════════════════════════════════════════════════════

func syncWithOrphan(t *testing.T, prune bool, confirm func(string) bool) (*fakeCalibre, ImportStats) {
	t.Helper()
	e := entryWith(t, "ZK1", "T1", []string{"a.pdf"}, map[string]string{"a.pdf": "body"})

	f := newFakeCalibre(t).
		reply("list", `[`+
			trackedRow(7, "Title ZK1", "ZK1", e.Rev(), "mine", "EXP1", "/lib/a.pdf")+`,`+
			trackedRow(8, "Dropped", "GONE", "T0+h0", "mine", "EXP1", "/lib/b.pdf")+`]`).
		reply("remove", "ok")

	stats, err := SyncEntries(ctx(), f.exe(), []ImportEntry{e},
		Bundle{Alias: "mine", ExportID: "EXP1"}, prune, confirm)
	if err != nil {
		t.Fatalf("SyncEntries: %v", err)
	}
	return f, stats
}

func TestSyncEntries_PruneConfirmed_Removes(t *testing.T) {
	f, stats := syncWithOrphan(t, true, yesConfirm)

	if stats.Removed != 1 {
		t.Errorf("stats = %+v, want 1 removed", stats)
	}
	if stats.Orphaned != 0 {
		t.Errorf("Orphaned = %d; it is only counted when prune is OFF (zoteroSync.go:150)", stats.Orphaned)
	}
	f.assertSubs("list", "remove")
}

func TestSyncEntries_PruneDeclined_RemovesNothing(t *testing.T) {
	f, stats := syncWithOrphan(t, true, noConfirm)

	if stats.Removed != 0 {
		t.Errorf("stats = %+v, want 0 removed when the operator declines", stats)
	}
	if f.count("remove") != 0 {
		t.Error("declining the prompt must issue no calibredb remove")
	}
}

func TestSyncEntries_PruneOff_CountsOrphansOnly(t *testing.T) {
	f, stats := syncWithOrphan(t, false, yesConfirm)

	if stats.Orphaned != 1 {
		t.Errorf("stats = %+v, want 1 orphaned", stats)
	}
	if stats.Removed != 0 || f.count("remove") != 0 {
		t.Error("prune off must never remove")
	}
	f.assertSubs("list")
}

// ═══════════════════════════════════════════════════════════════════
// StampDefaultCovers (zoteroSync.go:305-342)
// ═══════════════════════════════════════════════════════════════════

func TestStampDefaultCovers_OnlyCoverlessBooks(t *testing.T) {
	f := newFakeCalibre(t).
		reply("list", `[{"id":1,"cover":"/lib/1/cover.jpg"},{"id":2,"cover":""},{"id":3,"cover":""}]`).
		reply("set_metadata", "ok")

	if err := StampDefaultCovers(ctx(), f.exe()); err != nil {
		t.Fatalf("StampDefaultCovers: %v", err)
	}

	if f.count("set_metadata") != 2 {
		t.Errorf("set_metadata ran %d times, want 2 (books 2 and 3)", f.count("set_metadata"))
	}
	if v, ok := flagValue(f.argsOf("set_metadata", 0), "cover"); !ok || v == "" {
		t.Error("set_metadata carried no cover path")
	}
}

func TestStampDefaultCovers_AllCovered_IsNoOp(t *testing.T) {
	f := newFakeCalibre(t).reply("list", `[{"id":1,"cover":"/lib/1/cover.jpg"}]`)

	if err := StampDefaultCovers(ctx(), f.exe()); err != nil {
		t.Fatalf("StampDefaultCovers: %v", err)
	}
	f.assertSubs("list")
}

// A per-book failure is warned and skipped, not fatal (zoteroSync.go:336-338).
func TestStampDefaultCovers_SetMetadataFailureIsNotFatal(t *testing.T) {
	f := newFakeCalibre(t).
		reply("list", `[{"id":2,"cover":""},{"id":3,"cover":""}]`).
		on("set_metadata", func(*exec.Cmd, int) ([]byte, error) {
			return nil, exec.ErrNotFound
		})

	if err := StampDefaultCovers(ctx(), f.exe()); err != nil {
		t.Fatalf("StampDefaultCovers should tolerate per-book failures, got: %v", err)
	}
	if f.count("set_metadata") != 2 {
		t.Errorf("set_metadata ran %d times, want 2 — a failure must not abort the loop", f.count("set_metadata"))
	}
}
