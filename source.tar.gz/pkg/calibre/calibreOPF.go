package calibre

import (
	"encoding/xml"
	"strings"
)

type CreatorOPF struct {
	Role string `xml:"opf:role,attr"`
	Name string `xml:",chardata"`
}

type IdentifierOPF struct {
	Scheme string `xml:"opf:scheme,attr"`
	Id     string `xml:"id,attr"` // Calibre has two internal Ids: calibre_id and uuid_id
	Value  string `xml:",chardata"`
}

type BookOPF struct {
	XMLName          xml.Name `xml:"package"`
	Version          string   `xml:"version,attr"`
	Xmlns            string   `xml:"xmlns,attr"`
	UniqueIdentifier string   `xml:"unique-identifier,attr"`
	Metadata         struct {
		DC          string `xml:"dc,attr"`
		OPF         string `xml:"opf,attr"`
		Identifiers []struct {
			Scheme string `xml:"scheme,attr"`
			Id     string `xml:"id,attr"` // Calibre has two internal Ids: calibre_id and uuid_id
			Value  string `xml:",chardata"`
		} `xml:"identifier"`
		Title    string `xml:"title"`
		Creators []struct {
			Role string `xml:"role,attr"`
			Name string `xml:",chardata"`
		} `xml:"creator"`
		Published   string `xml:"date"`
		Description string `xml:"description"`
		Publisher   string `xml:"publisher"`
		Languages   []struct {
			Language string `xml:",chardata"`
		} `xml:"language"`
		Tags []struct {
			Tag string `xml:",chardata"`
		} `xml:"subject"`
		Meta []struct {
			Content string `xml:"content,attr"`
			Name    string `xml:"name,attr"`
		} `xml:"meta"`
	} `xml:"metadata"`
}

// TitleSort returns if Calibre processed Title for sorting order
func (book BookOPF) TitleSort() string {
	for _, meta := range book.Metadata.Meta {
		if meta.Name == "calibre:title_sort" {
			return meta.Content
		}
	}
	return ""
}

// LastModified is made from timestamp because calibre
// doesn't provide last_modified in OPF files
func (book BookOPF) LastModified() string {
	lastModified := ""
	for _, meta := range book.Metadata.Meta {
		if meta.Name == "calibre:timestamp" {
			lastModified = meta.Content
		}
	}
	return lastModified
}

// Authors parses creators and give back authors
func (book BookOPF) Authors() []string {
	authors := []string{}
	if len(book.Metadata.Creators) > 0 {
		for _, author := range book.Metadata.Creators {
			if author.Role == "aut" {
				authors = append(authors, author.Name)
			}
		}
	}
	return authors
}

// Tags gets a list of tags from Subject nodes in OPF
func (book BookOPF) Tags() []string {
	tags := []string{}
	for _, tag := range book.Metadata.Tags {
		tags = append(tags, tag.Tag)
	}
	return tags
}

// Languages gets a list of languages
func (book BookOPF) Languages() []string {
	languages := []string{}
	for _, l := range book.Metadata.Languages {
		languages = append(languages, l.Language)
	}
	return languages
}

// Identifiers returns list of identifiers like ISBN, DOI, Google, Amazon...
func (book BookOPF) Identifiers() []*Identifier {
	identifiers := []*Identifier{}
	for _, i := range book.Metadata.Identifiers {
		if i.Id == "" {
			identifiers = append(identifiers, &Identifier{
				Scheme: strings.ToLower(i.Scheme),
				Code:   i.Value,
			})
		}
	}
	return identifiers
}

// UUID returns calibre's book uuid...
func (book BookOPF) UUID() string {
	for _, i := range book.Metadata.Identifiers {
		if i.Id == "uuid_id" {
			return i.Value
		}
	}
	return ""
}
