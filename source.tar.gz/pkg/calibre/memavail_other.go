//go:build !linux

package calibre

func MemAvailable() uint64 {
	return 0
}
