package calibre

import (
	"fmt"
	"io"
	"io/fs"
	"log"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"github.com/goccy/go-json"
)

func RenderBooksBundle(destDir string, books []*Book) error {
	if err := os.MkdirAll(filepath.Join(destDir, "static"), 0755); err != nil {
		return fmt.Errorf("bundle: mkdir: %w", err)
	}

	copyEmbResourcesTo(destDir)

	sort.Sort(sort.Reverse(CalibreBooksByLastModified(books)))

	writeBundleDataJS(destDir, books)

	return nil
}

func copyEmbResourcesTo(destDir string) {
	_ = fs.WalkDir(embResources, ".", func(fsPath string, fsEntry fs.DirEntry, walkErr error) error {
		if walkErr != nil {
			return walkErr
		}
		if fsPath == "." || fsPath == "embResources" {
			return nil
		}
		destFsPath := strings.ReplaceAll(fsPath, "embResources/", "")
		if fsEntry.IsDir() {
			if err := os.MkdirAll(filepath.Join(destDir, destFsPath), 0755); err != nil {
				log.Printf("bundle: mkdir %s: %v", destFsPath, err)
			}
			return nil
		}

		embFile, err := embResources.Open(fsPath)
		if err != nil {
			log.Printf("bundle: open embedded %s: %v", fsPath, err)
			return nil
		}
		defer embFile.Close()

		newFile, err := os.Create(filepath.Join(destDir, destFsPath))
		if err != nil {
			log.Printf("bundle: create %s: %v", destFsPath, err)
			return nil
		}
		defer newFile.Close()

		if _, err := io.Copy(newFile, embFile); err != nil {
			log.Printf("bundle: copy %s: %v", destFsPath, err)
		}
		return nil
	})
}

func writeBundleDataJS(destDir string, books []*Book) {
	staticDir := filepath.Join(destDir, "static")

	writeDataJS := func(name string, d DataJS) {
		f, err := os.Create(filepath.Join(staticDir, name))
		if err != nil {
			log.Printf("bundle: create %s: %v", name, err)
			return
		}
		defer f.Close()
		b, _ := json.Marshal(&d)
		prefix := strings.TrimSuffix(strings.ToUpper(strings.TrimSuffix(name, ".js")), "")
		prefix = "CALIBRE_BOOKS" + strings.TrimPrefix(strings.TrimSuffix(name, ".js"), "data")
		f.Write([]byte(prefix + "="))
		f.Write(b)
	}

	endB := 24
	if endB > len(books) {
		endB = len(books)
	}
	writeDataJS("data1.js", DataJS{Portable: true, Total: len(books), Books: books[0:endB]})

	for i := 2; i <= 8; i++ {
		d := DataJS{Portable: true, Books: []*Book{}}
		if i == 8 {
			d.Total = len(books)
			if endB < len(books) {
				d.Books = books[endB:]
			}
		}
		writeDataJS(fmt.Sprintf("data%d.js", i), d)
	}
}

// CopyBrowseUIAssets writes the embedded browse-session UI shell
// (BROWSE_LIBRARY.html plus static/js, static/css, static/fonts,
// static/favicons) into destDir. It deliberately skips static/data1.js,
// static/index.html and BUNDLE_SOURCE.md.
//
// A friend's browse session syncs only catalog DATA (data1.js,
// library_index.zst) from the librarian; the UI shell must come from the
// friend's own binary so the batch-flow frontend matches this binary's
// backend_rpc handlers. Without this, a librarian on an older accorder
// would serve a stale bundle that has no batch UI.
func CopyBrowseUIAssets(destDir string) error {
	skip := map[string]bool{
		"embResources/static/data1.js":         true,
		"embResources/static/index.html":       true,
		"embResources/static/BUNDLE_SOURCE.md": true,
	}
	return fs.WalkDir(embResources, ".", func(fsPath string, fsEntry fs.DirEntry, walkErr error) error {
		if walkErr != nil {
			return walkErr
		}
		if fsPath == "." || fsPath == "embResources" || skip[fsPath] {
			return nil
		}
		destFsPath := strings.ReplaceAll(fsPath, "embResources/", "")
		dst := filepath.Join(destDir, destFsPath)
		if fsEntry.IsDir() {
			return os.MkdirAll(dst, 0755)
		}
		embFile, err := embResources.Open(fsPath)
		if err != nil {
			return fmt.Errorf("open embedded %s: %w", fsPath, err)
		}
		defer embFile.Close()
		if err := os.MkdirAll(filepath.Dir(dst), 0755); err != nil {
			return err
		}
		newFile, err := os.Create(dst)
		if err != nil {
			return fmt.Errorf("create %s: %w", destFsPath, err)
		}
		defer newFile.Close()
		if _, err := io.Copy(newFile, embFile); err != nil {
			return fmt.Errorf("copy %s: %w", destFsPath, err)
		}
		return nil
	})
}
