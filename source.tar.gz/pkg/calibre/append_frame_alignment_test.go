package calibre

import (
	"fmt"
	"path/filepath"
	"testing"
)

func TestAppendFrameAlignment(t *testing.T) {
	dir := t.TempDir()
	gen := [16]byte{0x5a, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16}
	idxPath := filepath.Join(dir, "appended")

	var base, delta1, delta2 []*Book
	for i := 0; i < 20; i++ {
		base = append(base, equivBook(fmt.Sprintf("b%d", i), fmt.Sprintf("Book %d", i), "Karl Marx", "marxism"))
	}
	for i := 0; i < 5; i++ {
		delta1 = append(delta1, equivBook(fmt.Sprintf("c%d", i), fmt.Sprintf("Second %d", i), "Karl Kautsky", "theory"))
		delta2 = append(delta2, equivBook(fmt.Sprintf("d%d", i), fmt.Sprintf("Third %d", i), "Karl Popper", "philosophy"))
	}

	baseJSONL := filepath.Join(dir, "base.jsonl")
	writeBooks(t, baseJSONL, base)
	ms := &MotwSearch{JsonlPath: baseJSONL, IndexPath: idxPath, BaseGeneration: &gen}
	bidx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(bidx); err != nil {
		t.Fatal(err)
	}
	for i, delta := range [][]*Book{delta1, delta2} {
		dj := filepath.Join(dir, fmt.Sprintf("delta%d.jsonl", i))
		writeBooks(t, dj, delta)
		dms := &MotwSearch{JsonlPath: dj, IndexPath: idxPath, BaseGeneration: &gen}
		didx, err := dms.BuildIndex()
		if err != nil {
			t.Fatal(err)
		}
		if err := dms.AppendToFile(didx, nil); err != nil {
			t.Fatal(err)
		}
	}

	mf, err := ReadExistingManifest(idxPath)
	if err != nil {
		t.Fatal(err)
	}
	if len(mf.Regions) != 3 {
		t.Fatalf("regions = %d, want 3 (base + 2 deltas)", len(mf.Regions))
	}

	if got, want := mf.Regions[1].SearchIndexOff, mf.TypeaheadOff+mf.TypeaheadLen; got != want {
		t.Fatalf("delta1 starts at %d, want %d (base typeahead end) — stale base manifest not truncated", got, want)
	}
	if got, want := mf.Regions[2].SearchIndexOff, mf.Regions[1].TypeaheadOff+mf.Regions[1].TypeaheadLen; got != want {
		t.Fatalf("delta2 starts at %d, want %d (delta1 typeahead end) — stale manifest v1 not truncated", got, want)
	}

	mcd, err := ExtractMemberContainer(idxPath)
	if err != nil {
		t.Fatalf("ExtractMemberContainer(appended): %v", err)
	}
	for i, r := range mcd.Regions {
		if r.TypeaheadLen != 0 {
			t.Fatalf("region %d still has per-region typeahead after extraction", i)
		}
	}
	if len(mcd.Typeahead) == 0 {
		t.Fatal("extracted member typeahead is empty — global+regional merge missing")
	}
	wantSpan := mf.Regions[2].TypeaheadOff + mf.Regions[2].TypeaheadLen
	if got := memberUncompressedSize(mcd); got != wantSpan {
		t.Fatalf("kept span = %d, want %d (final manifest start) — trailing manifest not cut", got, wantSpan)
	}

	aggPath := filepath.Join(dir, "agg")
	if err := ComposeAggregate(aggPath, []*MemberContainerData{mcd}, gen, 1, ComposeOpts{}); err != nil {
		t.Fatalf("ComposeAggregate: %v", err)
	}
	all := append(append(append([]*Book{}, base...), delta1...), delta2...)
	fullPath := buildFullIndex(t, t.TempDir(), all)
	cases := []struct {
		field  SearchField
		prefix string
	}{
		{FieldAuthor, "ka"}, {FieldAuthor, "marx"}, {FieldAuthor, "popp"},
		{FieldTag, "theo"}, {FieldTag, "phil"},
	}
	for _, tc := range cases {
		got := suggestMap(t, aggPath, tc.field, tc.prefix)
		want := suggestMap(t, fullPath, tc.field, tc.prefix)
		if diff, ok := mapsEqual(got, want); !ok {
			t.Fatalf("aggregate Suggest %s/%q != full rebuild: %s", tc.field, tc.prefix, diff)
		}
	}
}
