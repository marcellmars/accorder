package calibre

// Spike: can `accorder` recreate library_index.zst from only its display-JSONL?
//
// Uses the REAL live aggregate downloaded from
// https://library.memoryoftheworld.org/static/library_index.zst.
//
//   AGG_INDEX=/tmp/agg/library_index \
//     go test ./pkg/calibre/ -run TestSpikeAggregateReconstruct -v -timeout 30m
//
// (AGG_INDEX is the path WITHOUT the .zst suffix.)

import (
	"bytes"
	"encoding/hex"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/klauspost/compress/zstd"
)

func TestSpikeAggregateReconstruct(t *testing.T) {
	orig := os.Getenv("AGG_INDEX")
	if orig == "" {
		t.Skip("set AGG_INDEX=/path/to/library_index (no .zst) to run")
	}
	var rep strings.Builder
	logf := func(format string, a ...any) {
		line := fmt.Sprintf(format, a...)
		t.Log(line)
		rep.WriteString(line + "\n")
	}
	defer func() {
		if p := os.Getenv("REPORT"); p != "" {
			_ = os.WriteFile(p, []byte(rep.String()), 0o644)
		}
	}()

	origZst := orig + ".zst"
	oi, err := os.Stat(origZst)
	if err != nil {
		t.Fatalf("stat orig: %v", err)
	}

	mf, err := ReadExistingManifest(orig)
	if err != nil {
		t.Fatalf("ReadExistingManifest(orig): %v", err)
	}
	logf("ORIGINAL manifest:")
	logf("  NumBooks=%d NumSegments=%d regions=%d generation=%d",
		mf.NumBooks, mf.NumSegments, len(mf.Regions), mf.Generation)
	logf("  baseGeneration=%s", hex.EncodeToString(mf.BaseGeneration[:]))
	logf("  tombstones=%d entityProvenance=%d recencyIndex=%d typeaheadLen=%d",
		len(mf.Tombstones), len(mf.EntityProvenance), len(mf.RecencyIndex), mf.TypeaheadLen)
	for i, r := range mf.Regions {
		logf("  region[%d] dictID=%d searchLen=%d displayLen=%d postingsLen=%d docLenLen=%d fstLen=%d fpLen=%d",
			i, r.DictID, r.SearchIndexLen, r.DisplayIndexLen, r.PostingsLen, r.DocLengthsLen, r.FSTLen, r.FingerprintsLen)
	}

	// --- 1. Extract the display-JSONL and measure the standalone payload ---
	t0 := time.Now()
	jsonl, err := ReadDisplayJSONL(orig)
	if err != nil {
		t.Fatalf("ReadDisplayJSONL: %v", err)
	}
	logf("extracted display-JSONL: %d bytes raw (in %s)", len(jsonl), time.Since(t0).Round(time.Millisecond))

	enc, _ := zstd.NewWriter(nil, zstd.WithEncoderLevel(zstd.SpeedBestCompression))
	jsonlZst := enc.EncodeAll(jsonl, nil)
	_ = enc.Close()

	ratio := float64(len(jsonlZst)) / float64(oi.Size())
	logf("SAVINGS: full.zst=%d  jsonl-only.zst=%d  jsonl/full=%.1f%%  saving=%.1f%%",
		oi.Size(), len(jsonlZst), ratio*100, (1-ratio)*100)

	// --- 2. Reconstruct, pinning everything we can carry over ---
	dir := t.TempDir()
	jsonlPath := filepath.Join(dir, "books.jsonl")
	if err := os.WriteFile(jsonlPath, jsonl, 0o644); err != nil {
		t.Fatalf("write jsonl: %v", err)
	}
	rebuild := filepath.Join(dir, "library_index")

	baseGen := mf.BaseGeneration
	dictID := uint32(0)
	if len(mf.Regions) > 0 {
		dictID = mf.Regions[0].DictID
	}
	ms := &MotwSearch{
		JsonlPath:            jsonlPath,
		IndexPath:            rebuild,
		BaseGeneration:       &baseGen,
		StartGeneration:      mf.Generation,
		IndexAggregateFields: true, // aggregate indexes _id + library_uuid
		DictID:               dictID,
		ChunkSize:            int(mf.ChunkSize),
	}

	tb := time.Now()
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex: %v", err)
	}
	buildDur := time.Since(tb)
	tc := time.Now()
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatalf("CompressToFile: %v", err)
	}
	compDur := time.Since(tc)

	ri, err := os.Stat(rebuild + ".zst")
	if err != nil {
		t.Fatalf("stat rebuilt: %v", err)
	}
	logf("REBUILT: %d bytes (orig %d, delta %+d) build=%s compress=%s total=%s",
		ri.Size(), oi.Size(), ri.Size()-oi.Size(),
		buildDur.Round(time.Millisecond), compDur.Round(time.Millisecond),
		(buildDur + compDur).Round(time.Millisecond))

	// --- 3. Byte-identity check ---
	origBytes, err := os.ReadFile(origZst)
	if err != nil {
		t.Fatalf("read orig bytes: %v", err)
	}
	rebuiltBytes, err := os.ReadFile(rebuild + ".zst")
	if err != nil {
		t.Fatalf("read rebuilt bytes: %v", err)
	}
	if bytes.Equal(origBytes, rebuiltBytes) {
		logf("BYTE-IDENTICAL: yes — reconstruction is bit-for-bit identical")
	} else {
		n := len(origBytes)
		if len(rebuiltBytes) < n {
			n = len(rebuiltBytes)
		}
		firstDiff := -1
		for i := 0; i < n; i++ {
			if origBytes[i] != rebuiltBytes[i] {
				firstDiff = i
				break
			}
		}
		logf("BYTE-IDENTICAL: NO — first diff at offset %d of %d (%.4f%% in); size delta %+d",
			firstDiff, len(origBytes), 100*float64(firstDiff)/float64(len(origBytes)), len(rebuiltBytes)-len(origBytes))
	}

	// --- 4. Display-plane round-trip (does the JSONL itself come back identical?) ---
	jsonl2, err := ReadDisplayJSONL(rebuild)
	if err != nil {
		t.Fatalf("ReadDisplayJSONL(rebuilt): %v", err)
	}
	logf("DISPLAY round-trip identical: %v (orig %d bytes, rebuilt %d bytes)",
		bytes.Equal(jsonl, jsonl2), len(jsonl), len(jsonl2))

	// --- 5. Manifest field comparison ---
	mf2, err := ReadExistingManifest(rebuild)
	if err != nil {
		t.Fatalf("ReadExistingManifest(rebuilt): %v", err)
	}
	logf("REBUILT manifest: numBooks=%d segs=%d regions=%d gen=%d tombstones=%d entityProv=%d recency=%d typeaheadLen=%d",
		mf2.NumBooks, mf2.NumSegments, len(mf2.Regions), mf2.Generation,
		len(mf2.Tombstones), len(mf2.EntityProvenance), len(mf2.RecencyIndex), mf2.TypeaheadLen)
	if len(mf2.Regions) > 0 {
		r := mf2.Regions[0]
		logf("  region[0] dictID=%d searchLen=%d displayLen=%d postingsLen=%d docLenLen=%d fstLen=%d fpLen=%d",
			r.DictID, r.SearchIndexLen, r.DisplayIndexLen, r.PostingsLen, r.DocLengthsLen, r.FSTLen, r.FingerprintsLen)
	}

	fmt.Fprintln(os.Stdout, "spike-aggregate-reconstruct: done")
}
