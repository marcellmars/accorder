package calibre

// Phase-0 spike for WF3 (fedlib-operations): per-region BM25 vs global-IDF.
//
// Quantifies ranking divergence when BM25 scores use per-region term stats
// (each member's region has its own N and DF) versus a global-IDF baseline
// (aggregated N and DF across all regions). This runs on synthetic data —
// no container, no files, pure numerical test on the exported bm25/bm25IDF
// functions.
//
// The study (Phase 7) asks: is per-region BM25 acceptable quality? This test
// measures the ordering divergence for a concrete worst-case scenario (a rare
// term in one region is common in another).

import (
	"math"
	"testing"
)

// TestSpike_BM25_PerRegionVsGlobalIDF quantifies ranking divergence between
// per-region IDF and global IDF for a 2-region corpus where term frequency
// distributions differ.
func TestSpike_BM25_PerRegionVsGlobalIDF(t *testing.T) {
	// Region A: 100 docs, term "cybernetics" in 2 docs (rare).
	// Region B: 100 docs, term "cybernetics" in 80 docs (common).
	// Global:   200 docs, term "cybernetics" in 82 docs.
	idfRegionA := bm25IDF(100, 2)  // rare → high IDF
	idfRegionB := bm25IDF(100, 80) // common → low IDF
	idfGlobal := bm25IDF(200, 82)  // blended

	// A doc in region A with tf=1, dl=10, avgdl=10.
	scoreRegA := bm25(idfRegionA, 1, 10, 10, bm25K1, bm25B)
	scoreGloA := bm25(idfGlobal, 1, 10, 10, bm25K1, bm25B)

	// A doc in region B with tf=1, dl=10, avgdl=10.
	scoreRegB := bm25(idfRegionB, 1, 10, 10, bm25K1, bm25B)
	scoreGloB := bm25(idfGlobal, 1, 10, 10, bm25K1, bm25B)

	t.Logf("IDF: regionA=%.4f regionB=%.4f global=%.4f", idfRegionA, idfRegionB, idfGlobal)
	t.Logf("Scores regionA doc: per-region=%.4f global=%.4f (delta=%.4f)",
		scoreRegA, scoreGloA, scoreRegA-scoreGloA)
	t.Logf("Scores regionB doc: per-region=%.4f global=%.4f (delta=%.4f)",
		scoreRegB, scoreGloB, scoreRegB-scoreGloB)

	// Key metric: does per-region scoring change the ORDERING between a
	// region-A doc and a region-B doc vs global scoring?
	perRegionAWins := scoreRegA > scoreRegB
	globalAWins := scoreGloA > scoreGloB
	orderFlip := perRegionAWins != globalAWins

	t.Logf("Per-region: A>B=%v (%.4f vs %.4f); Global: A>B=%v (%.4f vs %.4f); order flip=%v",
		perRegionAWins, scoreRegA, scoreRegB, globalAWins, scoreGloA, scoreGloB, orderFlip)

	// Quantify the magnitude of score divergence (ratio of per-region to global).
	ratioA := scoreRegA / scoreGloA
	ratioB := scoreRegB / scoreGloB
	maxDivergence := math.Max(math.Abs(ratioA-1), math.Abs(ratioB-1))
	t.Logf("Score ratio A: %.4f, ratio B: %.4f, max divergence from 1.0: %.2f%%",
		ratioA, ratioB, maxDivergence*100)

	if orderFlip {
		t.Logf("FINDING: per-region IDF FLIPS ordering vs global IDF — " +
			"a rare-in-its-region doc ranks higher with per-region scoring")
	} else {
		t.Logf("FINDING: per-region IDF preserves ordering vs global IDF " +
			"(magnitude differs but rank order is the same)")
	}
}
