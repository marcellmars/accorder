package calibre_test

import (
	"context"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"
	"testing"
)

// spikeLibrary creates a temporary Calibre library for spike testing.
// Returns the library path and a cleanup function.
//
// Skips the calling test when calibredb is absent. Every H1-H5 spike enters
// through here, so this one guard covers all of them. The convention (and the
// contract stated in .sit/docs/accorder/E2E_HARNESS.md) is that
// calibredb-dependent tests SKIP rather than fail; six sites in
// pkg/browselocal do the same. No build tag: these are unit-package tests and
// a tag would hide them from `go test ./...` entirely.
func spikeLibrary(t *testing.T) string {
	t.Helper()
	if _, err := exec.LookPath("calibredb"); err != nil {
		t.Skip("calibredb not on PATH; the Zotero/Calibre import spikes require Calibre")
	}
	dir := t.TempDir()
	libPath := filepath.Join(dir, "spike_lib")

	// calibredb requires a pre-existing library; create one with an empty book
	cmd := exec.Command("calibredb", "--library-path="+libPath, "add", "--empty", "--title=SpikeInit")
	out, err := cmd.CombinedOutput()
	if err != nil {
		t.Fatalf("failed to init spike library: %v\n%s", err, out)
	}
	return libPath
}

// calibredb is a convenience wrapper.
func calibredb(t *testing.T, lib string, args ...string) (string, error) {
	t.Helper()
	full := append([]string{"--library-path=" + lib}, args...)
	cmd := exec.Command("calibredb", full...)
	out, err := cmd.CombinedOutput()
	return string(out), err
}

// mustCalibredb calls calibredb and fails the test on error.
func mustCalibredb(t *testing.T, lib string, args ...string) string {
	t.Helper()
	out, err := calibredb(t, lib, args...)
	if err != nil {
		t.Fatalf("calibredb %v failed: %v\n%s", args, err, out)
	}
	return out
}

// -----------------------------------------------------------------------
// H1: Custom identifier schemes round-trip through calibredb set_metadata
// -----------------------------------------------------------------------
func TestH1_CustomIdentifiersRoundTrip(t *testing.T) {
	lib := spikeLibrary(t)
	ctx := context.Background()
	_ = ctx

	// The init book has id=1. Set custom zotero identifiers + custom columns via identifiers.
	// calibredb set_metadata --field identifiers:zotero:K1,zotero_rev:20250508T115939Z+deadbeef
	mustCalibredb(t, lib, "set_metadata", "1",
		"--field", "identifiers:zotero:K1,zotero_rev:20250508T115939Z+deadbeef,zotero_src:demo,zotero_export:test-uuid-123")

	// Read back with show_metadata
	showOut := mustCalibredb(t, lib, "show_metadata", "1")
	t.Logf("show_metadata output:\n%s", showOut)

	// Read back with list --for-machine
	listOut := mustCalibredb(t, lib, "list", "--for-machine", "-f", "identifiers")
	t.Logf("list --for-machine output:\n%s", listOut)

	// Parse JSON and verify each identifier
	var books []map[string]interface{}
	if err := json.Unmarshal([]byte(listOut), &books); err != nil {
		t.Fatalf("failed to parse list JSON: %v", err)
	}
	if len(books) == 0 {
		t.Fatal("no books returned from list")
	}

	// --for-machine returns identifiers as a JSON object (map), not a string
	idMap, ok := books[0]["identifiers"].(map[string]interface{})
	if !ok {
		t.Fatalf("identifiers field is not a map: %T = %v", books[0]["identifiers"], books[0]["identifiers"])
	}

	// Check that all four custom identifiers round-tripped
	wantPairs := map[string]string{
		"zotero":        "K1",
		"zotero_rev":    "20250508T115939Z+deadbeef",
		"zotero_src":    "demo",
		"zotero_export": "test-uuid-123",
	}

	t.Logf("Raw identifiers map: %v", idMap)

	for scheme, wantVal := range wantPairs {
		gotVal, exists := idMap[scheme]
		if !exists {
			t.Errorf("H1 FAIL: identifier scheme %q not found in map", scheme)
		} else if fmt.Sprint(gotVal) != wantVal {
			t.Errorf("H1 FAIL: identifier %s = %v, want %s", scheme, gotVal, wantVal)
		} else {
			t.Logf("H1 OK: found %s=%s", scheme, wantVal)
		}
	}
}

// -----------------------------------------------------------------------
// H2: calibredb list -s 'identifiers:zotero:K1' filters correctly
// -----------------------------------------------------------------------
func TestH2_IdentifierSearch(t *testing.T) {
	lib := spikeLibrary(t)

	// Add a second book to distinguish from the first
	mustCalibredb(t, lib, "add", "--empty", "--title=SecondBook")

	// Set zotero identifier only on book 1
	mustCalibredb(t, lib, "set_metadata", "1",
		"--field", "identifiers:zotero:GPLH5D4S")

	// Set a different identifier on book 2
	mustCalibredb(t, lib, "set_metadata", "2",
		"--field", "identifiers:zotero:KCBU772W")

	// Search for exact zotero key
	searchOut := mustCalibredb(t, lib, "list", "--for-machine",
		"-s", "identifiers:zotero:GPLH5D4S", "-f", "id,identifiers,title")
	t.Logf("search for GPLH5D4S:\n%s", searchOut)

	var results []map[string]interface{}
	if err := json.Unmarshal([]byte(searchOut), &results); err != nil {
		t.Fatalf("failed to parse search JSON: %v", err)
	}

	if len(results) != 1 {
		t.Errorf("H2 FAIL: expected 1 result for GPLH5D4S, got %d", len(results))
	} else {
		t.Logf("H2 OK: exact match returned 1 result")
	}

	// Search for non-existent key → 0 results
	noOut := mustCalibredb(t, lib, "list", "--for-machine",
		"-s", "identifiers:zotero:NONEXIST", "-f", "id,identifiers,title")
	t.Logf("search for NONEXIST:\n%s", noOut)

	var noResults []map[string]interface{}
	if err := json.Unmarshal([]byte(noOut), &noResults); err != nil {
		t.Fatalf("failed to parse no-results JSON: %v", err)
	}
	if len(noResults) != 0 {
		t.Errorf("H2 FAIL: expected 0 results for NONEXIST, got %d", len(noResults))
	} else {
		t.Logf("H2 OK: non-existent key returned 0 results")
	}

	// Test prefix semantics: search "zotero:G" — does it match GPLH5D4S?
	prefixOut, prefixErr := calibredb(t, lib, "list", "--for-machine",
		"-s", "identifiers:zotero:G", "-f", "id,identifiers,title")
	t.Logf("prefix search for 'zotero:G' (err=%v):\n%s", prefixErr, prefixOut)

	var prefixResults []map[string]interface{}
	if err := json.Unmarshal([]byte(prefixOut), &prefixResults); err != nil {
		t.Logf("H2 INFO: prefix search parse failed (may be empty/error): %v", err)
	} else {
		t.Logf("H2 INFO: prefix search 'zotero:G' returned %d results (prefix match = %v)",
			len(prefixResults), len(prefixResults) > 0)
	}
}

// -----------------------------------------------------------------------
// H3: calibredb add prints parseable book ID on stdout
// -----------------------------------------------------------------------
func TestH3_AddPrintsBookID(t *testing.T) {
	lib := spikeLibrary(t)

	// Create a small test file to add
	tmpFile := filepath.Join(t.TempDir(), "test_book.txt")
	if err := os.WriteFile(tmpFile, []byte("spike test content for H3"), 0644); err != nil {
		t.Fatal(err)
	}

	// Add the file as a book
	addOut := mustCalibredb(t, lib, "add", "--title=H3 Test Book", tmpFile)
	t.Logf("calibredb add output:\n%s", addOut)

	// Try legacy Python regex: split("ids: ")[1].strip()
	if parts := strings.Split(addOut, "ids: "); len(parts) > 1 {
		idPart := strings.TrimSpace(parts[1])
		t.Logf("H3 OK (legacy split): extracted id=%q", idPart)
	} else {
		t.Logf("H3 INFO: legacy 'ids: ' split did not match")
	}

	// Try regex: ids?: *([0-9]+)
	re := regexp.MustCompile(`[Ii]ds?:\s*(\d+)`)
	if m := re.FindStringSubmatch(addOut); m != nil {
		t.Logf("H3 OK (regex): extracted id=%q", m[1])
	} else {
		t.Errorf("H3 FAIL: no id found in add output with regex `ids?:\\s*(\\d+)`")
	}

	// Try regex matching "Added book ids: 2" pattern
	re2 := regexp.MustCompile(`Added book ids:\s*(\d+)`)
	if m := re2.FindStringSubmatch(addOut); m != nil {
		t.Logf("H3 OK (Added book ids): extracted id=%q", m[1])
	} else {
		t.Logf("H3 INFO: 'Added book ids:' pattern did not match")
	}

	// Now test duplicate detection: add the same file again WITHOUT --duplicates
	dupOut, dupErr := calibredb(t, lib, "add", "--title=H3 Test Book", tmpFile)
	t.Logf("H3 duplicate add output (err=%v):\n%s", dupErr, dupOut)

	// Check for any dedup message
	dupLower := strings.ToLower(dupOut)
	if strings.Contains(dupLower, "already exist") || strings.Contains(dupLower, "duplicate") {
		t.Logf("H3 OK: dedup message detected in output")
	} else {
		t.Logf("H3 INFO: no obvious dedup message in output")
	}
}

// -----------------------------------------------------------------------
// H4: calibredb add_format replaces existing format by default
// -----------------------------------------------------------------------
func TestH4_AddFormatReplacesExisting(t *testing.T) {
	lib := spikeLibrary(t)

	// Create first version of a file
	tmpDir := t.TempDir()
	file1 := filepath.Join(tmpDir, "book_v1.epub")
	content1 := []byte("epub content version 1 - short")
	if err := os.WriteFile(file1, content1, 0644); err != nil {
		t.Fatal(err)
	}
	hash1 := fmt.Sprintf("%x", sha256.Sum256(content1))

	// Add format to book 1
	mustCalibredb(t, lib, "add_format", "1", file1)
	t.Logf("H4: added first EPUB format")

	// List formats to get the stored file path
	listOut1 := mustCalibredb(t, lib, "list", "--for-machine", "-f", "id,formats", "-s", "id:1")
	t.Logf("H4 formats after first add:\n%s", listOut1)

	// Create second version — different content, same extension
	file2 := filepath.Join(tmpDir, "book_v2.epub")
	content2 := []byte("epub content version 2 - this is a longer version with different content for hash comparison")
	if err := os.WriteFile(file2, content2, 0644); err != nil {
		t.Fatal(err)
	}
	hash2 := fmt.Sprintf("%x", sha256.Sum256(content2))

	// Add format again — should replace without error
	replaceOut := mustCalibredb(t, lib, "add_format", "1", file2)
	t.Logf("H4 replace output:\n%s", replaceOut)

	// List formats again
	listOut2 := mustCalibredb(t, lib, "list", "--for-machine", "-f", "id,formats", "-s", "id:1")
	t.Logf("H4 formats after replace:\n%s", listOut2)

	// Find the actual EPUB file in the library and hash it
	var books2 []map[string]interface{}
	if err := json.Unmarshal([]byte(listOut2), &books2); err != nil {
		t.Fatalf("failed to parse list: %v", err)
	}

	// --for-machine returns formats as a JSON array of full paths
	formatsArr, ok := books2[0]["formats"].([]interface{})
	if !ok {
		t.Fatalf("formats field is not array: %T = %v", books2[0]["formats"], books2[0]["formats"])
	}
	t.Logf("H4 formats array: %v", formatsArr)

	// Verify only one EPUB format exists (not duplicated)
	epubCount := 0
	for _, fmtRaw := range formatsArr {
		fmtPath, ok := fmtRaw.(string)
		if !ok {
			continue
		}
		if strings.HasSuffix(strings.ToLower(fmtPath), ".epub") {
			epubCount++
			data, err := os.ReadFile(fmtPath)
			if err != nil {
				t.Logf("H4 INFO: cannot read format file at %q: %v", fmtPath, err)
				continue
			}
			actualHash := fmt.Sprintf("%x", sha256.Sum256(data))
			if actualHash == hash2 {
				t.Logf("H4 OK: format was replaced (hash matches v2)")
			} else if actualHash == hash1 {
				t.Errorf("H4 FAIL: format still has v1 content after replace")
			} else {
				t.Logf("H4 INFO: format hash %s doesn't match v1(%s) or v2(%s)", actualHash[:16], hash1[:16], hash2[:16])
			}
		}
	}

	if epubCount == 1 {
		t.Logf("H4 OK: exactly one EPUB format (not duplicated)")
	} else {
		t.Errorf("H4 FAIL: expected 1 EPUB format, found %d in array %v", epubCount, formatsArr)
	}
}

// -----------------------------------------------------------------------
// H5: calibredb list -f id,identifiers,formats,title --for-machine
//
//	returns all fields together in parseable form
//

// -----------------------------------------------------------------------
func TestH5_ListMultipleFieldsForMachine(t *testing.T) {
	lib := spikeLibrary(t)

	// Set up a book with identifiers and formats
	mustCalibredb(t, lib, "set_metadata", "1",
		"--field", "identifiers:zotero:TESTKEY,isbn:1234567890")

	// Add a format
	tmpFile := filepath.Join(t.TempDir(), "h5test.pdf")
	if err := os.WriteFile(tmpFile, []byte("%PDF-1.4 spike test"), 0644); err != nil {
		t.Fatal(err)
	}
	mustCalibredb(t, lib, "add_format", "1", tmpFile)

	// List with multiple fields
	out := mustCalibredb(t, lib, "list", "--for-machine", "-f", "id,identifiers,formats,title")
	t.Logf("H5 multi-field list:\n%s", out)

	var books []map[string]interface{}
	if err := json.Unmarshal([]byte(out), &books); err != nil {
		t.Fatalf("H5 FAIL: cannot parse multi-field JSON: %v", err)
	}

	if len(books) == 0 {
		t.Fatal("H5 FAIL: no books in output")
	}

	book := books[0]

	// Check each field is present
	fields := []string{"id", "identifiers", "formats", "title"}
	for _, f := range fields {
		val, exists := book[f]
		if !exists {
			t.Errorf("H5 FAIL: field %q missing from output", f)
		} else {
			t.Logf("H5 OK: field %q present, type=%T, value=%v", f, val, val)
		}
	}

	// Check formats field structure — is it array of paths or comma-separated string?
	switch v := book["formats"].(type) {
	case string:
		t.Logf("H5 INFO: formats is a string: %q", v)

		// Check it contains the extension
		if strings.Contains(strings.ToLower(v), ".pdf") {
			t.Logf("H5 OK: formats string contains .pdf extension")
		}
	case []interface{}:
		t.Logf("H5 INFO: formats is an array with %d elements", len(v))
		for i, elem := range v {
			t.Logf("H5 INFO: formats[%d] = %v", i, elem)
		}
	default:
		t.Logf("H5 INFO: formats is unexpected type %T: %v", v, v)
	}

	// Check identifiers field structure
	switch v := book["identifiers"].(type) {
	case string:
		t.Logf("H5 INFO: identifiers is a string: %q", v)
		if strings.Contains(v, "zotero:TESTKEY") {
			t.Logf("H5 OK: identifiers contains zotero:TESTKEY")
		}
	case map[string]interface{}:
		t.Logf("H5 INFO: identifiers is a map: %v", v)
	default:
		t.Logf("H5 INFO: identifiers is unexpected type %T: %v", v, v)
	}
}
