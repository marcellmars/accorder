package calibre

import (
	"container/list"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"sort"
	"sync"
	"sync/atomic"

	"github.com/cespare/xxhash/v2"
	"github.com/klauspost/compress/zstd"
)

const (
	maxDecoderFrameSize = 128 << 20

	frameCacheBudgetBytes = 32 << 20
)

func readSeekTableTail(src io.ReaderAt, size int64) (entries []byte, entrySize int, tableStart int64, err error) {
	if size < seekTableFooterSize {
		return nil, 0, 0, fmt.Errorf("readSeekTableTail: stream too short: %d bytes", size)
	}
	var footer [seekTableFooterSize]byte
	if _, err := src.ReadAt(footer[:], size-seekTableFooterSize); err != nil {
		return nil, 0, 0, fmt.Errorf("readSeekTableTail: read footer: %w", err)
	}
	tableStart, entrySize, err = seekTableStart(footer[:], size)
	if err != nil {
		return nil, 0, 0, err
	}
	tableLen := size - tableStart
	if tableLen > maxDecoderFrameSize {
		return nil, 0, 0, fmt.Errorf("readSeekTableTail: seek table too large: %d bytes", tableLen)
	}
	buf := make([]byte, tableLen)
	if _, err := src.ReadAt(buf, tableStart); err != nil {
		return nil, 0, 0, fmt.Errorf("readSeekTableTail: read table: %w", err)
	}
	if magic := binary.LittleEndian.Uint32(buf[0:4]); magic != skippableFrameMagic+seekableTag {
		return nil, 0, 0, fmt.Errorf("readSeekTableTail: skippable frame magic mismatch: %#x", magic)
	}
	if declared := int64(binary.LittleEndian.Uint32(buf[4:8])); declared != tableLen-8 {
		return nil, 0, 0, fmt.Errorf("readSeekTableTail: skippable frame size mismatch: declared %d, actual %d", declared, tableLen-8)
	}
	return buf[8 : tableLen-seekTableFooterSize], entrySize, tableStart, nil
}

type frameSpan struct {
	cOff, dOff   uint64
	cSize, dSize uint32
	checksum     uint32
}

func buildFrameIndex(entries []byte, entrySize int) ([]frameSpan, int64) {
	frames := make([]frameSpan, len(entries)/entrySize)
	var cOff, dOff uint64
	for i := range frames {
		e := entries[i*entrySize:]
		frames[i] = frameSpan{
			cOff:  cOff,
			dOff:  dOff,
			cSize: binary.LittleEndian.Uint32(e[0:4]),
			dSize: binary.LittleEndian.Uint32(e[4:8]),
		}
		if entrySize == seekTableEntrySizeCksm {
			frames[i].checksum = binary.LittleEndian.Uint32(e[8:12])
		}
		cOff += uint64(frames[i].cSize)
		dOff += uint64(frames[i].dSize)
	}
	return frames, int64(dOff)
}

type mwscReaderAt struct {
	src       io.ReaderAt
	dec       *zstd.Decoder
	frames    []frameSpan
	size      int64
	checksums bool
	closed    atomic.Bool
	cache     frameCache
}

func newMWSCReaderAt(src io.ReaderAt, size int64, dec *zstd.Decoder) (*mwscReaderAt, error) {
	entries, entrySize, tableStart, err := readSeekTableTail(src, size)
	if err != nil {
		return nil, fmt.Errorf("newMWSCReaderAt: %w", err)
	}
	frames, total := buildFrameIndex(entries, entrySize)
	var compTotal uint64
	if n := len(frames); n > 0 {
		compTotal = frames[n-1].cOff + uint64(frames[n-1].cSize)
	}
	if compTotal != uint64(tableStart) {
		return nil, fmt.Errorf("newMWSCReaderAt: seek-table compressed sizes sum to %d but table starts at %d", compTotal, tableStart)
	}
	r := &mwscReaderAt{
		src:       src,
		dec:       dec,
		frames:    frames,
		size:      total,
		checksums: entrySize == seekTableEntrySizeCksm,
	}
	r.cache.init(frameCacheBudgetBytes)
	return r, nil
}

func (r *mwscReaderAt) Size() int64 { return r.size }

func (r *mwscReaderAt) numFrames() int { return len(r.frames) }

func (r *mwscReaderAt) Close() error {
	if r.closed.CompareAndSwap(false, true) {
		r.cache.clear()
	}
	return nil
}

func (r *mwscReaderAt) ReadAt(p []byte, off int64) (n int, err error) {
	for n < len(p) && err == nil {
		var m int
		m, err = r.readOne(p[n:], off+int64(n))
		n += m
	}
	return n, err
}

func (r *mwscReaderAt) readOne(dst []byte, off int64) (int, error) {
	if r.closed.Load() {
		return 0, errors.New("mwscReaderAt: reader is closed")
	}
	if off >= r.size {
		return 0, io.EOF
	}
	if off < 0 {
		return 0, fmt.Errorf("mwscReaderAt: negative offset: %d", off)
	}
	idx := r.frameFor(uint64(off))
	if idx < 0 {
		return 0, fmt.Errorf("mwscReaderAt: no frame for offset %d", off)
	}
	buf, err := r.frameBytes(idx)
	if err != nil {
		return 0, err
	}
	within := uint64(off) - r.frames[idx].dOff
	return copy(dst, buf[within:]), nil
}

func (r *mwscReaderAt) frameFor(off uint64) int {
	idx, found := sort.Find(len(r.frames), func(i int) int {
		f := &r.frames[i]
		switch {
		case off >= f.dOff+uint64(f.dSize):
			return 1
		case off < f.dOff:
			return -1
		default:
			return 0
		}
	})
	if !found {
		return -1
	}
	return idx
}

func (r *mwscReaderAt) frameBytes(idx int) ([]byte, error) {
	c := &r.cache
	c.mu.Lock()
	if el, ok := c.byIdx[idx]; ok {
		c.ll.MoveToFront(el)
		buf := el.Value.(*frameCacheEntry).buf
		c.mu.Unlock()
		return buf, nil
	}
	if fl, ok := c.inflight[idx]; ok {
		c.mu.Unlock()
		<-fl.done
		return fl.buf, fl.err
	}
	fl := &inflightFrame{done: make(chan struct{})}
	c.inflight[idx] = fl
	c.mu.Unlock()

	buf, err := r.decodeFrame(idx)
	fl.buf, fl.err = buf, err

	c.mu.Lock()
	delete(c.inflight, idx)
	if err == nil {
		c.putLocked(idx, buf)
	}
	c.mu.Unlock()
	close(fl.done)
	return buf, err
}

func (r *mwscReaderAt) decodeFrame(idx int) ([]byte, error) {
	f := &r.frames[idx]
	if f.cSize > maxDecoderFrameSize {
		return nil, fmt.Errorf("mwscReaderAt: frame %d compressed size too large: %d", idx, f.cSize)
	}
	if f.dSize > maxDecoderFrameSize {
		return nil, fmt.Errorf("mwscReaderAt: frame %d decompressed size too large: %d", idx, f.dSize)
	}
	comp := make([]byte, f.cSize)
	n, err := r.src.ReadAt(comp, int64(f.cOff))
	if err != nil && !errors.Is(err, io.EOF) {
		return nil, fmt.Errorf("mwscReaderAt: read frame %d at %d: %w", idx, f.cOff, err)
	}
	if n != len(comp) {
		return nil, fmt.Errorf("mwscReaderAt: frame %d truncated: read %d of %d bytes at %d", idx, n, f.cSize, f.cOff)
	}
	buf, err := r.dec.DecodeAll(comp, make([]byte, 0, f.dSize))
	if err != nil {
		return nil, fmt.Errorf("mwscReaderAt: decode frame %d: %w", idx, err)
	}
	if len(buf) != int(f.dSize) {
		return nil, fmt.Errorf("mwscReaderAt: frame %d decoded to %d bytes, seek table says %d", idx, len(buf), f.dSize)
	}
	if r.checksums {
		if got := uint32(xxhash.Sum64(buf)); got != f.checksum {
			return nil, fmt.Errorf("mwscReaderAt: frame %d checksum mismatch: got %#x want %#x", idx, got, f.checksum)
		}
	}
	return buf, nil
}

type frameCache struct {
	mu       sync.Mutex
	budget   int64
	used     int64
	dead     bool
	ll       *list.List
	byIdx    map[int]*list.Element
	inflight map[int]*inflightFrame
}

type frameCacheEntry struct {
	idx int
	buf []byte
}

type inflightFrame struct {
	done chan struct{}
	buf  []byte
	err  error
}

func (c *frameCache) init(budget int64) {
	c.budget = budget
	c.ll = list.New()
	c.byIdx = make(map[int]*list.Element)
	c.inflight = make(map[int]*inflightFrame)
}

func (c *frameCache) putLocked(idx int, buf []byte) {
	if c.dead || int64(len(buf)) > c.budget {
		return
	}
	if _, ok := c.byIdx[idx]; ok {
		return
	}
	c.byIdx[idx] = c.ll.PushFront(&frameCacheEntry{idx: idx, buf: buf})
	c.used += int64(len(buf))
	for c.used > c.budget {
		back := c.ll.Back()
		if back == nil {
			break
		}
		e := c.ll.Remove(back).(*frameCacheEntry)
		delete(c.byIdx, e.idx)
		c.used -= int64(len(e.buf))
	}
}

func (c *frameCache) clear() {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.dead = true
	c.ll.Init()
	c.byIdx = make(map[int]*list.Element)
	c.used = 0
}
