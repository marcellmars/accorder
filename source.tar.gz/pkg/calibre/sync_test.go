package calibre

import (
	"net/url"
	"os"
	"testing"
)

func TestDetermineSyncAction_NoOp(t *testing.T) {
	cached := &CachedSyncState{
		BaseGeneration:    "aabb",
		PointerGeneration: 5,
		LastCompactGen:    2,
	}
	pf := PointerFile{
		Index: PointerFileIndex{
			BaseGeneration:    "aabb",
			PointerGeneration: 5,
		},
		LastCompact: &PointerFileCompact{PointerGeneration: 2},
	}
	a := DetermineSyncAction(cached, pf, "compact", false)
	if a.Kind != SyncNoOp {
		t.Fatalf("expected NoOp, got %d (%s)", a.Kind, a.Reason)
	}
}

func TestDetermineSyncAction_FirstSync(t *testing.T) {
	pf := PointerFile{
		Index: PointerFileIndex{PointerGeneration: 1, BaseGeneration: "aabb"},
	}
	a := DetermineSyncAction(nil, pf, "compact", false)
	if a.Kind != SyncFullDownload {
		t.Fatalf("expected FullDownload for first sync, got %d (%s)", a.Kind, a.Reason)
	}
}

func TestDetermineSyncAction_Force(t *testing.T) {
	cached := &CachedSyncState{
		BaseGeneration:    "aabb",
		PointerGeneration: 5,
	}
	pf := PointerFile{
		Index: PointerFileIndex{BaseGeneration: "aabb", PointerGeneration: 5},
	}
	a := DetermineSyncAction(cached, pf, "compact", true)
	if a.Kind != SyncFullDownload {
		t.Fatalf("expected FullDownload for force, got %d (%s)", a.Kind, a.Reason)
	}
}

func TestDetermineSyncAction_LineageBreak(t *testing.T) {
	cached := &CachedSyncState{
		BaseGeneration:    "aabb",
		PointerGeneration: 5,
	}
	pf := PointerFile{
		Index: PointerFileIndex{BaseGeneration: "ccdd", PointerGeneration: 6},
	}
	a := DetermineSyncAction(cached, pf, "append", false)
	if a.Kind != SyncFullDownload {
		t.Fatalf("expected FullDownload for lineage break, got %d (%s)", a.Kind, a.Reason)
	}
}

func TestDetermineSyncAction_CompactMode(t *testing.T) {
	cached := &CachedSyncState{
		BaseGeneration:    "aabb",
		PointerGeneration: 3,
		LastCompactGen:    1,
	}
	pf := PointerFile{
		Index:       PointerFileIndex{BaseGeneration: "aabb", PointerGeneration: 5},
		LastCompact: &PointerFileCompact{PointerGeneration: 1},
	}
	a := DetermineSyncAction(cached, pf, "compact", false)
	if a.Kind != SyncFullDownload {
		t.Fatalf("compact mode should always full-download on advance, got %d (%s)", a.Kind, a.Reason)
	}
}

func TestDetermineSyncAction_AppendIncremental(t *testing.T) {
	cached := &CachedSyncState{
		BaseGeneration:    "aabb",
		PointerGeneration: 3,
		LastCompactGen:    1,
	}
	pf := PointerFile{
		Index:       PointerFileIndex{BaseGeneration: "aabb", PointerGeneration: 5},
		LastCompact: &PointerFileCompact{PointerGeneration: 1}, // no new compaction
	}
	a := DetermineSyncAction(cached, pf, "append", false)
	if a.Kind != SyncRangeFetch {
		t.Fatalf("expected RangeFetch for append incremental, got %d (%s)", a.Kind, a.Reason)
	}
}

func TestDetermineSyncAction_CompactionDetected(t *testing.T) {
	cached := &CachedSyncState{
		BaseGeneration:    "aabb",
		PointerGeneration: 3,
		LastCompactGen:    1,
	}
	pf := PointerFile{
		Index:       PointerFileIndex{BaseGeneration: "aabb", PointerGeneration: 5},
		LastCompact: &PointerFileCompact{PointerGeneration: 4}, // compaction at gen 4
	}

	// Append mode with compaction → full download.
	a := DetermineSyncAction(cached, pf, "append", false)
	if a.Kind != SyncFullDownload {
		t.Fatalf("append + compaction should full-download, got %d (%s)", a.Kind, a.Reason)
	}

	// Hybrid mode with compaction → full download.
	a2 := DetermineSyncAction(cached, pf, "hybrid", false)
	if a2.Kind != SyncFullDownload {
		t.Fatalf("hybrid + compaction should full-download, got %d (%s)", a2.Kind, a2.Reason)
	}
}

func TestDetermineSyncAction_HybridIncremental(t *testing.T) {
	cached := &CachedSyncState{
		BaseGeneration:    "aabb",
		PointerGeneration: 3,
		LastCompactGen:    1,
	}
	pf := PointerFile{
		Index:       PointerFileIndex{BaseGeneration: "aabb", PointerGeneration: 5},
		LastCompact: &PointerFileCompact{PointerGeneration: 1}, // no new compaction
	}
	a := DetermineSyncAction(cached, pf, "hybrid", false)
	if a.Kind != SyncRangeFetch {
		t.Fatalf("expected RangeFetch for hybrid incremental, got %d (%s)", a.Kind, a.Reason)
	}
}

func TestResolveRelativeURL(t *testing.T) {
	base, _ := url.Parse("https://cdn.example.com/libraries/mylib.manifest.json")
	resolved, err := ResolveRelativeURL(base, "lib.zst")
	if err != nil {
		t.Fatalf("ResolveRelativeURL: %v", err)
	}
	want := "https://cdn.example.com/libraries/lib.zst"
	if resolved != want {
		t.Fatalf("resolved URL: got %q, want %q", resolved, want)
	}
}

func TestResolveRelativeURL_Absolute(t *testing.T) {
	base, _ := url.Parse("https://cdn.example.com/libraries/mylib.manifest.json")
	resolved, err := ResolveRelativeURL(base, "https://other.com/lib.zst")
	if err != nil {
		t.Fatalf("ResolveRelativeURL: %v", err)
	}
	want := "https://other.com/lib.zst"
	if resolved != want {
		t.Fatalf("absolute URL should pass through: got %q, want %q", resolved, want)
	}
}

func TestSyncStateRoundTrip(t *testing.T) {
	dir := t.TempDir()
	pf := PointerFile{
		Library: PointerFileLibrary{UUID: "test-lib-uuid"},
		Index: PointerFileIndex{
			BaseGeneration:    "aabb",
			PointerGeneration: 7,
		},
		LastCompact: &PointerFileCompact{PointerGeneration: 3},
	}
	if err := SaveSyncState(dir, pf.Library.UUID, pf); err != nil {
		t.Fatalf("SaveSyncState: %v", err)
	}

	loaded, err := LoadSyncState(dir, "test-lib-uuid")
	if err != nil {
		t.Fatalf("LoadSyncState: %v", err)
	}
	if loaded.BaseGeneration != "aabb" {
		t.Errorf("BaseGeneration: got %q, want %q", loaded.BaseGeneration, "aabb")
	}
	if loaded.PointerGeneration != 7 {
		t.Errorf("PointerGeneration: got %d, want 7", loaded.PointerGeneration)
	}
	if loaded.LastCompactGen != 3 {
		t.Errorf("LastCompactGen: got %d, want 3", loaded.LastCompactGen)
	}
}

func TestLoadSyncStateNotExist(t *testing.T) {
	dir := t.TempDir()
	_, err := LoadSyncState(dir, "nonexistent-uuid")
	if err == nil {
		t.Fatal("expected error for nonexistent sync state")
	}
	if !os.IsNotExist(err) {
		t.Logf("error (expected to wrap os.ErrNotExist): %v", err)
	}
}

// TestDetermineSyncAction_GenerationRegression guards review finding #4: a remote
// pointerGeneration that went BACKWARDS with the same BaseGeneration (publisher's
// pointer file was reset/rebuilt) must trigger a re-download, not a silent no-op.
func TestDetermineSyncAction_GenerationRegression(t *testing.T) {
	cached := &CachedSyncState{
		BaseGeneration:    "aabb",
		PointerGeneration: 10,
		LastCompactGen:    0,
	}
	pf := PointerFile{
		Index: PointerFileIndex{BaseGeneration: "aabb", PointerGeneration: 3},
	}
	for _, mode := range []string{"compact", "append", "hybrid"} {
		a := DetermineSyncAction(cached, pf, mode, false)
		if a.Kind != SyncFullDownload {
			t.Fatalf("mode %s: expected FullDownload on generation regression, got %d (%s)", mode, a.Kind, a.Reason)
		}
	}
}
