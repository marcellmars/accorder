package calibre

import (
	"reflect"
	"testing"
)

// A literal Windows path, not filepath.Join evaluated on the CI host. Keep
// this native: a backslash is a legal filename character on POSIX.
func TestBookPrivateExcludeLiteralWindowsPath(t *testing.T) {
	b := &Book{Formats: []*File{{DirectoryPath: `Native Author\Secret (3)\`}}}
	if got, want := b.PrivateExcludeGlobs(), []string{"/Native Author/Secret (3)/**"}; !reflect.DeepEqual(got, want) {
		t.Fatalf("private Windows directory: got %q, want %q", got, want)
	}
}
