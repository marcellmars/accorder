package calibre

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
	"time"
)

type PointerFile struct {
	Version           int                 `json:"version"`
	Library           PointerFileLibrary  `json:"library"`
	Index             PointerFileIndex    `json:"index"`
	LastCompact       *PointerFileCompact `json:"lastCompact,omitempty"`
	SourceFingerprint string              `json:"source_fingerprint,omitempty"`
	Generation        uint64              `json:"generation,omitempty"`
	CatalogChecksum   string              `json:"catalog_checksum,omitempty"`
}

type PointerFileLibrary struct {
	UUID      string `json:"uuid"`
	Librarian string `json:"librarian"`
	Name      string `json:"name,omitempty"`
}

type PointerFileIndex struct {
	URL               string `json:"url"`
	PointerGeneration uint64 `json:"pointerGeneration"`
	BaseGeneration    string `json:"baseGeneration"`
	Regions           int    `json:"regions"`
	NumBooks          uint32 `json:"numBooks"`
	Tombstones        int    `json:"tombstones"`
	IsCompacted       bool   `json:"isCompacted"`

	JsonlURL             string `json:"jsonlURL,omitempty"`
	JsonlBytes           int64  `json:"jsonlBytes,omitempty"`
	JsonlRawBytes        int64  `json:"jsonlRawBytes,omitempty"`
	DictID               uint32 `json:"dictID,omitempty"`
	ChunkSize            uint32 `json:"chunkSize,omitempty"`
	IndexAggregateFields bool   `json:"indexAggregateFields,omitempty"`
}

type PointerFileCompact struct {
	PointerGeneration uint64 `json:"pointerGeneration"`
	NumBooks          uint32 `json:"numBooks"`
	BuiltAt           string `json:"builtAt"`
}

func WritePointerFile(indexPath string, mf Manifest, lib PointerFileLibrary, isCompacted bool) error {
	pfPath := indexPath + ".manifest.json"

	var prevGen uint64
	var prevCompact *PointerFileCompact
	prev, err := ReadPointerFile(pfPath)
	switch {
	case err == nil:
		prevGen = prev.Index.PointerGeneration
		prevCompact = prev.LastCompact
	case errors.Is(err, os.ErrNotExist):
	default:
		return fmt.Errorf("WritePointerFile: read previous: %w", err)
	}
	nextGen := prevGen + 1

	var lastCompact *PointerFileCompact
	if isCompacted {
		lastCompact = &PointerFileCompact{
			PointerGeneration: nextGen,
			NumBooks:          mf.NumBooks,
			BuiltAt:           time.Now().UTC().Format(time.RFC3339),
		}
	} else {
		lastCompact = prevCompact
	}

	idx := PointerFileIndex{
		URL:               filepath.Base(indexPath) + ".zst",
		PointerGeneration: nextGen,
		BaseGeneration:    hex.EncodeToString(mf.BaseGeneration[:]),
		Regions:           len(mf.Regions),
		NumBooks:          mf.NumBooks,
		Tombstones:        len(mf.Tombstones),
		IsCompacted:       isCompacted,
	}

	populateJSONLLineage(&idx, indexPath, mf, lib)

	pf := PointerFile{
		Version:     1,
		Library:     lib,
		Index:       idx,
		LastCompact: lastCompact,
	}

	return writePointerFileAtomic(pfPath, pf)
}

func populateJSONLLineage(idx *PointerFileIndex, indexPath string, mf Manifest, lib PointerFileLibrary) {
	jsonlZstPath := indexPath + ".jsonl.zst"
	fi, statErr := os.Stat(jsonlZstPath)
	if statErr != nil {
		return
	}
	idx.JsonlURL = filepath.Base(jsonlZstPath)
	idx.JsonlBytes = fi.Size()
	var rawBytes int64
	for _, r := range mf.Regions {
		rawBytes += int64(r.DisplayLen)
	}
	idx.JsonlRawBytes = rawBytes
	if len(mf.Regions) > 0 {
		idx.DictID = mf.Regions[0].DictID
	}
	idx.ChunkSize = mf.ChunkSize
	idx.IndexAggregateFields = lib.Librarian == "aggregate" || idx.DictID >= 2
}

func EnsurePointerFile(indexPath string, mf Manifest, lib PointerFileLibrary) error {
	pfPath := indexPath + ".manifest.json"
	_, err := os.Stat(pfPath)
	switch {
	case err == nil:
		return nil
	case errors.Is(err, os.ErrNotExist):
	default:
		return fmt.Errorf("EnsurePointerFile: stat %s: %w", pfPath, err)
	}
	idx := PointerFileIndex{
		URL:               filepath.Base(indexPath) + ".zst",
		PointerGeneration: 1,
		BaseGeneration:    hex.EncodeToString(mf.BaseGeneration[:]),
		Regions:           len(mf.Regions),
		NumBooks:          mf.NumBooks,
		Tombstones:        len(mf.Tombstones),
		IsCompacted:       false,
	}

	populateJSONLLineage(&idx, indexPath, mf, lib)

	pf := PointerFile{
		Version: 1,
		Library: lib,
		Index:   idx,
	}
	return writePointerFileAtomic(pfPath, pf)
}

func writePointerFileAtomic(pfPath string, pf PointerFile) error {
	data, err := json.MarshalIndent(pf, "", "  ")
	if err != nil {
		return fmt.Errorf("writePointerFileAtomic: marshal: %w", err)
	}
	tmp := pfPath + ".tmp"
	if err := os.WriteFile(tmp, data, 0644); err != nil {
		return fmt.Errorf("writePointerFileAtomic: write tmp: %w", err)
	}
	if err := os.Rename(tmp, pfPath); err != nil {
		return fmt.Errorf("writePointerFileAtomic: rename: %w", err)
	}
	return nil
}

// BindPointerCommit upgrades an existing member pointer to the version 2 wire
// contract that binds the published source snapshot to the trailing
// _GENERATION sentinel. The sentinel itself remains the final commit write.
func BindPointerCommit(pf PointerFile, sourceFingerprint string, generation uint64) (PointerFile, error) {
	if strings.TrimSpace(sourceFingerprint) == "" {
		return PointerFile{}, errors.New("BindPointerCommit: empty source fingerprint")
	}
	if generation == 0 {
		return PointerFile{}, errors.New("BindPointerCommit: zero generation")
	}
	if strings.TrimSpace(pf.Library.UUID) == "" {
		return PointerFile{}, errors.New("BindPointerCommit: empty library UUID")
	}
	pf.Version = 2
	pf.SourceFingerprint = sourceFingerprint
	pf.Generation = generation
	return pf, nil
}

func ValidatePointerCommit(pf PointerFile, sourceFingerprint string, generation uint64) error {
	if pf.Version != 2 {
		return fmt.Errorf("pointer version %d is legacy/unbound; version 2 required", pf.Version)
	}
	if pf.SourceFingerprint == "" {
		return errors.New("pointer version 2 is missing source_fingerprint")
	}
	if pf.Generation == 0 {
		return errors.New("pointer version 2 is missing generation")
	}
	if pf.SourceFingerprint != sourceFingerprint {
		return fmt.Errorf("pointer/source mismatch: pointer %s, live %s", pf.SourceFingerprint, sourceFingerprint)
	}
	if pf.Generation != generation {
		return fmt.Errorf("pointer/_GENERATION mismatch: pointer %d, sentinel %d", pf.Generation, generation)
	}
	if pf.CatalogChecksum != "" {
		if len(pf.CatalogChecksum) != sha256.Size*2 || strings.ToLower(pf.CatalogChecksum) != pf.CatalogChecksum {
			return errors.New("pointer catalog_checksum must be 64 lowercase hexadecimal characters")
		}
		if _, err := hex.DecodeString(pf.CatalogChecksum); err != nil {
			return fmt.Errorf("pointer catalog_checksum: %w", err)
		}
	}
	return nil
}

// WritePointerDocument atomically writes a fully prepared pointer. Build-time
// helpers continue to create version 1 candidates; the ordered publisher calls
// BindPointerCommit and writes version 2 immediately before _GENERATION.
func WritePointerDocument(path string, pf PointerFile) error {
	return writePointerFileAtomic(path, pf)
}

func ReadPointerFile(path string) (PointerFile, error) {
	f, err := os.Open(path)
	if err != nil {
		return PointerFile{}, fmt.Errorf("ReadPointerFile: %w", err)
	}
	defer f.Close()
	pf, err := DecodePointerFile(f)
	if err != nil {
		return PointerFile{}, fmt.Errorf("ReadPointerFile: %w", err)
	}
	return pf, nil
}

func DecodePointerFile(r io.Reader) (PointerFile, error) {
	var pf PointerFile
	if err := json.NewDecoder(r).Decode(&pf); err != nil {
		return PointerFile{}, fmt.Errorf("decode pointer file: %w", err)
	}
	return pf, nil
}
