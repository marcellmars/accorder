package calibre

import "strings"

// EVE-style JSON response envelope used by the single-index serve handlers.
// Preserved from the deleted fan-out aggregator so the frontend's wire format
// stays unchanged across the refactor.

type EveEnvelope struct {
	Items interface{} `json:"_items"`
	Meta  EveMeta     `json:"_meta"`
	Links EveLinks    `json:"_links"`
}

type EveMeta struct {
	Total      int `json:"total"`
	Page       int `json:"page"`
	MaxResults int `json:"max_results"`
}

type EveLink struct {
	Href  string `json:"href"`
	Title string `json:"title"`
}

type EveLinks struct {
	Self EveLink  `json:"self"`
	Next *EveLink `json:"next,omitempty"`
	Prev *EveLink `json:"prev,omitempty"`
	Last *EveLink `json:"last,omitempty"`
}

const EveDefaultPageSize = 48

// PluralToSingularField normalizes EVE-style plural route segments
// (/books, /titles) to the canonical singular field names used by the
// search engine.
func PluralToSingularField(field string) string {
	switch strings.ToLower(field) {
	case "titles":
		return "title"
	case "authors":
		return "author"
	case "tags":
		return "tag"
	case "librarians":
		return "librarian"
	default:
		return field
	}
}
