# Bundle Source

The `js/bundle.js` and `css/bundle.css` in this directory are built from
the svelte source at `<repo-root>/frontend/`.

To rebuild:

    cd frontend
    npm install              # first time only
    npm run build            # outputs to pkg/calibre/embResources/static/

Toolchain: svelte 5.55.7 + vite 6.4.2 + @sveltejs/vite-plugin-svelte 5.1.1
+ tailwindcss 4.3.0 + @tailwindcss/vite 4.3.0.

History: this source was originally maintained at letssharebooks/svelte-frontend
(github.com/marcellmars/letssharebooks). Moved in-tree on 2026-05-14 via the
`svelte-5-vite-tailwind-4` SIT workflow.
