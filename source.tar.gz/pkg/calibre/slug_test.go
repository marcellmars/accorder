package calibre

import "testing"

func TestSlugifySourceName(t *testing.T) {
	tests := []struct {
		input string
		want  string
	}{
		{"Alice's Library", "alices-library"},
		{"Memory of the World", "memory-of-the-world"},
		{"Marcell Mars", "marcell-mars"},
		{"UPPERCASE", "uppercase"},
		{"  leading  trailing  ", "leading-trailing"},
		{"under_score_name", "under-score-name"},
		{"mix-dash_under space", "mix-dash-under-space"},
		{"special!@#$%chars", "specialchars"},
		{"hello---world", "hello-world"},
		{"", ""},
		{"   ", ""},
		{"123numbers456", "123numbers456"},
		{"a", "a"},

		// Length clamp: 48 chars + excess
		{"aaaaaaaabbbbbbbbccccccccddddddddeeeeeeeeffffffffggg", "aaaaaaaabbbbbbbbccccccccddddddddeeeeeeeeffffffff"},

		// Trailing dash after clamp
		{"aaaaaaaabbbbbbbbccccccccddddddddeeeeeeeeffffffff-xx", "aaaaaaaabbbbbbbbccccccccddddddddeeeeeeeeffffffff"},
	}
	for _, tt := range tests {
		t.Run(tt.input, func(t *testing.T) {
			got := SlugifySourceName(tt.input)
			if got != tt.want {
				t.Errorf("SlugifySourceName(%q) = %q, want %q", tt.input, got, tt.want)
			}
		})
	}
}
