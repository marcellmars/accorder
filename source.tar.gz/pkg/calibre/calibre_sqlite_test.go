package calibre

import (
	"database/sql"
	"fmt"
	"path/filepath"
	"reflect"
	"sort"
	"strings"
	"testing"
)

// Minimal subset of Calibre's metadata.db schema — only the tables/columns the
// metadata queries (main_query, sub_query, all_books_SQL) touch.
const calibreTestSchema = `
CREATE TABLE books (id INTEGER PRIMARY KEY, title TEXT, sort TEXT, pubdate TEXT, last_modified TEXT, uuid TEXT, path TEXT);
CREATE TABLE data (id INTEGER PRIMARY KEY, book INTEGER, format TEXT, uncompressed_size INTEGER, name TEXT);
CREATE TABLE tags (id INTEGER PRIMARY KEY, name TEXT);
CREATE TABLE books_tags_link (book INTEGER, tag INTEGER);
CREATE TABLE authors (id INTEGER PRIMARY KEY, name TEXT);
CREATE TABLE books_authors_link (book INTEGER, author INTEGER);
CREATE TABLE publishers (id INTEGER PRIMARY KEY, name TEXT);
CREATE TABLE books_publishers_link (book INTEGER, publisher INTEGER);
CREATE TABLE series (id INTEGER PRIMARY KEY, name TEXT);
CREATE TABLE books_series_link (book INTEGER, series INTEGER);
CREATE TABLE languages (id INTEGER PRIMARY KEY, lang_code TEXT);
CREATE TABLE books_languages_link (book INTEGER, lang_code INTEGER);
CREATE TABLE comments (id INTEGER PRIMARY KEY, book INTEGER, text TEXT);
CREATE TABLE identifiers (book INTEGER, type TEXT, val TEXT);
CREATE INDEX data_idx ON data (book);
CREATE INDEX books_tags_link_bidx ON books_tags_link (book);
CREATE INDEX books_authors_link_bidx ON books_authors_link (book);
CREATE INDEX books_publishers_link_bidx ON books_publishers_link (book);
CREATE INDEX books_series_link_bidx ON books_series_link (book);
CREATE INDEX books_languages_link_bidx ON books_languages_link (book);
CREATE INDEX comments_idx ON comments (book);
CREATE INDEX identifiers_idx ON identifiers (book);
`

// seedCalibreDB writes a metadata.db with n fully-populated books into a temp
// dir and returns the dir. Each book gets 2 authors, 3 tags, a publisher, a
// series, a language, an abstract, 2 identifiers and 2 formats.
func seedCalibreDB(tb testing.TB, n int) string {
	tb.Helper()
	dir := tb.TempDir()
	db, err := sql.Open("sqlite", filepath.Join(dir, "metadata.db"))
	if err != nil {
		tb.Fatal(err)
	}
	defer db.Close()

	exec := func(q string, args ...any) {
		if _, err := db.Exec(q, args...); err != nil {
			tb.Fatalf("seed exec %q: %v", q, err)
		}
	}
	for _, stmt := range strings.Split(calibreTestSchema, ";") {
		if strings.TrimSpace(stmt) != "" {
			exec(stmt)
		}
	}
	exec(`INSERT INTO publishers(id,name) VALUES (1,'Verso'),(2,'MIT Press')`)
	exec(`INSERT INTO series(id,name) VALUES (1,'Critical AI')`)
	exec(`INSERT INTO languages(id,lang_code) VALUES (1,'eng'),(2,'fra')`)

	for i := 1; i <= n; i++ {
		title := fmt.Sprintf("Book %d: The Title", i)
		exec(`INSERT INTO books(id,title,sort,pubdate,last_modified,uuid,path) VALUES (?,?,?,?,?,?,?)`,
			i, title, title,
			fmt.Sprintf("2010-%02d-01T00:00:00+00:00", (i%12)+1),
			fmt.Sprintf("2025-%02d-%02dT00:00:00+00:00", (i%12)+1, (i%28)+1),
			fmt.Sprintf("uuid-%08d-0000-4000-8000-000000000000", i),
			fmt.Sprintf("Author %d/Book %d (%d)", i, i, i))
		for a := 0; a < 2; a++ {
			exec(`INSERT INTO authors(id,name) VALUES (?,?)`, i*10+a, fmt.Sprintf("Author %d.%d", i, a))
			exec(`INSERT INTO books_authors_link(book,author) VALUES (?,?)`, i, i*10+a)
		}
		for t := 0; t < 3; t++ {
			exec(`INSERT INTO tags(id,name) VALUES (?,?)`, i*10+t, fmt.Sprintf("tag-%d-%d", i, t))
			exec(`INSERT INTO books_tags_link(book,tag) VALUES (?,?)`, i, i*10+t)
		}
		exec(`INSERT INTO books_publishers_link(book,publisher) VALUES (?,?)`, i, (i%2)+1)
		exec(`INSERT INTO books_series_link(book,series) VALUES (?,1)`, i)
		exec(`INSERT INTO books_languages_link(book,lang_code) VALUES (?,?)`, i, (i%2)+1)
		exec(`INSERT INTO comments(id,book,text) VALUES (?,?,?)`, i, i, fmt.Sprintf("Abstract for book %d.", i))
		exec(`INSERT INTO identifiers(book,type,val) VALUES (?,'isbn',?),(?,'doi',?)`,
			i, fmt.Sprintf("978-%010d", i), i, fmt.Sprintf("10.1234/%d", i))
		name := fmt.Sprintf("Book %d - Author", i)
		exec(`INSERT INTO data(id,book,format,uncompressed_size,name) VALUES (?,?,'EPUB',?,?),(?,?,'PDF',?,?)`,
			i*10, i, 100000+i, name, i*10+1, i, 5000000+i, name)
	}
	return dir
}

func TestGetBooksSQLiteAgreesWithSingleQuery(t *testing.T) {
	dir := seedCalibreDB(t, 8)
	const libUUID = "11111111-0000-4000-8000-000000000000"

	active := &MotwStandaloneApp{CalibreDirectory: dir, LibraryUUID: libUUID}
	active.getBooksSQLite()
	single := &MotwStandaloneApp{CalibreDirectory: dir, LibraryUUID: libUUID}
	single.getBooksSQLiteSingleQuery()

	byTitle := func(books []*Book) map[string]*Book {
		m := make(map[string]*Book, len(books))
		for _, bk := range books {
			m[bk.Title] = bk
		}
		return m
	}
	sm, mm := byTitle(active.Books), byTitle(single.Books)
	if len(sm) != 8 || len(mm) != 8 {
		t.Fatalf("book counts: getBooksSQLite=%d getBooksSQLiteSingleQuery=%d, want 8", len(sm), len(mm))
	}

	sortedCopy := func(s []string) []string { c := make([]string, len(s)); copy(c, s); sort.Strings(c); return c }
	idSet := func(ids []*Identifier) []string {
		s := make([]string, 0, len(ids))
		for _, x := range ids {
			s = append(s, x.Scheme+":"+x.Code)
		}
		return sortedCopy(s)
	}
	fmtSet := func(fs []*File) []string {
		s := make([]string, 0, len(fs))
		for _, f := range fs {
			s = append(s, fmt.Sprintf("%s|%d|%s|%s", f.Format, f.Size, f.DirectoryPath, f.Name))
		}
		return sortedCopy(s)
	}

	for title, a := range sm {
		b, ok := mm[title]
		if !ok {
			t.Fatalf("getBooksSQLiteSingleQuery is missing %q", title)
		}
		if a.TitleSort != b.TitleSort || a.Pubdate != b.Pubdate || a.LastModified != b.LastModified ||
			a.Publisher != b.Publisher || a.Series != b.Series || a.Abstract != b.Abstract ||
			a.CoverUrl != b.CoverUrl || a.Id != b.Id {
			t.Errorf("%q scalar mismatch:\n getBooksSQLite          =%+v\n getBooksSQLiteSingleQuery=%+v", title, a, b)
		}
		if !reflect.DeepEqual(sortedCopy(a.Authors), sortedCopy(b.Authors)) {
			t.Errorf("%q authors: %v vs %v", title, a.Authors, b.Authors)
		}
		if !reflect.DeepEqual(sortedCopy(a.Tags), sortedCopy(b.Tags)) {
			t.Errorf("%q tags: %v vs %v", title, a.Tags, b.Tags)
		}
		if !reflect.DeepEqual(sortedCopy(a.Languages), sortedCopy(b.Languages)) {
			t.Errorf("%q languages: %v vs %v", title, a.Languages, b.Languages)
		}
		if !reflect.DeepEqual(idSet(a.Identifiers), idSet(b.Identifiers)) {
			t.Errorf("%q identifiers: %v vs %v", title, idSet(a.Identifiers), idSet(b.Identifiers))
		}
		if !reflect.DeepEqual(fmtSet(a.Formats), fmtSet(b.Formats)) {
			t.Errorf("%q formats: %v vs %v", title, fmtSet(a.Formats), fmtSet(b.Formats))
		}
	}
}

func benchGetBooks(b *testing.B, load func(*MotwStandaloneApp)) {
	const nBooks = 200
	dir := seedCalibreDB(b, nBooks)
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		motw := &MotwStandaloneApp{CalibreDirectory: dir, LibraryUUID: "00000000-0000-4000-8000-000000000000"}
		load(motw)
		if len(motw.Books) != nBooks {
			b.Fatalf("got %d books, want %d", len(motw.Books), nBooks)
		}
	}
}

// BenchmarkGetBooksSQLite measures the active loader (base query + per-relation
// JOINs, merged in Go). BenchmarkGetBooksSQLiteSingleQuery measures the one-query
// all_books_SQL alternative — it's the less-code version but reliably slower and
// allocates ~2.5x more, which is why getBooksSQLite stays the default.
func BenchmarkGetBooksSQLite(b *testing.B) {
	benchGetBooks(b, (*MotwStandaloneApp).getBooksSQLite)
}

func BenchmarkGetBooksSQLiteSingleQuery(b *testing.B) {
	benchGetBooks(b, (*MotwStandaloneApp).getBooksSQLiteSingleQuery)
}
