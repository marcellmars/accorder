package calibre

// Multi-region oracle for searchAllSinglePass — the coverage the single-region
// oracle lacked. Each test compares the new single-pass FieldAll-exact path against
// the proven old N-per-field searchAll (searchAllOld) on the shapes that exposed the
// four code-review regressions: per-region IDF, tombstones-consuming-the-window,
// Limit==0/Offset>0 truncation, and cross-region duplicate Ids.
//
// Run: go test ./pkg/calibre/ -run TestSearchAllSinglePass_ -count=1 -v

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"
)

// methodID renders i as a valid UUID so bookIDToTombstone can parse it (tombstones
// key on the book UUID, not an arbitrary string).
func methodID(i int) string {
	return fmt.Sprintf("00000000-0000-0000-0000-%012d", i)
}

// writeMethodBooks writes books [start,start+n) with "method" rare in titles
// (only ids 3 and 33) and common in ~3/4 of abstracts — so per-field DF, and thus
// IDF, genuinely spans regions.
func writeMethodBooks(t *testing.T, path string, start, n int) {
	t.Helper()
	f, err := os.Create(path)
	if err != nil {
		t.Fatal(err)
	}
	w := bufio.NewWriter(f)
	for i := start; i < start+n; i++ {
		b := Book{
			Id:           methodID(i),
			UUID:         fmt.Sprintf("u%d", i),
			Title:        fmt.Sprintf("Book number %d about things", i),
			Authors:      []string{"Auth"},
			Tags:         []string{"misc"},
			Abstract:     "filler text",
			LastModified: fmt.Sprintf("2024-02-%02dT00:00:00+00:00", (i%27)+1),
			LibraryUUID:  "L",
		}
		if i%4 != 0 {
			b.Abstract = fmt.Sprintf("a discussion of method number %d", i)
		}
		if i == 3 || i == 33 {
			b.Title = fmt.Sprintf("The method of %d", i)
		}
		line, _ := json.Marshal(b)
		w.Write(line)
		w.WriteByte('\n')
	}
	w.Flush()
	f.Close()
}

// buildTwoRegionIndex builds a base region (30 books) then appends a delta region
// (10 books), optionally tombstoning tombIDs — a genuine 2-region MWSC.
func buildTwoRegionIndex(t *testing.T, tombIDs []string) *MotwSearch {
	t.Helper()
	dir := t.TempDir()
	idxPath := filepath.Join(dir, "idx")

	base := filepath.Join(dir, "base.jsonl")
	writeMethodBooks(t, base, 0, 30)
	ms := &MotwSearch{JsonlPath: base, IndexPath: idxPath, IndexDescription: true}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}

	delta := filepath.Join(dir, "delta.jsonl")
	writeMethodBooks(t, delta, 30, 10)
	ms2 := &MotwSearch{JsonlPath: delta, IndexPath: idxPath, IndexDescription: true}
	dIdx, err := ms2.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	var tombs [][16]byte
	for _, id := range tombIDs {
		ts, err := bookIDToTombstone(id)
		if err != nil {
			t.Fatal(err)
		}
		tombs = append(tombs, ts)
	}
	if err := ms2.AppendToFile(dIdx, tombs); err != nil {
		t.Fatal(err)
	}
	return &MotwSearch{IndexPath: idxPath}
}

func searchAllNew(t *testing.T, s *MotwSearch, query string, opts SearchOptions) []*Book {
	t.Helper()
	opened, err := s.Open()
	if err != nil {
		t.Fatal(err)
	}
	defer opened.Close()
	books, _, err := opened.Search(context.Background(),
		SearchQuery{Field: FieldAll, Text: query, Mode: ModeExact}, opts)
	if err != nil {
		t.Fatal(err)
	}
	return books
}

func idScoreMap(books []*Book) map[string]float64 {
	m := make(map[string]float64, len(books))
	for _, b := range books {
		m[b.Id] = b.SearchScore
	}
	return m
}

// [0] On a multi-region index the new path's per-book scores must equal the old
// IDF-once path's. The pre-fix code recomputed IDF per region, diverging on region-2
// books.
func TestSearchAllSinglePass_MultiRegionIDFEquivalence(t *testing.T) {
	s := buildTwoRegionIndex(t, nil)
	opts := SearchOptions{SortMode: SortRelevance}
	newM := idScoreMap(searchAllNew(t, s, "method", opts))
	oldM := idScoreMap(searchAllOld(t, s, "method", opts))
	if len(newM) != len(oldM) {
		t.Fatalf("[0] result set size: new=%d old=%d", len(newM), len(oldM))
	}
	for id, os := range oldM {
		ns, ok := newM[id]
		if !ok {
			t.Fatalf("[0] book %s in old result but missing from new", id)
		}
		if d := ns - os; d > 1e-9 || d < -1e-9 {
			t.Fatalf("[0] book %s score new=%.6f old=%.6f — per-region IDF regression", id, ns, os)
		}
	}
	t.Logf("[0] OK: %d books, per-book scores identical to IDF-once oracle across 2 regions", len(newM))
}

// [1] Tombstoned books must not occupy window slots — a bounded page must still
// return `limit` LIVE books when enough live matches exist.
func TestSearchAllSinglePass_TombstonesDontShrinkWindow(t *testing.T) {
	// Tombstone the highest-scoring matches (books 3 and 33 carry "method" in the
	// title — top-ranked) so they fall INSIDE a bounded window: the buggy code admitted
	// them to the top-K heap and filtered them only at materialization, shrinking the
	// page; the fix drops them before bounding.
	dead := []string{methodID(3), methodID(33)}
	s := buildTwoRegionIndex(t, dead)
	opts := SearchOptions{SortMode: SortRelevance, Limit: 8}
	newB := searchAllNew(t, s, "method", opts)
	oldB := searchAllOld(t, s, "method", opts)
	for _, b := range newB {
		for _, d := range dead {
			if b.Id == d {
				t.Fatalf("[1] tombstoned book %s returned", d)
			}
		}
	}
	if len(newB) != len(oldB) {
		t.Fatalf("[1] window size new=%d old=%d — tombstones consumed slots", len(newB), len(oldB))
	}
	t.Logf("[1] OK: %d live books in the window, no tombstoned slots", len(newB))
}

// [2] Limit==0 with Offset>0 must stay unbounded (the caller applies offset); the
// pre-fix capK=Offset truncated the heap.
func TestSearchAllSinglePass_UnboundedWithOffset(t *testing.T) {
	s := buildTwoRegionIndex(t, nil)
	full := searchAllNew(t, s, "method", SearchOptions{SortMode: SortRelevance})
	off := searchAllNew(t, s, "method", SearchOptions{SortMode: SortRelevance, Offset: 3, Limit: 0})
	if len(off) != len(full) {
		t.Fatalf("[2] Limit=0,Offset=3 returned %d, want all %d — truncation regression", len(off), len(full))
	}
	t.Logf("[2] OK: unbounded query with offset returns all %d matches", len(full))
}

// [3] The same book Id present in two regions (federated aggregate) must collapse to
// a single result row.
func TestSearchAllSinglePass_CrossRegionDedup(t *testing.T) {
	dir := t.TempDir()
	idxPath := filepath.Join(dir, "idx")
	write := func(path string) {
		f, _ := os.Create(path)
		w := bufio.NewWriter(f)
		b := Book{Id: "100", UUID: "u100", Title: "The method of everything",
			Authors: []string{"A"}, Tags: []string{"t"}, Abstract: "method method",
			LastModified: "2024-03-01T00:00:00+00:00", LibraryUUID: "L"}
		line, _ := json.Marshal(b)
		w.Write(line)
		w.WriteByte('\n')
		w.Flush()
		f.Close()
	}
	base := filepath.Join(dir, "base.jsonl")
	write(base)
	ms := &MotwSearch{JsonlPath: base, IndexPath: idxPath, IndexDescription: true}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}
	delta := filepath.Join(dir, "delta.jsonl")
	write(delta) // same Id "100" in region 2
	ms2 := &MotwSearch{JsonlPath: delta, IndexPath: idxPath, IndexDescription: true}
	dIdx, err := ms2.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms2.AppendToFile(dIdx, nil); err != nil {
		t.Fatal(err)
	}

	newB := searchAllNew(t, &MotwSearch{IndexPath: idxPath}, "method", SearchOptions{SortMode: SortRelevance})
	count := 0
	for _, b := range newB {
		if b.Id == "100" {
			count++
		}
	}
	if count != 1 {
		t.Fatalf("[3] book 100 appeared %d times across 2 regions, want 1 (lost Id dedup)", count)
	}
	t.Logf("[3] OK: duplicate Id across regions collapsed to one row")
}
