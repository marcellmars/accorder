package calibre

import (
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"time"
)

type SyncActionKind int

const (
	SyncNoOp SyncActionKind = iota
	SyncFullDownload
	SyncRangeFetch
)

type SyncAction struct {
	Kind   SyncActionKind
	Reason string
}

type CachedSyncState struct {
	BaseGeneration    string `json:"baseGeneration"`
	PointerGeneration uint64 `json:"pointerGeneration"`
	LastCompactGen    uint64 `json:"lastCompactGen"`
}

func ResolveRelativeURL(base *url.URL, relative string) (string, error) {
	ref, err := url.Parse(relative)
	if err != nil {
		return "", fmt.Errorf("parse relative URL %q: %w", relative, err)
	}
	return base.ResolveReference(ref).String(), nil
}

func DetermineSyncAction(cached *CachedSyncState, pf PointerFile, mode string, force bool) SyncAction {
	if force {
		return SyncAction{Kind: SyncFullDownload, Reason: "forced"}
	}

	if cached == nil {
		return SyncAction{Kind: SyncFullDownload, Reason: "first sync"}
	}

	if cached.BaseGeneration != pf.Index.BaseGeneration {
		return SyncAction{
			Kind:   SyncFullDownload,
			Reason: "lineage break: BaseGeneration changed",
		}
	}

	if cached.PointerGeneration == pf.Index.PointerGeneration {
		return SyncAction{Kind: SyncNoOp, Reason: "up to date"}
	}

	if cached.PointerGeneration > pf.Index.PointerGeneration {
		return SyncAction{
			Kind:   SyncFullDownload,
			Reason: fmt.Sprintf("pointerGeneration regressed (%d → %d) — resync", cached.PointerGeneration, pf.Index.PointerGeneration),
		}
	}

	newCompaction := pf.LastCompact != nil &&
		pf.LastCompact.PointerGeneration > cached.LastCompactGen

	switch mode {
	case "compact":
		return SyncAction{
			Kind:   SyncFullDownload,
			Reason: fmt.Sprintf("compact mode: pointerGeneration %d → %d", cached.PointerGeneration, pf.Index.PointerGeneration),
		}
	case "append", "hybrid":
		if newCompaction {
			return SyncAction{
				Kind:   SyncFullDownload,
				Reason: fmt.Sprintf("%s mode: compaction detected — re-download", mode),
			}
		}
		return SyncAction{
			Kind:   SyncRangeFetch,
			Reason: fmt.Sprintf("%s mode: range-fetch pointerGeneration %d → %d", mode, cached.PointerGeneration, pf.Index.PointerGeneration),
		}
	default:
		return SyncAction{Kind: SyncFullDownload, Reason: fmt.Sprintf("unknown mode %q — full download", mode)}
	}
}

func ComputeRangeFetchOffset(zstPath string) (int64, error) {
	f, err := os.Open(zstPath)
	if err != nil {
		return 0, fmt.Errorf("ComputeRangeFetchOffset: open: %w", err)
	}
	defer f.Close()

	_, seekableOffset, err := readContainerHeader(f)
	if err != nil {
		return 0, fmt.Errorf("ComputeRangeFetchOffset: %w", err)
	}

	fileSize, err := f.Seek(0, io.SeekEnd)
	if err != nil {
		return 0, fmt.Errorf("ComputeRangeFetchOffset: seek end: %w", err)
	}
	seekableLen := fileSize - seekableOffset

	footer := make([]byte, seekTableFooterSize)
	if _, err := f.ReadAt(footer, fileSize-int64(seekTableFooterSize)); err != nil {
		return 0, fmt.Errorf("ComputeRangeFetchOffset: read footer: %w", err)
	}
	tableStart, entrySize, err := seekTableStart(footer, seekableLen)
	if err != nil {
		return 0, fmt.Errorf("ComputeRangeFetchOffset: %w", err)
	}

	entriesLen := seekableLen - tableStart - 8 - int64(seekTableFooterSize)
	entries := make([]byte, entriesLen)
	if _, err := f.ReadAt(entries, seekableOffset+tableStart+8); err != nil {
		return 0, fmt.Errorf("ComputeRangeFetchOffset: read seek table: %w", err)
	}

	if _, err := f.Seek(0, io.SeekStart); err != nil {
		return 0, fmt.Errorf("ComputeRangeFetchOffset: rewind: %w", err)
	}
	rdr, dec, _, err := openMWSC(f)
	if err != nil {
		return 0, fmt.Errorf("ComputeRangeFetchOffset: %w", err)
	}
	defer dec.Close()
	defer rdr.Close()
	msStart, err := manifestSpanStart(rdr)
	if err != nil {
		return 0, fmt.Errorf("ComputeRangeFetchOffset: %w", err)
	}

	if keptComp, _, aligned := keptFrameSpan(entries, entrySize, msStart); aligned {
		return seekableOffset + keptComp, nil
	}
	return seekableOffset + tableStart, nil
}

func syncStateFilename(cacheDir, libraryUUID string) string {
	return filepath.Join(cacheDir, libraryUUID+".sync-state.json")
}

func LoadSyncState(cacheDir, libraryUUID string) (*CachedSyncState, error) {
	data, err := os.ReadFile(syncStateFilename(cacheDir, libraryUUID))
	if err != nil {
		return nil, err
	}
	var state CachedSyncState
	if err := json.Unmarshal(data, &state); err != nil {
		return nil, fmt.Errorf("LoadSyncState: unmarshal: %w", err)
	}
	return &state, nil
}

func SaveSyncState(cacheDir, key string, pf PointerFile) error {
	state := CachedSyncState{
		BaseGeneration:    pf.Index.BaseGeneration,
		PointerGeneration: pf.Index.PointerGeneration,
	}
	if pf.LastCompact != nil {
		state.LastCompactGen = pf.LastCompact.PointerGeneration
	}
	data, err := json.MarshalIndent(state, "", "  ")
	if err != nil {
		return fmt.Errorf("SaveSyncState: marshal: %w", err)
	}
	return os.WriteFile(syncStateFilename(cacheDir, key), data, 0644)
}

func NewSyncHTTPClient() *http.Client {
	return &http.Client{
		Transport: &http.Transport{
			DialContext:           (&net.Dialer{Timeout: 10 * time.Second}).DialContext,
			TLSHandshakeTimeout:   10 * time.Second,
			ResponseHeaderTimeout: 30 * time.Second,
		},
	}
}
