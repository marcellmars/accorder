package calibre

// Tests for the SPA root handler's fallback: root-relative cover/book
// paths from the rendered site must reach the provided file handler
// instead of dying with the SPA's 404.

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
)

func TestRegisterFrontendRoutesWithFallback(t *testing.T) {
	hit := ""
	fallback := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		hit = r.URL.Path
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("file-bytes"))
	})

	mux := http.NewServeMux()
	RegisterFrontendRoutesWithFallback(mux, fallback)

	// "/" still serves the injected SPA.
	rec := httptest.NewRecorder()
	mux.ServeHTTP(rec, httptest.NewRequest("GET", "/", nil))
	if rec.Code != 200 || !strings.Contains(rec.Body.String(), "__RESTAPI__") {
		t.Fatalf("root: code=%d, SPA injection missing", rec.Code)
	}

	// A root-relative book path reaches the fallback.
	rec = httptest.NewRecorder()
	mux.ServeHTTP(rec, httptest.NewRequest("GET", "/Andy%20Clarke/Videogames%20(12)/cover.jpg", nil))
	if rec.Code != 200 || rec.Body.String() != "file-bytes" {
		t.Fatalf("cover path: code=%d body=%q, want fallback", rec.Code, rec.Body.String())
	}
	if !strings.Contains(hit, "cover.jpg") {
		t.Errorf("fallback saw path %q, want the cover path", hit)
	}
}

// TestFrontendCacheHeaders verifies the embedded SPA assets and shell carry an
// ETag + Cache-Control: no-cache so a redeploy busts the browser cache, and that
// an unchanged asset revalidates to 304 instead of re-downloading.
func TestFrontendCacheHeaders(t *testing.T) {
	mux := http.NewServeMux()
	RegisterFrontendRoutes(mux)

	for _, path := range []string{"/", "/static/js/bundle.js"} {
		rec := httptest.NewRecorder()
		mux.ServeHTTP(rec, httptest.NewRequest("GET", path, nil))
		if rec.Code != 200 {
			t.Fatalf("%s: code=%d, want 200", path, rec.Code)
		}
		cc := rec.Header().Get("Cache-Control")
		if !strings.Contains(cc, "no-cache") {
			t.Errorf("%s: Cache-Control=%q, want no-cache", path, cc)
		}
		etag := rec.Header().Get("ETag")
		if etag == "" {
			t.Fatalf("%s: missing ETag", path)
		}

		// Same ETag → 304, no body re-download.
		rec2 := httptest.NewRecorder()
		req := httptest.NewRequest("GET", path, nil)
		req.Header.Set("If-None-Match", etag)
		mux.ServeHTTP(rec2, req)
		if rec2.Code != http.StatusNotModified {
			t.Errorf("%s: If-None-Match %s → code=%d, want 304", path, etag, rec2.Code)
		}
	}
}

func TestRegisterFrontendRoutesNilFallback404s(t *testing.T) {
	mux := http.NewServeMux()
	RegisterFrontendRoutes(mux)
	rec := httptest.NewRecorder()
	mux.ServeHTTP(rec, httptest.NewRequest("GET", "/whatever/cover.jpg", nil))
	if rec.Code != http.StatusNotFound {
		t.Fatalf("nil fallback: code=%d, want 404", rec.Code)
	}
}
