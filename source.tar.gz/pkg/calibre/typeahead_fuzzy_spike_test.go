package calibre

import (
	"testing"

	"github.com/blevesearch/vellum/levenshtein"
)

func TestTypeaheadIndex_SuggestFuzzy(t *testing.T) {
	c := entityCollector{}
	c.add(FieldAuthor, "Jodi Dean")
	c.add(FieldAuthor, "Jodi Melamed")
	c.add(FieldAuthor, "Sean Dockray")
	c.add(FieldTitle, "Jodi")

	blob, err := buildEntityFST(c)
	if err != nil {
		t.Fatalf("buildEntityFST: %v", err)
	}
	d, err := parseSortedDict(blob)
	if err != nil {
		t.Fatalf("parseSortedDict: %v", err)
	}
	v := &vellumTypeaheadIndex{dicts: []*sortedTermDict{d}}
	defer v.Close()

	suggs, err := v.SuggestFuzzy(FieldAuthor, "jody", 1, 0)
	if err != nil {
		t.Fatalf("SuggestFuzzy(author): %v", err)
	}
	want := map[string]bool{"Jodi Dean": false, "Jodi Melamed": false}
	for _, sg := range suggs {
		if sg.Field != FieldAuthor {
			t.Errorf("author-field arm returned suggestion from field %q: %+v", sg.Field, sg)
		}
		if sg.Term != "jodi" {
			t.Errorf("unexpected fuzzy term %q (want jodi)", sg.Term)
		}
		if _, ok := want[sg.Entity]; !ok {
			t.Errorf("unexpected fuzzy entity %q", sg.Entity)
		}
		want[sg.Entity] = true
	}
	for e, found := range want {
		if !found {
			t.Errorf("expected entity %q to match query 'jody' at distance 1", e)
		}
	}

	all, err := v.SuggestFuzzy("", "jody", 1, 0)
	if err != nil {
		t.Fatalf("SuggestFuzzy(any): %v", err)
	}
	titleSeen := false
	for _, sg := range all {
		if sg.Field == FieldTitle && sg.Entity == "Jodi" {
			titleSeen = true
		}
	}
	if !titleSeen {
		t.Errorf("field==\"\" arm did not surface the title-field entity: %+v", all)
	}
	if len(all) != len(suggs)+1 {
		t.Errorf("field==\"\" arm returned %d suggestions, want %d (author hits + title hit)", len(all), len(suggs)+1)
	}

	limited, err := v.SuggestFuzzy(FieldAuthor, "jody", 1, 1)
	if err != nil {
		t.Fatalf("SuggestFuzzy(limit=1): %v", err)
	}
	if len(limited) != 1 {
		t.Errorf("limit=1 returned %d suggestions", len(limited))
	}

	lab, err := levenshtein.NewLevenshteinAutomatonBuilder(1, true)
	if err != nil {
		t.Fatalf("NewLevenshteinAutomatonBuilder: %v", err)
	}
	dfa, err := lab.BuildDfa("jody", 1)
	if err != nil {
		t.Fatalf("BuildDfa: %v", err)
	}
	start, end := fieldRange(FieldAuthor)
	prefixLen := len(FieldAuthor) + 1
	naive := 0
	d.rangeScan(start, end, func(key []byte, _ uint64) {
		if match, _ := dfa.MatchAndDistance(string(key[prefixLen:])); match {
			naive++
		}
	})
	if naive != 0 {
		t.Errorf("naive un-stripped matching found %d keys; expected 0 (entity suffix should inflate distance)", naive)
	}
}
