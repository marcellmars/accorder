package calibre

// Tests for the owned seekable-zstd reader (seekable_reader.go), replacing
// gitlab.com/rackn/seekable-zstd:
//   - cq-09 io.ReaderAt contract checklist (EOF on short read, zero-length
//     reads, out-of-bounds, exact-end reads, section confinement)
//   - deterministic corruption tests, one per parser/read rejection rule
//   - 8-byte (checksum-less) legacy seek tables — a LIVE path: AppendToFile
//     re-writes merged tables with the base index's entrySize and (since the
//     own-seekable-reader review) normalizes its NEW entries to that same
//     width, so appending onto an 8-byte base stays 8-byte throughout
//   - concurrent ReadAt on a shared reader (run with -race), mirroring the
//     aggregator-serve spike's TestSpikeConcurrentReadAtSameDecoder
//   - fuzzed ReadAt against an in-memory reference

import (
	"bytes"
	"encoding/binary"
	"errors"
	"io"
	"math/rand"
	"os"
	"strings"
	"sync"
	"testing"

	"github.com/cespare/xxhash/v2"
	"github.com/klauspost/compress/zstd"
)

// handRolledSeekableStream builds a seekable-zstd stream (frames + seek
// table) via the production-proven hand-rolled path: per-chunk EncodeAll +
// hand-built entries + writeSeekTable. entrySize selects 12-byte checksummed
// entries (footer flag 0x80) or 8-byte legacy entries.
func handRolledSeekableStream(tb testing.TB, encOpts []zstd.EOption, chunkSize, entrySize int, data []byte) []byte {
	tb.Helper()
	var buf bytes.Buffer
	var entries []byte
	for off := 0; off < len(data); off += chunkSize {
		end := min(off+chunkSize, len(data))
		chunk := data[off:end]
		fe, err := zstd.NewWriter(nil, encOpts...)
		if err != nil {
			tb.Fatal(err)
		}
		frame := fe.EncodeAll(chunk, nil)
		fe.Close()
		buf.Write(frame)
		var entry [seekTableEntrySizeCksm]byte
		binary.LittleEndian.PutUint32(entry[0:4], uint32(len(frame)))
		binary.LittleEndian.PutUint32(entry[4:8], uint32(len(chunk)))
		if entrySize == seekTableEntrySizeCksm {
			binary.LittleEndian.PutUint32(entry[8:12], uint32(xxhash.Sum64(chunk)))
		}
		entries = append(entries, entry[:entrySize]...)
	}
	if err := writeSeekTable(&buf, entries, entrySize); err != nil {
		tb.Fatal(err)
	}
	return buf.Bytes()
}

func testPayload(n int) []byte {
	data := make([]byte, 0, n)
	for i := 0; i < n; i++ {
		data = append(data, byte('a'+(i*2654435761)%26))
	}
	return data
}

func openOwnedReader(tb testing.TB, stream []byte) *mwscReaderAt {
	tb.Helper()
	dec, err := zstd.NewReader(nil)
	if err != nil {
		tb.Fatal(err)
	}
	tb.Cleanup(dec.Close)
	rdr, err := newMWSCReaderAt(bytes.NewReader(stream), int64(len(stream)), dec)
	if err != nil {
		tb.Fatalf("newMWSCReaderAt: %v", err)
	}
	tb.Cleanup(func() { rdr.Close() })
	return rdr
}

const contractChunk = 8 << 10

func TestOwnedReaderContract(t *testing.T) {
	data := testPayload(3*contractChunk + 777) // multiple frames incl. short tail
	stream := handRolledSeekableStream(t, nil, contractChunk, seekTableEntrySizeCksm, data)
	rdr := openOwnedReader(t, stream)
	size := int64(len(data))

	if rdr.Size() != size {
		t.Fatalf("Size=%d want %d", rdr.Size(), size)
	}
	if rdr.numFrames() != 4 {
		t.Fatalf("numFrames=%d want 4", rdr.numFrames())
	}

	t.Run("full read equals payload, ends exactly at Size with nil error", func(t *testing.T) {
		got := make([]byte, size)
		n, err := rdr.ReadAt(got, 0)
		if err != nil || int64(n) != size {
			t.Fatalf("ReadAt full: n=%d err=%v", n, err)
		}
		if !bytes.Equal(got, data) {
			t.Fatal("payload mismatch")
		}
	})

	t.Run("multi-frame spanning read", func(t *testing.T) {
		off := int64(contractChunk - 100)
		got := make([]byte, 2*contractChunk) // spans frames 0..2
		n, err := rdr.ReadAt(got, off)
		if err != nil || n != len(got) {
			t.Fatalf("spanning ReadAt: n=%d err=%v", n, err)
		}
		if !bytes.Equal(got, data[off:off+int64(len(got))]) {
			t.Fatal("spanning read mismatch")
		}
	})

	t.Run("exact-end tail read returns nil, not EOF", func(t *testing.T) {
		got := make([]byte, 8)
		n, err := rdr.ReadAt(got, size-8)
		if err != nil || n != 8 {
			t.Fatalf("exact-end ReadAt: n=%d err=%v (readManifestFromDecoder depends on err==nil here)", n, err)
		}
		if !bytes.Equal(got, data[size-8:]) {
			t.Fatal("tail bytes mismatch")
		}
	})

	t.Run("read spanning past tail: short read with io.EOF", func(t *testing.T) {
		got := make([]byte, 10)
		n, err := rdr.ReadAt(got, size-5)
		if n != 5 || !errors.Is(err, io.EOF) {
			t.Fatalf("past-tail ReadAt: n=%d err=%v, want n=5 io.EOF", n, err)
		}
		if !bytes.Equal(got[:5], data[size-5:]) {
			t.Fatal("short-read bytes mismatch")
		}
	})

	t.Run("read at or past Size is io.EOF", func(t *testing.T) {
		for _, off := range []int64{size, size + 1, size + 1<<20} {
			n, err := rdr.ReadAt(make([]byte, 1), off)
			if n != 0 || !errors.Is(err, io.EOF) {
				t.Fatalf("off=%d: n=%d err=%v, want 0, io.EOF", off, n, err)
			}
		}
	})

	t.Run("zero-length read returns (0, nil) unconditionally", func(t *testing.T) {
		for _, off := range []int64{0, -1, size, size + 99} {
			if n, err := rdr.ReadAt(nil, off); n != 0 || err != nil {
				t.Fatalf("zero-length at %d: n=%d err=%v", off, n, err)
			}
		}
	})

	t.Run("negative offset is an error, not EOF", func(t *testing.T) {
		n, err := rdr.ReadAt(make([]byte, 1), -1)
		if n != 0 || err == nil || errors.Is(err, io.EOF) {
			t.Fatalf("negative offset: n=%d err=%v", n, err)
		}
	})

	t.Run("section reader confinement", func(t *testing.T) {
		sr := io.NewSectionReader(rdr, 100, 300)
		got, err := io.ReadAll(sr)
		if err != nil {
			t.Fatal(err)
		}
		if !bytes.Equal(got, data[100:400]) {
			t.Fatal("section read mismatch")
		}
	})
}

func TestOwnedReaderClose(t *testing.T) {
	data := testPayload(2 * contractChunk)
	stream := handRolledSeekableStream(t, nil, contractChunk, seekTableEntrySizeCksm, data)
	rdr := openOwnedReader(t, stream)

	if err := rdr.Close(); err != nil {
		t.Fatal(err)
	}
	if err := rdr.Close(); err != nil {
		t.Fatalf("Close not idempotent: %v", err)
	}
	if n, err := rdr.ReadAt(make([]byte, 1), 0); err == nil || errors.Is(err, io.EOF) || n != 0 {
		t.Fatalf("read after Close: n=%d err=%v, want non-EOF error", n, err)
	}
	if n, err := rdr.ReadAt(nil, 0); n != 0 || err != nil {
		t.Fatalf("zero-length read after Close must stay (0, nil): n=%d err=%v", n, err)
	}
}

func TestOwnedReader8ByteEntries(t *testing.T) {
	data := testPayload(2*contractChunk + 123)
	stream := handRolledSeekableStream(t, nil, contractChunk, seekTableEntrySize8, data)
	rdr := openOwnedReader(t, stream)

	if rdr.checksums {
		t.Fatal("8-byte table must not enable checksum verification")
	}
	got := make([]byte, len(data))
	if _, err := rdr.ReadAt(got, 0); err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(got, data) {
		t.Fatal("8-byte round-trip mismatch")
	}
}

func TestOwnedReaderEmptyStream(t *testing.T) {
	stream := handRolledSeekableStream(t, nil, contractChunk, seekTableEntrySizeCksm, nil)
	rdr := openOwnedReader(t, stream)
	if rdr.Size() != 0 || rdr.numFrames() != 0 {
		t.Fatalf("empty stream: Size=%d frames=%d", rdr.Size(), rdr.numFrames())
	}
	if n, err := rdr.ReadAt(make([]byte, 1), 0); n != 0 || !errors.Is(err, io.EOF) {
		t.Fatalf("empty stream read: n=%d err=%v", n, err)
	}
}

// TestOwnedReaderCorruptTable exercises every parser-level rejection rule
// with one deterministic mutation each (donor: rackn reader_test.go
// TestSeekTableParsing). The entries-multiple-of-entrySize rule has no case:
// with the table span derived from the footer frame count, any count/size
// disagreement is caught by the declared-size check first (see
// readSeekTableTail).
func TestOwnedReaderCorruptTable(t *testing.T) {
	data := testPayload(2*contractChunk + 123)
	pristine := handRolledSeekableStream(t, nil, contractChunk, seekTableEntrySizeCksm, data)
	_, _, tableStart, err := readSeekTableEntries(pristine)
	if err != nil {
		t.Fatal(err)
	}

	dec, err := zstd.NewReader(nil)
	if err != nil {
		t.Fatal(err)
	}
	defer dec.Close()

	cases := []struct {
		name    string
		mutate  func(s []byte)
		errWant string
	}{
		{
			"footer magic",
			func(s []byte) { s[len(s)-1] ^= 0xFF },
			"magic mismatch",
		},
		{
			"reserved footer flag bits",
			func(s []byte) { s[len(s)-5] |= 0x04 },
			"reserved footer flag bits",
		},
		{
			"frame count inflated past stream start",
			func(s []byte) { binary.LittleEndian.PutUint32(s[len(s)-9:], 1<<24) },
			"negative table start",
		},
		{
			"skippable frame magic",
			func(s []byte) { s[tableStart] ^= 0xFF },
			"skippable frame magic mismatch",
		},
		{
			"declared frame size",
			func(s []byte) { s[tableStart+4] ^= 0xFF },
			"skippable frame size mismatch",
		},
		{
			// The entries' cSizes must prefix-sum exactly to tableStart; a
			// table inconsistent with the stream body is rejected at open.
			"entry cSize inconsistent with table start",
			func(s []byte) {
				cSize := binary.LittleEndian.Uint32(s[tableStart+8 : tableStart+12])
				binary.LittleEndian.PutUint32(s[tableStart+8:tableStart+12], cSize+1)
			},
			"compressed sizes sum to",
		},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			s := bytes.Clone(pristine)
			c.mutate(s)
			_, err := newMWSCReaderAt(bytes.NewReader(s), int64(len(s)), dec)
			if err == nil || !strings.Contains(err.Error(), c.errWant) {
				t.Fatalf("err=%v, want containing %q", err, c.errWant)
			}
		})
	}

	t.Run("stream too short", func(t *testing.T) {
		_, err := newMWSCReaderAt(bytes.NewReader(pristine[:4]), 4, dec)
		if err == nil || !strings.Contains(err.Error(), "stream too short") {
			t.Fatalf("err=%v", err)
		}
	})
}

// tailOnlyReaderAt fakes a huge stream by serving only its trailing bytes
// (seek table and/or footer), zero elsewhere — lets the 128 MiB caps be
// tested deterministically without allocating 128 MiB.
type tailOnlyReaderAt struct {
	size int64
	tail []byte // occupies [size-len(tail), size)
}

func (s *tailOnlyReaderAt) ReadAt(p []byte, off int64) (int, error) {
	tailStart := s.size - int64(len(s.tail))
	for i := range p {
		pos := off + int64(i)
		if pos >= tailStart && pos < s.size {
			p[i] = s.tail[pos-tailStart]
		} else {
			p[i] = 0
		}
	}
	return len(p), nil
}

func TestOwnedReaderSeekTableTooLarge(t *testing.T) {

	// 12M checksummed entries → table body 144 MiB > the 128 MiB cap, with a
	// claimed stream size large enough to keep tableStart positive.
	var footer [seekTableFooterSize]byte
	binary.LittleEndian.PutUint32(footer[0:4], 12<<20)
	footer[4] = 0x80
	binary.LittleEndian.PutUint32(footer[5:9], seekableMagicNumber)
	src := &tailOnlyReaderAt{size: 400 << 20, tail: footer[:]}

	_, _, _, err := readSeekTableTail(src, src.size)
	if err == nil || !strings.Contains(err.Error(), "seek table too large") {
		t.Fatalf("err=%v, want seek-table cap", err)
	}
}

// TestOwnedReaderCorruptFrames exercises the read-path rejection rules:
// checksum mismatch, decoded-length-vs-dSize mismatch, and the per-frame
// size caps — each via one targeted seek-table-entry mutation. The reader
// opens fine (the table is well-formed); the error surfaces on ReadAt.
func TestOwnedReaderCorruptFrames(t *testing.T) {
	data := testPayload(2*contractChunk + 123)
	pristine := handRolledSeekableStream(t, nil, contractChunk, seekTableEntrySizeCksm, data)
	_, _, tableStart, err := readSeekTableEntries(pristine)
	if err != nil {
		t.Fatal(err)
	}
	entry0 := tableStart + 8 // first entry: [cSize:4][dSize:4][checksum:4]

	dec, err := zstd.NewReader(nil)
	if err != nil {
		t.Fatal(err)
	}
	defer dec.Close()

	cases := []struct {
		name    string
		mutate  func(s []byte)
		errWant string
	}{
		{
			"checksum mismatch",
			func(s []byte) { s[entry0+8] ^= 0xFF },
			"checksum mismatch",
		},
		{
			"decoded length vs dSize",
			func(s []byte) {
				dSize := binary.LittleEndian.Uint32(s[entry0+4 : entry0+8])
				binary.LittleEndian.PutUint32(s[entry0+4:entry0+8], dSize+1)
			},
			"seek table says",
		},
		{
			"decompressed size over cap",
			func(s []byte) { binary.LittleEndian.PutUint32(s[entry0+4:entry0+8], maxDecoderFrameSize+1) },
			"decompressed size too large",
		},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			s := bytes.Clone(pristine)
			c.mutate(s)
			rdr, err := newMWSCReaderAt(bytes.NewReader(s), int64(len(s)), dec)
			if err != nil {
				t.Fatalf("open should succeed (table well-formed): %v", err)
			}
			defer rdr.Close()
			_, err = rdr.ReadAt(make([]byte, 16), 0)
			if err == nil || !strings.Contains(err.Error(), c.errWant) {
				t.Fatalf("err=%v, want containing %q", err, c.errWant)
			}
		})
	}

	t.Run("compressed size over cap (read-path guard)", func(t *testing.T) {
		// A single-entry table declaring cSize > cap, with a CONSISTENT
		// prefix-sum (tableStart == cSize), passes every open-time check;
		// the cap must fire on the read path before any allocation. Uses a
		// tail-only fake so the huge frame region is never materialized.
		entry := make([]byte, seekTableEntrySizeCksm)
		binary.LittleEndian.PutUint32(entry[0:4], maxDecoderFrameSize+1)
		binary.LittleEndian.PutUint32(entry[4:8], 100)
		var tbl bytes.Buffer
		writeSeekTableBuf(t, &tbl, entry, seekTableEntrySizeCksm)
		src := &tailOnlyReaderAt{size: int64(maxDecoderFrameSize+1) + int64(tbl.Len()), tail: tbl.Bytes()}
		rdr, err := newMWSCReaderAt(src, src.size, dec)
		if err != nil {
			t.Fatalf("open should succeed (consistent table): %v", err)
		}
		defer rdr.Close()
		if _, err := rdr.ReadAt(make([]byte, 16), 0); err == nil || !strings.Contains(err.Error(), "compressed size too large") {
			t.Fatalf("err=%v, want compressed-size cap", err)
		}
	})
}

// TestOwnedReaderConcurrentReadAt mirrors the aggregator-serve spike's
// TestSpikeConcurrentReadAtSameDecoder over the owned reader: 16 goroutines
// × 100 random reads on one shared reader. Run under -race. Three cache
// regimes: default (all frames cached), tiny budget (constant eviction
// churn), and zero budget (every frame bypasses the cache).
func TestOwnedReaderConcurrentReadAt(t *testing.T) {
	data := testPayload(8*contractChunk + 321)
	stream := handRolledSeekableStream(t, nil, contractChunk, seekTableEntrySizeCksm, data)
	size := int64(len(data))

	for _, regime := range []struct {
		name   string
		budget int64
	}{
		{"default budget", frameCacheBudgetBytes},
		{"evicting budget", 2 * contractChunk},
		{"zero budget (bypass)", 0},
	} {
		t.Run(regime.name, func(t *testing.T) {
			rdr := openOwnedReader(t, stream)
			rdr.cache.budget = regime.budget

			var wg sync.WaitGroup
			for g := 0; g < 16; g++ {
				wg.Add(1)
				go func(seed int64) {
					defer wg.Done()
					rng := rand.New(rand.NewSource(seed))
					for i := 0; i < 100; i++ {
						off := rng.Int63n(size)
						buf := make([]byte, 1+rng.Intn(3*contractChunk))
						n, err := rdr.ReadAt(buf, off)
						if err != nil && !errors.Is(err, io.EOF) {
							t.Errorf("ReadAt(%d): %v", off, err)
							return
						}
						if !bytes.Equal(buf[:n], data[off:off+int64(n)]) {
							t.Errorf("ReadAt(%d): payload mismatch over %d bytes", off, n)
							return
						}
					}
				}(int64(g))
			}
			wg.Wait()
		})
	}
}

func FuzzOwnedReaderReadAt(f *testing.F) {
	data := testPayload(3*contractChunk + 777)
	stream := handRolledSeekableStream(f, nil, contractChunk, seekTableEntrySizeCksm, data)
	dec, err := zstd.NewReader(nil)
	if err != nil {
		f.Fatal(err)
	}
	f.Cleanup(dec.Close)
	rdr, err := newMWSCReaderAt(bytes.NewReader(stream), int64(len(stream)), dec)
	if err != nil {
		f.Fatal(err)
	}
	f.Cleanup(func() { rdr.Close() })
	size := int64(len(data))

	f.Add(int64(0), 100)
	f.Add(size-1, 100)
	f.Add(int64(-5), 10)
	f.Add(size+5, 10)
	f.Add(int64(contractChunk-1), 2)

	f.Fuzz(func(t *testing.T, off int64, n int) {
		if n < 0 || n > 1<<20 {
			return
		}
		buf := make([]byte, n)
		got, err := rdr.ReadAt(buf, off)
		switch {
		case n == 0:
			if got != 0 || err != nil {
				t.Fatalf("zero-length: n=%d err=%v", got, err)
			}
		case off < 0:
			if err == nil || errors.Is(err, io.EOF) {
				t.Fatalf("negative offset: err=%v", err)
			}
		case off >= size:
			if got != 0 || !errors.Is(err, io.EOF) {
				t.Fatalf("past-end: n=%d err=%v", got, err)
			}
		default:
			wantN := min(int64(n), size-off)
			if int64(got) != wantN {
				t.Fatalf("n=%d want %d (err=%v)", got, wantN, err)
			}
			if !bytes.Equal(buf[:got], data[off:off+wantN]) {
				t.Fatal("payload mismatch")
			}
			if off+int64(n) > size {
				if !errors.Is(err, io.EOF) {
					t.Fatalf("expected io.EOF on short read, got %v", err)
				}
			} else if err != nil {
				t.Fatalf("unexpected error on in-bounds read: %v", err)
			}
		}
	})
}

// TestGoldenSeekableStreamLayout freezes today's on-disk seekable layout as
// checked-in testdata and asserts the reader parses it. This replaces the
// retired byte-identity oracle against rackn's writer: a symmetric layout
// drift mirrored in writeSeekTable and readSeekTableTail would round-trip
// green in-process but break every already-published index — this test
// catches it because the golden bytes never change (zstd DECODING of a
// frozen file is stable across library versions; only encoder output
// varies, which is why byte-identity was retired but a frozen artifact
// works). Regenerate ONLY on a deliberate, versioned format change:
//
//	REGEN_GOLDEN=1 go test -run TestGoldenSeekableStreamLayout ./pkg/calibre/
func TestGoldenSeekableStreamLayout(t *testing.T) {
	const streamPath = "testdata/golden_seekable_stream.bin"
	const payloadPath = "testdata/golden_seekable_payload.bin"
	if os.Getenv("REGEN_GOLDEN") == "1" {
		payload := testPayload(3*contractChunk + 777)
		stream := handRolledSeekableStream(t, []zstd.EOption{zstd.WithEncoderLevel(zstd.SpeedBestCompression)}, contractChunk, seekTableEntrySizeCksm, payload)
		if err := os.MkdirAll("testdata", 0o755); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(streamPath, stream, 0o644); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(payloadPath, payload, 0o644); err != nil {
			t.Fatal(err)
		}
		t.Log("golden files regenerated — commit only with a deliberate format change")
	}
	stream, err := os.ReadFile(streamPath)
	if err != nil {
		t.Fatalf("golden stream missing (regenerate only on a deliberate format change): %v", err)
	}
	payload, err := os.ReadFile(payloadPath)
	if err != nil {
		t.Fatal(err)
	}
	rdr := openOwnedReader(t, stream)
	if rdr.Size() != int64(len(payload)) {
		t.Fatalf("golden Size=%d want %d", rdr.Size(), len(payload))
	}
	if want := (len(payload) + contractChunk - 1) / contractChunk; rdr.numFrames() != want {
		t.Fatalf("golden numFrames=%d want %d", rdr.numFrames(), want)
	}
	got := make([]byte, len(payload))
	if _, err := rdr.ReadAt(got, 0); err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(got, payload) {
		t.Fatal("golden payload mismatch")
	}
}
