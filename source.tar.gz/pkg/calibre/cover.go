package calibre

import (
	"bytes"
	"image"
	"image/color"
	"image/jpeg"
	"os"
)

var defaultCoverJPEG []byte

func DefaultCoverJPEG() []byte {
	if defaultCoverJPEG != nil {
		return defaultCoverJPEG
	}

	img := image.NewRGBA(image.Rect(0, 0, 120, 160))
	gray := color.RGBA{R: 200, G: 200, B: 200, A: 255}
	for y := 0; y < 160; y++ {
		for x := 0; x < 120; x++ {
			img.Set(x, y, gray)
		}
	}

	var buf bytes.Buffer
	if err := jpeg.Encode(&buf, img, &jpeg.Options{Quality: 50}); err != nil {
		return nil
	}
	defaultCoverJPEG = buf.Bytes()
	return defaultCoverJPEG
}

func writeTempCover(data []byte) (*os.File, error) {
	f, err := os.CreateTemp("", "accorder-cover-*.jpg")
	if err != nil {
		return nil, err
	}
	if _, err := f.Write(data); err != nil {
		f.Close()
		os.Remove(f.Name())
		return nil, err
	}
	return f, nil
}
