package calibre

import (
	"accorder/pkg/bibtexjson"
	"crypto/md5"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"slices"
	"sort"
	"strconv"
	"strings"
)

var bookExtensions = map[string]bool{
	".pdf":  true,
	".epub": true,
	".mobi": true,
	".azw3": true,
	".djvu": true,
	".fb2":  true,
	".cbz":  true,
	".cbr":  true,
	".lit":  true,
	".rtf":  true,
	".doc":  true,
	".docx": true,
	".odt":  true,
	".txt":  true,
}

type ImportFile struct {
	AbsPath string
	Ext     string
}

type ImportEntry struct {
	ItemKey    string
	EffMtime   string
	Title      string
	Authors    []string
	AuthorSort string

	Identifiers map[string]string

	Tags        []string
	Language    string
	Comments    string
	Publisher   string
	Series      string
	SeriesIndex string
	PubDate     string

	Files []ImportFile
}

type Bundle struct {
	Alias    string
	ExportID string
}

type ImportStats struct {
	Added     int
	Updated   int
	Unchanged int
	Removed   int
	Total     int
	Orphaned  int // tracked books under this bundle no longer in the export (only when --prune is off)
}

func (s ImportStats) Summary() string {
	return fmt.Sprintf(">>>> %d added / %d updated / %d unchanged / %d removed  (of %d items)",
		s.Added, s.Updated, s.Unchanged, s.Removed, s.Total)
}

func LocateBetterBibTexExport(dir string) (jsonPath, baseDir string, err error) {
	matches, err := filepath.Glob(filepath.Join(dir, "*.json"))
	if err != nil {
		return "", "", fmt.Errorf("glob: %w", err)
	}
	if len(matches) == 0 {
		return "", "", fmt.Errorf("no .json files found in %s", dir)
	}
	if len(matches) > 1 {
		return "", "", fmt.Errorf("multiple .json files found in %s: expected exactly one", dir)
	}
	return matches[0], dir, nil
}

var romanNumeralRe = regexp.MustCompile(`^[IVXLCDMivxlcdm]+$`)

// romanToArabic converts a Roman-numeral string to its Arabic integer value.
// Subtractive notation is honored (IV=4, XL=40); the caller is expected to
// have screened input through romanNumeralRe so unknown runes cannot appear.
func romanToArabic(s string) int {
	values := map[byte]int{'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
	s = strings.ToUpper(s)
	total, prev := 0, 0
	for i := len(s) - 1; i >= 0; i-- {
		v := values[s[i]]
		if v < prev {
			total -= v
		} else {
			total += v
		}
		prev = v
	}
	return total
}

// coerceSeriesIndex normalizes a Zotero series-number string for Calibre's
// float-typed series_index column. Returns the input when it parses as a
// float, the Arabic form when it is a pure Roman numeral, and "" otherwise
// (the call site drops empty values via the existing guard in zoteroSync.go).
func coerceSeriesIndex(s string) string {
	s = strings.TrimSpace(s)
	if s == "" {
		return ""
	}
	if _, err := strconv.ParseFloat(s, 64); err == nil {
		return s
	}
	if romanNumeralRe.MatchString(s) {
		if n := romanToArabic(s); n > 0 {
			return strconv.Itoa(n)
		}
	}
	return ""
}

func qualifyingCreator(ct *bibtexjson.CreatorType) bool {
	if ct == nil {
		return false
	}
	switch *ct {
	case bibtexjson.Author, bibtexjson.Editor, bibtexjson.Director:
		return true
	}
	return false
}

func creatorNames(c bibtexjson.Creator) (display, sortName string) {
	if c.Name != nil && *c.Name != "" {
		return *c.Name, *c.Name
	}
	first := derefStr(c.FirstName)
	last := derefStr(c.LastName)
	switch {
	case first != "" && last != "":
		return first + " " + last, last + ", " + first
	case last != "":
		return last, last
	default:
		return first, first
	}
}

func EntriesFromBetterBibTex(bbt bibtexjson.BetterBibTex, baseDir string) []ImportEntry {
	var entries []ImportEntry

	for _, item := range bbt.Items {
		if item.ItemKey == nil || item.Title == nil {
			continue
		}

		var authors []string
		var sortNames []string
		for _, c := range item.Creators {
			if !qualifyingCreator(c.CreatorType) {
				continue
			}
			name, sortName := creatorNames(c)
			if name == "" {
				continue
			}
			authors = append(authors, name)
			sortNames = append(sortNames, sortName)
		}
		if len(authors) == 0 {
			continue
		}

		var files []ImportFile
		effMtime := derefStr(item.DateModified)
		for _, att := range item.Attachments {
			if att.Path == nil {
				continue
			}
			ext := strings.ToLower(filepath.Ext(*att.Path))
			if !bookExtensions[ext] {
				continue
			}
			absPath := filepath.Join(baseDir, *att.Path)
			if _, err := os.Stat(absPath); err != nil {
				continue
			}
			files = append(files, ImportFile{AbsPath: absPath, Ext: ext})
			if att.DateModified != nil && *att.DateModified > effMtime {
				effMtime = *att.DateModified
			}
		}
		if len(files) == 0 {
			continue
		}

		sort.Slice(files, func(i, j int) bool {
			if (files[i].Ext == ".pdf") != (files[j].Ext == ".pdf") {
				return files[i].Ext == ".pdf"
			}
			return files[i].Ext < files[j].Ext
		})

		identifiers := make(map[string]string)
		for scheme, v := range map[string]*string{"isbn": item.Isbn, "issn": item.Issn, "doi": item.Doi} {
			if v != nil && *v != "" {
				identifiers[scheme] = *v
			}
		}

		var tags []string
		for _, t := range item.Tags {
			if tag := strings.TrimSpace(strings.ReplaceAll(t.Tag, ",", "-")); tag != "" {
				tags = append(tags, tag)
			}
		}

		entry := ImportEntry{
			ItemKey:     *item.ItemKey,
			EffMtime:    effMtime,
			Title:       *item.Title,
			Authors:     authors,
			AuthorSort:  strings.Join(sortNames, " & "),
			Identifiers: identifiers,
			Tags:        tags,
			Language:    derefStr(item.Language),
			Comments:    derefStr(item.AbstractNote),
			Publisher:   derefStr(item.Publisher),
			Series:      derefStr(item.Series),
			SeriesIndex: coerceSeriesIndex(derefStr(item.SeriesNumber)),
			PubDate:     derefStr(item.Date),
			Files:       files,
		}
		entries = append(entries, entry)
	}

	return entries
}

func (e ImportEntry) FileHash() string {
	h := md5.New()
	for _, f := range e.Files {
		fh := md5.New()
		file, err := os.Open(f.AbsPath)
		if err != nil {
			continue
		}
		_, err = io.Copy(fh, file)
		file.Close()
		if err != nil {
			continue
		}
		fmt.Fprintf(h, "%s:%x", f.Ext, fh.Sum(nil))
	}
	return fmt.Sprintf("%x", h.Sum(nil))[:16]
}

func (e ImportEntry) Rev() string {
	return e.EffMtime + "+" + e.FileHash()
}

func (e ImportEntry) Exts() []string {
	exts := make([]string, 0, len(e.Files))
	for _, f := range e.Files {
		exts = append(exts, f.Ext)
	}
	return sortedUnique(exts)
}

func sortedUnique(s []string) []string {
	if len(s) == 0 {
		return nil
	}
	out := append([]string(nil), s...)
	sort.Strings(out)
	return slices.Compact(out)
}

func derefStr(s *string) string {
	if s == nil {
		return ""
	}
	return *s
}
