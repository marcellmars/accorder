package calibre

import (
	"bufio"
	"fmt"
	"os"
	"path/filepath"
	"testing"

	"github.com/goccy/go-json"
	"github.com/google/uuid"
)

// seedJSONLWithIDs writes n synthetic Book JSONL lines with valid UUID _id fields,
// suitable for testing tombstone and RecencyIndex logic.
func seedJSONLWithIDs(tb testing.TB, n int, libraryUUID, lastModPrefix string) string {
	tb.Helper()
	dir := tb.TempDir()
	path := filepath.Join(dir, "books.jsonl")
	f, err := os.Create(path)
	if err != nil {
		tb.Fatal(err)
	}
	defer f.Close()
	w := bufio.NewWriter(f)
	defer w.Flush()

	for i := 0; i < n; i++ {
		book := Book{
			Title:        fmt.Sprintf("Book %d", i),
			Authors:      []string{fmt.Sprintf("Author %d", i)},
			Tags:         []string{"test"},
			LastModified: fmt.Sprintf("%s-%02dT00:00:00+00:00", lastModPrefix, (i%28)+1),
			LibraryUUID:  libraryUUID,
			Librarian:    "testlib",
			UUID:         fmt.Sprintf("book-uuid-%d", i),
			Id:           uuid.New().String(),
		}
		data, err := json.Marshal(book)
		if err != nil {
			tb.Fatal(err)
		}
		_, _ = w.Write(data)
		_ = w.WriteByte('\n')
	}
	return path
}

// TestAppendToFilePreservesRecencyIndex builds an index with CompressToFile,
// then appends to it with AppendToFile, and verifies the resulting manifest
// has a non-empty RecencyIndex and preserved EntityProvenance.
func TestAppendToFilePreservesRecencyIndex(t *testing.T) {

	// Phase 1: build base index with 20 books.
	basePath := seedJSONLWithIDs(t, 20, "lib-base", "2024-01")
	dir := t.TempDir()
	indexPath := filepath.Join(dir, "test_index")

	ms := &MotwSearch{
		JsonlPath:            basePath,
		IndexPath:            indexPath,
		IndexAggregateFields: true,
	}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex (base): %v", err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatalf("CompressToFile: %v", err)
	}

	// Verify base manifest exists and has books.
	baseMf, err := ReadExistingManifest(indexPath)
	if err != nil {
		t.Fatalf("ReadExistingManifest (base): %v", err)
	}
	if baseMf.NumBooks != 20 {
		t.Fatalf("base NumBooks = %d; want 20", baseMf.NumBooks)
	}

	// Phase 2: build delta with 10 more books and append.
	deltaPath := seedJSONLWithIDs(t, 10, "lib-delta", "2024-02")
	deltaMs := &MotwSearch{
		JsonlPath:            deltaPath,
		IndexPath:            indexPath,
		IndexAggregateFields: true,
	}
	deltaIdx, err := deltaMs.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex (delta): %v", err)
	}
	if err := deltaMs.AppendToFile(deltaIdx, nil); err != nil {
		t.Fatalf("AppendToFile: %v", err)
	}

	// Phase 3: verify the post-append manifest.
	appendedMf, err := ReadExistingManifest(indexPath)
	if err != nil {
		t.Fatalf("ReadExistingManifest (appended): %v", err)
	}

	// NumBooks should include both base and delta.
	if appendedMf.NumBooks != 30 {
		t.Fatalf("appended NumBooks = %d; want 30", appendedMf.NumBooks)
	}

	// Generation should have advanced.
	if appendedMf.Generation <= baseMf.Generation {
		t.Fatalf("Generation = %d; want > %d", appendedMf.Generation, baseMf.Generation)
	}

	// RecencyIndex must be non-empty (the fix).
	if len(appendedMf.RecencyIndex) == 0 {
		t.Fatal("RecencyIndex is empty after AppendToFile; want non-empty (bug #1 regression)")
	}

	// RecencyIndex should have 30 entries (all 30 books, no tombstones).
	if len(appendedMf.RecencyIndex) != 30 {
		t.Fatalf("RecencyIndex has %d entries; want 30", len(appendedMf.RecencyIndex))
	}

	// RecencyIndex must be sorted newest-first.
	for i := 1; i < len(appendedMf.RecencyIndex); i++ {
		prev := appendedMf.RecencyIndex[i-1]
		curr := appendedMf.RecencyIndex[i]
		if prev.LastModified < curr.LastModified {
			t.Fatalf("RecencyIndex not sorted newest-first at index %d: %q < %q",
				i, prev.LastModified, curr.LastModified)
		}
	}
}

// TestAppendToFileRecencyFiltersTombstones verifies that AppendToFile's
// RecencyIndex excludes tombstoned books.
func TestAppendToFileRecencyFiltersTombstones(t *testing.T) {

	// Build base with 20 books that have known IDs.
	dir := t.TempDir()
	basePath := filepath.Join(dir, "base.jsonl")
	indexPath := filepath.Join(dir, "test_index")

	// Write base books with deterministic UUIDs.
	baseIDs := make([]string, 20)
	{
		f, err := os.Create(basePath)
		if err != nil {
			t.Fatal(err)
		}
		w := bufio.NewWriter(f)
		for i := 0; i < 20; i++ {
			id := uuid.New().String()
			baseIDs[i] = id
			book := Book{
				Title:        fmt.Sprintf("Base Book %d", i),
				Authors:      []string{"Test Author"},
				Tags:         []string{"test"},
				LastModified: fmt.Sprintf("2024-01-%02dT00:00:00+00:00", (i%28)+1),
				LibraryUUID:  "lib-base",
				Librarian:    "testlib",
				UUID:         fmt.Sprintf("base-uuid-%d", i),
				Id:           id,
			}
			data, _ := json.Marshal(book)
			w.Write(data)
			w.WriteByte('\n')
		}
		w.Flush()
		f.Close()
	}

	ms := &MotwSearch{
		JsonlPath:            basePath,
		IndexPath:            indexPath,
		IndexAggregateFields: true,
	}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex: %v", err)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatalf("CompressToFile: %v", err)
	}

	// Build delta and tombstone the first 5 base books.
	deltaPath := seedJSONLWithIDs(t, 5, "lib-delta", "2024-02")
	var tombstones [][16]byte
	for i := 0; i < 5; i++ {
		ts, err := BookIDToTombstone(baseIDs[i])
		if err != nil {
			t.Fatalf("BookIDToTombstone: %v", err)
		}
		tombstones = append(tombstones, ts)
	}

	deltaMs := &MotwSearch{
		JsonlPath:            deltaPath,
		IndexPath:            indexPath,
		IndexAggregateFields: true,
	}
	deltaIdx, err := deltaMs.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex (delta): %v", err)
	}
	if err := deltaMs.AppendToFile(deltaIdx, tombstones); err != nil {
		t.Fatalf("AppendToFile: %v", err)
	}

	mf, err := ReadExistingManifest(indexPath)
	if err != nil {
		t.Fatalf("ReadExistingManifest: %v", err)
	}

	// RecencyIndex should have 20 (live base - 5 tombstoned + 5 delta = 20 books).
	if len(mf.RecencyIndex) != 20 {
		t.Fatalf("RecencyIndex has %d entries; want 20 (15 live base + 5 delta)", len(mf.RecencyIndex))
	}

	// Verify none of the tombstoned IDs appear in RecencyIndex.
	tombstoneIDSet := make(map[string]bool)
	for i := 0; i < 5; i++ {
		tombstoneIDSet[baseIDs[i]] = true
	}
	for _, re := range mf.RecencyIndex {
		if tombstoneIDSet[re.Id] {
			t.Fatalf("tombstoned book %s found in RecencyIndex", re.Id)
		}
	}
}
