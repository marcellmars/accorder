package calibre

import (
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
)

// Calibre's command-line tools (calibredb, calibre, ebook-convert, …) are NOT on
// PATH by default on macOS — they live inside the application bundle at
// /Applications/calibre.app/Contents/MacOS — nor on Windows. So a bare
// exec.Command("calibredb", …) fails there even with Calibre installed. These
// helpers resolve a tool to an absolute path, probing the known per-OS install
// locations after PATH.
//
// See: https://manual.calibre-ebook.com/faq.html ("the command line tools are
// inside the calibre bundle … not automatically added to your PATH").

// calibreBinDirEnv is an optional override: point it at the directory that holds
// Calibre's CLI tools (e.g. /Applications/calibre.app/Contents/MacOS) and it is
// tried before PATH and the built-in defaults.
const calibreBinDirEnv = "CALIBRE_BIN_DIR"

// findCalibreTool locates a Calibre CLI tool by absolute path. Resolution order:
//  1. $CALIBRE_BIN_DIR/<tool>   — explicit override (directory holding the tools)
//  2. exec.LookPath(tool)       — on PATH
//  3. known per-OS install dirs (calibreInstallDirs)
//
// Returns (path, true) on success, ("", false) if the tool is not found anywhere.
func findCalibreTool(tool string) (string, bool) {
	exeName := tool
	if runtime.GOOS == "windows" {
		exeName += ".exe"
	}
	if dir := os.Getenv(calibreBinDirEnv); dir != "" {
		if p := filepath.Join(dir, exeName); isExecutableFile(p) {
			return p, true
		}
	}
	if p, err := exec.LookPath(tool); err == nil {
		return p, true
	}
	for _, dir := range calibreInstallDirs() {
		if p := filepath.Join(dir, exeName); isExecutableFile(p) {
			return p, true
		}
	}
	return "", false
}

// calibreToolPath is findCalibreTool with a fallback to the bare tool name, so a
// genuinely-missing tool surfaces exec's clear "executable file not found in
// $PATH" error rather than a confusing absolute-path error.
func calibreToolPath(tool string) string {
	if p, ok := findCalibreTool(tool); ok {
		return p
	}
	return tool
}

// calibreInstallDirs lists the default directories that hold Calibre's CLI tools
// for the running OS.
func calibreInstallDirs() []string {
	home, _ := os.UserHomeDir()
	return calibreInstallDirsFor(runtime.GOOS, home)
}

// calibreInstallDirsFor is the pure, testable core of calibreInstallDirs.
func calibreInstallDirsFor(goos, home string) []string {
	switch goos {
	case "darwin":
		// System install, then a per-user ~/Applications install.
		dirs := []string{"/Applications/calibre.app/Contents/MacOS"}
		if home != "" {
			dirs = append(dirs, filepath.Join(home, "Applications", "calibre.app", "Contents", "MacOS"))
		}
		return dirs
	case "windows":
		return []string{`C:\Program Files\Calibre2`, `C:\Program Files (x86)\Calibre2`}
	default: // linux & other unix — usually on PATH; cover common manual installs
		return []string{"/opt/calibre", "/usr/local/bin", "/usr/bin"}
	}
}

// isExecutableFile reports whether p is a regular file that can be executed.
func isExecutableFile(p string) bool {
	info, err := os.Stat(p)
	if err != nil || info.IsDir() {
		return false
	}
	if runtime.GOOS == "windows" {
		return true // .exe presence is enough; no Unix mode bits
	}
	return info.Mode()&0o111 != 0
}
