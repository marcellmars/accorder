package calibre

import (
	"bytes"
	"fmt"
	"runtime"
	"testing"
)

// TestParallelBuildIndex_ByteIdentical verifies that BuildIndex produces
// byte-identical indexData regardless of GOMAXPROCS. The sequential baseline
// (GOMAXPROCS=1) is compared against parallel builds at GOMAXPROCS=2, 4, and
// runtime.NumCPU(). Both IndexDescription=false (3 fields) and
// IndexDescription=true (4 fields) are tested.
//

// This is the oracle test for the parallel-index-compile feature.
func TestParallelBuildIndex_ByteIdentical(t *testing.T) {

	// 64 books: 4 full segments, exercises multi-segment parallel dispatch.
	// 50 books: 3 full + 1 partial trailing segment.
	for _, tc := range []struct {
		name             string
		numBooks         int
		indexDescription bool
		seedFn           func(testing.TB, int) string
	}{
		{"64books_noDesc", 64, false, seedJSONL},
		{"50books_noDesc", 50, false, seedJSONL},
		{"64books_withDesc", 64, true, seedJSONLWithDescriptions},
		{"50books_withDesc", 50, true, seedJSONLWithDescriptions},
		{"17books_noDesc", 17, false, seedJSONL}, // 1 full + 1 partial segment
		{"33books_noDesc", 33, false, seedJSONL}, // 2 full + 1 partial
		{"100books_withDesc", 100, true, seedJSONLWithDescriptions},
	} {
		t.Run(tc.name, func(t *testing.T) {
			path := tc.seedFn(t, tc.numBooks)

			// Build the baseline at GOMAXPROCS=1 (forces single worker).
			prev := runtime.GOMAXPROCS(1)
			ms := &MotwSearch{JsonlPath: path, IndexDescription: tc.indexDescription}
			baseline, err := ms.BuildIndex()
			if err != nil {
				t.Fatalf("baseline BuildIndex: %v", err)
			}
			runtime.GOMAXPROCS(prev)

			gomaxValues := []int{2, 4}
			if n := runtime.NumCPU(); n > 4 {
				gomaxValues = append(gomaxValues, n)
			}

			for _, gmp := range gomaxValues {
				t.Run("gomaxprocs="+itoa(gmp), func(t *testing.T) {
					prev := runtime.GOMAXPROCS(gmp)
					defer runtime.GOMAXPROCS(prev)

					ms := &MotwSearch{JsonlPath: path, IndexDescription: tc.indexDescription}
					got, err := ms.BuildIndex()
					if err != nil {
						t.Fatalf("BuildIndex at GOMAXPROCS=%d: %v", gmp, err)
					}

					assertIndexDataEqual(t, baseline, got, gmp)
				})
			}
		})
	}
}

// TestParallelBuildIndex_AggregateFields verifies byte-identity when
// IndexAggregateFields is enabled (adds FieldID and FieldLibraryUUID
// postings).
func TestParallelBuildIndex_AggregateFields(t *testing.T) {
	path := seedJSONL(t, 64)

	prev := runtime.GOMAXPROCS(1)
	ms := &MotwSearch{JsonlPath: path, IndexAggregateFields: true}
	baseline, err := ms.BuildIndex()
	if err != nil {
		t.Fatalf("baseline BuildIndex: %v", err)
	}
	runtime.GOMAXPROCS(prev)

	for _, gmp := range []int{2, 4} {
		t.Run("gomaxprocs="+itoa(gmp), func(t *testing.T) {
			prev := runtime.GOMAXPROCS(gmp)
			defer runtime.GOMAXPROCS(prev)

			ms := &MotwSearch{JsonlPath: path, IndexAggregateFields: true}
			got, err := ms.BuildIndex()
			if err != nil {
				t.Fatalf("BuildIndex at GOMAXPROCS=%d: %v", gmp, err)
			}

			assertIndexDataEqual(t, baseline, got, gmp)
		})
	}
}

func itoa(n int) string {
	return fmt.Sprintf("%d", n)
}

func assertIndexDataEqual(t *testing.T, want, got indexData, gomaxprocs int) {
	t.Helper()

	if want.NumBooks != got.NumBooks {
		t.Errorf("GOMAXPROCS=%d: NumBooks: want %d, got %d", gomaxprocs, want.NumBooks, got.NumBooks)
	}
	if want.NumSegments != got.NumSegments {
		t.Errorf("GOMAXPROCS=%d: NumSegments: want %d, got %d", gomaxprocs, want.NumSegments, got.NumSegments)
	}
	if !bytes.Equal(want.Postings, got.Postings) {
		t.Errorf("GOMAXPROCS=%d: Postings differ (want %d bytes, got %d bytes)", gomaxprocs, len(want.Postings), len(got.Postings))
	}
	if !bytes.Equal(want.PostingsMeta, got.PostingsMeta) {
		t.Errorf("GOMAXPROCS=%d: PostingsMeta differ (want %d bytes, got %d bytes)", gomaxprocs, len(want.PostingsMeta), len(got.PostingsMeta))
	}
	if !bytes.Equal(want.DocLengths, got.DocLengths) {
		t.Errorf("GOMAXPROCS=%d: DocLengths differ (want %d bytes, got %d bytes)", gomaxprocs, len(want.DocLengths), len(got.DocLengths))
	}
	if !bytes.Equal(want.FSTBytes, got.FSTBytes) {
		t.Errorf("GOMAXPROCS=%d: FSTBytes differ (want %d bytes, got %d bytes)", gomaxprocs, len(want.FSTBytes), len(got.FSTBytes))
	}
	if !bytes.Equal(want.EntityFST, got.EntityFST) {
		t.Errorf("GOMAXPROCS=%d: EntityFST differ (want %d bytes, got %d bytes)", gomaxprocs, len(want.EntityFST), len(got.EntityFST))
	}
	if !bytes.Equal(want.Fingerprints, got.Fingerprints) {
		t.Errorf("GOMAXPROCS=%d: Fingerprints differ (want %d bytes, got %d bytes)", gomaxprocs, len(want.Fingerprints), len(got.Fingerprints))
	}
	// NumSegments (compared above) is the segment-count gate; the former
	// JsonlIndex offset array was dropped with ca-107.
}

// BenchmarkBuildIndex_Parallel measures BuildIndex wall-clock time at
// different GOMAXPROCS values. Compare sequential (GOMAXPROCS=1) vs
// parallel (GOMAXPROCS=NumCPU) on a corpus large enough to show speedup.
func BenchmarkBuildIndex_Parallel(b *testing.B) {

	// 500 books: 31 full + 1 partial segment. Large enough for measurable
	// tokenization work, small enough for benchmark iteration count.
	path := seedJSONLWithDescriptions(b, 500)

	for _, gmp := range []int{1, 2, 4, runtime.NumCPU()} {
		b.Run("gomaxprocs="+itoa(gmp), func(b *testing.B) {
			prev := runtime.GOMAXPROCS(gmp)
			defer runtime.GOMAXPROCS(prev)

			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				ms := &MotwSearch{JsonlPath: path, IndexDescription: true}
				if _, err := ms.BuildIndex(); err != nil {
					b.Fatal(err)
				}
			}
		})
	}
}
