package calibre

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"testing"

	"github.com/goccy/go-json"
)

// TestLookupByIDRoundTrip verifies that, when MotwSearch.IndexAggregateFields is
// enabled (as the aggregate-index builder uses), an opaque _id resolves via
// a direct postings lookup with one segment decompression; and that the
// default build (IndexAggregateFields=false, what per-library `calibre build
// --index` produces) has no _id postings so LookupByID returns nil.
func TestLookupByIDRoundTrip(t *testing.T) {
	dir := t.TempDir()
	jsonlPath := filepath.Join(dir, "books.jsonl")

	type seed struct {
		id, title string
	}
	seeds := []seed{
		{"00000000-0000-0000-0000-000000000001", "Alpha"},
		{"00000000-0000-0000-0000-000000000002", "Beta"},
		{"00000000-0000-0000-0000-000000000003", "Gamma"},
	}
	books := make([]Book, 0, 40)
	for _, s := range seeds {
		books = append(books, Book{
			Id:           s.id,
			Title:        s.title,
			Authors:      []string{"Test Author"},
			LastModified: "2024-01-01T00:00:00+00:00",
		})
	}
	// Pad past the 16-book segment boundary so the postings → segment lookup
	// actually narrows (matches must come from a specific segment, not "the
	// whole index").
	for i := len(seeds); i < 40; i++ {
		books = append(books, Book{
			Id:           fmt.Sprintf("00000000-0000-0000-0000-%012d", i+100),
			Title:        fmt.Sprintf("Filler %d", i),
			Authors:      []string{"Test Author"},
			LastModified: fmt.Sprintf("2024-02-%02dT00:00:00+00:00", (i%28)+1),
		})
	}

	f, err := os.Create(jsonlPath)
	if err != nil {
		t.Fatal(err)
	}
	for _, b := range books {
		data, err := json.Marshal(b)
		if err != nil {
			t.Fatal(err)
		}
		if _, err := f.Write(append(data, '\n')); err != nil {
			t.Fatal(err)
		}
	}
	f.Close()

	t.Run("with_id_postings", func(t *testing.T) {
		indexPath := filepath.Join(dir, "with-id-index")
		ms := &MotwSearch{
			JsonlPath:            jsonlPath,
			IndexPath:            indexPath,
			IndexAggregateFields: true,
		}
		idx, err := ms.BuildIndex()
		if err != nil {
			t.Fatalf("BuildIndex: %v", err)
		}
		if err := ms.CompressToFile(idx); err != nil {
			t.Fatalf("CompressToFile: %v", err)
		}

		searcher := &MotwSearch{IndexPath: indexPath}
		opened, err := searcher.Open()
		if err != nil {
			t.Fatalf("Open: %v", err)
		}
		defer opened.Close()

		// Hit: a known _id resolves to the right book.
		got, err := opened.LookupByID(context.Background(), "00000000-0000-0000-0000-000000000002")
		if err != nil {
			t.Fatalf("LookupByID hit: %v", err)
		}
		if got == nil {
			t.Fatal("LookupByID: nil, want book")
		}
		if got.Title != "Beta" {
			t.Fatalf("LookupByID: title=%q, want Beta", got.Title)
		}

		// Miss: unknown _id returns (nil, nil).
		miss, err := opened.LookupByID(context.Background(), "ffffffff-ffff-ffff-ffff-ffffffffffff")
		if err != nil {
			t.Fatalf("LookupByID miss: %v", err)
		}
		if miss != nil {
			t.Fatalf("LookupByID: got %+v, want nil for unknown id", miss)
		}

		// Empty id: returns nil without scanning.
		empty, err := opened.LookupByID(context.Background(), "")
		if err != nil {
			t.Fatalf("LookupByID empty: %v", err)
		}
		if empty != nil {
			t.Fatalf("LookupByID(\"\"): got %+v, want nil", empty)
		}
	})

	t.Run("without_id_postings_returns_nil", func(t *testing.T) {
		indexPath := filepath.Join(dir, "no-id-index")
		ms := &MotwSearch{
			JsonlPath: jsonlPath,
			IndexPath: indexPath,
			// IndexAggregateFields left false — the per-library `calibre build`
			// path. The book has the right _id, but no FieldID posting was
			// added, so LookupByID cannot resolve it.
		}
		idx, err := ms.BuildIndex()
		if err != nil {
			t.Fatalf("BuildIndex: %v", err)
		}
		if err := ms.CompressToFile(idx); err != nil {
			t.Fatalf("CompressToFile: %v", err)
		}

		searcher := &MotwSearch{IndexPath: indexPath}
		opened, err := searcher.Open()
		if err != nil {
			t.Fatalf("Open: %v", err)
		}
		defer opened.Close()

		got, err := opened.LookupByID(context.Background(), "00000000-0000-0000-0000-000000000002")
		if err != nil {
			t.Fatalf("LookupByID: %v", err)
		}
		if got != nil {
			t.Fatalf("LookupByID without IndexAggregateFields: got %+v, want nil", got)
		}
	})
}
