package calibre

import (
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func BenchmarkRealCorpusBuild(b *testing.B) {
	jp := os.Getenv("ACCORDER_BENCH_JSONL")
	if jp == "" {
		b.Skip("set ACCORDER_BENCH_JSONL")
	}
	dir := b.TempDir()
	b.ResetTimer()
	var buildNs, compressNs int64
	for i := 0; i < b.N; i++ {
		ms := &MotwSearch{JsonlPath: jp, IndexPath: filepath.Join(dir, fmt.Sprintf("idx%d", i))}
		t0 := time.Now()
		idx, err := ms.BuildIndex()
		if err != nil {
			b.Fatal(err)
		}
		buildNs += time.Since(t0).Nanoseconds()
		t1 := time.Now()
		if err := ms.CompressToFile(idx); err != nil {
			b.Fatal(err)
		}
		compressNs += time.Since(t1).Nanoseconds()
		if info, err := os.Stat(ms.IndexPath + ".zst"); err == nil {
			b.ReportMetric(float64(info.Size()), "zst-bytes")
		}
	}
	b.ReportMetric(float64(buildNs)/float64(b.N)/1e6, "BuildIndex-ms")
	b.ReportMetric(float64(compressNs)/float64(b.N)/1e6, "CompressToFile-ms")
}
