//go:build calibre_e2e

package calibre

import (
	"os"
	"os/exec"
	"path/filepath"
	"testing"
)

// ═══════════════════════════════════════════════════════════════════
// Zotero import round-trip against a REAL Calibre library.
//
//	go test -tags calibre_e2e ./pkg/calibre/
//
// The fake-CLI engine tests (zoteroSyncEngine_test.go) prove what accorder
// DECIDES. They cannot prove that calibredb accepts those decisions, nor that
// the zotero:/zotero_rev:/zotero_src: identifiers survive a set_metadata →
// list round-trip in the shape buildTrackedMap parses. Canned JSON encodes
// today's `--for-machine` output; a Calibre upgrade that changed it would
// leave every fake test green and production broken. This tier is the only
// thing that catches that drift — do not "simplify" it away.
//
// No browser is involved, so this deliberately lives here rather than in
// pkg/browselocal with the rod-driven calibre_e2e tests.
//
// Skips when calibredb is absent (via roundTripLibrary).
// ═══════════════════════════════════════════════════════════════════

// roundTripLibrary creates an empty Calibre library, skipping when calibredb
// is absent.
//
// This intentionally mirrors spikeLibrary in zotero_calibre_import_spike_test.go
// rather than calling it: that file is `package calibre_test` (external), while
// these tests need the unexported buildTrackedMap and so must be `package
// calibre`. Go's package boundary, not an oversight — see the [DRY] entry in
// the workflow proposal.
func roundTripLibrary(t *testing.T) string {
	t.Helper()
	if _, err := exec.LookPath("calibredb"); err != nil {
		t.Skip("calibredb not on PATH; the Zotero import round-trip requires Calibre")
	}
	libPath := filepath.Join(t.TempDir(), "roundtrip_lib")
	out, err := exec.Command("calibredb", "--library-path="+libPath, "add", "--empty", "--title=RoundTripInit").CombinedOutput()
	if err != nil {
		t.Fatalf("init round-trip library: %v\n%s", err, out)
	}
	return libPath
}

// roundTripEntry builds an ImportEntry over files in a caller-owned directory,
// so later generations can mutate the same paths.
func roundTripEntry(t *testing.T, dir, itemKey, title, effMtime string, files map[string]string) ImportEntry {
	t.Helper()
	entry := ImportEntry{
		ItemKey:    itemKey,
		EffMtime:   effMtime,
		Title:      title,
		Authors:    []string{"Round Trip"},
		AuthorSort: "Trip, Round",
		Tags:       []string{"e2e", "zotero"},
	}
	for name, content := range files {
		p := filepath.Join(dir, name)
		if err := os.WriteFile(p, []byte(content), 0o600); err != nil {
			t.Fatalf("write %s: %v", name, err)
		}
		entry.Files = append(entry.Files, ImportFile{AbsPath: p, Ext: filepath.Ext(name)})
	}
	return entry
}

func TestZoteroImport_RoundTripAgainstRealCalibre(t *testing.T) {
	lib := roundTripLibrary(t) // skips if calibredb is not on PATH
	exe := &CalibreExe{LibraryPath: lib}
	bundle := Bundle{Alias: "e2e-alias", ExportID: "EXP-E2E"}
	dir := t.TempDir()

	alpha := roundTripEntry(t, dir, "ZKALPHA", "Alpha Round Trip", "2026-01-01T00:00:00Z",
		map[string]string{"alpha.epub": "alpha original content, sufficiently unique"})
	beta := roundTripEntry(t, dir, "ZKBETA", "Beta Round Trip", "2026-01-01T00:00:00Z",
		map[string]string{"beta.epub": "beta original content, also quite unique"})

	// ── Generation 1: first import ───────────────────────────────────
	stats, err := SyncEntries(ctx(), exe, []ImportEntry{alpha, beta}, bundle, false, yesConfirm)
	if err != nil {
		t.Fatalf("gen1 SyncEntries: %v", err)
	}
	if stats.Added != 2 {
		t.Fatalf("gen1 stats = %+v, want 2 added", stats)
	}

	// The drift check: read the identifiers back through REAL calibredb output.
	tracked, err := buildTrackedMap(ctx(), exe)
	if err != nil {
		t.Fatalf("gen1 buildTrackedMap: %v", err)
	}
	if len(tracked) != 2 {
		t.Fatalf("gen1 tracked %d books, want 2 — identifiers did not survive the set_metadata → list round-trip: %+v", len(tracked), tracked)
	}
	ta := tracked["ZKALPHA"]
	if ta.rev != alpha.Rev() {
		t.Errorf("gen1 zotero_rev = %q, want %q", ta.rev, alpha.Rev())
	}
	if ta.src != bundle.Alias {
		t.Errorf("gen1 zotero_src = %q, want %q", ta.src, bundle.Alias)
	}
	if ta.export != bundle.ExportID {
		t.Errorf("gen1 zotero_export = %q, want %q", ta.export, bundle.ExportID)
	}
	// extractExts must agree with what the export carries, or every later run
	// would see a phantom format change (study F3).
	if got, want := ta.formats, alpha.Exts(); len(got) != len(want) || got[0] != want[0] {
		t.Errorf("gen1 formats = %v, want %v", got, want)
	}

	// ── Generation 2: nothing changed ────────────────────────────────
	stats, err = SyncEntries(ctx(), exe, []ImportEntry{alpha, beta}, bundle, false, yesConfirm)
	if err != nil {
		t.Fatalf("gen2 SyncEntries: %v", err)
	}
	if stats.Unchanged != 2 || stats.Added != 0 || stats.Updated != 0 {
		t.Errorf("gen2 stats = %+v, want 2 unchanged — the cheap gate did not recognise a real round-tripped rev", stats)
	}

	// ── Generation 3: alpha's bytes and mtime move ───────────────────
	alphaV2 := roundTripEntry(t, dir, "ZKALPHA", "Alpha Round Trip", "2026-06-06T00:00:00Z",
		map[string]string{"alpha.epub": "alpha REVISED content, materially different from before"})

	stats, err = SyncEntries(ctx(), exe, []ImportEntry{alphaV2, beta}, bundle, false, yesConfirm)
	if err != nil {
		t.Fatalf("gen3 SyncEntries: %v", err)
	}
	if stats.Updated != 1 || stats.Unchanged != 1 {
		t.Errorf("gen3 stats = %+v, want 1 updated / 1 unchanged", stats)
	}

	tracked, err = buildTrackedMap(ctx(), exe)
	if err != nil {
		t.Fatalf("gen3 buildTrackedMap: %v", err)
	}
	if got := tracked["ZKALPHA"].rev; got != alphaV2.Rev() {
		t.Errorf("gen3 zotero_rev = %q, want %q — the new revision did not persist", got, alphaV2.Rev())
	}
	if tracked["ZKALPHA"].bookID != ta.bookID {
		t.Errorf("gen3 book id moved %d → %d; an update must not re-add", ta.bookID, tracked["ZKALPHA"].bookID)
	}

	// ── Generation 4: beta drops out of the export, with --prune ─────
	stats, err = SyncEntries(ctx(), exe, []ImportEntry{alphaV2}, bundle, true, yesConfirm)
	if err != nil {
		t.Fatalf("gen4 SyncEntries: %v", err)
	}
	if stats.Removed != 1 {
		t.Errorf("gen4 stats = %+v, want 1 removed", stats)
	}

	tracked, err = buildTrackedMap(ctx(), exe)
	if err != nil {
		t.Fatalf("gen4 buildTrackedMap: %v", err)
	}
	if _, still := tracked["ZKBETA"]; still {
		t.Error("gen4: pruned book is still tracked in the library")
	}
	if len(tracked) != 1 {
		t.Errorf("gen4 tracked %d books, want 1", len(tracked))
	}
}

// TestZoteroImport_PruneIsScopedToBundle proves against a real library that
// --prune never touches books imported under a different alias — the guarantee
// pruneCandidates makes at zoteroSync.go:264.
func TestZoteroImport_PruneIsScopedToBundle(t *testing.T) {
	lib := roundTripLibrary(t)
	exe := &CalibreExe{LibraryPath: lib}
	dir := t.TempDir()

	mine := roundTripEntry(t, dir, "ZKMINE", "Mine", "2026-01-01T00:00:00Z",
		map[string]string{"mine.epub": "content belonging to my alias"})
	theirs := roundTripEntry(t, dir, "ZKTHEIRS", "Theirs", "2026-01-01T00:00:00Z",
		map[string]string{"theirs.epub": "content belonging to a different alias"})

	if _, err := SyncEntries(ctx(), exe, []ImportEntry{mine}, Bundle{Alias: "alias-a"}, false, yesConfirm); err != nil {
		t.Fatalf("import under alias-a: %v", err)
	}
	if _, err := SyncEntries(ctx(), exe, []ImportEntry{theirs}, Bundle{Alias: "alias-b"}, false, yesConfirm); err != nil {
		t.Fatalf("import under alias-b: %v", err)
	}

	// alias-a re-imports with an empty export and --prune: only its own book goes.
	stats, err := SyncEntries(ctx(), exe, nil, Bundle{Alias: "alias-a"}, true, yesConfirm)
	if err != nil {
		t.Fatalf("prune under alias-a: %v", err)
	}
	if stats.Removed != 1 {
		t.Errorf("stats = %+v, want exactly 1 removed", stats)
	}

	tracked, err := buildTrackedMap(ctx(), exe)
	if err != nil {
		t.Fatalf("buildTrackedMap: %v", err)
	}
	if _, gone := tracked["ZKTHEIRS"]; !gone {
		t.Error("alias-b's book was pruned by alias-a — prune scoping is broken")
	}
	if _, still := tracked["ZKMINE"]; still {
		t.Error("alias-a's own orphan survived its own prune")
	}
}
