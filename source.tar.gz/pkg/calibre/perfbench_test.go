package calibre

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"
)

// TestPerfBench_CompileAndAllSearch times the two parked perf concerns on a large
// synthetic corpus so their relative cost picks the work order:
//   - build-with-descriptions  (== `lib index recompile --descriptions` cost) → parallel-index-compile draft
//   - `all` vs single-field search                                            → all-mode-single-pass-scorer draft
//
// Gated behind ACCORDER_BENCH=1 (slow, single-threaded by design). Run:
//
//	ACCORDER_BENCH=1 go test ./pkg/calibre/ -run TestPerfBench_CompileAndAllSearch -count=1 -v -timeout 20m
func TestPerfBench_CompileAndAllSearch(t *testing.T) {
	if os.Getenv("ACCORDER_BENCH") == "" {
		t.Skip("set ACCORDER_BENCH=1 to run the perf benchmark")
	}
	const n = 50000

	topics := []string{
		"power", "discipline", "freedom", "method", "society", "language", "memory",
		"capital", "labour", "reason", "spirit", "science", "history", "nature",
		"justice", "knowledge", "desire", "machine", "network", "archive",
		"colonial", "ecology", "ethics", "media", "theatre", "ritual", "myth",
		"border", "commons", "translation",
	}
	authors := []string{"Foucault", "Freire", "Fanon", "Kittler", "Hawking", "Piketty", "Kant", "Sartre", "Kuhn", "Hegel"}
	tags := []string{"philosophy", "physics", "politics", "media-theory", "economics", "history", "ecology", "ethics"}

	dir := t.TempDir()
	jsonlPath := filepath.Join(dir, "bench.jsonl")
	f, err := os.Create(jsonlPath)
	if err != nil {
		t.Fatal(err)
	}
	w := bufio.NewWriter(f)
	for i := 0; i < n; i++ {
		ta, tb, tc := topics[i%len(topics)], topics[(i*7)%len(topics)], topics[(i*13)%len(topics)]
		b := Book{
			Title:        fmt.Sprintf("Treatise %d on %s and %s", i, ta, tb),
			Authors:      []string{authors[i%len(authors)]},
			Tags:         []string{tags[i%len(tags)], tags[(i*3)%len(tags)]},
			Abstract:     fmt.Sprintf("<p>This volume examines <b>%s</b> through the lens of %s, with attention to %s and to broader questions of research &amp; method. Entry %d.</p>", ta, tb, tc, i),
			LastModified: fmt.Sprintf("2024-01-%02dT00:00:00+00:00", (i%28)+1),
			LibraryUUID:  "bench",
			UUID:         fmt.Sprintf("uuid-%d", i),
			Id:           fmt.Sprintf("%d", i),
		}
		line, _ := json.Marshal(b)
		w.Write(line)
		w.WriteByte('\n')
	}
	w.Flush()
	f.Close()
	t.Logf("corpus: %d books, JSONL %s", n, sizeOf(t, jsonlPath))

	build := func(label, indexPath string, withDesc bool) {
		ms := &MotwSearch{JsonlPath: jsonlPath, IndexPath: indexPath, IndexDescription: withDesc}
		t0 := time.Now()
		idx, err := ms.BuildIndex()
		if err != nil {
			t.Fatalf("%s BuildIndex: %v", label, err)
		}
		tBuild := time.Since(t0)
		t1 := time.Now()
		if err := ms.CompressToFile(idx); err != nil {
			t.Fatalf("%s CompressToFile: %v", label, err)
		}
		tCompress := time.Since(t1)
		t.Logf("%-22s BuildIndex=%-8s CompressToFile=%-8s total=%-8s out=%s",
			label, tBuild.Round(time.Millisecond), tCompress.Round(time.Millisecond),
			(tBuild + tCompress).Round(time.Millisecond), sizeOf(t, indexPath+".zst"))
	}

	plainIdx := filepath.Join(dir, "plain")
	descIdx := filepath.Join(dir, "desc")
	build("build (no descriptions)", plainIdx, false)
	build("build (descriptions)   ", descIdx, true) // == recompile --descriptions cost

	searcher := &MotwSearch{IndexPath: descIdx}
	timeSearch := func(label string, q SearchQuery, limit int) {
		// warm + measure best of 3
		var best time.Duration = time.Hour
		var nres int
		for i := 0; i < 3; i++ {
			t0 := time.Now()
			books, _, err := searcher.Search(context.Background(), q, SearchOptions{Limit: limit, SortMode: SortRelevance})
			d := time.Since(t0)
			if err != nil {
				t.Fatalf("%s search: %v", label, err)
			}
			if d < best {
				best = d
			}
			nres = len(books)
		}
		t.Logf("%-34s best=%-9s (limit=%d, returned=%d)", label, best.Round(time.Microsecond), limit, nres)
	}

	// "method" is in every abstract (broad); a numbered title term is selective.
	timeSearch("title:method (single field, broad)", SearchQuery{Field: FieldTitle, Text: "method"}, 48)
	timeSearch("all:method   (all fields, broad)  ", SearchQuery{Field: FieldAll, Text: "method"}, 48)
	timeSearch("title:power  (single field)       ", SearchQuery{Field: FieldTitle, Text: "power"}, 48)
	timeSearch("all:power    (all fields)         ", SearchQuery{Field: FieldAll, Text: "power"}, 48)
	timeSearch("description:research (abstract)   ", SearchQuery{Field: FieldAbstract, Text: "research"}, 48)
	timeSearch("all:research (all fields, in every abstract)", SearchQuery{Field: FieldAll, Text: "research"}, 48)
}

func sizeOf(t *testing.T, path string) string {
	t.Helper()
	fi, err := os.Stat(path)
	if err != nil {
		return "?"
	}
	return fmt.Sprintf("%.1f MiB", float64(fi.Size())/(1<<20))
}
