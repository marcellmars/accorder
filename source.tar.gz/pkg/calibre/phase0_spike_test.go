package calibre

// Phase 0 discovery spike for typeahead-decoupling workflow.
// These are throwaway probes — NOT permanent regression tests.
// Purpose: validate three integration-boundary assumptions before the propose phase.

import (
	"bytes"
	"os"
	"path/filepath"
	"testing"

	"github.com/cespare/xxhash/v2"
)

// TestSpikeA1_TypeaheadFSTHashStability validates that building an entity FST
// from identical entity input produces byte-identical output (and therefore a
// stable xxhash). If the FST builder is non-deterministic (e.g. map iteration
// order leaks into the output), the reuse decision must hash the sorted token
// set instead of the FST bytes.
func TestSpikeA1_TypeaheadFSTHashStability(t *testing.T) {

	// Build the same entity collector twice with identical data.
	mkCollector := func() entityCollector {
		c := make(entityCollector)
		c.add(FieldTitle, "The Art of Programming")
		c.add(FieldTitle, "Discourse Networks, 1800/1900")
		c.add(FieldTitle, "A Brief History of Time")
		c.add(FieldAuthor, "Donald Knuth")
		c.add(FieldAuthor, "Friedrich Kittler")
		c.add(FieldAuthor, "Stephen Hawking")
		c.add(FieldTag, "computer science")
		c.add(FieldTag, "algorithms")
		c.add(FieldTag, "media theory")
		c.add(FieldTag, "physics")
		c.add(FieldTag, "cosmology")
		return c
	}

	fst1, err := buildEntityFST(mkCollector())
	if err != nil {
		t.Fatalf("buildEntityFST run 1: %v", err)
	}
	fst2, err := buildEntityFST(mkCollector())
	if err != nil {
		t.Fatalf("buildEntityFST run 2: %v", err)
	}

	if !bytes.Equal(fst1, fst2) {
		t.Fatalf("REFUTED: FST bytes differ across identical entity sets (%d vs %d bytes)", len(fst1), len(fst2))
	}

	h1 := xxhash.Sum64(fst1)
	h2 := xxhash.Sum64(fst2)
	if h1 != h2 {
		t.Fatalf("REFUTED: xxhash differs: %x vs %x", h1, h2)
	}
	t.Logf("VALIDATED: FST bytes are identical (%d bytes, xxhash=%x)", len(fst1), h1)
}

// TestSpikeA2_DecodeManifestTrailingBytes validates that decodeManifest
// tolerates extra trailing bytes appended after the Tombstones section.
// If it errors, a manifestFormatTag bump is required for additive fields.
func TestSpikeA2_DecodeManifestTrailingBytes(t *testing.T) {
	orig := Manifest{
		FormatTag:      manifestFormatTag,
		ChunkSize:      256 << 10,
		NumSegments:    42,
		NumBooks:       100,
		BaseGeneration: [16]byte{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16},
		Generation:     7,
		TypeaheadOff:   12345,
		TypeaheadLen:   6789,
		Regions: []ManifestRegion{
			{SearchIndexOff: 0, SearchIndexLen: 100, DisplayIndexOff: 100, DisplayIndexLen: 50, DictID: 2},
		},
		Tombstones: [][16]byte{{0xAA, 0xBB}},
	}

	encoded, err := encodeManifest(orig)
	if err != nil {
		t.Fatalf("encodeManifest: %v", err)
	}

	// Append 64 bytes of trailing junk (simulating future additive fields).
	trailing := make([]byte, 64)
	for i := range trailing {
		trailing[i] = byte(i + 0xC0)
	}
	withTrailing := append(encoded, trailing...)

	decoded, err := decodeManifest(withTrailing)
	if err != nil {
		t.Fatalf("REFUTED: decodeManifest errors on trailing bytes: %v", err)
	}

	// Verify round-trip of known fields.
	if decoded.FormatTag != orig.FormatTag {
		t.Fatalf("FormatTag mismatch: got %d, want %d", decoded.FormatTag, orig.FormatTag)
	}
	if decoded.NumBooks != orig.NumBooks {
		t.Fatalf("NumBooks mismatch: got %d, want %d", decoded.NumBooks, orig.NumBooks)
	}
	if decoded.Generation != orig.Generation {
		t.Fatalf("Generation mismatch: got %d, want %d", decoded.Generation, orig.Generation)
	}
	if decoded.TypeaheadOff != orig.TypeaheadOff || decoded.TypeaheadLen != orig.TypeaheadLen {
		t.Fatalf("Typeahead mismatch: off=%d/%d len=%d/%d", decoded.TypeaheadOff, orig.TypeaheadOff, decoded.TypeaheadLen, orig.TypeaheadLen)
	}
	if len(decoded.Regions) != len(orig.Regions) {
		t.Fatalf("Region count mismatch: got %d, want %d", len(decoded.Regions), len(orig.Regions))
	}
	if len(decoded.Tombstones) != len(orig.Tombstones) {
		t.Fatalf("Tombstone count mismatch: got %d, want %d", len(decoded.Tombstones), len(orig.Tombstones))
	}
	if decoded.Tombstones[0] != orig.Tombstones[0] {
		t.Fatalf("Tombstone[0] mismatch")
	}
	t.Logf("VALIDATED: decodeManifest ignores %d trailing bytes; all fields round-trip correctly", len(trailing))
}

// TestSpikeA3_TypeaheadRegionCopyFidelity validates that a prior aggregate's
// typeahead region can be read and spliced verbatim into a new container via
// the ComposeAggregate machinery, and Suggest() on the result matches the
// original. This is the (A) reuse path's core assumption.
func TestSpikeA3_TypeaheadRegionCopyFidelity(t *testing.T) {
	dir := t.TempDir()

	// Build two small member indexes with distinct DictIDs.
	mkMember := func(name, uuid, librarian string, n int, dictID uint32) string {
		mdir := filepath.Join(dir, name)
		if err := os.MkdirAll(mdir, 0o755); err != nil {
			t.Fatal(err)
		}
		jsonl := seedMemberJSONL(t, mdir, n, uuid, librarian, "/files/"+name)
		idx := filepath.Join(mdir, "library_index")
		buildMemberIndex(t, jsonl, idx, dictID)
		return idx
	}
	idxA := mkMember("spike_memberA", "lib-spike-a", "alice", 5, 2)
	idxB := mkMember("spike_memberB", "lib-spike-b", "bob", 5, 3)

	// --- Build the first aggregate (the "prior") ---
	mcdA, err := ExtractMemberContainer(idxA)
	if err != nil {
		t.Fatalf("extract A: %v", err)
	}
	mcdB, err := ExtractMemberContainer(idxB)
	if err != nil {
		t.Fatalf("extract B: %v", err)
	}
	priorAgg := filepath.Join(dir, "agg1", "library_index")
	if err := os.MkdirAll(filepath.Dir(priorAgg), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := ComposeAggregate(priorAgg, []*MemberContainerData{mcdA, mcdB}, [16]byte{}, 1, ComposeOpts{}); err != nil {
		t.Fatalf("ComposeAggregate (prior): %v", err)
	}

	// Collect Suggest results from the prior aggregate.
	priorSuggestions := collectSuggestions(t, priorAgg)
	if len(priorSuggestions) == 0 {
		t.Fatal("prior aggregate has no suggestions — test is vacuous")
	}

	// --- Read the prior aggregate's typeahead bytes (the "reuse" path) ---
	priorMCD, err := ExtractMemberContainer(priorAgg)
	if err != nil {
		t.Fatalf("extract prior agg: %v", err)
	}
	if len(priorMCD.Typeahead) == 0 {
		t.Fatal("prior aggregate has no typeahead bytes")
	}
	priorTABytes := priorMCD.Typeahead

	// --- Build a second aggregate with the SAME members, but simulate the
	// reuse path: instead of re-merging typeaheads, inject the prior's
	// typeahead bytes as the sole typeahead input. ---
	mcdA2, err := ExtractMemberContainer(idxA)
	if err != nil {
		t.Fatalf("extract A (2nd): %v", err)
	}
	mcdB2, err := ExtractMemberContainer(idxB)
	if err != nil {
		t.Fatalf("extract B (2nd): %v", err)
	}

	// Replace per-member typeaheads: zero them out, set one member to carry
	// the prior aggregate's merged typeahead bytes. ComposeAggregate will
	// "merge" just that one input (effectively a copy).
	mcdA2.Typeahead = priorTABytes
	mcdB2.Typeahead = nil

	reusedAgg := filepath.Join(dir, "agg2", "library_index")
	if err := os.MkdirAll(filepath.Dir(reusedAgg), 0o755); err != nil {
		t.Fatal(err)
	}
	if err := ComposeAggregate(reusedAgg, []*MemberContainerData{mcdA2, mcdB2}, [16]byte{}, 2, ComposeOpts{}); err != nil {
		t.Fatalf("ComposeAggregate (reused): %v", err)
	}

	// Collect Suggest results from the reused aggregate and compare.
	reusedSuggestions := collectSuggestions(t, reusedAgg)

	if len(priorSuggestions) != len(reusedSuggestions) {
		t.Fatalf("REFUTED: suggestion count differs: prior=%d reused=%d", len(priorSuggestions), len(reusedSuggestions))
	}
	for i, ps := range priorSuggestions {
		rs := reusedSuggestions[i]
		if ps.Term != rs.Term || ps.Field != rs.Field || ps.Entity != rs.Entity || ps.Weight != rs.Weight {
			t.Fatalf("REFUTED: suggestion[%d] differs:\n  prior:  %+v\n  reused: %+v", i, ps, rs)
		}
	}
	t.Logf("VALIDATED: reused typeahead produces %d identical suggestions", len(priorSuggestions))
}

// collectSuggestions opens an index and runs SuggestAny to collect all typeahead
// suggestions for a broad prefix.
func collectSuggestions(t *testing.T, idxPath string) []Suggestion {
	t.Helper()
	ms := &MotwSearch{IndexPath: idxPath}
	opened, err := ms.Open()
	if err != nil {
		t.Fatalf("open %s: %v", idxPath, err)
	}
	defer opened.Close()
	ta, err := opened.Typeahead(t.TempDir())
	if err != nil {
		t.Fatalf("typeahead %s: %v", idxPath, err)
	}
	defer ta.Close()

	// Query a broad set of prefixes to exercise coverage.
	var all []Suggestion
	for _, prefix := range []string{"a", "b", "c", "d", "e", "f", "h", "k", "m", "n", "p", "s", "t"} {
		res, err := ta.SuggestAny(prefix, 100)
		if err != nil {
			t.Fatalf("SuggestAny(%q): %v", prefix, err)
		}
		all = append(all, res...)
	}
	return all
}
