package calibre

// Spike tests for self-contained-aggregate-rebuild workflow.
//

// Hypotheses tested:
//   1. Splice peak RSS fits njalla budget (~448 MB child + ~500 MB daemon < 2.9 GB)
//   2. DictID assignment from federation state produces unique, valid containers
//   3. shouldAutoCompact threshold can be isolated to aggregate-only context
//   4. Self-healing splice with reassigned DictIDs produces valid containers

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"testing"
)

// ---------------------------------------------------------------------------
// Hypothesis 1: Splice peak RSS measurement
//

// Measures the heap footprint of ComposeAggregate with varying member counts
// and book counts. The critical question: does splice stay under ~500 MB for
// a realistic federation (27 members, ~6K books each, ~159K total)?
//

// This is a local measurement — not on njalla — but establishes the shape of
// the curve and whether the ~448 MB estimate from study notes is credible.
// ---------------------------------------------------------------------------

func TestSpike_SplicePeakRSS(t *testing.T) {

	// Scaling parameters: we test multiple configurations to establish
	// the RSS growth curve. The real federation has ~27 members × ~6K books.
	// We test at 1/10 scale (manageable in CI) and extrapolate.
	configs := []struct {
		name      string
		members   int
		booksEach int
	}{
		{"tiny-3x50", 3, 50},
		{"small-5x200", 5, 200},
		{"medium-10x500", 10, 500},
		{"scaled-27x200", 27, 200}, // member count matches prod, fewer books
	}

	for _, cfg := range configs {
		t.Run(cfg.name, func(t *testing.T) {
			dir := t.TempDir()

			// Build member indexes with unique DictIDs
			type memberInfo struct {
				indexPath string
				dictID    uint32
			}
			var members []memberInfo
			for i := 0; i < cfg.members; i++ {
				mDir := filepath.Join(dir, fmt.Sprintf("member-%d", i))
				if err := os.MkdirAll(mDir, 0o755); err != nil {
					t.Fatal(err)
				}
				uuid := fmt.Sprintf("spike-rss-%d", i)
				librarian := fmt.Sprintf("librarian-%d", i)
				dictID := uint32(i + 2) // DictIDs start at 2

				jsonlPath := seedMemberJSONL(t, mDir, cfg.booksEach, uuid, librarian)
				indexPath := filepath.Join(mDir, "library_index")
				buildMemberIndex(t, jsonlPath, indexPath, dictID)

				members = append(members, memberInfo{indexPath: indexPath, dictID: dictID})
			}

			// Extract member containers
			var extracted []*MemberContainerData
			for _, m := range members {
				mcd, err := ExtractMemberContainer(m.indexPath)
				if err != nil {
					t.Fatalf("ExtractMemberContainer(%s): %v", m.indexPath, err)
				}
				extracted = append(extracted, mcd)
			}

			// Force GC before measurement
			runtime.GC()
			var mBefore runtime.MemStats
			runtime.ReadMemStats(&mBefore)

			// Run ComposeAggregate
			aggPath := filepath.Join(dir, "aggregate_index")
			err := ComposeAggregate(aggPath, extracted, [16]byte{}, 1, ComposeOpts{})
			if err != nil {
				t.Fatalf("ComposeAggregate: %v", err)
			}

			// Measure after
			var mAfter runtime.MemStats
			runtime.ReadMemStats(&mAfter)

			heapDelta := int64(mAfter.TotalAlloc) - int64(mBefore.TotalAlloc)
			peakHeap := mAfter.HeapInuse

			totalBooks := cfg.members * cfg.booksEach

			t.Logf("CONFIG: %d members × %d books = %d total", cfg.members, cfg.booksEach, totalBooks)
			t.Logf("HEAP: delta=%d MB, peak-in-use=%d MB, sys=%d MB",
				heapDelta/(1<<20), peakHeap/(1<<20), mAfter.Sys/(1<<20))
			t.Logf("PER-BOOK: ~%d bytes/book heap delta", heapDelta/int64(totalBooks))

			// Verify the aggregate is valid and searchable
			mf, err := ReadExistingManifest(aggPath)
			if err != nil {
				t.Fatalf("ReadExistingManifest: %v", err)
			}
			if mf.NumBooks != uint32(totalBooks) {
				t.Errorf("expected %d books, got %d", totalBooks, mf.NumBooks)
			}
			t.Logf("AGGREGATE: %d books, %d regions, %d dicts in catalog",
				mf.NumBooks, len(mf.Regions), cfg.members)

			// Searchability check
			ms := &MotwSearch{IndexPath: aggPath}
			opened, err := ms.Open()
			if err != nil {
				t.Fatalf("Open: %v", err)
			}
			defer opened.Close()

			results, _, err := opened.Search(context.Background(),
				SearchQuery{Field: FieldTitle, Text: "Art"},
				SearchOptions{Limit: 10, SortMode: SortRelevance})
			if err != nil {
				t.Fatalf("Search: %v", err)
			}
			t.Logf("SEARCH 'Art': %d results", len(results))

			// The key assertion: for 27×200=5400 books (1/30 of prod),
			// heap should be well under 50 MB. If it's proportional,
			// 27×6000=162K books would be ~30× more ≈ 1.5 GB — too much.
			// But splice is streaming (frame-copy), so it should NOT scale
			// with book count. The dominant cost is typeahead merge.
			if cfg.members == 27 {

				// At 27 members, splice heap should be modest.
				// Flag if > 200 MB — that would mean 27×6K books
				// could approach the 448 MB estimate.
				if heapDelta > 200*(1<<20) {
					t.Logf("WARNING: splice heap %d MB at 27×%d books — may exceed budget at prod scale",
						heapDelta/(1<<20), cfg.booksEach)
				}
			}
		})
	}
}

// ---------------------------------------------------------------------------
// Hypothesis 2: Native reindex — DictID assignment from federation state
//

// Tests that DictIDs can be assigned to members from a monotonic counter
// (simulating what `fedlib members reindex` would do), and that the resulting
// containers splice correctly. This validates the "assign DictIDs from
// federation state" part of the reindex design.
// ---------------------------------------------------------------------------

func TestSpike_ReindexDictIDAssignment(t *testing.T) {
	dir := t.TempDir()

	// Simulate a federation with 5 members, all currently having DictID=1
	// (the legacy default). We want to verify:
	// 1. Allocating unique DictIDs (2, 3, 4, 5, 6) works
	// 2. Rebuilding each member's index with the new DictID works
	// 3. The resulting indexes splice into a valid aggregate

	type member struct {
		uuid      string
		librarian string
		oldDictID uint32
		newDictID uint32
		jsonlPath string
		indexPath string
	}

	members := make([]member, 5)
	for i := range members {
		mDir := filepath.Join(dir, fmt.Sprintf("member-%d", i))
		if err := os.MkdirAll(mDir, 0o755); err != nil {
			t.Fatal(err)
		}
		members[i] = member{
			uuid:      fmt.Sprintf("reindex-uuid-%d", i),
			librarian: fmt.Sprintf("librarian-%d", i),
			oldDictID: 1, // all legacy
			newDictID: uint32(i + 2),
		}
		members[i].jsonlPath = seedMemberJSONL(t, mDir, 100, members[i].uuid, members[i].librarian)
		members[i].indexPath = filepath.Join(mDir, "library_index")
	}

	// Step 1: Build all members with old DictID=1, verify splice fails
	t.Run("legacy-dictid-collision", func(t *testing.T) {
		for i := range members {
			buildMemberIndex(t, members[i].jsonlPath, members[i].indexPath, members[i].oldDictID)
		}

		var extracted []*MemberContainerData
		for _, m := range members {
			mcd, err := ExtractMemberContainer(m.indexPath)
			if err != nil {
				t.Fatalf("ExtractMemberContainer: %v", err)
			}
			extracted = append(extracted, mcd)
		}

		aggPath := filepath.Join(dir, "agg_legacy")
		err := ComposeAggregate(aggPath, extracted, [16]byte{}, 1, ComposeOpts{})
		if err == nil {
			t.Fatal("expected DictID collision error, got nil")
		}
		if !strings.Contains(err.Error(), "collision") {
			t.Fatalf("expected collision error, got: %v", err)
		}
		t.Logf("CONFIRMED: legacy DictID=1 causes collision: %v", err)
	})

	// Step 2: Simulate reindex — rebuild each member with unique DictID
	t.Run("reindexed-unique-dictids", func(t *testing.T) {

		// Simulate the DictID allocation counter
		nextDictID := uint32(2) // starts at 2, matching allocateMemberDictID

		for i := range members {
			members[i].newDictID = nextDictID
			nextDictID++

			// Rebuild with new DictID
			buildMemberIndex(t, members[i].jsonlPath, members[i].indexPath, members[i].newDictID)
		}

		// Verify each container has the correct DictID
		var extracted []*MemberContainerData
		for _, m := range members {
			mcd, err := ExtractMemberContainer(m.indexPath)
			if err != nil {
				t.Fatalf("ExtractMemberContainer: %v", err)
			}
			if mcd.DictEntry.DictID != m.newDictID {
				t.Errorf("member %s: expected DictID %d, got %d", m.uuid, m.newDictID, mcd.DictEntry.DictID)
			}

			// Verify region DictIDs match
			for ri, r := range mcd.Regions {
				if r.DictID != m.newDictID {
					t.Errorf("member %s region[%d]: expected DictID %d, got %d", m.uuid, ri, m.newDictID, r.DictID)
				}
			}
			extracted = append(extracted, mcd)
		}

		// Splice should succeed
		aggPath := filepath.Join(dir, "agg_reindexed")
		err := ComposeAggregate(aggPath, extracted, [16]byte{}, 1, ComposeOpts{})
		if err != nil {
			t.Fatalf("ComposeAggregate after reindex: %v", err)
		}

		// Verify aggregate
		mf, err := ReadExistingManifest(aggPath)
		if err != nil {
			t.Fatalf("ReadExistingManifest: %v", err)
		}
		expectedBooks := uint32(len(members) * 100)
		if mf.NumBooks != expectedBooks {
			t.Errorf("expected %d books, got %d", expectedBooks, mf.NumBooks)
		}
		t.Logf("REINDEX: %d members, %d books, %d regions — splice succeeded",
			len(members), mf.NumBooks, len(mf.Regions))

		// Verify each region has the correct DictID
		dictIDs := make(map[uint32]int)
		for _, r := range mf.Regions {
			dictIDs[r.DictID]++
		}
		t.Logf("DICTID distribution: %v", dictIDs)
		if len(dictIDs) != len(members) {
			t.Errorf("expected %d distinct DictIDs, got %d", len(members), len(dictIDs))
		}

		// Verify searchability
		ms := &MotwSearch{IndexPath: aggPath}
		opened, err := ms.Open()
		if err != nil {
			t.Fatalf("Open: %v", err)
		}
		defer opened.Close()

		results, _, err := opened.Search(context.Background(),
			SearchQuery{Field: FieldTitle, Text: "Art"},
			SearchOptions{Limit: 10, SortMode: SortRelevance})
		if err != nil {
			t.Fatalf("Search: %v", err)
		}
		if len(results) == 0 {
			t.Error("expected search results for 'Art', got none")
		}
		t.Logf("SEARCH 'Art': %d results across %d members", len(results), len(members))
	})

	// Step 3: Verify DictID uniqueness invariant — no two members share an ID
	t.Run("uniqueness-invariant", func(t *testing.T) {
		seen := make(map[uint32]string) // DictID -> first member UUID
		for _, m := range members {
			if prev, ok := seen[m.newDictID]; ok {
				t.Errorf("DictID %d collision: %s and %s", m.newDictID, prev, m.uuid)
			}
			seen[m.newDictID] = m.uuid
		}
		t.Logf("UNIQUENESS: %d DictIDs, all unique", len(seen))
	})
}

// ---------------------------------------------------------------------------
// Hypothesis 3: shouldAutoCompact threshold isolation
//

// Tests that shouldAutoCompact's behavior can be distinguished between
// single-library and aggregate contexts. Currently it's called from both
// cmd/libBuild.go and cmd/fedlibBuild.go with the same threshold. The spike
// validates that the threshold is purely a function of Manifest fields, so an
// aggregate-specific guard can be added without breaking single-library.
// ---------------------------------------------------------------------------

func TestSpike_ShouldAutoCompactIsolation(t *testing.T) {

	// shouldAutoCompact is in cmd/ package — we can't call it directly from
	// pkg/calibre. Instead, we test the _conditions_ it checks against
	// Manifest fields to verify isolation is feasible.

	// The current thresholds (from cmd/libBuild.go:464-472):
	//   Regions > 5  → true
	//   NumBooks > 0 && Tombstones*3 > NumBooks → true

	type testCase struct {
		name          string
		regions       int
		numBooks      uint32
		tombstones    int
		wantTriggered bool
		context       string // "lib" or "aggregate"
	}

	cases := []testCase{

		// Single-library cases: these should trigger compaction
		{"lib-6-regions", 6, 100, 0, true, "lib"},
		{"lib-high-tombstones", 2, 100, 35, true, "lib"},

		// Single-library cases: these should NOT trigger
		{"lib-5-regions", 5, 100, 0, false, "lib"},
		{"lib-low-tombstones", 2, 100, 10, false, "lib"},

		// Aggregate cases: in an aggregate, regions = number_of_members
		// (each member contributes 1 region). So 27 members → 27 regions
		// → ALWAYS triggers compaction, which forces the monolithic path.
		// This is the bug: the threshold doesn't distinguish aggregate from lib.
		{"agg-27-members", 27, 159000, 0, true, "aggregate"},
		{"agg-10-members", 10, 50000, 0, true, "aggregate"},
		{"agg-6-members", 6, 30000, 0, true, "aggregate"},

		// Even 3 members + some tombstones could trigger
		{"agg-3-members-tombstones", 3, 15000, 5001, true, "aggregate"},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			mf := Manifest{
				NumBooks:   tc.numBooks,
				Tombstones: make([][16]byte, tc.tombstones),
				Regions:    make([]ManifestRegion, tc.regions),
			}

			// Replicate shouldAutoCompact logic
			triggered := false
			if len(mf.Regions) > 5 {
				triggered = true
			}
			if mf.NumBooks > 0 && uint32(len(mf.Tombstones))*3 > mf.NumBooks {
				triggered = true
			}

			if triggered != tc.wantTriggered {
				t.Errorf("%s: expected triggered=%v, got %v (regions=%d, books=%d, tombstones=%d)",
					tc.context, tc.wantTriggered, triggered, tc.regions, tc.numBooks, tc.tombstones)
			}

			// The key insight: for aggregates, the "Regions > 5" threshold
			// is too low. An aggregate with N members has at least N regions.
			// Any federation with >5 members will always trigger compaction,
			// forcing the OOM monolithic path.
			if tc.context == "aggregate" && triggered && len(mf.Regions) > 5 {
				t.Logf("CONFIRMED: aggregate with %d regions triggers compaction — "+
					"this forces monolithic fallback which OOMs on njalla", tc.regions)
			}

			// Isolation strategy: guard the threshold with an aggregate check.
			// In aggregate context, only compact on tombstone ratio, not region count.
			aggTriggered := false
			if mf.NumBooks > 0 && uint32(len(mf.Tombstones))*3 > mf.NumBooks {
				aggTriggered = true
			}

			// region-count check only for single-library context
			libTriggered := len(mf.Regions) > 5
			if mf.NumBooks > 0 && uint32(len(mf.Tombstones))*3 > mf.NumBooks {
				libTriggered = true
			}

			t.Logf("ISOLATION: context=%s regions=%d → lib-triggered=%v, agg-triggered=%v",
				tc.context, tc.regions, libTriggered, aggTriggered)
		})
	}
}

// ---------------------------------------------------------------------------
// Hypothesis 4: Self-healing splice with DictID reassignment
//

// Tests that when members have colliding DictIDs, we can:
// 1. Detect the collision
// 2. Reassign DictIDs (simulating "self-healing")
// 3. Rebuild affected members with new DictIDs
// 4. Successfully splice with the corrected containers
// 5. The output matches a clean build (no corruption)
// ---------------------------------------------------------------------------

func TestSpike_SelfHealingSpliceDictID(t *testing.T) {
	dir := t.TempDir()
	nMembers := 4
	booksEach := 80

	// Build members: two pairs share DictIDs (simulating legacy state)
	// member 0,1 → DictID 2; member 2,3 → DictID 3
	collidingDictIDs := []uint32{2, 2, 3, 3}

	type memberData struct {
		uuid       string
		librarian  string
		jsonlPath  string
		indexPath  string
		origDictID uint32
	}
	members := make([]memberData, nMembers)

	for i := 0; i < nMembers; i++ {
		mDir := filepath.Join(dir, fmt.Sprintf("member-%d", i))
		if err := os.MkdirAll(mDir, 0o755); err != nil {
			t.Fatal(err)
		}
		members[i] = memberData{
			uuid:       fmt.Sprintf("heal-uuid-%d", i),
			librarian:  fmt.Sprintf("librarian-%d", i),
			origDictID: collidingDictIDs[i],
		}
		baseURL := fmt.Sprintf("https://example.com/files/member-%d", i)
		members[i].jsonlPath = seedMemberJSONL(t, mDir, booksEach, members[i].uuid, members[i].librarian, baseURL)
		members[i].indexPath = filepath.Join(mDir, "library_index")
		buildMemberIndex(t, members[i].jsonlPath, members[i].indexPath, members[i].origDictID)
	}

	// Step 1: Confirm collision is detected
	t.Run("detect-collision", func(t *testing.T) {
		var extracted []*MemberContainerData
		for _, m := range members {
			mcd, err := ExtractMemberContainer(m.indexPath)
			if err != nil {
				t.Fatalf("ExtractMemberContainer: %v", err)
			}
			extracted = append(extracted, mcd)
		}

		aggPath := filepath.Join(dir, "agg_colliding")
		err := ComposeAggregate(aggPath, extracted, [16]byte{}, 1, ComposeOpts{})
		if err == nil {
			t.Fatal("expected collision error, got nil")
		}
		if !strings.Contains(err.Error(), "collision") {
			t.Fatalf("expected collision error, got: %v", err)
		}
		t.Logf("COLLISION detected: %v", err)
	})

	// Step 2: Self-heal — detect collisions and reassign DictIDs
	t.Run("self-heal-and-splice", func(t *testing.T) {

		// Simulate the self-healing algorithm:
		// 1. Extract all members
		// 2. Detect DictID collisions
		// 3. Reassign colliding DictIDs from a monotonic counter
		// 4. Rebuild affected members
		// 5. Splice

		var extracted []*MemberContainerData
		for _, m := range members {
			mcd, err := ExtractMemberContainer(m.indexPath)
			if err != nil {
				t.Fatalf("ExtractMemberContainer: %v", err)
			}
			extracted = append(extracted, mcd)
		}

		// Detect collisions
		dictIDOwner := make(map[uint32]int) // DictID → first member index
		var collisions []int                // indices of members needing new DictIDs
		for i, mcd := range extracted {
			did := mcd.DictEntry.DictID
			if _, ok := dictIDOwner[did]; ok {
				collisions = append(collisions, i)
			} else {
				dictIDOwner[did] = i
			}
		}

		if len(collisions) == 0 {
			t.Fatal("expected collisions, found none")
		}
		t.Logf("COLLISIONS: %d members need new DictIDs: %v", len(collisions), collisions)

		// Assign new DictIDs from counter (find max existing + 1)
		maxDictID := uint32(1)
		for did := range dictIDOwner {
			if did > maxDictID {
				maxDictID = did
			}
		}
		nextID := maxDictID + 1

		// Rebuild colliding members
		for _, idx := range collisions {
			m := &members[idx]
			newDictID := nextID
			nextID++

			t.Logf("HEAL: member %d (%s) DictID %d → %d", idx, m.uuid, m.origDictID, newDictID)

			// Rebuild with new DictID
			buildMemberIndex(t, m.jsonlPath, m.indexPath, newDictID)

			// Re-extract
			mcd, err := ExtractMemberContainer(m.indexPath)
			if err != nil {
				t.Fatalf("re-extract member %d: %v", idx, err)
			}
			extracted[idx] = mcd

			if mcd.DictEntry.DictID != newDictID {
				t.Errorf("member %d: expected DictID %d after rebuild, got %d", idx, newDictID, mcd.DictEntry.DictID)
			}
		}

		// Splice with healed DictIDs
		aggPath := filepath.Join(dir, "agg_healed")
		err := ComposeAggregate(aggPath, extracted, [16]byte{}, 1, ComposeOpts{})
		if err != nil {
			t.Fatalf("ComposeAggregate after heal: %v", err)
		}

		// Verify aggregate correctness
		mf, err := ReadExistingManifest(aggPath)
		if err != nil {
			t.Fatalf("ReadExistingManifest: %v", err)
		}
		expectedBooks := uint32(nMembers * booksEach)
		if mf.NumBooks != expectedBooks {
			t.Errorf("expected %d books, got %d", expectedBooks, mf.NumBooks)
		}
		t.Logf("HEALED AGGREGATE: %d books, %d regions", mf.NumBooks, len(mf.Regions))

		// Verify all DictIDs are unique in the aggregate
		aggDicts := make(map[uint32]bool)
		for _, r := range mf.Regions {
			if aggDicts[r.DictID] {
				t.Errorf("duplicate DictID %d in aggregate regions", r.DictID)
			}
			aggDicts[r.DictID] = true
		}
		t.Logf("DICTID uniqueness in aggregate: %d unique IDs, all distinct", len(aggDicts))

		// Searchability
		ms := &MotwSearch{IndexPath: aggPath}
		opened, err := ms.Open()
		if err != nil {
			t.Fatalf("Open: %v", err)
		}
		defer opened.Close()

		results, _, err := opened.Search(context.Background(),
			SearchQuery{Field: FieldTitle, Text: "Art"},
			SearchOptions{Limit: 10, SortMode: SortRelevance})
		if err != nil {
			t.Fatalf("Search: %v", err)
		}
		if len(results) == 0 {
			t.Error("expected search results after heal, got none")
		}
		t.Logf("SEARCH: %d results for 'Art'", len(results))
	})

	// Step 3: Compare healed splice vs clean-DictID full build
	t.Run("heal-vs-clean-equivalence", func(t *testing.T) {

		// Build all members fresh with unique DictIDs from the start
		cleanDir := filepath.Join(dir, "clean")
		if err := os.MkdirAll(cleanDir, 0o755); err != nil {
			t.Fatal(err)
		}

		var cleanExtracted []*MemberContainerData
		for i, m := range members {
			cDir := filepath.Join(cleanDir, fmt.Sprintf("member-%d", i))
			if err := os.MkdirAll(cDir, 0o755); err != nil {
				t.Fatal(err)
			}
			cleanDictID := uint32(i + 2)
			cleanIdxPath := filepath.Join(cDir, "library_index")
			buildMemberIndex(t, m.jsonlPath, cleanIdxPath, cleanDictID)

			mcd, err := ExtractMemberContainer(cleanIdxPath)
			if err != nil {
				t.Fatalf("ExtractMemberContainer(clean): %v", err)
			}
			cleanExtracted = append(cleanExtracted, mcd)
		}

		cleanAggPath := filepath.Join(cleanDir, "aggregate")
		err := ComposeAggregate(cleanAggPath, cleanExtracted, [16]byte{}, 1, ComposeOpts{})
		if err != nil {
			t.Fatalf("ComposeAggregate(clean): %v", err)
		}

		// Also build healed aggregate for comparison
		var healExtracted []*MemberContainerData

		// Use same DictID mapping as the heal step
		healDictIDs := []uint32{2, 4, 3, 5} // member 0 keeps 2, member 1 gets 4, member 2 keeps 3, member 3 gets 5
		for i, m := range members {
			hDir := filepath.Join(dir, fmt.Sprintf("heal-cmp-%d", i))
			if err := os.MkdirAll(hDir, 0o755); err != nil {
				t.Fatal(err)
			}
			hIdxPath := filepath.Join(hDir, "library_index")
			buildMemberIndex(t, m.jsonlPath, hIdxPath, healDictIDs[i])

			mcd, err := ExtractMemberContainer(hIdxPath)
			if err != nil {
				t.Fatalf("ExtractMemberContainer(heal): %v", err)
			}
			healExtracted = append(healExtracted, mcd)
		}

		healAggPath := filepath.Join(dir, "agg_heal_cmp")
		err = ComposeAggregate(healAggPath, healExtracted, [16]byte{}, 1, ComposeOpts{})
		if err != nil {
			t.Fatalf("ComposeAggregate(heal): %v", err)
		}

		// Compare: both should have same book count, same search results
		cleanMf, _ := ReadExistingManifest(cleanAggPath)
		healMf, _ := ReadExistingManifest(healAggPath)

		if cleanMf.NumBooks != healMf.NumBooks {
			t.Errorf("book count mismatch: clean=%d heal=%d", cleanMf.NumBooks, healMf.NumBooks)
		}

		cleanMS := &MotwSearch{IndexPath: cleanAggPath}
		cleanOpened, err := cleanMS.Open()
		if err != nil {
			t.Fatalf("Open(clean): %v", err)
		}
		defer cleanOpened.Close()

		healMS := &MotwSearch{IndexPath: healAggPath}
		healOpened, err := healMS.Open()
		if err != nil {
			t.Fatalf("Open(heal): %v", err)
		}
		defer healOpened.Close()

		type searchCase struct {
			field SearchField
			text  string
		}
		queries := []searchCase{
			{FieldTitle, "Art"},
			{FieldTitle, "History"},
			{FieldAuthor, "Kant"},
			{FieldTag, "economics"},
		}
		for _, sq := range queries {
			q := fmt.Sprintf("%s:%s", sq.field, sq.text)
			cleanResults, _, err := cleanOpened.Search(context.Background(),
				SearchQuery{Field: sq.field, Text: sq.text},
				SearchOptions{Limit: 100, SortMode: SortRelevance})
			if err != nil {
				t.Fatalf("clean search %q: %v", q, err)
			}
			healResults, _, err := healOpened.Search(context.Background(),
				SearchQuery{Field: sq.field, Text: sq.text},
				SearchOptions{Limit: 100, SortMode: SortRelevance})
			if err != nil {
				t.Fatalf("heal search %q: %v", q, err)
			}

			if len(cleanResults) != len(healResults) {
				t.Errorf("search %q: clean=%d results, heal=%d results", q, len(cleanResults), len(healResults))
			} else {
				t.Logf("EQUIVALENCE %q: %d results (match)", q, len(cleanResults))
			}

			// Compare book IDs
			cleanIDs := bookIDSet(cleanResults)
			healIDs := bookIDSet(healResults)
			for id := range cleanIDs {
				if !healIDs[id] {
					t.Errorf("search %q: book %s in clean but not heal", q, id)
				}
			}
			for id := range healIDs {
				if !cleanIDs[id] {
					t.Errorf("search %q: book %s in heal but not clean", q, id)
				}
			}
		}

		t.Logf("EQUIVALENCE: healed aggregate matches clean aggregate — DictID reassignment is safe")
	})
}
