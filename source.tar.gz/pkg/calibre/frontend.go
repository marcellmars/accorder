package calibre

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"io/fs"
	"net/http"
)

func RegisterFrontendRoutes(mux *http.ServeMux) {
	RegisterFrontendRoutesWithFallback(mux, nil)
}

// RegisterFrontendRoutesWithFallback serves the embedded SPA at "/" and
// delegates any other unmatched path to fallback — e.g. a (guarded) file
// server over the library directory, so the rendered site's root-relative
// cover and book URLs resolve like on a classic static deployment. A nil
// fallback keeps the plain-404 behavior.
func RegisterFrontendRoutesWithFallback(mux *http.ServeMux, fallback http.Handler) {
	RegisterFrontendRoutesGated(mux, fallback, nil)
}

// RegisterFrontendRoutesGated is RegisterFrontendRoutesWithFallback with an
// optional wrap applied to the SPA shell ("/") and embedded static-asset
// ("/static/") handlers — the browser plane. Callers pass wrap to gate these
// behind a capability check (private mode); a nil wrap leaves them open
// (public / offline-private), so the browser plane stays anonymous.
func RegisterFrontendRoutesGated(mux *http.ServeMux, fallback http.Handler, wrap func(http.Handler) http.Handler) {
	embFS, err := fs.Sub(embResources, "embResources")
	if err != nil {
		panic("RegisterFrontendRoutes: fs.Sub embResources: " + err.Error())
	}

	// The embedded SPA assets (bundle.js, bundle.css, fonts…) have stable
	// filenames with no build-time hash, and embed.FS exposes no modtime/ETag —
	// so without help a browser heuristically caches them and never picks up a
	// redeploy (stale bundle.js = users stuck on old frontend after every
	// deploy). Precompute a content ETag per asset and serve Cache-Control:
	// no-cache: the browser revalidates each load, gets a cheap 304 when the
	// bytes are unchanged, and re-fetches only when a deploy actually changed
	// them. http.ServeContent honors a pre-set ETag header for If-None-Match.
	etags := map[string]string{}
	_ = fs.WalkDir(embFS, ".", func(p string, d fs.DirEntry, walkErr error) error {
		if walkErr != nil || d.IsDir() {
			return nil
		}
		if b, e := fs.ReadFile(embFS, p); e == nil {
			sum := sha256.Sum256(b)
			etags["/"+p] = `"` + hex.EncodeToString(sum[:8]) + `"`
		}
		return nil
	})

	if wrap == nil {
		wrap = func(h http.Handler) http.Handler { return h }
	}

	fileServer := http.FileServer(http.FS(embFS))
	mux.Handle("/static/", wrap(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if etag, ok := etags[r.URL.Path]; ok {
			w.Header().Set("ETag", etag) // ServeContent uses this for If-None-Match → 304
		}
		w.Header().Set("Cache-Control", "no-cache")
		fileServer.ServeHTTP(w, r)
	})))

	rawHTML, err := fs.ReadFile(embFS, "BROWSE_LIBRARY.html")
	if err != nil {
		panic("RegisterFrontendRoutes: read BROWSE_LIBRARY.html: " + err.Error())
	}
	injectedHTML := bytes.Replace(rawHTML,
		[]byte("</head>"),
		[]byte(`<script>window.__RESTAPI__="/"</script></head>`),
		1,
	)
	if !bytes.Contains(injectedHTML, []byte(`window.__RESTAPI__`)) {
		panic("RegisterFrontendRoutes: </head> marker not found in BROWSE_LIBRARY.html")
	}
	shellSum := sha256.Sum256(injectedHTML)
	shellETag := `"` + hex.EncodeToString(shellSum[:8]) + `"`

	mux.Handle("/", wrap(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/" {
			w.Header().Set("Cache-Control", "no-cache")
			w.Header().Set("ETag", shellETag)
			if r.Header.Get("If-None-Match") == shellETag {
				w.WriteHeader(http.StatusNotModified)
				return
			}
			w.Header().Set("Content-Type", "text/html; charset=utf-8")
			w.Write(injectedHTML)
			return
		}
		if fallback != nil {
			fallback.ServeHTTP(w, r)
			return
		}
		http.NotFound(w, r)
	})))
}
