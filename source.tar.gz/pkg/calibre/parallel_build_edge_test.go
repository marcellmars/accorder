package calibre

// Edge case the byte-identical oracle missed (its corpora all end with a newline):
// a JSONL whose final line lacks a trailing newline. BuildIndex and CompressToFile must
// agree on the book/segment count — both DROP that line. The pre-parallel code did;
// the parallel pre-scan briefly kept it, so BuildIndex emitted a segment CompressToFile
// never wrote, and a query for the last book resolved to a segment id past displayIndex.

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"
)

func TestParallelBuildIndex_FinalLineNoTrailingNewline(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "books.jsonl")
	f, err := os.Create(path)
	if err != nil {
		t.Fatal(err)
	}
	const n = 33 // > 2 segments, so the dropped line changes the segment count
	for i := 0; i < n; i++ {
		b := Book{
			Id:           fmt.Sprintf("00000000-0000-0000-0000-%012d", i),
			UUID:         fmt.Sprintf("u%d", i),
			Title:        fmt.Sprintf("Book %d alpha", i),
			Authors:      []string{"A"},
			Tags:         []string{"t"},
			LastModified: "2024-01-01T00:00:00+00:00",
			LibraryUUID:  "L",
		}
		line, _ := json.Marshal(b)
		f.Write(line)
		if i < n-1 {
			f.Write([]byte("\n")) // the final line gets NO trailing newline
		}
	}
	f.Close()

	ms := &MotwSearch{JsonlPath: path, IndexPath: filepath.Join(dir, "idx")}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	// BuildIndex must drop the final newline-less line, matching CompressToFile.
	if idx.NumBooks != n-1 {
		t.Fatalf("NumBooks=%d, want %d — final newline-less line must be dropped so BuildIndex and CompressToFile agree", idx.NumBooks, n-1)
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}
	// End-to-end: a search must not resolve a segment id past displayIndex (the pre-fix
	// failure was a silent miss or an out-of-range panic on materialize).
	opened, err := ms.Open()
	if err != nil {
		t.Fatal(err)
	}
	defer opened.Close()
	if _, _, err := opened.Search(context.Background(),
		SearchQuery{Field: FieldTitle, Text: "alpha", Mode: ModeExact}, SearchOptions{}); err != nil {
		t.Fatalf("search after no-trailing-newline build: %v", err)
	}
}
