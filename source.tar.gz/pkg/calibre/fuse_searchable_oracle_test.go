package calibre

import (
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"testing"
)

func fuseWriteCorpus(t *testing.T, path string, n int, trailingNewline bool) {
	t.Helper()
	f, err := os.Create(path)
	if err != nil {
		t.Fatal(err)
	}
	w := bufio.NewWriter(f)
	for i := 0; i < n; i++ {
		b := Book{
			Id:           methodID(i),
			UUID:         fmt.Sprintf("u%d", i),
			Title:        fmt.Sprintf("Book number %d about quantum methods", i),
			Authors:      []string{fmt.Sprintf("Author %d", i%5)},
			Tags:         []string{"physics", "alpha"},
			Abstract:     fmt.Sprintf("<p>discussion of method %d with <b>filler</b> words</p>", i),
			LastModified: fmt.Sprintf("2024-01-%02dT00:00:00+00:00", (i%27)+1),
			LibraryUUID:  "L",
		}
		line, _ := json.Marshal(b)
		w.Write(line)
		if trailingNewline || i < n-1 {
			w.WriteByte('\n')
		}
	}
	w.Flush()
	f.Close()
}

func fuseBuildZst(t *testing.T, jsonlPath, idxPath string, gmp int, indexDesc, forceFallback bool) []byte {
	t.Helper()
	prev := runtime.GOMAXPROCS(gmp)
	defer runtime.GOMAXPROCS(prev)
	gen := [16]byte{0x5a, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16}
	ms := &MotwSearch{JsonlPath: jsonlPath, IndexPath: idxPath, IndexDescription: indexDesc, BaseGeneration: &gen}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if forceFallback {
		idx.Searchable = nil
		idx.SearchSegLens = nil
		idx.Recency = nil
	}
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}
	b, err := os.ReadFile(idxPath + ".zst")
	if err != nil {
		t.Fatal(err)
	}
	return b
}

func TestFuseSearchable_FusedEqualsFallback(t *testing.T) {
	cases := []struct {
		name            string
		n               int
		trailingNewline bool
	}{
		{"multiple_of_16", 32, true},
		{"non_multiple_of_16", 37, true},
		{"no_trailing_newline", 20, false},
		{"no_trailing_newline_odd", 19, false},
		{"tiny", 3, true},
		{"single", 1, true},
		{"empty", 0, true},
	}
	for _, tc := range cases {
		for _, desc := range []bool{false, true} {
			t.Run(fmt.Sprintf("%s/desc=%v", tc.name, desc), func(t *testing.T) {
				dir := t.TempDir()
				jp := filepath.Join(dir, "books.jsonl")
				fuseWriteCorpus(t, jp, tc.n, tc.trailingNewline)

				fused := fuseBuildZst(t, jp, filepath.Join(dir, "fused"), runtime.NumCPU(), desc, false)
				fallback := fuseBuildZst(t, jp, filepath.Join(dir, "fallback"), 1, desc, true)

				if !bytes.Equal(fused, fallback) {
					t.Fatalf("fused (%d bytes) != serial fallback (%d bytes) for n=%d trailingNL=%v desc=%v",
						len(fused), len(fallback), tc.n, tc.trailingNewline, desc)
				}
			})
		}
	}
}

func TestFuseSearchable_ByteIdenticalAcrossGOMAXPROCS(t *testing.T) {
	if runtime.NumCPU() < 2 {
		t.Skip("needs >1 CPU")
	}
	dir := t.TempDir()
	jp := filepath.Join(dir, "books.jsonl")
	fuseWriteCorpus(t, jp, 150, true)
	seq := fuseBuildZst(t, jp, filepath.Join(dir, "seq"), 1, true, false)
	for _, gmp := range []int{2, 4, runtime.NumCPU()} {
		got := fuseBuildZst(t, jp, filepath.Join(dir, fmt.Sprintf("gmp%d", gmp)), gmp, true, false)
		if !bytes.Equal(got, seq) {
			t.Fatalf("gmp=%d diverged from gmp=1 (%d vs %d bytes)", gmp, len(got), len(seq))
		}
	}
}

func TestFuseSearchable_RedCheck(t *testing.T) {
	dir := t.TempDir()
	jp := filepath.Join(dir, "books.jsonl")
	fuseWriteCorpus(t, jp, 40, true)

	gen := [16]byte{0x5a, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16}
	ms := &MotwSearch{JsonlPath: jp, IndexPath: filepath.Join(dir, "corrupt"), BaseGeneration: &gen}
	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if len(idx.Searchable) == 0 {
		t.Fatal("no searchable bytes to corrupt")
	}
	idx.Searchable[len(idx.Searchable)/2] ^= 0xff
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatal(err)
	}
	corrupt, _ := os.ReadFile(filepath.Join(dir, "corrupt.zst"))
	clean := fuseBuildZst(t, jp, filepath.Join(dir, "clean"), 1, false, true)
	if bytes.Equal(corrupt, clean) {
		t.Fatal("oracle is blind: a corrupted searchable buffer produced an identical .zst")
	}
}
