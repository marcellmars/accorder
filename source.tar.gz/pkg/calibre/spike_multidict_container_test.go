package calibre

// Phase-0 spike for WF3 (fedlib-operations): end-to-end multi-dict decode
// through the container reader path.
//

// Proves that the openMWSC → newMWSCReaderAt → multi-dict zstd.Decoder
// chain selects the correct per-region dict by frame Dictionary_ID when N dicts
// are registered at decoder creation. Mirrors the production wiring: build a
// spliced seekable stream, wrap it with the MWSC container header (magic +
// version + dict prefix), open it with the same readContainerHeader →
// newMWSCReaderAt → zstd.Decoder pattern, and verify each region's payload.
//

// This does NOT modify production code. It constructs a minimal multi-dict MWSC
// file in a temp dir and opens it using the same primitives openMWSC uses.

import (
	"bytes"
	"encoding/binary"
	"io"
	"os"
	"path/filepath"
	"testing"

	"github.com/klauspost/compress/zstd"
)

// TestSpike_MultiDictContainer_E2E builds a multi-dict MWSC-shaped file and
// opens it using the same newMWSCReaderAt + multi-dict zstd.Decoder wiring
// that openMWSC uses, verifying each region decodes correctly.
func TestSpike_MultiDictContainer_E2E(t *testing.T) {

	// Two members, each with a distinct dict and dictID.
	dictA := rawDict("member-alpha")
	dictB := rawDict("member-bravo")
	payloadA := dictBackedPayload(dictA, "\n{\"_id\":\"a1\"}\n")
	payloadB := dictBackedPayload(dictB, "\n{\"_id\":\"b1\"}\n")

	// Build per-member seekable streams.
	streamA := buildSeekableStream(t, 100, dictA, payloadA)
	streamB := buildSeekableStream(t, 200, dictB, payloadB)

	// Extract frames + entries, splice into one seekable stream.
	entriesA, eszA, tsA := readSeekTableEntriesTB(t, streamA)
	entriesB, eszB, tsB := readSeekTableEntriesTB(t, streamB)
	if eszA != eszB {
		t.Fatalf("entry size mismatch: %d vs %d", eszA, eszB)
	}
	var splicedStream bytes.Buffer
	splicedStream.Write(streamA[:tsA])
	splicedStream.Write(streamB[:tsB])
	merged := append(entriesA, entriesB...)
	writeSeekTableBuf(t, &splicedStream, merged, eszA)

	// Write a v2 MWSC container with a dict catalog containing both dicts.
	catalog := []DictCatalogEntry{
		{DictID: 100, DictBytes: dictA},
		{DictID: 200, DictBytes: dictB},
	}
	catSize := dictCatalogSize(catalog)
	dir := t.TempDir()
	containerPath := filepath.Join(dir, "multi.mwsc.zst")
	f, err := os.Create(containerPath)
	if err != nil {
		t.Fatal(err)
	}

	// Container header: "MWSC" + version(2) + catalogSize(8) + catalog entries.
	f.Write([]byte(containerMagic))
	f.Write([]byte{containerVersion})
	binary.Write(f, binary.LittleEndian, catSize)
	writeDictCatalog(f, catalog)

	// Seekable stream follows the header+catalog.
	f.Write(splicedStream.Bytes())
	f.Close()

	// --- Open using the SAME pattern as openMWSC ---
	f2, err := os.Open(containerPath)
	if err != nil {
		t.Fatal(err)
	}
	defer f2.Close()

	// Step 1: readContainerHeader (production function).
	headerCatalog, seekableOffset, err := readContainerHeader(f2)
	if err != nil {
		t.Fatalf("readContainerHeader: %v", err)
	}
	if len(headerCatalog) != 2 {
		t.Fatalf("expected 2 catalog entries, got %d", len(headerCatalog))
	}
	if !bytes.Equal(headerCatalog[0].DictBytes, dictA) || headerCatalog[0].DictID != 100 {
		t.Fatal("catalog entry 0 mismatch")
	}
	if !bytes.Equal(headerCatalog[1].DictBytes, dictB) || headerCatalog[1].DictID != 200 {
		t.Fatal("catalog entry 1 mismatch")
	}

	// Step 2: Create multi-dict decoder — mirrors what openMWSC does in v5.
	// Register BOTH dicts from the catalog.
	var decOpts []zstd.DOption
	for _, entry := range headerCatalog {
		decOpts = append(decOpts, zstd.WithDecoderDictRaw(entry.DictID, entry.DictBytes))
	}
	dec, err := zstd.NewReader(nil, decOpts...)
	if err != nil {
		t.Fatalf("multi-dict zstd reader: %v", err)
	}
	defer dec.Close()

	// Step 3: owned reader over the seekable portion (production pattern).
	fileSize, err := f2.Seek(0, io.SeekEnd)
	if err != nil {
		t.Fatal(err)
	}
	seekableLen := fileSize - seekableOffset
	sr := io.NewSectionReader(f2, seekableOffset, seekableLen)
	rdr, err := newMWSCReaderAt(sr, seekableLen, dec)
	if err != nil {
		t.Fatalf("seekable reader: %v", err)
	}
	defer rdr.Close()

	// Step 4: Verify each region round-trips.
	totalExpected := int64(len(payloadA) + len(payloadB))
	if rdr.Size() != totalExpected {
		t.Fatalf("container Size=%d want %d", rdr.Size(), totalExpected)
	}

	gotA := make([]byte, len(payloadA))
	if _, err := rdr.ReadAt(gotA, 0); err != nil {
		t.Fatalf("ReadAt region A: %v", err)
	}
	if !bytes.Equal(gotA, payloadA) {
		t.Fatalf("region A payload mismatch")
	}

	gotB := make([]byte, len(payloadB))
	if _, err := rdr.ReadAt(gotB, int64(len(payloadA))); err != nil {
		t.Fatalf("ReadAt region B: %v", err)
	}
	if !bytes.Equal(gotB, payloadB) {
		t.Fatalf("region B payload mismatch")
	}

	t.Logf("VALIDATED: E2E multi-dict container — readContainerHeader → "+
		"newMWSCReaderAt → multi-dict zstd.Decoder chain selects correct "+
		"per-region dict. frames=%d size=%d", rdr.numFrames(), rdr.Size())
}
