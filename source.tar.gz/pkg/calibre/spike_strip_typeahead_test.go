package calibre

// Spike: the "strip just the typeahead FST" middle option.
//
// Instead of shipping JSONL-only and recompiling everything (~2 min), ship the
// full index MINUS the 91 MB (uncompressed) typeahead/entity FST, and have the
// client rebuild ONLY that section from the display-JSONL already in the
// download. Measures (a) the real *compressed* download saving from dropping
// typeahead, and (b) the client cost to rebuild just typeahead vs the full
// from-scratch compile.
//
//   REPORT=/tmp/strip.txt AGG_INDEX=/tmp/agg/library_index \
//     go test ./pkg/calibre/ -run TestSpikeStripTypeahead -v -timeout 30m

import (
	"bufio"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestSpikeStripTypeahead(t *testing.T) {
	orig := os.Getenv("AGG_INDEX")
	if orig == "" {
		t.Skip("set AGG_INDEX=/path/to/library_index (no .zst) to run")
	}
	var rep strings.Builder
	logf := func(format string, a ...any) {
		line := fmt.Sprintf(format, a...)
		t.Log(line)
		rep.WriteString(line + "\n")
	}
	defer func() {
		if p := os.Getenv("REPORT"); p != "" {
			_ = os.WriteFile(p, []byte(rep.String()), 0o644)
		}
	}()

	oi, err := os.Stat(orig + ".zst")
	if err != nil {
		t.Fatalf("stat orig: %v", err)
	}
	mf, err := ReadExistingManifest(orig)
	if err != nil {
		t.Fatalf("manifest: %v", err)
	}
	logf("ORIGINAL full.zst=%d typeaheadLen(uncompressed)=%d", oi.Size(), mf.TypeaheadLen)

	jsonl, err := ReadDisplayJSONL(orig)
	if err != nil {
		t.Fatalf("ReadDisplayJSONL: %v", err)
	}
	dir := t.TempDir()
	jsonlPath := filepath.Join(dir, "books.jsonl")
	if err := os.WriteFile(jsonlPath, jsonl, 0o644); err != nil {
		t.Fatalf("write jsonl: %v", err)
	}

	baseGen := mf.BaseGeneration
	dictID := uint32(0)
	if len(mf.Regions) > 0 {
		dictID = mf.Regions[0].DictID
	}
	rebuild := filepath.Join(dir, "library_index")
	ms := &MotwSearch{
		JsonlPath: jsonlPath, IndexPath: rebuild,
		BaseGeneration: &baseGen, StartGeneration: mf.Generation,
		IndexAggregateFields: true, DictID: dictID, ChunkSize: int(mf.ChunkSize),
	}

	idx, err := ms.BuildIndex()
	if err != nil {
		t.Fatalf("BuildIndex: %v", err)
	}

	// Strip: replace the entity FST with an empty one so the emitted typeahead
	// section collapses to ~nothing. CompressToFile derives typeahead from this.
	emptyEntity, err := buildEntityFST(entityCollector{})
	if err != nil {
		t.Fatalf("buildEntityFST(empty): %v", err)
	}
	idx.EntityFST = emptyEntity

	tc := time.Now()
	if err := ms.CompressToFile(idx); err != nil {
		t.Fatalf("CompressToFile(stripped): %v", err)
	}
	compStrip := time.Since(tc)
	si, err := os.Stat(rebuild + ".zst")
	if err != nil {
		t.Fatalf("stat stripped: %v", err)
	}
	mf2, _ := ReadExistingManifest(rebuild)
	saved := oi.Size() - si.Size()
	logf("STRIPPED-TYPEAHEAD .zst=%d (typeaheadLen now %d) compress=%s",
		si.Size(), mf2.TypeaheadLen, compStrip.Round(time.Millisecond))
	logf("DOWNLOAD SAVING from dropping typeahead: %d bytes = %.1f%% of full",
		saved, 100*float64(saved)/float64(oi.Size()))

	// Client cost to rebuild ONLY the typeahead from the display-JSONL: scan the
	// JSONL, collect entities (title/authors/tags), build entity FST + typeahead.
	tr := time.Now()
	entities := entityCollector{}
	f, err := os.Open(jsonlPath)
	if err != nil {
		t.Fatalf("open jsonl: %v", err)
	}
	sc := bufio.NewScanner(f)
	sc.Buffer(make([]byte, 1<<20), 1<<24)
	nb := 0
	for sc.Scan() {
		var b Book
		if err := json.Unmarshal(sc.Bytes(), &b); err != nil {
			t.Fatalf("unmarshal: %v", err)
		}
		entities.add(FieldTitle, b.Title)
		for _, a := range b.Authors {
			entities.add(FieldAuthor, a)
		}
		for _, tg := range b.Tags {
			entities.add(FieldTag, tg)
		}
		nb++
	}
	f.Close()
	efst, err := buildEntityFST(entities)
	if err != nil {
		t.Fatalf("buildEntityFST: %v", err)
	}
	taBytes, err := buildTypeaheadFSTBytes([][]byte{efst})
	if err != nil {
		t.Fatalf("buildTypeaheadFSTBytes: %v", err)
	}
	rebuildTA := time.Since(tr)
	logf("CLIENT typeahead rebuild from JSONL: %s for %d books (entityFST=%d B, typeahead=%d B)",
		rebuildTA.Round(time.Millisecond), nb, len(efst), len(taBytes))

	logf("COMPARE: full-JSONL option = ~77 MB saved / ~2m00s compile;  strip-typeahead option = %.0f MB saved / %s client cost",
		float64(saved)/1e6, rebuildTA.Round(time.Millisecond))
	fmt.Fprintln(os.Stdout, "spike-strip-typeahead: done")
}
