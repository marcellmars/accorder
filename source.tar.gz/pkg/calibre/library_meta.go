package calibre

type LibraryMeta struct {
	Librarian  string `json:"librarian"`
	Prefix     string `json:"prefix"`
	State      string `json:"state,omitempty"`
	Kind       string `json:"kind,omitempty"` // "local" | "rclone" | "peer" | "" (empty => rclone; rclone members carry no kind)
	LocalPath  string `json:"local_path,omitempty"`
	DictID     uint32 `json:"dict_id,omitempty"`
	Endpoint   string `json:"endpoint,omitempty"`
	GrantToken string `json:"grant_token,omitempty"`
}

func (m LibraryMeta) IsLocal() bool {
	return m.Kind == "local"
}

func (m LibraryMeta) IsPeer() bool {
	return m.Kind == "peer"
}

func (m LibraryMeta) IsActive() bool {
	switch m.State {
	case "", "ready":
		return true
	default:
		return false
	}
}

func HasRcloneMembers(registry map[string]LibraryMeta) bool {
	for _, m := range registry {
		if m.IsLocal() || m.IsPeer() {
			continue
		}
		if m.IsActive() || m.State == "invited" || m.State == "retired" {
			return true
		}
	}
	return false
}

func HasPeerMembers(registry map[string]LibraryMeta) bool {
	for _, m := range registry {
		if !m.IsPeer() {
			continue
		}
		if m.IsActive() || m.State == "invited" || m.State == "retired" {
			return true
		}
	}
	return false
}
