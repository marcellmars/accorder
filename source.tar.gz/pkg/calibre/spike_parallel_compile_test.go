package calibre

// Phase 0 spike for parallel-index-compile: the proposed merge strategy assumes a postings
// bitmap built by roaring.Or of segment-DISJOINT per-worker partials serializes
// byte-identically to one built by sequential Add (what BuildIndex does today, encoded via
// bm.WriteTo with NO RunOptimize — search.go:4392). If any case diverges, the merge must
// replay all Adds into one bitmap instead of Or-ing partials.
//

// Container type (array ≤4096 vs bitmap >4096, per 64K block) is a function of the final
// SET, not insertion order — so this SHOULD hold; the spike proves it across container
// regimes and both Or forms.
//

// Run: go test ./pkg/calibre/ -run TestSpikeParallelCompile -count=1 -v

import (
	"bytes"
	"testing"

	"github.com/RoaringBitmap/roaring/v2"
)

func serializeBM(t *testing.T, bm *roaring.Bitmap) []byte {
	t.Helper()
	var buf bytes.Buffer
	if _, err := bm.WriteTo(&buf); err != nil {
		t.Fatal(err)
	}
	return buf.Bytes()
}

// split returns segs partitioned at boundary into two range-aligned worker partials.
func split(segs []uint32, boundary uint32) (lo, hi []uint32) {
	for _, s := range segs {
		if s < boundary {
			lo = append(lo, s)
		} else {
			hi = append(hi, s)
		}
	}
	return
}

func TestSpikeParallelCompile_RoaringMergeByteIdentical(t *testing.T) {
	cases := []struct {
		name     string
		segs     []uint32 // the segment IDs a term appears in, in sequential book order
		boundary uint32   // worker range split (segment-aligned)
	}{
		{"sparse_array_container", []uint32{0, 1, 3, 4, 5, 7, 12, 30}, 16},
		{"dense_bitmap_container", denseRange(0, 6000), 3008},    // >4096 in one 64K block → bitmap container
		{"multi_64k_block", multiBlock(), 65536},                 // spans container key boundary
		{"boundary_exact_4096", denseRange(0, 4096), 2048},       // array↔bitmap threshold
		{"single_worker_all", []uint32{0, 5, 9, 40, 99}, 100000}, // hi partial empty
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {

			// Path A: sequential Add (today's BuildIndex).
			seq := roaring.New()
			for _, s := range c.segs {
				seq.Add(s)
			}
			seqBytes := serializeBM(t, seq)

			lo, hi := split(c.segs, c.boundary)
			w0 := roaring.New()
			for _, s := range lo {
				w0.Add(s)
			}
			w1 := roaring.New()
			for _, s := range hi {
				w1.Add(s)
			}

			// Path B1: roaring.Or (new bitmap from two partials).
			mergedNew := roaring.Or(w0, w1)
			if !bytes.Equal(seqBytes, serializeBM(t, mergedNew)) {
				t.Fatalf("roaring.Or NOT byte-identical to sequential Add (seq=%d B) — merge must replay Adds, not Or partials", len(seqBytes))
			}

			// Path B2: in-place a.Or(b) (the form used at search.go:3946 unionBitmap.Or).
			mergedInPlace := w0.Clone()
			mergedInPlace.Or(w1)
			if !bytes.Equal(seqBytes, serializeBM(t, mergedInPlace)) {
				t.Fatalf("in-place Or NOT byte-identical to sequential Add (seq=%d B)", len(seqBytes))
			}
			t.Logf("OK %s: Or-of-disjoint == sequential Add (%d bytes, %d segs)", c.name, len(seqBytes), len(c.segs))
		})
	}
}

func denseRange(start, end uint32) []uint32 {
	out := make([]uint32, 0, end-start)
	for s := start; s < end; s++ {
		out = append(out, s)
	}
	return out
}

func multiBlock() []uint32 {

	// Segments in two different 64K roaring blocks (different container keys).
	out := denseRange(0, 5000)
	for s := uint32(65536); s < 65536+5000; s++ {
		out = append(out, s)
	}
	return out
}
