package calibre

import (
	"bytes"
	"encoding/json"
	"fmt"
	"path/filepath"
	"reflect"
	"testing"
)

func TestReadCatalogRecordsKeepsNewestAndTombstones(t *testing.T) {
	dir := t.TempDir()
	var base []*Book
	want := make(map[string]CatalogRecordInfo)
	for i := range 64 {
		book := generationChangeTestBook(fmt.Sprintf("00000000-0000-4000-8000-%012d", i+1), fmt.Sprintf("Book %d", i))
		base = append(base, book)
		info, err := catalogRecordInfoFromBook(book)
		if err != nil {
			t.Fatal(err)
		}
		want[book.Id] = info
	}
	indexPath := filepath.Join(dir, "index")
	ms := &MotwSearch{JsonlPath: writeBooksJSONL(t, base, dir, "base.jsonl"), IndexPath: indexPath}
	index, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.CompressToFile(index); err != nil {
		t.Fatal(err)
	}
	edited := generationChangeTestBook(base[0].Id, "Updated title")
	ms.JsonlPath = writeBooksJSONL(t, []*Book{edited}, dir, "delta.jsonl")
	delta, err := ms.BuildIndex()
	if err != nil {
		t.Fatal(err)
	}
	deleted, err := bookIDToTombstone(base[1].Id)
	if err != nil {
		t.Fatal(err)
	}
	if err := ms.AppendToFile(delta, [][16]byte{deleted}); err != nil {
		t.Fatal(err)
	}
	want[edited.Id], err = catalogRecordInfoFromBook(edited)
	if err != nil {
		t.Fatal(err)
	}
	delete(want, base[1].Id)
	for range 5 {
		got, err := ReadCatalogRecordInfos(indexPath)
		if err != nil || !reflect.DeepEqual(got, want) {
			t.Fatalf("parallel record selection differs: got=%+v want=%+v err=%v", got, want, err)
		}
		got, err = ReadCatalogRecordInfosByID(indexPath, []string{edited.Id, base[1].Id})
		if err != nil || !reflect.DeepEqual(got, map[string]CatalogRecordInfo{edited.Id: want[edited.Id]}) {
			t.Fatalf("selected IDs included a deleted/stale record: %+v %v", got, err)
		}
	}
}

func TestCatalogRecordInfoMatchesCanonicalRoundTrip(t *testing.T) {
	for _, suffix := range []string{"", "\xff\xfe"} {
		book := generationChangeTestBook("00000000-0000-4000-8000-000000000001", "<Title> & café"+suffix)
		book.CoverUrl += suffix
		book.Formats[0].DirectoryPath += suffix
		book.Formats[0].Name += suffix
		canonical, err := CanonicalRecordBytes(book)
		if err != nil {
			t.Fatal(err)
		}
		var record canonicalRecord
		if err := json.Unmarshal(canonical, &record); err != nil {
			t.Fatal(err)
		}
		want := catalogRecordInfo(record, canonical)
		got, err := catalogRecordInfoFromBook(book)
		if err != nil || !reflect.DeepEqual(got, want) {
			t.Fatalf("book round trip changed: %+v %+v %v", got, want, err)
		}
		got, err = catalogRecordInfoFromJSON(canonical, book.Id)
		// The old JSON path re-encodes decoded strings; invalid source bytes
		// have already become valid replacement runes at this boundary.
		jsonCanonical, marshalErr := json.Marshal(record)
		if marshalErr != nil {
			t.Fatal(marshalErr)
		}
		wantJSON := catalogRecordInfo(record, jsonCanonical)
		if err != nil || !reflect.DeepEqual(got, wantJSON) {
			t.Fatalf("JSON round trip changed: %+v %+v %v", got, wantJSON, err)
		}
		// Old normalization sorts map keys before decoding. Uppercase aliases
		// must not gain precedence because a redundant re-marshal was removed.
		aliased := append(append([]byte(nil), canonical[:len(canonical)-1]...), []byte(`,"TITLE":"unexpected"}`)...)
		normalized, err := CanonicalRecordBytesFromJSON(aliased, book.Id)
		if err != nil || !bytes.Equal(normalized, jsonCanonical) {
			t.Fatalf("case alias changed canonical bytes: %s %v", normalized, err)
		}
	}
}

func TestCatalogRecordInfoNormalizesInvalidMetadataUTF8(t *testing.T) {
	for _, change := range []func(*Book){
		func(book *Book) { book.Title += "\xff" },
		func(book *Book) { book.Authors[0] += "\xff" },
		func(book *Book) { book.Formats[0].Format += "\xff" },
		func(book *Book) { book.Identifiers = []*Identifier{{Scheme: "isbn", Code: "\xff"}} },
	} {
		book := generationChangeTestBook("00000000-0000-4000-8000-000000000001", "Title")
		change(book)
		canonical, err := CanonicalRecordBytes(book)
		if err != nil {
			t.Fatal(err)
		}
		var record canonicalRecord
		if err := json.Unmarshal(canonical, &record); err != nil {
			t.Fatal(err)
		}
		want := catalogRecordInfo(record, canonical)
		got, err := catalogRecordInfoFromBook(book)
		if err != nil || !reflect.DeepEqual(got, want) {
			t.Fatalf("invalid metadata UTF-8 changed digest: got=%+v want=%+v err=%v", got, want, err)
		}
	}
}
