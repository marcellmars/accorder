package calibre

import (
	"testing"
)

// TestMemoryOfTheWorldifyIdempotent guards the two-stage build path
// (calibre build --jsonl-export then calibre build --index
// --jsonl-path=...). The second pass reads books from the JSONL whose
// UUID has already been cleared by the first pass; running
// MemoryOfTheWorldify again on a cleared book used to overwrite Book.Id
// with HMAC(LibraryUUID, "") — producing the same Id for every book in
// the resulting index. After the idempotency fix, a second pass should
// be a no-op for the Id field.
func TestMemoryOfTheWorldifyIdempotent(t *testing.T) {
	motw := &MotwStandaloneApp{
		Librarian:   "test",
		LibraryUUID: "fac314b6-cfa9-4d2b-99d6-e40a37599cdd",
	}
	book1 := &Book{UUID: "11111111-1111-1111-1111-111111111111", Title: "A"}
	book2 := &Book{UUID: "22222222-2222-2222-2222-222222222222", Title: "B"}

	book1.MemoryOfTheWorldify(motw)
	book2.MemoryOfTheWorldify(motw)
	id1First := book1.Id
	id2First := book2.Id

	if id1First == "" || id2First == "" {
		t.Fatalf("first pass: empty Id (book1=%q book2=%q)", id1First, id2First)
	}
	if id1First == id2First {
		t.Fatalf("first pass: two different books got the same Id %q — UUID input ignored?", id1First)
	}

	// Second pass — UUIDs already cleared.
	if book1.UUID != "" || book2.UUID != "" {
		t.Fatalf("UUID not cleared after first pass (book1=%q book2=%q)", book1.UUID, book2.UUID)
	}
	book1.MemoryOfTheWorldify(motw)
	book2.MemoryOfTheWorldify(motw)

	if book1.Id != id1First {
		t.Errorf("book1 Id mutated by second pass: %q → %q", id1First, book1.Id)
	}
	if book2.Id != id2First {
		t.Errorf("book2 Id mutated by second pass: %q → %q", id2First, book2.Id)
	}
	if book1.Id == book2.Id {
		t.Errorf("after second pass, distinct books collided to Id %q (the bug we're guarding)", book1.Id)
	}
}

// TestMemoryOfTheWorldifyFallbackForEmptyUUID guards book-id-integrity Part A:
// a book with no source UUID must still get a non-empty, deterministic, distinct
// _id (an empty _id is silently dropped by DiffBooks/tombstones and collides in
// the keyed UI list).
func TestMemoryOfTheWorldifyFallbackForEmptyUUID(t *testing.T) {
	motw := &MotwStandaloneApp{
		Librarian:   "test",
		LibraryUUID: "fac314b6-cfa9-4d2b-99d6-e40a37599cdd",
	}
	a := &Book{Title: "No UUID A", LastModified: "2024-01-01", CalibreID: 1}
	b := &Book{Title: "No UUID B", LastModified: "2024-01-02", CalibreID: 2}

	a.MemoryOfTheWorldify(motw)
	b.MemoryOfTheWorldify(motw)

	if a.Id == "" || b.Id == "" {
		t.Fatalf("fallback produced empty Id (a=%q b=%q)", a.Id, b.Id)
	}
	if a.Id == b.Id {
		t.Fatalf("distinct UUID-less books collided to Id %q", a.Id)
	}

	// Deterministic: a fresh book with the same source fields derives the same Id.
	aAgain := &Book{Title: "No UUID A", LastModified: "2024-01-01", CalibreID: 1}
	aAgain.MemoryOfTheWorldify(motw)
	if aAgain.Id != a.Id {
		t.Fatalf("fallback not deterministic: %q != %q", aAgain.Id, a.Id)
	}

	// Idempotent: re-running on the already-MotWified book is a no-op for Id.
	idBefore := a.Id
	a.MemoryOfTheWorldify(motw)
	if a.Id != idBefore {
		t.Fatalf("second pass mutated Id: %q → %q", idBefore, a.Id)
	}
}

func TestAssertBookIDsUnique(t *testing.T) {
	t.Run("all_unique", func(t *testing.T) {
		motw := &MotwStandaloneApp{Books: []*Book{
			{Id: "00000000-0000-4000-8000-000000000001", Title: "A"},
			{Id: "00000000-0000-4000-8000-000000000002", Title: "B"},
		}}
		if err := motw.AssertBookIDsUnique(); err != nil {
			t.Fatalf("unexpected error: %v", err)
		}
	})
	t.Run("empty_id", func(t *testing.T) {
		motw := &MotwStandaloneApp{Books: []*Book{
			{Id: "00000000-0000-4000-8000-000000000001", Title: "A"},
			{Id: "", Title: "B"},
		}}
		if err := motw.AssertBookIDsUnique(); err == nil {
			t.Fatal("expected error for empty _id, got nil")
		}
	})
	t.Run("duplicate_id", func(t *testing.T) {
		motw := &MotwStandaloneApp{Books: []*Book{
			{Id: "00000000-0000-4000-8000-000000000001", Title: "A"},
			{Id: "00000000-0000-4000-8000-000000000001", Title: "B"},
		}}
		if err := motw.AssertBookIDsUnique(); err == nil {
			t.Fatal("expected error for duplicate _id, got nil")
		}
	})
}

// TestMemoryOfTheWorldifyClearsSourceWhenIdPreset guards review finding #12:
// a book presented with both Id AND a source UUID skips _id derivation, but must
// still have UUID/CalibreID cleared so Calibre internals never leak via the
// omitempty JSON fields.
func TestMemoryOfTheWorldifyClearsSourceWhenIdPreset(t *testing.T) {
	motw := &MotwStandaloneApp{Librarian: "test", LibraryUUID: "fac314b6-cfa9-4d2b-99d6-e40a37599cdd"}
	b := &Book{Id: "00000000-0000-4000-8000-000000000001", UUID: "leak-me", CalibreID: 42, Title: "X"}
	b.MemoryOfTheWorldify(motw)
	if b.Id != "00000000-0000-4000-8000-000000000001" {
		t.Fatalf("pre-set Id should be preserved, got %q", b.Id)
	}
	if b.UUID != "" || b.CalibreID != 0 {
		t.Fatalf("source identity leaked: UUID=%q CalibreID=%d", b.UUID, b.CalibreID)
	}
}
