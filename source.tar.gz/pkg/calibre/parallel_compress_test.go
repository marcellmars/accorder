package calibre

// Stage 2 Phase 1 gate, historical record: the hand-rolled seekable path
// (independently EncodeAll'd frames + writeSeekTable) was proven BYTE-IDENTICAL
// to gitlab.com/rackn/seekable-zstd's NewWriter output — with and without a
// raw dict — by TestStage2Phase1_HandRolledByteIdentical (GO recorded in the
// parallel-compress-stage2 retrospective). With the rackn dep removed
// (own-seekable-reader), the byte-identity assertion is retired: zstd encoder
// output is not stable across klauspost versions, so a frozen reference would
// be fragile. What this test now proves is the semantic invariant that
// matters: the hand-rolled stream parses and round-trips through the owned
// reader, with and without a dict, at the production chunk shape.
//

// Run: go test ./pkg/calibre/ -run TestStage2Phase1 -count=1 -v

import (
	"bytes"
	"strings"
	"testing"

	"github.com/klauspost/compress/zstd"
)

func TestStage2Phase1_HandRolledRoundTrip(t *testing.T) {
	const chunkSize = 64 * 1024
	data := make([]byte, 0, 3*chunkSize+777) // multiple frames incl. a short tail
	for i := 0; i < cap(data); i++ {
		data = append(data, byte('A'+(i*2654435761)%26))
	}
	dict := []byte(strings.Repeat("display dictionary sample text 0123456789 ", 300))

	cases := []struct {
		name    string
		encOpts []zstd.EOption
		decOpts []zstd.DOption
	}{
		{
			"no_dict",
			[]zstd.EOption{zstd.WithEncoderLevel(zstd.SpeedBestCompression)},
			nil,
		},
		{
			"with_dict",
			[]zstd.EOption{zstd.WithEncoderLevel(zstd.SpeedBestCompression), zstd.WithEncoderDictRaw(7, dict)},
			[]zstd.DOption{zstd.WithDecoderDictRaw(7, dict)},
		},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			stream := handRolledSeekableStream(t, c.encOpts, chunkSize, seekTableEntrySizeCksm, data)

			dec, err := zstd.NewReader(nil, c.decOpts...)
			if err != nil {
				t.Fatal(err)
			}
			defer dec.Close()

			rdr, err := newMWSCReaderAt(bytes.NewReader(stream), int64(len(stream)), dec)
			if err != nil {
				t.Fatalf("owned reader over hand-rolled stream: %v", err)
			}
			defer rdr.Close()

			if rdr.Size() != int64(len(data)) {
				t.Fatalf("Size=%d want %d", rdr.Size(), len(data))
			}
			wantFrames := (len(data) + chunkSize - 1) / chunkSize
			if rdr.numFrames() != wantFrames {
				t.Fatalf("numFrames=%d want %d", rdr.numFrames(), wantFrames)
			}
			got := make([]byte, len(data))
			if _, err := rdr.ReadAt(got, 0); err != nil {
				t.Fatal(err)
			}
			if !bytes.Equal(got, data) {
				t.Fatalf("round-trip mismatch (%s)", c.name)
			}
			t.Logf("GO (%s): hand-rolled stream round-trips through the owned reader (%d B compressed, %d frames)", c.name, len(stream), wantFrames)
		})
	}
}
