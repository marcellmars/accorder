package calibre

// Spike for the client-side-index-compile draft (2026-06-20).
//
// Question it answers: if `lib browse` downloaded only the display-JSONL and
// compiled the search structures locally, how much smaller is the initial
// download, and what does the local compile cost?
//
// It measures, per corpus profile and size:
//   - full MWSC .zst (what we ship today)
//   - the display-JSONL compressed alone (what we'd ship instead)
//   - BuildIndex + CompressToFile wall-time (the client's one-time compile cost)
//
// Gated behind SPIKE=1 so it never runs in `go test ./...`. Run with:
//   SPIKE=1 go test ./pkg/calibre/ -run TestSpikeClientCompile -v -timeout 20m

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/klauspost/compress/zstd"
)

// tiny deterministic LCG so generated text varies (real-ish compression) without
// Math/rand, and is reproducible run-to-run.
type lcg uint64

func (s *lcg) next() uint64 {
	*s = lcg(uint64(*s)*6364136223846793005 + 1442695040888963407)
	return uint64(*s) >> 16
}
func (s *lcg) pick(words []string) string { return words[int(s.next())%len(words)] }
func (s *lcg) between(lo, hi int) int     { return lo + int(s.next())%(hi-lo+1) }

var spikeWords = strings.Fields(`
the structure of capital media networks discourse power history time being
nothingness critique pure reason science revolutions phenomenology spirit man
earth politics theory algorithms programming art language machine cybernetics
information society control protocol archive memory world library catalog index
labor value commodity form abstraction digital material culture aesthetics
ideology subject object dialectic negation totality fragment montage assemblage
ecology planet crisis future ruins infrastructure platform extraction logistics
`)

func (s *lcg) phrase(lo, hi int) string {
	n := s.between(lo, hi)
	parts := make([]string, n)
	for i := range parts {
		parts[i] = s.pick(spikeWords)
	}
	return strings.Join(parts, " ")
}

// seedRealisticJSONL writes n book records resembling real Calibre/MotW metadata.
// rich=true adds a multi-sentence abstract (the display-only field that dominates
// real records); rich=false is a sparse catalog with title/authors/tags only.
func seedRealisticJSONL(tb testing.TB, n int, rich bool) string {
	tb.Helper()
	dir := tb.TempDir()
	path := filepath.Join(dir, "books.jsonl")
	f, err := os.Create(path)
	if err != nil {
		tb.Fatal(err)
	}
	defer f.Close()

	rng := lcg(0x9e3779b97f4a7c15)
	for i := 0; i < n; i++ {
		na := rng.between(1, 3)
		authors := make([]string, na)
		for j := range authors {
			authors[j] = strings.Title(rng.phrase(2, 3))
		}
		nt := rng.between(2, 6)
		tags := make([]string, nt)
		for j := range tags {
			tags[j] = rng.phrase(1, 2)
		}
		b := Book{
			Title:        strings.Title(rng.phrase(3, 8)),
			Authors:      authors,
			Tags:         tags,
			Publisher:    strings.Title(rng.phrase(1, 3)),
			Series:       strings.Title(rng.phrase(1, 2)),
			Languages:    []string{"eng"},
			Pubdate:      fmt.Sprintf("%04d-01-01T00:00:00+00:00", 1950+int(rng.next())%75),
			LastModified: fmt.Sprintf("2024-%02d-%02dT00:00:00+00:00", rng.between(1, 12), rng.between(1, 28)),
			LibraryUUID:  "11111111-2222-3333-4444-555555555555",
			Librarian:    "slowrotation",
			UUID:         fmt.Sprintf("book-uuid-%08d-aaaa-bbbb-cccc-1234567890ab", i),
			Id:           fmt.Sprintf("slowrotation:%d", i),
			CoverUrl:     fmt.Sprintf("slowrotation/books/%d/cover.jpg", i),
			LibraryUrl:   fmt.Sprintf("https://library.memoryoftheworld.org/slowrotation/%d", i),
			Identifiers: []*Identifier{
				{Scheme: "isbn", Code: fmt.Sprintf("978%010d", i)},
				{Scheme: "doi", Code: fmt.Sprintf("10.%04d/%s", rng.between(1000, 9999), rng.phrase(1, 1))},
			},
			Formats: []*File{
				{Format: "EPUB", DirectoryPath: fmt.Sprintf("slowrotation/books/%d", i), Name: "book.epub", Size: int64(rng.between(200000, 4000000))},
				{Format: "PDF", DirectoryPath: fmt.Sprintf("slowrotation/books/%d", i), Name: "book.pdf", Size: int64(rng.between(500000, 30000000))},
			},
			CoverFingerprint: "AQIDBAUG", // 6-byte base64, like the real fingerprint
		}
		if rich {
			b.Abstract = strings.Title(rng.phrase(40, 120)) + "."
		}
		data, err := json.Marshal(b)
		if err != nil {
			tb.Fatal(err)
		}
		if _, err := f.Write(append(data, '\n')); err != nil {
			tb.Fatal(err)
		}
	}
	return path
}

func zstdBestSize(tb testing.TB, raw []byte) int {
	tb.Helper()
	enc, err := zstd.NewWriter(nil, zstd.WithEncoderLevel(zstd.SpeedBestCompression))
	if err != nil {
		tb.Fatal(err)
	}
	out := enc.EncodeAll(raw, nil)
	_ = enc.Close()
	return len(out)
}

func TestSpikeClientCompile(t *testing.T) {
	if os.Getenv("SPIKE") != "1" {
		t.Skip("set SPIKE=1 to run the client-compile measurement spike")
	}

	type profile struct {
		name string
		rich bool
	}
	profiles := []profile{{"lean", false}, {"rich", true}}
	sizes := []int{2000, 20000, 52000}

	t.Logf("%-6s %-7s %12s %12s %12s %10s %9s %9s %9s",
		"prof", "books", "rawJSONL", "jsonl.zst", "full.zst", "jsonl/full", "saving%", "buildMs", "compMs")

	for _, p := range profiles {
		for _, n := range sizes {
			jsonlPath := seedRealisticJSONL(t, n, p.rich)
			rawInfo, _ := os.Stat(jsonlPath)
			indexPath := filepath.Join(filepath.Dir(jsonlPath), "library_index")
			ms := &MotwSearch{JsonlPath: jsonlPath, IndexPath: indexPath}

			t0 := time.Now()
			idx, err := ms.BuildIndex()
			if err != nil {
				t.Fatalf("BuildIndex(%s,%d): %v", p.name, n, err)
			}
			buildMs := time.Since(t0).Milliseconds()

			t1 := time.Now()
			if err := ms.CompressToFile(idx); err != nil {
				t.Fatalf("CompressToFile(%s,%d): %v", p.name, n, err)
			}
			compMs := time.Since(t1).Milliseconds()

			fullInfo, err := os.Stat(indexPath + ".zst")
			if err != nil {
				t.Fatalf("stat full zst: %v", err)
			}

			displayJSONL, err := ReadDisplayJSONL(indexPath)
			if err != nil {
				t.Fatalf("ReadDisplayJSONL: %v", err)
			}
			jsonlZst := zstdBestSize(t, displayJSONL)

			ratio := float64(jsonlZst) / float64(fullInfo.Size())
			t.Logf("%-6s %-7d %12d %12d %12d %9.1f%% %8.1f%% %9d %9d",
				p.name, n, rawInfo.Size(), jsonlZst, fullInfo.Size(),
				ratio*100, (1-ratio)*100, buildMs, compMs)
		}
	}
}
