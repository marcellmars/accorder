package calibre

import (
	"bytes"
	"context"
	"fmt"
	"os/exec"
	"strings"
	"testing"
)

// ═══════════════════════════════════════════════════════════════════
// Spike: A1 — Can a single CalibreCLI closure serve a multi-call
// sequence by dispatching on cmd.Args?
//
// The assumption: each production method (calibredb, calibredbCapturingStderr)
// constructs a FRESH *exec.Cmd via exec.CommandContext, populates cmd.Args,
// then calls CalibreCLI(cmd). So cmd.Args is always populated with the
// command-specific arguments before the fake sees it.
// ═══════════════════════════════════════════════════════════════════

func TestSpike_A1_MultiCallDispatch(t *testing.T) {
	// Build a CalibreCLI that dispatches on cmd.Args[1] (the calibredb subcommand).
	// The production code prepends --library-path=... as Args[1] when LibraryPath
	// is set, pushing the subcommand to a later position. We test both with and
	// without LibraryPath.

	t.Run("without library path", func(t *testing.T) {
		var callLog []string

		exe := &CalibreExe{
			CalibreCLI: func(cmd *exec.Cmd) ([]byte, error) {
				// cmd.Args[0] is the binary name (calibredb), [1] is the subcommand
				sub := findSubcommand(cmd.Args)
				callLog = append(callLog, sub)

				switch sub {
				case "list":
					return []byte(`[{"id":1,"title":"Test","identifiers":{"zotero":"ZK1","zotero_rev":"mtime1+hash1","zotero_src":"myalias"},"formats":["/tmp/test.pdf"]}]`), nil
				case "add":
					return []byte("Added book ids: 42\n"), nil
				case "set_metadata":
					return []byte("ok"), nil
				default:
					return nil, fmt.Errorf("unexpected subcommand: %s (args: %v)", sub, cmd.Args)
				}
			},
		}

		// Call 1: list (via buildTrackedMap -> ListWithFilter -> calibredb)
		ctx := context.Background()
		out, err := exe.ListWithFilter(ctx, "identifiers:zotero:", "id,title,identifiers,formats")
		if err != nil {
			t.Fatalf("ListWithFilter: %v", err)
		}
		if !bytes.Contains(out, []byte("ZK1")) {
			t.Errorf("ListWithFilter output missing ZK1: %s", out)
		}

		// Call 2: set_metadata (via SetMetadata -> calibredb)
		if err := exe.SetMetadata(ctx, 1, map[string]string{"tags": "test"}); err != nil {
			t.Fatalf("SetMetadata: %v", err)
		}

		// Verify both calls went through the same closure
		if len(callLog) != 2 {
			t.Fatalf("expected 2 calls, got %d: %v", len(callLog), callLog)
		}
		if callLog[0] != "list" {
			t.Errorf("call[0] = %q, want %q", callLog[0], "list")
		}
		if callLog[1] != "set_metadata" {
			t.Errorf("call[1] = %q, want %q", callLog[1], "set_metadata")
		}
	})

	t.Run("with library path", func(t *testing.T) {
		var callLog []string

		exe := &CalibreExe{
			LibraryPath: "/tmp/testlib",
			CalibreCLI: func(cmd *exec.Cmd) ([]byte, error) {
				sub := findSubcommand(cmd.Args)
				callLog = append(callLog, sub)

				// Verify --library-path is present
				hasLibPath := false
				for _, a := range cmd.Args {
					if strings.HasPrefix(a, "--library-path=") {
						hasLibPath = true
					}
				}
				if !hasLibPath {
					t.Errorf("expected --library-path in args, got: %v", cmd.Args)
				}

				switch sub {
				case "list":
					return []byte(`[]`), nil
				case "add":
					return []byte("Added book ids: 7\n"), nil
				case "set_metadata":
					return []byte("ok"), nil
				default:
					return nil, fmt.Errorf("unexpected: %s", sub)
				}
			},
		}

		ctx := context.Background()
		_, err := exe.ListWithFilter(ctx, "", "id")
		if err != nil {
			t.Fatalf("ListWithFilter: %v", err)
		}
		if err := exe.SetMetadata(ctx, 7, map[string]string{"tags": "x"}); err != nil {
			t.Fatalf("SetMetadata: %v", err)
		}

		if len(callLog) != 2 {
			t.Fatalf("expected 2 calls, got %d: %v", len(callLog), callLog)
		}
	})

	t.Run("three-call sequence: list + add + set_metadata", func(t *testing.T) {
		var callLog []string

		exe := &CalibreExe{
			CalibreCLI: func(cmd *exec.Cmd) ([]byte, error) {
				sub := findSubcommand(cmd.Args)
				callLog = append(callLog, sub)

				switch sub {
				case "list":
					return []byte(`[]`), nil
				case "add":
					return []byte("Added book ids: 99\n"), nil
				case "set_metadata":
					return []byte("ok"), nil
				default:
					return nil, fmt.Errorf("unexpected: %s", sub)
				}
			},
		}

		ctx := context.Background()

		// Simulate the SyncEntries flow: list tracked → add → set metadata
		_, _ = exe.ListWithFilter(ctx, "identifiers:zotero:", "id,title,identifiers,formats")
		id, err := exe.Add(ctx, "Test Book", "/tmp/test.pdf")
		if err != nil {
			t.Fatalf("Add: %v", err)
		}
		if id != 99 {
			t.Errorf("Add returned id %d, want 99", id)
		}
		if err := exe.SetMetadata(ctx, id, map[string]string{"identifiers": "zotero:ZK1"}); err != nil {
			t.Fatalf("SetMetadata: %v", err)
		}

		if len(callLog) != 3 {
			t.Fatalf("expected 3 calls, got %d: %v", len(callLog), callLog)
		}
		want := []string{"list", "add", "set_metadata"}
		for i, w := range want {
			if callLog[i] != w {
				t.Errorf("call[%d] = %q, want %q", i, callLog[i], w)
			}
		}
	})
}

// ═══════════════════════════════════════════════════════════════════
// Spike: A2 — Can the fake simulate the duplicate-detect path by
// writing into cmd.Stderr?
//
// The assumption: calibredbCapturingStderr sets cmd.Stderr to an
// io.MultiWriter(&stderrBuf, os.Stderr) BEFORE calling CalibreCLI.
// If the fake writes to cmd.Stderr, those bytes appear in the stderrBuf
// that Add inspects for the "not added as they already exist" marker.
// ═══════════════════════════════════════════════════════════════════

func TestSpike_A2_StderrDuplicateDetect(t *testing.T) {
	t.Run("fake writes duplicate marker to cmd.Stderr", func(t *testing.T) {
		callCount := 0

		exe := &CalibreExe{
			CalibreCLI: func(cmd *exec.Cmd) ([]byte, error) {
				callCount++
				sub := findSubcommand(cmd.Args)

				switch {
				case sub == "add":
					// Simulate calibredb writing "not added as they already exist"
					// to stderr and returning a non-parseable stdout (no "Added book ids:")
					if cmd.Stderr != nil {
						_, _ = cmd.Stderr.Write([]byte("The following books were not added as they already exist in the database\n"))
					}
					// Return stdout that has NO "Added book ids:" line
					return []byte("    /tmp/test.pdf\n"), nil

				case sub == "list":
					// The duplicate-detect path calls findBookIDByTitle which does a list
					return []byte(`[{"id":42,"title":"Test Book"}]`), nil

				default:
					return nil, fmt.Errorf("unexpected: %s (args: %v)", sub, cmd.Args)
				}
			},
		}

		ctx := context.Background()
		id, err := exe.Add(ctx, "Test Book", "/tmp/test.pdf")
		if err != nil {
			t.Fatalf("Add should have recovered via duplicate path, got error: %v", err)
		}
		if id != 42 {
			t.Errorf("Add returned id %d, want 42 (from findBookIDByTitle)", id)
		}
		// Should have made 2 calls: add (which triggered duplicate) + list (title lookup)
		if callCount != 2 {
			t.Errorf("expected 2 CalibreCLI calls, got %d", callCount)
		}
	})

	t.Run("stderr written by fake is inspected by production code", func(t *testing.T) {
		// Verify the seam: cmd.Stderr is set to io.MultiWriter before CalibreCLI is called
		var stderrWasSet bool

		exe := &CalibreExe{
			CalibreCLI: func(cmd *exec.Cmd) ([]byte, error) {
				sub := findSubcommand(cmd.Args)

				// Check that cmd.Stderr is not nil and is writable
				stderrWasSet = cmd.Stderr != nil

				switch sub {
				case "add":
					// Write nothing to stderr → fresh add path
					return []byte("Added book ids: 10\n"), nil
				default:
					return []byte("ok"), nil
				}
			},
		}

		ctx := context.Background()
		id, err := exe.Add(ctx, "Test", "/tmp/t.pdf")
		if err != nil {
			t.Fatalf("Add: %v", err)
		}
		if id != 10 {
			t.Errorf("id = %d, want 10", id)
		}
		if !stderrWasSet {
			t.Error("cmd.Stderr was nil when CalibreCLI was called — " +
				"the io.MultiWriter seam is not set before the fake runs")
		}
	})

	t.Run("duplicate marker on stdout also triggers recovery", func(t *testing.T) {
		// Production code checks both stderr AND stdout for the duplicate marker
		// (calibreExec.go:210). Verify the stdout path also works.
		exe := &CalibreExe{
			CalibreCLI: func(cmd *exec.Cmd) ([]byte, error) {
				sub := findSubcommand(cmd.Args)
				switch sub {
				case "add":
					// Duplicate marker in stdout, no stderr write
					return []byte("The following books were not added as they already exist in the database\n    /tmp/test.pdf\n"), nil
				case "list":
					return []byte(`[{"id":55,"title":"Dup Book"}]`), nil
				default:
					return nil, fmt.Errorf("unexpected: %s", sub)
				}
			},
		}

		ctx := context.Background()
		id, err := exe.Add(ctx, "Dup Book", "/tmp/test.pdf")
		if err != nil {
			t.Fatalf("Add: %v", err)
		}
		if id != 55 {
			t.Errorf("id = %d, want 55", id)
		}
	})
}

// findSubcommand now lives in fakecalibre_test.go, shared with the engine
// tests. These spike tests keep their hand-rolled closures on purpose: they
// assert properties OF the seam (that cmd.Stderr is wired, that
// --library-path is present), which an abstraction over the seam would hide.
