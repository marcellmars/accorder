package torinvite

import (
	"encoding/base64"
	"encoding/json"
	"fmt"
	"strings"
)

const TransportPrefix = "accorder-invite:"

const v1Prefix = "accorder-invite1:"

type InviteV2 struct {
	Onion         string      `json:"onion,omitempty"`
	Endpoint      string      `json:"endpoint,omitempty"`
	PublisherType string      `json:"publisher_type"`
	Auth          *InviteAuth `json:"auth,omitempty"`
	Label         string      `json:"label"`
}

type InviteAuth struct {
	Scheme     string `json:"scheme"`
	KeyPrivB32 string `json:"key_priv_b32,omitempty"`
	Token      string `json:"token,omitempty"`
}

func EncodeV2(onion, label, publisherType string, auth *InviteAuth) string {
	inv := InviteV2{
		Onion:         onion,
		PublisherType: publisherType,
		Auth:          auth,
		Label:         label,
	}
	b, _ := json.Marshal(inv)
	return TransportPrefix + base64.RawURLEncoding.EncodeToString(b)
}

func EncodeV2Clearnet(endpoint, label, publisherType, token string) string {
	inv := InviteV2{
		Endpoint:      endpoint,
		PublisherType: publisherType,
		Auth:          &InviteAuth{Scheme: "bearer", Token: token},
		Label:         label,
	}
	b, _ := json.Marshal(inv)
	return TransportPrefix + base64.RawURLEncoding.EncodeToString(b)
}

func Decode(blob string) (*InviteV2, error) {
	if strings.HasPrefix(blob, v1Prefix) {
		return nil, fmt.Errorf("torinvite: v1 invites are no longer supported; please request a new invite")
	}
	if !strings.HasPrefix(blob, TransportPrefix) {
		return nil, fmt.Errorf("torinvite: invalid prefix (expected %q)", TransportPrefix)
	}
	payload := strings.TrimPrefix(blob, TransportPrefix)
	data, err := base64.RawURLEncoding.DecodeString(payload)
	if err != nil {
		return nil, fmt.Errorf("torinvite: base64 decode: %w", err)
	}
	var inv InviteV2
	if err := json.Unmarshal(data, &inv); err != nil {
		return nil, fmt.Errorf("torinvite: json decode: %w", err)
	}
	if inv.Onion == "" && inv.Endpoint == "" {
		return nil, fmt.Errorf("torinvite: missing onion or endpoint address")
	}
	if inv.PublisherType != "per_library" && inv.PublisherType != "aggregator" {
		return nil, fmt.Errorf("torinvite: invalid publisher_type %q (expected \"per_library\" or \"aggregator\")", inv.PublisherType)
	}
	return &inv, nil
}
