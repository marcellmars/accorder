package torinvite

import (
	"strings"
	"testing"
)

func TestInviteV2RoundTrip(t *testing.T) {
	tests := []struct {
		name          string
		onion         string
		label         string
		publisherType string
		auth          *InviteAuth
	}{
		{
			name:          "per_library with auth",
			onion:         "abc123.onion",
			label:         "my-lib",
			publisherType: "per_library",
			auth:          &InviteAuth{Scheme: "x25519", KeyPrivB32: "TESTKEY32BASE32"},
		},
		{
			name:          "aggregator with auth",
			onion:         "def456.onion",
			label:         "my-agg",
			publisherType: "aggregator",
			auth:          &InviteAuth{Scheme: "x25519", KeyPrivB32: "AGGKEY32BASE32"},
		},
		{
			name:          "per_library public (no auth)",
			onion:         "ghi789.onion",
			label:         "pub-lib",
			publisherType: "per_library",
			auth:          nil,
		},
		{
			name:          "aggregator public (no auth)",
			onion:         "jkl012.onion",
			label:         "pub-agg",
			publisherType: "aggregator",
			auth:          nil,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			blob := EncodeV2(tt.onion, tt.label, tt.publisherType, tt.auth)

			if !strings.HasPrefix(blob, TransportPrefix) {
				t.Fatalf("blob missing prefix %q: %s", TransportPrefix, blob)
			}

			inv, err := Decode(blob)
			if err != nil {
				t.Fatalf("Decode: %v", err)
			}

			if inv.Onion != tt.onion {
				t.Errorf("Onion = %q, want %q", inv.Onion, tt.onion)
			}
			if inv.Label != tt.label {
				t.Errorf("Label = %q, want %q", inv.Label, tt.label)
			}
			if inv.PublisherType != tt.publisherType {
				t.Errorf("PublisherType = %q, want %q", inv.PublisherType, tt.publisherType)
			}
			if tt.auth == nil {
				if inv.Auth != nil {
					t.Errorf("Auth = %+v, want nil", inv.Auth)
				}
			} else {
				if inv.Auth == nil {
					t.Fatal("Auth = nil, want non-nil")
				}
				if inv.Auth.Scheme != tt.auth.Scheme {
					t.Errorf("Auth.Scheme = %q, want %q", inv.Auth.Scheme, tt.auth.Scheme)
				}
				if inv.Auth.KeyPrivB32 != tt.auth.KeyPrivB32 {
					t.Errorf("Auth.KeyPrivB32 = %q, want %q", inv.Auth.KeyPrivB32, tt.auth.KeyPrivB32)
				}
			}
		})
	}
}

func TestInviteV1Rejected(t *testing.T) {
	v1Blob := "accorder-invite1:eyJvbmlvbiI6InRlc3Qub25pb24iLCJ0b3JfY2xpZW50X2F1dGgiOiJrZXkiLCJsYWJlbCI6ImwifQ"
	_, err := Decode(v1Blob)
	if err == nil {
		t.Fatal("expected error for v1 invite, got nil")
	}
	if !strings.Contains(err.Error(), "v1 invites are no longer supported") {
		t.Errorf("unexpected error: %v", err)
	}
}

func TestDecodeInvalidPublisherType(t *testing.T) {
	blob := EncodeV2("test.onion", "label", "per_library", nil)

	// Manually craft a blob with an invalid publisher_type by encoding directly
	badBlob := EncodeV2("test.onion", "label", "invalid", nil)

	// The EncodeV2 will produce a valid blob but Decode should reject "invalid"
	_, err := Decode(badBlob)
	if err == nil {
		t.Fatal("expected error for invalid publisher_type, got nil")
	}
	if !strings.Contains(err.Error(), "invalid publisher_type") {
		t.Errorf("unexpected error: %v", err)
	}

	// Valid blob should decode fine
	_, err = Decode(blob)
	if err != nil {
		t.Fatalf("valid blob failed: %v", err)
	}
}

func TestInviteV2_ClearnetRoundTrip(t *testing.T) {
	blob := EncodeV2Clearnet("https://example.com/", "mylib", "aggregator", "deadbeef")
	inv, err := Decode(blob)
	if err != nil {
		t.Fatal(err)
	}
	if inv.Endpoint != "https://example.com/" {
		t.Fatalf("endpoint: %q", inv.Endpoint)
	}
	if inv.Onion != "" {
		t.Fatalf("onion should be empty: %q", inv.Onion)
	}
	if inv.Auth.Token != "deadbeef" {
		t.Fatalf("token: %q", inv.Auth.Token)
	}
	if inv.Auth.Scheme != "bearer" {
		t.Fatalf("scheme: %q", inv.Auth.Scheme)
	}
}

func TestInviteV2_TorBackwardCompat(t *testing.T) {

	// Existing Tor invites still decode correctly after omitempty change
	blob := EncodeV2("abc.onion", "test", "aggregator", nil)
	inv, err := Decode(blob)
	if err != nil {
		t.Fatal(err)
	}
	if inv.Onion != "abc.onion" {
		t.Fatalf("onion: %q", inv.Onion)
	}
	if inv.Endpoint != "" {
		t.Fatalf("endpoint should be empty: %q", inv.Endpoint)
	}
}

func TestInviteV2_MissingBothAddresses(t *testing.T) {

	// Neither Onion nor Endpoint → decode should fail
	blob := EncodeV2("", "test", "aggregator", nil)

	// EncodeV2 sets Onion to empty string; with omitempty it won't be in JSON
	_, err := Decode(blob)
	if err == nil {
		t.Fatal("expected error for missing both onion and endpoint")
	}
	if !strings.Contains(err.Error(), "missing onion or endpoint") {
		t.Fatalf("unexpected error: %v", err)
	}
}
