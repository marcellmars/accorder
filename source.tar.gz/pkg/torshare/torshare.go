//go:build tor

package torshare

import (
	"accorder/internal/torsupervisor"
	"context"
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

func StateDir(configDir, alias string) string {
	return filepath.Join(configDir, "tor", alias)
}

func ReadOnionAddr(configDir, alias string) (string, error) {
	hostnameFile := filepath.Join(StateDir(configDir, alias), "hostname")
	data, err := os.ReadFile(hostnameFile)
	if err != nil {
		if os.IsNotExist(err) {
			return "", fmt.Errorf("no onion service found for alias %q — run share-tor first", alias)
		}
		return "", fmt.Errorf("read hostname: %w", err)
	}
	hostname := string(data)
	if hostname == "" {
		return "", fmt.Errorf("empty hostname file for alias %q", alias)
	}
	return hostname, nil
}

func ReadDualOnionAddrs(configDir, alias string) (browser, index string, err error) {
	base := StateDir(configDir, alias)
	read := func(sub string) (string, error) {
		data, err := os.ReadFile(filepath.Join(base, sub, "hostname"))
		if err != nil {
			if os.IsNotExist(err) {
				return "", fmt.Errorf("no %s onion found for alias %q — share first", sub, alias)
			}
			return "", fmt.Errorf("read %s hostname: %w", sub, err)
		}
		h := strings.TrimSpace(string(data))
		if h == "" {
			return "", fmt.Errorf("empty %s hostname file for alias %q", sub, alias)
		}
		return h, nil
	}
	if browser, err = read("browser"); err != nil {
		return "", "", err
	}
	if index, err = read("index"); err != nil {
		return "", "", err
	}
	return browser, index, nil
}

func StartSupervisor(ctx context.Context, localAddr, alias, configDir string) (*torsupervisor.Supervisor, error) {
	stateDir := StateDir(configDir, alias)
	hsDir := stateDir

	if err := os.MkdirAll(filepath.Join(hsDir, "authorized_clients"), 0700); err != nil {
		return nil, fmt.Errorf("torshare: mkdir state: %w", err)
	}

	sv := &torsupervisor.Supervisor{}
	cfg := torsupervisor.Config{
		DataDir: stateDir,
		HiddenServices: []torsupervisor.HiddenServiceConfig{
			{Dir: hsDir, VirtPort: 80, TargetAddr: localAddr},
		},
	}

	if err := sv.Start(ctx, cfg); err != nil {
		return nil, fmt.Errorf("torshare: start tor: %w", err)
	}
	return sv, nil
}

func WrapStartSupervisor(ctx context.Context, localAddr, alias, configDir string) (string, func() error, error) {
	sv, err := StartSupervisor(ctx, localAddr, alias, configDir)
	if err != nil {
		return "", nil, err
	}
	return sv.OnionHostname(), sv.Stop, nil
}
