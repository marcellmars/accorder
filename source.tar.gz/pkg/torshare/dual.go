//go:build tor

package torshare

import (
	"accorder/internal/torsupervisor"
	"context"
	"fmt"
	"log"
	"os"
	"path/filepath"
)

type DualOnionConfig struct {
	BrowserPublic bool
	IndexPublic   bool
}

type DualOnionResult struct {
	BrowserOnion string
	IndexOnion   string
	StopFn       func() error
}

func WrapStartDualSupervisor(ctx context.Context, browserAddr, indexAddr, alias, configDir string, dualCfg DualOnionConfig) (DualOnionResult, error) {
	baseDir := filepath.Join(configDir, "tor", alias)
	browserDir := filepath.Join(baseDir, "browser")
	indexDir := filepath.Join(baseDir, "index")

	for _, dir := range []string{browserDir, indexDir} {
		if err := os.MkdirAll(filepath.Join(dir, "authorized_clients"), 0700); err != nil {
			return DualOnionResult{}, fmt.Errorf("torshare: mkdir dual state: %w", err)
		}
	}

	if dualCfg.BrowserPublic {
		clearAuthClients(filepath.Join(browserDir, "authorized_clients"))
	}
	if dualCfg.IndexPublic {
		clearAuthClients(filepath.Join(indexDir, "authorized_clients"))
	}

	sv := &torsupervisor.Supervisor{}
	cfg := torsupervisor.Config{
		DataDir: baseDir,
		HiddenServices: []torsupervisor.HiddenServiceConfig{
			{Dir: browserDir, VirtPort: 80, TargetAddr: browserAddr},
			{Dir: indexDir, VirtPort: 80, TargetAddr: indexAddr},
		},
	}

	if err := sv.Start(ctx, cfg); err != nil {
		return DualOnionResult{}, fmt.Errorf("torshare: start dual tor: %w", err)
	}

	hostnames := sv.OnionHostnames()
	if len(hostnames) < 2 {
		_ = sv.Stop()
		return DualOnionResult{}, fmt.Errorf("torshare: expected 2 onion hostnames, got %d", len(hostnames))
	}

	return DualOnionResult{
		BrowserOnion: hostnames[0],
		IndexOnion:   hostnames[1],
		StopFn:       sv.Stop,
	}, nil
}

func clearAuthClients(dir string) {
	entries, _ := filepath.Glob(filepath.Join(dir, "*.auth"))
	for _, e := range entries {
		if err := os.Remove(e); err != nil {
			log.Printf("torshare: clear auth client %s: %v", filepath.Base(e), err)
		}
	}
}
