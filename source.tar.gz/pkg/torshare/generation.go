package torshare

import (
	"encoding/binary"
	"fmt"
)

// Generation sentinel encode/decode are pure data routines with no Tor
// dependency, so they live in an untagged file. The on-disk shape is:
//
//	bytes  0..16 : BaseGeneration (16 raw bytes, lineage identifier)
//	bytes 16..24 : Generation (uint64 big-endian, monotonically increasing)
//
// Producers: the index build (per-library) and `motw aggregate-build` write
// a _GENERATION sentinel beside the .zst they emit.
// Consumers: clients (sync, share-tor, motw serve) poll the small sentinel
// file to decide whether to refetch the index.

func EncodeGeneration(base [16]byte, gen uint64) []byte {
	buf := make([]byte, 24)
	copy(buf[:16], base[:])
	binary.BigEndian.PutUint64(buf[16:], gen)
	return buf
}

func DecodeGeneration(b []byte) (base [16]byte, gen uint64, err error) {
	if len(b) != 24 {
		return base, 0, fmt.Errorf("torshare: generation sentinel: expected 24 bytes, got %d", len(b))
	}
	copy(base[:], b[:16])
	gen = binary.BigEndian.Uint64(b[16:])
	return base, gen, nil
}
