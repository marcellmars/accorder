package libraryflow

import (
	"fmt"
	"golang.org/x/sys/windows"
	"strings"
)

func LocalFileEvidence(path string) (identity, capability string) {
	name, err := windows.UTF16PtrFromString(path)
	if err != nil {
		return "", ""
	}
	handle, err := windows.CreateFile(name, windows.FILE_READ_ATTRIBUTES,
		windows.FILE_SHARE_READ|windows.FILE_SHARE_WRITE|windows.FILE_SHARE_DELETE,
		nil, windows.OPEN_EXISTING, windows.FILE_FLAG_BACKUP_SEMANTICS, 0)
	if err != nil {
		return "", ""
	}
	defer windows.CloseHandle(handle)
	var info windows.ByHandleFileInformation
	if windows.GetFileInformationByHandle(handle, &info) != nil {
		return "", ""
	}
	return windowsHandleEvidence(handle, name, &info)
}

func windowsHandleEvidence(handle windows.Handle, name *uint16, info *windows.ByHandleFileInformation) (identity, capability string) {
	if info.FileIndexHigh == 0 && info.FileIndexLow == 0 {
		return "", ""
	}
	identity = fmt.Sprintf("%x:%08x%08x", info.VolumeSerialNumber, info.FileIndexHigh, info.FileIndexLow)
	var fsName [64]uint16
	var volume [32768]uint16
	if windows.GetVolumeInformationByHandle(handle, nil, 0, nil, nil, nil, &fsName[0], uint32(len(fsName))) == nil &&
		strings.EqualFold(windows.UTF16ToString(fsName[:]), "NTFS") &&
		windows.GetVolumePathName(name, &volume[0], uint32(len(volume))) == nil && windows.GetDriveType(&volume[0]) == windows.DRIVE_FIXED {
		capability = "windows:NTFS"
	}
	return identity, capability
}
