package libraryflow

import (
	"fmt"
	"os"
	"syscall"

	"golang.org/x/sys/unix"
)

func observeLocalObject(path, localPath string, info os.FileInfo) (Object, string, string) {
	object := NewLocalObjectAt(path, localPath, info)
	stat, ok := info.Sys().(*syscall.Stat_t)
	var fs unix.Statfs_t
	if !ok || stat.Ino == 0 || unix.Statfs(localPath, &fs) != nil {
		return object, "", ""
	}
	id := fmt.Sprintf("%x:%x", stat.Dev, stat.Ino)
	return object, id, darwinFileCapability(&fs)
}
