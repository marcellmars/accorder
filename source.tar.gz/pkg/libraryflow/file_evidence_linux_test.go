package libraryflow

import (
	"testing"

	"golang.org/x/sys/unix"
)

func TestLinuxDurableFileCapability(t *testing.T) {
	if linuxFileCapability(unix.EXT4_SUPER_MAGIC) == "" {
		t.Fatal("ext4 must support retained native evidence")
	}
	for _, fs := range []int64{unix.TMPFS_MAGIC, unix.NFS_SUPER_MAGIC, 0} {
		if got := linuxFileCapability(fs); got != "" {
			t.Errorf("filesystem %x unexpectedly supplies durable evidence: %s", fs, got)
		}
	}
}

func TestLinuxTmpfsEvidenceIsInstanceScoped(t *testing.T) {
	fs := unix.Statfs_t{Type: unix.TMPFS_MAGIC}
	if localFilesystemCapability(&fs) != "" {
		t.Fatal("tmpfs without instance identity was trusted")
	}
	fs.Fsid.Val = [2]int32{123, 456}
	first := localFilesystemCapability(&fs)
	if first == "" || first != localFilesystemCapability(&fs) {
		t.Fatal("same tmpfs instance must be reusable")
	}
	fs.Fsid.Val[1]++
	if first == localFilesystemCapability(&fs) {
		t.Fatal("new tmpfs instance reused old evidence")
	}
}
