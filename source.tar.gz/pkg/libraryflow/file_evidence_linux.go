package libraryflow

import (
	"fmt"

	"golang.org/x/sys/unix"
)

// Unknown filesystems deliberately provide no trust capability; callers may
// still compile local catalogs.
func localFilesystemCapability(fs *unix.Statfs_t) string {
	if fs.Type == unix.TMPFS_MAGIC {
		// Linux shmem_statfs derives this ID from the per-superblock UUID.
		// Scope reusable evidence to this tmpfs instance, not merely its type:
		// a remounted/recreated tmpfs must not inherit the previous identity.
		if fs.Fsid.Val == [2]int32{} {
			return ""
		}
		return fmt.Sprintf("linux:%x:instance:%08x%08x", fs.Type, uint32(fs.Fsid.Val[0]), uint32(fs.Fsid.Val[1]))
	}
	return linuxFileCapability(int64(fs.Type))
}

func linuxFileCapability(fsType int64) string {
	switch fsType {
	case unix.EXT4_SUPER_MAGIC:
		return fmt.Sprintf("linux:%x", fsType)
	}
	// A filesystem type alone is insufficient for tmpfs; the caller must bind
	// its current instance ID as well.
	return ""
}
