package libraryflow

import (
	"fmt"
	"golang.org/x/sys/unix"
)

// LocalFileEvidence returns metadata only. Unknown filesystems deliberately
// provide no trust capability; callers may still compile local catalogs.
func LocalFileEvidence(path string) (identity, capability string) {
	var stat unix.Stat_t
	var fs unix.Statfs_t
	if unix.Stat(path, &stat) != nil || unix.Statfs(path, &fs) != nil || stat.Ino == 0 {
		return "", ""
	}
	identity = fmt.Sprintf("%x:%x", stat.Dev, stat.Ino)
	return identity, linuxFileCapability(int64(fs.Type))
}

func linuxFileCapability(fsType int64) string {
	switch fsType {
	case unix.EXT4_SUPER_MAGIC, unix.TMPFS_MAGIC:
		return fmt.Sprintf("linux:%x", fsType)
	}
	return ""
}
