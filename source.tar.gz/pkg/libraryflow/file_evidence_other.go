//go:build !linux && !darwin && !windows

package libraryflow

func LocalFileEvidence(string) (string, string) { return "", "" }
