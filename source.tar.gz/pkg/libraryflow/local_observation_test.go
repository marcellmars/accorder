package libraryflow

import (
	"encoding/json"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
)

func TestLocalObservationMatchesIndependentProbes(t *testing.T) {
	path := filepath.Join(t.TempDir(), "book.epub")
	if err := os.WriteFile(path, []byte("book"), 0o600); err != nil {
		t.Fatal(err)
	}
	info, err := os.Stat(path)
	if err != nil {
		t.Fatal(err)
	}
	want := NewLocalObjectAt("book.epub", path, info)
	wantID, wantCapability := LocalFileEvidence(path)
	got, id, capability := ObserveLocalObject("book.epub", path, info)
	if !reflect.DeepEqual(got, want) || id != wantID || capability != wantCapability {
		t.Fatalf("combined=%+v %q %q independent=%+v %q %q", got, id, capability, want, wantID, wantCapability)
	}
	raw, err := json.Marshal(got)
	if err != nil || strings.Contains(string(raw), "capability") || strings.Contains(string(raw), "identity") {
		t.Fatalf("local observation leaked into Object JSON: %s %v", raw, err)
	}
	// A failed filesystem probe must not inherit the earlier capability.
	_, _, missingCapability := ObserveLocalObject("book.epub", filepath.Join(t.TempDir(), "missing"), info)
	if missingCapability != "" {
		t.Fatal("failed observation retained capability")
	}
}
