package libraryflow

import "os"

// ObserveLocalObject returns one ephemeral metadata observation. It never reads
// payload bytes. Identity/capability are not part of Object or its wire format.
// A fresh observation is required at each independent coherence boundary.
func ObserveLocalObject(path, localPath string, info os.FileInfo) (Object, string, string) {
	return observeLocalObject(path, localPath, info)
}
