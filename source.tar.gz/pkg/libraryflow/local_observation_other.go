//go:build !linux && !darwin && !windows

package libraryflow

import "os"

func observeLocalObject(path, localPath string, info os.FileInfo) (Object, string, string) {
	return NewLocalObjectAt(path, localPath, info), "", ""
}
