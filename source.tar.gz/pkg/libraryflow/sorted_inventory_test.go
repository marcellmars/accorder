package libraryflow

import (
	"reflect"
	"testing"
)

func TestFilterSortedInventoryMatchesGeneralFilter(t *testing.T) {
	objects := []Object{{Path: "A/[Book]/book.epub"}, {Path: "B/book.pdf"}, {Path: "_GENERATION"}, {Path: "metadata.db"}, {Path: "static/library.zst"}}
	for _, excludes := range [][]string{nil, {"B/**"}, {"A/**"}} {
		for _, derived := range []bool{false, true} {
			want, err := FilterInventory(objects, excludes, derived)
			if err != nil {
				t.Fatal(err)
			}
			got, err := FilterSortedInventory(objects, excludes, derived)
			if err != nil || !reflect.DeepEqual(got, want) {
				t.Fatalf("filter mismatch: %v != %v (%v)", got, want, err)
			}
		}
	}
}

func TestFilterSortedInventoryRejectsInvalidOrdering(t *testing.T) {
	for _, objects := range [][]Object{
		{{Path: "a"}, {Path: "a"}}, {{Path: "b"}, {Path: "a"}},
		{{Path: "../escape"}}, {{Path: "a/../b"}},
		{{Path: "static/a"}, {Path: "static/a"}}, // Excluded duplicates are still invalid.
	} {
		if _, err := FilterSortedInventory(objects, nil, false); err == nil {
			t.Fatalf("accepted malformed sorted inventory: %+v", objects)
		}
	}
}
