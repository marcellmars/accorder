package libraryflow

import (
	"os"
	"time"
	"unsafe"

	"golang.org/x/sys/windows"
)

func observeLocalObject(path, localPath string, info os.FileInfo) (Object, string, string) {
	// Do not call NewLocalObjectAt: it opens a separate ChangeTime handle.
	object := Object{Path: path, Size: info.Size(), ModTime: info.ModTime().UTC()}
	name, err := windows.UTF16PtrFromString(localPath)
	if err != nil {
		return object, "", ""
	}
	handle, err := windows.CreateFile(name, windows.FILE_READ_ATTRIBUTES,
		windows.FILE_SHARE_READ|windows.FILE_SHARE_WRITE|windows.FILE_SHARE_DELETE,
		nil, windows.OPEN_EXISTING, windows.FILE_FLAG_BACKUP_SEMANTICS|windows.FILE_FLAG_OPEN_REPARSE_POINT, 0)
	if err != nil {
		return object, "", ""
	}
	defer windows.CloseHandle(handle)
	var native windows.ByHandleFileInformation
	var basic fileBasicInfo
	if windows.GetFileInformationByHandle(handle, &native) != nil ||
		native.FileAttributes&windows.FILE_ATTRIBUTE_REPARSE_POINT != 0 ||
		windows.GetFileInformationByHandleEx(handle, windows.FileBasicInfo, (*byte)(unsafe.Pointer(&basic)), uint32(unsafe.Sizeof(basic))) != nil {
		return object, "", ""
	}
	// Size, mtime, ChangeTime and identity all describe this handle, not a
	// possible replacement between DirEntry.Info and opening the handle.
	object.Size = int64(uint64(native.FileSizeHigh)<<32 | uint64(native.FileSizeLow))
	object.ModTime = time.Unix(0, native.LastWriteTime.Nanoseconds()).UTC()
	if basic.ChangeTime > 0 {
		stamp := windows.Filetime{LowDateTime: uint32(basic.ChangeTime), HighDateTime: uint32(uint64(basic.ChangeTime) >> 32)}
		object.ChangeTime = stamp.Nanoseconds()
	}
	id, capability := windowsHandleEvidence(handle, name, &native)
	return object, id, capability
}
