package libraryflow

import (
	"golang.org/x/sys/unix"
)

func localFilesystemCapability(fs *unix.Statfs_t) string {
	return darwinFileCapability(fs)
}

func darwinFileCapability(fs *unix.Statfs_t) string {
	if unix.ByteSliceToString(fs.Fstypename[:]) == "apfs" && fs.Flags&unix.MNT_LOCAL != 0 {
		return "darwin:apfs"
	}
	return ""
}
