//go:build linux || darwin

package libraryflow

import (
	"fmt"

	"golang.org/x/sys/unix"
)

func LocalFileEvidence(path string) (identity, capability string) {
	var stat unix.Stat_t
	var fs unix.Statfs_t
	if unix.Stat(path, &stat) != nil || unix.Statfs(path, &fs) != nil || stat.Ino == 0 {
		return "", ""
	}
	return fmt.Sprintf("%x:%x", stat.Dev, stat.Ino), localFilesystemCapability(&fs)
}
