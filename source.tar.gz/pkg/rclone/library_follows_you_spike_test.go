package rclone

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"sort"
	"strings"
	"testing"
	"time"

	_ "github.com/rclone/rclone/backend/local"
	_ "github.com/rclone/rclone/fs/operations"
	_ "github.com/rclone/rclone/fs/sync"
	"github.com/rclone/rclone/librclone/librclone"
)

// TestLibraryFollowsYouSpike exercises only the librclone integration
// boundaries needed by the library-follows-you study. The local backend keeps
// the spike hermetic while still running the real sync/sync, operations/list,
// core/stats, and job/status RPCs.
func TestLibraryFollowsYouSpike(t *testing.T) {
	librclone.Initialize()
	defer librclone.Finalize()

	t.Run("H1_DryRunPreservesDestinationAndCountsDeletes", spikeDryRunPreservesDestinationAndCountsDeletes)
	t.Run("H2_DryRunTransferStatsAreStable", spikeDryRunTransferStatsAreStable)
	t.Run("H3_FilteredInventoryDiffNamesDeletes", spikeFilteredInventoryDiffNamesDeletes)
	t.Run("H4_MaxDeleteAllowsPartialDeletion", spikeMaxDeleteAllowsPartialDeletion)
}

func spikeDryRunPreservesDestinationAndCountsDeletes(t *testing.T) {
	src := t.TempDir()
	dst := t.TempDir()
	spikeWriteFile(t, src, "keep.txt", "same")
	spikeWriteFile(t, dst, "keep.txt", "same")
	spikeWriteFile(t, dst, "obsolete-root.txt", "delete one")
	spikeWriteFile(t, dst, "Author/Old Book (2)/book.epub", "delete two")
	spikeWriteFile(t, dst, "Author/Old Book (2)/cover.jpg", "delete three")

	before := spikeSnapshotTree(t, dst)
	job, stats := spikeRunSync(t, src, dst, map[string]any{
		"dryRun":    true,
		"sizeOnly":  true,
		"checkers":  1,
		"transfers": 1,
	}, nil)
	after := spikeSnapshotTree(t, dst)

	if !job.Success {
		t.Fatalf("dry-run job failed: %s", job.Error)
	}
	if !reflect.DeepEqual(after, before) {
		t.Fatalf("dry run mutated destination:\nbefore=%v\nafter=%v", before, after)
	}
	if stats.Deletes != 3 {
		t.Fatalf("core/stats deletes=%d, want 3 would-delete files; stats=%+v", stats.Deletes, stats)
	}
	t.Logf("dry-run success=%v deletes=%d destination_entries_before=%d destination_entries_after=%d",
		job.Success, stats.Deletes, len(before), len(after))
}

func spikeDryRunTransferStatsAreStable(t *testing.T) {
	src := t.TempDir()
	dst := t.TempDir()
	spikeWriteFile(t, src, "new.txt", "new upload")
	spikeWriteFile(t, src, "changed.txt", "changed source bytes")
	spikeWriteFile(t, src, "unchanged.txt", "same")
	spikeWriteFile(t, dst, "changed.txt", "old")
	spikeWriteFile(t, dst, "unchanged.txt", "same")

	before := spikeSnapshotTree(t, dst)
	var runs []spikeStats
	for i := 0; i < 2; i++ {
		job, stats := spikeRunSync(t, src, dst, map[string]any{
			"dryRun":    true,
			"sizeOnly":  true,
			"checkers":  1,
			"transfers": 1,
		}, nil)
		if !job.Success {
			t.Fatalf("dry-run %d job failed: %s", i+1, job.Error)
		}
		if stats.Transfers != 2 {
			t.Fatalf("dry-run %d transfers=%d, want 2 (one new, one changed); stats=%+v", i+1, stats.Transfers, stats)
		}
		wantBytes := int64(len("new upload") + len("changed source bytes"))
		if stats.Bytes != wantBytes {
			t.Fatalf("dry-run %d bytes=%d, want %d would-upload bytes; stats=%+v", i+1, stats.Bytes, wantBytes, stats)
		}
		if stats.Checks == 0 {
			t.Fatalf("dry-run %d checks=0, want nonzero comparison work; stats=%+v", i+1, stats)
		}
		runs = append(runs, stats)
	}

	stableA := runs[0].stableFields()
	stableB := runs[1].stableFields()
	if stableA != stableB {
		t.Fatalf("dry-run stats changed between identical runs: first=%+v second=%+v", stableA, stableB)
	}
	if after := spikeSnapshotTree(t, dst); !reflect.DeepEqual(after, before) {
		t.Fatalf("repeated dry runs mutated destination:\nbefore=%v\nafter=%v", before, after)
	}
	t.Logf("two identical dry runs: transfers=%d bytes=%d checks=%d totalTransfers=%d totalBytes=%d totalChecks=%d",
		runs[0].Transfers, runs[0].Bytes, runs[0].Checks,
		runs[0].TotalTransfers, runs[0].TotalBytes, runs[0].TotalChecks)
}

func spikeFilteredInventoryDiffNamesDeletes(t *testing.T) {
	src := t.TempDir()
	dst := t.TempDir()
	spikeWriteFile(t, src, "shared.txt", "source")
	spikeWriteFile(t, src, "Author/Keep Book (1)/book.epub", "source book")
	spikeWriteFile(t, src, "_GENERATION", "new generation")
	spikeWriteFile(t, src, "_WRITER", "new writer")
	spikeWriteFile(t, dst, "shared.txt", "destination")
	spikeWriteFile(t, dst, "Author/Keep Book (1)/book.epub", "destination book")
	spikeWriteFile(t, dst, "Author/Old Book (2)/old.epub", "obsolete book")
	spikeWriteFile(t, dst, "obsolete-root.txt", "obsolete root")
	spikeWriteFile(t, dst, "_GENERATION", "protected generation")
	spikeWriteFile(t, dst, "_WRITER", "protected writer")

	srcBefore := spikeSnapshotTree(t, src)
	dstBefore := spikeSnapshotTree(t, dst)
	excludes := []string{"/_GENERATION", "/_WRITER"}
	srcPaths := spikeListPaths(t, src, excludes)
	dstPaths := spikeListPaths(t, dst, excludes)
	wouldDelete := spikeDifference(dstPaths, srcPaths)
	want := []string{"Author/Old Book (2)/old.epub", "obsolete-root.txt"}

	if !reflect.DeepEqual(wouldDelete, want) {
		t.Fatalf("filtered inventory diff=%v, want exact would-delete paths %v; src=%v dst=%v", wouldDelete, want, srcPaths, dstPaths)
	}
	for _, marker := range []string{"_GENERATION", "_WRITER"} {
		if spikeContains(srcPaths, marker) || spikeContains(dstPaths, marker) || spikeContains(wouldDelete, marker) {
			t.Fatalf("protected marker %q leaked through exclude rules: src=%v dst=%v diff=%v", marker, srcPaths, dstPaths, wouldDelete)
		}
	}
	if srcAfter := spikeSnapshotTree(t, src); !reflect.DeepEqual(srcAfter, srcBefore) {
		t.Fatalf("operations/list mutated source: before=%v after=%v", srcBefore, srcAfter)
	}
	if dstAfter := spikeSnapshotTree(t, dst); !reflect.DeepEqual(dstAfter, dstBefore) {
		t.Fatalf("operations/list mutated destination: before=%v after=%v", dstBefore, dstAfter)
	}
	t.Logf("filtered source=%v destination=%v exact would-delete=%v (protected markers absent)", srcPaths, dstPaths, wouldDelete)
}

func spikeMaxDeleteAllowsPartialDeletion(t *testing.T) {
	src := t.TempDir()
	dst := t.TempDir()
	spikeWriteFile(t, src, "keep.txt", "same")
	spikeWriteFile(t, dst, "keep.txt", "same")
	for i := 1; i <= 3; i++ {
		spikeWriteFile(t, dst, fmt.Sprintf("obsolete-%d.txt", i), fmt.Sprintf("obsolete %d", i))
	}

	before := spikeListPaths(t, dst, nil)
	job, stats := spikeRunSync(t, src, dst, map[string]any{
		"sizeOnly":  true,
		"maxDelete": 1,
		"checkers":  1,
		"transfers": 1,
	}, nil)
	after := spikeListPaths(t, dst, nil)
	remainingObsolete := 0
	for _, path := range after {
		if strings.HasPrefix(path, "obsolete-") {
			remainingObsolete++
		}
	}

	if job.Success {
		t.Fatalf("maxDelete job unexpectedly succeeded: stats=%+v before=%v after=%v", stats, before, after)
	}
	if !strings.Contains(strings.ToLower(stats.LastError), "max-delete") {
		t.Fatalf("failed job lacks max-delete evidence in core/stats.lastError: job_error=%q stats=%+v", job.Error, stats)
	}
	if stats.Deletes != 1 {
		t.Fatalf("core/stats deletes=%d, want cap of 1 recorded before failure; stats=%+v", stats.Deletes, stats)
	}
	if remainingObsolete != 2 {
		t.Fatalf("remaining obsolete files=%d, want 2 after one partial deletion; before=%v after=%v", remainingObsolete, before, after)
	}
	if reflect.DeepEqual(after, before) {
		t.Fatalf("maxDelete behaved all-or-nothing unexpectedly; before=%v after=%v", before, after)
	}
	t.Logf("job success=%v error=%q deletes=%d before=%v after=%v", job.Success, job.Error, stats.Deletes, before, after)
}

type spikeJob struct {
	Finished bool   `json:"finished"`
	Success  bool   `json:"success"`
	Error    string `json:"error"`
}

type spikeStats struct {
	Bytes          int64  `json:"bytes"`
	TotalBytes     int64  `json:"totalBytes"`
	Checks         int64  `json:"checks"`
	TotalChecks    int64  `json:"totalChecks"`
	Transfers      int64  `json:"transfers"`
	TotalTransfers int64  `json:"totalTransfers"`
	Deletes        int64  `json:"deletes"`
	Errors         int64  `json:"errors"`
	FatalError     bool   `json:"fatalError"`
	LastError      string `json:"lastError"`
}

type spikeStableStats struct {
	Bytes          int64
	TotalBytes     int64
	Checks         int64
	TotalChecks    int64
	Transfers      int64
	TotalTransfers int64
	Deletes        int64
	Errors         int64
	FatalError     bool
	LastError      string
}

func (s spikeStats) stableFields() spikeStableStats {
	return spikeStableStats{
		Bytes:          s.Bytes,
		TotalBytes:     s.TotalBytes,
		Checks:         s.Checks,
		TotalChecks:    s.TotalChecks,
		Transfers:      s.Transfers,
		TotalTransfers: s.TotalTransfers,
		Deletes:        s.Deletes,
		Errors:         s.Errors,
		FatalError:     s.FatalError,
		LastError:      s.LastError,
	}
}

func spikeRunSync(t *testing.T, src, dst string, config map[string]any, excludes []string) (spikeJob, spikeStats) {
	t.Helper()
	payload := map[string]any{
		"srcFs":   src,
		"dstFs":   dst,
		"_async":  true,
		"_config": config,
	}
	if len(excludes) > 0 {
		payload["_filter"] = map[string]any{"ExcludeRule": excludes}
	}
	out, status := librclone.RPC("sync/sync", spikeJSON(t, payload))
	if status != 200 {
		t.Fatalf("start sync/sync: status=%d out=%s", status, out)
	}
	var started struct {
		JobID int64 `json:"jobid"`
	}
	if err := json.Unmarshal([]byte(out), &started); err != nil || started.JobID == 0 {
		t.Fatalf("decode sync job response %q: job=%+v err=%v", out, started, err)
	}

	deadline := time.Now().Add(10 * time.Second)
	var job spikeJob
	for {
		out, status = librclone.RPC("job/status", spikeJSON(t, map[string]any{"jobid": started.JobID}))
		if status != 200 {
			t.Fatalf("job/status %d: status=%d out=%s", started.JobID, status, out)
		}
		if err := json.Unmarshal([]byte(out), &job); err != nil {
			t.Fatalf("decode job/status %q: %v", out, err)
		}
		if job.Finished {
			break
		}
		if time.Now().After(deadline) {
			t.Fatalf("sync job %d did not finish in 10s; last status=%s", started.JobID, out)
		}
		time.Sleep(10 * time.Millisecond)
	}

	out, status = librclone.RPC("core/stats", spikeJSON(t, map[string]any{"group": fmt.Sprintf("job/%d", started.JobID)}))
	if status != 200 {
		t.Fatalf("core/stats job/%d: status=%d out=%s", started.JobID, status, out)
	}
	var stats spikeStats
	if err := json.Unmarshal([]byte(out), &stats); err != nil {
		t.Fatalf("decode core/stats %q: %v", out, err)
	}
	return job, stats
}

func spikeListPaths(t *testing.T, fs string, excludes []string) []string {
	t.Helper()
	payload := map[string]any{
		"fs":     fs,
		"remote": "",
		"opt": map[string]any{
			"recurse":   true,
			"filesOnly": true,
		},
	}
	if len(excludes) > 0 {
		payload["_filter"] = map[string]any{"ExcludeRule": excludes}
	}
	out, status := librclone.RPC("operations/list", spikeJSON(t, payload))
	if status != 200 {
		t.Fatalf("operations/list %s: status=%d out=%s", fs, status, out)
	}
	var response struct {
		List []struct {
			Path string `json:"Path"`
		} `json:"list"`
	}
	if err := json.Unmarshal([]byte(out), &response); err != nil {
		t.Fatalf("decode operations/list %q: %v", out, err)
	}
	paths := make([]string, 0, len(response.List))
	for _, item := range response.List {
		paths = append(paths, item.Path)
	}
	sort.Strings(paths)
	return paths
}

func spikeDifference(destination, source []string) []string {
	sourceSet := make(map[string]struct{}, len(source))
	for _, path := range source {
		sourceSet[path] = struct{}{}
	}
	var difference []string
	for _, path := range destination {
		if _, ok := sourceSet[path]; !ok {
			difference = append(difference, path)
		}
	}
	sort.Strings(difference)
	return difference
}

func spikeContains(paths []string, want string) bool {
	for _, path := range paths {
		if path == want {
			return true
		}
	}
	return false
}

func spikeWriteFile(t *testing.T, root, relative, contents string) {
	t.Helper()
	path := filepath.Join(root, filepath.FromSlash(relative))
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		t.Fatalf("mkdir fixture %s: %v", relative, err)
	}
	if err := os.WriteFile(path, []byte(contents), 0o644); err != nil {
		t.Fatalf("write fixture %s: %v", relative, err)
	}
}

func spikeSnapshotTree(t *testing.T, root string) []string {
	t.Helper()
	var snapshot []string
	err := filepath.Walk(root, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return err
		}
		if path == root {
			return nil
		}
		relative, err := filepath.Rel(root, path)
		if err != nil {
			return err
		}
		relative = filepath.ToSlash(relative)
		if info.IsDir() {
			snapshot = append(snapshot, "D "+relative)
			return nil
		}
		contents, err := os.ReadFile(path)
		if err != nil {
			return err
		}
		snapshot = append(snapshot, fmt.Sprintf("F %s %x", relative, contents))
		return nil
	})
	if err != nil {
		t.Fatalf("snapshot %s: %v", root, err)
	}
	sort.Strings(snapshot)
	return snapshot
}

func spikeJSON(t *testing.T, value any) string {
	t.Helper()
	encoded, err := json.Marshal(value)
	if err != nil {
		t.Fatalf("marshal RPC payload: %v", err)
	}
	return string(encoded)
}
