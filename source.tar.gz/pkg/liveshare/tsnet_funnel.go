package liveshare

import (
	"fmt"
	"log"
	"net/http"
	"os"
	"path/filepath"

	"tailscale.com/tsnet"
	"tailscale.com/types/logger"
)

func tailscaleStatePath(configDir string) string {
	tailscaleStateDirectoryPath := filepath.Join(configDir, "tailscale_state")
	err := os.MkdirAll(tailscaleStateDirectoryPath, os.ModePerm)
	if err != nil {
		log.Fatalln("Not able to make the Tailscale state directory.", err)
	}
	return tailscaleStateDirectoryPath
}

func Run(subdomain, authkey, calibreDir, configDir string) {

	s := &tsnet.Server{
		Dir:      tailscaleStatePath(configDir),
		Logf:     logger.Discard,
		Hostname: subdomain,
		AuthKey:  authkey,
	}
	defer s.Close()
	ln, err := s.ListenFunnel("tcp", ":443")
	if err != nil {
		log.Fatal(err)
	}
	defer ln.Close()
	// check if tailscale actually runs
	// fmt.Printf("State in directory://%v\n", s.Dir)
	fmt.Printf("https://%v\n", s.CertDomains()[0])
	fileServer := http.FileServer(http.Dir(calibreDir))
	err = http.Serve(ln, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/" {
			http.Redirect(w, r, "/BROWSE_LIBRARY.html", http.StatusFound)
		} else {
			fileServer.ServeHTTP(w, r)
		}
	}))
	log.Fatal(err)
}
